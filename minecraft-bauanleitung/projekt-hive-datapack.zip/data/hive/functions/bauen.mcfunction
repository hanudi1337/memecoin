# Baut das ganze Projekt. Vorher an die Nordwest-Ecke stellen, Füße auf Grashöhe.
kill @e[type=minecraft:marker,tag=hive_origin]
summon minecraft:marker ~ ~ ~ {Tags:["hive_origin"]}
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Baue Tempel und Labor ... (18 Teile, dauert ca. 4 Sekunden)","color":"white"}]
function hive:weiter/1