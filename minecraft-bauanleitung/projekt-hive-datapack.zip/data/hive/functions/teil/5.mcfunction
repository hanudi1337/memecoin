setblock ~18 ~-44 ~9 minecraft:light_gray_concrete
fill ~19 ~-44 ~9 ~31 ~-44 ~9 minecraft:polished_andesite
setblock ~32 ~-44 ~9 minecraft:light_gray_concrete
setblock ~33 ~-44 ~9 minecraft:white_concrete
setblock ~34 ~-44 ~9 minecraft:red_concrete
setblock ~35 ~-44 ~9 minecraft:white_concrete
setblock ~36 ~-44 ~9 minecraft:light_gray_concrete
fill ~37 ~-44 ~9 ~49 ~-44 ~9 minecraft:black_concrete
setblock ~50 ~-44 ~9 minecraft:light_gray_concrete
fill ~51 ~-44 ~9 ~63 ~-44 ~9 minecraft:polished_andesite
setblock ~64 ~-44 ~9 minecraft:light_gray_concrete
setblock ~4 ~-44 ~10 minecraft:light_gray_concrete
fill ~5 ~-44 ~10 ~17 ~-44 ~10 minecraft:polished_andesite
setblock ~18 ~-44 ~10 minecraft:light_gray_concrete
fill ~19 ~-44 ~10 ~31 ~-44 ~10 minecraft:polished_andesite
setblock ~32 ~-44 ~10 minecraft:light_gray_concrete
setblock ~33 ~-44 ~10 minecraft:white_concrete
setblock ~34 ~-44 ~10 minecraft:red_concrete
setblock ~35 ~-44 ~10 minecraft:white_concrete
setblock ~36 ~-44 ~10 minecraft:light_gray_concrete
fill ~37 ~-44 ~10 ~49 ~-44 ~10 minecraft:black_concrete
setblock ~50 ~-44 ~10 minecraft:light_gray_concrete
fill ~51 ~-44 ~10 ~63 ~-44 ~10 minecraft:polished_andesite
setblock ~64 ~-44 ~10 minecraft:light_gray_concrete
setblock ~4 ~-44 ~11 minecraft:light_gray_concrete
fill ~5 ~-44 ~11 ~17 ~-44 ~11 minecraft:polished_andesite
setblock ~18 ~-44 ~11 minecraft:light_gray_concrete
fill ~19 ~-44 ~11 ~31 ~-44 ~11 minecraft:polished_andesite
setblock ~32 ~-44 ~11 minecraft:light_gray_concrete
setblock ~33 ~-44 ~11 minecraft:white_concrete
setblock ~34 ~-44 ~11 minecraft:red_concrete
setblock ~35 ~-44 ~11 minecraft:white_concrete
setblock ~36 ~-44 ~11 minecraft:light_gray_concrete
fill ~37 ~-44 ~11 ~49 ~-44 ~11 minecraft:black_concrete
setblock ~50 ~-44 ~11 minecraft:light_gray_concrete
fill ~51 ~-44 ~11 ~63 ~-44 ~11 minecraft:polished_andesite
setblock ~64 ~-44 ~11 minecraft:light_gray_concrete
setblock ~4 ~-44 ~12 minecraft:light_gray_concrete
fill ~5 ~-44 ~12 ~17 ~-44 ~12 minecraft:polished_andesite
setblock ~18 ~-44 ~12 minecraft:light_gray_concrete
fill ~19 ~-44 ~12 ~31 ~-44 ~12 minecraft:polished_andesite
setblock ~32 ~-44 ~12 minecraft:light_gray_concrete
setblock ~33 ~-44 ~12 minecraft:white_concrete
setblock ~34 ~-44 ~12 minecraft:red_concrete
setblock ~35 ~-44 ~12 minecraft:white_concrete
setblock ~36 ~-44 ~12 minecraft:light_gray_concrete
fill ~37 ~-44 ~12 ~49 ~-44 ~12 minecraft:black_concrete
setblock ~50 ~-44 ~12 minecraft:light_gray_concrete
fill ~51 ~-44 ~12 ~63 ~-44 ~12 minecraft:polished_andesite
setblock ~64 ~-44 ~12 minecraft:light_gray_concrete
setblock ~4 ~-44 ~13 minecraft:light_gray_concrete
fill ~5 ~-44 ~13 ~17 ~-44 ~13 minecraft:polished_andesite
setblock ~18 ~-44 ~13 minecraft:light_gray_concrete
fill ~19 ~-44 ~13 ~31 ~-44 ~13 minecraft:polished_andesite
setblock ~32 ~-44 ~13 minecraft:light_gray_concrete
setblock ~33 ~-44 ~13 minecraft:white_concrete
setblock ~34 ~-44 ~13 minecraft:red_concrete
setblock ~35 ~-44 ~13 minecraft:white_concrete
setblock ~36 ~-44 ~13 minecraft:light_gray_concrete
fill ~37 ~-44 ~13 ~49 ~-44 ~13 minecraft:black_concrete
setblock ~50 ~-44 ~13 minecraft:light_gray_concrete
fill ~51 ~-44 ~13 ~63 ~-44 ~13 minecraft:polished_andesite
setblock ~64 ~-44 ~13 minecraft:light_gray_concrete
setblock ~4 ~-44 ~14 minecraft:light_gray_concrete
fill ~5 ~-44 ~14 ~17 ~-44 ~14 minecraft:polished_andesite
setblock ~18 ~-44 ~14 minecraft:light_gray_concrete
fill ~19 ~-44 ~14 ~31 ~-44 ~14 minecraft:polished_andesite
setblock ~32 ~-44 ~14 minecraft:light_gray_concrete
setblock ~33 ~-44 ~14 minecraft:white_concrete
setblock ~34 ~-44 ~14 minecraft:red_concrete
setblock ~35 ~-44 ~14 minecraft:white_concrete
setblock ~36 ~-44 ~14 minecraft:light_gray_concrete
fill ~37 ~-44 ~14 ~49 ~-44 ~14 minecraft:black_concrete
setblock ~50 ~-44 ~14 minecraft:light_gray_concrete
fill ~51 ~-44 ~14 ~63 ~-44 ~14 minecraft:polished_andesite
setblock ~64 ~-44 ~14 minecraft:light_gray_concrete
setblock ~4 ~-44 ~15 minecraft:light_gray_concrete
fill ~5 ~-44 ~15 ~17 ~-44 ~15 minecraft:polished_andesite
setblock ~18 ~-44 ~15 minecraft:light_gray_concrete
fill ~19 ~-44 ~15 ~31 ~-44 ~15 minecraft:polished_andesite
setblock ~32 ~-44 ~15 minecraft:light_gray_concrete
setblock ~33 ~-44 ~15 minecraft:white_concrete
setblock ~34 ~-44 ~15 minecraft:red_concrete
setblock ~35 ~-44 ~15 minecraft:white_concrete
setblock ~36 ~-44 ~15 minecraft:light_gray_concrete
fill ~37 ~-44 ~15 ~49 ~-44 ~15 minecraft:black_concrete
setblock ~50 ~-44 ~15 minecraft:light_gray_concrete
fill ~51 ~-44 ~15 ~63 ~-44 ~15 minecraft:polished_andesite
setblock ~64 ~-44 ~15 minecraft:light_gray_concrete
setblock ~4 ~-44 ~16 minecraft:light_gray_concrete
fill ~5 ~-44 ~16 ~17 ~-44 ~16 minecraft:polished_andesite
setblock ~18 ~-44 ~16 minecraft:light_gray_concrete
fill ~19 ~-44 ~16 ~31 ~-44 ~16 minecraft:polished_andesite
setblock ~32 ~-44 ~16 minecraft:light_gray_concrete
setblock ~33 ~-44 ~16 minecraft:white_concrete
setblock ~34 ~-44 ~16 minecraft:red_concrete
setblock ~35 ~-44 ~16 minecraft:white_concrete
setblock ~36 ~-44 ~16 minecraft:light_gray_concrete
fill ~37 ~-44 ~16 ~49 ~-44 ~16 minecraft:black_concrete
setblock ~50 ~-44 ~16 minecraft:light_gray_concrete
fill ~51 ~-44 ~16 ~63 ~-44 ~16 minecraft:polished_andesite
setblock ~64 ~-44 ~16 minecraft:light_gray_concrete
setblock ~4 ~-44 ~17 minecraft:light_gray_concrete
fill ~5 ~-44 ~17 ~17 ~-44 ~17 minecraft:polished_andesite
setblock ~18 ~-44 ~17 minecraft:light_gray_concrete
fill ~19 ~-44 ~17 ~31 ~-44 ~17 minecraft:polished_andesite
setblock ~32 ~-44 ~17 minecraft:light_gray_concrete
setblock ~33 ~-44 ~17 minecraft:white_concrete
setblock ~34 ~-44 ~17 minecraft:red_concrete
setblock ~35 ~-44 ~17 minecraft:white_concrete
setblock ~36 ~-44 ~17 minecraft:light_gray_concrete
fill ~37 ~-44 ~17 ~49 ~-44 ~17 minecraft:black_concrete
setblock ~50 ~-44 ~17 minecraft:light_gray_concrete
fill ~51 ~-44 ~17 ~63 ~-44 ~17 minecraft:polished_andesite
setblock ~64 ~-44 ~17 minecraft:light_gray_concrete
fill ~4 ~-44 ~18 ~32 ~-44 ~18 minecraft:light_gray_concrete
setblock ~33 ~-44 ~18 minecraft:white_concrete
setblock ~34 ~-44 ~18 minecraft:red_concrete
setblock ~35 ~-44 ~18 minecraft:white_concrete
fill ~36 ~-44 ~18 ~64 ~-44 ~18 minecraft:light_gray_concrete
setblock ~4 ~-44 ~19 minecraft:light_gray_concrete
fill ~5 ~-44 ~19 ~17 ~-44 ~19 minecraft:polished_andesite
setblock ~18 ~-44 ~19 minecraft:light_gray_concrete
fill ~19 ~-44 ~19 ~31 ~-44 ~19 minecraft:white_concrete
setblock ~32 ~-44 ~19 minecraft:light_gray_concrete
setblock ~33 ~-44 ~19 minecraft:white_concrete
setblock ~34 ~-44 ~19 minecraft:red_concrete
setblock ~35 ~-44 ~19 minecraft:white_concrete
setblock ~36 ~-44 ~19 minecraft:light_gray_concrete
fill ~37 ~-44 ~19 ~49 ~-44 ~19 minecraft:polished_andesite
setblock ~50 ~-44 ~19 minecraft:light_gray_concrete
fill ~51 ~-44 ~19 ~63 ~-44 ~19 minecraft:white_concrete
setblock ~64 ~-44 ~19 minecraft:light_gray_concrete
setblock ~4 ~-44 ~20 minecraft:light_gray_concrete
fill ~5 ~-44 ~20 ~17 ~-44 ~20 minecraft:polished_andesite
setblock ~18 ~-44 ~20 minecraft:light_gray_concrete
fill ~19 ~-44 ~20 ~31 ~-44 ~20 minecraft:white_concrete
setblock ~32 ~-44 ~20 minecraft:light_gray_concrete
setblock ~33 ~-44 ~20 minecraft:white_concrete
setblock ~34 ~-44 ~20 minecraft:red_concrete
setblock ~35 ~-44 ~20 minecraft:white_concrete
setblock ~36 ~-44 ~20 minecraft:light_gray_concrete
fill ~37 ~-44 ~20 ~49 ~-44 ~20 minecraft:polished_andesite
setblock ~50 ~-44 ~20 minecraft:light_gray_concrete
fill ~51 ~-44 ~20 ~63 ~-44 ~20 minecraft:white_concrete
setblock ~64 ~-44 ~20 minecraft:light_gray_concrete
setblock ~4 ~-44 ~21 minecraft:light_gray_concrete
fill ~5 ~-44 ~21 ~17 ~-44 ~21 minecraft:polished_andesite
setblock ~18 ~-44 ~21 minecraft:light_gray_concrete
fill ~19 ~-44 ~21 ~31 ~-44 ~21 minecraft:white_concrete
setblock ~32 ~-44 ~21 minecraft:light_gray_concrete
setblock ~33 ~-44 ~21 minecraft:white_concrete
setblock ~34 ~-44 ~21 minecraft:smooth_quartz
setblock ~35 ~-44 ~21 minecraft:white_concrete
setblock ~36 ~-44 ~21 minecraft:light_gray_concrete
fill ~37 ~-44 ~21 ~49 ~-44 ~21 minecraft:polished_andesite
setblock ~50 ~-44 ~21 minecraft:light_gray_concrete
fill ~51 ~-44 ~21 ~63 ~-44 ~21 minecraft:white_concrete
setblock ~64 ~-44 ~21 minecraft:light_gray_concrete
setblock ~4 ~-44 ~22 minecraft:light_gray_concrete
fill ~5 ~-44 ~22 ~17 ~-44 ~22 minecraft:polished_andesite
setblock ~18 ~-44 ~22 minecraft:light_gray_concrete
fill ~19 ~-44 ~22 ~28 ~-44 ~22 minecraft:white_concrete
fill ~29 ~-44 ~22 ~32 ~-44 ~22 minecraft:polished_andesite
fill ~33 ~-44 ~22 ~35 ~-44 ~22 minecraft:smooth_quartz
fill ~36 ~-44 ~22 ~49 ~-44 ~22 minecraft:polished_andesite
setblock ~50 ~-44 ~22 minecraft:light_gray_concrete
fill ~51 ~-44 ~22 ~63 ~-44 ~22 minecraft:white_concrete
setblock ~64 ~-44 ~22 minecraft:light_gray_concrete
setblock ~4 ~-44 ~23 minecraft:light_gray_concrete
fill ~5 ~-44 ~23 ~17 ~-44 ~23 minecraft:polished_andesite
setblock ~18 ~-44 ~23 minecraft:light_gray_concrete
fill ~19 ~-44 ~23 ~27 ~-44 ~23 minecraft:white_concrete
fill ~28 ~-44 ~23 ~29 ~-44 ~23 minecraft:polished_andesite
fill ~30 ~-44 ~23 ~33 ~-44 ~23 minecraft:smooth_quartz
setblock ~34 ~-44 ~23 minecraft:polished_diorite
fill ~35 ~-44 ~23 ~38 ~-44 ~23 minecraft:smooth_quartz
fill ~39 ~-44 ~23 ~49 ~-44 ~23 minecraft:polished_andesite
setblock ~50 ~-44 ~23 minecraft:light_gray_concrete
fill ~51 ~-44 ~23 ~63 ~-44 ~23 minecraft:white_concrete
setblock ~64 ~-44 ~23 minecraft:light_gray_concrete
setblock ~4 ~-44 ~24 minecraft:light_gray_concrete
fill ~5 ~-44 ~24 ~17 ~-44 ~24 minecraft:polished_andesite
setblock ~18 ~-44 ~24 minecraft:light_gray_concrete
fill ~19 ~-44 ~24 ~25 ~-44 ~24 minecraft:white_concrete
fill ~26 ~-44 ~24 ~27 ~-44 ~24 minecraft:polished_andesite
fill ~28 ~-44 ~24 ~29 ~-44 ~24 minecraft:smooth_quartz
fill ~30 ~-44 ~24 ~33 ~-44 ~24 minecraft:polished_diorite
setblock ~34 ~-44 ~24 minecraft:smooth_quartz
fill ~35 ~-44 ~24 ~38 ~-44 ~24 minecraft:polished_diorite
fill ~39 ~-44 ~24 ~40 ~-44 ~24 minecraft:smooth_quartz
fill ~41 ~-44 ~24 ~49 ~-44 ~24 minecraft:polished_andesite
setblock ~50 ~-44 ~24 minecraft:light_gray_concrete
fill ~51 ~-44 ~24 ~63 ~-44 ~24 minecraft:white_concrete
setblock ~64 ~-44 ~24 minecraft:light_gray_concrete
setblock ~4 ~-44 ~25 minecraft:light_gray_concrete
fill ~5 ~-44 ~25 ~17 ~-44 ~25 minecraft:polished_andesite
setblock ~18 ~-44 ~25 minecraft:light_gray_concrete
fill ~19 ~-44 ~25 ~24 ~-44 ~25 minecraft:white_concrete
fill ~25 ~-44 ~25 ~26 ~-44 ~25 minecraft:polished_andesite
setblock ~27 ~-44 ~25 minecraft:smooth_quartz
fill ~28 ~-44 ~25 ~29 ~-44 ~25 minecraft:polished_diorite
fill ~30 ~-44 ~25 ~31 ~-44 ~25 minecraft:smooth_quartz
fill ~32 ~-44 ~25 ~36 ~-44 ~25 minecraft:red_concrete
fill ~37 ~-44 ~25 ~38 ~-44 ~25 minecraft:smooth_quartz
fill ~39 ~-44 ~25 ~40 ~-44 ~25 minecraft:polished_diorite
setblock ~41 ~-44 ~25 minecraft:smooth_quartz
fill ~42 ~-44 ~25 ~49 ~-44 ~25 minecraft:polished_andesite
setblock ~50 ~-44 ~25 minecraft:light_gray_concrete
fill ~51 ~-44 ~25 ~63 ~-44 ~25 minecraft:white_concrete
setblock ~64 ~-44 ~25 minecraft:light_gray_concrete
setblock ~4 ~-44 ~26 minecraft:light_gray_concrete
fill ~5 ~-44 ~26 ~17 ~-44 ~26 minecraft:polished_andesite
setblock ~18 ~-44 ~26 minecraft:light_gray_concrete
fill ~19 ~-44 ~26 ~23 ~-44 ~26 minecraft:white_concrete
fill ~24 ~-44 ~26 ~25 ~-44 ~26 minecraft:polished_andesite
setblock ~26 ~-44 ~26 minecraft:smooth_quartz
setblock ~27 ~-44 ~26 minecraft:polished_diorite
fill ~28 ~-44 ~26 ~29 ~-44 ~26 minecraft:smooth_quartz
fill ~30 ~-44 ~26 ~31 ~-44 ~26 minecraft:red_concrete
fill ~32 ~-44 ~26 ~36 ~-44 ~26 minecraft:iron_block
fill ~37 ~-44 ~26 ~38 ~-44 ~26 minecraft:red_concrete
fill ~39 ~-44 ~26 ~40 ~-44 ~26 minecraft:smooth_quartz
setblock ~41 ~-44 ~26 minecraft:polished_diorite
setblock ~42 ~-44 ~26 minecraft:smooth_quartz
fill ~43 ~-44 ~26 ~49 ~-44 ~26 minecraft:polished_andesite
setblock ~50 ~-44 ~26 minecraft:light_gray_concrete
fill ~51 ~-44 ~26 ~63 ~-44 ~26 minecraft:white_concrete
setblock ~64 ~-44 ~26 minecraft:light_gray_concrete
setblock ~4 ~-44 ~27 minecraft:light_gray_concrete
fill ~5 ~-44 ~27 ~17 ~-44 ~27 minecraft:polished_andesite
setblock ~18 ~-44 ~27 minecraft:light_gray_concrete
fill ~19 ~-44 ~27 ~23 ~-44 ~27 minecraft:white_concrete
setblock ~24 ~-44 ~27 minecraft:polished_andesite
setblock ~25 ~-44 ~27 minecraft:smooth_quartz
setblock ~26 ~-44 ~27 minecraft:polished_diorite
setblock ~27 ~-44 ~27 minecraft:smooth_quartz
fill ~28 ~-44 ~27 ~29 ~-44 ~27 minecraft:red_concrete
fill ~30 ~-44 ~27 ~31 ~-44 ~27 minecraft:iron_block
fill ~32 ~-44 ~27 ~36 ~-44 ~27 minecraft:glass
fill ~37 ~-44 ~27 ~38 ~-44 ~27 minecraft:iron_block
fill ~39 ~-44 ~27 ~40 ~-44 ~27 minecraft:red_concrete
setblock ~41 ~-44 ~27 minecraft:smooth_quartz
setblock ~42 ~-44 ~27 minecraft:polished_diorite
setblock ~43 ~-44 ~27 minecraft:smooth_quartz
fill ~44 ~-44 ~27 ~49 ~-44 ~27 minecraft:polished_andesite
setblock ~50 ~-44 ~27 minecraft:light_gray_concrete
fill ~51 ~-44 ~27 ~63 ~-44 ~27 minecraft:white_concrete
setblock ~64 ~-44 ~27 minecraft:light_gray_concrete
setblock ~4 ~-44 ~28 minecraft:light_gray_concrete
fill ~5 ~-44 ~28 ~17 ~-44 ~28 minecraft:polished_andesite
setblock ~18 ~-44 ~28 minecraft:light_gray_concrete
fill ~19 ~-44 ~28 ~22 ~-44 ~28 minecraft:white_concrete
setblock ~23 ~-44 ~28 minecraft:polished_andesite
setblock ~24 ~-44 ~28 minecraft:smooth_quartz
setblock ~25 ~-44 ~28 minecraft:polished_diorite
setblock ~26 ~-44 ~28 minecraft:smooth_quartz
setblock ~27 ~-44 ~28 minecraft:red_concrete
fill ~28 ~-44 ~28 ~29 ~-44 ~28 minecraft:iron_block
fill ~30 ~-44 ~28 ~38 ~-44 ~28 minecraft:glass
fill ~39 ~-44 ~28 ~40 ~-44 ~28 minecraft:iron_block
setblock ~41 ~-44 ~28 minecraft:red_concrete
setblock ~42 ~-44 ~28 minecraft:smooth_quartz
setblock ~43 ~-44 ~28 minecraft:polished_diorite
setblock ~44 ~-44 ~28 minecraft:smooth_quartz
fill ~45 ~-44 ~28 ~49 ~-44 ~28 minecraft:polished_andesite
setblock ~50 ~-44 ~28 minecraft:light_gray_concrete
fill ~51 ~-44 ~28 ~63 ~-44 ~28 minecraft:white_concrete
setblock ~64 ~-44 ~28 minecraft:light_gray_concrete
setblock ~4 ~-44 ~29 minecraft:light_gray_concrete
fill ~5 ~-44 ~29 ~17 ~-44 ~29 minecraft:polished_andesite
setblock ~18 ~-44 ~29 minecraft:light_gray_concrete
fill ~19 ~-44 ~29 ~21 ~-44 ~29 minecraft:white_concrete
fill ~22 ~-44 ~29 ~23 ~-44 ~29 minecraft:polished_andesite
setblock ~24 ~-44 ~29 minecraft:smooth_quartz
setblock ~25 ~-44 ~29 minecraft:polished_diorite
setblock ~26 ~-44 ~29 minecraft:smooth_quartz
setblock ~27 ~-44 ~29 minecraft:red_concrete
setblock ~28 ~-44 ~29 minecraft:iron_block
fill ~29 ~-44 ~29 ~39 ~-44 ~29 minecraft:glass
setblock ~40 ~-44 ~29 minecraft:iron_block
setblock ~41 ~-44 ~29 minecraft:red_concrete
setblock ~42 ~-44 ~29 minecraft:smooth_quartz
setblock ~43 ~-44 ~29 minecraft:polished_diorite
setblock ~44 ~-44 ~29 minecraft:smooth_quartz
fill ~45 ~-44 ~29 ~49 ~-44 ~29 minecraft:polished_andesite
setblock ~50 ~-44 ~29 minecraft:light_gray_concrete
fill ~51 ~-44 ~29 ~63 ~-44 ~29 minecraft:white_concrete
setblock ~64 ~-44 ~29 minecraft:light_gray_concrete
setblock ~4 ~-44 ~30 minecraft:light_gray_concrete
fill ~5 ~-44 ~30 ~17 ~-44 ~30 minecraft:polished_andesite
setblock ~18 ~-44 ~30 minecraft:light_gray_concrete
fill ~19 ~-44 ~30 ~21 ~-44 ~30 minecraft:white_concrete
setblock ~22 ~-44 ~30 minecraft:polished_andesite
setblock ~23 ~-44 ~30 minecraft:smooth_quartz
setblock ~24 ~-44 ~30 minecraft:polished_diorite
setblock ~25 ~-44 ~30 minecraft:smooth_quartz
setblock ~26 ~-44 ~30 minecraft:red_concrete
setblock ~27 ~-44 ~30 minecraft:iron_block
fill ~28 ~-44 ~30 ~40 ~-44 ~30 minecraft:glass
setblock ~41 ~-44 ~30 minecraft:iron_block
setblock ~42 ~-44 ~30 minecraft:red_concrete
setblock ~43 ~-44 ~30 minecraft:smooth_quartz
setblock ~44 ~-44 ~30 minecraft:polished_diorite
setblock ~45 ~-44 ~30 minecraft:smooth_quartz
fill ~46 ~-44 ~30 ~49 ~-44 ~30 minecraft:polished_andesite
setblock ~50 ~-44 ~30 minecraft:light_gray_concrete
fill ~51 ~-44 ~30 ~63 ~-44 ~30 minecraft:white_concrete
setblock ~64 ~-44 ~30 minecraft:light_gray_concrete
setblock ~4 ~-44 ~31 minecraft:light_gray_concrete
fill ~5 ~-44 ~31 ~17 ~-44 ~31 minecraft:polished_andesite
setblock ~18 ~-44 ~31 minecraft:light_gray_concrete
fill ~19 ~-44 ~31 ~21 ~-44 ~31 minecraft:white_concrete
setblock ~22 ~-44 ~31 minecraft:polished_andesite
setblock ~23 ~-44 ~31 minecraft:smooth_quartz
setblock ~24 ~-44 ~31 minecraft:polished_diorite
setblock ~25 ~-44 ~31 minecraft:smooth_quartz
setblock ~26 ~-44 ~31 minecraft:red_concrete
setblock ~27 ~-44 ~31 minecraft:iron_block
fill ~28 ~-44 ~31 ~31 ~-44 ~31 minecraft:glass
fill ~32 ~-44 ~31 ~36 ~-44 ~31 minecraft:iron_block
fill ~37 ~-44 ~31 ~40 ~-44 ~31 minecraft:glass
setblock ~41 ~-44 ~31 minecraft:iron_block
setblock ~42 ~-44 ~31 minecraft:red_concrete
setblock ~43 ~-44 ~31 minecraft:smooth_quartz
setblock ~44 ~-44 ~31 minecraft:polished_diorite
setblock ~45 ~-44 ~31 minecraft:smooth_quartz
fill ~46 ~-44 ~31 ~49 ~-44 ~31 minecraft:polished_andesite
setblock ~50 ~-44 ~31 minecraft:light_gray_concrete
fill ~51 ~-44 ~31 ~63 ~-44 ~31 minecraft:white_concrete
setblock ~64 ~-44 ~31 minecraft:light_gray_concrete
fill ~4 ~-44 ~32 ~21 ~-44 ~32 minecraft:light_gray_concrete
setblock ~22 ~-44 ~32 minecraft:polished_andesite
setblock ~23 ~-44 ~32 minecraft:smooth_quartz
setblock ~24 ~-44 ~32 minecraft:polished_diorite
setblock ~25 ~-44 ~32 minecraft:red_concrete
setblock ~26 ~-44 ~32 minecraft:iron_block
fill ~27 ~-44 ~32 ~31 ~-44 ~32 minecraft:glass
setblock ~32 ~-44 ~32 minecraft:iron_block
fill ~33 ~-44 ~32 ~35 ~-44 ~32 minecraft:glass
setblock ~36 ~-44 ~32 minecraft:iron_block
fill ~37 ~-44 ~32 ~41 ~-44 ~32 minecraft:glass
setblock ~42 ~-44 ~32 minecraft:iron_block
setblock ~43 ~-44 ~32 minecraft:red_concrete
setblock ~44 ~-44 ~32 minecraft:polished_diorite
setblock ~45 ~-44 ~32 minecraft:smooth_quartz
setblock ~46 ~-44 ~32 minecraft:polished_andesite
fill ~47 ~-44 ~32 ~64 ~-44 ~32 minecraft:light_gray_concrete
setblock ~4 ~-44 ~33 minecraft:light_gray_concrete
fill ~5 ~-44 ~33 ~21 ~-44 ~33 minecraft:white_concrete
fill ~22 ~-44 ~33 ~23 ~-44 ~33 minecraft:smooth_quartz
setblock ~24 ~-44 ~33 minecraft:polished_diorite
setblock ~25 ~-44 ~33 minecraft:red_concrete
setblock ~26 ~-44 ~33 minecraft:iron_block
fill ~27 ~-44 ~33 ~31 ~-44 ~33 minecraft:glass
setblock ~32 ~-44 ~33 minecraft:iron_block
setblock ~33 ~-44 ~33 minecraft:glass
setblock ~34 ~-44 ~33 minecraft:magma_block
setblock ~35 ~-44 ~33 minecraft:glass
setblock ~36 ~-44 ~33 minecraft:iron_block
fill ~37 ~-44 ~33 ~41 ~-44 ~33 minecraft:glass
setblock ~42 ~-44 ~33 minecraft:iron_block
setblock ~43 ~-44 ~33 minecraft:red_concrete
setblock ~44 ~-44 ~33 minecraft:polished_diorite
fill ~45 ~-44 ~33 ~46 ~-44 ~33 minecraft:smooth_quartz
fill ~47 ~-44 ~33 ~63 ~-44 ~33 minecraft:white_concrete
setblock ~64 ~-44 ~33 minecraft:light_gray_concrete
setblock ~4 ~-44 ~34 minecraft:light_gray_concrete
fill ~5 ~-44 ~34 ~20 ~-44 ~34 minecraft:red_concrete
fill ~21 ~-44 ~34 ~22 ~-44 ~34 minecraft:smooth_quartz
setblock ~23 ~-44 ~34 minecraft:polished_diorite
setblock ~24 ~-44 ~34 minecraft:smooth_quartz
setblock ~25 ~-44 ~34 minecraft:red_concrete
setblock ~26 ~-44 ~34 minecraft:iron_block
fill ~27 ~-44 ~34 ~31 ~-44 ~34 minecraft:glass
setblock ~32 ~-44 ~34 minecraft:iron_block
fill ~33 ~-44 ~34 ~35 ~-44 ~34 minecraft:glass
setblock ~36 ~-44 ~34 minecraft:iron_block
fill ~37 ~-44 ~34 ~41 ~-44 ~34 minecraft:glass
setblock ~42 ~-44 ~34 minecraft:iron_block
setblock ~43 ~-44 ~34 minecraft:red_concrete
setblock ~44 ~-44 ~34 minecraft:smooth_quartz
setblock ~45 ~-44 ~34 minecraft:polished_diorite
fill ~46 ~-44 ~34 ~47 ~-44 ~34 minecraft:smooth_quartz
fill ~48 ~-44 ~34 ~63 ~-44 ~34 minecraft:red_concrete
setblock ~64 ~-44 ~34 minecraft:light_gray_concrete
setblock ~4 ~-44 ~35 minecraft:light_gray_concrete
fill ~5 ~-44 ~35 ~21 ~-44 ~35 minecraft:white_concrete
fill ~22 ~-44 ~35 ~23 ~-44 ~35 minecraft:smooth_quartz
setblock ~24 ~-44 ~35 minecraft:polished_diorite
setblock ~25 ~-44 ~35 minecraft:red_concrete
setblock ~26 ~-44 ~35 minecraft:iron_block
fill ~27 ~-44 ~35 ~31 ~-44 ~35 minecraft:glass
setblock ~32 ~-44 ~35 minecraft:iron_block
setblock ~33 ~-44 ~35 minecraft:glass
setblock ~34 ~-44 ~35 minecraft:soul_sand
setblock ~35 ~-44 ~35 minecraft:glass
setblock ~36 ~-44 ~35 minecraft:iron_block
fill ~37 ~-44 ~35 ~41 ~-44 ~35 minecraft:glass
setblock ~42 ~-44 ~35 minecraft:iron_block
setblock ~43 ~-44 ~35 minecraft:red_concrete
setblock ~44 ~-44 ~35 minecraft:polished_diorite
fill ~45 ~-44 ~35 ~46 ~-44 ~35 minecraft:smooth_quartz
fill ~47 ~-44 ~35 ~63 ~-44 ~35 minecraft:white_concrete
setblock ~64 ~-44 ~35 minecraft:light_gray_concrete
fill ~4 ~-44 ~36 ~21 ~-44 ~36 minecraft:light_gray_concrete
setblock ~22 ~-44 ~36 minecraft:polished_andesite
setblock ~23 ~-44 ~36 minecraft:smooth_quartz
setblock ~24 ~-44 ~36 minecraft:polished_diorite
setblock ~25 ~-44 ~36 minecraft:red_concrete
setblock ~26 ~-44 ~36 minecraft:iron_block
fill ~27 ~-44 ~36 ~31 ~-44 ~36 minecraft:glass
setblock ~32 ~-44 ~36 minecraft:iron_block
fill ~33 ~-44 ~36 ~35 ~-44 ~36 minecraft:glass
setblock ~36 ~-44 ~36 minecraft:iron_block
fill ~37 ~-44 ~36 ~41 ~-44 ~36 minecraft:glass
setblock ~42 ~-44 ~36 minecraft:iron_block
setblock ~43 ~-44 ~36 minecraft:red_concrete
setblock ~44 ~-44 ~36 minecraft:polished_diorite
setblock ~45 ~-44 ~36 minecraft:smooth_quartz
setblock ~46 ~-44 ~36 minecraft:polished_andesite
fill ~47 ~-44 ~36 ~64 ~-44 ~36 minecraft:light_gray_concrete
setblock ~4 ~-44 ~37 minecraft:light_gray_concrete
fill ~5 ~-44 ~37 ~17 ~-44 ~37 minecraft:dark_oak_planks
setblock ~18 ~-44 ~37 minecraft:light_gray_concrete
fill ~19 ~-44 ~37 ~21 ~-44 ~37 minecraft:white_concrete
setblock ~22 ~-44 ~37 minecraft:polished_andesite
setblock ~23 ~-44 ~37 minecraft:smooth_quartz
setblock ~24 ~-44 ~37 minecraft:polished_diorite
setblock ~25 ~-44 ~37 minecraft:smooth_quartz
setblock ~26 ~-44 ~37 minecraft:red_concrete
setblock ~27 ~-44 ~37 minecraft:iron_block
fill ~28 ~-44 ~37 ~31 ~-44 ~37 minecraft:glass
fill ~32 ~-44 ~37 ~36 ~-44 ~37 minecraft:iron_block
fill ~37 ~-44 ~37 ~40 ~-44 ~37 minecraft:glass
setblock ~41 ~-44 ~37 minecraft:iron_block
setblock ~42 ~-44 ~37 minecraft:red_concrete
setblock ~43 ~-44 ~37 minecraft:smooth_quartz
setblock ~44 ~-44 ~37 minecraft:polished_diorite
setblock ~45 ~-44 ~37 minecraft:smooth_quartz
fill ~46 ~-44 ~37 ~49 ~-44 ~37 minecraft:polished_andesite
setblock ~50 ~-44 ~37 minecraft:light_gray_concrete
fill ~51 ~-44 ~37 ~63 ~-44 ~37 minecraft:spruce_planks
setblock ~64 ~-44 ~37 minecraft:light_gray_concrete
setblock ~4 ~-44 ~38 minecraft:light_gray_concrete
fill ~5 ~-44 ~38 ~17 ~-44 ~38 minecraft:dark_oak_planks
setblock ~18 ~-44 ~38 minecraft:light_gray_concrete
fill ~19 ~-44 ~38 ~21 ~-44 ~38 minecraft:white_concrete
setblock ~22 ~-44 ~38 minecraft:polished_andesite
setblock ~23 ~-44 ~38 minecraft:smooth_quartz
setblock ~24 ~-44 ~38 minecraft:polished_diorite
setblock ~25 ~-44 ~38 minecraft:smooth_quartz
setblock ~26 ~-44 ~38 minecraft:red_concrete
setblock ~27 ~-44 ~38 minecraft:iron_block
fill ~28 ~-44 ~38 ~40 ~-44 ~38 minecraft:glass
setblock ~41 ~-44 ~38 minecraft:iron_block
setblock ~42 ~-44 ~38 minecraft:red_concrete
setblock ~43 ~-44 ~38 minecraft:smooth_quartz
setblock ~44 ~-44 ~38 minecraft:polished_diorite
setblock ~45 ~-44 ~38 minecraft:smooth_quartz
fill ~46 ~-44 ~38 ~49 ~-44 ~38 minecraft:polished_andesite
setblock ~50 ~-44 ~38 minecraft:light_gray_concrete
fill ~51 ~-44 ~38 ~63 ~-44 ~38 minecraft:spruce_planks
setblock ~64 ~-44 ~38 minecraft:light_gray_concrete
setblock ~4 ~-44 ~39 minecraft:light_gray_concrete
fill ~5 ~-44 ~39 ~17 ~-44 ~39 minecraft:dark_oak_planks
setblock ~18 ~-44 ~39 minecraft:light_gray_concrete
fill ~19 ~-44 ~39 ~21 ~-44 ~39 minecraft:white_concrete
fill ~22 ~-44 ~39 ~23 ~-44 ~39 minecraft:polished_andesite
setblock ~24 ~-44 ~39 minecraft:smooth_quartz
setblock ~25 ~-44 ~39 minecraft:polished_diorite
setblock ~26 ~-44 ~39 minecraft:smooth_quartz
setblock ~27 ~-44 ~39 minecraft:red_concrete
setblock ~28 ~-44 ~39 minecraft:iron_block
fill ~29 ~-44 ~39 ~39 ~-44 ~39 minecraft:glass
setblock ~40 ~-44 ~39 minecraft:iron_block
setblock ~41 ~-44 ~39 minecraft:red_concrete
setblock ~42 ~-44 ~39 minecraft:smooth_quartz
setblock ~43 ~-44 ~39 minecraft:polished_diorite
setblock ~44 ~-44 ~39 minecraft:smooth_quartz
fill ~45 ~-44 ~39 ~49 ~-44 ~39 minecraft:polished_andesite
setblock ~50 ~-44 ~39 minecraft:light_gray_concrete
fill ~51 ~-44 ~39 ~63 ~-44 ~39 minecraft:spruce_planks
setblock ~64 ~-44 ~39 minecraft:light_gray_concrete
setblock ~4 ~-44 ~40 minecraft:light_gray_concrete
fill ~5 ~-44 ~40 ~17 ~-44 ~40 minecraft:dark_oak_planks
setblock ~18 ~-44 ~40 minecraft:light_gray_concrete
fill ~19 ~-44 ~40 ~22 ~-44 ~40 minecraft:white_concrete
setblock ~23 ~-44 ~40 minecraft:polished_andesite
setblock ~24 ~-44 ~40 minecraft:smooth_quartz
setblock ~25 ~-44 ~40 minecraft:polished_diorite
setblock ~26 ~-44 ~40 minecraft:smooth_quartz
setblock ~27 ~-44 ~40 minecraft:red_concrete
fill ~28 ~-44 ~40 ~29 ~-44 ~40 minecraft:iron_block
fill ~30 ~-44 ~40 ~38 ~-44 ~40 minecraft:glass
fill ~39 ~-44 ~40 ~40 ~-44 ~40 minecraft:iron_block
setblock ~41 ~-44 ~40 minecraft:red_concrete
setblock ~42 ~-44 ~40 minecraft:smooth_quartz
setblock ~43 ~-44 ~40 minecraft:polished_diorite
setblock ~44 ~-44 ~40 minecraft:smooth_quartz
fill ~45 ~-44 ~40 ~49 ~-44 ~40 minecraft:polished_andesite
setblock ~50 ~-44 ~40 minecraft:light_gray_concrete
fill ~51 ~-44 ~40 ~63 ~-44 ~40 minecraft:spruce_planks
setblock ~64 ~-44 ~40 minecraft:light_gray_concrete
setblock ~4 ~-44 ~41 minecraft:light_gray_concrete
fill ~5 ~-44 ~41 ~17 ~-44 ~41 minecraft:dark_oak_planks
setblock ~18 ~-44 ~41 minecraft:light_gray_concrete
fill ~19 ~-44 ~41 ~23 ~-44 ~41 minecraft:white_concrete
setblock ~24 ~-44 ~41 minecraft:polished_andesite
setblock ~25 ~-44 ~41 minecraft:smooth_quartz
setblock ~26 ~-44 ~41 minecraft:polished_diorite
setblock ~27 ~-44 ~41 minecraft:smooth_quartz
fill ~28 ~-44 ~41 ~29 ~-44 ~41 minecraft:red_concrete
fill ~30 ~-44 ~41 ~31 ~-44 ~41 minecraft:iron_block
fill ~32 ~-44 ~41 ~36 ~-44 ~41 minecraft:glass
fill ~37 ~-44 ~41 ~38 ~-44 ~41 minecraft:iron_block
fill ~39 ~-44 ~41 ~40 ~-44 ~41 minecraft:red_concrete
setblock ~41 ~-44 ~41 minecraft:smooth_quartz
setblock ~42 ~-44 ~41 minecraft:polished_diorite
setblock ~43 ~-44 ~41 minecraft:smooth_quartz
fill ~44 ~-44 ~41 ~49 ~-44 ~41 minecraft:polished_andesite
setblock ~50 ~-44 ~41 minecraft:light_gray_concrete
fill ~51 ~-44 ~41 ~63 ~-44 ~41 minecraft:spruce_planks
setblock ~64 ~-44 ~41 minecraft:light_gray_concrete
setblock ~4 ~-44 ~42 minecraft:light_gray_concrete
fill ~5 ~-44 ~42 ~17 ~-44 ~42 minecraft:dark_oak_planks
setblock ~18 ~-44 ~42 minecraft:light_gray_concrete
fill ~19 ~-44 ~42 ~23 ~-44 ~42 minecraft:white_concrete
fill ~24 ~-44 ~42 ~25 ~-44 ~42 minecraft:polished_andesite
setblock ~26 ~-44 ~42 minecraft:smooth_quartz
setblock ~27 ~-44 ~42 minecraft:polished_diorite
fill ~28 ~-44 ~42 ~29 ~-44 ~42 minecraft:smooth_quartz
fill ~30 ~-44 ~42 ~31 ~-44 ~42 minecraft:red_concrete
fill ~32 ~-44 ~42 ~36 ~-44 ~42 minecraft:iron_block
fill ~37 ~-44 ~42 ~38 ~-44 ~42 minecraft:red_concrete
fill ~39 ~-44 ~42 ~40 ~-44 ~42 minecraft:smooth_quartz
setblock ~41 ~-44 ~42 minecraft:polished_diorite
setblock ~42 ~-44 ~42 minecraft:smooth_quartz
fill ~43 ~-44 ~42 ~49 ~-44 ~42 minecraft:polished_andesite
setblock ~50 ~-44 ~42 minecraft:light_gray_concrete
fill ~51 ~-44 ~42 ~63 ~-44 ~42 minecraft:spruce_planks
setblock ~64 ~-44 ~42 minecraft:light_gray_concrete
setblock ~4 ~-44 ~43 minecraft:light_gray_concrete
fill ~5 ~-44 ~43 ~17 ~-44 ~43 minecraft:dark_oak_planks
setblock ~18 ~-44 ~43 minecraft:light_gray_concrete
fill ~19 ~-44 ~43 ~24 ~-44 ~43 minecraft:white_concrete
fill ~25 ~-44 ~43 ~26 ~-44 ~43 minecraft:polished_andesite
setblock ~27 ~-44 ~43 minecraft:smooth_quartz
fill ~28 ~-44 ~43 ~29 ~-44 ~43 minecraft:polished_diorite
fill ~30 ~-44 ~43 ~31 ~-44 ~43 minecraft:smooth_quartz
fill ~32 ~-44 ~43 ~36 ~-44 ~43 minecraft:red_concrete
fill ~37 ~-44 ~43 ~38 ~-44 ~43 minecraft:smooth_quartz
fill ~39 ~-44 ~43 ~40 ~-44 ~43 minecraft:polished_diorite
setblock ~41 ~-44 ~43 minecraft:smooth_quartz
fill ~42 ~-44 ~43 ~49 ~-44 ~43 minecraft:polished_andesite
setblock ~50 ~-44 ~43 minecraft:light_gray_concrete
fill ~51 ~-44 ~43 ~63 ~-44 ~43 minecraft:spruce_planks
setblock ~64 ~-44 ~43 minecraft:light_gray_concrete
setblock ~4 ~-44 ~44 minecraft:light_gray_concrete
fill ~5 ~-44 ~44 ~17 ~-44 ~44 minecraft:dark_oak_planks
setblock ~18 ~-44 ~44 minecraft:light_gray_concrete
fill ~19 ~-44 ~44 ~25 ~-44 ~44 minecraft:white_concrete
fill ~26 ~-44 ~44 ~27 ~-44 ~44 minecraft:polished_andesite
fill ~28 ~-44 ~44 ~29 ~-44 ~44 minecraft:smooth_quartz
fill ~30 ~-44 ~44 ~33 ~-44 ~44 minecraft:polished_diorite
setblock ~34 ~-44 ~44 minecraft:smooth_quartz
fill ~35 ~-44 ~44 ~38 ~-44 ~44 minecraft:polished_diorite
fill ~39 ~-44 ~44 ~40 ~-44 ~44 minecraft:smooth_quartz
fill ~41 ~-44 ~44 ~49 ~-44 ~44 minecraft:polished_andesite
setblock ~50 ~-44 ~44 minecraft:light_gray_concrete
fill ~51 ~-44 ~44 ~63 ~-44 ~44 minecraft:spruce_planks
setblock ~64 ~-44 ~44 minecraft:light_gray_concrete
setblock ~4 ~-44 ~45 minecraft:light_gray_concrete
fill ~5 ~-44 ~45 ~17 ~-44 ~45 minecraft:dark_oak_planks
setblock ~18 ~-44 ~45 minecraft:light_gray_concrete
fill ~19 ~-44 ~45 ~27 ~-44 ~45 minecraft:white_concrete
fill ~28 ~-44 ~45 ~29 ~-44 ~45 minecraft:polished_andesite
fill ~30 ~-44 ~45 ~33 ~-44 ~45 minecraft:smooth_quartz
setblock ~34 ~-44 ~45 minecraft:polished_diorite
fill ~35 ~-44 ~45 ~38 ~-44 ~45 minecraft:smooth_quartz
fill ~39 ~-44 ~45 ~49 ~-44 ~45 minecraft:polished_andesite
setblock ~50 ~-44 ~45 minecraft:light_gray_concrete
fill ~51 ~-44 ~45 ~63 ~-44 ~45 minecraft:spruce_planks
setblock ~64 ~-44 ~45 minecraft:light_gray_concrete
setblock ~4 ~-44 ~46 minecraft:light_gray_concrete
fill ~5 ~-44 ~46 ~17 ~-44 ~46 minecraft:dark_oak_planks
setblock ~18 ~-44 ~46 minecraft:light_gray_concrete
fill ~19 ~-44 ~46 ~28 ~-44 ~46 minecraft:white_concrete
fill ~29 ~-44 ~46 ~32 ~-44 ~46 minecraft:polished_andesite
fill ~33 ~-44 ~46 ~35 ~-44 ~46 minecraft:smooth_quartz
fill ~36 ~-44 ~46 ~49 ~-44 ~46 minecraft:polished_andesite
setblock ~50 ~-44 ~46 minecraft:light_gray_concrete
fill ~51 ~-44 ~46 ~63 ~-44 ~46 minecraft:spruce_planks
setblock ~64 ~-44 ~46 minecraft:light_gray_concrete
setblock ~4 ~-44 ~47 minecraft:light_gray_concrete
fill ~5 ~-44 ~47 ~17 ~-44 ~47 minecraft:dark_oak_planks
setblock ~18 ~-44 ~47 minecraft:light_gray_concrete
fill ~19 ~-44 ~47 ~31 ~-44 ~47 minecraft:white_concrete
setblock ~32 ~-44 ~47 minecraft:light_gray_concrete
setblock ~33 ~-44 ~47 minecraft:white_concrete
setblock ~34 ~-44 ~47 minecraft:smooth_quartz
setblock ~35 ~-44 ~47 minecraft:white_concrete
setblock ~36 ~-44 ~47 minecraft:light_gray_concrete
fill ~37 ~-44 ~47 ~49 ~-44 ~47 minecraft:polished_andesite
setblock ~50 ~-44 ~47 minecraft:light_gray_concrete
fill ~51 ~-44 ~47 ~63 ~-44 ~47 minecraft:spruce_planks
setblock ~64 ~-44 ~47 minecraft:light_gray_concrete
setblock ~4 ~-44 ~48 minecraft:light_gray_concrete
fill ~5 ~-44 ~48 ~17 ~-44 ~48 minecraft:dark_oak_planks
setblock ~18 ~-44 ~48 minecraft:light_gray_concrete
fill ~19 ~-44 ~48 ~31 ~-44 ~48 minecraft:white_concrete
setblock ~32 ~-44 ~48 minecraft:light_gray_concrete
setblock ~33 ~-44 ~48 minecraft:white_concrete
setblock ~34 ~-44 ~48 minecraft:red_concrete
setblock ~35 ~-44 ~48 minecraft:white_concrete
setblock ~36 ~-44 ~48 minecraft:light_gray_concrete
fill ~37 ~-44 ~48 ~49 ~-44 ~48 minecraft:polished_andesite
setblock ~50 ~-44 ~48 minecraft:light_gray_concrete
fill ~51 ~-44 ~48 ~63 ~-44 ~48 minecraft:spruce_planks
setblock ~64 ~-44 ~48 minecraft:light_gray_concrete
setblock ~4 ~-44 ~49 minecraft:light_gray_concrete
fill ~5 ~-44 ~49 ~17 ~-44 ~49 minecraft:dark_oak_planks
setblock ~18 ~-44 ~49 minecraft:light_gray_concrete
fill ~19 ~-44 ~49 ~31 ~-44 ~49 minecraft:white_concrete
setblock ~32 ~-44 ~49 minecraft:light_gray_concrete
setblock ~33 ~-44 ~49 minecraft:white_concrete
setblock ~34 ~-44 ~49 minecraft:red_concrete
setblock ~35 ~-44 ~49 minecraft:white_concrete
setblock ~36 ~-44 ~49 minecraft:light_gray_concrete
fill ~37 ~-44 ~49 ~49 ~-44 ~49 minecraft:polished_andesite
setblock ~50 ~-44 ~49 minecraft:light_gray_concrete
fill ~51 ~-44 ~49 ~63 ~-44 ~49 minecraft:spruce_planks
setblock ~64 ~-44 ~49 minecraft:light_gray_concrete
fill ~4 ~-44 ~50 ~32 ~-44 ~50 minecraft:light_gray_concrete
setblock ~33 ~-44 ~50 minecraft:white_concrete
setblock ~34 ~-44 ~50 minecraft:red_concrete
setblock ~35 ~-44 ~50 minecraft:white_concrete
fill ~36 ~-44 ~50 ~64 ~-44 ~50 minecraft:light_gray_concrete
setblock ~4 ~-44 ~51 minecraft:light_gray_concrete
fill ~5 ~-44 ~51 ~17 ~-44 ~51 minecraft:polished_andesite
setblock ~18 ~-44 ~51 minecraft:light_gray_concrete
fill ~19 ~-44 ~51 ~31 ~-44 ~51 minecraft:polished_andesite
setblock ~32 ~-44 ~51 minecraft:light_gray_concrete
setblock ~33 ~-44 ~51 minecraft:white_concrete
setblock ~34 ~-44 ~51 minecraft:red_concrete
setblock ~35 ~-44 ~51 minecraft:white_concrete
setblock ~36 ~-44 ~51 minecraft:light_gray_concrete
fill ~37 ~-44 ~51 ~49 ~-44 ~51 minecraft:white_concrete
setblock ~50 ~-44 ~51 minecraft:light_gray_concrete
fill ~51 ~-44 ~51 ~63 ~-44 ~51 minecraft:white_concrete
setblock ~64 ~-44 ~51 minecraft:light_gray_concrete
setblock ~4 ~-44 ~52 minecraft:light_gray_concrete
fill ~5 ~-44 ~52 ~17 ~-44 ~52 minecraft:polished_andesite
setblock ~18 ~-44 ~52 minecraft:light_gray_concrete
fill ~19 ~-44 ~52 ~31 ~-44 ~52 minecraft:polished_andesite
setblock ~32 ~-44 ~52 minecraft:light_gray_concrete
setblock ~33 ~-44 ~52 minecraft:white_concrete
setblock ~34 ~-44 ~52 minecraft:red_concrete
setblock ~35 ~-44 ~52 minecraft:white_concrete
setblock ~36 ~-44 ~52 minecraft:light_gray_concrete
fill ~37 ~-44 ~52 ~49 ~-44 ~52 minecraft:white_concrete
setblock ~50 ~-44 ~52 minecraft:light_gray_concrete
fill ~51 ~-44 ~52 ~63 ~-44 ~52 minecraft:white_concrete
setblock ~64 ~-44 ~52 minecraft:light_gray_concrete
setblock ~4 ~-44 ~53 minecraft:light_gray_concrete
fill ~5 ~-44 ~53 ~17 ~-44 ~53 minecraft:polished_andesite
setblock ~18 ~-44 ~53 minecraft:light_gray_concrete
fill ~19 ~-44 ~53 ~31 ~-44 ~53 minecraft:polished_andesite
setblock ~32 ~-44 ~53 minecraft:light_gray_concrete
setblock ~33 ~-44 ~53 minecraft:white_concrete
setblock ~34 ~-44 ~53 minecraft:red_concrete
setblock ~35 ~-44 ~53 minecraft:white_concrete
setblock ~36 ~-44 ~53 minecraft:light_gray_concrete
fill ~37 ~-44 ~53 ~49 ~-44 ~53 minecraft:white_concrete
setblock ~50 ~-44 ~53 minecraft:light_gray_concrete
fill ~51 ~-44 ~53 ~63 ~-44 ~53 minecraft:white_concrete
setblock ~64 ~-44 ~53 minecraft:light_gray_concrete
setblock ~4 ~-44 ~54 minecraft:light_gray_concrete
fill ~5 ~-44 ~54 ~17 ~-44 ~54 minecraft:polished_andesite
setblock ~18 ~-44 ~54 minecraft:light_gray_concrete
fill ~19 ~-44 ~54 ~31 ~-44 ~54 minecraft:polished_andesite
setblock ~32 ~-44 ~54 minecraft:light_gray_concrete
setblock ~33 ~-44 ~54 minecraft:white_concrete
setblock ~34 ~-44 ~54 minecraft:red_concrete
setblock ~35 ~-44 ~54 minecraft:white_concrete
setblock ~36 ~-44 ~54 minecraft:light_gray_concrete
fill ~37 ~-44 ~54 ~49 ~-44 ~54 minecraft:white_concrete
setblock ~50 ~-44 ~54 minecraft:light_gray_concrete
fill ~51 ~-44 ~54 ~63 ~-44 ~54 minecraft:white_concrete
setblock ~64 ~-44 ~54 minecraft:light_gray_concrete
setblock ~4 ~-44 ~55 minecraft:light_gray_concrete
fill ~5 ~-44 ~55 ~17 ~-44 ~55 minecraft:polished_andesite
setblock ~18 ~-44 ~55 minecraft:light_gray_concrete
fill ~19 ~-44 ~55 ~31 ~-44 ~55 minecraft:polished_andesite
setblock ~32 ~-44 ~55 minecraft:light_gray_concrete
setblock ~33 ~-44 ~55 minecraft:white_concrete
setblock ~34 ~-44 ~55 minecraft:red_concrete
setblock ~35 ~-44 ~55 minecraft:white_concrete
setblock ~36 ~-44 ~55 minecraft:light_gray_concrete
fill ~37 ~-44 ~55 ~49 ~-44 ~55 minecraft:white_concrete
setblock ~50 ~-44 ~55 minecraft:light_gray_concrete
fill ~51 ~-44 ~55 ~63 ~-44 ~55 minecraft:white_concrete
setblock ~64 ~-44 ~55 minecraft:light_gray_concrete
setblock ~4 ~-44 ~56 minecraft:light_gray_concrete
fill ~5 ~-44 ~56 ~17 ~-44 ~56 minecraft:polished_andesite
setblock ~18 ~-44 ~56 minecraft:light_gray_concrete
fill ~19 ~-44 ~56 ~31 ~-44 ~56 minecraft:polished_andesite
setblock ~32 ~-44 ~56 minecraft:light_gray_concrete
setblock ~33 ~-44 ~56 minecraft:white_concrete
setblock ~34 ~-44 ~56 minecraft:red_concrete
setblock ~35 ~-44 ~56 minecraft:white_concrete
setblock ~36 ~-44 ~56 minecraft:light_gray_concrete
fill ~37 ~-44 ~56 ~49 ~-44 ~56 minecraft:white_concrete
setblock ~50 ~-44 ~56 minecraft:light_gray_concrete
fill ~51 ~-44 ~56 ~63 ~-44 ~56 minecraft:white_concrete
setblock ~64 ~-44 ~56 minecraft:light_gray_concrete
setblock ~4 ~-44 ~57 minecraft:light_gray_concrete
fill ~5 ~-44 ~57 ~17 ~-44 ~57 minecraft:polished_andesite
setblock ~18 ~-44 ~57 minecraft:light_gray_concrete
fill ~19 ~-44 ~57 ~31 ~-44 ~57 minecraft:polished_andesite
setblock ~32 ~-44 ~57 minecraft:light_gray_concrete
setblock ~33 ~-44 ~57 minecraft:white_concrete
setblock ~34 ~-44 ~57 minecraft:red_concrete
setblock ~35 ~-44 ~57 minecraft:white_concrete
setblock ~36 ~-44 ~57 minecraft:light_gray_concrete
fill ~37 ~-44 ~57 ~49 ~-44 ~57 minecraft:white_concrete
setblock ~50 ~-44 ~57 minecraft:light_gray_concrete
fill ~51 ~-44 ~57 ~63 ~-44 ~57 minecraft:white_concrete
setblock ~64 ~-44 ~57 minecraft:light_gray_concrete
setblock ~4 ~-44 ~58 minecraft:light_gray_concrete
fill ~5 ~-44 ~58 ~17 ~-44 ~58 minecraft:polished_andesite
setblock ~18 ~-44 ~58 minecraft:light_gray_concrete
fill ~19 ~-44 ~58 ~31 ~-44 ~58 minecraft:polished_andesite
setblock ~32 ~-44 ~58 minecraft:light_gray_concrete
setblock ~33 ~-44 ~58 minecraft:white_concrete
setblock ~34 ~-44 ~58 minecraft:red_concrete
setblock ~35 ~-44 ~58 minecraft:white_concrete
setblock ~36 ~-44 ~58 minecraft:light_gray_concrete
fill ~37 ~-44 ~58 ~49 ~-44 ~58 minecraft:white_concrete
setblock ~50 ~-44 ~58 minecraft:light_gray_concrete
fill ~51 ~-44 ~58 ~63 ~-44 ~58 minecraft:white_concrete
setblock ~64 ~-44 ~58 minecraft:light_gray_concrete
setblock ~4 ~-44 ~59 minecraft:light_gray_concrete
fill ~5 ~-44 ~59 ~17 ~-44 ~59 minecraft:polished_andesite
setblock ~18 ~-44 ~59 minecraft:light_gray_concrete
fill ~19 ~-44 ~59 ~31 ~-44 ~59 minecraft:polished_andesite
setblock ~32 ~-44 ~59 minecraft:light_gray_concrete
setblock ~33 ~-44 ~59 minecraft:white_concrete
setblock ~34 ~-44 ~59 minecraft:red_concrete
setblock ~35 ~-44 ~59 minecraft:white_concrete
setblock ~36 ~-44 ~59 minecraft:light_gray_concrete
fill ~37 ~-44 ~59 ~49 ~-44 ~59 minecraft:white_concrete
setblock ~50 ~-44 ~59 minecraft:light_gray_concrete
fill ~51 ~-44 ~59 ~63 ~-44 ~59 minecraft:white_concrete
setblock ~64 ~-44 ~59 minecraft:light_gray_concrete
setblock ~4 ~-44 ~60 minecraft:light_gray_concrete
fill ~5 ~-44 ~60 ~17 ~-44 ~60 minecraft:polished_andesite
setblock ~18 ~-44 ~60 minecraft:light_gray_concrete
fill ~19 ~-44 ~60 ~31 ~-44 ~60 minecraft:polished_andesite
setblock ~32 ~-44 ~60 minecraft:light_gray_concrete
setblock ~33 ~-44 ~60 minecraft:white_concrete
setblock ~34 ~-44 ~60 minecraft:red_concrete
setblock ~35 ~-44 ~60 minecraft:white_concrete
setblock ~36 ~-44 ~60 minecraft:light_gray_concrete
fill ~37 ~-44 ~60 ~49 ~-44 ~60 minecraft:white_concrete
setblock ~50 ~-44 ~60 minecraft:light_gray_concrete
fill ~51 ~-44 ~60 ~63 ~-44 ~60 minecraft:white_concrete
setblock ~64 ~-44 ~60 minecraft:light_gray_concrete
setblock ~4 ~-44 ~61 minecraft:light_gray_concrete
fill ~5 ~-44 ~61 ~17 ~-44 ~61 minecraft:polished_andesite
setblock ~18 ~-44 ~61 minecraft:light_gray_concrete
fill ~19 ~-44 ~61 ~31 ~-44 ~61 minecraft:polished_andesite
setblock ~32 ~-44 ~61 minecraft:light_gray_concrete
setblock ~33 ~-44 ~61 minecraft:white_concrete
setblock ~34 ~-44 ~61 minecraft:red_concrete
setblock ~35 ~-44 ~61 minecraft:white_concrete
setblock ~36 ~-44 ~61 minecraft:light_gray_concrete
fill ~37 ~-44 ~61 ~49 ~-44 ~61 minecraft:white_concrete
setblock ~50 ~-44 ~61 minecraft:light_gray_concrete
fill ~51 ~-44 ~61 ~63 ~-44 ~61 minecraft:white_concrete
setblock ~64 ~-44 ~61 minecraft:light_gray_concrete
setblock ~4 ~-44 ~62 minecraft:light_gray_concrete
fill ~5 ~-44 ~62 ~17 ~-44 ~62 minecraft:polished_andesite
setblock ~18 ~-44 ~62 minecraft:light_gray_concrete
fill ~19 ~-44 ~62 ~31 ~-44 ~62 minecraft:polished_andesite
setblock ~32 ~-44 ~62 minecraft:light_gray_concrete
setblock ~33 ~-44 ~62 minecraft:white_concrete
setblock ~34 ~-44 ~62 minecraft:red_concrete
setblock ~35 ~-44 ~62 minecraft:white_concrete
setblock ~36 ~-44 ~62 minecraft:light_gray_concrete
fill ~37 ~-44 ~62 ~49 ~-44 ~62 minecraft:white_concrete
setblock ~50 ~-44 ~62 minecraft:light_gray_concrete
fill ~51 ~-44 ~62 ~63 ~-44 ~62 minecraft:white_concrete
setblock ~64 ~-44 ~62 minecraft:light_gray_concrete
setblock ~4 ~-44 ~63 minecraft:light_gray_concrete
fill ~5 ~-44 ~63 ~17 ~-44 ~63 minecraft:polished_andesite
setblock ~18 ~-44 ~63 minecraft:light_gray_concrete
fill ~19 ~-44 ~63 ~31 ~-44 ~63 minecraft:polished_andesite
setblock ~32 ~-44 ~63 minecraft:light_gray_concrete
setblock ~33 ~-44 ~63 minecraft:white_concrete
setblock ~34 ~-44 ~63 minecraft:red_concrete
setblock ~35 ~-44 ~63 minecraft:white_concrete
setblock ~36 ~-44 ~63 minecraft:light_gray_concrete
fill ~37 ~-44 ~63 ~49 ~-44 ~63 minecraft:white_concrete
setblock ~50 ~-44 ~63 minecraft:light_gray_concrete
fill ~51 ~-44 ~63 ~63 ~-44 ~63 minecraft:white_concrete
setblock ~64 ~-44 ~63 minecraft:light_gray_concrete
fill ~4 ~-44 ~64 ~64 ~-44 ~64 minecraft:light_gray_concrete
setblock ~34 ~-44 ~65 minecraft:white_concrete
fill ~32 ~-44 ~66 ~36 ~-44 ~66 minecraft:polished_andesite
setblock ~32 ~-44 ~67 minecraft:polished_andesite
setblock ~33 ~-44 ~67 minecraft:air
setblock ~34 ~-44 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-44 ~67 minecraft:air
setblock ~36 ~-44 ~67 minecraft:polished_andesite
setblock ~32 ~-44 ~68 minecraft:polished_andesite
setblock ~33 ~-44 ~68 minecraft:air
setblock ~34 ~-44 ~68 minecraft:quartz_pillar
setblock ~35 ~-44 ~68 minecraft:air
setblock ~36 ~-44 ~68 minecraft:polished_andesite
setblock ~32 ~-44 ~69 minecraft:polished_andesite
fill ~33 ~-44 ~69 ~35 ~-44 ~69 minecraft:air
setblock ~36 ~-44 ~69 minecraft:polished_andesite
fill ~32 ~-44 ~70 ~36 ~-44 ~70 minecraft:polished_andesite
fill ~4 ~-43 ~4 ~64 ~-43 ~4 minecraft:light_gray_concrete
setblock ~4 ~-43 ~5 minecraft:light_gray_concrete
fill ~5 ~-43 ~5 ~6 ~-43 ~5 minecraft:air
setblock ~7 ~-43 ~5 minecraft:barrel
fill ~8 ~-43 ~5 ~10 ~-43 ~5 minecraft:air
setblock ~11 ~-43 ~5 minecraft:barrel
fill ~12 ~-43 ~5 ~14 ~-43 ~5 minecraft:air
setblock ~15 ~-43 ~5 minecraft:barrel
fill ~16 ~-43 ~5 ~17 ~-43 ~5 minecraft:air
setblock ~18 ~-43 ~5 minecraft:light_gray_concrete
setblock ~19 ~-43 ~5 minecraft:barrel
fill ~20 ~-43 ~5 ~22 ~-43 ~5 minecraft:air
setblock ~23 ~-43 ~5 minecraft:barrel
fill ~24 ~-43 ~5 ~26 ~-43 ~5 minecraft:air
setblock ~27 ~-43 ~5 minecraft:barrel
fill ~28 ~-43 ~5 ~30 ~-43 ~5 minecraft:air
setblock ~31 ~-43 ~5 minecraft:barrel
setblock ~32 ~-43 ~5 minecraft:light_gray_concrete
fill ~33 ~-43 ~5 ~35 ~-43 ~5 minecraft:air
setblock ~36 ~-43 ~5 minecraft:light_gray_concrete
setblock ~37 ~-43 ~5 minecraft:air
setblock ~38 ~-43 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~5 ~41 ~-43 ~5 minecraft:air
setblock ~42 ~-43 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~5 ~45 ~-43 ~5 minecraft:air
setblock ~46 ~-43 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~5 ~49 ~-43 ~5 minecraft:air
setblock ~50 ~-43 ~5 minecraft:light_gray_concrete
fill ~51 ~-43 ~5 ~63 ~-43 ~5 minecraft:iron_block
setblock ~64 ~-43 ~5 minecraft:light_gray_concrete
setblock ~4 ~-43 ~6 minecraft:light_gray_concrete
fill ~5 ~-43 ~6 ~17 ~-43 ~6 minecraft:air
setblock ~18 ~-43 ~6 minecraft:light_gray_concrete
fill ~19 ~-43 ~6 ~31 ~-43 ~6 minecraft:air
setblock ~32 ~-43 ~6 minecraft:light_gray_concrete
fill ~33 ~-43 ~6 ~35 ~-43 ~6 minecraft:air
setblock ~36 ~-43 ~6 minecraft:light_gray_concrete
setblock ~37 ~-43 ~6 minecraft:air
setblock ~38 ~-43 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~6 ~41 ~-43 ~6 minecraft:air
setblock ~42 ~-43 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~6 ~45 ~-43 ~6 minecraft:air
setblock ~46 ~-43 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~6 ~49 ~-43 ~6 minecraft:air
setblock ~50 ~-43 ~6 minecraft:light_gray_concrete
setblock ~51 ~-43 ~6 minecraft:iron_block
fill ~52 ~-43 ~6 ~61 ~-43 ~6 minecraft:air
setblock ~62 ~-43 ~6 minecraft:chest[facing=south]
setblock ~63 ~-43 ~6 minecraft:iron_block
setblock ~64 ~-43 ~6 minecraft:light_gray_concrete
setblock ~4 ~-43 ~7 minecraft:light_gray_concrete
setblock ~5 ~-43 ~7 minecraft:barrel
setblock ~6 ~-43 ~7 minecraft:observer[facing=south]
setblock ~7 ~-43 ~7 minecraft:air
fill ~8 ~-43 ~7 ~10 ~-43 ~7 minecraft:observer[facing=south]
setblock ~11 ~-43 ~7 minecraft:air
fill ~12 ~-43 ~7 ~14 ~-43 ~7 minecraft:observer[facing=south]
setblock ~15 ~-43 ~7 minecraft:air
setblock ~16 ~-43 ~7 minecraft:observer[facing=south]
setblock ~17 ~-43 ~7 minecraft:barrel
setblock ~18 ~-43 ~7 minecraft:light_gray_concrete
setblock ~19 ~-43 ~7 minecraft:air
setblock ~20 ~-43 ~7 minecraft:observer[facing=south]
setblock ~21 ~-43 ~7 minecraft:air
fill ~22 ~-43 ~7 ~24 ~-43 ~7 minecraft:observer[facing=south]
setblock ~25 ~-43 ~7 minecraft:air
fill ~26 ~-43 ~7 ~28 ~-43 ~7 minecraft:observer[facing=south]
setblock ~29 ~-43 ~7 minecraft:air
setblock ~30 ~-43 ~7 minecraft:observer[facing=south]
setblock ~31 ~-43 ~7 minecraft:air
setblock ~32 ~-43 ~7 minecraft:light_gray_concrete
fill ~33 ~-43 ~7 ~35 ~-43 ~7 minecraft:air
setblock ~36 ~-43 ~7 minecraft:light_gray_concrete
setblock ~37 ~-43 ~7 minecraft:air
setblock ~38 ~-43 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~7 ~41 ~-43 ~7 minecraft:air
setblock ~42 ~-43 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~7 ~45 ~-43 ~7 minecraft:air
setblock ~46 ~-43 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~7 ~49 ~-43 ~7 minecraft:air
setblock ~50 ~-43 ~7 minecraft:light_gray_concrete
setblock ~51 ~-43 ~7 minecraft:iron_block
setblock ~52 ~-43 ~7 minecraft:air
setblock ~53 ~-43 ~7 minecraft:iron_block
setblock ~54 ~-43 ~7 minecraft:air
setblock ~55 ~-43 ~7 minecraft:iron_block
setblock ~56 ~-43 ~7 minecraft:air
setblock ~57 ~-43 ~7 minecraft:iron_block
setblock ~58 ~-43 ~7 minecraft:air
setblock ~59 ~-43 ~7 minecraft:iron_block
setblock ~60 ~-43 ~7 minecraft:air
setblock ~61 ~-43 ~7 minecraft:iron_block
setblock ~62 ~-43 ~7 minecraft:air
setblock ~63 ~-43 ~7 minecraft:iron_block
setblock ~64 ~-43 ~7 minecraft:light_gray_concrete
setblock ~4 ~-43 ~8 minecraft:light_gray_concrete
fill ~5 ~-43 ~8 ~17 ~-43 ~8 minecraft:air
setblock ~18 ~-43 ~8 minecraft:light_gray_concrete
fill ~19 ~-43 ~8 ~31 ~-43 ~8 minecraft:air
setblock ~32 ~-43 ~8 minecraft:light_gray_concrete
fill ~33 ~-43 ~8 ~35 ~-43 ~8 minecraft:air
setblock ~36 ~-43 ~8 minecraft:light_gray_concrete
setblock ~37 ~-43 ~8 minecraft:air
setblock ~38 ~-43 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~8 ~41 ~-43 ~8 minecraft:air
setblock ~42 ~-43 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~8 ~45 ~-43 ~8 minecraft:air
setblock ~46 ~-43 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~8 ~49 ~-43 ~8 minecraft:air
setblock ~50 ~-43 ~8 minecraft:light_gray_concrete
setblock ~51 ~-43 ~8 minecraft:iron_block
fill ~52 ~-43 ~8 ~53 ~-43 ~8 minecraft:air
setblock ~54 ~-43 ~8 minecraft:iron_block
setblock ~55 ~-43 ~8 minecraft:air
setblock ~56 ~-43 ~8 minecraft:iron_block
setblock ~57 ~-43 ~8 minecraft:air
setblock ~58 ~-43 ~8 minecraft:iron_block
setblock ~59 ~-43 ~8 minecraft:air
setblock ~60 ~-43 ~8 minecraft:iron_block
fill ~61 ~-43 ~8 ~62 ~-43 ~8 minecraft:air
setblock ~63 ~-43 ~8 minecraft:iron_block
setblock ~64 ~-43 ~8 minecraft:light_gray_concrete
setblock ~4 ~-43 ~9 minecraft:light_gray_concrete
fill ~5 ~-43 ~9 ~17 ~-43 ~9 minecraft:air
setblock ~18 ~-43 ~9 minecraft:light_gray_concrete
setblock ~19 ~-43 ~9 minecraft:barrel
fill ~20 ~-43 ~9 ~30 ~-43 ~9 minecraft:air
setblock ~31 ~-43 ~9 minecraft:barrel
setblock ~32 ~-43 ~9 minecraft:light_gray_concrete
fill ~33 ~-43 ~9 ~35 ~-43 ~9 minecraft:air
setblock ~36 ~-43 ~9 minecraft:light_gray_concrete
setblock ~37 ~-43 ~9 minecraft:air
setblock ~38 ~-43 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~9 ~41 ~-43 ~9 minecraft:air
setblock ~42 ~-43 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~9 ~45 ~-43 ~9 minecraft:air
setblock ~46 ~-43 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~9 ~49 ~-43 ~9 minecraft:air
setblock ~50 ~-43 ~9 minecraft:light_gray_concrete
setblock ~51 ~-43 ~9 minecraft:iron_block
setblock ~52 ~-43 ~9 minecraft:air
setblock ~53 ~-43 ~9 minecraft:iron_block
setblock ~54 ~-43 ~9 minecraft:air
setblock ~55 ~-43 ~9 minecraft:iron_block
setblock ~56 ~-43 ~9 minecraft:air
setblock ~57 ~-43 ~9 minecraft:iron_block
setblock ~58 ~-43 ~9 minecraft:air
setblock ~59 ~-43 ~9 minecraft:iron_block
setblock ~60 ~-43 ~9 minecraft:air
setblock ~61 ~-43 ~9 minecraft:iron_block
setblock ~62 ~-43 ~9 minecraft:air
setblock ~63 ~-43 ~9 minecraft:iron_block
setblock ~64 ~-43 ~9 minecraft:light_gray_concrete
setblock ~4 ~-43 ~10 minecraft:light_gray_concrete
setblock ~5 ~-43 ~10 minecraft:air
setblock ~6 ~-43 ~10 minecraft:observer[facing=north]
setblock ~7 ~-43 ~10 minecraft:air
fill ~8 ~-43 ~10 ~10 ~-43 ~10 minecraft:observer[facing=north]
setblock ~11 ~-43 ~10 minecraft:air
fill ~12 ~-43 ~10 ~14 ~-43 ~10 minecraft:observer[facing=north]
setblock ~15 ~-43 ~10 minecraft:air
setblock ~16 ~-43 ~10 minecraft:observer[facing=north]
setblock ~17 ~-43 ~10 minecraft:air
setblock ~18 ~-43 ~10 minecraft:light_gray_concrete
setblock ~19 ~-43 ~10 minecraft:air
setblock ~20 ~-43 ~10 minecraft:observer[facing=north]
setblock ~21 ~-43 ~10 minecraft:air
fill ~22 ~-43 ~10 ~24 ~-43 ~10 minecraft:observer[facing=north]
setblock ~25 ~-43 ~10 minecraft:air
fill ~26 ~-43 ~10 ~28 ~-43 ~10 minecraft:observer[facing=north]
setblock ~29 ~-43 ~10 minecraft:air
setblock ~30 ~-43 ~10 minecraft:observer[facing=north]
setblock ~31 ~-43 ~10 minecraft:air
setblock ~32 ~-43 ~10 minecraft:light_gray_concrete
fill ~33 ~-43 ~10 ~35 ~-43 ~10 minecraft:air
setblock ~36 ~-43 ~10 minecraft:light_gray_concrete
setblock ~37 ~-43 ~10 minecraft:air
setblock ~38 ~-43 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~10 ~41 ~-43 ~10 minecraft:air
setblock ~42 ~-43 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~10 ~45 ~-43 ~10 minecraft:air
setblock ~46 ~-43 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~10 ~49 ~-43 ~10 minecraft:air
setblock ~50 ~-43 ~10 minecraft:light_gray_concrete
fill ~51 ~-43 ~10 ~53 ~-43 ~10 minecraft:air
setblock ~54 ~-43 ~10 minecraft:iron_block
setblock ~55 ~-43 ~10 minecraft:air
setblock ~56 ~-43 ~10 minecraft:iron_block
setblock ~57 ~-43 ~10 minecraft:air
setblock ~58 ~-43 ~10 minecraft:iron_block
setblock ~59 ~-43 ~10 minecraft:chest[facing=south]
setblock ~60 ~-43 ~10 minecraft:iron_block
fill ~61 ~-43 ~10 ~62 ~-43 ~10 minecraft:air
setblock ~63 ~-43 ~10 minecraft:iron_block
setblock ~64 ~-43 ~10 minecraft:light_gray_concrete
setblock ~4 ~-43 ~11 minecraft:light_gray_concrete
setblock ~5 ~-43 ~11 minecraft:barrel
fill ~6 ~-43 ~11 ~41 ~-43 ~11 minecraft:air
setblock ~42 ~-43 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~11 ~45 ~-43 ~11 minecraft:air
setblock ~46 ~-43 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~11 ~52 ~-43 ~11 minecraft:air
setblock ~53 ~-43 ~11 minecraft:iron_block
setblock ~54 ~-43 ~11 minecraft:air
setblock ~55 ~-43 ~11 minecraft:iron_block
setblock ~56 ~-43 ~11 minecraft:air
setblock ~57 ~-43 ~11 minecraft:iron_block
setblock ~58 ~-43 ~11 minecraft:air
setblock ~59 ~-43 ~11 minecraft:iron_block
setblock ~60 ~-43 ~11 minecraft:air
setblock ~61 ~-43 ~11 minecraft:iron_block
setblock ~62 ~-43 ~11 minecraft:air
setblock ~63 ~-43 ~11 minecraft:iron_block
setblock ~64 ~-43 ~11 minecraft:light_gray_concrete
setblock ~4 ~-43 ~12 minecraft:light_gray_concrete
fill ~5 ~-43 ~12 ~17 ~-43 ~12 minecraft:air
setblock ~18 ~-43 ~12 minecraft:light_gray_concrete
fill ~19 ~-43 ~12 ~31 ~-43 ~12 minecraft:air
setblock ~32 ~-43 ~12 minecraft:light_gray_concrete
fill ~33 ~-43 ~12 ~35 ~-43 ~12 minecraft:air
setblock ~36 ~-43 ~12 minecraft:light_gray_concrete
setblock ~37 ~-43 ~12 minecraft:air
setblock ~38 ~-43 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~12 ~41 ~-43 ~12 minecraft:air
setblock ~42 ~-43 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~12 ~45 ~-43 ~12 minecraft:air
setblock ~46 ~-43 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~12 ~49 ~-43 ~12 minecraft:air
setblock ~50 ~-43 ~12 minecraft:light_gray_concrete
fill ~51 ~-43 ~12 ~53 ~-43 ~12 minecraft:air
setblock ~54 ~-43 ~12 minecraft:iron_block
setblock ~55 ~-43 ~12 minecraft:air
setblock ~56 ~-43 ~12 minecraft:iron_block
setblock ~57 ~-43 ~12 minecraft:air
setblock ~58 ~-43 ~12 minecraft:iron_block
setblock ~59 ~-43 ~12 minecraft:air
setblock ~60 ~-43 ~12 minecraft:iron_block
fill ~61 ~-43 ~12 ~62 ~-43 ~12 minecraft:air
setblock ~63 ~-43 ~12 minecraft:iron_block
setblock ~64 ~-43 ~12 minecraft:light_gray_concrete
setblock ~4 ~-43 ~13 minecraft:light_gray_concrete
setblock ~5 ~-43 ~13 minecraft:air
setblock ~6 ~-43 ~13 minecraft:observer[facing=south]
setblock ~7 ~-43 ~13 minecraft:air
fill ~8 ~-43 ~13 ~10 ~-43 ~13 minecraft:observer[facing=south]
setblock ~11 ~-43 ~13 minecraft:air
fill ~12 ~-43 ~13 ~14 ~-43 ~13 minecraft:observer[facing=south]
setblock ~15 ~-43 ~13 minecraft:air
setblock ~16 ~-43 ~13 minecraft:observer[facing=south]
setblock ~17 ~-43 ~13 minecraft:air
setblock ~18 ~-43 ~13 minecraft:light_gray_concrete
setblock ~19 ~-43 ~13 minecraft:barrel
setblock ~20 ~-43 ~13 minecraft:observer[facing=south]
setblock ~21 ~-43 ~13 minecraft:air
fill ~22 ~-43 ~13 ~24 ~-43 ~13 minecraft:observer[facing=south]
setblock ~25 ~-43 ~13 minecraft:air
fill ~26 ~-43 ~13 ~28 ~-43 ~13 minecraft:observer[facing=south]
setblock ~29 ~-43 ~13 minecraft:air
setblock ~30 ~-43 ~13 minecraft:observer[facing=south]
setblock ~31 ~-43 ~13 minecraft:barrel
setblock ~32 ~-43 ~13 minecraft:light_gray_concrete
fill ~33 ~-43 ~13 ~35 ~-43 ~13 minecraft:air
setblock ~36 ~-43 ~13 minecraft:light_gray_concrete
setblock ~37 ~-43 ~13 minecraft:air
setblock ~38 ~-43 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~13 ~41 ~-43 ~13 minecraft:air
setblock ~42 ~-43 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~13 ~45 ~-43 ~13 minecraft:air
setblock ~46 ~-43 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~13 ~49 ~-43 ~13 minecraft:air
setblock ~50 ~-43 ~13 minecraft:light_gray_concrete
setblock ~51 ~-43 ~13 minecraft:iron_block
setblock ~52 ~-43 ~13 minecraft:air
setblock ~53 ~-43 ~13 minecraft:iron_block
setblock ~54 ~-43 ~13 minecraft:air
setblock ~55 ~-43 ~13 minecraft:iron_block
setblock ~56 ~-43 ~13 minecraft:air
setblock ~57 ~-43 ~13 minecraft:iron_block
setblock ~58 ~-43 ~13 minecraft:air
setblock ~59 ~-43 ~13 minecraft:iron_block
setblock ~60 ~-43 ~13 minecraft:air
setblock ~61 ~-43 ~13 minecraft:iron_block
setblock ~62 ~-43 ~13 minecraft:air
setblock ~63 ~-43 ~13 minecraft:iron_block
setblock ~64 ~-43 ~13 minecraft:light_gray_concrete
setblock ~4 ~-43 ~14 minecraft:light_gray_concrete
fill ~5 ~-43 ~14 ~17 ~-43 ~14 minecraft:air
setblock ~18 ~-43 ~14 minecraft:light_gray_concrete
fill ~19 ~-43 ~14 ~31 ~-43 ~14 minecraft:air
setblock ~32 ~-43 ~14 minecraft:light_gray_concrete
fill ~33 ~-43 ~14 ~35 ~-43 ~14 minecraft:air
setblock ~36 ~-43 ~14 minecraft:light_gray_concrete
setblock ~37 ~-43 ~14 minecraft:air
setblock ~38 ~-43 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~14 ~41 ~-43 ~14 minecraft:air
setblock ~42 ~-43 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~14 ~45 ~-43 ~14 minecraft:air
setblock ~46 ~-43 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~14 ~49 ~-43 ~14 minecraft:air
setblock ~50 ~-43 ~14 minecraft:light_gray_concrete
setblock ~51 ~-43 ~14 minecraft:iron_block
fill ~52 ~-43 ~14 ~53 ~-43 ~14 minecraft:air
setblock ~54 ~-43 ~14 minecraft:iron_block
setblock ~55 ~-43 ~14 minecraft:air
setblock ~56 ~-43 ~14 minecraft:iron_block
setblock ~57 ~-43 ~14 minecraft:air
setblock ~58 ~-43 ~14 minecraft:iron_block
setblock ~59 ~-43 ~14 minecraft:air
setblock ~60 ~-43 ~14 minecraft:iron_block
fill ~61 ~-43 ~14 ~62 ~-43 ~14 minecraft:air
setblock ~63 ~-43 ~14 minecraft:iron_block
setblock ~64 ~-43 ~14 minecraft:light_gray_concrete
setblock ~4 ~-43 ~15 minecraft:light_gray_concrete
setblock ~5 ~-43 ~15 minecraft:barrel
fill ~6 ~-43 ~15 ~16 ~-43 ~15 minecraft:air
setblock ~17 ~-43 ~15 minecraft:barrel
setblock ~18 ~-43 ~15 minecraft:light_gray_concrete
fill ~19 ~-43 ~15 ~31 ~-43 ~15 minecraft:air
setblock ~32 ~-43 ~15 minecraft:light_gray_concrete
fill ~33 ~-43 ~15 ~35 ~-43 ~15 minecraft:air
setblock ~36 ~-43 ~15 minecraft:light_gray_concrete
setblock ~37 ~-43 ~15 minecraft:air
setblock ~38 ~-43 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~15 ~41 ~-43 ~15 minecraft:air
setblock ~42 ~-43 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~15 ~45 ~-43 ~15 minecraft:air
setblock ~46 ~-43 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~15 ~49 ~-43 ~15 minecraft:air
setblock ~50 ~-43 ~15 minecraft:light_gray_concrete
setblock ~51 ~-43 ~15 minecraft:iron_block
setblock ~52 ~-43 ~15 minecraft:air
setblock ~53 ~-43 ~15 minecraft:iron_block
setblock ~54 ~-43 ~15 minecraft:air
setblock ~55 ~-43 ~15 minecraft:iron_block
setblock ~56 ~-43 ~15 minecraft:air
setblock ~57 ~-43 ~15 minecraft:iron_block
setblock ~58 ~-43 ~15 minecraft:air
setblock ~59 ~-43 ~15 minecraft:iron_block
setblock ~60 ~-43 ~15 minecraft:chest[facing=south]
setblock ~61 ~-43 ~15 minecraft:iron_block
setblock ~62 ~-43 ~15 minecraft:air
setblock ~63 ~-43 ~15 minecraft:iron_block
setblock ~64 ~-43 ~15 minecraft:light_gray_concrete
setblock ~4 ~-43 ~16 minecraft:light_gray_concrete
setblock ~5 ~-43 ~16 minecraft:air
setblock ~6 ~-43 ~16 minecraft:observer[facing=north]
setblock ~7 ~-43 ~16 minecraft:air
fill ~8 ~-43 ~16 ~10 ~-43 ~16 minecraft:observer[facing=north]
setblock ~11 ~-43 ~16 minecraft:air
fill ~12 ~-43 ~16 ~14 ~-43 ~16 minecraft:observer[facing=north]
setblock ~15 ~-43 ~16 minecraft:air
setblock ~16 ~-43 ~16 minecraft:observer[facing=north]
setblock ~17 ~-43 ~16 minecraft:air
setblock ~18 ~-43 ~16 minecraft:light_gray_concrete
setblock ~19 ~-43 ~16 minecraft:air
setblock ~20 ~-43 ~16 minecraft:observer[facing=north]
setblock ~21 ~-43 ~16 minecraft:air
fill ~22 ~-43 ~16 ~24 ~-43 ~16 minecraft:observer[facing=north]
setblock ~25 ~-43 ~16 minecraft:air
fill ~26 ~-43 ~16 ~28 ~-43 ~16 minecraft:observer[facing=north]
setblock ~29 ~-43 ~16 minecraft:air
setblock ~30 ~-43 ~16 minecraft:observer[facing=north]
setblock ~31 ~-43 ~16 minecraft:air
setblock ~32 ~-43 ~16 minecraft:light_gray_concrete
fill ~33 ~-43 ~16 ~35 ~-43 ~16 minecraft:air
setblock ~36 ~-43 ~16 minecraft:light_gray_concrete
setblock ~37 ~-43 ~16 minecraft:air
setblock ~38 ~-43 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~16 ~41 ~-43 ~16 minecraft:air
setblock ~42 ~-43 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~16 ~45 ~-43 ~16 minecraft:air
setblock ~46 ~-43 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~16 ~49 ~-43 ~16 minecraft:air
setblock ~50 ~-43 ~16 minecraft:light_gray_concrete
setblock ~51 ~-43 ~16 minecraft:iron_block
fill ~52 ~-43 ~16 ~57 ~-43 ~16 minecraft:air
setblock ~58 ~-43 ~16 minecraft:chest[facing=south]
fill ~59 ~-43 ~16 ~62 ~-43 ~16 minecraft:air
setblock ~63 ~-43 ~16 minecraft:iron_block
setblock ~64 ~-43 ~16 minecraft:light_gray_concrete
setblock ~4 ~-43 ~17 minecraft:light_gray_concrete
fill ~5 ~-43 ~17 ~6 ~-43 ~17 minecraft:air
setblock ~7 ~-43 ~17 minecraft:barrel
fill ~8 ~-43 ~17 ~14 ~-43 ~17 minecraft:air
setblock ~15 ~-43 ~17 minecraft:barrel
fill ~16 ~-43 ~17 ~17 ~-43 ~17 minecraft:air
setblock ~18 ~-43 ~17 minecraft:light_gray_concrete
setblock ~19 ~-43 ~17 minecraft:barrel
fill ~20 ~-43 ~17 ~22 ~-43 ~17 minecraft:air
setblock ~23 ~-43 ~17 minecraft:barrel
fill ~24 ~-43 ~17 ~26 ~-43 ~17 minecraft:air
setblock ~27 ~-43 ~17 minecraft:barrel
fill ~28 ~-43 ~17 ~30 ~-43 ~17 minecraft:air
setblock ~31 ~-43 ~17 minecraft:barrel
setblock ~32 ~-43 ~17 minecraft:light_gray_concrete
fill ~33 ~-43 ~17 ~35 ~-43 ~17 minecraft:air
setblock ~36 ~-43 ~17 minecraft:light_gray_concrete
setblock ~37 ~-43 ~17 minecraft:air
setblock ~38 ~-43 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-43 ~17 ~41 ~-43 ~17 minecraft:air
setblock ~42 ~-43 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-43 ~17 ~45 ~-43 ~17 minecraft:air
setblock ~46 ~-43 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-43 ~17 ~49 ~-43 ~17 minecraft:air
setblock ~50 ~-43 ~17 minecraft:light_gray_concrete
fill ~51 ~-43 ~17 ~55 ~-43 ~17 minecraft:iron_block
fill ~56 ~-43 ~17 ~58 ~-43 ~17 minecraft:air
fill ~59 ~-43 ~17 ~63 ~-43 ~17 minecraft:iron_block
setblock ~64 ~-43 ~17 minecraft:light_gray_concrete
fill ~4 ~-43 ~18 ~10 ~-43 ~18 minecraft:light_gray_concrete
setblock ~11 ~-43 ~18 minecraft:air
fill ~12 ~-43 ~18 ~32 ~-43 ~18 minecraft:light_gray_concrete
fill ~33 ~-43 ~18 ~35 ~-43 ~18 minecraft:air
fill ~36 ~-43 ~18 ~56 ~-43 ~18 minecraft:light_gray_concrete
setblock ~57 ~-43 ~18 minecraft:air
fill ~58 ~-43 ~18 ~64 ~-43 ~18 minecraft:light_gray_concrete
setblock ~4 ~-43 ~19 minecraft:light_gray_concrete
setblock ~5 ~-43 ~19 minecraft:blast_furnace[facing=south]
setblock ~6 ~-43 ~19 minecraft:waxed_cut_copper
setblock ~7 ~-43 ~19 minecraft:dispenser[facing=south]
setblock ~8 ~-43 ~19 minecraft:blast_furnace[facing=south]
setblock ~9 ~-43 ~19 minecraft:waxed_cut_copper
fill ~10 ~-43 ~19 ~12 ~-43 ~19 minecraft:air
setblock ~13 ~-43 ~19 minecraft:dispenser[facing=south]
setblock ~14 ~-43 ~19 minecraft:blast_furnace[facing=south]
setblock ~15 ~-43 ~19 minecraft:waxed_cut_copper
setblock ~16 ~-43 ~19 minecraft:dispenser[facing=south]
setblock ~17 ~-43 ~19 minecraft:blast_furnace[facing=south]
setblock ~18 ~-43 ~19 minecraft:light_gray_concrete
fill ~19 ~-43 ~19 ~30 ~-43 ~19 minecraft:black_concrete
setblock ~31 ~-43 ~19 minecraft:air
setblock ~32 ~-43 ~19 minecraft:light_gray_concrete
fill ~33 ~-43 ~19 ~35 ~-43 ~19 minecraft:air
setblock ~36 ~-43 ~19 minecraft:light_gray_concrete
fill ~37 ~-43 ~19 ~40 ~-43 ~19 minecraft:air
setblock ~41 ~-43 ~19 minecraft:barrel
fill ~42 ~-43 ~19 ~44 ~-43 ~19 minecraft:air
setblock ~45 ~-43 ~19 minecraft:barrel
fill ~46 ~-43 ~19 ~48 ~-43 ~19 minecraft:air
setblock ~49 ~-43 ~19 minecraft:barrel
setblock ~50 ~-43 ~19 minecraft:light_gray_concrete
setblock ~51 ~-43 ~19 minecraft:barrel
fill ~52 ~-43 ~19 ~53 ~-43 ~19 minecraft:air
setblock ~54 ~-43 ~19 minecraft:barrel
fill ~55 ~-43 ~19 ~59 ~-43 ~19 minecraft:air
setblock ~60 ~-43 ~19 minecraft:barrel
fill ~61 ~-43 ~19 ~62 ~-43 ~19 minecraft:air
setblock ~63 ~-43 ~19 minecraft:barrel
setblock ~64 ~-43 ~19 minecraft:light_gray_concrete
setblock ~4 ~-43 ~20 minecraft:light_gray_concrete
setblock ~5 ~-43 ~20 minecraft:waxed_cut_copper
fill ~6 ~-43 ~20 ~16 ~-43 ~20 minecraft:air
setblock ~17 ~-43 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-43 ~20 minecraft:light_gray_concrete
fill ~19 ~-43 ~20 ~49 ~-43 ~20 minecraft:air
setblock ~50 ~-43 ~20 minecraft:light_gray_concrete
fill ~51 ~-43 ~20 ~62 ~-43 ~20 minecraft:air
setblock ~63 ~-43 ~20 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-43 ~20 minecraft:light_gray_concrete
setblock ~4 ~-43 ~21 minecraft:light_gray_concrete
setblock ~5 ~-43 ~21 minecraft:dispenser[facing=east]
fill ~6 ~-43 ~21 ~16 ~-43 ~21 minecraft:air
setblock ~17 ~-43 ~21 minecraft:dispenser[facing=west]
setblock ~18 ~-43 ~21 minecraft:light_gray_concrete
fill ~19 ~-43 ~21 ~31 ~-43 ~21 minecraft:air
setblock ~32 ~-43 ~21 minecraft:light_gray_concrete
fill ~33 ~-43 ~21 ~35 ~-43 ~21 minecraft:air
setblock ~36 ~-43 ~21 minecraft:light_gray_concrete
setblock ~37 ~-43 ~21 minecraft:air
setblock ~38 ~-43 ~21 minecraft:observer[facing=south]
setblock ~39 ~-43 ~21 minecraft:barrel
setblock ~40 ~-43 ~21 minecraft:air
fill ~41 ~-43 ~21 ~42 ~-43 ~21 minecraft:observer[facing=south]
setblock ~43 ~-43 ~21 minecraft:air
fill ~44 ~-43 ~21 ~46 ~-43 ~21 minecraft:observer[facing=south]
setblock ~47 ~-43 ~21 minecraft:air
setblock ~48 ~-43 ~21 minecraft:observer[facing=south]
setblock ~49 ~-43 ~21 minecraft:air
setblock ~50 ~-43 ~21 minecraft:light_gray_concrete
fill ~51 ~-43 ~21 ~63 ~-43 ~21 minecraft:air
setblock ~64 ~-43 ~21 minecraft:light_gray_concrete
setblock ~4 ~-43 ~22 minecraft:light_gray_concrete
setblock ~5 ~-43 ~22 minecraft:blast_furnace[facing=east]
fill ~6 ~-43 ~22 ~9 ~-43 ~22 minecraft:air
setblock ~10 ~-43 ~22 minecraft:waxed_cut_copper
fill ~11 ~-43 ~22 ~13 ~-43 ~22 minecraft:air
setblock ~14 ~-43 ~22 minecraft:waxed_cut_copper
fill ~15 ~-43 ~22 ~16 ~-43 ~22 minecraft:air
setblock ~17 ~-43 ~22 minecraft:blast_furnace[facing=west]
setblock ~18 ~-43 ~22 minecraft:light_gray_concrete
setblock ~19 ~-43 ~22 minecraft:air
fill ~20 ~-43 ~22 ~22 ~-43 ~22 minecraft:smooth_stone_slab[type=top]
setblock ~23 ~-43 ~22 minecraft:air
fill ~24 ~-43 ~22 ~25 ~-43 ~22 minecraft:smooth_stone_slab[type=top]
fill ~26 ~-43 ~22 ~28 ~-43 ~22 minecraft:air
fill ~29 ~-43 ~22 ~32 ~-43 ~22 minecraft:polished_andesite
fill ~33 ~-43 ~22 ~35 ~-43 ~22 minecraft:air
fill ~36 ~-43 ~22 ~39 ~-43 ~22 minecraft:polished_andesite
fill ~40 ~-43 ~22 ~49 ~-43 ~22 minecraft:air
setblock ~50 ~-43 ~22 minecraft:light_gray_concrete
setblock ~51 ~-43 ~22 minecraft:barrel
fill ~52 ~-43 ~22 ~62 ~-43 ~22 minecraft:air
setblock ~63 ~-43 ~22 minecraft:barrel
setblock ~64 ~-43 ~22 minecraft:light_gray_concrete
setblock ~4 ~-43 ~23 minecraft:light_gray_concrete
setblock ~5 ~-43 ~23 minecraft:waxed_cut_copper
fill ~6 ~-43 ~23 ~16 ~-43 ~23 minecraft:air
setblock ~17 ~-43 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-43 ~23 minecraft:light_gray_concrete
setblock ~19 ~-43 ~23 minecraft:air
fill ~20 ~-43 ~23 ~22 ~-43 ~23 minecraft:spruce_stairs[facing=south,half=bottom]
setblock ~23 ~-43 ~23 minecraft:air
fill ~24 ~-43 ~23 ~25 ~-43 ~23 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~26 ~-43 ~23 ~28 ~-43 ~23 minecraft:air
setblock ~29 ~-43 ~23 minecraft:polished_andesite
fill ~30 ~-43 ~23 ~38 ~-43 ~23 minecraft:air
setblock ~39 ~-43 ~23 minecraft:polished_andesite
fill ~40 ~-43 ~23 ~48 ~-43 ~23 minecraft:air
setblock ~49 ~-43 ~23 minecraft:barrel
setblock ~50 ~-43 ~23 minecraft:light_gray_concrete
fill ~51 ~-43 ~23 ~62 ~-43 ~23 minecraft:air
setblock ~63 ~-43 ~23 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-43 ~23 minecraft:light_gray_concrete
setblock ~4 ~-43 ~24 minecraft:light_gray_concrete
setblock ~5 ~-43 ~24 minecraft:dispenser[facing=east]
fill ~6 ~-43 ~24 ~16 ~-43 ~24 minecraft:air
setblock ~17 ~-43 ~24 minecraft:dispenser[facing=west]
setblock ~18 ~-43 ~24 minecraft:light_gray_concrete
fill ~19 ~-43 ~24 ~25 ~-43 ~24 minecraft:air
fill ~26 ~-43 ~24 ~27 ~-43 ~24 minecraft:polished_andesite
fill ~28 ~-43 ~24 ~29 ~-43 ~24 minecraft:air
setblock ~30 ~-43 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-43 ~24 ~37 ~-43 ~24 minecraft:air
setblock ~38 ~-43 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-43 ~24 ~40 ~-43 ~24 minecraft:air
fill ~41 ~-43 ~24 ~42 ~-43 ~24 minecraft:polished_andesite
setblock ~43 ~-43 ~24 minecraft:air
fill ~44 ~-43 ~24 ~46 ~-43 ~24 minecraft:observer[facing=north]
setblock ~47 ~-43 ~24 minecraft:air
setblock ~48 ~-43 ~24 minecraft:observer[facing=north]
setblock ~49 ~-43 ~24 minecraft:air
setblock ~50 ~-43 ~24 minecraft:light_gray_concrete
fill ~51 ~-43 ~24 ~55 ~-43 ~24 minecraft:air
setblock ~56 ~-43 ~24 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-43 ~24 ~58 ~-43 ~24 minecraft:spruce_slab[type=top]
setblock ~59 ~-43 ~24 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-43 ~24 ~63 ~-43 ~24 minecraft:air
setblock ~64 ~-43 ~24 minecraft:light_gray_concrete
setblock ~4 ~-43 ~25 minecraft:light_gray_concrete
setblock ~5 ~-43 ~25 minecraft:blast_furnace[facing=east]
fill ~6 ~-43 ~25 ~16 ~-43 ~25 minecraft:air
setblock ~17 ~-43 ~25 minecraft:blast_furnace[facing=west]
setblock ~18 ~-43 ~25 minecraft:light_gray_concrete
fill ~19 ~-43 ~25 ~24 ~-43 ~25 minecraft:air
fill ~25 ~-43 ~25 ~26 ~-43 ~25 minecraft:polished_andesite
fill ~27 ~-43 ~25 ~41 ~-43 ~25 minecraft:air
fill ~42 ~-43 ~25 ~43 ~-43 ~25 minecraft:polished_andesite
fill ~44 ~-43 ~25 ~49 ~-43 ~25 minecraft:air
setblock ~50 ~-43 ~25 minecraft:light_gray_concrete
setblock ~51 ~-43 ~25 minecraft:barrel
fill ~52 ~-43 ~25 ~55 ~-43 ~25 minecraft:air
setblock ~56 ~-43 ~25 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-43 ~25 ~58 ~-43 ~25 minecraft:spruce_slab[type=top]
setblock ~59 ~-43 ~25 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-43 ~25 ~62 ~-43 ~25 minecraft:air
setblock ~63 ~-43 ~25 minecraft:barrel
setblock ~64 ~-43 ~25 minecraft:light_gray_concrete
setblock ~4 ~-43 ~26 minecraft:light_gray_concrete
setblock ~5 ~-43 ~26 minecraft:waxed_cut_copper
fill ~6 ~-43 ~26 ~9 ~-43 ~26 minecraft:air
setblock ~10 ~-43 ~26 minecraft:waxed_cut_copper
fill ~11 ~-43 ~26 ~13 ~-43 ~26 minecraft:air
setblock ~14 ~-43 ~26 minecraft:waxed_cut_copper
fill ~15 ~-43 ~26 ~16 ~-43 ~26 minecraft:air
setblock ~17 ~-43 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-43 ~26 minecraft:light_gray_concrete
fill ~19 ~-43 ~26 ~23 ~-43 ~26 minecraft:air
fill ~24 ~-43 ~26 ~25 ~-43 ~26 minecraft:polished_andesite
fill ~26 ~-43 ~26 ~42 ~-43 ~26 minecraft:air
fill ~43 ~-43 ~26 ~44 ~-43 ~26 minecraft:polished_andesite
fill ~45 ~-43 ~26 ~49 ~-43 ~26 minecraft:air
setblock ~50 ~-43 ~26 minecraft:light_gray_concrete
fill ~51 ~-43 ~26 ~62 ~-43 ~26 minecraft:air
setblock ~63 ~-43 ~26 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-43 ~26 minecraft:light_gray_concrete
setblock ~4 ~-43 ~27 minecraft:light_gray_concrete
setblock ~5 ~-43 ~27 minecraft:dispenser[facing=east]
fill ~6 ~-43 ~27 ~16 ~-43 ~27 minecraft:air
setblock ~17 ~-43 ~27 minecraft:dispenser[facing=west]
setblock ~18 ~-43 ~27 minecraft:light_gray_concrete
fill ~19 ~-43 ~27 ~23 ~-43 ~27 minecraft:air
setblock ~24 ~-43 ~27 minecraft:polished_andesite
fill ~25 ~-43 ~27 ~43 ~-43 ~27 minecraft:air
setblock ~44 ~-43 ~27 minecraft:polished_andesite
fill ~45 ~-43 ~27 ~46 ~-43 ~27 minecraft:observer[facing=south]
setblock ~47 ~-43 ~27 minecraft:air
setblock ~48 ~-43 ~27 minecraft:observer[facing=south]
setblock ~49 ~-43 ~27 minecraft:barrel
setblock ~50 ~-43 ~27 minecraft:light_gray_concrete
fill ~51 ~-43 ~27 ~63 ~-43 ~27 minecraft:air
setblock ~64 ~-43 ~27 minecraft:light_gray_concrete
setblock ~4 ~-43 ~28 minecraft:light_gray_concrete
setblock ~5 ~-43 ~28 minecraft:blast_furnace[facing=east]
fill ~6 ~-43 ~28 ~16 ~-43 ~28 minecraft:air
setblock ~17 ~-43 ~28 minecraft:blast_furnace[facing=west]
setblock ~18 ~-43 ~28 minecraft:light_gray_concrete
fill ~19 ~-43 ~28 ~22 ~-43 ~28 minecraft:air
setblock ~23 ~-43 ~28 minecraft:polished_andesite
fill ~24 ~-43 ~28 ~44 ~-43 ~28 minecraft:air
setblock ~45 ~-43 ~28 minecraft:polished_andesite
fill ~46 ~-43 ~28 ~49 ~-43 ~28 minecraft:air
setblock ~50 ~-43 ~28 minecraft:light_gray_concrete
setblock ~51 ~-43 ~28 minecraft:barrel
fill ~52 ~-43 ~28 ~62 ~-43 ~28 minecraft:air
setblock ~63 ~-43 ~28 minecraft:barrel
setblock ~64 ~-43 ~28 minecraft:light_gray_concrete
setblock ~4 ~-43 ~29 minecraft:light_gray_concrete
setblock ~5 ~-43 ~29 minecraft:waxed_cut_copper
fill ~6 ~-43 ~29 ~16 ~-43 ~29 minecraft:air
setblock ~17 ~-43 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-43 ~29 minecraft:light_gray_concrete
fill ~19 ~-43 ~29 ~21 ~-43 ~29 minecraft:air
fill ~22 ~-43 ~29 ~23 ~-43 ~29 minecraft:polished_andesite
fill ~24 ~-43 ~29 ~44 ~-43 ~29 minecraft:air
fill ~45 ~-43 ~29 ~46 ~-43 ~29 minecraft:polished_andesite
setblock ~47 ~-43 ~29 minecraft:barrel
fill ~48 ~-43 ~29 ~49 ~-43 ~29 minecraft:air
setblock ~50 ~-43 ~29 minecraft:light_gray_concrete
fill ~51 ~-43 ~29 ~62 ~-43 ~29 minecraft:air
setblock ~63 ~-43 ~29 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-43 ~29 minecraft:light_gray_concrete
setblock ~4 ~-43 ~30 minecraft:light_gray_concrete
setblock ~5 ~-43 ~30 minecraft:dispenser[facing=east]
fill ~6 ~-43 ~30 ~16 ~-43 ~30 minecraft:air
setblock ~17 ~-43 ~30 minecraft:dispenser[facing=west]
setblock ~18 ~-43 ~30 minecraft:light_gray_concrete
fill ~19 ~-43 ~30 ~21 ~-43 ~30 minecraft:air
setblock ~22 ~-43 ~30 minecraft:polished_andesite
setblock ~23 ~-43 ~30 minecraft:air
setblock ~24 ~-43 ~30 minecraft:chiseled_quartz_block
fill ~25 ~-43 ~30 ~43 ~-43 ~30 minecraft:air
setblock ~44 ~-43 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-43 ~30 minecraft:air
setblock ~46 ~-43 ~30 minecraft:polished_andesite
fill ~47 ~-43 ~30 ~49 ~-43 ~30 minecraft:air
setblock ~50 ~-43 ~30 minecraft:light_gray_concrete
fill ~51 ~-43 ~30 ~63 ~-43 ~30 minecraft:air
setblock ~64 ~-43 ~30 minecraft:light_gray_concrete
setblock ~4 ~-43 ~31 minecraft:light_gray_concrete
setblock ~5 ~-43 ~31 minecraft:blast_furnace[facing=north]
setblock ~6 ~-43 ~31 minecraft:waxed_cut_copper
setblock ~7 ~-43 ~31 minecraft:dispenser[facing=north]
setblock ~8 ~-43 ~31 minecraft:blast_furnace[facing=north]
setblock ~9 ~-43 ~31 minecraft:waxed_cut_copper
fill ~10 ~-43 ~31 ~12 ~-43 ~31 minecraft:air
setblock ~13 ~-43 ~31 minecraft:dispenser[facing=north]
setblock ~14 ~-43 ~31 minecraft:blast_furnace[facing=north]
setblock ~15 ~-43 ~31 minecraft:waxed_cut_copper
setblock ~16 ~-43 ~31 minecraft:dispenser[facing=north]
setblock ~17 ~-43 ~31 minecraft:blast_furnace[facing=west]
setblock ~18 ~-43 ~31 minecraft:light_gray_concrete
fill ~19 ~-43 ~31 ~21 ~-43 ~31 minecraft:air
setblock ~22 ~-43 ~31 minecraft:polished_andesite
fill ~23 ~-43 ~31 ~45 ~-43 ~31 minecraft:air
setblock ~46 ~-43 ~31 minecraft:polished_andesite
fill ~47 ~-43 ~31 ~49 ~-43 ~31 minecraft:air
setblock ~50 ~-43 ~31 minecraft:light_gray_concrete
setblock ~51 ~-43 ~31 minecraft:barrel
fill ~52 ~-43 ~31 ~53 ~-43 ~31 minecraft:air
setblock ~54 ~-43 ~31 minecraft:barrel
fill ~55 ~-43 ~31 ~59 ~-43 ~31 minecraft:air
setblock ~60 ~-43 ~31 minecraft:barrel
fill ~61 ~-43 ~31 ~62 ~-43 ~31 minecraft:air
setblock ~63 ~-43 ~31 minecraft:barrel
setblock ~64 ~-43 ~31 minecraft:light_gray_concrete
fill ~4 ~-43 ~32 ~10 ~-43 ~32 minecraft:light_gray_concrete
setblock ~11 ~-43 ~32 minecraft:air
fill ~12 ~-43 ~32 ~19 ~-43 ~32 minecraft:light_gray_concrete
setblock ~20 ~-43 ~32 minecraft:air
setblock ~21 ~-43 ~32 minecraft:light_gray_concrete
setblock ~22 ~-43 ~32 minecraft:polished_andesite
fill ~23 ~-43 ~32 ~32 ~-43 ~32 minecraft:air
fill ~33 ~-43 ~32 ~35 ~-43 ~32 minecraft:glass
fill ~36 ~-43 ~32 ~45 ~-43 ~32 minecraft:air
setblock ~46 ~-43 ~32 minecraft:polished_andesite
setblock ~47 ~-43 ~32 minecraft:light_gray_concrete
setblock ~48 ~-43 ~32 minecraft:air
fill ~49 ~-43 ~32 ~56 ~-43 ~32 minecraft:light_gray_concrete
setblock ~57 ~-43 ~32 minecraft:air
fill ~58 ~-43 ~32 ~64 ~-43 ~32 minecraft:light_gray_concrete
setblock ~4 ~-43 ~33 minecraft:light_gray_concrete
fill ~5 ~-43 ~33 ~32 ~-43 ~33 minecraft:air
setblock ~33 ~-43 ~33 minecraft:glass
fill ~34 ~-43 ~33 ~63 ~-43 ~33 minecraft:air
setblock ~64 ~-43 ~33 minecraft:light_gray_concrete
setblock ~4 ~-43 ~34 minecraft:light_gray_concrete
fill ~5 ~-43 ~34 ~32 ~-43 ~34 minecraft:air
fill ~33 ~-43 ~34 ~35 ~-43 ~34 minecraft:glass
fill ~36 ~-43 ~34 ~63 ~-43 ~34 minecraft:air
setblock ~64 ~-43 ~34 minecraft:light_gray_concrete
setblock ~4 ~-43 ~35 minecraft:light_gray_concrete
fill ~5 ~-43 ~35 ~32 ~-43 ~35 minecraft:air
setblock ~33 ~-43 ~35 minecraft:glass
fill ~34 ~-43 ~35 ~63 ~-43 ~35 minecraft:air
setblock ~64 ~-43 ~35 minecraft:light_gray_concrete
fill ~4 ~-43 ~36 ~10 ~-43 ~36 minecraft:light_gray_concrete
setblock ~11 ~-43 ~36 minecraft:air
fill ~12 ~-43 ~36 ~19 ~-43 ~36 minecraft:light_gray_concrete
setblock ~20 ~-43 ~36 minecraft:air
setblock ~21 ~-43 ~36 minecraft:light_gray_concrete
setblock ~22 ~-43 ~36 minecraft:polished_andesite
fill ~23 ~-43 ~36 ~32 ~-43 ~36 minecraft:air
fill ~33 ~-43 ~36 ~35 ~-43 ~36 minecraft:glass
fill ~36 ~-43 ~36 ~45 ~-43 ~36 minecraft:air
setblock ~46 ~-43 ~36 minecraft:polished_andesite
setblock ~47 ~-43 ~36 minecraft:light_gray_concrete
setblock ~48 ~-43 ~36 minecraft:air
fill ~49 ~-43 ~36 ~56 ~-43 ~36 minecraft:light_gray_concrete
setblock ~57 ~-43 ~36 minecraft:air
fill ~58 ~-43 ~36 ~64 ~-43 ~36 minecraft:light_gray_concrete
setblock ~4 ~-43 ~37 minecraft:light_gray_concrete
fill ~5 ~-43 ~37 ~17 ~-43 ~37 minecraft:air
setblock ~18 ~-43 ~37 minecraft:light_gray_concrete
fill ~19 ~-43 ~37 ~21 ~-43 ~37 minecraft:air
setblock ~22 ~-43 ~37 minecraft:polished_andesite
fill ~23 ~-43 ~37 ~45 ~-43 ~37 minecraft:air
setblock ~46 ~-43 ~37 minecraft:polished_andesite
fill ~47 ~-43 ~37 ~49 ~-43 ~37 minecraft:air
setblock ~50 ~-43 ~37 minecraft:light_gray_concrete
fill ~51 ~-43 ~37 ~63 ~-43 ~37 minecraft:air
setblock ~64 ~-43 ~37 minecraft:light_gray_concrete
setblock ~4 ~-43 ~38 minecraft:light_gray_concrete
fill ~5 ~-43 ~38 ~17 ~-43 ~38 minecraft:air
setblock ~18 ~-43 ~38 minecraft:light_gray_concrete
fill ~19 ~-43 ~38 ~21 ~-43 ~38 minecraft:air
setblock ~22 ~-43 ~38 minecraft:polished_andesite
setblock ~23 ~-43 ~38 minecraft:air
setblock ~24 ~-43 ~38 minecraft:chiseled_quartz_block
fill ~25 ~-43 ~38 ~43 ~-43 ~38 minecraft:air
setblock ~44 ~-43 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-43 ~38 minecraft:air
setblock ~46 ~-43 ~38 minecraft:polished_andesite
fill ~47 ~-43 ~38 ~49 ~-43 ~38 minecraft:air
setblock ~50 ~-43 ~38 minecraft:light_gray_concrete
fill ~51 ~-43 ~38 ~62 ~-43 ~38 minecraft:air
setblock ~63 ~-43 ~38 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~38 minecraft:light_gray_concrete
setblock ~4 ~-43 ~39 minecraft:light_gray_concrete
fill ~5 ~-43 ~39 ~17 ~-43 ~39 minecraft:air
setblock ~18 ~-43 ~39 minecraft:light_gray_concrete
fill ~19 ~-43 ~39 ~21 ~-43 ~39 minecraft:air
fill ~22 ~-43 ~39 ~23 ~-43 ~39 minecraft:polished_andesite
fill ~24 ~-43 ~39 ~44 ~-43 ~39 minecraft:air
fill ~45 ~-43 ~39 ~46 ~-43 ~39 minecraft:polished_andesite
fill ~47 ~-43 ~39 ~48 ~-43 ~39 minecraft:air
setblock ~49 ~-43 ~39 minecraft:barrel
setblock ~50 ~-43 ~39 minecraft:light_gray_concrete
fill ~51 ~-43 ~39 ~52 ~-43 ~39 minecraft:air
fill ~53 ~-43 ~39 ~61 ~-43 ~39 minecraft:red_carpet
setblock ~62 ~-43 ~39 minecraft:air
setblock ~63 ~-43 ~39 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~39 minecraft:light_gray_concrete
setblock ~4 ~-43 ~40 minecraft:light_gray_concrete
fill ~5 ~-43 ~40 ~8 ~-43 ~40 minecraft:air
setblock ~9 ~-43 ~40 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-43 ~40 ~11 ~-43 ~40 minecraft:spruce_slab[type=top]
setblock ~12 ~-43 ~40 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-43 ~40 ~17 ~-43 ~40 minecraft:air
setblock ~18 ~-43 ~40 minecraft:light_gray_concrete
fill ~19 ~-43 ~40 ~22 ~-43 ~40 minecraft:air
setblock ~23 ~-43 ~40 minecraft:polished_andesite
fill ~24 ~-43 ~40 ~44 ~-43 ~40 minecraft:air
setblock ~45 ~-43 ~40 minecraft:polished_andesite
fill ~46 ~-43 ~40 ~49 ~-43 ~40 minecraft:air
setblock ~50 ~-43 ~40 minecraft:light_gray_concrete
fill ~51 ~-43 ~40 ~52 ~-43 ~40 minecraft:air
fill ~53 ~-43 ~40 ~61 ~-43 ~40 minecraft:red_carpet
setblock ~62 ~-43 ~40 minecraft:air
setblock ~63 ~-43 ~40 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~40 minecraft:light_gray_concrete
setblock ~4 ~-43 ~41 minecraft:light_gray_concrete
fill ~5 ~-43 ~41 ~8 ~-43 ~41 minecraft:air
setblock ~9 ~-43 ~41 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-43 ~41 ~11 ~-43 ~41 minecraft:spruce_slab[type=top]
setblock ~12 ~-43 ~41 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-43 ~41 ~17 ~-43 ~41 minecraft:air
setblock ~18 ~-43 ~41 minecraft:light_gray_concrete
fill ~19 ~-43 ~41 ~23 ~-43 ~41 minecraft:air
setblock ~24 ~-43 ~41 minecraft:polished_andesite
fill ~25 ~-43 ~41 ~43 ~-43 ~41 minecraft:air
setblock ~44 ~-43 ~41 minecraft:polished_andesite
fill ~45 ~-43 ~41 ~46 ~-43 ~41 minecraft:observer[facing=north]
setblock ~47 ~-43 ~41 minecraft:air
setblock ~48 ~-43 ~41 minecraft:observer[facing=north]
setblock ~49 ~-43 ~41 minecraft:air
setblock ~50 ~-43 ~41 minecraft:light_gray_concrete
fill ~51 ~-43 ~41 ~52 ~-43 ~41 minecraft:air
fill ~53 ~-43 ~41 ~61 ~-43 ~41 minecraft:red_carpet
setblock ~62 ~-43 ~41 minecraft:air
setblock ~63 ~-43 ~41 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~41 minecraft:light_gray_concrete
setblock ~4 ~-43 ~42 minecraft:light_gray_concrete
setblock ~5 ~-43 ~42 minecraft:black_concrete
fill ~6 ~-43 ~42 ~8 ~-43 ~42 minecraft:air
setblock ~9 ~-43 ~42 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-43 ~42 ~11 ~-43 ~42 minecraft:spruce_slab[type=top]
setblock ~12 ~-43 ~42 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-43 ~42 ~17 ~-43 ~42 minecraft:air
setblock ~18 ~-43 ~42 minecraft:light_gray_concrete
fill ~19 ~-43 ~42 ~23 ~-43 ~42 minecraft:air
fill ~24 ~-43 ~42 ~25 ~-43 ~42 minecraft:polished_andesite
fill ~26 ~-43 ~42 ~42 ~-43 ~42 minecraft:air
fill ~43 ~-43 ~42 ~44 ~-43 ~42 minecraft:polished_andesite
fill ~45 ~-43 ~42 ~49 ~-43 ~42 minecraft:air
setblock ~50 ~-43 ~42 minecraft:light_gray_concrete
fill ~51 ~-43 ~42 ~52 ~-43 ~42 minecraft:air
fill ~53 ~-43 ~42 ~59 ~-43 ~42 minecraft:red_carpet
setblock ~60 ~-43 ~42 minecraft:smooth_stone_slab[type=top]
setblock ~61 ~-43 ~42 minecraft:red_carpet
setblock ~62 ~-43 ~42 minecraft:air
setblock ~63 ~-43 ~42 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~42 minecraft:light_gray_concrete
setblock ~4 ~-43 ~43 minecraft:light_gray_concrete
setblock ~5 ~-43 ~43 minecraft:black_concrete
fill ~6 ~-43 ~43 ~8 ~-43 ~43 minecraft:air
setblock ~9 ~-43 ~43 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-43 ~43 ~11 ~-43 ~43 minecraft:spruce_slab[type=top]
setblock ~12 ~-43 ~43 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-43 ~43 ~17 ~-43 ~43 minecraft:air
setblock ~18 ~-43 ~43 minecraft:light_gray_concrete
fill ~19 ~-43 ~43 ~24 ~-43 ~43 minecraft:air
fill ~25 ~-43 ~43 ~26 ~-43 ~43 minecraft:polished_andesite
fill ~27 ~-43 ~43 ~41 ~-43 ~43 minecraft:air
fill ~42 ~-43 ~43 ~43 ~-43 ~43 minecraft:polished_andesite
fill ~44 ~-43 ~43 ~48 ~-43 ~43 minecraft:air
setblock ~49 ~-43 ~43 minecraft:barrel
setblock ~50 ~-43 ~43 minecraft:light_gray_concrete
fill ~51 ~-43 ~43 ~52 ~-43 ~43 minecraft:air
fill ~53 ~-43 ~43 ~58 ~-43 ~43 minecraft:red_carpet
setblock ~59 ~-43 ~43 minecraft:spruce_stairs[facing=west,half=bottom]
setblock ~60 ~-43 ~43 minecraft:smooth_stone_slab[type=top]
setblock ~61 ~-43 ~43 minecraft:red_carpet
setblock ~62 ~-43 ~43 minecraft:air
setblock ~63 ~-43 ~43 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~43 minecraft:light_gray_concrete
setblock ~4 ~-43 ~44 minecraft:light_gray_concrete
setblock ~5 ~-43 ~44 minecraft:black_concrete
fill ~6 ~-43 ~44 ~8 ~-43 ~44 minecraft:air
setblock ~9 ~-43 ~44 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-43 ~44 ~11 ~-43 ~44 minecraft:spruce_slab[type=top]
setblock ~12 ~-43 ~44 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-43 ~44 ~17 ~-43 ~44 minecraft:air
setblock ~18 ~-43 ~44 minecraft:light_gray_concrete
fill ~19 ~-43 ~44 ~25 ~-43 ~44 minecraft:air
fill ~26 ~-43 ~44 ~27 ~-43 ~44 minecraft:polished_andesite
fill ~28 ~-43 ~44 ~29 ~-43 ~44 minecraft:air
setblock ~30 ~-43 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-43 ~44 ~37 ~-43 ~44 minecraft:air
setblock ~38 ~-43 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-43 ~44 ~40 ~-43 ~44 minecraft:air
fill ~41 ~-43 ~44 ~42 ~-43 ~44 minecraft:polished_andesite
setblock ~43 ~-43 ~44 minecraft:air
fill ~44 ~-43 ~44 ~46 ~-43 ~44 minecraft:observer[facing=south]
setblock ~47 ~-43 ~44 minecraft:air
setblock ~48 ~-43 ~44 minecraft:observer[facing=south]
setblock ~49 ~-43 ~44 minecraft:air
setblock ~50 ~-43 ~44 minecraft:light_gray_concrete
fill ~51 ~-43 ~44 ~52 ~-43 ~44 minecraft:air
fill ~53 ~-43 ~44 ~59 ~-43 ~44 minecraft:red_carpet
setblock ~60 ~-43 ~44 minecraft:smooth_stone_slab[type=top]
setblock ~61 ~-43 ~44 minecraft:red_carpet
setblock ~62 ~-43 ~44 minecraft:air
setblock ~63 ~-43 ~44 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~44 minecraft:light_gray_concrete
setblock ~4 ~-43 ~45 minecraft:light_gray_concrete
fill ~5 ~-43 ~45 ~8 ~-43 ~45 minecraft:air
setblock ~9 ~-43 ~45 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-43 ~45 ~11 ~-43 ~45 minecraft:spruce_slab[type=top]
setblock ~12 ~-43 ~45 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-43 ~45 ~17 ~-43 ~45 minecraft:air
setblock ~18 ~-43 ~45 minecraft:light_gray_concrete
setblock ~19 ~-43 ~45 minecraft:air
fill ~20 ~-43 ~45 ~22 ~-43 ~45 minecraft:spruce_stairs[facing=north,half=bottom]
setblock ~23 ~-43 ~45 minecraft:air
fill ~24 ~-43 ~45 ~25 ~-43 ~45 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~26 ~-43 ~45 ~28 ~-43 ~45 minecraft:air
setblock ~29 ~-43 ~45 minecraft:polished_andesite
fill ~30 ~-43 ~45 ~38 ~-43 ~45 minecraft:air
setblock ~39 ~-43 ~45 minecraft:polished_andesite
fill ~40 ~-43 ~45 ~49 ~-43 ~45 minecraft:air
setblock ~50 ~-43 ~45 minecraft:light_gray_concrete
fill ~51 ~-43 ~45 ~52 ~-43 ~45 minecraft:air
fill ~53 ~-43 ~45 ~59 ~-43 ~45 minecraft:red_carpet
setblock ~60 ~-43 ~45 minecraft:lectern
setblock ~61 ~-43 ~45 minecraft:red_carpet
setblock ~62 ~-43 ~45 minecraft:air
setblock ~63 ~-43 ~45 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~45 minecraft:light_gray_concrete
setblock ~4 ~-43 ~46 minecraft:light_gray_concrete
fill ~5 ~-43 ~46 ~8 ~-43 ~46 minecraft:air
setblock ~9 ~-43 ~46 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-43 ~46 ~11 ~-43 ~46 minecraft:spruce_slab[type=top]
setblock ~12 ~-43 ~46 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-43 ~46 ~17 ~-43 ~46 minecraft:air
setblock ~18 ~-43 ~46 minecraft:light_gray_concrete
setblock ~19 ~-43 ~46 minecraft:air
fill ~20 ~-43 ~46 ~22 ~-43 ~46 minecraft:smooth_stone_slab[type=top]
setblock ~23 ~-43 ~46 minecraft:air
fill ~24 ~-43 ~46 ~25 ~-43 ~46 minecraft:smooth_stone_slab[type=top]
fill ~26 ~-43 ~46 ~28 ~-43 ~46 minecraft:air
fill ~29 ~-43 ~46 ~32 ~-43 ~46 minecraft:polished_andesite
fill ~33 ~-43 ~46 ~35 ~-43 ~46 minecraft:air
fill ~36 ~-43 ~46 ~39 ~-43 ~46 minecraft:polished_andesite
fill ~40 ~-43 ~46 ~49 ~-43 ~46 minecraft:air
setblock ~50 ~-43 ~46 minecraft:light_gray_concrete
fill ~51 ~-43 ~46 ~52 ~-43 ~46 minecraft:air
fill ~53 ~-43 ~46 ~61 ~-43 ~46 minecraft:red_carpet
setblock ~62 ~-43 ~46 minecraft:air
setblock ~63 ~-43 ~46 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~46 minecraft:light_gray_concrete
setblock ~4 ~-43 ~47 minecraft:light_gray_concrete
fill ~5 ~-43 ~47 ~17 ~-43 ~47 minecraft:air
setblock ~18 ~-43 ~47 minecraft:light_gray_concrete
fill ~19 ~-43 ~47 ~31 ~-43 ~47 minecraft:air
setblock ~32 ~-43 ~47 minecraft:light_gray_concrete
fill ~33 ~-43 ~47 ~35 ~-43 ~47 minecraft:air
setblock ~36 ~-43 ~47 minecraft:light_gray_concrete
setblock ~37 ~-43 ~47 minecraft:air
setblock ~38 ~-43 ~47 minecraft:observer[facing=north]
fill ~39 ~-43 ~47 ~40 ~-43 ~47 minecraft:air
fill ~41 ~-43 ~47 ~42 ~-43 ~47 minecraft:observer[facing=north]
setblock ~43 ~-43 ~47 minecraft:air
fill ~44 ~-43 ~47 ~46 ~-43 ~47 minecraft:observer[facing=north]
setblock ~47 ~-43 ~47 minecraft:air
setblock ~48 ~-43 ~47 minecraft:observer[facing=north]
setblock ~49 ~-43 ~47 minecraft:barrel
setblock ~50 ~-43 ~47 minecraft:light_gray_concrete
fill ~51 ~-43 ~47 ~52 ~-43 ~47 minecraft:air
fill ~53 ~-43 ~47 ~61 ~-43 ~47 minecraft:red_carpet
setblock ~62 ~-43 ~47 minecraft:air
setblock ~63 ~-43 ~47 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~47 minecraft:light_gray_concrete
setblock ~4 ~-43 ~48 minecraft:light_gray_concrete
fill ~5 ~-43 ~48 ~17 ~-43 ~48 minecraft:air
setblock ~18 ~-43 ~48 minecraft:light_gray_concrete
fill ~19 ~-43 ~48 ~49 ~-43 ~48 minecraft:air
setblock ~50 ~-43 ~48 minecraft:light_gray_concrete
fill ~51 ~-43 ~48 ~62 ~-43 ~48 minecraft:air
setblock ~63 ~-43 ~48 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~48 minecraft:light_gray_concrete
setblock ~4 ~-43 ~49 minecraft:light_gray_concrete
fill ~5 ~-43 ~49 ~17 ~-43 ~49 minecraft:air
setblock ~18 ~-43 ~49 minecraft:light_gray_concrete
fill ~19 ~-43 ~49 ~30 ~-43 ~49 minecraft:black_concrete
setblock ~31 ~-43 ~49 minecraft:air
setblock ~32 ~-43 ~49 minecraft:light_gray_concrete
fill ~33 ~-43 ~49 ~35 ~-43 ~49 minecraft:air
setblock ~36 ~-43 ~49 minecraft:light_gray_concrete
fill ~37 ~-43 ~49 ~38 ~-43 ~49 minecraft:air
setblock ~39 ~-43 ~49 minecraft:barrel
fill ~40 ~-43 ~49 ~42 ~-43 ~49 minecraft:air
setblock ~43 ~-43 ~49 minecraft:barrel
fill ~44 ~-43 ~49 ~46 ~-43 ~49 minecraft:air
setblock ~47 ~-43 ~49 minecraft:barrel
fill ~48 ~-43 ~49 ~49 ~-43 ~49 minecraft:air
setblock ~50 ~-43 ~49 minecraft:light_gray_concrete
fill ~51 ~-43 ~49 ~62 ~-43 ~49 minecraft:air
setblock ~63 ~-43 ~49 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-43 ~49 minecraft:light_gray_concrete
fill ~4 ~-43 ~50 ~10 ~-43 ~50 minecraft:light_gray_concrete
setblock ~11 ~-43 ~50 minecraft:air
fill ~12 ~-43 ~50 ~32 ~-43 ~50 minecraft:light_gray_concrete
fill ~33 ~-43 ~50 ~35 ~-43 ~50 minecraft:air
fill ~36 ~-43 ~50 ~56 ~-43 ~50 minecraft:light_gray_concrete
setblock ~57 ~-43 ~50 minecraft:air
fill ~58 ~-43 ~50 ~64 ~-43 ~50 minecraft:light_gray_concrete
setblock ~4 ~-43 ~51 minecraft:light_gray_concrete
setblock ~5 ~-43 ~51 minecraft:barrel
fill ~6 ~-43 ~51 ~8 ~-43 ~51 minecraft:air
setblock ~9 ~-43 ~51 minecraft:barrel
fill ~10 ~-43 ~51 ~12 ~-43 ~51 minecraft:air
setblock ~13 ~-43 ~51 minecraft:barrel
fill ~14 ~-43 ~51 ~16 ~-43 ~51 minecraft:air
setblock ~17 ~-43 ~51 minecraft:barrel
setblock ~18 ~-43 ~51 minecraft:light_gray_concrete
setblock ~19 ~-43 ~51 minecraft:waxed_cut_copper
setblock ~20 ~-43 ~51 minecraft:dispenser[facing=south]
setblock ~21 ~-43 ~51 minecraft:blast_furnace[facing=south]
setblock ~22 ~-43 ~51 minecraft:waxed_cut_copper
setblock ~23 ~-43 ~51 minecraft:dispenser[facing=south]
setblock ~24 ~-43 ~51 minecraft:blast_furnace[facing=south]
setblock ~25 ~-43 ~51 minecraft:waxed_cut_copper
setblock ~26 ~-43 ~51 minecraft:dispenser[facing=south]
setblock ~27 ~-43 ~51 minecraft:blast_furnace[facing=south]
setblock ~28 ~-43 ~51 minecraft:waxed_cut_copper
setblock ~29 ~-43 ~51 minecraft:dispenser[facing=south]
setblock ~30 ~-43 ~51 minecraft:blast_furnace[facing=south]
setblock ~31 ~-43 ~51 minecraft:waxed_cut_copper
setblock ~32 ~-43 ~51 minecraft:light_gray_concrete
fill ~33 ~-43 ~51 ~35 ~-43 ~51 minecraft:air
setblock ~36 ~-43 ~51 minecraft:light_gray_concrete
setblock ~37 ~-43 ~51 minecraft:crafting_table
setblock ~38 ~-43 ~51 minecraft:smithing_table
setblock ~39 ~-43 ~51 minecraft:barrel
setblock ~40 ~-43 ~51 minecraft:iron_block
setblock ~41 ~-43 ~51 minecraft:crafting_table
setblock ~42 ~-43 ~51 minecraft:smithing_table
setblock ~43 ~-43 ~51 minecraft:barrel
setblock ~44 ~-43 ~51 minecraft:iron_block
setblock ~45 ~-43 ~51 minecraft:crafting_table
setblock ~46 ~-43 ~51 minecraft:smithing_table
setblock ~47 ~-43 ~51 minecraft:barrel
setblock ~48 ~-43 ~51 minecraft:iron_block
setblock ~49 ~-43 ~51 minecraft:crafting_table
setblock ~50 ~-43 ~51 minecraft:light_gray_concrete
setblock ~51 ~-43 ~51 minecraft:chest[facing=south]
setblock ~52 ~-43 ~51 minecraft:air
setblock ~53 ~-43 ~51 minecraft:chest[facing=south]
setblock ~54 ~-43 ~51 minecraft:air
setblock ~55 ~-43 ~51 minecraft:chest[facing=south]
fill ~56 ~-43 ~51 ~58 ~-43 ~51 minecraft:air
setblock ~59 ~-43 ~51 minecraft:chest[facing=south]
setblock ~60 ~-43 ~51 minecraft:air
setblock ~61 ~-43 ~51 minecraft:chest[facing=south]
setblock ~62 ~-43 ~51 minecraft:air
setblock ~63 ~-43 ~51 minecraft:chest[facing=south]
setblock ~64 ~-43 ~51 minecraft:light_gray_concrete
setblock ~4 ~-43 ~52 minecraft:light_gray_concrete
setblock ~5 ~-43 ~52 minecraft:air
setblock ~6 ~-43 ~52 minecraft:observer[facing=south]
setblock ~7 ~-43 ~52 minecraft:air
fill ~8 ~-43 ~52 ~10 ~-43 ~52 minecraft:observer[facing=south]
setblock ~11 ~-43 ~52 minecraft:air
fill ~12 ~-43 ~52 ~14 ~-43 ~52 minecraft:observer[facing=south]
setblock ~15 ~-43 ~52 minecraft:air
setblock ~16 ~-43 ~52 minecraft:observer[facing=south]
setblock ~17 ~-43 ~52 minecraft:air
setblock ~18 ~-43 ~52 minecraft:light_gray_concrete
setblock ~19 ~-43 ~52 minecraft:dispenser[facing=east]
fill ~20 ~-43 ~52 ~30 ~-43 ~52 minecraft:air
setblock ~31 ~-43 ~52 minecraft:dispenser[facing=west]
setblock ~32 ~-43 ~52 minecraft:light_gray_concrete
fill ~33 ~-43 ~52 ~35 ~-43 ~52 minecraft:air
setblock ~36 ~-43 ~52 minecraft:light_gray_concrete
setblock ~37 ~-43 ~52 minecraft:smithing_table
fill ~38 ~-43 ~52 ~48 ~-43 ~52 minecraft:air
setblock ~49 ~-43 ~52 minecraft:smithing_table
setblock ~50 ~-43 ~52 minecraft:light_gray_concrete
setblock ~51 ~-43 ~52 minecraft:air
fill ~52 ~-43 ~52 ~55 ~-43 ~52 minecraft:barrel
fill ~56 ~-43 ~52 ~57 ~-43 ~52 minecraft:air
fill ~58 ~-43 ~52 ~60 ~-43 ~52 minecraft:barrel
setblock ~61 ~-43 ~52 minecraft:air
setblock ~62 ~-43 ~52 minecraft:barrel
setblock ~63 ~-43 ~52 minecraft:air
setblock ~64 ~-43 ~52 minecraft:light_gray_concrete
setblock ~4 ~-43 ~53 minecraft:light_gray_concrete
fill ~5 ~-43 ~53 ~17 ~-43 ~53 minecraft:air
setblock ~18 ~-43 ~53 minecraft:light_gray_concrete
setblock ~19 ~-43 ~53 minecraft:blast_furnace[facing=east]
fill ~20 ~-43 ~53 ~30 ~-43 ~53 minecraft:air
setblock ~31 ~-43 ~53 minecraft:blast_furnace[facing=west]
setblock ~32 ~-43 ~53 minecraft:light_gray_concrete
fill ~33 ~-43 ~53 ~35 ~-43 ~53 minecraft:air
setblock ~36 ~-43 ~53 minecraft:light_gray_concrete
setblock ~37 ~-43 ~53 minecraft:barrel
fill ~38 ~-43 ~53 ~48 ~-43 ~53 minecraft:air
setblock ~49 ~-43 ~53 minecraft:barrel
setblock ~50 ~-43 ~53 minecraft:light_gray_concrete
setblock ~51 ~-43 ~53 minecraft:chest[facing=east]
fill ~52 ~-43 ~53 ~62 ~-43 ~53 minecraft:air
setblock ~63 ~-43 ~53 minecraft:chest[facing=west]
setblock ~64 ~-43 ~53 minecraft:light_gray_concrete
setblock ~4 ~-43 ~54 minecraft:light_gray_concrete
fill ~5 ~-43 ~54 ~17 ~-43 ~54 minecraft:air
setblock ~18 ~-43 ~54 minecraft:light_gray_concrete
setblock ~19 ~-43 ~54 minecraft:waxed_cut_copper
fill ~20 ~-43 ~54 ~21 ~-43 ~54 minecraft:air
setblock ~22 ~-43 ~54 minecraft:waxed_cut_copper
fill ~23 ~-43 ~54 ~25 ~-43 ~54 minecraft:air
setblock ~26 ~-43 ~54 minecraft:waxed_cut_copper
fill ~27 ~-43 ~54 ~30 ~-43 ~54 minecraft:air
setblock ~31 ~-43 ~54 minecraft:waxed_cut_copper
setblock ~32 ~-43 ~54 minecraft:light_gray_concrete
fill ~33 ~-43 ~54 ~35 ~-43 ~54 minecraft:air
setblock ~36 ~-43 ~54 minecraft:light_gray_concrete
setblock ~37 ~-43 ~54 minecraft:iron_block
fill ~38 ~-43 ~54 ~48 ~-43 ~54 minecraft:air
setblock ~49 ~-43 ~54 minecraft:iron_block
setblock ~50 ~-43 ~54 minecraft:light_gray_concrete
fill ~51 ~-43 ~54 ~63 ~-43 ~54 minecraft:air
setblock ~64 ~-43 ~54 minecraft:light_gray_concrete
setblock ~4 ~-43 ~55 minecraft:light_gray_concrete
setblock ~5 ~-43 ~55 minecraft:barrel
setblock ~6 ~-43 ~55 minecraft:observer[facing=north]
setblock ~7 ~-43 ~55 minecraft:air
fill ~8 ~-43 ~55 ~10 ~-43 ~55 minecraft:observer[facing=north]
setblock ~11 ~-43 ~55 minecraft:air
fill ~12 ~-43 ~55 ~14 ~-43 ~55 minecraft:observer[facing=north]
setblock ~15 ~-43 ~55 minecraft:air
setblock ~16 ~-43 ~55 minecraft:observer[facing=north]
setblock ~17 ~-43 ~55 minecraft:barrel
setblock ~18 ~-43 ~55 minecraft:light_gray_concrete
setblock ~19 ~-43 ~55 minecraft:dispenser[facing=east]
fill ~20 ~-43 ~55 ~30 ~-43 ~55 minecraft:air
setblock ~31 ~-43 ~55 minecraft:dispenser[facing=west]
setblock ~32 ~-43 ~55 minecraft:light_gray_concrete
fill ~33 ~-43 ~55 ~35 ~-43 ~55 minecraft:air
setblock ~36 ~-43 ~55 minecraft:light_gray_concrete
setblock ~37 ~-43 ~55 minecraft:crafting_table
fill ~38 ~-43 ~55 ~39 ~-43 ~55 minecraft:air
fill ~40 ~-43 ~55 ~46 ~-43 ~55 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-43 ~55 ~48 ~-43 ~55 minecraft:air
setblock ~49 ~-43 ~55 minecraft:crafting_table
setblock ~50 ~-43 ~55 minecraft:light_gray_concrete
setblock ~51 ~-43 ~55 minecraft:chest[facing=east]
fill ~52 ~-43 ~55 ~55 ~-43 ~55 minecraft:barrel
setblock ~56 ~-43 ~55 minecraft:air
fill ~57 ~-43 ~55 ~60 ~-43 ~55 minecraft:barrel
setblock ~61 ~-43 ~55 minecraft:air
setblock ~62 ~-43 ~55 minecraft:barrel
setblock ~63 ~-43 ~55 minecraft:chest[facing=west]
setblock ~64 ~-43 ~55 minecraft:light_gray_concrete
setblock ~4 ~-43 ~56 minecraft:light_gray_concrete
fill ~5 ~-43 ~56 ~17 ~-43 ~56 minecraft:air
setblock ~18 ~-43 ~56 minecraft:light_gray_concrete
fill ~19 ~-43 ~56 ~31 ~-43 ~56 minecraft:air
setblock ~32 ~-43 ~56 minecraft:light_gray_concrete
fill ~33 ~-43 ~56 ~35 ~-43 ~56 minecraft:air
setblock ~36 ~-43 ~56 minecraft:light_gray_concrete
fill ~37 ~-43 ~56 ~49 ~-43 ~56 minecraft:air
setblock ~50 ~-43 ~56 minecraft:light_gray_concrete
fill ~51 ~-43 ~56 ~63 ~-43 ~56 minecraft:air
setblock ~64 ~-43 ~56 minecraft:light_gray_concrete
setblock ~4 ~-43 ~57 minecraft:light_gray_concrete
fill ~5 ~-43 ~57 ~62 ~-43 ~57 minecraft:air
setblock ~63 ~-43 ~57 minecraft:chest[facing=west]
setblock ~64 ~-43 ~57 minecraft:light_gray_concrete
setblock ~4 ~-43 ~58 minecraft:light_gray_concrete
setblock ~5 ~-43 ~58 minecraft:air
setblock ~6 ~-43 ~58 minecraft:observer[facing=south]
setblock ~7 ~-43 ~58 minecraft:air
fill ~8 ~-43 ~58 ~10 ~-43 ~58 minecraft:observer[facing=south]
setblock ~11 ~-43 ~58 minecraft:air
fill ~12 ~-43 ~58 ~14 ~-43 ~58 minecraft:observer[facing=south]
setblock ~15 ~-43 ~58 minecraft:air
setblock ~16 ~-43 ~58 minecraft:observer[facing=south]
setblock ~17 ~-43 ~58 minecraft:air
setblock ~18 ~-43 ~58 minecraft:light_gray_concrete
fill ~19 ~-43 ~58 ~21 ~-43 ~58 minecraft:air
setblock ~22 ~-43 ~58 minecraft:waxed_cut_copper
fill ~23 ~-43 ~58 ~25 ~-43 ~58 minecraft:air
setblock ~26 ~-43 ~58 minecraft:waxed_cut_copper
fill ~27 ~-43 ~58 ~31 ~-43 ~58 minecraft:air
setblock ~32 ~-43 ~58 minecraft:light_gray_concrete
fill ~33 ~-43 ~58 ~35 ~-43 ~58 minecraft:air
setblock ~36 ~-43 ~58 minecraft:light_gray_concrete
fill ~37 ~-43 ~58 ~49 ~-43 ~58 minecraft:air
setblock ~50 ~-43 ~58 minecraft:light_gray_concrete
setblock ~51 ~-43 ~58 minecraft:air
fill ~52 ~-43 ~58 ~55 ~-43 ~58 minecraft:barrel
setblock ~56 ~-43 ~58 minecraft:air
fill ~57 ~-43 ~58 ~60 ~-43 ~58 minecraft:barrel
setblock ~61 ~-43 ~58 minecraft:air
setblock ~62 ~-43 ~58 minecraft:barrel
setblock ~63 ~-43 ~58 minecraft:air
setblock ~64 ~-43 ~58 minecraft:light_gray_concrete
setblock ~4 ~-43 ~59 minecraft:light_gray_concrete
setblock ~5 ~-43 ~59 minecraft:barrel
fill ~6 ~-43 ~59 ~16 ~-43 ~59 minecraft:air
setblock ~17 ~-43 ~59 minecraft:barrel
setblock ~18 ~-43 ~59 minecraft:light_gray_concrete
setblock ~19 ~-43 ~59 minecraft:blast_furnace[facing=east]
fill ~20 ~-43 ~59 ~30 ~-43 ~59 minecraft:air
setblock ~31 ~-43 ~59 minecraft:blast_furnace[facing=west]
setblock ~32 ~-43 ~59 minecraft:light_gray_concrete
fill ~33 ~-43 ~59 ~35 ~-43 ~59 minecraft:air
setblock ~36 ~-43 ~59 minecraft:light_gray_concrete
setblock ~37 ~-43 ~59 minecraft:crafting_table
fill ~38 ~-43 ~59 ~39 ~-43 ~59 minecraft:air
fill ~40 ~-43 ~59 ~46 ~-43 ~59 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-43 ~59 ~48 ~-43 ~59 minecraft:air
setblock ~49 ~-43 ~59 minecraft:crafting_table
setblock ~50 ~-43 ~59 minecraft:light_gray_concrete
setblock ~51 ~-43 ~59 minecraft:chest[facing=east]
fill ~52 ~-43 ~59 ~62 ~-43 ~59 minecraft:air
setblock ~63 ~-43 ~59 minecraft:chest[facing=west]
setblock ~64 ~-43 ~59 minecraft:light_gray_concrete
setblock ~4 ~-43 ~60 minecraft:light_gray_concrete
fill ~5 ~-43 ~60 ~17 ~-43 ~60 minecraft:air
setblock ~18 ~-43 ~60 minecraft:light_gray_concrete
setblock ~19 ~-43 ~60 minecraft:waxed_cut_copper
fill ~20 ~-43 ~60 ~30 ~-43 ~60 minecraft:air
setblock ~31 ~-43 ~60 minecraft:waxed_cut_copper
setblock ~32 ~-43 ~60 minecraft:light_gray_concrete
fill ~33 ~-43 ~60 ~35 ~-43 ~60 minecraft:air
setblock ~36 ~-43 ~60 minecraft:light_gray_concrete
setblock ~37 ~-43 ~60 minecraft:smithing_table
fill ~38 ~-43 ~60 ~48 ~-43 ~60 minecraft:air
setblock ~49 ~-43 ~60 minecraft:smithing_table
setblock ~50 ~-43 ~60 minecraft:light_gray_concrete
fill ~51 ~-43 ~60 ~63 ~-43 ~60 minecraft:air
setblock ~64 ~-43 ~60 minecraft:light_gray_concrete
setblock ~4 ~-43 ~61 minecraft:light_gray_concrete
setblock ~5 ~-43 ~61 minecraft:air
setblock ~6 ~-43 ~61 minecraft:observer[facing=north]
setblock ~7 ~-43 ~61 minecraft:air
fill ~8 ~-43 ~61 ~10 ~-43 ~61 minecraft:observer[facing=north]
setblock ~11 ~-43 ~61 minecraft:air
fill ~12 ~-43 ~61 ~14 ~-43 ~61 minecraft:observer[facing=north]
setblock ~15 ~-43 ~61 minecraft:air
setblock ~16 ~-43 ~61 minecraft:observer[facing=north]
setblock ~17 ~-43 ~61 minecraft:air
setblock ~18 ~-43 ~61 minecraft:light_gray_concrete
setblock ~19 ~-43 ~61 minecraft:dispenser[facing=east]
fill ~20 ~-43 ~61 ~30 ~-43 ~61 minecraft:air
setblock ~31 ~-43 ~61 minecraft:dispenser[facing=west]
setblock ~32 ~-43 ~61 minecraft:light_gray_concrete
fill ~33 ~-43 ~61 ~35 ~-43 ~61 minecraft:air
setblock ~36 ~-43 ~61 minecraft:light_gray_concrete
setblock ~37 ~-43 ~61 minecraft:barrel
fill ~38 ~-43 ~61 ~48 ~-43 ~61 minecraft:air
setblock ~49 ~-43 ~61 minecraft:barrel
setblock ~50 ~-43 ~61 minecraft:light_gray_concrete
setblock ~51 ~-43 ~61 minecraft:chest[facing=east]
fill ~52 ~-43 ~61 ~55 ~-43 ~61 minecraft:barrel
setblock ~56 ~-43 ~61 minecraft:air
fill ~57 ~-43 ~61 ~60 ~-43 ~61 minecraft:barrel
setblock ~61 ~-43 ~61 minecraft:air
setblock ~62 ~-43 ~61 minecraft:barrel
setblock ~63 ~-43 ~61 minecraft:chest[facing=west]
setblock ~64 ~-43 ~61 minecraft:light_gray_concrete
setblock ~4 ~-43 ~62 minecraft:light_gray_concrete
fill ~5 ~-43 ~62 ~17 ~-43 ~62 minecraft:air
setblock ~18 ~-43 ~62 minecraft:light_gray_concrete
setblock ~19 ~-43 ~62 minecraft:blast_furnace[facing=east]
fill ~20 ~-43 ~62 ~30 ~-43 ~62 minecraft:air
setblock ~31 ~-43 ~62 minecraft:blast_furnace[facing=west]
setblock ~32 ~-43 ~62 minecraft:light_gray_concrete
fill ~33 ~-43 ~62 ~35 ~-43 ~62 minecraft:air
setblock ~36 ~-43 ~62 minecraft:light_gray_concrete
setblock ~37 ~-43 ~62 minecraft:iron_block
fill ~38 ~-43 ~62 ~48 ~-43 ~62 minecraft:air
setblock ~49 ~-43 ~62 minecraft:iron_block
setblock ~50 ~-43 ~62 minecraft:light_gray_concrete
fill ~51 ~-43 ~62 ~63 ~-43 ~62 minecraft:air
setblock ~64 ~-43 ~62 minecraft:light_gray_concrete
setblock ~4 ~-43 ~63 minecraft:light_gray_concrete
setblock ~5 ~-43 ~63 minecraft:barrel
fill ~6 ~-43 ~63 ~8 ~-43 ~63 minecraft:air
setblock ~9 ~-43 ~63 minecraft:barrel
fill ~10 ~-43 ~63 ~12 ~-43 ~63 minecraft:air
setblock ~13 ~-43 ~63 minecraft:barrel
fill ~14 ~-43 ~63 ~16 ~-43 ~63 minecraft:air
setblock ~17 ~-43 ~63 minecraft:barrel
setblock ~18 ~-43 ~63 minecraft:light_gray_concrete
setblock ~19 ~-43 ~63 minecraft:waxed_cut_copper
setblock ~20 ~-43 ~63 minecraft:dispenser[facing=north]
setblock ~21 ~-43 ~63 minecraft:blast_furnace[facing=north]
setblock ~22 ~-43 ~63 minecraft:waxed_cut_copper
setblock ~23 ~-43 ~63 minecraft:dispenser[facing=north]
setblock ~24 ~-43 ~63 minecraft:blast_furnace[facing=north]
setblock ~25 ~-43 ~63 minecraft:waxed_cut_copper
setblock ~26 ~-43 ~63 minecraft:dispenser[facing=north]
setblock ~27 ~-43 ~63 minecraft:blast_furnace[facing=north]
setblock ~28 ~-43 ~63 minecraft:waxed_cut_copper
setblock ~29 ~-43 ~63 minecraft:dispenser[facing=north]
setblock ~30 ~-43 ~63 minecraft:blast_furnace[facing=north]
setblock ~31 ~-43 ~63 minecraft:waxed_cut_copper
setblock ~32 ~-43 ~63 minecraft:light_gray_concrete
fill ~33 ~-43 ~63 ~35 ~-43 ~63 minecraft:air
setblock ~36 ~-43 ~63 minecraft:light_gray_concrete
setblock ~37 ~-43 ~63 minecraft:crafting_table
setblock ~38 ~-43 ~63 minecraft:smithing_table
setblock ~39 ~-43 ~63 minecraft:barrel
setblock ~40 ~-43 ~63 minecraft:iron_block
setblock ~41 ~-43 ~63 minecraft:crafting_table
setblock ~42 ~-43 ~63 minecraft:smithing_table
setblock ~43 ~-43 ~63 minecraft:barrel
setblock ~44 ~-43 ~63 minecraft:iron_block
setblock ~45 ~-43 ~63 minecraft:crafting_table
setblock ~46 ~-43 ~63 minecraft:smithing_table
setblock ~47 ~-43 ~63 minecraft:barrel
setblock ~48 ~-43 ~63 minecraft:iron_block
setblock ~49 ~-43 ~63 minecraft:crafting_table
setblock ~50 ~-43 ~63 minecraft:light_gray_concrete
setblock ~51 ~-43 ~63 minecraft:chest[facing=north]
setblock ~52 ~-43 ~63 minecraft:air
setblock ~53 ~-43 ~63 minecraft:chest[facing=north]
setblock ~54 ~-43 ~63 minecraft:air
setblock ~55 ~-43 ~63 minecraft:chest[facing=north]
setblock ~56 ~-43 ~63 minecraft:air
setblock ~57 ~-43 ~63 minecraft:chest[facing=north]
setblock ~58 ~-43 ~63 minecraft:air
setblock ~59 ~-43 ~63 minecraft:chest[facing=north]
setblock ~60 ~-43 ~63 minecraft:air
setblock ~61 ~-43 ~63 minecraft:chest[facing=north]
setblock ~62 ~-43 ~63 minecraft:air
setblock ~63 ~-43 ~63 minecraft:chest[facing=west]
setblock ~64 ~-43 ~63 minecraft:light_gray_concrete
fill ~4 ~-43 ~64 ~33 ~-43 ~64 minecraft:light_gray_concrete
setblock ~34 ~-43 ~64 minecraft:air
fill ~35 ~-43 ~64 ~64 ~-43 ~64 minecraft:light_gray_concrete
setblock ~33 ~-43 ~65 minecraft:light_gray_concrete
setblock ~34 ~-43 ~65 minecraft:air
setblock ~35 ~-43 ~65 minecraft:light_gray_concrete
fill ~32 ~-43 ~66 ~33 ~-43 ~66 minecraft:polished_andesite
setblock ~34 ~-43 ~66 minecraft:air
fill ~35 ~-43 ~66 ~36 ~-43 ~66 minecraft:polished_andesite
setblock ~32 ~-43 ~67 minecraft:polished_andesite
fill ~33 ~-43 ~67 ~34 ~-43 ~67 minecraft:air
setblock ~35 ~-43 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-43 ~67 minecraft:polished_andesite
setblock ~32 ~-43 ~68 minecraft:polished_andesite
setblock ~33 ~-43 ~68 minecraft:air
setblock ~34 ~-43 ~68 minecraft:quartz_pillar
setblock ~35 ~-43 ~68 minecraft:air
setblock ~36 ~-43 ~68 minecraft:polished_andesite
setblock ~32 ~-43 ~69 minecraft:polished_andesite
fill ~33 ~-43 ~69 ~35 ~-43 ~69 minecraft:air
setblock ~36 ~-43 ~69 minecraft:polished_andesite
fill ~32 ~-43 ~70 ~36 ~-43 ~70 minecraft:polished_andesite
fill ~4 ~-42 ~4 ~64 ~-42 ~4 minecraft:light_gray_concrete
setblock ~4 ~-42 ~5 minecraft:light_gray_concrete
fill ~5 ~-42 ~5 ~17 ~-42 ~5 minecraft:air
setblock ~18 ~-42 ~5 minecraft:light_gray_concrete
fill ~19 ~-42 ~5 ~31 ~-42 ~5 minecraft:air
setblock ~32 ~-42 ~5 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~5 ~35 ~-42 ~5 minecraft:air
setblock ~36 ~-42 ~5 minecraft:red_concrete
fill ~37 ~-42 ~5 ~39 ~-42 ~5 minecraft:air
setblock ~40 ~-42 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~5 ~43 ~-42 ~5 minecraft:air
setblock ~44 ~-42 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~5 ~47 ~-42 ~5 minecraft:air
setblock ~48 ~-42 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~5 minecraft:air
setblock ~50 ~-42 ~5 minecraft:light_gray_concrete
fill ~51 ~-42 ~5 ~63 ~-42 ~5 minecraft:iron_block
setblock ~64 ~-42 ~5 minecraft:light_gray_concrete
setblock ~4 ~-42 ~6 minecraft:light_gray_concrete
fill ~5 ~-42 ~6 ~17 ~-42 ~6 minecraft:air
setblock ~18 ~-42 ~6 minecraft:light_gray_concrete
fill ~19 ~-42 ~6 ~31 ~-42 ~6 minecraft:air
setblock ~32 ~-42 ~6 minecraft:red_concrete
fill ~33 ~-42 ~6 ~35 ~-42 ~6 minecraft:air
setblock ~36 ~-42 ~6 minecraft:red_concrete
fill ~37 ~-42 ~6 ~39 ~-42 ~6 minecraft:air
setblock ~40 ~-42 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~6 ~43 ~-42 ~6 minecraft:air
setblock ~44 ~-42 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~6 ~47 ~-42 ~6 minecraft:air
setblock ~48 ~-42 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~6 minecraft:air
setblock ~50 ~-42 ~6 minecraft:light_gray_concrete
setblock ~51 ~-42 ~6 minecraft:iron_block
fill ~52 ~-42 ~6 ~62 ~-42 ~6 minecraft:air
setblock ~63 ~-42 ~6 minecraft:iron_block
setblock ~64 ~-42 ~6 minecraft:light_gray_concrete
setblock ~4 ~-42 ~7 minecraft:light_gray_concrete
setblock ~5 ~-42 ~7 minecraft:air
setblock ~6 ~-42 ~7 minecraft:observer[facing=south]
setblock ~7 ~-42 ~7 minecraft:air
fill ~8 ~-42 ~7 ~10 ~-42 ~7 minecraft:observer[facing=south]
setblock ~11 ~-42 ~7 minecraft:air
fill ~12 ~-42 ~7 ~14 ~-42 ~7 minecraft:observer[facing=south]
setblock ~15 ~-42 ~7 minecraft:air
setblock ~16 ~-42 ~7 minecraft:observer[facing=south]
setblock ~17 ~-42 ~7 minecraft:air
setblock ~18 ~-42 ~7 minecraft:light_gray_concrete
setblock ~19 ~-42 ~7 minecraft:air
setblock ~20 ~-42 ~7 minecraft:observer[facing=south]
setblock ~21 ~-42 ~7 minecraft:air
fill ~22 ~-42 ~7 ~24 ~-42 ~7 minecraft:observer[facing=south]
setblock ~25 ~-42 ~7 minecraft:air
fill ~26 ~-42 ~7 ~28 ~-42 ~7 minecraft:observer[facing=south]
setblock ~29 ~-42 ~7 minecraft:air
setblock ~30 ~-42 ~7 minecraft:observer[facing=south]
setblock ~31 ~-42 ~7 minecraft:air
setblock ~32 ~-42 ~7 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~7 ~35 ~-42 ~7 minecraft:air
setblock ~36 ~-42 ~7 minecraft:red_concrete
fill ~37 ~-42 ~7 ~39 ~-42 ~7 minecraft:air
setblock ~40 ~-42 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~7 ~43 ~-42 ~7 minecraft:air
setblock ~44 ~-42 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~7 ~47 ~-42 ~7 minecraft:air
setblock ~48 ~-42 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~7 minecraft:air
setblock ~50 ~-42 ~7 minecraft:light_gray_concrete
setblock ~51 ~-42 ~7 minecraft:iron_block
setblock ~52 ~-42 ~7 minecraft:air
setblock ~53 ~-42 ~7 minecraft:raw_gold_block
setblock ~54 ~-42 ~7 minecraft:air
setblock ~55 ~-42 ~7 minecraft:gold_block
setblock ~56 ~-42 ~7 minecraft:air
setblock ~57 ~-42 ~7 minecraft:raw_gold_block
setblock ~58 ~-42 ~7 minecraft:air
setblock ~59 ~-42 ~7 minecraft:gold_block
setblock ~60 ~-42 ~7 minecraft:air
setblock ~61 ~-42 ~7 minecraft:raw_gold_block
setblock ~62 ~-42 ~7 minecraft:air
setblock ~63 ~-42 ~7 minecraft:iron_block
setblock ~64 ~-42 ~7 minecraft:light_gray_concrete
setblock ~4 ~-42 ~8 minecraft:light_gray_concrete
fill ~5 ~-42 ~8 ~17 ~-42 ~8 minecraft:air
setblock ~18 ~-42 ~8 minecraft:light_gray_concrete
fill ~19 ~-42 ~8 ~31 ~-42 ~8 minecraft:air
setblock ~32 ~-42 ~8 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~8 ~35 ~-42 ~8 minecraft:air
setblock ~36 ~-42 ~8 minecraft:red_concrete
fill ~37 ~-42 ~8 ~39 ~-42 ~8 minecraft:air
setblock ~40 ~-42 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~8 ~43 ~-42 ~8 minecraft:air
setblock ~44 ~-42 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~8 ~47 ~-42 ~8 minecraft:air
setblock ~48 ~-42 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~8 minecraft:air
setblock ~50 ~-42 ~8 minecraft:light_gray_concrete
setblock ~51 ~-42 ~8 minecraft:iron_block
fill ~52 ~-42 ~8 ~53 ~-42 ~8 minecraft:air
setblock ~54 ~-42 ~8 minecraft:gold_block
setblock ~55 ~-42 ~8 minecraft:air
setblock ~56 ~-42 ~8 minecraft:raw_gold_block
setblock ~57 ~-42 ~8 minecraft:air
setblock ~58 ~-42 ~8 minecraft:gold_block
setblock ~59 ~-42 ~8 minecraft:air
setblock ~60 ~-42 ~8 minecraft:raw_gold_block
fill ~61 ~-42 ~8 ~62 ~-42 ~8 minecraft:air
setblock ~63 ~-42 ~8 minecraft:iron_block
setblock ~64 ~-42 ~8 minecraft:light_gray_concrete
setblock ~4 ~-42 ~9 minecraft:light_gray_concrete
fill ~5 ~-42 ~9 ~17 ~-42 ~9 minecraft:air
setblock ~18 ~-42 ~9 minecraft:light_gray_concrete
fill ~19 ~-42 ~9 ~31 ~-42 ~9 minecraft:air
setblock ~32 ~-42 ~9 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~9 ~35 ~-42 ~9 minecraft:air
setblock ~36 ~-42 ~9 minecraft:red_concrete
fill ~37 ~-42 ~9 ~39 ~-42 ~9 minecraft:air
setblock ~40 ~-42 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~9 ~43 ~-42 ~9 minecraft:air
setblock ~44 ~-42 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~9 ~47 ~-42 ~9 minecraft:air
setblock ~48 ~-42 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~9 minecraft:air
setblock ~50 ~-42 ~9 minecraft:light_gray_concrete
setblock ~51 ~-42 ~9 minecraft:iron_block
setblock ~52 ~-42 ~9 minecraft:air
setblock ~53 ~-42 ~9 minecraft:gold_block
setblock ~54 ~-42 ~9 minecraft:air
setblock ~55 ~-42 ~9 minecraft:raw_gold_block
setblock ~56 ~-42 ~9 minecraft:air
setblock ~57 ~-42 ~9 minecraft:gold_block
setblock ~58 ~-42 ~9 minecraft:air
setblock ~59 ~-42 ~9 minecraft:raw_gold_block
setblock ~60 ~-42 ~9 minecraft:air
setblock ~61 ~-42 ~9 minecraft:gold_block
setblock ~62 ~-42 ~9 minecraft:air
setblock ~63 ~-42 ~9 minecraft:iron_block
setblock ~64 ~-42 ~9 minecraft:light_gray_concrete
setblock ~4 ~-42 ~10 minecraft:light_gray_concrete
setblock ~5 ~-42 ~10 minecraft:air
setblock ~6 ~-42 ~10 minecraft:observer[facing=north]
setblock ~7 ~-42 ~10 minecraft:air
fill ~8 ~-42 ~10 ~10 ~-42 ~10 minecraft:observer[facing=north]
setblock ~11 ~-42 ~10 minecraft:air
fill ~12 ~-42 ~10 ~14 ~-42 ~10 minecraft:observer[facing=north]
setblock ~15 ~-42 ~10 minecraft:air
setblock ~16 ~-42 ~10 minecraft:observer[facing=north]
setblock ~17 ~-42 ~10 minecraft:air
setblock ~18 ~-42 ~10 minecraft:light_gray_concrete
setblock ~19 ~-42 ~10 minecraft:air
setblock ~20 ~-42 ~10 minecraft:observer[facing=north]
setblock ~21 ~-42 ~10 minecraft:air
fill ~22 ~-42 ~10 ~24 ~-42 ~10 minecraft:observer[facing=north]
setblock ~25 ~-42 ~10 minecraft:air
fill ~26 ~-42 ~10 ~28 ~-42 ~10 minecraft:observer[facing=north]
setblock ~29 ~-42 ~10 minecraft:air
setblock ~30 ~-42 ~10 minecraft:observer[facing=north]
setblock ~31 ~-42 ~10 minecraft:air
setblock ~32 ~-42 ~10 minecraft:red_concrete
fill ~33 ~-42 ~10 ~35 ~-42 ~10 minecraft:air
setblock ~36 ~-42 ~10 minecraft:red_concrete
fill ~37 ~-42 ~10 ~39 ~-42 ~10 minecraft:air
setblock ~40 ~-42 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~10 ~43 ~-42 ~10 minecraft:air
setblock ~44 ~-42 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~10 ~47 ~-42 ~10 minecraft:air
setblock ~48 ~-42 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~10 minecraft:air
setblock ~50 ~-42 ~10 minecraft:light_gray_concrete
fill ~51 ~-42 ~10 ~53 ~-42 ~10 minecraft:air
setblock ~54 ~-42 ~10 minecraft:raw_gold_block
setblock ~55 ~-42 ~10 minecraft:air
setblock ~56 ~-42 ~10 minecraft:gold_block
setblock ~57 ~-42 ~10 minecraft:air
setblock ~58 ~-42 ~10 minecraft:raw_gold_block
setblock ~59 ~-42 ~10 minecraft:air
setblock ~60 ~-42 ~10 minecraft:gold_block
fill ~61 ~-42 ~10 ~62 ~-42 ~10 minecraft:air
setblock ~63 ~-42 ~10 minecraft:iron_block
setblock ~64 ~-42 ~10 minecraft:light_gray_concrete
setblock ~4 ~-42 ~11 minecraft:light_gray_concrete
fill ~5 ~-42 ~11 ~39 ~-42 ~11 minecraft:air
setblock ~40 ~-42 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~11 ~43 ~-42 ~11 minecraft:air
setblock ~44 ~-42 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~11 ~52 ~-42 ~11 minecraft:air
setblock ~53 ~-42 ~11 minecraft:raw_gold_block
setblock ~54 ~-42 ~11 minecraft:air
setblock ~55 ~-42 ~11 minecraft:gold_block
setblock ~56 ~-42 ~11 minecraft:air
setblock ~57 ~-42 ~11 minecraft:raw_gold_block
setblock ~58 ~-42 ~11 minecraft:air
setblock ~59 ~-42 ~11 minecraft:gold_block
setblock ~60 ~-42 ~11 minecraft:air
setblock ~61 ~-42 ~11 minecraft:raw_gold_block
setblock ~62 ~-42 ~11 minecraft:air
setblock ~63 ~-42 ~11 minecraft:iron_block
setblock ~64 ~-42 ~11 minecraft:light_gray_concrete
setblock ~4 ~-42 ~12 minecraft:light_gray_concrete
fill ~5 ~-42 ~12 ~17 ~-42 ~12 minecraft:air
setblock ~18 ~-42 ~12 minecraft:light_gray_concrete
fill ~19 ~-42 ~12 ~31 ~-42 ~12 minecraft:air
setblock ~32 ~-42 ~12 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~12 ~35 ~-42 ~12 minecraft:air
setblock ~36 ~-42 ~12 minecraft:red_concrete
fill ~37 ~-42 ~12 ~39 ~-42 ~12 minecraft:air
setblock ~40 ~-42 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~12 ~43 ~-42 ~12 minecraft:air
setblock ~44 ~-42 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~12 ~47 ~-42 ~12 minecraft:air
setblock ~48 ~-42 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~12 minecraft:air
setblock ~50 ~-42 ~12 minecraft:light_gray_concrete
fill ~51 ~-42 ~12 ~53 ~-42 ~12 minecraft:air
setblock ~54 ~-42 ~12 minecraft:gold_block
setblock ~55 ~-42 ~12 minecraft:air
setblock ~56 ~-42 ~12 minecraft:raw_gold_block
setblock ~57 ~-42 ~12 minecraft:air
setblock ~58 ~-42 ~12 minecraft:gold_block
setblock ~59 ~-42 ~12 minecraft:air
setblock ~60 ~-42 ~12 minecraft:raw_gold_block
fill ~61 ~-42 ~12 ~62 ~-42 ~12 minecraft:air
setblock ~63 ~-42 ~12 minecraft:iron_block
setblock ~64 ~-42 ~12 minecraft:light_gray_concrete
setblock ~4 ~-42 ~13 minecraft:light_gray_concrete
setblock ~5 ~-42 ~13 minecraft:air
setblock ~6 ~-42 ~13 minecraft:observer[facing=south]
setblock ~7 ~-42 ~13 minecraft:air
fill ~8 ~-42 ~13 ~10 ~-42 ~13 minecraft:observer[facing=south]
setblock ~11 ~-42 ~13 minecraft:air
fill ~12 ~-42 ~13 ~14 ~-42 ~13 minecraft:observer[facing=south]
setblock ~15 ~-42 ~13 minecraft:air
setblock ~16 ~-42 ~13 minecraft:observer[facing=south]
setblock ~17 ~-42 ~13 minecraft:air
setblock ~18 ~-42 ~13 minecraft:light_gray_concrete
setblock ~19 ~-42 ~13 minecraft:air
setblock ~20 ~-42 ~13 minecraft:observer[facing=south]
setblock ~21 ~-42 ~13 minecraft:air
fill ~22 ~-42 ~13 ~24 ~-42 ~13 minecraft:observer[facing=south]
setblock ~25 ~-42 ~13 minecraft:air
fill ~26 ~-42 ~13 ~28 ~-42 ~13 minecraft:observer[facing=south]
setblock ~29 ~-42 ~13 minecraft:air
setblock ~30 ~-42 ~13 minecraft:observer[facing=south]
setblock ~31 ~-42 ~13 minecraft:air
setblock ~32 ~-42 ~13 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~13 ~35 ~-42 ~13 minecraft:air
setblock ~36 ~-42 ~13 minecraft:red_concrete
fill ~37 ~-42 ~13 ~39 ~-42 ~13 minecraft:air
setblock ~40 ~-42 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~13 ~43 ~-42 ~13 minecraft:air
setblock ~44 ~-42 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~13 ~47 ~-42 ~13 minecraft:air
setblock ~48 ~-42 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~13 minecraft:air
setblock ~50 ~-42 ~13 minecraft:light_gray_concrete
setblock ~51 ~-42 ~13 minecraft:iron_block
setblock ~52 ~-42 ~13 minecraft:air
setblock ~53 ~-42 ~13 minecraft:gold_block
setblock ~54 ~-42 ~13 minecraft:air
setblock ~55 ~-42 ~13 minecraft:raw_gold_block
setblock ~56 ~-42 ~13 minecraft:air
setblock ~57 ~-42 ~13 minecraft:gold_block
setblock ~58 ~-42 ~13 minecraft:air
setblock ~59 ~-42 ~13 minecraft:raw_gold_block
setblock ~60 ~-42 ~13 minecraft:air
setblock ~61 ~-42 ~13 minecraft:gold_block
setblock ~62 ~-42 ~13 minecraft:air
setblock ~63 ~-42 ~13 minecraft:iron_block
setblock ~64 ~-42 ~13 minecraft:light_gray_concrete
setblock ~4 ~-42 ~14 minecraft:light_gray_concrete
fill ~5 ~-42 ~14 ~17 ~-42 ~14 minecraft:air
setblock ~18 ~-42 ~14 minecraft:light_gray_concrete
fill ~19 ~-42 ~14 ~31 ~-42 ~14 minecraft:air
setblock ~32 ~-42 ~14 minecraft:red_concrete
fill ~33 ~-42 ~14 ~35 ~-42 ~14 minecraft:air
setblock ~36 ~-42 ~14 minecraft:red_concrete
fill ~37 ~-42 ~14 ~39 ~-42 ~14 minecraft:air
setblock ~40 ~-42 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~14 ~43 ~-42 ~14 minecraft:air
setblock ~44 ~-42 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~14 ~47 ~-42 ~14 minecraft:air
setblock ~48 ~-42 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~14 minecraft:air
setblock ~50 ~-42 ~14 minecraft:light_gray_concrete
setblock ~51 ~-42 ~14 minecraft:iron_block
fill ~52 ~-42 ~14 ~53 ~-42 ~14 minecraft:air
setblock ~54 ~-42 ~14 minecraft:raw_gold_block
setblock ~55 ~-42 ~14 minecraft:air
setblock ~56 ~-42 ~14 minecraft:gold_block
setblock ~57 ~-42 ~14 minecraft:air
setblock ~58 ~-42 ~14 minecraft:raw_gold_block
setblock ~59 ~-42 ~14 minecraft:air
setblock ~60 ~-42 ~14 minecraft:gold_block
fill ~61 ~-42 ~14 ~62 ~-42 ~14 minecraft:air
setblock ~63 ~-42 ~14 minecraft:iron_block
setblock ~64 ~-42 ~14 minecraft:light_gray_concrete
setblock ~4 ~-42 ~15 minecraft:light_gray_concrete
fill ~5 ~-42 ~15 ~17 ~-42 ~15 minecraft:air
setblock ~18 ~-42 ~15 minecraft:light_gray_concrete
fill ~19 ~-42 ~15 ~31 ~-42 ~15 minecraft:air
setblock ~32 ~-42 ~15 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~15 ~35 ~-42 ~15 minecraft:air
setblock ~36 ~-42 ~15 minecraft:red_concrete
fill ~37 ~-42 ~15 ~39 ~-42 ~15 minecraft:air
setblock ~40 ~-42 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~15 ~43 ~-42 ~15 minecraft:air
setblock ~44 ~-42 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~15 ~47 ~-42 ~15 minecraft:air
setblock ~48 ~-42 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~15 minecraft:air
setblock ~50 ~-42 ~15 minecraft:light_gray_concrete
setblock ~51 ~-42 ~15 minecraft:iron_block
setblock ~52 ~-42 ~15 minecraft:air
setblock ~53 ~-42 ~15 minecraft:raw_gold_block
setblock ~54 ~-42 ~15 minecraft:air
setblock ~55 ~-42 ~15 minecraft:gold_block
setblock ~56 ~-42 ~15 minecraft:air
setblock ~57 ~-42 ~15 minecraft:raw_gold_block
setblock ~58 ~-42 ~15 minecraft:air
setblock ~59 ~-42 ~15 minecraft:gold_block
setblock ~60 ~-42 ~15 minecraft:air
setblock ~61 ~-42 ~15 minecraft:raw_gold_block
setblock ~62 ~-42 ~15 minecraft:air
setblock ~63 ~-42 ~15 minecraft:iron_block
setblock ~64 ~-42 ~15 minecraft:light_gray_concrete
setblock ~4 ~-42 ~16 minecraft:light_gray_concrete
setblock ~5 ~-42 ~16 minecraft:air
setblock ~6 ~-42 ~16 minecraft:observer[facing=north]
setblock ~7 ~-42 ~16 minecraft:air
fill ~8 ~-42 ~16 ~10 ~-42 ~16 minecraft:observer[facing=north]
setblock ~11 ~-42 ~16 minecraft:air
fill ~12 ~-42 ~16 ~14 ~-42 ~16 minecraft:observer[facing=north]
setblock ~15 ~-42 ~16 minecraft:air
setblock ~16 ~-42 ~16 minecraft:observer[facing=north]
setblock ~17 ~-42 ~16 minecraft:air
setblock ~18 ~-42 ~16 minecraft:light_gray_concrete
setblock ~19 ~-42 ~16 minecraft:air
setblock ~20 ~-42 ~16 minecraft:observer[facing=north]
setblock ~21 ~-42 ~16 minecraft:air
fill ~22 ~-42 ~16 ~24 ~-42 ~16 minecraft:observer[facing=north]
setblock ~25 ~-42 ~16 minecraft:air
fill ~26 ~-42 ~16 ~28 ~-42 ~16 minecraft:observer[facing=north]
setblock ~29 ~-42 ~16 minecraft:air
setblock ~30 ~-42 ~16 minecraft:observer[facing=north]
setblock ~31 ~-42 ~16 minecraft:air
setblock ~32 ~-42 ~16 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~16 ~35 ~-42 ~16 minecraft:air
setblock ~36 ~-42 ~16 minecraft:red_concrete
fill ~37 ~-42 ~16 ~39 ~-42 ~16 minecraft:air
setblock ~40 ~-42 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~16 ~43 ~-42 ~16 minecraft:air
setblock ~44 ~-42 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~16 ~47 ~-42 ~16 minecraft:air
setblock ~48 ~-42 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
schedule function hive:weiter/6 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 5 von 18 fertig","color":"gray"}]