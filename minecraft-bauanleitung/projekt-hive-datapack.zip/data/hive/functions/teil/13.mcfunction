fill ~51 ~-23 ~58 ~63 ~-23 ~58 minecraft:air
setblock ~64 ~-23 ~58 minecraft:light_gray_concrete
setblock ~4 ~-23 ~59 minecraft:light_gray_concrete
fill ~5 ~-23 ~59 ~17 ~-23 ~59 minecraft:air
setblock ~18 ~-23 ~59 minecraft:light_gray_concrete
fill ~19 ~-23 ~59 ~31 ~-23 ~59 minecraft:air
setblock ~32 ~-23 ~59 minecraft:light_gray_concrete
fill ~33 ~-23 ~59 ~35 ~-23 ~59 minecraft:air
setblock ~36 ~-23 ~59 minecraft:light_gray_concrete
fill ~37 ~-23 ~59 ~49 ~-23 ~59 minecraft:air
setblock ~50 ~-23 ~59 minecraft:light_gray_concrete
fill ~51 ~-23 ~59 ~63 ~-23 ~59 minecraft:air
setblock ~64 ~-23 ~59 minecraft:light_gray_concrete
setblock ~4 ~-23 ~60 minecraft:light_gray_concrete
fill ~5 ~-23 ~60 ~17 ~-23 ~60 minecraft:air
setblock ~18 ~-23 ~60 minecraft:light_gray_concrete
fill ~19 ~-23 ~60 ~31 ~-23 ~60 minecraft:air
setblock ~32 ~-23 ~60 minecraft:light_gray_concrete
fill ~33 ~-23 ~60 ~35 ~-23 ~60 minecraft:air
setblock ~36 ~-23 ~60 minecraft:light_gray_concrete
fill ~37 ~-23 ~60 ~49 ~-23 ~60 minecraft:air
setblock ~50 ~-23 ~60 minecraft:light_gray_concrete
fill ~51 ~-23 ~60 ~63 ~-23 ~60 minecraft:air
setblock ~64 ~-23 ~60 minecraft:light_gray_concrete
setblock ~4 ~-23 ~61 minecraft:light_gray_concrete
fill ~5 ~-23 ~61 ~17 ~-23 ~61 minecraft:air
setblock ~18 ~-23 ~61 minecraft:light_gray_concrete
fill ~19 ~-23 ~61 ~31 ~-23 ~61 minecraft:air
setblock ~32 ~-23 ~61 minecraft:light_gray_concrete
fill ~33 ~-23 ~61 ~35 ~-23 ~61 minecraft:air
setblock ~36 ~-23 ~61 minecraft:light_gray_concrete
fill ~37 ~-23 ~61 ~49 ~-23 ~61 minecraft:air
setblock ~50 ~-23 ~61 minecraft:light_gray_concrete
fill ~51 ~-23 ~61 ~63 ~-23 ~61 minecraft:air
setblock ~64 ~-23 ~61 minecraft:light_gray_concrete
setblock ~4 ~-23 ~62 minecraft:light_gray_concrete
fill ~5 ~-23 ~62 ~17 ~-23 ~62 minecraft:air
setblock ~18 ~-23 ~62 minecraft:light_gray_concrete
fill ~19 ~-23 ~62 ~31 ~-23 ~62 minecraft:air
setblock ~32 ~-23 ~62 minecraft:light_gray_concrete
fill ~33 ~-23 ~62 ~35 ~-23 ~62 minecraft:air
setblock ~36 ~-23 ~62 minecraft:light_gray_concrete
fill ~37 ~-23 ~62 ~49 ~-23 ~62 minecraft:air
setblock ~50 ~-23 ~62 minecraft:light_gray_concrete
fill ~51 ~-23 ~62 ~63 ~-23 ~62 minecraft:air
setblock ~64 ~-23 ~62 minecraft:light_gray_concrete
setblock ~4 ~-23 ~63 minecraft:light_gray_concrete
fill ~5 ~-23 ~63 ~17 ~-23 ~63 minecraft:air
setblock ~18 ~-23 ~63 minecraft:light_gray_concrete
fill ~19 ~-23 ~63 ~31 ~-23 ~63 minecraft:air
setblock ~32 ~-23 ~63 minecraft:light_gray_concrete
fill ~33 ~-23 ~63 ~35 ~-23 ~63 minecraft:air
setblock ~36 ~-23 ~63 minecraft:light_gray_concrete
fill ~37 ~-23 ~63 ~49 ~-23 ~63 minecraft:air
setblock ~50 ~-23 ~63 minecraft:light_gray_concrete
fill ~51 ~-23 ~63 ~63 ~-23 ~63 minecraft:air
setblock ~64 ~-23 ~63 minecraft:light_gray_concrete
fill ~4 ~-23 ~64 ~64 ~-23 ~64 minecraft:light_gray_concrete
fill ~32 ~-23 ~66 ~36 ~-23 ~66 minecraft:polished_andesite
setblock ~32 ~-23 ~67 minecraft:polished_andesite
fill ~33 ~-23 ~67 ~35 ~-23 ~67 minecraft:air
setblock ~36 ~-23 ~67 minecraft:polished_andesite
setblock ~32 ~-23 ~68 minecraft:polished_andesite
setblock ~33 ~-23 ~68 minecraft:air
setblock ~34 ~-23 ~68 minecraft:quartz_pillar
setblock ~35 ~-23 ~68 minecraft:air
setblock ~36 ~-23 ~68 minecraft:polished_andesite
setblock ~32 ~-23 ~69 minecraft:polished_andesite
setblock ~33 ~-23 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-23 ~69 ~35 ~-23 ~69 minecraft:air
setblock ~36 ~-23 ~69 minecraft:polished_andesite
fill ~32 ~-23 ~70 ~36 ~-23 ~70 minecraft:polished_andesite
fill ~4 ~-22 ~4 ~64 ~-22 ~4 minecraft:light_gray_concrete
setblock ~4 ~-22 ~5 minecraft:light_gray_concrete
fill ~5 ~-22 ~5 ~17 ~-22 ~5 minecraft:air
setblock ~18 ~-22 ~5 minecraft:light_gray_concrete
fill ~19 ~-22 ~5 ~31 ~-22 ~5 minecraft:air
setblock ~32 ~-22 ~5 minecraft:light_gray_concrete
fill ~33 ~-22 ~5 ~35 ~-22 ~5 minecraft:air
setblock ~36 ~-22 ~5 minecraft:light_gray_concrete
fill ~37 ~-22 ~5 ~49 ~-22 ~5 minecraft:air
setblock ~50 ~-22 ~5 minecraft:light_gray_concrete
fill ~51 ~-22 ~5 ~63 ~-22 ~5 minecraft:air
setblock ~64 ~-22 ~5 minecraft:light_gray_concrete
setblock ~4 ~-22 ~6 minecraft:light_gray_concrete
fill ~5 ~-22 ~6 ~17 ~-22 ~6 minecraft:air
setblock ~18 ~-22 ~6 minecraft:light_gray_concrete
fill ~19 ~-22 ~6 ~31 ~-22 ~6 minecraft:air
setblock ~32 ~-22 ~6 minecraft:light_gray_concrete
fill ~33 ~-22 ~6 ~35 ~-22 ~6 minecraft:air
setblock ~36 ~-22 ~6 minecraft:light_gray_concrete
fill ~37 ~-22 ~6 ~49 ~-22 ~6 minecraft:air
setblock ~50 ~-22 ~6 minecraft:light_gray_concrete
fill ~51 ~-22 ~6 ~63 ~-22 ~6 minecraft:air
setblock ~64 ~-22 ~6 minecraft:light_gray_concrete
setblock ~4 ~-22 ~7 minecraft:light_gray_concrete
fill ~5 ~-22 ~7 ~17 ~-22 ~7 minecraft:air
setblock ~18 ~-22 ~7 minecraft:light_gray_concrete
fill ~19 ~-22 ~7 ~31 ~-22 ~7 minecraft:air
setblock ~32 ~-22 ~7 minecraft:light_gray_concrete
fill ~33 ~-22 ~7 ~35 ~-22 ~7 minecraft:air
setblock ~36 ~-22 ~7 minecraft:light_gray_concrete
fill ~37 ~-22 ~7 ~49 ~-22 ~7 minecraft:air
setblock ~50 ~-22 ~7 minecraft:light_gray_concrete
fill ~51 ~-22 ~7 ~63 ~-22 ~7 minecraft:air
setblock ~64 ~-22 ~7 minecraft:light_gray_concrete
setblock ~4 ~-22 ~8 minecraft:light_gray_concrete
fill ~5 ~-22 ~8 ~17 ~-22 ~8 minecraft:air
setblock ~18 ~-22 ~8 minecraft:light_gray_concrete
fill ~19 ~-22 ~8 ~31 ~-22 ~8 minecraft:air
setblock ~32 ~-22 ~8 minecraft:light_gray_concrete
fill ~33 ~-22 ~8 ~35 ~-22 ~8 minecraft:air
setblock ~36 ~-22 ~8 minecraft:light_gray_concrete
fill ~37 ~-22 ~8 ~49 ~-22 ~8 minecraft:air
setblock ~50 ~-22 ~8 minecraft:light_gray_concrete
fill ~51 ~-22 ~8 ~63 ~-22 ~8 minecraft:air
setblock ~64 ~-22 ~8 minecraft:light_gray_concrete
setblock ~4 ~-22 ~9 minecraft:light_gray_concrete
fill ~5 ~-22 ~9 ~17 ~-22 ~9 minecraft:air
setblock ~18 ~-22 ~9 minecraft:light_gray_concrete
fill ~19 ~-22 ~9 ~31 ~-22 ~9 minecraft:air
setblock ~32 ~-22 ~9 minecraft:light_gray_concrete
fill ~33 ~-22 ~9 ~35 ~-22 ~9 minecraft:air
setblock ~36 ~-22 ~9 minecraft:light_gray_concrete
fill ~37 ~-22 ~9 ~49 ~-22 ~9 minecraft:air
setblock ~50 ~-22 ~9 minecraft:light_gray_concrete
fill ~51 ~-22 ~9 ~63 ~-22 ~9 minecraft:air
setblock ~64 ~-22 ~9 minecraft:light_gray_concrete
setblock ~4 ~-22 ~10 minecraft:light_gray_concrete
fill ~5 ~-22 ~10 ~17 ~-22 ~10 minecraft:air
setblock ~18 ~-22 ~10 minecraft:light_gray_concrete
fill ~19 ~-22 ~10 ~31 ~-22 ~10 minecraft:air
setblock ~32 ~-22 ~10 minecraft:light_gray_concrete
fill ~33 ~-22 ~10 ~35 ~-22 ~10 minecraft:air
setblock ~36 ~-22 ~10 minecraft:light_gray_concrete
fill ~37 ~-22 ~10 ~49 ~-22 ~10 minecraft:air
setblock ~50 ~-22 ~10 minecraft:light_gray_concrete
fill ~51 ~-22 ~10 ~63 ~-22 ~10 minecraft:air
setblock ~64 ~-22 ~10 minecraft:light_gray_concrete
setblock ~4 ~-22 ~11 minecraft:light_gray_concrete
fill ~5 ~-22 ~11 ~17 ~-22 ~11 minecraft:air
setblock ~18 ~-22 ~11 minecraft:light_gray_concrete
fill ~19 ~-22 ~11 ~31 ~-22 ~11 minecraft:air
setblock ~32 ~-22 ~11 minecraft:light_gray_concrete
fill ~33 ~-22 ~11 ~35 ~-22 ~11 minecraft:air
setblock ~36 ~-22 ~11 minecraft:light_gray_concrete
fill ~37 ~-22 ~11 ~49 ~-22 ~11 minecraft:air
setblock ~50 ~-22 ~11 minecraft:light_gray_concrete
fill ~51 ~-22 ~11 ~63 ~-22 ~11 minecraft:air
setblock ~64 ~-22 ~11 minecraft:light_gray_concrete
setblock ~4 ~-22 ~12 minecraft:light_gray_concrete
fill ~5 ~-22 ~12 ~17 ~-22 ~12 minecraft:air
setblock ~18 ~-22 ~12 minecraft:light_gray_concrete
fill ~19 ~-22 ~12 ~31 ~-22 ~12 minecraft:air
setblock ~32 ~-22 ~12 minecraft:light_gray_concrete
fill ~33 ~-22 ~12 ~35 ~-22 ~12 minecraft:air
setblock ~36 ~-22 ~12 minecraft:light_gray_concrete
fill ~37 ~-22 ~12 ~49 ~-22 ~12 minecraft:air
setblock ~50 ~-22 ~12 minecraft:light_gray_concrete
fill ~51 ~-22 ~12 ~63 ~-22 ~12 minecraft:air
setblock ~64 ~-22 ~12 minecraft:light_gray_concrete
setblock ~4 ~-22 ~13 minecraft:light_gray_concrete
fill ~5 ~-22 ~13 ~17 ~-22 ~13 minecraft:air
setblock ~18 ~-22 ~13 minecraft:light_gray_concrete
fill ~19 ~-22 ~13 ~31 ~-22 ~13 minecraft:air
setblock ~32 ~-22 ~13 minecraft:light_gray_concrete
fill ~33 ~-22 ~13 ~35 ~-22 ~13 minecraft:air
setblock ~36 ~-22 ~13 minecraft:light_gray_concrete
fill ~37 ~-22 ~13 ~49 ~-22 ~13 minecraft:air
setblock ~50 ~-22 ~13 minecraft:light_gray_concrete
fill ~51 ~-22 ~13 ~63 ~-22 ~13 minecraft:air
setblock ~64 ~-22 ~13 minecraft:light_gray_concrete
setblock ~4 ~-22 ~14 minecraft:light_gray_concrete
fill ~5 ~-22 ~14 ~17 ~-22 ~14 minecraft:air
setblock ~18 ~-22 ~14 minecraft:light_gray_concrete
fill ~19 ~-22 ~14 ~31 ~-22 ~14 minecraft:air
setblock ~32 ~-22 ~14 minecraft:light_gray_concrete
fill ~33 ~-22 ~14 ~35 ~-22 ~14 minecraft:air
setblock ~36 ~-22 ~14 minecraft:light_gray_concrete
fill ~37 ~-22 ~14 ~49 ~-22 ~14 minecraft:air
setblock ~50 ~-22 ~14 minecraft:light_gray_concrete
fill ~51 ~-22 ~14 ~63 ~-22 ~14 minecraft:air
setblock ~64 ~-22 ~14 minecraft:light_gray_concrete
setblock ~4 ~-22 ~15 minecraft:light_gray_concrete
fill ~5 ~-22 ~15 ~17 ~-22 ~15 minecraft:air
setblock ~18 ~-22 ~15 minecraft:light_gray_concrete
fill ~19 ~-22 ~15 ~31 ~-22 ~15 minecraft:air
setblock ~32 ~-22 ~15 minecraft:light_gray_concrete
fill ~33 ~-22 ~15 ~35 ~-22 ~15 minecraft:air
setblock ~36 ~-22 ~15 minecraft:light_gray_concrete
fill ~37 ~-22 ~15 ~49 ~-22 ~15 minecraft:air
setblock ~50 ~-22 ~15 minecraft:light_gray_concrete
fill ~51 ~-22 ~15 ~63 ~-22 ~15 minecraft:air
setblock ~64 ~-22 ~15 minecraft:light_gray_concrete
setblock ~4 ~-22 ~16 minecraft:light_gray_concrete
fill ~5 ~-22 ~16 ~17 ~-22 ~16 minecraft:air
setblock ~18 ~-22 ~16 minecraft:light_gray_concrete
fill ~19 ~-22 ~16 ~31 ~-22 ~16 minecraft:air
setblock ~32 ~-22 ~16 minecraft:light_gray_concrete
fill ~33 ~-22 ~16 ~35 ~-22 ~16 minecraft:air
setblock ~36 ~-22 ~16 minecraft:light_gray_concrete
fill ~37 ~-22 ~16 ~49 ~-22 ~16 minecraft:air
setblock ~50 ~-22 ~16 minecraft:light_gray_concrete
fill ~51 ~-22 ~16 ~63 ~-22 ~16 minecraft:air
setblock ~64 ~-22 ~16 minecraft:light_gray_concrete
setblock ~4 ~-22 ~17 minecraft:light_gray_concrete
fill ~5 ~-22 ~17 ~17 ~-22 ~17 minecraft:air
setblock ~18 ~-22 ~17 minecraft:light_gray_concrete
fill ~19 ~-22 ~17 ~31 ~-22 ~17 minecraft:air
setblock ~32 ~-22 ~17 minecraft:light_gray_concrete
fill ~33 ~-22 ~17 ~35 ~-22 ~17 minecraft:air
setblock ~36 ~-22 ~17 minecraft:light_gray_concrete
fill ~37 ~-22 ~17 ~49 ~-22 ~17 minecraft:air
setblock ~50 ~-22 ~17 minecraft:light_gray_concrete
fill ~51 ~-22 ~17 ~63 ~-22 ~17 minecraft:air
setblock ~64 ~-22 ~17 minecraft:light_gray_concrete
fill ~4 ~-22 ~18 ~32 ~-22 ~18 minecraft:light_gray_concrete
fill ~33 ~-22 ~18 ~35 ~-22 ~18 minecraft:air
fill ~36 ~-22 ~18 ~64 ~-22 ~18 minecraft:light_gray_concrete
setblock ~4 ~-22 ~19 minecraft:light_gray_concrete
fill ~5 ~-22 ~19 ~17 ~-22 ~19 minecraft:air
setblock ~18 ~-22 ~19 minecraft:light_gray_concrete
fill ~19 ~-22 ~19 ~31 ~-22 ~19 minecraft:air
setblock ~32 ~-22 ~19 minecraft:light_gray_concrete
fill ~33 ~-22 ~19 ~35 ~-22 ~19 minecraft:air
setblock ~36 ~-22 ~19 minecraft:light_gray_concrete
fill ~37 ~-22 ~19 ~49 ~-22 ~19 minecraft:air
setblock ~50 ~-22 ~19 minecraft:light_gray_concrete
fill ~51 ~-22 ~19 ~63 ~-22 ~19 minecraft:air
setblock ~64 ~-22 ~19 minecraft:light_gray_concrete
setblock ~4 ~-22 ~20 minecraft:light_gray_concrete
fill ~5 ~-22 ~20 ~17 ~-22 ~20 minecraft:air
setblock ~18 ~-22 ~20 minecraft:light_gray_concrete
fill ~19 ~-22 ~20 ~31 ~-22 ~20 minecraft:air
setblock ~32 ~-22 ~20 minecraft:light_gray_concrete
fill ~33 ~-22 ~20 ~35 ~-22 ~20 minecraft:air
setblock ~36 ~-22 ~20 minecraft:light_gray_concrete
fill ~37 ~-22 ~20 ~49 ~-22 ~20 minecraft:air
setblock ~50 ~-22 ~20 minecraft:light_gray_concrete
fill ~51 ~-22 ~20 ~63 ~-22 ~20 minecraft:air
setblock ~64 ~-22 ~20 minecraft:light_gray_concrete
setblock ~4 ~-22 ~21 minecraft:light_gray_concrete
fill ~5 ~-22 ~21 ~17 ~-22 ~21 minecraft:air
setblock ~18 ~-22 ~21 minecraft:light_gray_concrete
fill ~19 ~-22 ~21 ~31 ~-22 ~21 minecraft:air
setblock ~32 ~-22 ~21 minecraft:light_gray_concrete
setblock ~33 ~-22 ~21 minecraft:air
setblock ~34 ~-22 ~21 minecraft:smooth_quartz
setblock ~35 ~-22 ~21 minecraft:air
setblock ~36 ~-22 ~21 minecraft:light_gray_concrete
fill ~37 ~-22 ~21 ~49 ~-22 ~21 minecraft:air
setblock ~50 ~-22 ~21 minecraft:light_gray_concrete
fill ~51 ~-22 ~21 ~63 ~-22 ~21 minecraft:air
setblock ~64 ~-22 ~21 minecraft:light_gray_concrete
setblock ~4 ~-22 ~22 minecraft:light_gray_concrete
fill ~5 ~-22 ~22 ~17 ~-22 ~22 minecraft:air
setblock ~18 ~-22 ~22 minecraft:light_gray_concrete
fill ~19 ~-22 ~22 ~28 ~-22 ~22 minecraft:air
fill ~29 ~-22 ~22 ~33 ~-22 ~22 minecraft:smooth_quartz
setblock ~34 ~-22 ~22 minecraft:air
fill ~35 ~-22 ~22 ~39 ~-22 ~22 minecraft:smooth_quartz
fill ~40 ~-22 ~22 ~49 ~-22 ~22 minecraft:air
setblock ~50 ~-22 ~22 minecraft:light_gray_concrete
fill ~51 ~-22 ~22 ~63 ~-22 ~22 minecraft:air
setblock ~64 ~-22 ~22 minecraft:light_gray_concrete
setblock ~4 ~-22 ~23 minecraft:light_gray_concrete
fill ~5 ~-22 ~23 ~17 ~-22 ~23 minecraft:air
setblock ~18 ~-22 ~23 minecraft:light_gray_concrete
fill ~19 ~-22 ~23 ~27 ~-22 ~23 minecraft:air
fill ~28 ~-22 ~23 ~29 ~-22 ~23 minecraft:smooth_quartz
fill ~30 ~-22 ~23 ~38 ~-22 ~23 minecraft:air
fill ~39 ~-22 ~23 ~40 ~-22 ~23 minecraft:smooth_quartz
fill ~41 ~-22 ~23 ~49 ~-22 ~23 minecraft:air
setblock ~50 ~-22 ~23 minecraft:light_gray_concrete
fill ~51 ~-22 ~23 ~63 ~-22 ~23 minecraft:air
setblock ~64 ~-22 ~23 minecraft:light_gray_concrete
setblock ~4 ~-22 ~24 minecraft:light_gray_concrete
fill ~5 ~-22 ~24 ~17 ~-22 ~24 minecraft:air
setblock ~18 ~-22 ~24 minecraft:light_gray_concrete
fill ~19 ~-22 ~24 ~25 ~-22 ~24 minecraft:air
fill ~26 ~-22 ~24 ~27 ~-22 ~24 minecraft:smooth_quartz
fill ~28 ~-22 ~24 ~29 ~-22 ~24 minecraft:air
setblock ~30 ~-22 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-22 ~24 ~37 ~-22 ~24 minecraft:air
setblock ~38 ~-22 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-22 ~24 ~40 ~-22 ~24 minecraft:air
fill ~41 ~-22 ~24 ~42 ~-22 ~24 minecraft:smooth_quartz
fill ~43 ~-22 ~24 ~49 ~-22 ~24 minecraft:air
setblock ~50 ~-22 ~24 minecraft:light_gray_concrete
fill ~51 ~-22 ~24 ~63 ~-22 ~24 minecraft:air
setblock ~64 ~-22 ~24 minecraft:light_gray_concrete
setblock ~4 ~-22 ~25 minecraft:light_gray_concrete
fill ~5 ~-22 ~25 ~17 ~-22 ~25 minecraft:air
setblock ~18 ~-22 ~25 minecraft:light_gray_concrete
fill ~19 ~-22 ~25 ~24 ~-22 ~25 minecraft:air
fill ~25 ~-22 ~25 ~26 ~-22 ~25 minecraft:smooth_quartz
fill ~27 ~-22 ~25 ~41 ~-22 ~25 minecraft:air
fill ~42 ~-22 ~25 ~43 ~-22 ~25 minecraft:smooth_quartz
fill ~44 ~-22 ~25 ~49 ~-22 ~25 minecraft:air
setblock ~50 ~-22 ~25 minecraft:light_gray_concrete
fill ~51 ~-22 ~25 ~63 ~-22 ~25 minecraft:air
setblock ~64 ~-22 ~25 minecraft:light_gray_concrete
setblock ~4 ~-22 ~26 minecraft:light_gray_concrete
fill ~5 ~-22 ~26 ~17 ~-22 ~26 minecraft:air
setblock ~18 ~-22 ~26 minecraft:light_gray_concrete
fill ~19 ~-22 ~26 ~23 ~-22 ~26 minecraft:air
fill ~24 ~-22 ~26 ~25 ~-22 ~26 minecraft:smooth_quartz
fill ~26 ~-22 ~26 ~42 ~-22 ~26 minecraft:air
fill ~43 ~-22 ~26 ~44 ~-22 ~26 minecraft:smooth_quartz
fill ~45 ~-22 ~26 ~49 ~-22 ~26 minecraft:air
setblock ~50 ~-22 ~26 minecraft:light_gray_concrete
fill ~51 ~-22 ~26 ~63 ~-22 ~26 minecraft:air
setblock ~64 ~-22 ~26 minecraft:light_gray_concrete
setblock ~4 ~-22 ~27 minecraft:light_gray_concrete
fill ~5 ~-22 ~27 ~17 ~-22 ~27 minecraft:air
setblock ~18 ~-22 ~27 minecraft:light_gray_concrete
fill ~19 ~-22 ~27 ~23 ~-22 ~27 minecraft:air
setblock ~24 ~-22 ~27 minecraft:smooth_quartz
fill ~25 ~-22 ~27 ~43 ~-22 ~27 minecraft:air
setblock ~44 ~-22 ~27 minecraft:smooth_quartz
fill ~45 ~-22 ~27 ~49 ~-22 ~27 minecraft:air
setblock ~50 ~-22 ~27 minecraft:light_gray_concrete
fill ~51 ~-22 ~27 ~63 ~-22 ~27 minecraft:air
setblock ~64 ~-22 ~27 minecraft:light_gray_concrete
setblock ~4 ~-22 ~28 minecraft:light_gray_concrete
fill ~5 ~-22 ~28 ~17 ~-22 ~28 minecraft:air
setblock ~18 ~-22 ~28 minecraft:light_gray_concrete
fill ~19 ~-22 ~28 ~22 ~-22 ~28 minecraft:air
setblock ~23 ~-22 ~28 minecraft:smooth_quartz
fill ~24 ~-22 ~28 ~44 ~-22 ~28 minecraft:air
setblock ~45 ~-22 ~28 minecraft:smooth_quartz
fill ~46 ~-22 ~28 ~49 ~-22 ~28 minecraft:air
setblock ~50 ~-22 ~28 minecraft:light_gray_concrete
fill ~51 ~-22 ~28 ~63 ~-22 ~28 minecraft:air
setblock ~64 ~-22 ~28 minecraft:light_gray_concrete
setblock ~4 ~-22 ~29 minecraft:light_gray_concrete
fill ~5 ~-22 ~29 ~17 ~-22 ~29 minecraft:air
setblock ~18 ~-22 ~29 minecraft:light_gray_concrete
fill ~19 ~-22 ~29 ~21 ~-22 ~29 minecraft:air
fill ~22 ~-22 ~29 ~23 ~-22 ~29 minecraft:smooth_quartz
fill ~24 ~-22 ~29 ~44 ~-22 ~29 minecraft:air
fill ~45 ~-22 ~29 ~46 ~-22 ~29 minecraft:smooth_quartz
fill ~47 ~-22 ~29 ~49 ~-22 ~29 minecraft:air
setblock ~50 ~-22 ~29 minecraft:light_gray_concrete
fill ~51 ~-22 ~29 ~63 ~-22 ~29 minecraft:air
setblock ~64 ~-22 ~29 minecraft:light_gray_concrete
setblock ~4 ~-22 ~30 minecraft:light_gray_concrete
fill ~5 ~-22 ~30 ~17 ~-22 ~30 minecraft:air
setblock ~18 ~-22 ~30 minecraft:light_gray_concrete
fill ~19 ~-22 ~30 ~21 ~-22 ~30 minecraft:air
setblock ~22 ~-22 ~30 minecraft:smooth_quartz
setblock ~23 ~-22 ~30 minecraft:air
setblock ~24 ~-22 ~30 minecraft:chiseled_quartz_block
fill ~25 ~-22 ~30 ~43 ~-22 ~30 minecraft:air
setblock ~44 ~-22 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-22 ~30 minecraft:air
setblock ~46 ~-22 ~30 minecraft:smooth_quartz
fill ~47 ~-22 ~30 ~49 ~-22 ~30 minecraft:air
setblock ~50 ~-22 ~30 minecraft:light_gray_concrete
fill ~51 ~-22 ~30 ~63 ~-22 ~30 minecraft:air
setblock ~64 ~-22 ~30 minecraft:light_gray_concrete
setblock ~4 ~-22 ~31 minecraft:light_gray_concrete
fill ~5 ~-22 ~31 ~17 ~-22 ~31 minecraft:air
setblock ~18 ~-22 ~31 minecraft:light_gray_concrete
fill ~19 ~-22 ~31 ~21 ~-22 ~31 minecraft:air
setblock ~22 ~-22 ~31 minecraft:smooth_quartz
fill ~23 ~-22 ~31 ~31 ~-22 ~31 minecraft:air
fill ~32 ~-22 ~31 ~36 ~-22 ~31 minecraft:sea_lantern
fill ~37 ~-22 ~31 ~45 ~-22 ~31 minecraft:air
setblock ~46 ~-22 ~31 minecraft:smooth_quartz
fill ~47 ~-22 ~31 ~49 ~-22 ~31 minecraft:air
setblock ~50 ~-22 ~31 minecraft:light_gray_concrete
fill ~51 ~-22 ~31 ~63 ~-22 ~31 minecraft:air
setblock ~64 ~-22 ~31 minecraft:light_gray_concrete
fill ~4 ~-22 ~32 ~21 ~-22 ~32 minecraft:light_gray_concrete
setblock ~22 ~-22 ~32 minecraft:smooth_quartz
fill ~23 ~-22 ~32 ~31 ~-22 ~32 minecraft:air
setblock ~32 ~-22 ~32 minecraft:sea_lantern
fill ~33 ~-22 ~32 ~35 ~-22 ~32 minecraft:glass
setblock ~36 ~-22 ~32 minecraft:sea_lantern
fill ~37 ~-22 ~32 ~45 ~-22 ~32 minecraft:air
setblock ~46 ~-22 ~32 minecraft:smooth_quartz
fill ~47 ~-22 ~32 ~64 ~-22 ~32 minecraft:light_gray_concrete
setblock ~4 ~-22 ~33 minecraft:light_gray_concrete
fill ~5 ~-22 ~33 ~21 ~-22 ~33 minecraft:air
setblock ~22 ~-22 ~33 minecraft:smooth_quartz
fill ~23 ~-22 ~33 ~31 ~-22 ~33 minecraft:air
setblock ~32 ~-22 ~33 minecraft:sea_lantern
setblock ~33 ~-22 ~33 minecraft:glass
setblock ~34 ~-22 ~33 minecraft:air
setblock ~35 ~-22 ~33 minecraft:glass
setblock ~36 ~-22 ~33 minecraft:sea_lantern
fill ~37 ~-22 ~33 ~45 ~-22 ~33 minecraft:air
setblock ~46 ~-22 ~33 minecraft:smooth_quartz
fill ~47 ~-22 ~33 ~63 ~-22 ~33 minecraft:air
setblock ~64 ~-22 ~33 minecraft:light_gray_concrete
setblock ~4 ~-22 ~34 minecraft:light_gray_concrete
fill ~5 ~-22 ~34 ~20 ~-22 ~34 minecraft:air
setblock ~21 ~-22 ~34 minecraft:smooth_quartz
fill ~22 ~-22 ~34 ~31 ~-22 ~34 minecraft:air
setblock ~32 ~-22 ~34 minecraft:sea_lantern
fill ~33 ~-22 ~34 ~35 ~-22 ~34 minecraft:glass
setblock ~36 ~-22 ~34 minecraft:sea_lantern
fill ~37 ~-22 ~34 ~46 ~-22 ~34 minecraft:air
setblock ~47 ~-22 ~34 minecraft:smooth_quartz
fill ~48 ~-22 ~34 ~63 ~-22 ~34 minecraft:air
setblock ~64 ~-22 ~34 minecraft:light_gray_concrete
setblock ~4 ~-22 ~35 minecraft:light_gray_concrete
fill ~5 ~-22 ~35 ~21 ~-22 ~35 minecraft:air
setblock ~22 ~-22 ~35 minecraft:smooth_quartz
fill ~23 ~-22 ~35 ~31 ~-22 ~35 minecraft:air
setblock ~32 ~-22 ~35 minecraft:sea_lantern
setblock ~33 ~-22 ~35 minecraft:glass
setblock ~34 ~-22 ~35 minecraft:air
setblock ~35 ~-22 ~35 minecraft:glass
setblock ~36 ~-22 ~35 minecraft:sea_lantern
fill ~37 ~-22 ~35 ~45 ~-22 ~35 minecraft:air
setblock ~46 ~-22 ~35 minecraft:smooth_quartz
fill ~47 ~-22 ~35 ~63 ~-22 ~35 minecraft:air
setblock ~64 ~-22 ~35 minecraft:light_gray_concrete
fill ~4 ~-22 ~36 ~21 ~-22 ~36 minecraft:light_gray_concrete
setblock ~22 ~-22 ~36 minecraft:smooth_quartz
fill ~23 ~-22 ~36 ~31 ~-22 ~36 minecraft:air
setblock ~32 ~-22 ~36 minecraft:sea_lantern
fill ~33 ~-22 ~36 ~35 ~-22 ~36 minecraft:glass
setblock ~36 ~-22 ~36 minecraft:sea_lantern
fill ~37 ~-22 ~36 ~45 ~-22 ~36 minecraft:air
setblock ~46 ~-22 ~36 minecraft:smooth_quartz
fill ~47 ~-22 ~36 ~64 ~-22 ~36 minecraft:light_gray_concrete
setblock ~4 ~-22 ~37 minecraft:light_gray_concrete
fill ~5 ~-22 ~37 ~17 ~-22 ~37 minecraft:air
setblock ~18 ~-22 ~37 minecraft:light_gray_concrete
fill ~19 ~-22 ~37 ~21 ~-22 ~37 minecraft:air
setblock ~22 ~-22 ~37 minecraft:smooth_quartz
fill ~23 ~-22 ~37 ~31 ~-22 ~37 minecraft:air
fill ~32 ~-22 ~37 ~36 ~-22 ~37 minecraft:sea_lantern
fill ~37 ~-22 ~37 ~45 ~-22 ~37 minecraft:air
setblock ~46 ~-22 ~37 minecraft:smooth_quartz
fill ~47 ~-22 ~37 ~49 ~-22 ~37 minecraft:air
setblock ~50 ~-22 ~37 minecraft:light_gray_concrete
fill ~51 ~-22 ~37 ~63 ~-22 ~37 minecraft:air
setblock ~64 ~-22 ~37 minecraft:light_gray_concrete
setblock ~4 ~-22 ~38 minecraft:light_gray_concrete
fill ~5 ~-22 ~38 ~17 ~-22 ~38 minecraft:air
setblock ~18 ~-22 ~38 minecraft:light_gray_concrete
fill ~19 ~-22 ~38 ~21 ~-22 ~38 minecraft:air
setblock ~22 ~-22 ~38 minecraft:smooth_quartz
setblock ~23 ~-22 ~38 minecraft:air
setblock ~24 ~-22 ~38 minecraft:chiseled_quartz_block
fill ~25 ~-22 ~38 ~43 ~-22 ~38 minecraft:air
setblock ~44 ~-22 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-22 ~38 minecraft:air
setblock ~46 ~-22 ~38 minecraft:smooth_quartz
fill ~47 ~-22 ~38 ~49 ~-22 ~38 minecraft:air
setblock ~50 ~-22 ~38 minecraft:light_gray_concrete
fill ~51 ~-22 ~38 ~63 ~-22 ~38 minecraft:air
setblock ~64 ~-22 ~38 minecraft:light_gray_concrete
setblock ~4 ~-22 ~39 minecraft:light_gray_concrete
fill ~5 ~-22 ~39 ~17 ~-22 ~39 minecraft:air
setblock ~18 ~-22 ~39 minecraft:light_gray_concrete
fill ~19 ~-22 ~39 ~21 ~-22 ~39 minecraft:air
fill ~22 ~-22 ~39 ~23 ~-22 ~39 minecraft:smooth_quartz
fill ~24 ~-22 ~39 ~44 ~-22 ~39 minecraft:air
fill ~45 ~-22 ~39 ~46 ~-22 ~39 minecraft:smooth_quartz
fill ~47 ~-22 ~39 ~49 ~-22 ~39 minecraft:air
setblock ~50 ~-22 ~39 minecraft:light_gray_concrete
fill ~51 ~-22 ~39 ~63 ~-22 ~39 minecraft:air
setblock ~64 ~-22 ~39 minecraft:light_gray_concrete
setblock ~4 ~-22 ~40 minecraft:light_gray_concrete
fill ~5 ~-22 ~40 ~17 ~-22 ~40 minecraft:air
setblock ~18 ~-22 ~40 minecraft:light_gray_concrete
fill ~19 ~-22 ~40 ~22 ~-22 ~40 minecraft:air
setblock ~23 ~-22 ~40 minecraft:smooth_quartz
fill ~24 ~-22 ~40 ~44 ~-22 ~40 minecraft:air
setblock ~45 ~-22 ~40 minecraft:smooth_quartz
fill ~46 ~-22 ~40 ~49 ~-22 ~40 minecraft:air
setblock ~50 ~-22 ~40 minecraft:light_gray_concrete
fill ~51 ~-22 ~40 ~63 ~-22 ~40 minecraft:air
setblock ~64 ~-22 ~40 minecraft:light_gray_concrete
setblock ~4 ~-22 ~41 minecraft:light_gray_concrete
fill ~5 ~-22 ~41 ~17 ~-22 ~41 minecraft:air
setblock ~18 ~-22 ~41 minecraft:light_gray_concrete
fill ~19 ~-22 ~41 ~23 ~-22 ~41 minecraft:air
setblock ~24 ~-22 ~41 minecraft:smooth_quartz
fill ~25 ~-22 ~41 ~43 ~-22 ~41 minecraft:air
setblock ~44 ~-22 ~41 minecraft:smooth_quartz
fill ~45 ~-22 ~41 ~49 ~-22 ~41 minecraft:air
setblock ~50 ~-22 ~41 minecraft:light_gray_concrete
fill ~51 ~-22 ~41 ~63 ~-22 ~41 minecraft:air
setblock ~64 ~-22 ~41 minecraft:light_gray_concrete
setblock ~4 ~-22 ~42 minecraft:light_gray_concrete
fill ~5 ~-22 ~42 ~17 ~-22 ~42 minecraft:air
setblock ~18 ~-22 ~42 minecraft:light_gray_concrete
fill ~19 ~-22 ~42 ~23 ~-22 ~42 minecraft:air
fill ~24 ~-22 ~42 ~25 ~-22 ~42 minecraft:smooth_quartz
fill ~26 ~-22 ~42 ~42 ~-22 ~42 minecraft:air
fill ~43 ~-22 ~42 ~44 ~-22 ~42 minecraft:smooth_quartz
fill ~45 ~-22 ~42 ~49 ~-22 ~42 minecraft:air
setblock ~50 ~-22 ~42 minecraft:light_gray_concrete
fill ~51 ~-22 ~42 ~63 ~-22 ~42 minecraft:air
setblock ~64 ~-22 ~42 minecraft:light_gray_concrete
setblock ~4 ~-22 ~43 minecraft:light_gray_concrete
fill ~5 ~-22 ~43 ~17 ~-22 ~43 minecraft:air
setblock ~18 ~-22 ~43 minecraft:light_gray_concrete
fill ~19 ~-22 ~43 ~24 ~-22 ~43 minecraft:air
fill ~25 ~-22 ~43 ~26 ~-22 ~43 minecraft:smooth_quartz
fill ~27 ~-22 ~43 ~41 ~-22 ~43 minecraft:air
fill ~42 ~-22 ~43 ~43 ~-22 ~43 minecraft:smooth_quartz
fill ~44 ~-22 ~43 ~49 ~-22 ~43 minecraft:air
setblock ~50 ~-22 ~43 minecraft:light_gray_concrete
fill ~51 ~-22 ~43 ~63 ~-22 ~43 minecraft:air
setblock ~64 ~-22 ~43 minecraft:light_gray_concrete
setblock ~4 ~-22 ~44 minecraft:light_gray_concrete
fill ~5 ~-22 ~44 ~17 ~-22 ~44 minecraft:air
setblock ~18 ~-22 ~44 minecraft:light_gray_concrete
fill ~19 ~-22 ~44 ~25 ~-22 ~44 minecraft:air
fill ~26 ~-22 ~44 ~27 ~-22 ~44 minecraft:smooth_quartz
fill ~28 ~-22 ~44 ~29 ~-22 ~44 minecraft:air
setblock ~30 ~-22 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-22 ~44 ~37 ~-22 ~44 minecraft:air
setblock ~38 ~-22 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-22 ~44 ~40 ~-22 ~44 minecraft:air
fill ~41 ~-22 ~44 ~42 ~-22 ~44 minecraft:smooth_quartz
fill ~43 ~-22 ~44 ~49 ~-22 ~44 minecraft:air
setblock ~50 ~-22 ~44 minecraft:light_gray_concrete
fill ~51 ~-22 ~44 ~63 ~-22 ~44 minecraft:air
setblock ~64 ~-22 ~44 minecraft:light_gray_concrete
setblock ~4 ~-22 ~45 minecraft:light_gray_concrete
fill ~5 ~-22 ~45 ~17 ~-22 ~45 minecraft:air
setblock ~18 ~-22 ~45 minecraft:light_gray_concrete
fill ~19 ~-22 ~45 ~27 ~-22 ~45 minecraft:air
fill ~28 ~-22 ~45 ~29 ~-22 ~45 minecraft:smooth_quartz
fill ~30 ~-22 ~45 ~38 ~-22 ~45 minecraft:air
fill ~39 ~-22 ~45 ~40 ~-22 ~45 minecraft:smooth_quartz
fill ~41 ~-22 ~45 ~49 ~-22 ~45 minecraft:air
setblock ~50 ~-22 ~45 minecraft:light_gray_concrete
fill ~51 ~-22 ~45 ~63 ~-22 ~45 minecraft:air
setblock ~64 ~-22 ~45 minecraft:light_gray_concrete
setblock ~4 ~-22 ~46 minecraft:light_gray_concrete
fill ~5 ~-22 ~46 ~17 ~-22 ~46 minecraft:air
setblock ~18 ~-22 ~46 minecraft:light_gray_concrete
fill ~19 ~-22 ~46 ~28 ~-22 ~46 minecraft:air
fill ~29 ~-22 ~46 ~33 ~-22 ~46 minecraft:smooth_quartz
setblock ~34 ~-22 ~46 minecraft:air
fill ~35 ~-22 ~46 ~39 ~-22 ~46 minecraft:smooth_quartz
fill ~40 ~-22 ~46 ~49 ~-22 ~46 minecraft:air
setblock ~50 ~-22 ~46 minecraft:light_gray_concrete
fill ~51 ~-22 ~46 ~63 ~-22 ~46 minecraft:air
setblock ~64 ~-22 ~46 minecraft:light_gray_concrete
setblock ~4 ~-22 ~47 minecraft:light_gray_concrete
fill ~5 ~-22 ~47 ~17 ~-22 ~47 minecraft:air
setblock ~18 ~-22 ~47 minecraft:light_gray_concrete
fill ~19 ~-22 ~47 ~31 ~-22 ~47 minecraft:air
setblock ~32 ~-22 ~47 minecraft:light_gray_concrete
setblock ~33 ~-22 ~47 minecraft:air
setblock ~34 ~-22 ~47 minecraft:smooth_quartz
setblock ~35 ~-22 ~47 minecraft:air
setblock ~36 ~-22 ~47 minecraft:light_gray_concrete
fill ~37 ~-22 ~47 ~49 ~-22 ~47 minecraft:air
setblock ~50 ~-22 ~47 minecraft:light_gray_concrete
fill ~51 ~-22 ~47 ~63 ~-22 ~47 minecraft:air
setblock ~64 ~-22 ~47 minecraft:light_gray_concrete
setblock ~4 ~-22 ~48 minecraft:light_gray_concrete
fill ~5 ~-22 ~48 ~17 ~-22 ~48 minecraft:air
setblock ~18 ~-22 ~48 minecraft:light_gray_concrete
fill ~19 ~-22 ~48 ~31 ~-22 ~48 minecraft:air
setblock ~32 ~-22 ~48 minecraft:light_gray_concrete
fill ~33 ~-22 ~48 ~35 ~-22 ~48 minecraft:air
setblock ~36 ~-22 ~48 minecraft:light_gray_concrete
fill ~37 ~-22 ~48 ~49 ~-22 ~48 minecraft:air
setblock ~50 ~-22 ~48 minecraft:light_gray_concrete
fill ~51 ~-22 ~48 ~63 ~-22 ~48 minecraft:air
setblock ~64 ~-22 ~48 minecraft:light_gray_concrete
setblock ~4 ~-22 ~49 minecraft:light_gray_concrete
fill ~5 ~-22 ~49 ~17 ~-22 ~49 minecraft:air
setblock ~18 ~-22 ~49 minecraft:light_gray_concrete
fill ~19 ~-22 ~49 ~31 ~-22 ~49 minecraft:air
setblock ~32 ~-22 ~49 minecraft:light_gray_concrete
fill ~33 ~-22 ~49 ~35 ~-22 ~49 minecraft:air
setblock ~36 ~-22 ~49 minecraft:light_gray_concrete
fill ~37 ~-22 ~49 ~49 ~-22 ~49 minecraft:air
setblock ~50 ~-22 ~49 minecraft:light_gray_concrete
fill ~51 ~-22 ~49 ~63 ~-22 ~49 minecraft:air
setblock ~64 ~-22 ~49 minecraft:light_gray_concrete
fill ~4 ~-22 ~50 ~32 ~-22 ~50 minecraft:light_gray_concrete
fill ~33 ~-22 ~50 ~35 ~-22 ~50 minecraft:air
fill ~36 ~-22 ~50 ~64 ~-22 ~50 minecraft:light_gray_concrete
setblock ~4 ~-22 ~51 minecraft:light_gray_concrete
fill ~5 ~-22 ~51 ~17 ~-22 ~51 minecraft:air
setblock ~18 ~-22 ~51 minecraft:light_gray_concrete
fill ~19 ~-22 ~51 ~31 ~-22 ~51 minecraft:air
setblock ~32 ~-22 ~51 minecraft:light_gray_concrete
fill ~33 ~-22 ~51 ~35 ~-22 ~51 minecraft:air
setblock ~36 ~-22 ~51 minecraft:light_gray_concrete
fill ~37 ~-22 ~51 ~49 ~-22 ~51 minecraft:air
setblock ~50 ~-22 ~51 minecraft:light_gray_concrete
fill ~51 ~-22 ~51 ~63 ~-22 ~51 minecraft:air
setblock ~64 ~-22 ~51 minecraft:light_gray_concrete
setblock ~4 ~-22 ~52 minecraft:light_gray_concrete
fill ~5 ~-22 ~52 ~17 ~-22 ~52 minecraft:air
setblock ~18 ~-22 ~52 minecraft:light_gray_concrete
fill ~19 ~-22 ~52 ~31 ~-22 ~52 minecraft:air
setblock ~32 ~-22 ~52 minecraft:light_gray_concrete
fill ~33 ~-22 ~52 ~35 ~-22 ~52 minecraft:air
setblock ~36 ~-22 ~52 minecraft:light_gray_concrete
fill ~37 ~-22 ~52 ~49 ~-22 ~52 minecraft:air
setblock ~50 ~-22 ~52 minecraft:light_gray_concrete
fill ~51 ~-22 ~52 ~63 ~-22 ~52 minecraft:air
setblock ~64 ~-22 ~52 minecraft:light_gray_concrete
setblock ~4 ~-22 ~53 minecraft:light_gray_concrete
fill ~5 ~-22 ~53 ~17 ~-22 ~53 minecraft:air
setblock ~18 ~-22 ~53 minecraft:light_gray_concrete
fill ~19 ~-22 ~53 ~31 ~-22 ~53 minecraft:air
setblock ~32 ~-22 ~53 minecraft:light_gray_concrete
fill ~33 ~-22 ~53 ~35 ~-22 ~53 minecraft:air
setblock ~36 ~-22 ~53 minecraft:light_gray_concrete
fill ~37 ~-22 ~53 ~49 ~-22 ~53 minecraft:air
setblock ~50 ~-22 ~53 minecraft:light_gray_concrete
fill ~51 ~-22 ~53 ~63 ~-22 ~53 minecraft:air
setblock ~64 ~-22 ~53 minecraft:light_gray_concrete
setblock ~4 ~-22 ~54 minecraft:light_gray_concrete
fill ~5 ~-22 ~54 ~17 ~-22 ~54 minecraft:air
setblock ~18 ~-22 ~54 minecraft:light_gray_concrete
fill ~19 ~-22 ~54 ~31 ~-22 ~54 minecraft:air
setblock ~32 ~-22 ~54 minecraft:light_gray_concrete
fill ~33 ~-22 ~54 ~35 ~-22 ~54 minecraft:air
setblock ~36 ~-22 ~54 minecraft:light_gray_concrete
fill ~37 ~-22 ~54 ~49 ~-22 ~54 minecraft:air
setblock ~50 ~-22 ~54 minecraft:light_gray_concrete
fill ~51 ~-22 ~54 ~63 ~-22 ~54 minecraft:air
setblock ~64 ~-22 ~54 minecraft:light_gray_concrete
setblock ~4 ~-22 ~55 minecraft:light_gray_concrete
fill ~5 ~-22 ~55 ~17 ~-22 ~55 minecraft:air
setblock ~18 ~-22 ~55 minecraft:light_gray_concrete
fill ~19 ~-22 ~55 ~31 ~-22 ~55 minecraft:air
setblock ~32 ~-22 ~55 minecraft:light_gray_concrete
fill ~33 ~-22 ~55 ~35 ~-22 ~55 minecraft:air
setblock ~36 ~-22 ~55 minecraft:light_gray_concrete
fill ~37 ~-22 ~55 ~49 ~-22 ~55 minecraft:air
setblock ~50 ~-22 ~55 minecraft:light_gray_concrete
fill ~51 ~-22 ~55 ~63 ~-22 ~55 minecraft:air
setblock ~64 ~-22 ~55 minecraft:light_gray_concrete
setblock ~4 ~-22 ~56 minecraft:light_gray_concrete
fill ~5 ~-22 ~56 ~17 ~-22 ~56 minecraft:air
setblock ~18 ~-22 ~56 minecraft:light_gray_concrete
fill ~19 ~-22 ~56 ~31 ~-22 ~56 minecraft:air
setblock ~32 ~-22 ~56 minecraft:light_gray_concrete
fill ~33 ~-22 ~56 ~35 ~-22 ~56 minecraft:air
setblock ~36 ~-22 ~56 minecraft:light_gray_concrete
fill ~37 ~-22 ~56 ~49 ~-22 ~56 minecraft:air
setblock ~50 ~-22 ~56 minecraft:light_gray_concrete
fill ~51 ~-22 ~56 ~63 ~-22 ~56 minecraft:air
setblock ~64 ~-22 ~56 minecraft:light_gray_concrete
setblock ~4 ~-22 ~57 minecraft:light_gray_concrete
fill ~5 ~-22 ~57 ~17 ~-22 ~57 minecraft:air
setblock ~18 ~-22 ~57 minecraft:light_gray_concrete
fill ~19 ~-22 ~57 ~31 ~-22 ~57 minecraft:air
setblock ~32 ~-22 ~57 minecraft:light_gray_concrete
fill ~33 ~-22 ~57 ~35 ~-22 ~57 minecraft:air
setblock ~36 ~-22 ~57 minecraft:light_gray_concrete
fill ~37 ~-22 ~57 ~49 ~-22 ~57 minecraft:air
setblock ~50 ~-22 ~57 minecraft:light_gray_concrete
fill ~51 ~-22 ~57 ~63 ~-22 ~57 minecraft:air
setblock ~64 ~-22 ~57 minecraft:light_gray_concrete
setblock ~4 ~-22 ~58 minecraft:light_gray_concrete
fill ~5 ~-22 ~58 ~17 ~-22 ~58 minecraft:air
setblock ~18 ~-22 ~58 minecraft:light_gray_concrete
fill ~19 ~-22 ~58 ~31 ~-22 ~58 minecraft:air
setblock ~32 ~-22 ~58 minecraft:light_gray_concrete
fill ~33 ~-22 ~58 ~35 ~-22 ~58 minecraft:air
setblock ~36 ~-22 ~58 minecraft:light_gray_concrete
fill ~37 ~-22 ~58 ~49 ~-22 ~58 minecraft:air
setblock ~50 ~-22 ~58 minecraft:light_gray_concrete
fill ~51 ~-22 ~58 ~63 ~-22 ~58 minecraft:air
setblock ~64 ~-22 ~58 minecraft:light_gray_concrete
setblock ~4 ~-22 ~59 minecraft:light_gray_concrete
fill ~5 ~-22 ~59 ~17 ~-22 ~59 minecraft:air
setblock ~18 ~-22 ~59 minecraft:light_gray_concrete
fill ~19 ~-22 ~59 ~31 ~-22 ~59 minecraft:air
setblock ~32 ~-22 ~59 minecraft:light_gray_concrete
fill ~33 ~-22 ~59 ~35 ~-22 ~59 minecraft:air
setblock ~36 ~-22 ~59 minecraft:light_gray_concrete
fill ~37 ~-22 ~59 ~49 ~-22 ~59 minecraft:air
setblock ~50 ~-22 ~59 minecraft:light_gray_concrete
fill ~51 ~-22 ~59 ~63 ~-22 ~59 minecraft:air
setblock ~64 ~-22 ~59 minecraft:light_gray_concrete
setblock ~4 ~-22 ~60 minecraft:light_gray_concrete
fill ~5 ~-22 ~60 ~17 ~-22 ~60 minecraft:air
setblock ~18 ~-22 ~60 minecraft:light_gray_concrete
fill ~19 ~-22 ~60 ~31 ~-22 ~60 minecraft:air
setblock ~32 ~-22 ~60 minecraft:light_gray_concrete
fill ~33 ~-22 ~60 ~35 ~-22 ~60 minecraft:air
setblock ~36 ~-22 ~60 minecraft:light_gray_concrete
fill ~37 ~-22 ~60 ~49 ~-22 ~60 minecraft:air
setblock ~50 ~-22 ~60 minecraft:light_gray_concrete
fill ~51 ~-22 ~60 ~63 ~-22 ~60 minecraft:air
setblock ~64 ~-22 ~60 minecraft:light_gray_concrete
setblock ~4 ~-22 ~61 minecraft:light_gray_concrete
fill ~5 ~-22 ~61 ~17 ~-22 ~61 minecraft:air
setblock ~18 ~-22 ~61 minecraft:light_gray_concrete
fill ~19 ~-22 ~61 ~31 ~-22 ~61 minecraft:air
setblock ~32 ~-22 ~61 minecraft:light_gray_concrete
fill ~33 ~-22 ~61 ~35 ~-22 ~61 minecraft:air
setblock ~36 ~-22 ~61 minecraft:light_gray_concrete
fill ~37 ~-22 ~61 ~49 ~-22 ~61 minecraft:air
setblock ~50 ~-22 ~61 minecraft:light_gray_concrete
fill ~51 ~-22 ~61 ~63 ~-22 ~61 minecraft:air
setblock ~64 ~-22 ~61 minecraft:light_gray_concrete
setblock ~4 ~-22 ~62 minecraft:light_gray_concrete
fill ~5 ~-22 ~62 ~17 ~-22 ~62 minecraft:air
setblock ~18 ~-22 ~62 minecraft:light_gray_concrete
fill ~19 ~-22 ~62 ~31 ~-22 ~62 minecraft:air
setblock ~32 ~-22 ~62 minecraft:light_gray_concrete
fill ~33 ~-22 ~62 ~35 ~-22 ~62 minecraft:air
setblock ~36 ~-22 ~62 minecraft:light_gray_concrete
fill ~37 ~-22 ~62 ~49 ~-22 ~62 minecraft:air
setblock ~50 ~-22 ~62 minecraft:light_gray_concrete
fill ~51 ~-22 ~62 ~63 ~-22 ~62 minecraft:air
setblock ~64 ~-22 ~62 minecraft:light_gray_concrete
setblock ~4 ~-22 ~63 minecraft:light_gray_concrete
fill ~5 ~-22 ~63 ~17 ~-22 ~63 minecraft:air
setblock ~18 ~-22 ~63 minecraft:light_gray_concrete
fill ~19 ~-22 ~63 ~31 ~-22 ~63 minecraft:air
setblock ~32 ~-22 ~63 minecraft:light_gray_concrete
fill ~33 ~-22 ~63 ~35 ~-22 ~63 minecraft:air
setblock ~36 ~-22 ~63 minecraft:light_gray_concrete
fill ~37 ~-22 ~63 ~49 ~-22 ~63 minecraft:air
setblock ~50 ~-22 ~63 minecraft:light_gray_concrete
fill ~51 ~-22 ~63 ~63 ~-22 ~63 minecraft:air
setblock ~64 ~-22 ~63 minecraft:light_gray_concrete
fill ~4 ~-22 ~64 ~64 ~-22 ~64 minecraft:light_gray_concrete
fill ~32 ~-22 ~66 ~36 ~-22 ~66 minecraft:polished_andesite
setblock ~32 ~-22 ~67 minecraft:polished_andesite
fill ~33 ~-22 ~67 ~35 ~-22 ~67 minecraft:air
setblock ~36 ~-22 ~67 minecraft:polished_andesite
setblock ~32 ~-22 ~68 minecraft:polished_andesite
setblock ~33 ~-22 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-22 ~68 minecraft:quartz_pillar
setblock ~35 ~-22 ~68 minecraft:air
setblock ~36 ~-22 ~68 minecraft:polished_andesite
setblock ~32 ~-22 ~69 minecraft:polished_andesite
fill ~33 ~-22 ~69 ~35 ~-22 ~69 minecraft:air
setblock ~36 ~-22 ~69 minecraft:polished_andesite
fill ~32 ~-22 ~70 ~36 ~-22 ~70 minecraft:polished_andesite
fill ~4 ~-21 ~4 ~64 ~-21 ~4 minecraft:smooth_stone
fill ~4 ~-21 ~5 ~64 ~-21 ~5 minecraft:smooth_stone
fill ~4 ~-21 ~6 ~5 ~-21 ~6 minecraft:smooth_stone
setblock ~6 ~-21 ~6 minecraft:sea_lantern
fill ~7 ~-21 ~6 ~9 ~-21 ~6 minecraft:smooth_stone
setblock ~10 ~-21 ~6 minecraft:sea_lantern
fill ~11 ~-21 ~6 ~13 ~-21 ~6 minecraft:smooth_stone
setblock ~14 ~-21 ~6 minecraft:sea_lantern
fill ~15 ~-21 ~6 ~21 ~-21 ~6 minecraft:smooth_stone
setblock ~22 ~-21 ~6 minecraft:sea_lantern
fill ~23 ~-21 ~6 ~25 ~-21 ~6 minecraft:smooth_stone
setblock ~26 ~-21 ~6 minecraft:sea_lantern
fill ~27 ~-21 ~6 ~29 ~-21 ~6 minecraft:smooth_stone
setblock ~30 ~-21 ~6 minecraft:sea_lantern
fill ~31 ~-21 ~6 ~33 ~-21 ~6 minecraft:smooth_stone
setblock ~34 ~-21 ~6 minecraft:sea_lantern
fill ~35 ~-21 ~6 ~37 ~-21 ~6 minecraft:smooth_stone
setblock ~38 ~-21 ~6 minecraft:sea_lantern
fill ~39 ~-21 ~6 ~41 ~-21 ~6 minecraft:smooth_stone
setblock ~42 ~-21 ~6 minecraft:sea_lantern
fill ~43 ~-21 ~6 ~45 ~-21 ~6 minecraft:smooth_stone
setblock ~46 ~-21 ~6 minecraft:sea_lantern
fill ~47 ~-21 ~6 ~53 ~-21 ~6 minecraft:smooth_stone
setblock ~54 ~-21 ~6 minecraft:sea_lantern
fill ~55 ~-21 ~6 ~57 ~-21 ~6 minecraft:smooth_stone
setblock ~58 ~-21 ~6 minecraft:sea_lantern
fill ~59 ~-21 ~6 ~61 ~-21 ~6 minecraft:smooth_stone
setblock ~62 ~-21 ~6 minecraft:sea_lantern
fill ~63 ~-21 ~6 ~64 ~-21 ~6 minecraft:smooth_stone
fill ~4 ~-21 ~7 ~51 ~-21 ~7 minecraft:smooth_stone
setblock ~52 ~-21 ~7 minecraft:sea_lantern
fill ~53 ~-21 ~7 ~54 ~-21 ~7 minecraft:smooth_stone
setblock ~55 ~-21 ~7 minecraft:sea_lantern
fill ~56 ~-21 ~7 ~57 ~-21 ~7 minecraft:smooth_stone
setblock ~58 ~-21 ~7 minecraft:sea_lantern
fill ~59 ~-21 ~7 ~60 ~-21 ~7 minecraft:smooth_stone
setblock ~61 ~-21 ~7 minecraft:sea_lantern
fill ~62 ~-21 ~7 ~64 ~-21 ~7 minecraft:smooth_stone
fill ~4 ~-21 ~8 ~64 ~-21 ~8 minecraft:smooth_stone
fill ~4 ~-21 ~9 ~64 ~-21 ~9 minecraft:smooth_stone
fill ~4 ~-21 ~10 ~5 ~-21 ~10 minecraft:smooth_stone
setblock ~6 ~-21 ~10 minecraft:sea_lantern
fill ~7 ~-21 ~10 ~9 ~-21 ~10 minecraft:smooth_stone
setblock ~10 ~-21 ~10 minecraft:sea_lantern
fill ~11 ~-21 ~10 ~13 ~-21 ~10 minecraft:smooth_stone
setblock ~14 ~-21 ~10 minecraft:sea_lantern
fill ~15 ~-21 ~10 ~21 ~-21 ~10 minecraft:smooth_stone
setblock ~22 ~-21 ~10 minecraft:sea_lantern
fill ~23 ~-21 ~10 ~25 ~-21 ~10 minecraft:smooth_stone
setblock ~26 ~-21 ~10 minecraft:sea_lantern
fill ~27 ~-21 ~10 ~29 ~-21 ~10 minecraft:smooth_stone
setblock ~30 ~-21 ~10 minecraft:sea_lantern
fill ~31 ~-21 ~10 ~33 ~-21 ~10 minecraft:smooth_stone
setblock ~34 ~-21 ~10 minecraft:sea_lantern
fill ~35 ~-21 ~10 ~37 ~-21 ~10 minecraft:smooth_stone
setblock ~38 ~-21 ~10 minecraft:sea_lantern
fill ~39 ~-21 ~10 ~41 ~-21 ~10 minecraft:smooth_stone
setblock ~42 ~-21 ~10 minecraft:sea_lantern
fill ~43 ~-21 ~10 ~45 ~-21 ~10 minecraft:smooth_stone
setblock ~46 ~-21 ~10 minecraft:sea_lantern
fill ~47 ~-21 ~10 ~51 ~-21 ~10 minecraft:smooth_stone
setblock ~52 ~-21 ~10 minecraft:sea_lantern
setblock ~53 ~-21 ~10 minecraft:smooth_stone
fill ~54 ~-21 ~10 ~55 ~-21 ~10 minecraft:sea_lantern
fill ~56 ~-21 ~10 ~57 ~-21 ~10 minecraft:smooth_stone
setblock ~58 ~-21 ~10 minecraft:sea_lantern
fill ~59 ~-21 ~10 ~60 ~-21 ~10 minecraft:smooth_stone
fill ~61 ~-21 ~10 ~62 ~-21 ~10 minecraft:sea_lantern
fill ~63 ~-21 ~10 ~64 ~-21 ~10 minecraft:smooth_stone
fill ~4 ~-21 ~11 ~64 ~-21 ~11 minecraft:smooth_stone
fill ~4 ~-21 ~12 ~64 ~-21 ~12 minecraft:smooth_stone
fill ~4 ~-21 ~13 ~51 ~-21 ~13 minecraft:smooth_stone
setblock ~52 ~-21 ~13 minecraft:sea_lantern
fill ~53 ~-21 ~13 ~54 ~-21 ~13 minecraft:smooth_stone
setblock ~55 ~-21 ~13 minecraft:sea_lantern
fill ~56 ~-21 ~13 ~57 ~-21 ~13 minecraft:smooth_stone
setblock ~58 ~-21 ~13 minecraft:sea_lantern
fill ~59 ~-21 ~13 ~60 ~-21 ~13 minecraft:smooth_stone
setblock ~61 ~-21 ~13 minecraft:sea_lantern
fill ~62 ~-21 ~13 ~64 ~-21 ~13 minecraft:smooth_stone
fill ~4 ~-21 ~14 ~5 ~-21 ~14 minecraft:smooth_stone
setblock ~6 ~-21 ~14 minecraft:sea_lantern
fill ~7 ~-21 ~14 ~9 ~-21 ~14 minecraft:smooth_stone
setblock ~10 ~-21 ~14 minecraft:sea_lantern
fill ~11 ~-21 ~14 ~13 ~-21 ~14 minecraft:smooth_stone
setblock ~14 ~-21 ~14 minecraft:sea_lantern
fill ~15 ~-21 ~14 ~21 ~-21 ~14 minecraft:smooth_stone
setblock ~22 ~-21 ~14 minecraft:sea_lantern
fill ~23 ~-21 ~14 ~25 ~-21 ~14 minecraft:smooth_stone
setblock ~26 ~-21 ~14 minecraft:sea_lantern
fill ~27 ~-21 ~14 ~29 ~-21 ~14 minecraft:smooth_stone
setblock ~30 ~-21 ~14 minecraft:sea_lantern
fill ~31 ~-21 ~14 ~33 ~-21 ~14 minecraft:smooth_stone
setblock ~34 ~-21 ~14 minecraft:sea_lantern
fill ~35 ~-21 ~14 ~37 ~-21 ~14 minecraft:smooth_stone
setblock ~38 ~-21 ~14 minecraft:sea_lantern
fill ~39 ~-21 ~14 ~41 ~-21 ~14 minecraft:smooth_stone
setblock ~42 ~-21 ~14 minecraft:sea_lantern
fill ~43 ~-21 ~14 ~45 ~-21 ~14 minecraft:smooth_stone
setblock ~46 ~-21 ~14 minecraft:sea_lantern
fill ~47 ~-21 ~14 ~53 ~-21 ~14 minecraft:smooth_stone
setblock ~54 ~-21 ~14 minecraft:sea_lantern
fill ~55 ~-21 ~14 ~57 ~-21 ~14 minecraft:smooth_stone
setblock ~58 ~-21 ~14 minecraft:sea_lantern
fill ~59 ~-21 ~14 ~61 ~-21 ~14 minecraft:smooth_stone
setblock ~62 ~-21 ~14 minecraft:sea_lantern
fill ~63 ~-21 ~14 ~64 ~-21 ~14 minecraft:smooth_stone
fill ~4 ~-21 ~15 ~64 ~-21 ~15 minecraft:smooth_stone
fill ~4 ~-21 ~16 ~51 ~-21 ~16 minecraft:smooth_stone
setblock ~52 ~-21 ~16 minecraft:sea_lantern
fill ~53 ~-21 ~16 ~54 ~-21 ~16 minecraft:smooth_stone
setblock ~55 ~-21 ~16 minecraft:sea_lantern
fill ~56 ~-21 ~16 ~57 ~-21 ~16 minecraft:smooth_stone
setblock ~58 ~-21 ~16 minecraft:sea_lantern
fill ~59 ~-21 ~16 ~60 ~-21 ~16 minecraft:smooth_stone
setblock ~61 ~-21 ~16 minecraft:sea_lantern
fill ~62 ~-21 ~16 ~64 ~-21 ~16 minecraft:smooth_stone
fill ~4 ~-21 ~17 ~64 ~-21 ~17 minecraft:smooth_stone
fill ~4 ~-21 ~18 ~33 ~-21 ~18 minecraft:smooth_stone
setblock ~34 ~-21 ~18 minecraft:sea_lantern
fill ~35 ~-21 ~18 ~64 ~-21 ~18 minecraft:smooth_stone
fill ~4 ~-21 ~19 ~36 ~-21 ~19 minecraft:smooth_stone
setblock ~37 ~-21 ~19 minecraft:sea_lantern
fill ~38 ~-21 ~19 ~39 ~-21 ~19 minecraft:smooth_stone
setblock ~40 ~-21 ~19 minecraft:sea_lantern
fill ~41 ~-21 ~19 ~42 ~-21 ~19 minecraft:smooth_stone
setblock ~43 ~-21 ~19 minecraft:sea_lantern
fill ~44 ~-21 ~19 ~45 ~-21 ~19 minecraft:smooth_stone
setblock ~46 ~-21 ~19 minecraft:sea_lantern
fill ~47 ~-21 ~19 ~48 ~-21 ~19 minecraft:smooth_stone
setblock ~49 ~-21 ~19 minecraft:sea_lantern
fill ~50 ~-21 ~19 ~64 ~-21 ~19 minecraft:smooth_stone
fill ~4 ~-21 ~20 ~64 ~-21 ~20 minecraft:smooth_stone
fill ~4 ~-21 ~21 ~33 ~-21 ~21 minecraft:smooth_stone
setblock ~34 ~-21 ~21 minecraft:smooth_quartz
fill ~35 ~-21 ~21 ~64 ~-21 ~21 minecraft:smooth_stone
fill ~4 ~-21 ~22 ~5 ~-21 ~22 minecraft:smooth_stone
setblock ~6 ~-21 ~22 minecraft:sea_lantern
fill ~7 ~-21 ~22 ~9 ~-21 ~22 minecraft:smooth_stone
setblock ~10 ~-21 ~22 minecraft:sea_lantern
fill ~11 ~-21 ~22 ~13 ~-21 ~22 minecraft:smooth_stone
setblock ~14 ~-21 ~22 minecraft:sea_lantern
fill ~15 ~-21 ~22 ~21 ~-21 ~22 minecraft:smooth_stone
setblock ~22 ~-21 ~22 minecraft:sea_lantern
fill ~23 ~-21 ~22 ~25 ~-21 ~22 minecraft:smooth_stone
setblock ~26 ~-21 ~22 minecraft:sea_lantern
fill ~27 ~-21 ~22 ~28 ~-21 ~22 minecraft:smooth_stone
fill ~29 ~-21 ~22 ~39 ~-21 ~22 minecraft:smooth_quartz
setblock ~40 ~-21 ~22 minecraft:sea_lantern
setblock ~41 ~-21 ~22 minecraft:smooth_stone
fill ~42 ~-21 ~22 ~43 ~-21 ~22 minecraft:sea_lantern
fill ~44 ~-21 ~22 ~45 ~-21 ~22 minecraft:smooth_stone
setblock ~46 ~-21 ~22 minecraft:sea_lantern
fill ~47 ~-21 ~22 ~48 ~-21 ~22 minecraft:smooth_stone
setblock ~49 ~-21 ~22 minecraft:sea_lantern
fill ~50 ~-21 ~22 ~53 ~-21 ~22 minecraft:smooth_stone
setblock ~54 ~-21 ~22 minecraft:sea_lantern
fill ~55 ~-21 ~22 ~57 ~-21 ~22 minecraft:smooth_stone
setblock ~58 ~-21 ~22 minecraft:sea_lantern
fill ~59 ~-21 ~22 ~61 ~-21 ~22 minecraft:smooth_stone
setblock ~62 ~-21 ~22 minecraft:sea_lantern
fill ~63 ~-21 ~22 ~64 ~-21 ~22 minecraft:smooth_stone
fill ~4 ~-21 ~23 ~27 ~-21 ~23 minecraft:smooth_stone
fill ~28 ~-21 ~23 ~40 ~-21 ~23 minecraft:smooth_quartz
fill ~41 ~-21 ~23 ~64 ~-21 ~23 minecraft:smooth_stone
fill ~4 ~-21 ~24 ~25 ~-21 ~24 minecraft:smooth_stone
fill ~26 ~-21 ~24 ~42 ~-21 ~24 minecraft:smooth_quartz
fill ~43 ~-21 ~24 ~64 ~-21 ~24 minecraft:smooth_stone
fill ~4 ~-21 ~25 ~24 ~-21 ~25 minecraft:smooth_stone
fill ~25 ~-21 ~25 ~31 ~-21 ~25 minecraft:smooth_quartz
fill ~32 ~-21 ~25 ~36 ~-21 ~25 minecraft:sea_lantern
fill ~37 ~-21 ~25 ~43 ~-21 ~25 minecraft:smooth_quartz
fill ~44 ~-21 ~25 ~45 ~-21 ~25 minecraft:smooth_stone
setblock ~46 ~-21 ~25 minecraft:sea_lantern
fill ~47 ~-21 ~25 ~48 ~-21 ~25 minecraft:smooth_stone
setblock ~49 ~-21 ~25 minecraft:sea_lantern
fill ~50 ~-21 ~25 ~64 ~-21 ~25 minecraft:smooth_stone
fill ~4 ~-21 ~26 ~5 ~-21 ~26 minecraft:smooth_stone
setblock ~6 ~-21 ~26 minecraft:sea_lantern
fill ~7 ~-21 ~26 ~9 ~-21 ~26 minecraft:smooth_stone
setblock ~10 ~-21 ~26 minecraft:sea_lantern
fill ~11 ~-21 ~26 ~13 ~-21 ~26 minecraft:smooth_stone
setblock ~14 ~-21 ~26 minecraft:sea_lantern
fill ~15 ~-21 ~26 ~21 ~-21 ~26 minecraft:smooth_stone
setblock ~22 ~-21 ~26 minecraft:sea_lantern
setblock ~23 ~-21 ~26 minecraft:smooth_stone
fill ~24 ~-21 ~26 ~29 ~-21 ~26 minecraft:smooth_quartz
fill ~30 ~-21 ~26 ~31 ~-21 ~26 minecraft:sea_lantern
fill ~32 ~-21 ~26 ~36 ~-21 ~26 minecraft:air
fill ~37 ~-21 ~26 ~38 ~-21 ~26 minecraft:sea_lantern
fill ~39 ~-21 ~26 ~44 ~-21 ~26 minecraft:smooth_quartz
setblock ~45 ~-21 ~26 minecraft:smooth_stone
setblock ~46 ~-21 ~26 minecraft:sea_lantern
fill ~47 ~-21 ~26 ~53 ~-21 ~26 minecraft:smooth_stone
setblock ~54 ~-21 ~26 minecraft:sea_lantern
fill ~55 ~-21 ~26 ~57 ~-21 ~26 minecraft:smooth_stone
setblock ~58 ~-21 ~26 minecraft:sea_lantern
fill ~59 ~-21 ~26 ~61 ~-21 ~26 minecraft:smooth_stone
setblock ~62 ~-21 ~26 minecraft:sea_lantern
fill ~63 ~-21 ~26 ~64 ~-21 ~26 minecraft:smooth_stone
fill ~4 ~-21 ~27 ~23 ~-21 ~27 minecraft:smooth_stone
fill ~24 ~-21 ~27 ~27 ~-21 ~27 minecraft:smooth_quartz
fill ~28 ~-21 ~27 ~29 ~-21 ~27 minecraft:sea_lantern
fill ~30 ~-21 ~27 ~38 ~-21 ~27 minecraft:air
fill ~39 ~-21 ~27 ~40 ~-21 ~27 minecraft:sea_lantern
fill ~41 ~-21 ~27 ~44 ~-21 ~27 minecraft:smooth_quartz
fill ~45 ~-21 ~27 ~64 ~-21 ~27 minecraft:smooth_stone
fill ~4 ~-21 ~28 ~22 ~-21 ~28 minecraft:smooth_stone
fill ~23 ~-21 ~28 ~26 ~-21 ~28 minecraft:smooth_quartz
setblock ~27 ~-21 ~28 minecraft:sea_lantern
fill ~28 ~-21 ~28 ~40 ~-21 ~28 minecraft:air
setblock ~41 ~-21 ~28 minecraft:sea_lantern
fill ~42 ~-21 ~28 ~45 ~-21 ~28 minecraft:smooth_quartz
setblock ~46 ~-21 ~28 minecraft:sea_lantern
fill ~47 ~-21 ~28 ~48 ~-21 ~28 minecraft:smooth_stone
setblock ~49 ~-21 ~28 minecraft:sea_lantern
fill ~50 ~-21 ~28 ~64 ~-21 ~28 minecraft:smooth_stone
fill ~4 ~-21 ~29 ~21 ~-21 ~29 minecraft:smooth_stone
fill ~22 ~-21 ~29 ~26 ~-21 ~29 minecraft:smooth_quartz
setblock ~27 ~-21 ~29 minecraft:sea_lantern
fill ~28 ~-21 ~29 ~40 ~-21 ~29 minecraft:air
setblock ~41 ~-21 ~29 minecraft:sea_lantern
fill ~42 ~-21 ~29 ~46 ~-21 ~29 minecraft:smooth_quartz
fill ~47 ~-21 ~29 ~64 ~-21 ~29 minecraft:smooth_stone
fill ~4 ~-21 ~30 ~5 ~-21 ~30 minecraft:smooth_stone
setblock ~6 ~-21 ~30 minecraft:sea_lantern
fill ~7 ~-21 ~30 ~9 ~-21 ~30 minecraft:smooth_stone
setblock ~10 ~-21 ~30 minecraft:sea_lantern
fill ~11 ~-21 ~30 ~13 ~-21 ~30 minecraft:smooth_stone
setblock ~14 ~-21 ~30 minecraft:sea_lantern
fill ~15 ~-21 ~30 ~21 ~-21 ~30 minecraft:smooth_stone
fill ~22 ~-21 ~30 ~25 ~-21 ~30 minecraft:smooth_quartz
setblock ~26 ~-21 ~30 minecraft:sea_lantern
fill ~27 ~-21 ~30 ~41 ~-21 ~30 minecraft:air
setblock ~42 ~-21 ~30 minecraft:sea_lantern
fill ~43 ~-21 ~30 ~46 ~-21 ~30 minecraft:smooth_quartz
fill ~47 ~-21 ~30 ~53 ~-21 ~30 minecraft:smooth_stone
setblock ~54 ~-21 ~30 minecraft:sea_lantern
fill ~55 ~-21 ~30 ~57 ~-21 ~30 minecraft:smooth_stone
setblock ~58 ~-21 ~30 minecraft:sea_lantern
fill ~59 ~-21 ~30 ~61 ~-21 ~30 minecraft:smooth_stone
setblock ~62 ~-21 ~30 minecraft:sea_lantern
fill ~63 ~-21 ~30 ~64 ~-21 ~30 minecraft:smooth_stone
fill ~4 ~-21 ~31 ~21 ~-21 ~31 minecraft:smooth_stone
fill ~22 ~-21 ~31 ~25 ~-21 ~31 minecraft:smooth_quartz
setblock ~26 ~-21 ~31 minecraft:sea_lantern
fill ~27 ~-21 ~31 ~41 ~-21 ~31 minecraft:air
setblock ~42 ~-21 ~31 minecraft:sea_lantern
fill ~43 ~-21 ~31 ~46 ~-21 ~31 minecraft:smooth_quartz
fill ~47 ~-21 ~31 ~48 ~-21 ~31 minecraft:smooth_stone
setblock ~49 ~-21 ~31 minecraft:sea_lantern
fill ~50 ~-21 ~31 ~64 ~-21 ~31 minecraft:smooth_stone
fill ~4 ~-21 ~32 ~21 ~-21 ~32 minecraft:smooth_stone
fill ~22 ~-21 ~32 ~24 ~-21 ~32 minecraft:smooth_quartz
setblock ~25 ~-21 ~32 minecraft:sea_lantern
fill ~26 ~-21 ~32 ~32 ~-21 ~32 minecraft:air
fill ~33 ~-21 ~32 ~35 ~-21 ~32 minecraft:glass
fill ~36 ~-21 ~32 ~42 ~-21 ~32 minecraft:air
setblock ~43 ~-21 ~32 minecraft:sea_lantern
fill ~44 ~-21 ~32 ~46 ~-21 ~32 minecraft:smooth_quartz
fill ~47 ~-21 ~32 ~64 ~-21 ~32 minecraft:smooth_stone
fill ~4 ~-21 ~33 ~21 ~-21 ~33 minecraft:smooth_stone
fill ~22 ~-21 ~33 ~24 ~-21 ~33 minecraft:smooth_quartz
setblock ~25 ~-21 ~33 minecraft:sea_lantern
fill ~26 ~-21 ~33 ~32 ~-21 ~33 minecraft:air
setblock ~33 ~-21 ~33 minecraft:glass
setblock ~34 ~-21 ~33 minecraft:air
setblock ~35 ~-21 ~33 minecraft:glass
fill ~36 ~-21 ~33 ~42 ~-21 ~33 minecraft:air
setblock ~43 ~-21 ~33 minecraft:sea_lantern
fill ~44 ~-21 ~33 ~46 ~-21 ~33 minecraft:smooth_quartz
fill ~47 ~-21 ~33 ~64 ~-21 ~33 minecraft:smooth_stone
fill ~4 ~-21 ~34 ~5 ~-21 ~34 minecraft:smooth_stone
setblock ~6 ~-21 ~34 minecraft:sea_lantern
fill ~7 ~-21 ~34 ~9 ~-21 ~34 minecraft:smooth_stone
setblock ~10 ~-21 ~34 minecraft:sea_lantern
fill ~11 ~-21 ~34 ~13 ~-21 ~34 minecraft:smooth_stone
setblock ~14 ~-21 ~34 minecraft:sea_lantern
fill ~15 ~-21 ~34 ~17 ~-21 ~34 minecraft:smooth_stone
setblock ~18 ~-21 ~34 minecraft:sea_lantern
fill ~19 ~-21 ~34 ~20 ~-21 ~34 minecraft:smooth_stone
fill ~21 ~-21 ~34 ~24 ~-21 ~34 minecraft:smooth_quartz
setblock ~25 ~-21 ~34 minecraft:sea_lantern
fill ~26 ~-21 ~34 ~32 ~-21 ~34 minecraft:air
fill ~33 ~-21 ~34 ~35 ~-21 ~34 minecraft:glass
fill ~36 ~-21 ~34 ~42 ~-21 ~34 minecraft:air
setblock ~43 ~-21 ~34 minecraft:sea_lantern
fill ~44 ~-21 ~34 ~47 ~-21 ~34 minecraft:smooth_quartz
fill ~48 ~-21 ~34 ~49 ~-21 ~34 minecraft:smooth_stone
setblock ~50 ~-21 ~34 minecraft:sea_lantern
fill ~51 ~-21 ~34 ~53 ~-21 ~34 minecraft:smooth_stone
setblock ~54 ~-21 ~34 minecraft:sea_lantern
fill ~55 ~-21 ~34 ~57 ~-21 ~34 minecraft:smooth_stone
setblock ~58 ~-21 ~34 minecraft:sea_lantern
fill ~59 ~-21 ~34 ~61 ~-21 ~34 minecraft:smooth_stone
setblock ~62 ~-21 ~34 minecraft:sea_lantern
fill ~63 ~-21 ~34 ~64 ~-21 ~34 minecraft:smooth_stone
fill ~4 ~-21 ~35 ~21 ~-21 ~35 minecraft:smooth_stone
fill ~22 ~-21 ~35 ~24 ~-21 ~35 minecraft:smooth_quartz
setblock ~25 ~-21 ~35 minecraft:sea_lantern
fill ~26 ~-21 ~35 ~32 ~-21 ~35 minecraft:air
setblock ~33 ~-21 ~35 minecraft:glass
setblock ~34 ~-21 ~35 minecraft:air
setblock ~35 ~-21 ~35 minecraft:glass
fill ~36 ~-21 ~35 ~42 ~-21 ~35 minecraft:air
setblock ~43 ~-21 ~35 minecraft:sea_lantern
fill ~44 ~-21 ~35 ~46 ~-21 ~35 minecraft:smooth_quartz
fill ~47 ~-21 ~35 ~64 ~-21 ~35 minecraft:smooth_stone
fill ~4 ~-21 ~36 ~21 ~-21 ~36 minecraft:smooth_stone
fill ~22 ~-21 ~36 ~24 ~-21 ~36 minecraft:smooth_quartz
setblock ~25 ~-21 ~36 minecraft:sea_lantern
fill ~26 ~-21 ~36 ~32 ~-21 ~36 minecraft:air
fill ~33 ~-21 ~36 ~35 ~-21 ~36 minecraft:glass
fill ~36 ~-21 ~36 ~42 ~-21 ~36 minecraft:air
setblock ~43 ~-21 ~36 minecraft:sea_lantern
fill ~44 ~-21 ~36 ~46 ~-21 ~36 minecraft:smooth_quartz
fill ~47 ~-21 ~36 ~64 ~-21 ~36 minecraft:smooth_stone
fill ~4 ~-21 ~37 ~21 ~-21 ~37 minecraft:smooth_stone
fill ~22 ~-21 ~37 ~25 ~-21 ~37 minecraft:smooth_quartz
setblock ~26 ~-21 ~37 minecraft:sea_lantern
fill ~27 ~-21 ~37 ~41 ~-21 ~37 minecraft:air
setblock ~42 ~-21 ~37 minecraft:sea_lantern
fill ~43 ~-21 ~37 ~46 ~-21 ~37 minecraft:smooth_quartz
fill ~47 ~-21 ~37 ~64 ~-21 ~37 minecraft:smooth_stone
fill ~4 ~-21 ~38 ~5 ~-21 ~38 minecraft:smooth_stone
setblock ~6 ~-21 ~38 minecraft:sea_lantern
fill ~7 ~-21 ~38 ~9 ~-21 ~38 minecraft:smooth_stone
setblock ~10 ~-21 ~38 minecraft:sea_lantern
fill ~11 ~-21 ~38 ~13 ~-21 ~38 minecraft:smooth_stone
setblock ~14 ~-21 ~38 minecraft:sea_lantern
fill ~15 ~-21 ~38 ~21 ~-21 ~38 minecraft:smooth_stone
fill ~22 ~-21 ~38 ~25 ~-21 ~38 minecraft:smooth_quartz
setblock ~26 ~-21 ~38 minecraft:sea_lantern
fill ~27 ~-21 ~38 ~41 ~-21 ~38 minecraft:air
setblock ~42 ~-21 ~38 minecraft:sea_lantern
fill ~43 ~-21 ~38 ~46 ~-21 ~38 minecraft:smooth_quartz
fill ~47 ~-21 ~38 ~53 ~-21 ~38 minecraft:smooth_stone
setblock ~54 ~-21 ~38 minecraft:sea_lantern
fill ~55 ~-21 ~38 ~57 ~-21 ~38 minecraft:smooth_stone
setblock ~58 ~-21 ~38 minecraft:sea_lantern
fill ~59 ~-21 ~38 ~61 ~-21 ~38 minecraft:smooth_stone
setblock ~62 ~-21 ~38 minecraft:sea_lantern
fill ~63 ~-21 ~38 ~64 ~-21 ~38 minecraft:smooth_stone
fill ~4 ~-21 ~39 ~21 ~-21 ~39 minecraft:smooth_stone
fill ~22 ~-21 ~39 ~26 ~-21 ~39 minecraft:smooth_quartz
setblock ~27 ~-21 ~39 minecraft:sea_lantern
fill ~28 ~-21 ~39 ~40 ~-21 ~39 minecraft:air
setblock ~41 ~-21 ~39 minecraft:sea_lantern
fill ~42 ~-21 ~39 ~46 ~-21 ~39 minecraft:smooth_quartz
fill ~47 ~-21 ~39 ~64 ~-21 ~39 minecraft:smooth_stone
fill ~4 ~-21 ~40 ~22 ~-21 ~40 minecraft:smooth_stone
fill ~23 ~-21 ~40 ~26 ~-21 ~40 minecraft:smooth_quartz
setblock ~27 ~-21 ~40 minecraft:sea_lantern
fill ~28 ~-21 ~40 ~40 ~-21 ~40 minecraft:air
setblock ~41 ~-21 ~40 minecraft:sea_lantern
fill ~42 ~-21 ~40 ~45 ~-21 ~40 minecraft:smooth_quartz
fill ~46 ~-21 ~40 ~64 ~-21 ~40 minecraft:smooth_stone
fill ~4 ~-21 ~41 ~23 ~-21 ~41 minecraft:smooth_stone
fill ~24 ~-21 ~41 ~27 ~-21 ~41 minecraft:smooth_quartz
fill ~28 ~-21 ~41 ~29 ~-21 ~41 minecraft:sea_lantern
fill ~30 ~-21 ~41 ~38 ~-21 ~41 minecraft:air
fill ~39 ~-21 ~41 ~40 ~-21 ~41 minecraft:sea_lantern
fill ~41 ~-21 ~41 ~44 ~-21 ~41 minecraft:smooth_quartz
fill ~45 ~-21 ~41 ~64 ~-21 ~41 minecraft:smooth_stone
fill ~4 ~-21 ~42 ~5 ~-21 ~42 minecraft:smooth_stone
setblock ~6 ~-21 ~42 minecraft:sea_lantern
fill ~7 ~-21 ~42 ~9 ~-21 ~42 minecraft:smooth_stone
setblock ~10 ~-21 ~42 minecraft:sea_lantern
fill ~11 ~-21 ~42 ~13 ~-21 ~42 minecraft:smooth_stone
setblock ~14 ~-21 ~42 minecraft:sea_lantern
fill ~15 ~-21 ~42 ~21 ~-21 ~42 minecraft:smooth_stone
setblock ~22 ~-21 ~42 minecraft:sea_lantern
setblock ~23 ~-21 ~42 minecraft:smooth_stone
fill ~24 ~-21 ~42 ~29 ~-21 ~42 minecraft:smooth_quartz
fill ~30 ~-21 ~42 ~31 ~-21 ~42 minecraft:sea_lantern
fill ~32 ~-21 ~42 ~36 ~-21 ~42 minecraft:air
fill ~37 ~-21 ~42 ~38 ~-21 ~42 minecraft:sea_lantern
fill ~39 ~-21 ~42 ~44 ~-21 ~42 minecraft:smooth_quartz
setblock ~45 ~-21 ~42 minecraft:smooth_stone
setblock ~46 ~-21 ~42 minecraft:sea_lantern
fill ~47 ~-21 ~42 ~53 ~-21 ~42 minecraft:smooth_stone
setblock ~54 ~-21 ~42 minecraft:sea_lantern
fill ~55 ~-21 ~42 ~57 ~-21 ~42 minecraft:smooth_stone
setblock ~58 ~-21 ~42 minecraft:sea_lantern
fill ~59 ~-21 ~42 ~61 ~-21 ~42 minecraft:smooth_stone
setblock ~62 ~-21 ~42 minecraft:sea_lantern
fill ~63 ~-21 ~42 ~64 ~-21 ~42 minecraft:smooth_stone
fill ~4 ~-21 ~43 ~24 ~-21 ~43 minecraft:smooth_stone
fill ~25 ~-21 ~43 ~31 ~-21 ~43 minecraft:smooth_quartz
fill ~32 ~-21 ~43 ~36 ~-21 ~43 minecraft:sea_lantern
fill ~37 ~-21 ~43 ~43 ~-21 ~43 minecraft:smooth_quartz
fill ~44 ~-21 ~43 ~64 ~-21 ~43 minecraft:smooth_stone
fill ~4 ~-21 ~44 ~25 ~-21 ~44 minecraft:smooth_stone
fill ~26 ~-21 ~44 ~42 ~-21 ~44 minecraft:smooth_quartz
fill ~43 ~-21 ~44 ~64 ~-21 ~44 minecraft:smooth_stone
fill ~4 ~-21 ~45 ~27 ~-21 ~45 minecraft:smooth_stone
fill ~28 ~-21 ~45 ~40 ~-21 ~45 minecraft:smooth_quartz
fill ~41 ~-21 ~45 ~64 ~-21 ~45 minecraft:smooth_stone
fill ~4 ~-21 ~46 ~5 ~-21 ~46 minecraft:smooth_stone
setblock ~6 ~-21 ~46 minecraft:sea_lantern
fill ~7 ~-21 ~46 ~9 ~-21 ~46 minecraft:smooth_stone
setblock ~10 ~-21 ~46 minecraft:sea_lantern
fill ~11 ~-21 ~46 ~13 ~-21 ~46 minecraft:smooth_stone
setblock ~14 ~-21 ~46 minecraft:sea_lantern
fill ~15 ~-21 ~46 ~21 ~-21 ~46 minecraft:smooth_stone
setblock ~22 ~-21 ~46 minecraft:sea_lantern
fill ~23 ~-21 ~46 ~25 ~-21 ~46 minecraft:smooth_stone
setblock ~26 ~-21 ~46 minecraft:sea_lantern
fill ~27 ~-21 ~46 ~28 ~-21 ~46 minecraft:smooth_stone
fill ~29 ~-21 ~46 ~39 ~-21 ~46 minecraft:smooth_quartz
fill ~40 ~-21 ~46 ~41 ~-21 ~46 minecraft:smooth_stone
setblock ~42 ~-21 ~46 minecraft:sea_lantern
fill ~43 ~-21 ~46 ~45 ~-21 ~46 minecraft:smooth_stone
setblock ~46 ~-21 ~46 minecraft:sea_lantern
fill ~47 ~-21 ~46 ~53 ~-21 ~46 minecraft:smooth_stone
setblock ~54 ~-21 ~46 minecraft:sea_lantern
fill ~55 ~-21 ~46 ~57 ~-21 ~46 minecraft:smooth_stone
setblock ~58 ~-21 ~46 minecraft:sea_lantern
fill ~59 ~-21 ~46 ~61 ~-21 ~46 minecraft:smooth_stone
setblock ~62 ~-21 ~46 minecraft:sea_lantern
fill ~63 ~-21 ~46 ~64 ~-21 ~46 minecraft:smooth_stone
fill ~4 ~-21 ~47 ~33 ~-21 ~47 minecraft:smooth_stone
setblock ~34 ~-21 ~47 minecraft:smooth_quartz
fill ~35 ~-21 ~47 ~64 ~-21 ~47 minecraft:smooth_stone
fill ~4 ~-21 ~48 ~64 ~-21 ~48 minecraft:smooth_stone
fill ~4 ~-21 ~49 ~64 ~-21 ~49 minecraft:smooth_stone
fill ~4 ~-21 ~50 ~33 ~-21 ~50 minecraft:smooth_stone
setblock ~34 ~-21 ~50 minecraft:sea_lantern
fill ~35 ~-21 ~50 ~64 ~-21 ~50 minecraft:smooth_stone
fill ~4 ~-21 ~51 ~64 ~-21 ~51 minecraft:smooth_stone
fill ~4 ~-21 ~52 ~64 ~-21 ~52 minecraft:smooth_stone
fill ~4 ~-21 ~53 ~64 ~-21 ~53 minecraft:smooth_stone
fill ~4 ~-21 ~54 ~5 ~-21 ~54 minecraft:smooth_stone
setblock ~6 ~-21 ~54 minecraft:sea_lantern
fill ~7 ~-21 ~54 ~9 ~-21 ~54 minecraft:smooth_stone
setblock ~10 ~-21 ~54 minecraft:sea_lantern
fill ~11 ~-21 ~54 ~13 ~-21 ~54 minecraft:smooth_stone
setblock ~14 ~-21 ~54 minecraft:sea_lantern
fill ~15 ~-21 ~54 ~21 ~-21 ~54 minecraft:smooth_stone
setblock ~22 ~-21 ~54 minecraft:sea_lantern
fill ~23 ~-21 ~54 ~25 ~-21 ~54 minecraft:smooth_stone
setblock ~26 ~-21 ~54 minecraft:sea_lantern
fill ~27 ~-21 ~54 ~29 ~-21 ~54 minecraft:smooth_stone
setblock ~30 ~-21 ~54 minecraft:sea_lantern
fill ~31 ~-21 ~54 ~33 ~-21 ~54 minecraft:smooth_stone
setblock ~34 ~-21 ~54 minecraft:sea_lantern
fill ~35 ~-21 ~54 ~37 ~-21 ~54 minecraft:smooth_stone
setblock ~38 ~-21 ~54 minecraft:sea_lantern
fill ~39 ~-21 ~54 ~41 ~-21 ~54 minecraft:smooth_stone
setblock ~42 ~-21 ~54 minecraft:sea_lantern
fill ~43 ~-21 ~54 ~45 ~-21 ~54 minecraft:smooth_stone
setblock ~46 ~-21 ~54 minecraft:sea_lantern
fill ~47 ~-21 ~54 ~53 ~-21 ~54 minecraft:smooth_stone
setblock ~54 ~-21 ~54 minecraft:sea_lantern
fill ~55 ~-21 ~54 ~57 ~-21 ~54 minecraft:smooth_stone
setblock ~58 ~-21 ~54 minecraft:sea_lantern
fill ~59 ~-21 ~54 ~61 ~-21 ~54 minecraft:smooth_stone
setblock ~62 ~-21 ~54 minecraft:sea_lantern
fill ~63 ~-21 ~54 ~64 ~-21 ~54 minecraft:smooth_stone
fill ~4 ~-21 ~55 ~64 ~-21 ~55 minecraft:smooth_stone
fill ~4 ~-21 ~56 ~64 ~-21 ~56 minecraft:smooth_stone
fill ~4 ~-21 ~57 ~64 ~-21 ~57 minecraft:smooth_stone
fill ~4 ~-21 ~58 ~5 ~-21 ~58 minecraft:smooth_stone
setblock ~6 ~-21 ~58 minecraft:sea_lantern
fill ~7 ~-21 ~58 ~9 ~-21 ~58 minecraft:smooth_stone
setblock ~10 ~-21 ~58 minecraft:sea_lantern
fill ~11 ~-21 ~58 ~13 ~-21 ~58 minecraft:smooth_stone
setblock ~14 ~-21 ~58 minecraft:sea_lantern
fill ~15 ~-21 ~58 ~21 ~-21 ~58 minecraft:smooth_stone
setblock ~22 ~-21 ~58 minecraft:sea_lantern
fill ~23 ~-21 ~58 ~25 ~-21 ~58 minecraft:smooth_stone
setblock ~26 ~-21 ~58 minecraft:sea_lantern
fill ~27 ~-21 ~58 ~29 ~-21 ~58 minecraft:smooth_stone
setblock ~30 ~-21 ~58 minecraft:sea_lantern
fill ~31 ~-21 ~58 ~33 ~-21 ~58 minecraft:smooth_stone
setblock ~34 ~-21 ~58 minecraft:sea_lantern
fill ~35 ~-21 ~58 ~37 ~-21 ~58 minecraft:smooth_stone
setblock ~38 ~-21 ~58 minecraft:sea_lantern
fill ~39 ~-21 ~58 ~41 ~-21 ~58 minecraft:smooth_stone
setblock ~42 ~-21 ~58 minecraft:sea_lantern
fill ~43 ~-21 ~58 ~45 ~-21 ~58 minecraft:smooth_stone
setblock ~46 ~-21 ~58 minecraft:sea_lantern
fill ~47 ~-21 ~58 ~53 ~-21 ~58 minecraft:smooth_stone
setblock ~54 ~-21 ~58 minecraft:sea_lantern
fill ~55 ~-21 ~58 ~57 ~-21 ~58 minecraft:smooth_stone
setblock ~58 ~-21 ~58 minecraft:sea_lantern
fill ~59 ~-21 ~58 ~61 ~-21 ~58 minecraft:smooth_stone
setblock ~62 ~-21 ~58 minecraft:sea_lantern
fill ~63 ~-21 ~58 ~64 ~-21 ~58 minecraft:smooth_stone
fill ~4 ~-21 ~59 ~64 ~-21 ~59 minecraft:smooth_stone
fill ~4 ~-21 ~60 ~64 ~-21 ~60 minecraft:smooth_stone
fill ~4 ~-21 ~61 ~64 ~-21 ~61 minecraft:smooth_stone
fill ~4 ~-21 ~62 ~5 ~-21 ~62 minecraft:smooth_stone
setblock ~6 ~-21 ~62 minecraft:sea_lantern
fill ~7 ~-21 ~62 ~9 ~-21 ~62 minecraft:smooth_stone
setblock ~10 ~-21 ~62 minecraft:sea_lantern
fill ~11 ~-21 ~62 ~13 ~-21 ~62 minecraft:smooth_stone
setblock ~14 ~-21 ~62 minecraft:sea_lantern
fill ~15 ~-21 ~62 ~21 ~-21 ~62 minecraft:smooth_stone
setblock ~22 ~-21 ~62 minecraft:sea_lantern
fill ~23 ~-21 ~62 ~25 ~-21 ~62 minecraft:smooth_stone
setblock ~26 ~-21 ~62 minecraft:sea_lantern
fill ~27 ~-21 ~62 ~29 ~-21 ~62 minecraft:smooth_stone
setblock ~30 ~-21 ~62 minecraft:sea_lantern
fill ~31 ~-21 ~62 ~33 ~-21 ~62 minecraft:smooth_stone
setblock ~34 ~-21 ~62 minecraft:sea_lantern
fill ~35 ~-21 ~62 ~37 ~-21 ~62 minecraft:smooth_stone
setblock ~38 ~-21 ~62 minecraft:sea_lantern
fill ~39 ~-21 ~62 ~41 ~-21 ~62 minecraft:smooth_stone
setblock ~42 ~-21 ~62 minecraft:sea_lantern
fill ~43 ~-21 ~62 ~45 ~-21 ~62 minecraft:smooth_stone
setblock ~46 ~-21 ~62 minecraft:sea_lantern
fill ~47 ~-21 ~62 ~53 ~-21 ~62 minecraft:smooth_stone
setblock ~54 ~-21 ~62 minecraft:sea_lantern
fill ~55 ~-21 ~62 ~57 ~-21 ~62 minecraft:smooth_stone
setblock ~58 ~-21 ~62 minecraft:sea_lantern
fill ~59 ~-21 ~62 ~61 ~-21 ~62 minecraft:smooth_stone
setblock ~62 ~-21 ~62 minecraft:sea_lantern
fill ~63 ~-21 ~62 ~64 ~-21 ~62 minecraft:smooth_stone
fill ~4 ~-21 ~63 ~64 ~-21 ~63 minecraft:smooth_stone
fill ~4 ~-21 ~64 ~64 ~-21 ~64 minecraft:smooth_stone
fill ~32 ~-21 ~66 ~36 ~-21 ~66 minecraft:polished_andesite
setblock ~32 ~-21 ~67 minecraft:polished_andesite
setblock ~33 ~-21 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-21 ~67 ~35 ~-21 ~67 minecraft:air
setblock ~36 ~-21 ~67 minecraft:polished_andesite
setblock ~32 ~-21 ~68 minecraft:polished_andesite
setblock ~33 ~-21 ~68 minecraft:air
setblock ~34 ~-21 ~68 minecraft:quartz_pillar
setblock ~35 ~-21 ~68 minecraft:air
setblock ~36 ~-21 ~68 minecraft:polished_andesite
setblock ~32 ~-21 ~69 minecraft:polished_andesite
fill ~33 ~-21 ~69 ~35 ~-21 ~69 minecraft:air
setblock ~36 ~-21 ~69 minecraft:polished_andesite
fill ~32 ~-21 ~70 ~36 ~-21 ~70 minecraft:polished_andesite
fill ~4 ~-20 ~4 ~64 ~-20 ~4 minecraft:light_gray_concrete
setblock ~4 ~-20 ~5 minecraft:light_gray_concrete
fill ~5 ~-20 ~5 ~17 ~-20 ~5 minecraft:spruce_planks
setblock ~18 ~-20 ~5 minecraft:light_gray_concrete
fill ~19 ~-20 ~5 ~31 ~-20 ~5 minecraft:white_concrete
setblock ~32 ~-20 ~5 minecraft:light_gray_concrete
setblock ~33 ~-20 ~5 minecraft:white_concrete
setblock ~34 ~-20 ~5 minecraft:red_concrete
setblock ~35 ~-20 ~5 minecraft:white_concrete
setblock ~36 ~-20 ~5 minecraft:light_gray_concrete
fill ~37 ~-20 ~5 ~49 ~-20 ~5 minecraft:white_concrete
setblock ~50 ~-20 ~5 minecraft:light_gray_concrete
fill ~51 ~-20 ~5 ~63 ~-20 ~5 minecraft:polished_diorite
setblock ~64 ~-20 ~5 minecraft:light_gray_concrete
setblock ~4 ~-20 ~6 minecraft:light_gray_concrete
fill ~5 ~-20 ~6 ~17 ~-20 ~6 minecraft:spruce_planks
setblock ~18 ~-20 ~6 minecraft:light_gray_concrete
fill ~19 ~-20 ~6 ~31 ~-20 ~6 minecraft:white_concrete
setblock ~32 ~-20 ~6 minecraft:light_gray_concrete
setblock ~33 ~-20 ~6 minecraft:white_concrete
setblock ~34 ~-20 ~6 minecraft:red_concrete
setblock ~35 ~-20 ~6 minecraft:white_concrete
setblock ~36 ~-20 ~6 minecraft:light_gray_concrete
fill ~37 ~-20 ~6 ~49 ~-20 ~6 minecraft:white_concrete
setblock ~50 ~-20 ~6 minecraft:light_gray_concrete
fill ~51 ~-20 ~6 ~63 ~-20 ~6 minecraft:polished_diorite
setblock ~64 ~-20 ~6 minecraft:light_gray_concrete
setblock ~4 ~-20 ~7 minecraft:light_gray_concrete
fill ~5 ~-20 ~7 ~17 ~-20 ~7 minecraft:spruce_planks
setblock ~18 ~-20 ~7 minecraft:light_gray_concrete
fill ~19 ~-20 ~7 ~31 ~-20 ~7 minecraft:white_concrete
setblock ~32 ~-20 ~7 minecraft:light_gray_concrete
setblock ~33 ~-20 ~7 minecraft:white_concrete
setblock ~34 ~-20 ~7 minecraft:red_concrete
setblock ~35 ~-20 ~7 minecraft:white_concrete
setblock ~36 ~-20 ~7 minecraft:light_gray_concrete
fill ~37 ~-20 ~7 ~49 ~-20 ~7 minecraft:white_concrete
setblock ~50 ~-20 ~7 minecraft:light_gray_concrete
fill ~51 ~-20 ~7 ~63 ~-20 ~7 minecraft:polished_diorite
setblock ~64 ~-20 ~7 minecraft:light_gray_concrete
setblock ~4 ~-20 ~8 minecraft:light_gray_concrete
fill ~5 ~-20 ~8 ~17 ~-20 ~8 minecraft:spruce_planks
setblock ~18 ~-20 ~8 minecraft:light_gray_concrete
fill ~19 ~-20 ~8 ~31 ~-20 ~8 minecraft:white_concrete
setblock ~32 ~-20 ~8 minecraft:light_gray_concrete
setblock ~33 ~-20 ~8 minecraft:white_concrete
setblock ~34 ~-20 ~8 minecraft:red_concrete
setblock ~35 ~-20 ~8 minecraft:white_concrete
setblock ~36 ~-20 ~8 minecraft:light_gray_concrete
fill ~37 ~-20 ~8 ~49 ~-20 ~8 minecraft:white_concrete
setblock ~50 ~-20 ~8 minecraft:light_gray_concrete
fill ~51 ~-20 ~8 ~63 ~-20 ~8 minecraft:polished_diorite
setblock ~64 ~-20 ~8 minecraft:light_gray_concrete
setblock ~4 ~-20 ~9 minecraft:light_gray_concrete
fill ~5 ~-20 ~9 ~17 ~-20 ~9 minecraft:spruce_planks
setblock ~18 ~-20 ~9 minecraft:light_gray_concrete
fill ~19 ~-20 ~9 ~31 ~-20 ~9 minecraft:white_concrete
setblock ~32 ~-20 ~9 minecraft:light_gray_concrete
setblock ~33 ~-20 ~9 minecraft:white_concrete
setblock ~34 ~-20 ~9 minecraft:red_concrete
setblock ~35 ~-20 ~9 minecraft:white_concrete
setblock ~36 ~-20 ~9 minecraft:light_gray_concrete
fill ~37 ~-20 ~9 ~49 ~-20 ~9 minecraft:white_concrete
setblock ~50 ~-20 ~9 minecraft:light_gray_concrete
fill ~51 ~-20 ~9 ~63 ~-20 ~9 minecraft:polished_diorite
setblock ~64 ~-20 ~9 minecraft:light_gray_concrete
setblock ~4 ~-20 ~10 minecraft:light_gray_concrete
fill ~5 ~-20 ~10 ~17 ~-20 ~10 minecraft:spruce_planks
setblock ~18 ~-20 ~10 minecraft:light_gray_concrete
fill ~19 ~-20 ~10 ~31 ~-20 ~10 minecraft:white_concrete
setblock ~32 ~-20 ~10 minecraft:light_gray_concrete
setblock ~33 ~-20 ~10 minecraft:white_concrete
setblock ~34 ~-20 ~10 minecraft:red_concrete
setblock ~35 ~-20 ~10 minecraft:white_concrete
setblock ~36 ~-20 ~10 minecraft:light_gray_concrete
fill ~37 ~-20 ~10 ~49 ~-20 ~10 minecraft:white_concrete
setblock ~50 ~-20 ~10 minecraft:light_gray_concrete
fill ~51 ~-20 ~10 ~63 ~-20 ~10 minecraft:polished_diorite
setblock ~64 ~-20 ~10 minecraft:light_gray_concrete
setblock ~4 ~-20 ~11 minecraft:light_gray_concrete
fill ~5 ~-20 ~11 ~17 ~-20 ~11 minecraft:spruce_planks
setblock ~18 ~-20 ~11 minecraft:light_gray_concrete
fill ~19 ~-20 ~11 ~31 ~-20 ~11 minecraft:white_concrete
setblock ~32 ~-20 ~11 minecraft:light_gray_concrete
setblock ~33 ~-20 ~11 minecraft:white_concrete
setblock ~34 ~-20 ~11 minecraft:red_concrete
setblock ~35 ~-20 ~11 minecraft:white_concrete
setblock ~36 ~-20 ~11 minecraft:light_gray_concrete
fill ~37 ~-20 ~11 ~49 ~-20 ~11 minecraft:white_concrete
setblock ~50 ~-20 ~11 minecraft:light_gray_concrete
fill ~51 ~-20 ~11 ~63 ~-20 ~11 minecraft:polished_diorite
setblock ~64 ~-20 ~11 minecraft:light_gray_concrete
setblock ~4 ~-20 ~12 minecraft:light_gray_concrete
fill ~5 ~-20 ~12 ~17 ~-20 ~12 minecraft:spruce_planks
setblock ~18 ~-20 ~12 minecraft:light_gray_concrete
fill ~19 ~-20 ~12 ~31 ~-20 ~12 minecraft:white_concrete
setblock ~32 ~-20 ~12 minecraft:light_gray_concrete
setblock ~33 ~-20 ~12 minecraft:white_concrete
setblock ~34 ~-20 ~12 minecraft:red_concrete
setblock ~35 ~-20 ~12 minecraft:white_concrete
setblock ~36 ~-20 ~12 minecraft:light_gray_concrete
fill ~37 ~-20 ~12 ~49 ~-20 ~12 minecraft:white_concrete
setblock ~50 ~-20 ~12 minecraft:light_gray_concrete
fill ~51 ~-20 ~12 ~63 ~-20 ~12 minecraft:polished_diorite
setblock ~64 ~-20 ~12 minecraft:light_gray_concrete
setblock ~4 ~-20 ~13 minecraft:light_gray_concrete
fill ~5 ~-20 ~13 ~17 ~-20 ~13 minecraft:spruce_planks
setblock ~18 ~-20 ~13 minecraft:light_gray_concrete
fill ~19 ~-20 ~13 ~31 ~-20 ~13 minecraft:white_concrete
setblock ~32 ~-20 ~13 minecraft:light_gray_concrete
setblock ~33 ~-20 ~13 minecraft:white_concrete
setblock ~34 ~-20 ~13 minecraft:red_concrete
setblock ~35 ~-20 ~13 minecraft:white_concrete
setblock ~36 ~-20 ~13 minecraft:light_gray_concrete
fill ~37 ~-20 ~13 ~49 ~-20 ~13 minecraft:white_concrete
setblock ~50 ~-20 ~13 minecraft:light_gray_concrete
fill ~51 ~-20 ~13 ~63 ~-20 ~13 minecraft:polished_diorite
setblock ~64 ~-20 ~13 minecraft:light_gray_concrete
setblock ~4 ~-20 ~14 minecraft:light_gray_concrete
fill ~5 ~-20 ~14 ~17 ~-20 ~14 minecraft:spruce_planks
setblock ~18 ~-20 ~14 minecraft:light_gray_concrete
fill ~19 ~-20 ~14 ~31 ~-20 ~14 minecraft:white_concrete
setblock ~32 ~-20 ~14 minecraft:light_gray_concrete
setblock ~33 ~-20 ~14 minecraft:white_concrete
setblock ~34 ~-20 ~14 minecraft:red_concrete
setblock ~35 ~-20 ~14 minecraft:white_concrete
setblock ~36 ~-20 ~14 minecraft:light_gray_concrete
fill ~37 ~-20 ~14 ~49 ~-20 ~14 minecraft:white_concrete
setblock ~50 ~-20 ~14 minecraft:light_gray_concrete
fill ~51 ~-20 ~14 ~63 ~-20 ~14 minecraft:polished_diorite
setblock ~64 ~-20 ~14 minecraft:light_gray_concrete
setblock ~4 ~-20 ~15 minecraft:light_gray_concrete
fill ~5 ~-20 ~15 ~17 ~-20 ~15 minecraft:spruce_planks
setblock ~18 ~-20 ~15 minecraft:light_gray_concrete
fill ~19 ~-20 ~15 ~31 ~-20 ~15 minecraft:white_concrete
setblock ~32 ~-20 ~15 minecraft:light_gray_concrete
setblock ~33 ~-20 ~15 minecraft:white_concrete
setblock ~34 ~-20 ~15 minecraft:red_concrete
setblock ~35 ~-20 ~15 minecraft:white_concrete
setblock ~36 ~-20 ~15 minecraft:light_gray_concrete
fill ~37 ~-20 ~15 ~49 ~-20 ~15 minecraft:white_concrete
setblock ~50 ~-20 ~15 minecraft:light_gray_concrete
fill ~51 ~-20 ~15 ~63 ~-20 ~15 minecraft:polished_diorite
setblock ~64 ~-20 ~15 minecraft:light_gray_concrete
setblock ~4 ~-20 ~16 minecraft:light_gray_concrete
fill ~5 ~-20 ~16 ~17 ~-20 ~16 minecraft:spruce_planks
setblock ~18 ~-20 ~16 minecraft:light_gray_concrete
fill ~19 ~-20 ~16 ~31 ~-20 ~16 minecraft:white_concrete
setblock ~32 ~-20 ~16 minecraft:light_gray_concrete
setblock ~33 ~-20 ~16 minecraft:white_concrete
setblock ~34 ~-20 ~16 minecraft:red_concrete
setblock ~35 ~-20 ~16 minecraft:white_concrete
setblock ~36 ~-20 ~16 minecraft:light_gray_concrete
fill ~37 ~-20 ~16 ~49 ~-20 ~16 minecraft:white_concrete
setblock ~50 ~-20 ~16 minecraft:light_gray_concrete
fill ~51 ~-20 ~16 ~63 ~-20 ~16 minecraft:polished_diorite
setblock ~64 ~-20 ~16 minecraft:light_gray_concrete
setblock ~4 ~-20 ~17 minecraft:light_gray_concrete
fill ~5 ~-20 ~17 ~17 ~-20 ~17 minecraft:spruce_planks
setblock ~18 ~-20 ~17 minecraft:light_gray_concrete
fill ~19 ~-20 ~17 ~31 ~-20 ~17 minecraft:white_concrete
setblock ~32 ~-20 ~17 minecraft:light_gray_concrete
setblock ~33 ~-20 ~17 minecraft:white_concrete
setblock ~34 ~-20 ~17 minecraft:red_concrete
setblock ~35 ~-20 ~17 minecraft:white_concrete
setblock ~36 ~-20 ~17 minecraft:light_gray_concrete
fill ~37 ~-20 ~17 ~49 ~-20 ~17 minecraft:white_concrete
setblock ~50 ~-20 ~17 minecraft:light_gray_concrete
fill ~51 ~-20 ~17 ~63 ~-20 ~17 minecraft:polished_diorite
setblock ~64 ~-20 ~17 minecraft:light_gray_concrete
fill ~4 ~-20 ~18 ~32 ~-20 ~18 minecraft:light_gray_concrete
setblock ~33 ~-20 ~18 minecraft:white_concrete
setblock ~34 ~-20 ~18 minecraft:red_concrete
setblock ~35 ~-20 ~18 minecraft:white_concrete
fill ~36 ~-20 ~18 ~64 ~-20 ~18 minecraft:light_gray_concrete
setblock ~4 ~-20 ~19 minecraft:light_gray_concrete
fill ~5 ~-20 ~19 ~17 ~-20 ~19 minecraft:white_concrete
setblock ~18 ~-20 ~19 minecraft:light_gray_concrete
fill ~19 ~-20 ~19 ~31 ~-20 ~19 minecraft:white_concrete
setblock ~32 ~-20 ~19 minecraft:light_gray_concrete
setblock ~33 ~-20 ~19 minecraft:white_concrete
setblock ~34 ~-20 ~19 minecraft:red_concrete
setblock ~35 ~-20 ~19 minecraft:white_concrete
setblock ~36 ~-20 ~19 minecraft:light_gray_concrete
fill ~37 ~-20 ~19 ~49 ~-20 ~19 minecraft:white_concrete
setblock ~50 ~-20 ~19 minecraft:light_gray_concrete
fill ~51 ~-20 ~19 ~63 ~-20 ~19 minecraft:dark_oak_planks
setblock ~64 ~-20 ~19 minecraft:light_gray_concrete
setblock ~4 ~-20 ~20 minecraft:light_gray_concrete
fill ~5 ~-20 ~20 ~17 ~-20 ~20 minecraft:white_concrete
setblock ~18 ~-20 ~20 minecraft:light_gray_concrete
fill ~19 ~-20 ~20 ~31 ~-20 ~20 minecraft:white_concrete
setblock ~32 ~-20 ~20 minecraft:light_gray_concrete
setblock ~33 ~-20 ~20 minecraft:white_concrete
setblock ~34 ~-20 ~20 minecraft:red_concrete
setblock ~35 ~-20 ~20 minecraft:white_concrete
setblock ~36 ~-20 ~20 minecraft:light_gray_concrete
fill ~37 ~-20 ~20 ~49 ~-20 ~20 minecraft:white_concrete
setblock ~50 ~-20 ~20 minecraft:light_gray_concrete
fill ~51 ~-20 ~20 ~63 ~-20 ~20 minecraft:dark_oak_planks
setblock ~64 ~-20 ~20 minecraft:light_gray_concrete
setblock ~4 ~-20 ~21 minecraft:light_gray_concrete
setblock ~5 ~-20 ~21 minecraft:white_concrete
setblock ~6 ~-20 ~21 minecraft:campfire[lit=true]
fill ~7 ~-20 ~21 ~8 ~-20 ~21 minecraft:white_concrete
setblock ~9 ~-20 ~21 minecraft:campfire[lit=true]
fill ~10 ~-20 ~21 ~11 ~-20 ~21 minecraft:white_concrete
setblock ~12 ~-20 ~21 minecraft:campfire[lit=true]
fill ~13 ~-20 ~21 ~14 ~-20 ~21 minecraft:white_concrete
setblock ~15 ~-20 ~21 minecraft:campfire[lit=true]
fill ~16 ~-20 ~21 ~17 ~-20 ~21 minecraft:white_concrete
setblock ~18 ~-20 ~21 minecraft:light_gray_concrete
fill ~19 ~-20 ~21 ~31 ~-20 ~21 minecraft:white_concrete
setblock ~32 ~-20 ~21 minecraft:light_gray_concrete
setblock ~33 ~-20 ~21 minecraft:white_concrete
setblock ~34 ~-20 ~21 minecraft:smooth_quartz
setblock ~35 ~-20 ~21 minecraft:white_concrete
setblock ~36 ~-20 ~21 minecraft:light_gray_concrete
fill ~37 ~-20 ~21 ~49 ~-20 ~21 minecraft:white_concrete
setblock ~50 ~-20 ~21 minecraft:light_gray_concrete
fill ~51 ~-20 ~21 ~63 ~-20 ~21 minecraft:dark_oak_planks
setblock ~64 ~-20 ~21 minecraft:light_gray_concrete
setblock ~4 ~-20 ~22 minecraft:light_gray_concrete
fill ~5 ~-20 ~22 ~17 ~-20 ~22 minecraft:white_concrete
setblock ~18 ~-20 ~22 minecraft:light_gray_concrete
fill ~19 ~-20 ~22 ~28 ~-20 ~22 minecraft:white_concrete
fill ~29 ~-20 ~22 ~32 ~-20 ~22 minecraft:polished_andesite
fill ~33 ~-20 ~22 ~35 ~-20 ~22 minecraft:smooth_quartz
fill ~36 ~-20 ~22 ~39 ~-20 ~22 minecraft:polished_andesite
fill ~40 ~-20 ~22 ~49 ~-20 ~22 minecraft:white_concrete
setblock ~50 ~-20 ~22 minecraft:light_gray_concrete
fill ~51 ~-20 ~22 ~63 ~-20 ~22 minecraft:dark_oak_planks
setblock ~64 ~-20 ~22 minecraft:light_gray_concrete
setblock ~4 ~-20 ~23 minecraft:light_gray_concrete
fill ~5 ~-20 ~23 ~17 ~-20 ~23 minecraft:white_concrete
setblock ~18 ~-20 ~23 minecraft:light_gray_concrete
fill ~19 ~-20 ~23 ~27 ~-20 ~23 minecraft:white_concrete
fill ~28 ~-20 ~23 ~29 ~-20 ~23 minecraft:polished_andesite
fill ~30 ~-20 ~23 ~33 ~-20 ~23 minecraft:smooth_quartz
setblock ~34 ~-20 ~23 minecraft:polished_diorite
fill ~35 ~-20 ~23 ~38 ~-20 ~23 minecraft:smooth_quartz
fill ~39 ~-20 ~23 ~40 ~-20 ~23 minecraft:polished_andesite
fill ~41 ~-20 ~23 ~49 ~-20 ~23 minecraft:white_concrete
setblock ~50 ~-20 ~23 minecraft:light_gray_concrete
fill ~51 ~-20 ~23 ~63 ~-20 ~23 minecraft:dark_oak_planks
setblock ~64 ~-20 ~23 minecraft:light_gray_concrete
setblock ~4 ~-20 ~24 minecraft:light_gray_concrete
setblock ~5 ~-20 ~24 minecraft:white_concrete
setblock ~6 ~-20 ~24 minecraft:campfire[lit=true]
fill ~7 ~-20 ~24 ~8 ~-20 ~24 minecraft:white_concrete
setblock ~9 ~-20 ~24 minecraft:campfire[lit=true]
fill ~10 ~-20 ~24 ~11 ~-20 ~24 minecraft:white_concrete
setblock ~12 ~-20 ~24 minecraft:campfire[lit=true]
fill ~13 ~-20 ~24 ~14 ~-20 ~24 minecraft:white_concrete
setblock ~15 ~-20 ~24 minecraft:campfire[lit=true]
fill ~16 ~-20 ~24 ~17 ~-20 ~24 minecraft:white_concrete
setblock ~18 ~-20 ~24 minecraft:light_gray_concrete
fill ~19 ~-20 ~24 ~25 ~-20 ~24 minecraft:white_concrete
fill ~26 ~-20 ~24 ~27 ~-20 ~24 minecraft:polished_andesite
fill ~28 ~-20 ~24 ~29 ~-20 ~24 minecraft:smooth_quartz
fill ~30 ~-20 ~24 ~33 ~-20 ~24 minecraft:polished_diorite
setblock ~34 ~-20 ~24 minecraft:smooth_quartz
fill ~35 ~-20 ~24 ~38 ~-20 ~24 minecraft:polished_diorite
fill ~39 ~-20 ~24 ~40 ~-20 ~24 minecraft:smooth_quartz
fill ~41 ~-20 ~24 ~42 ~-20 ~24 minecraft:polished_andesite
fill ~43 ~-20 ~24 ~49 ~-20 ~24 minecraft:white_concrete
setblock ~50 ~-20 ~24 minecraft:light_gray_concrete
fill ~51 ~-20 ~24 ~63 ~-20 ~24 minecraft:dark_oak_planks
setblock ~64 ~-20 ~24 minecraft:light_gray_concrete
setblock ~4 ~-20 ~25 minecraft:light_gray_concrete
fill ~5 ~-20 ~25 ~17 ~-20 ~25 minecraft:white_concrete
setblock ~18 ~-20 ~25 minecraft:light_gray_concrete
fill ~19 ~-20 ~25 ~24 ~-20 ~25 minecraft:white_concrete
fill ~25 ~-20 ~25 ~26 ~-20 ~25 minecraft:polished_andesite
setblock ~27 ~-20 ~25 minecraft:smooth_quartz
fill ~28 ~-20 ~25 ~29 ~-20 ~25 minecraft:polished_diorite
fill ~30 ~-20 ~25 ~31 ~-20 ~25 minecraft:smooth_quartz
fill ~32 ~-20 ~25 ~36 ~-20 ~25 minecraft:red_concrete
fill ~37 ~-20 ~25 ~38 ~-20 ~25 minecraft:smooth_quartz
fill ~39 ~-20 ~25 ~40 ~-20 ~25 minecraft:polished_diorite
setblock ~41 ~-20 ~25 minecraft:smooth_quartz
fill ~42 ~-20 ~25 ~43 ~-20 ~25 minecraft:polished_andesite
fill ~44 ~-20 ~25 ~49 ~-20 ~25 minecraft:white_concrete
setblock ~50 ~-20 ~25 minecraft:light_gray_concrete
fill ~51 ~-20 ~25 ~63 ~-20 ~25 minecraft:dark_oak_planks
setblock ~64 ~-20 ~25 minecraft:light_gray_concrete
setblock ~4 ~-20 ~26 minecraft:light_gray_concrete
fill ~5 ~-20 ~26 ~17 ~-20 ~26 minecraft:white_concrete
setblock ~18 ~-20 ~26 minecraft:light_gray_concrete
fill ~19 ~-20 ~26 ~23 ~-20 ~26 minecraft:white_concrete
fill ~24 ~-20 ~26 ~25 ~-20 ~26 minecraft:polished_andesite
setblock ~26 ~-20 ~26 minecraft:smooth_quartz
setblock ~27 ~-20 ~26 minecraft:polished_diorite
fill ~28 ~-20 ~26 ~29 ~-20 ~26 minecraft:smooth_quartz
fill ~30 ~-20 ~26 ~31 ~-20 ~26 minecraft:red_concrete
fill ~32 ~-20 ~26 ~36 ~-20 ~26 minecraft:air
fill ~37 ~-20 ~26 ~38 ~-20 ~26 minecraft:red_concrete
fill ~39 ~-20 ~26 ~40 ~-20 ~26 minecraft:smooth_quartz
setblock ~41 ~-20 ~26 minecraft:polished_diorite
setblock ~42 ~-20 ~26 minecraft:smooth_quartz
fill ~43 ~-20 ~26 ~44 ~-20 ~26 minecraft:polished_andesite
fill ~45 ~-20 ~26 ~49 ~-20 ~26 minecraft:white_concrete
setblock ~50 ~-20 ~26 minecraft:light_gray_concrete
fill ~51 ~-20 ~26 ~63 ~-20 ~26 minecraft:dark_oak_planks
setblock ~64 ~-20 ~26 minecraft:light_gray_concrete
setblock ~4 ~-20 ~27 minecraft:light_gray_concrete
setblock ~5 ~-20 ~27 minecraft:white_concrete
setblock ~6 ~-20 ~27 minecraft:campfire[lit=true]
fill ~7 ~-20 ~27 ~8 ~-20 ~27 minecraft:white_concrete
setblock ~9 ~-20 ~27 minecraft:campfire[lit=true]
fill ~10 ~-20 ~27 ~11 ~-20 ~27 minecraft:white_concrete
setblock ~12 ~-20 ~27 minecraft:campfire[lit=true]
fill ~13 ~-20 ~27 ~14 ~-20 ~27 minecraft:white_concrete
setblock ~15 ~-20 ~27 minecraft:campfire[lit=true]
fill ~16 ~-20 ~27 ~17 ~-20 ~27 minecraft:white_concrete
setblock ~18 ~-20 ~27 minecraft:light_gray_concrete
fill ~19 ~-20 ~27 ~23 ~-20 ~27 minecraft:white_concrete
setblock ~24 ~-20 ~27 minecraft:polished_andesite
setblock ~25 ~-20 ~27 minecraft:smooth_quartz
setblock ~26 ~-20 ~27 minecraft:polished_diorite
setblock ~27 ~-20 ~27 minecraft:smooth_quartz
fill ~28 ~-20 ~27 ~29 ~-20 ~27 minecraft:red_concrete
fill ~30 ~-20 ~27 ~38 ~-20 ~27 minecraft:air
fill ~39 ~-20 ~27 ~40 ~-20 ~27 minecraft:red_concrete
setblock ~41 ~-20 ~27 minecraft:smooth_quartz
setblock ~42 ~-20 ~27 minecraft:polished_diorite
setblock ~43 ~-20 ~27 minecraft:smooth_quartz
setblock ~44 ~-20 ~27 minecraft:polished_andesite
fill ~45 ~-20 ~27 ~49 ~-20 ~27 minecraft:white_concrete
setblock ~50 ~-20 ~27 minecraft:light_gray_concrete
fill ~51 ~-20 ~27 ~63 ~-20 ~27 minecraft:dark_oak_planks
setblock ~64 ~-20 ~27 minecraft:light_gray_concrete
setblock ~4 ~-20 ~28 minecraft:light_gray_concrete
fill ~5 ~-20 ~28 ~17 ~-20 ~28 minecraft:white_concrete
setblock ~18 ~-20 ~28 minecraft:light_gray_concrete
fill ~19 ~-20 ~28 ~22 ~-20 ~28 minecraft:white_concrete
setblock ~23 ~-20 ~28 minecraft:polished_andesite
setblock ~24 ~-20 ~28 minecraft:smooth_quartz
setblock ~25 ~-20 ~28 minecraft:polished_diorite
setblock ~26 ~-20 ~28 minecraft:smooth_quartz
setblock ~27 ~-20 ~28 minecraft:red_concrete
fill ~28 ~-20 ~28 ~40 ~-20 ~28 minecraft:air
setblock ~41 ~-20 ~28 minecraft:red_concrete
setblock ~42 ~-20 ~28 minecraft:smooth_quartz
setblock ~43 ~-20 ~28 minecraft:polished_diorite
setblock ~44 ~-20 ~28 minecraft:smooth_quartz
setblock ~45 ~-20 ~28 minecraft:polished_andesite
fill ~46 ~-20 ~28 ~49 ~-20 ~28 minecraft:white_concrete
setblock ~50 ~-20 ~28 minecraft:light_gray_concrete
fill ~51 ~-20 ~28 ~63 ~-20 ~28 minecraft:dark_oak_planks
setblock ~64 ~-20 ~28 minecraft:light_gray_concrete
setblock ~4 ~-20 ~29 minecraft:light_gray_concrete
fill ~5 ~-20 ~29 ~17 ~-20 ~29 minecraft:white_concrete
setblock ~18 ~-20 ~29 minecraft:light_gray_concrete
fill ~19 ~-20 ~29 ~21 ~-20 ~29 minecraft:white_concrete
fill ~22 ~-20 ~29 ~23 ~-20 ~29 minecraft:polished_andesite
setblock ~24 ~-20 ~29 minecraft:smooth_quartz
setblock ~25 ~-20 ~29 minecraft:polished_diorite
setblock ~26 ~-20 ~29 minecraft:smooth_quartz
setblock ~27 ~-20 ~29 minecraft:red_concrete
fill ~28 ~-20 ~29 ~40 ~-20 ~29 minecraft:air
setblock ~41 ~-20 ~29 minecraft:red_concrete
setblock ~42 ~-20 ~29 minecraft:smooth_quartz
setblock ~43 ~-20 ~29 minecraft:polished_diorite
setblock ~44 ~-20 ~29 minecraft:smooth_quartz
fill ~45 ~-20 ~29 ~46 ~-20 ~29 minecraft:polished_andesite
fill ~47 ~-20 ~29 ~49 ~-20 ~29 minecraft:white_concrete
setblock ~50 ~-20 ~29 minecraft:light_gray_concrete
fill ~51 ~-20 ~29 ~63 ~-20 ~29 minecraft:dark_oak_planks
setblock ~64 ~-20 ~29 minecraft:light_gray_concrete
setblock ~4 ~-20 ~30 minecraft:light_gray_concrete
setblock ~5 ~-20 ~30 minecraft:white_concrete
setblock ~6 ~-20 ~30 minecraft:campfire[lit=true]
fill ~7 ~-20 ~30 ~8 ~-20 ~30 minecraft:white_concrete
setblock ~9 ~-20 ~30 minecraft:campfire[lit=true]
fill ~10 ~-20 ~30 ~11 ~-20 ~30 minecraft:white_concrete
setblock ~12 ~-20 ~30 minecraft:campfire[lit=true]
fill ~13 ~-20 ~30 ~14 ~-20 ~30 minecraft:white_concrete
setblock ~15 ~-20 ~30 minecraft:campfire[lit=true]
fill ~16 ~-20 ~30 ~17 ~-20 ~30 minecraft:white_concrete
setblock ~18 ~-20 ~30 minecraft:light_gray_concrete
fill ~19 ~-20 ~30 ~21 ~-20 ~30 minecraft:white_concrete
setblock ~22 ~-20 ~30 minecraft:polished_andesite
setblock ~23 ~-20 ~30 minecraft:smooth_quartz
setblock ~24 ~-20 ~30 minecraft:polished_diorite
setblock ~25 ~-20 ~30 minecraft:smooth_quartz
setblock ~26 ~-20 ~30 minecraft:red_concrete
fill ~27 ~-20 ~30 ~41 ~-20 ~30 minecraft:air
setblock ~42 ~-20 ~30 minecraft:red_concrete
setblock ~43 ~-20 ~30 minecraft:smooth_quartz
setblock ~44 ~-20 ~30 minecraft:polished_diorite
setblock ~45 ~-20 ~30 minecraft:smooth_quartz
setblock ~46 ~-20 ~30 minecraft:polished_andesite
fill ~47 ~-20 ~30 ~49 ~-20 ~30 minecraft:white_concrete
setblock ~50 ~-20 ~30 minecraft:light_gray_concrete
fill ~51 ~-20 ~30 ~63 ~-20 ~30 minecraft:dark_oak_planks
setblock ~64 ~-20 ~30 minecraft:light_gray_concrete
setblock ~4 ~-20 ~31 minecraft:light_gray_concrete
fill ~5 ~-20 ~31 ~17 ~-20 ~31 minecraft:white_concrete
setblock ~18 ~-20 ~31 minecraft:light_gray_concrete
fill ~19 ~-20 ~31 ~21 ~-20 ~31 minecraft:white_concrete
setblock ~22 ~-20 ~31 minecraft:polished_andesite
setblock ~23 ~-20 ~31 minecraft:smooth_quartz
setblock ~24 ~-20 ~31 minecraft:polished_diorite
setblock ~25 ~-20 ~31 minecraft:smooth_quartz
setblock ~26 ~-20 ~31 minecraft:red_concrete
fill ~27 ~-20 ~31 ~31 ~-20 ~31 minecraft:air
fill ~32 ~-20 ~31 ~36 ~-20 ~31 minecraft:iron_block
fill ~37 ~-20 ~31 ~41 ~-20 ~31 minecraft:air
setblock ~42 ~-20 ~31 minecraft:red_concrete
setblock ~43 ~-20 ~31 minecraft:smooth_quartz
setblock ~44 ~-20 ~31 minecraft:polished_diorite
setblock ~45 ~-20 ~31 minecraft:smooth_quartz
setblock ~46 ~-20 ~31 minecraft:polished_andesite
fill ~47 ~-20 ~31 ~49 ~-20 ~31 minecraft:white_concrete
setblock ~50 ~-20 ~31 minecraft:light_gray_concrete
fill ~51 ~-20 ~31 ~63 ~-20 ~31 minecraft:dark_oak_planks
setblock ~64 ~-20 ~31 minecraft:light_gray_concrete
fill ~4 ~-20 ~32 ~21 ~-20 ~32 minecraft:light_gray_concrete
setblock ~22 ~-20 ~32 minecraft:polished_andesite
setblock ~23 ~-20 ~32 minecraft:smooth_quartz
setblock ~24 ~-20 ~32 minecraft:polished_diorite
setblock ~25 ~-20 ~32 minecraft:red_concrete
fill ~26 ~-20 ~32 ~31 ~-20 ~32 minecraft:air
setblock ~32 ~-20 ~32 minecraft:iron_block
fill ~33 ~-20 ~32 ~35 ~-20 ~32 minecraft:glass
fill ~36 ~-20 ~32 ~42 ~-20 ~32 minecraft:iron_block
setblock ~43 ~-20 ~32 minecraft:red_concrete
setblock ~44 ~-20 ~32 minecraft:polished_diorite
setblock ~45 ~-20 ~32 minecraft:smooth_quartz
setblock ~46 ~-20 ~32 minecraft:polished_andesite
fill ~47 ~-20 ~32 ~64 ~-20 ~32 minecraft:light_gray_concrete
setblock ~4 ~-20 ~33 minecraft:light_gray_concrete
fill ~5 ~-20 ~33 ~21 ~-20 ~33 minecraft:white_concrete
fill ~22 ~-20 ~33 ~23 ~-20 ~33 minecraft:smooth_quartz
setblock ~24 ~-20 ~33 minecraft:polished_diorite
setblock ~25 ~-20 ~33 minecraft:red_concrete
fill ~26 ~-20 ~33 ~31 ~-20 ~33 minecraft:air
setblock ~32 ~-20 ~33 minecraft:iron_block
setblock ~33 ~-20 ~33 minecraft:glass
setblock ~34 ~-20 ~33 minecraft:air
setblock ~35 ~-20 ~33 minecraft:glass
setblock ~36 ~-20 ~33 minecraft:iron_block
fill ~37 ~-20 ~33 ~42 ~-20 ~33 minecraft:polished_andesite
setblock ~43 ~-20 ~33 minecraft:red_concrete
setblock ~44 ~-20 ~33 minecraft:polished_diorite
fill ~45 ~-20 ~33 ~46 ~-20 ~33 minecraft:smooth_quartz
fill ~47 ~-20 ~33 ~63 ~-20 ~33 minecraft:white_concrete
setblock ~64 ~-20 ~33 minecraft:light_gray_concrete
setblock ~4 ~-20 ~34 minecraft:light_gray_concrete
fill ~5 ~-20 ~34 ~20 ~-20 ~34 minecraft:red_concrete
fill ~21 ~-20 ~34 ~22 ~-20 ~34 minecraft:smooth_quartz
setblock ~23 ~-20 ~34 minecraft:polished_diorite
setblock ~24 ~-20 ~34 minecraft:smooth_quartz
setblock ~25 ~-20 ~34 minecraft:red_concrete
fill ~26 ~-20 ~34 ~31 ~-20 ~34 minecraft:air
setblock ~32 ~-20 ~34 minecraft:iron_block
fill ~33 ~-20 ~34 ~35 ~-20 ~34 minecraft:glass
setblock ~36 ~-20 ~34 minecraft:iron_block
fill ~37 ~-20 ~34 ~42 ~-20 ~34 minecraft:polished_andesite
setblock ~43 ~-20 ~34 minecraft:red_concrete
setblock ~44 ~-20 ~34 minecraft:smooth_quartz
setblock ~45 ~-20 ~34 minecraft:polished_diorite
fill ~46 ~-20 ~34 ~47 ~-20 ~34 minecraft:smooth_quartz
fill ~48 ~-20 ~34 ~63 ~-20 ~34 minecraft:red_concrete
setblock ~64 ~-20 ~34 minecraft:light_gray_concrete
setblock ~4 ~-20 ~35 minecraft:light_gray_concrete
fill ~5 ~-20 ~35 ~21 ~-20 ~35 minecraft:white_concrete
fill ~22 ~-20 ~35 ~23 ~-20 ~35 minecraft:smooth_quartz
setblock ~24 ~-20 ~35 minecraft:polished_diorite
setblock ~25 ~-20 ~35 minecraft:red_concrete
fill ~26 ~-20 ~35 ~31 ~-20 ~35 minecraft:air
setblock ~32 ~-20 ~35 minecraft:iron_block
setblock ~33 ~-20 ~35 minecraft:glass
setblock ~34 ~-20 ~35 minecraft:air
setblock ~35 ~-20 ~35 minecraft:glass
setblock ~36 ~-20 ~35 minecraft:iron_block
fill ~37 ~-20 ~35 ~42 ~-20 ~35 minecraft:polished_andesite
setblock ~43 ~-20 ~35 minecraft:red_concrete
setblock ~44 ~-20 ~35 minecraft:polished_diorite
fill ~45 ~-20 ~35 ~46 ~-20 ~35 minecraft:smooth_quartz
fill ~47 ~-20 ~35 ~63 ~-20 ~35 minecraft:white_concrete
setblock ~64 ~-20 ~35 minecraft:light_gray_concrete
fill ~4 ~-20 ~36 ~21 ~-20 ~36 minecraft:light_gray_concrete
setblock ~22 ~-20 ~36 minecraft:polished_andesite
setblock ~23 ~-20 ~36 minecraft:smooth_quartz
setblock ~24 ~-20 ~36 minecraft:polished_diorite
setblock ~25 ~-20 ~36 minecraft:red_concrete
fill ~26 ~-20 ~36 ~31 ~-20 ~36 minecraft:air
setblock ~32 ~-20 ~36 minecraft:iron_block
fill ~33 ~-20 ~36 ~35 ~-20 ~36 minecraft:glass
fill ~36 ~-20 ~36 ~42 ~-20 ~36 minecraft:iron_block
setblock ~43 ~-20 ~36 minecraft:red_concrete
setblock ~44 ~-20 ~36 minecraft:polished_diorite
setblock ~45 ~-20 ~36 minecraft:smooth_quartz
setblock ~46 ~-20 ~36 minecraft:polished_andesite
fill ~47 ~-20 ~36 ~64 ~-20 ~36 minecraft:light_gray_concrete
setblock ~4 ~-20 ~37 minecraft:light_gray_concrete
fill ~5 ~-20 ~37 ~17 ~-20 ~37 minecraft:white_concrete
setblock ~18 ~-20 ~37 minecraft:light_gray_concrete
fill ~19 ~-20 ~37 ~21 ~-20 ~37 minecraft:white_concrete
setblock ~22 ~-20 ~37 minecraft:polished_andesite
setblock ~23 ~-20 ~37 minecraft:smooth_quartz
setblock ~24 ~-20 ~37 minecraft:polished_diorite
setblock ~25 ~-20 ~37 minecraft:smooth_quartz
setblock ~26 ~-20 ~37 minecraft:red_concrete
fill ~27 ~-20 ~37 ~31 ~-20 ~37 minecraft:air
fill ~32 ~-20 ~37 ~36 ~-20 ~37 minecraft:iron_block
fill ~37 ~-20 ~37 ~41 ~-20 ~37 minecraft:air
setblock ~42 ~-20 ~37 minecraft:red_concrete
setblock ~43 ~-20 ~37 minecraft:smooth_quartz
setblock ~44 ~-20 ~37 minecraft:polished_diorite
setblock ~45 ~-20 ~37 minecraft:smooth_quartz
setblock ~46 ~-20 ~37 minecraft:polished_andesite
fill ~47 ~-20 ~37 ~49 ~-20 ~37 minecraft:spruce_planks
setblock ~50 ~-20 ~37 minecraft:light_gray_concrete
fill ~51 ~-20 ~37 ~63 ~-20 ~37 minecraft:white_concrete
setblock ~64 ~-20 ~37 minecraft:light_gray_concrete
setblock ~4 ~-20 ~38 minecraft:light_gray_concrete
fill ~5 ~-20 ~38 ~7 ~-20 ~38 minecraft:polished_andesite
fill ~8 ~-20 ~38 ~17 ~-20 ~38 minecraft:white_concrete
setblock ~18 ~-20 ~38 minecraft:light_gray_concrete
fill ~19 ~-20 ~38 ~21 ~-20 ~38 minecraft:white_concrete
setblock ~22 ~-20 ~38 minecraft:polished_andesite
setblock ~23 ~-20 ~38 minecraft:smooth_quartz
setblock ~24 ~-20 ~38 minecraft:polished_diorite
setblock ~25 ~-20 ~38 minecraft:smooth_quartz
setblock ~26 ~-20 ~38 minecraft:red_concrete
fill ~27 ~-20 ~38 ~41 ~-20 ~38 minecraft:air
setblock ~42 ~-20 ~38 minecraft:red_concrete
setblock ~43 ~-20 ~38 minecraft:smooth_quartz
setblock ~44 ~-20 ~38 minecraft:polished_diorite
setblock ~45 ~-20 ~38 minecraft:smooth_quartz
setblock ~46 ~-20 ~38 minecraft:polished_andesite
fill ~47 ~-20 ~38 ~49 ~-20 ~38 minecraft:spruce_planks
setblock ~50 ~-20 ~38 minecraft:light_gray_concrete
fill ~51 ~-20 ~38 ~63 ~-20 ~38 minecraft:white_concrete
setblock ~64 ~-20 ~38 minecraft:light_gray_concrete
setblock ~4 ~-20 ~39 minecraft:light_gray_concrete
fill ~5 ~-20 ~39 ~7 ~-20 ~39 minecraft:polished_andesite
fill ~8 ~-20 ~39 ~17 ~-20 ~39 minecraft:white_concrete
setblock ~18 ~-20 ~39 minecraft:light_gray_concrete
fill ~19 ~-20 ~39 ~21 ~-20 ~39 minecraft:white_concrete
fill ~22 ~-20 ~39 ~23 ~-20 ~39 minecraft:polished_andesite
setblock ~24 ~-20 ~39 minecraft:smooth_quartz
setblock ~25 ~-20 ~39 minecraft:polished_diorite
setblock ~26 ~-20 ~39 minecraft:smooth_quartz
setblock ~27 ~-20 ~39 minecraft:red_concrete
fill ~28 ~-20 ~39 ~40 ~-20 ~39 minecraft:air
setblock ~41 ~-20 ~39 minecraft:red_concrete
setblock ~42 ~-20 ~39 minecraft:smooth_quartz
setblock ~43 ~-20 ~39 minecraft:polished_diorite
setblock ~44 ~-20 ~39 minecraft:smooth_quartz
fill ~45 ~-20 ~39 ~46 ~-20 ~39 minecraft:polished_andesite
fill ~47 ~-20 ~39 ~49 ~-20 ~39 minecraft:spruce_planks
setblock ~50 ~-20 ~39 minecraft:light_gray_concrete
fill ~51 ~-20 ~39 ~63 ~-20 ~39 minecraft:white_concrete
setblock ~64 ~-20 ~39 minecraft:light_gray_concrete
setblock ~4 ~-20 ~40 minecraft:light_gray_concrete
fill ~5 ~-20 ~40 ~7 ~-20 ~40 minecraft:polished_andesite
fill ~8 ~-20 ~40 ~17 ~-20 ~40 minecraft:white_concrete
setblock ~18 ~-20 ~40 minecraft:light_gray_concrete
fill ~19 ~-20 ~40 ~22 ~-20 ~40 minecraft:white_concrete
setblock ~23 ~-20 ~40 minecraft:polished_andesite
setblock ~24 ~-20 ~40 minecraft:smooth_quartz
setblock ~25 ~-20 ~40 minecraft:polished_diorite
setblock ~26 ~-20 ~40 minecraft:smooth_quartz
setblock ~27 ~-20 ~40 minecraft:red_concrete
fill ~28 ~-20 ~40 ~40 ~-20 ~40 minecraft:air
setblock ~41 ~-20 ~40 minecraft:red_concrete
setblock ~42 ~-20 ~40 minecraft:smooth_quartz
setblock ~43 ~-20 ~40 minecraft:polished_diorite
setblock ~44 ~-20 ~40 minecraft:smooth_quartz
setblock ~45 ~-20 ~40 minecraft:polished_andesite
fill ~46 ~-20 ~40 ~49 ~-20 ~40 minecraft:spruce_planks
setblock ~50 ~-20 ~40 minecraft:light_gray_concrete
fill ~51 ~-20 ~40 ~63 ~-20 ~40 minecraft:white_concrete
setblock ~64 ~-20 ~40 minecraft:light_gray_concrete
setblock ~4 ~-20 ~41 minecraft:light_gray_concrete
fill ~5 ~-20 ~41 ~17 ~-20 ~41 minecraft:white_concrete
setblock ~18 ~-20 ~41 minecraft:light_gray_concrete
fill ~19 ~-20 ~41 ~23 ~-20 ~41 minecraft:white_concrete
setblock ~24 ~-20 ~41 minecraft:polished_andesite
setblock ~25 ~-20 ~41 minecraft:smooth_quartz
setblock ~26 ~-20 ~41 minecraft:polished_diorite
setblock ~27 ~-20 ~41 minecraft:smooth_quartz
fill ~28 ~-20 ~41 ~29 ~-20 ~41 minecraft:red_concrete
fill ~30 ~-20 ~41 ~38 ~-20 ~41 minecraft:air
fill ~39 ~-20 ~41 ~40 ~-20 ~41 minecraft:red_concrete
setblock ~41 ~-20 ~41 minecraft:smooth_quartz
setblock ~42 ~-20 ~41 minecraft:polished_diorite
setblock ~43 ~-20 ~41 minecraft:smooth_quartz
setblock ~44 ~-20 ~41 minecraft:polished_andesite
fill ~45 ~-20 ~41 ~49 ~-20 ~41 minecraft:spruce_planks
setblock ~50 ~-20 ~41 minecraft:light_gray_concrete
fill ~51 ~-20 ~41 ~63 ~-20 ~41 minecraft:white_concrete
setblock ~64 ~-20 ~41 minecraft:light_gray_concrete
setblock ~4 ~-20 ~42 minecraft:light_gray_concrete
fill ~5 ~-20 ~42 ~7 ~-20 ~42 minecraft:polished_andesite
fill ~8 ~-20 ~42 ~17 ~-20 ~42 minecraft:white_concrete
setblock ~18 ~-20 ~42 minecraft:light_gray_concrete
fill ~19 ~-20 ~42 ~23 ~-20 ~42 minecraft:white_concrete
fill ~24 ~-20 ~42 ~25 ~-20 ~42 minecraft:polished_andesite
setblock ~26 ~-20 ~42 minecraft:smooth_quartz
setblock ~27 ~-20 ~42 minecraft:polished_diorite
fill ~28 ~-20 ~42 ~29 ~-20 ~42 minecraft:smooth_quartz
fill ~30 ~-20 ~42 ~31 ~-20 ~42 minecraft:red_concrete
fill ~32 ~-20 ~42 ~36 ~-20 ~42 minecraft:air
fill ~37 ~-20 ~42 ~38 ~-20 ~42 minecraft:red_concrete
fill ~39 ~-20 ~42 ~40 ~-20 ~42 minecraft:smooth_quartz
setblock ~41 ~-20 ~42 minecraft:polished_diorite
setblock ~42 ~-20 ~42 minecraft:smooth_quartz
fill ~43 ~-20 ~42 ~44 ~-20 ~42 minecraft:polished_andesite
fill ~45 ~-20 ~42 ~49 ~-20 ~42 minecraft:spruce_planks
setblock ~50 ~-20 ~42 minecraft:light_gray_concrete
fill ~51 ~-20 ~42 ~63 ~-20 ~42 minecraft:white_concrete
setblock ~64 ~-20 ~42 minecraft:light_gray_concrete
setblock ~4 ~-20 ~43 minecraft:light_gray_concrete
fill ~5 ~-20 ~43 ~7 ~-20 ~43 minecraft:polished_andesite
fill ~8 ~-20 ~43 ~17 ~-20 ~43 minecraft:white_concrete
setblock ~18 ~-20 ~43 minecraft:light_gray_concrete
fill ~19 ~-20 ~43 ~24 ~-20 ~43 minecraft:white_concrete
fill ~25 ~-20 ~43 ~26 ~-20 ~43 minecraft:polished_andesite
setblock ~27 ~-20 ~43 minecraft:smooth_quartz
fill ~28 ~-20 ~43 ~29 ~-20 ~43 minecraft:polished_diorite
fill ~30 ~-20 ~43 ~31 ~-20 ~43 minecraft:smooth_quartz
fill ~32 ~-20 ~43 ~36 ~-20 ~43 minecraft:red_concrete
fill ~37 ~-20 ~43 ~38 ~-20 ~43 minecraft:smooth_quartz
fill ~39 ~-20 ~43 ~40 ~-20 ~43 minecraft:polished_diorite
setblock ~41 ~-20 ~43 minecraft:smooth_quartz
fill ~42 ~-20 ~43 ~43 ~-20 ~43 minecraft:polished_andesite
fill ~44 ~-20 ~43 ~49 ~-20 ~43 minecraft:spruce_planks
setblock ~50 ~-20 ~43 minecraft:light_gray_concrete
fill ~51 ~-20 ~43 ~63 ~-20 ~43 minecraft:white_concrete
setblock ~64 ~-20 ~43 minecraft:light_gray_concrete
setblock ~4 ~-20 ~44 minecraft:light_gray_concrete
fill ~5 ~-20 ~44 ~7 ~-20 ~44 minecraft:polished_andesite
fill ~8 ~-20 ~44 ~17 ~-20 ~44 minecraft:white_concrete
setblock ~18 ~-20 ~44 minecraft:light_gray_concrete
fill ~19 ~-20 ~44 ~25 ~-20 ~44 minecraft:white_concrete
fill ~26 ~-20 ~44 ~27 ~-20 ~44 minecraft:polished_andesite
fill ~28 ~-20 ~44 ~29 ~-20 ~44 minecraft:smooth_quartz
fill ~30 ~-20 ~44 ~33 ~-20 ~44 minecraft:polished_diorite
setblock ~34 ~-20 ~44 minecraft:smooth_quartz
fill ~35 ~-20 ~44 ~38 ~-20 ~44 minecraft:polished_diorite
fill ~39 ~-20 ~44 ~40 ~-20 ~44 minecraft:smooth_quartz
fill ~41 ~-20 ~44 ~42 ~-20 ~44 minecraft:polished_andesite
fill ~43 ~-20 ~44 ~49 ~-20 ~44 minecraft:spruce_planks
setblock ~50 ~-20 ~44 minecraft:light_gray_concrete
fill ~51 ~-20 ~44 ~63 ~-20 ~44 minecraft:white_concrete
setblock ~64 ~-20 ~44 minecraft:light_gray_concrete
setblock ~4 ~-20 ~45 minecraft:light_gray_concrete
fill ~5 ~-20 ~45 ~17 ~-20 ~45 minecraft:white_concrete
setblock ~18 ~-20 ~45 minecraft:light_gray_concrete
fill ~19 ~-20 ~45 ~27 ~-20 ~45 minecraft:white_concrete
fill ~28 ~-20 ~45 ~29 ~-20 ~45 minecraft:polished_andesite
fill ~30 ~-20 ~45 ~33 ~-20 ~45 minecraft:smooth_quartz
setblock ~34 ~-20 ~45 minecraft:polished_diorite
fill ~35 ~-20 ~45 ~38 ~-20 ~45 minecraft:smooth_quartz
fill ~39 ~-20 ~45 ~40 ~-20 ~45 minecraft:polished_andesite
fill ~41 ~-20 ~45 ~49 ~-20 ~45 minecraft:spruce_planks
setblock ~50 ~-20 ~45 minecraft:light_gray_concrete
fill ~51 ~-20 ~45 ~63 ~-20 ~45 minecraft:white_concrete
setblock ~64 ~-20 ~45 minecraft:light_gray_concrete
setblock ~4 ~-20 ~46 minecraft:light_gray_concrete
fill ~5 ~-20 ~46 ~7 ~-20 ~46 minecraft:polished_andesite
fill ~8 ~-20 ~46 ~17 ~-20 ~46 minecraft:white_concrete
setblock ~18 ~-20 ~46 minecraft:light_gray_concrete
fill ~19 ~-20 ~46 ~28 ~-20 ~46 minecraft:white_concrete
fill ~29 ~-20 ~46 ~32 ~-20 ~46 minecraft:polished_andesite
fill ~33 ~-20 ~46 ~35 ~-20 ~46 minecraft:smooth_quartz
fill ~36 ~-20 ~46 ~39 ~-20 ~46 minecraft:polished_andesite
fill ~40 ~-20 ~46 ~49 ~-20 ~46 minecraft:spruce_planks
setblock ~50 ~-20 ~46 minecraft:light_gray_concrete
fill ~51 ~-20 ~46 ~63 ~-20 ~46 minecraft:white_concrete
setblock ~64 ~-20 ~46 minecraft:light_gray_concrete
setblock ~4 ~-20 ~47 minecraft:light_gray_concrete
fill ~5 ~-20 ~47 ~7 ~-20 ~47 minecraft:polished_andesite
fill ~8 ~-20 ~47 ~17 ~-20 ~47 minecraft:white_concrete
setblock ~18 ~-20 ~47 minecraft:light_gray_concrete
fill ~19 ~-20 ~47 ~31 ~-20 ~47 minecraft:white_concrete
setblock ~32 ~-20 ~47 minecraft:light_gray_concrete
setblock ~33 ~-20 ~47 minecraft:white_concrete
setblock ~34 ~-20 ~47 minecraft:smooth_quartz
setblock ~35 ~-20 ~47 minecraft:white_concrete
setblock ~36 ~-20 ~47 minecraft:light_gray_concrete
fill ~37 ~-20 ~47 ~49 ~-20 ~47 minecraft:spruce_planks
setblock ~50 ~-20 ~47 minecraft:light_gray_concrete
fill ~51 ~-20 ~47 ~63 ~-20 ~47 minecraft:white_concrete
setblock ~64 ~-20 ~47 minecraft:light_gray_concrete
setblock ~4 ~-20 ~48 minecraft:light_gray_concrete
fill ~5 ~-20 ~48 ~7 ~-20 ~48 minecraft:polished_andesite
fill ~8 ~-20 ~48 ~17 ~-20 ~48 minecraft:white_concrete
setblock ~18 ~-20 ~48 minecraft:light_gray_concrete
fill ~19 ~-20 ~48 ~31 ~-20 ~48 minecraft:white_concrete
setblock ~32 ~-20 ~48 minecraft:light_gray_concrete
setblock ~33 ~-20 ~48 minecraft:white_concrete
setblock ~34 ~-20 ~48 minecraft:red_concrete
setblock ~35 ~-20 ~48 minecraft:white_concrete
setblock ~36 ~-20 ~48 minecraft:light_gray_concrete
fill ~37 ~-20 ~48 ~49 ~-20 ~48 minecraft:spruce_planks
setblock ~50 ~-20 ~48 minecraft:light_gray_concrete
fill ~51 ~-20 ~48 ~63 ~-20 ~48 minecraft:white_concrete
setblock ~64 ~-20 ~48 minecraft:light_gray_concrete
setblock ~4 ~-20 ~49 minecraft:light_gray_concrete
fill ~5 ~-20 ~49 ~17 ~-20 ~49 minecraft:white_concrete
setblock ~18 ~-20 ~49 minecraft:light_gray_concrete
fill ~19 ~-20 ~49 ~31 ~-20 ~49 minecraft:white_concrete
setblock ~32 ~-20 ~49 minecraft:light_gray_concrete
setblock ~33 ~-20 ~49 minecraft:white_concrete
setblock ~34 ~-20 ~49 minecraft:red_concrete
setblock ~35 ~-20 ~49 minecraft:white_concrete
setblock ~36 ~-20 ~49 minecraft:light_gray_concrete
fill ~37 ~-20 ~49 ~49 ~-20 ~49 minecraft:spruce_planks
setblock ~50 ~-20 ~49 minecraft:light_gray_concrete
fill ~51 ~-20 ~49 ~63 ~-20 ~49 minecraft:white_concrete
setblock ~64 ~-20 ~49 minecraft:light_gray_concrete
fill ~4 ~-20 ~50 ~32 ~-20 ~50 minecraft:light_gray_concrete
setblock ~33 ~-20 ~50 minecraft:white_concrete
setblock ~34 ~-20 ~50 minecraft:red_concrete
setblock ~35 ~-20 ~50 minecraft:white_concrete
fill ~36 ~-20 ~50 ~64 ~-20 ~50 minecraft:light_gray_concrete
setblock ~4 ~-20 ~51 minecraft:light_gray_concrete
fill ~5 ~-20 ~51 ~17 ~-20 ~51 minecraft:white_concrete
setblock ~18 ~-20 ~51 minecraft:light_gray_concrete
fill ~19 ~-20 ~51 ~31 ~-20 ~51 minecraft:white_concrete
setblock ~32 ~-20 ~51 minecraft:light_gray_concrete
setblock ~33 ~-20 ~51 minecraft:white_concrete
setblock ~34 ~-20 ~51 minecraft:red_concrete
setblock ~35 ~-20 ~51 minecraft:white_concrete
setblock ~36 ~-20 ~51 minecraft:light_gray_concrete
fill ~37 ~-20 ~51 ~49 ~-20 ~51 minecraft:white_concrete
setblock ~50 ~-20 ~51 minecraft:light_gray_concrete
fill ~51 ~-20 ~51 ~63 ~-20 ~51 minecraft:spruce_planks
setblock ~64 ~-20 ~51 minecraft:light_gray_concrete
setblock ~4 ~-20 ~52 minecraft:light_gray_concrete
fill ~5 ~-20 ~52 ~17 ~-20 ~52 minecraft:white_concrete
setblock ~18 ~-20 ~52 minecraft:light_gray_concrete
fill ~19 ~-20 ~52 ~31 ~-20 ~52 minecraft:white_concrete
setblock ~32 ~-20 ~52 minecraft:light_gray_concrete
setblock ~33 ~-20 ~52 minecraft:white_concrete
setblock ~34 ~-20 ~52 minecraft:red_concrete
setblock ~35 ~-20 ~52 minecraft:white_concrete
setblock ~36 ~-20 ~52 minecraft:light_gray_concrete
fill ~37 ~-20 ~52 ~49 ~-20 ~52 minecraft:white_concrete
setblock ~50 ~-20 ~52 minecraft:light_gray_concrete
fill ~51 ~-20 ~52 ~63 ~-20 ~52 minecraft:spruce_planks
setblock ~64 ~-20 ~52 minecraft:light_gray_concrete
setblock ~4 ~-20 ~53 minecraft:light_gray_concrete
fill ~5 ~-20 ~53 ~17 ~-20 ~53 minecraft:white_concrete
setblock ~18 ~-20 ~53 minecraft:light_gray_concrete
fill ~19 ~-20 ~53 ~31 ~-20 ~53 minecraft:white_concrete
setblock ~32 ~-20 ~53 minecraft:light_gray_concrete
setblock ~33 ~-20 ~53 minecraft:white_concrete
setblock ~34 ~-20 ~53 minecraft:red_concrete
setblock ~35 ~-20 ~53 minecraft:white_concrete
setblock ~36 ~-20 ~53 minecraft:light_gray_concrete
fill ~37 ~-20 ~53 ~49 ~-20 ~53 minecraft:white_concrete
setblock ~50 ~-20 ~53 minecraft:light_gray_concrete
fill ~51 ~-20 ~53 ~63 ~-20 ~53 minecraft:spruce_planks
setblock ~64 ~-20 ~53 minecraft:light_gray_concrete
setblock ~4 ~-20 ~54 minecraft:light_gray_concrete
fill ~5 ~-20 ~54 ~17 ~-20 ~54 minecraft:white_concrete
setblock ~18 ~-20 ~54 minecraft:light_gray_concrete
fill ~19 ~-20 ~54 ~31 ~-20 ~54 minecraft:white_concrete
setblock ~32 ~-20 ~54 minecraft:light_gray_concrete
setblock ~33 ~-20 ~54 minecraft:white_concrete
setblock ~34 ~-20 ~54 minecraft:red_concrete
setblock ~35 ~-20 ~54 minecraft:white_concrete
setblock ~36 ~-20 ~54 minecraft:light_gray_concrete
fill ~37 ~-20 ~54 ~49 ~-20 ~54 minecraft:white_concrete
setblock ~50 ~-20 ~54 minecraft:light_gray_concrete
fill ~51 ~-20 ~54 ~63 ~-20 ~54 minecraft:spruce_planks
setblock ~64 ~-20 ~54 minecraft:light_gray_concrete
setblock ~4 ~-20 ~55 minecraft:light_gray_concrete
fill ~5 ~-20 ~55 ~17 ~-20 ~55 minecraft:white_concrete
setblock ~18 ~-20 ~55 minecraft:light_gray_concrete
fill ~19 ~-20 ~55 ~31 ~-20 ~55 minecraft:white_concrete
setblock ~32 ~-20 ~55 minecraft:light_gray_concrete
setblock ~33 ~-20 ~55 minecraft:white_concrete
setblock ~34 ~-20 ~55 minecraft:red_concrete
setblock ~35 ~-20 ~55 minecraft:white_concrete
setblock ~36 ~-20 ~55 minecraft:light_gray_concrete
fill ~37 ~-20 ~55 ~49 ~-20 ~55 minecraft:white_concrete
setblock ~50 ~-20 ~55 minecraft:light_gray_concrete
fill ~51 ~-20 ~55 ~63 ~-20 ~55 minecraft:spruce_planks
setblock ~64 ~-20 ~55 minecraft:light_gray_concrete
setblock ~4 ~-20 ~56 minecraft:light_gray_concrete
fill ~5 ~-20 ~56 ~17 ~-20 ~56 minecraft:white_concrete
setblock ~18 ~-20 ~56 minecraft:light_gray_concrete
fill ~19 ~-20 ~56 ~31 ~-20 ~56 minecraft:white_concrete
setblock ~32 ~-20 ~56 minecraft:light_gray_concrete
setblock ~33 ~-20 ~56 minecraft:white_concrete
setblock ~34 ~-20 ~56 minecraft:red_concrete
setblock ~35 ~-20 ~56 minecraft:white_concrete
setblock ~36 ~-20 ~56 minecraft:light_gray_concrete
fill ~37 ~-20 ~56 ~49 ~-20 ~56 minecraft:white_concrete
setblock ~50 ~-20 ~56 minecraft:light_gray_concrete
fill ~51 ~-20 ~56 ~63 ~-20 ~56 minecraft:spruce_planks
setblock ~64 ~-20 ~56 minecraft:light_gray_concrete
setblock ~4 ~-20 ~57 minecraft:light_gray_concrete
fill ~5 ~-20 ~57 ~17 ~-20 ~57 minecraft:white_concrete
setblock ~18 ~-20 ~57 minecraft:light_gray_concrete
fill ~19 ~-20 ~57 ~31 ~-20 ~57 minecraft:white_concrete
setblock ~32 ~-20 ~57 minecraft:light_gray_concrete
setblock ~33 ~-20 ~57 minecraft:white_concrete
setblock ~34 ~-20 ~57 minecraft:red_concrete
setblock ~35 ~-20 ~57 minecraft:white_concrete
setblock ~36 ~-20 ~57 minecraft:light_gray_concrete
fill ~37 ~-20 ~57 ~49 ~-20 ~57 minecraft:white_concrete
setblock ~50 ~-20 ~57 minecraft:light_gray_concrete
fill ~51 ~-20 ~57 ~63 ~-20 ~57 minecraft:spruce_planks
setblock ~64 ~-20 ~57 minecraft:light_gray_concrete
setblock ~4 ~-20 ~58 minecraft:light_gray_concrete
fill ~5 ~-20 ~58 ~17 ~-20 ~58 minecraft:white_concrete
setblock ~18 ~-20 ~58 minecraft:light_gray_concrete
fill ~19 ~-20 ~58 ~31 ~-20 ~58 minecraft:white_concrete
setblock ~32 ~-20 ~58 minecraft:light_gray_concrete
setblock ~33 ~-20 ~58 minecraft:white_concrete
setblock ~34 ~-20 ~58 minecraft:red_concrete
setblock ~35 ~-20 ~58 minecraft:white_concrete
setblock ~36 ~-20 ~58 minecraft:light_gray_concrete
fill ~37 ~-20 ~58 ~49 ~-20 ~58 minecraft:white_concrete
setblock ~50 ~-20 ~58 minecraft:light_gray_concrete
fill ~51 ~-20 ~58 ~63 ~-20 ~58 minecraft:spruce_planks
setblock ~64 ~-20 ~58 minecraft:light_gray_concrete
setblock ~4 ~-20 ~59 minecraft:light_gray_concrete
fill ~5 ~-20 ~59 ~17 ~-20 ~59 minecraft:white_concrete
setblock ~18 ~-20 ~59 minecraft:light_gray_concrete
fill ~19 ~-20 ~59 ~31 ~-20 ~59 minecraft:white_concrete
setblock ~32 ~-20 ~59 minecraft:light_gray_concrete
setblock ~33 ~-20 ~59 minecraft:white_concrete
setblock ~34 ~-20 ~59 minecraft:red_concrete
setblock ~35 ~-20 ~59 minecraft:white_concrete
setblock ~36 ~-20 ~59 minecraft:light_gray_concrete
fill ~37 ~-20 ~59 ~49 ~-20 ~59 minecraft:white_concrete
setblock ~50 ~-20 ~59 minecraft:light_gray_concrete
fill ~51 ~-20 ~59 ~63 ~-20 ~59 minecraft:spruce_planks
setblock ~64 ~-20 ~59 minecraft:light_gray_concrete
setblock ~4 ~-20 ~60 minecraft:light_gray_concrete
fill ~5 ~-20 ~60 ~17 ~-20 ~60 minecraft:white_concrete
setblock ~18 ~-20 ~60 minecraft:light_gray_concrete
fill ~19 ~-20 ~60 ~31 ~-20 ~60 minecraft:white_concrete
setblock ~32 ~-20 ~60 minecraft:light_gray_concrete
setblock ~33 ~-20 ~60 minecraft:white_concrete
setblock ~34 ~-20 ~60 minecraft:red_concrete
setblock ~35 ~-20 ~60 minecraft:white_concrete
setblock ~36 ~-20 ~60 minecraft:light_gray_concrete
fill ~37 ~-20 ~60 ~49 ~-20 ~60 minecraft:white_concrete
setblock ~50 ~-20 ~60 minecraft:light_gray_concrete
fill ~51 ~-20 ~60 ~63 ~-20 ~60 minecraft:spruce_planks
setblock ~64 ~-20 ~60 minecraft:light_gray_concrete
setblock ~4 ~-20 ~61 minecraft:light_gray_concrete
fill ~5 ~-20 ~61 ~17 ~-20 ~61 minecraft:white_concrete
setblock ~18 ~-20 ~61 minecraft:light_gray_concrete
fill ~19 ~-20 ~61 ~31 ~-20 ~61 minecraft:white_concrete
setblock ~32 ~-20 ~61 minecraft:light_gray_concrete
setblock ~33 ~-20 ~61 minecraft:white_concrete
setblock ~34 ~-20 ~61 minecraft:red_concrete
setblock ~35 ~-20 ~61 minecraft:white_concrete
setblock ~36 ~-20 ~61 minecraft:light_gray_concrete
fill ~37 ~-20 ~61 ~49 ~-20 ~61 minecraft:white_concrete
setblock ~50 ~-20 ~61 minecraft:light_gray_concrete
fill ~51 ~-20 ~61 ~63 ~-20 ~61 minecraft:spruce_planks
setblock ~64 ~-20 ~61 minecraft:light_gray_concrete
setblock ~4 ~-20 ~62 minecraft:light_gray_concrete
fill ~5 ~-20 ~62 ~17 ~-20 ~62 minecraft:white_concrete
setblock ~18 ~-20 ~62 minecraft:light_gray_concrete
fill ~19 ~-20 ~62 ~31 ~-20 ~62 minecraft:white_concrete
setblock ~32 ~-20 ~62 minecraft:light_gray_concrete
setblock ~33 ~-20 ~62 minecraft:white_concrete
setblock ~34 ~-20 ~62 minecraft:red_concrete
setblock ~35 ~-20 ~62 minecraft:white_concrete
setblock ~36 ~-20 ~62 minecraft:light_gray_concrete
fill ~37 ~-20 ~62 ~49 ~-20 ~62 minecraft:white_concrete
setblock ~50 ~-20 ~62 minecraft:light_gray_concrete
fill ~51 ~-20 ~62 ~63 ~-20 ~62 minecraft:spruce_planks
setblock ~64 ~-20 ~62 minecraft:light_gray_concrete
setblock ~4 ~-20 ~63 minecraft:light_gray_concrete
fill ~5 ~-20 ~63 ~17 ~-20 ~63 minecraft:white_concrete
setblock ~18 ~-20 ~63 minecraft:light_gray_concrete
fill ~19 ~-20 ~63 ~31 ~-20 ~63 minecraft:white_concrete
setblock ~32 ~-20 ~63 minecraft:light_gray_concrete
setblock ~33 ~-20 ~63 minecraft:white_concrete
setblock ~34 ~-20 ~63 minecraft:red_concrete
setblock ~35 ~-20 ~63 minecraft:white_concrete
setblock ~36 ~-20 ~63 minecraft:light_gray_concrete
fill ~37 ~-20 ~63 ~49 ~-20 ~63 minecraft:white_concrete
setblock ~50 ~-20 ~63 minecraft:light_gray_concrete
fill ~51 ~-20 ~63 ~63 ~-20 ~63 minecraft:spruce_planks
setblock ~64 ~-20 ~63 minecraft:light_gray_concrete
fill ~4 ~-20 ~64 ~64 ~-20 ~64 minecraft:light_gray_concrete
setblock ~34 ~-20 ~65 minecraft:white_concrete
fill ~32 ~-20 ~66 ~36 ~-20 ~66 minecraft:polished_andesite
setblock ~32 ~-20 ~67 minecraft:polished_andesite
setblock ~33 ~-20 ~67 minecraft:air
setblock ~34 ~-20 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-20 ~67 minecraft:air
setblock ~36 ~-20 ~67 minecraft:polished_andesite
setblock ~32 ~-20 ~68 minecraft:polished_andesite
setblock ~33 ~-20 ~68 minecraft:air
setblock ~34 ~-20 ~68 minecraft:quartz_pillar
setblock ~35 ~-20 ~68 minecraft:air
setblock ~36 ~-20 ~68 minecraft:polished_andesite
setblock ~32 ~-20 ~69 minecraft:polished_andesite
fill ~33 ~-20 ~69 ~35 ~-20 ~69 minecraft:air
setblock ~36 ~-20 ~69 minecraft:polished_andesite
fill ~32 ~-20 ~70 ~36 ~-20 ~70 minecraft:polished_andesite
fill ~4 ~-19 ~4 ~64 ~-19 ~4 minecraft:light_gray_concrete
setblock ~4 ~-19 ~5 minecraft:light_gray_concrete
setblock ~5 ~-19 ~5 minecraft:barrel
fill ~6 ~-19 ~5 ~7 ~-19 ~5 minecraft:air
setblock ~8 ~-19 ~5 minecraft:barrel
fill ~9 ~-19 ~5 ~10 ~-19 ~5 minecraft:air
setblock ~11 ~-19 ~5 minecraft:barrel
fill ~12 ~-19 ~5 ~13 ~-19 ~5 minecraft:air
setblock ~14 ~-19 ~5 minecraft:barrel
fill ~15 ~-19 ~5 ~16 ~-19 ~5 minecraft:air
setblock ~17 ~-19 ~5 minecraft:barrel
setblock ~18 ~-19 ~5 minecraft:light_gray_concrete
setblock ~19 ~-19 ~5 minecraft:air
fill ~20 ~-19 ~5 ~23 ~-19 ~5 minecraft:barrel
setblock ~24 ~-19 ~5 minecraft:air
fill ~25 ~-19 ~5 ~28 ~-19 ~5 minecraft:barrel
setblock ~29 ~-19 ~5 minecraft:air
fill ~30 ~-19 ~5 ~31 ~-19 ~5 minecraft:barrel
setblock ~32 ~-19 ~5 minecraft:light_gray_concrete
fill ~33 ~-19 ~5 ~35 ~-19 ~5 minecraft:air
setblock ~36 ~-19 ~5 minecraft:light_gray_concrete
setblock ~37 ~-19 ~5 minecraft:smoker[facing=south]
setblock ~38 ~-19 ~5 minecraft:furnace[facing=south]
setblock ~39 ~-19 ~5 minecraft:barrel
setblock ~40 ~-19 ~5 minecraft:cauldron
setblock ~41 ~-19 ~5 minecraft:crafting_table
fill ~42 ~-19 ~5 ~43 ~-19 ~5 minecraft:smoker[facing=south]
setblock ~44 ~-19 ~5 minecraft:furnace[facing=south]
setblock ~45 ~-19 ~5 minecraft:barrel
setblock ~46 ~-19 ~5 minecraft:cauldron
setblock ~47 ~-19 ~5 minecraft:crafting_table
fill ~48 ~-19 ~5 ~49 ~-19 ~5 minecraft:smoker[facing=south]
setblock ~50 ~-19 ~5 minecraft:light_gray_concrete
setblock ~51 ~-19 ~5 minecraft:cauldron
setblock ~52 ~-19 ~5 minecraft:smoker[facing=south]
setblock ~53 ~-19 ~5 minecraft:barrel
setblock ~54 ~-19 ~5 minecraft:cauldron
setblock ~55 ~-19 ~5 minecraft:smoker[facing=south]
setblock ~56 ~-19 ~5 minecraft:barrel
setblock ~57 ~-19 ~5 minecraft:cauldron
setblock ~58 ~-19 ~5 minecraft:smoker[facing=south]
setblock ~59 ~-19 ~5 minecraft:barrel
setblock ~60 ~-19 ~5 minecraft:cauldron
setblock ~61 ~-19 ~5 minecraft:smoker[facing=south]
setblock ~62 ~-19 ~5 minecraft:barrel
setblock ~63 ~-19 ~5 minecraft:cauldron
setblock ~64 ~-19 ~5 minecraft:light_gray_concrete
setblock ~4 ~-19 ~6 minecraft:light_gray_concrete
fill ~5 ~-19 ~6 ~17 ~-19 ~6 minecraft:air
setblock ~18 ~-19 ~6 minecraft:light_gray_concrete
setblock ~19 ~-19 ~6 minecraft:barrel
fill ~20 ~-19 ~6 ~30 ~-19 ~6 minecraft:air
setblock ~31 ~-19 ~6 minecraft:barrel
setblock ~32 ~-19 ~6 minecraft:light_gray_concrete
fill ~33 ~-19 ~6 ~35 ~-19 ~6 minecraft:air
setblock ~36 ~-19 ~6 minecraft:light_gray_concrete
setblock ~37 ~-19 ~6 minecraft:furnace[facing=east]
fill ~38 ~-19 ~6 ~48 ~-19 ~6 minecraft:air
setblock ~49 ~-19 ~6 minecraft:furnace[facing=west]
setblock ~50 ~-19 ~6 minecraft:light_gray_concrete
fill ~51 ~-19 ~6 ~63 ~-19 ~6 minecraft:air
setblock ~64 ~-19 ~6 minecraft:light_gray_concrete
setblock ~4 ~-19 ~7 minecraft:light_gray_concrete
fill ~5 ~-19 ~7 ~17 ~-19 ~7 minecraft:air
setblock ~18 ~-19 ~7 minecraft:light_gray_concrete
setblock ~19 ~-19 ~7 minecraft:barrel
fill ~20 ~-19 ~7 ~30 ~-19 ~7 minecraft:air
setblock ~31 ~-19 ~7 minecraft:barrel
setblock ~32 ~-19 ~7 minecraft:light_gray_concrete
fill ~33 ~-19 ~7 ~35 ~-19 ~7 minecraft:air
setblock ~36 ~-19 ~7 minecraft:light_gray_concrete
setblock ~37 ~-19 ~7 minecraft:barrel
fill ~38 ~-19 ~7 ~48 ~-19 ~7 minecraft:air
setblock ~49 ~-19 ~7 minecraft:barrel
setblock ~50 ~-19 ~7 minecraft:light_gray_concrete
fill ~51 ~-19 ~7 ~52 ~-19 ~7 minecraft:air
fill ~53 ~-19 ~7 ~56 ~-19 ~7 minecraft:spruce_stairs[facing=north,half=bottom]
setblock ~57 ~-19 ~7 minecraft:air
fill ~58 ~-19 ~7 ~61 ~-19 ~7 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~62 ~-19 ~7 ~63 ~-19 ~7 minecraft:air
setblock ~64 ~-19 ~7 minecraft:light_gray_concrete
setblock ~4 ~-19 ~8 minecraft:light_gray_concrete
setblock ~5 ~-19 ~8 minecraft:barrel
fill ~6 ~-19 ~8 ~7 ~-19 ~8 minecraft:air
fill ~8 ~-19 ~8 ~14 ~-19 ~8 minecraft:light_gray_carpet
fill ~15 ~-19 ~8 ~16 ~-19 ~8 minecraft:air
setblock ~17 ~-19 ~8 minecraft:barrel
setblock ~18 ~-19 ~8 minecraft:light_gray_concrete
setblock ~19 ~-19 ~8 minecraft:barrel
setblock ~20 ~-19 ~8 minecraft:air
fill ~21 ~-19 ~8 ~24 ~-19 ~8 minecraft:spruce_slab
setblock ~25 ~-19 ~8 minecraft:air
fill ~26 ~-19 ~8 ~29 ~-19 ~8 minecraft:spruce_slab
fill ~30 ~-19 ~8 ~31 ~-19 ~8 minecraft:air
setblock ~32 ~-19 ~8 minecraft:light_gray_concrete
fill ~33 ~-19 ~8 ~35 ~-19 ~8 minecraft:air
setblock ~36 ~-19 ~8 minecraft:light_gray_concrete
setblock ~37 ~-19 ~8 minecraft:cauldron
fill ~38 ~-19 ~8 ~48 ~-19 ~8 minecraft:air
setblock ~49 ~-19 ~8 minecraft:cauldron
setblock ~50 ~-19 ~8 minecraft:light_gray_concrete
fill ~51 ~-19 ~8 ~52 ~-19 ~8 minecraft:air
fill ~53 ~-19 ~8 ~56 ~-19 ~8 minecraft:spruce_slab[type=top]
setblock ~57 ~-19 ~8 minecraft:air
fill ~58 ~-19 ~8 ~61 ~-19 ~8 minecraft:spruce_slab[type=top]
fill ~62 ~-19 ~8 ~63 ~-19 ~8 minecraft:air
setblock ~64 ~-19 ~8 minecraft:light_gray_concrete
setblock ~4 ~-19 ~9 minecraft:light_gray_concrete
fill ~5 ~-19 ~9 ~7 ~-19 ~9 minecraft:air
fill ~8 ~-19 ~9 ~14 ~-19 ~9 minecraft:light_gray_carpet
fill ~15 ~-19 ~9 ~17 ~-19 ~9 minecraft:air
setblock ~18 ~-19 ~9 minecraft:light_gray_concrete
setblock ~19 ~-19 ~9 minecraft:barrel
fill ~20 ~-19 ~9 ~30 ~-19 ~9 minecraft:air
setblock ~31 ~-19 ~9 minecraft:barrel
setblock ~32 ~-19 ~9 minecraft:light_gray_concrete
fill ~33 ~-19 ~9 ~35 ~-19 ~9 minecraft:air
setblock ~36 ~-19 ~9 minecraft:light_gray_concrete
setblock ~37 ~-19 ~9 minecraft:crafting_table
fill ~38 ~-19 ~9 ~48 ~-19 ~9 minecraft:air
setblock ~49 ~-19 ~9 minecraft:crafting_table
setblock ~50 ~-19 ~9 minecraft:light_gray_concrete
fill ~51 ~-19 ~9 ~52 ~-19 ~9 minecraft:air
fill ~53 ~-19 ~9 ~56 ~-19 ~9 minecraft:spruce_stairs[facing=south,half=bottom]
setblock ~57 ~-19 ~9 minecraft:air
fill ~58 ~-19 ~9 ~61 ~-19 ~9 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~62 ~-19 ~9 ~63 ~-19 ~9 minecraft:air
setblock ~64 ~-19 ~9 minecraft:light_gray_concrete
setblock ~4 ~-19 ~10 minecraft:light_gray_concrete
fill ~5 ~-19 ~10 ~7 ~-19 ~10 minecraft:air
fill ~8 ~-19 ~10 ~14 ~-19 ~10 minecraft:light_gray_carpet
fill ~15 ~-19 ~10 ~17 ~-19 ~10 minecraft:air
setblock ~18 ~-19 ~10 minecraft:light_gray_concrete
fill ~19 ~-19 ~10 ~31 ~-19 ~10 minecraft:air
setblock ~32 ~-19 ~10 minecraft:light_gray_concrete
fill ~33 ~-19 ~10 ~35 ~-19 ~10 minecraft:air
setblock ~36 ~-19 ~10 minecraft:light_gray_concrete
fill ~37 ~-19 ~10 ~39 ~-19 ~10 minecraft:air
fill ~40 ~-19 ~10 ~46 ~-19 ~10 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-19 ~10 ~49 ~-19 ~10 minecraft:air
setblock ~50 ~-19 ~10 minecraft:light_gray_concrete
fill ~51 ~-19 ~10 ~63 ~-19 ~10 minecraft:air
setblock ~64 ~-19 ~10 minecraft:light_gray_concrete
setblock ~4 ~-19 ~11 minecraft:light_gray_concrete
setblock ~5 ~-19 ~11 minecraft:barrel
fill ~6 ~-19 ~11 ~7 ~-19 ~11 minecraft:air
fill ~8 ~-19 ~11 ~10 ~-19 ~11 minecraft:light_gray_carpet
setblock ~11 ~-19 ~11 minecraft:spruce_slab[type=top]
fill ~12 ~-19 ~11 ~14 ~-19 ~11 minecraft:light_gray_carpet
fill ~15 ~-19 ~11 ~20 ~-19 ~11 minecraft:air
fill ~21 ~-19 ~11 ~24 ~-19 ~11 minecraft:spruce_slab
setblock ~25 ~-19 ~11 minecraft:air
fill ~26 ~-19 ~11 ~29 ~-19 ~11 minecraft:spruce_slab
fill ~30 ~-19 ~11 ~39 ~-19 ~11 minecraft:air
fill ~40 ~-19 ~11 ~46 ~-19 ~11 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-19 ~11 ~52 ~-19 ~11 minecraft:air
fill ~53 ~-19 ~11 ~56 ~-19 ~11 minecraft:spruce_stairs[facing=north,half=bottom]
setblock ~57 ~-19 ~11 minecraft:air
fill ~58 ~-19 ~11 ~61 ~-19 ~11 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~62 ~-19 ~11 ~63 ~-19 ~11 minecraft:air
setblock ~64 ~-19 ~11 minecraft:light_gray_concrete
setblock ~4 ~-19 ~12 minecraft:light_gray_concrete
fill ~5 ~-19 ~12 ~7 ~-19 ~12 minecraft:air
fill ~8 ~-19 ~12 ~14 ~-19 ~12 minecraft:light_gray_carpet
fill ~15 ~-19 ~12 ~17 ~-19 ~12 minecraft:air
setblock ~18 ~-19 ~12 minecraft:light_gray_concrete
fill ~19 ~-19 ~12 ~31 ~-19 ~12 minecraft:air
setblock ~32 ~-19 ~12 minecraft:light_gray_concrete
fill ~33 ~-19 ~12 ~35 ~-19 ~12 minecraft:air
setblock ~36 ~-19 ~12 minecraft:light_gray_concrete
fill ~37 ~-19 ~12 ~49 ~-19 ~12 minecraft:air
setblock ~50 ~-19 ~12 minecraft:light_gray_concrete
fill ~51 ~-19 ~12 ~52 ~-19 ~12 minecraft:air
fill ~53 ~-19 ~12 ~56 ~-19 ~12 minecraft:spruce_slab[type=top]
setblock ~57 ~-19 ~12 minecraft:air
fill ~58 ~-19 ~12 ~61 ~-19 ~12 minecraft:spruce_slab[type=top]
fill ~62 ~-19 ~12 ~63 ~-19 ~12 minecraft:air
setblock ~64 ~-19 ~12 minecraft:light_gray_concrete
setblock ~4 ~-19 ~13 minecraft:light_gray_concrete
fill ~5 ~-19 ~13 ~7 ~-19 ~13 minecraft:air
fill ~8 ~-19 ~13 ~14 ~-19 ~13 minecraft:light_gray_carpet
fill ~15 ~-19 ~13 ~17 ~-19 ~13 minecraft:air
setblock ~18 ~-19 ~13 minecraft:light_gray_concrete
setblock ~19 ~-19 ~13 minecraft:barrel
fill ~20 ~-19 ~13 ~31 ~-19 ~13 minecraft:air
setblock ~32 ~-19 ~13 minecraft:light_gray_concrete
fill ~33 ~-19 ~13 ~35 ~-19 ~13 minecraft:air
setblock ~36 ~-19 ~13 minecraft:light_gray_concrete
setblock ~37 ~-19 ~13 minecraft:barrel
fill ~38 ~-19 ~13 ~48 ~-19 ~13 minecraft:air
setblock ~49 ~-19 ~13 minecraft:barrel
setblock ~50 ~-19 ~13 minecraft:light_gray_concrete
fill ~51 ~-19 ~13 ~52 ~-19 ~13 minecraft:air
fill ~53 ~-19 ~13 ~56 ~-19 ~13 minecraft:spruce_stairs[facing=south,half=bottom]
setblock ~57 ~-19 ~13 minecraft:air
fill ~58 ~-19 ~13 ~61 ~-19 ~13 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~62 ~-19 ~13 ~63 ~-19 ~13 minecraft:air
setblock ~64 ~-19 ~13 minecraft:light_gray_concrete
setblock ~4 ~-19 ~14 minecraft:light_gray_concrete
setblock ~5 ~-19 ~14 minecraft:barrel
fill ~6 ~-19 ~14 ~7 ~-19 ~14 minecraft:air
fill ~8 ~-19 ~14 ~14 ~-19 ~14 minecraft:light_gray_carpet
fill ~15 ~-19 ~14 ~16 ~-19 ~14 minecraft:air
setblock ~17 ~-19 ~14 minecraft:barrel
setblock ~18 ~-19 ~14 minecraft:light_gray_concrete
setblock ~19 ~-19 ~14 minecraft:barrel
setblock ~20 ~-19 ~14 minecraft:air
fill ~21 ~-19 ~14 ~24 ~-19 ~14 minecraft:spruce_slab
setblock ~25 ~-19 ~14 minecraft:air
fill ~26 ~-19 ~14 ~29 ~-19 ~14 minecraft:spruce_slab
setblock ~30 ~-19 ~14 minecraft:air
setblock ~31 ~-19 ~14 minecraft:barrel
setblock ~32 ~-19 ~14 minecraft:light_gray_concrete
fill ~33 ~-19 ~14 ~35 ~-19 ~14 minecraft:air
setblock ~36 ~-19 ~14 minecraft:light_gray_concrete
setblock ~37 ~-19 ~14 minecraft:cauldron
fill ~38 ~-19 ~14 ~48 ~-19 ~14 minecraft:air
setblock ~49 ~-19 ~14 minecraft:cauldron
setblock ~50 ~-19 ~14 minecraft:light_gray_concrete
fill ~51 ~-19 ~14 ~63 ~-19 ~14 minecraft:air
setblock ~64 ~-19 ~14 minecraft:light_gray_concrete
setblock ~4 ~-19 ~15 minecraft:light_gray_concrete
fill ~5 ~-19 ~15 ~17 ~-19 ~15 minecraft:air
setblock ~18 ~-19 ~15 minecraft:light_gray_concrete
fill ~19 ~-19 ~15 ~30 ~-19 ~15 minecraft:air
setblock ~31 ~-19 ~15 minecraft:barrel
setblock ~32 ~-19 ~15 minecraft:light_gray_concrete
fill ~33 ~-19 ~15 ~35 ~-19 ~15 minecraft:air
setblock ~36 ~-19 ~15 minecraft:light_gray_concrete
setblock ~37 ~-19 ~15 minecraft:crafting_table
fill ~38 ~-19 ~15 ~48 ~-19 ~15 minecraft:air
setblock ~49 ~-19 ~15 minecraft:crafting_table
setblock ~50 ~-19 ~15 minecraft:light_gray_concrete
fill ~51 ~-19 ~15 ~52 ~-19 ~15 minecraft:air
fill ~53 ~-19 ~15 ~56 ~-19 ~15 minecraft:spruce_stairs[facing=north,half=bottom]
setblock ~57 ~-19 ~15 minecraft:air
fill ~58 ~-19 ~15 ~61 ~-19 ~15 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~62 ~-19 ~15 ~63 ~-19 ~15 minecraft:air
setblock ~64 ~-19 ~15 minecraft:light_gray_concrete
setblock ~4 ~-19 ~16 minecraft:light_gray_concrete
fill ~5 ~-19 ~16 ~17 ~-19 ~16 minecraft:air
setblock ~18 ~-19 ~16 minecraft:light_gray_concrete
setblock ~19 ~-19 ~16 minecraft:barrel
fill ~20 ~-19 ~16 ~30 ~-19 ~16 minecraft:air
setblock ~31 ~-19 ~16 minecraft:barrel
setblock ~32 ~-19 ~16 minecraft:light_gray_concrete
fill ~33 ~-19 ~16 ~35 ~-19 ~16 minecraft:air
setblock ~36 ~-19 ~16 minecraft:light_gray_concrete
setblock ~37 ~-19 ~16 minecraft:smoker[facing=east]
fill ~38 ~-19 ~16 ~48 ~-19 ~16 minecraft:air
setblock ~49 ~-19 ~16 minecraft:smoker[facing=west]
setblock ~50 ~-19 ~16 minecraft:light_gray_concrete
fill ~51 ~-19 ~16 ~52 ~-19 ~16 minecraft:air
fill ~53 ~-19 ~16 ~56 ~-19 ~16 minecraft:spruce_slab[type=top]
setblock ~57 ~-19 ~16 minecraft:air
fill ~58 ~-19 ~16 ~61 ~-19 ~16 minecraft:spruce_slab[type=top]
fill ~62 ~-19 ~16 ~63 ~-19 ~16 minecraft:air
setblock ~64 ~-19 ~16 minecraft:light_gray_concrete
setblock ~4 ~-19 ~17 minecraft:light_gray_concrete
setblock ~5 ~-19 ~17 minecraft:barrel
fill ~6 ~-19 ~17 ~7 ~-19 ~17 minecraft:air
setblock ~8 ~-19 ~17 minecraft:barrel
fill ~9 ~-19 ~17 ~13 ~-19 ~17 minecraft:air
setblock ~14 ~-19 ~17 minecraft:barrel
fill ~15 ~-19 ~17 ~16 ~-19 ~17 minecraft:air
setblock ~17 ~-19 ~17 minecraft:barrel
setblock ~18 ~-19 ~17 minecraft:light_gray_concrete
fill ~19 ~-19 ~17 ~21 ~-19 ~17 minecraft:barrel
setblock ~22 ~-19 ~17 minecraft:air
fill ~23 ~-19 ~17 ~26 ~-19 ~17 minecraft:barrel
setblock ~27 ~-19 ~17 minecraft:air
fill ~28 ~-19 ~17 ~31 ~-19 ~17 minecraft:barrel
setblock ~32 ~-19 ~17 minecraft:light_gray_concrete
fill ~33 ~-19 ~17 ~35 ~-19 ~17 minecraft:air
setblock ~36 ~-19 ~17 minecraft:light_gray_concrete
setblock ~37 ~-19 ~17 minecraft:smoker[facing=north]
setblock ~38 ~-19 ~17 minecraft:furnace[facing=north]
setblock ~39 ~-19 ~17 minecraft:barrel
setblock ~40 ~-19 ~17 minecraft:cauldron
setblock ~41 ~-19 ~17 minecraft:crafting_table
fill ~42 ~-19 ~17 ~43 ~-19 ~17 minecraft:smoker[facing=north]
setblock ~44 ~-19 ~17 minecraft:furnace[facing=north]
setblock ~45 ~-19 ~17 minecraft:barrel
setblock ~46 ~-19 ~17 minecraft:cauldron
setblock ~47 ~-19 ~17 minecraft:crafting_table
setblock ~48 ~-19 ~17 minecraft:smoker[facing=north]
setblock ~49 ~-19 ~17 minecraft:smoker[facing=west]
setblock ~50 ~-19 ~17 minecraft:light_gray_concrete
fill ~51 ~-19 ~17 ~52 ~-19 ~17 minecraft:air
fill ~53 ~-19 ~17 ~55 ~-19 ~17 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~56 ~-19 ~17 ~58 ~-19 ~17 minecraft:air
fill ~59 ~-19 ~17 ~61 ~-19 ~17 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~62 ~-19 ~17 ~63 ~-19 ~17 minecraft:air
setblock ~64 ~-19 ~17 minecraft:light_gray_concrete
fill ~4 ~-19 ~18 ~10 ~-19 ~18 minecraft:light_gray_concrete
setblock ~11 ~-19 ~18 minecraft:air
fill ~12 ~-19 ~18 ~32 ~-19 ~18 minecraft:light_gray_concrete
fill ~33 ~-19 ~18 ~35 ~-19 ~18 minecraft:air
fill ~36 ~-19 ~18 ~56 ~-19 ~18 minecraft:light_gray_concrete
setblock ~57 ~-19 ~18 minecraft:air
fill ~58 ~-19 ~18 ~64 ~-19 ~18 minecraft:light_gray_concrete
setblock ~4 ~-19 ~19 minecraft:light_gray_concrete
setblock ~5 ~-19 ~19 minecraft:cauldron
fill ~6 ~-19 ~19 ~8 ~-19 ~19 minecraft:air
setblock ~9 ~-19 ~19 minecraft:cauldron
fill ~10 ~-19 ~19 ~12 ~-19 ~19 minecraft:air
setblock ~13 ~-19 ~19 minecraft:cauldron
fill ~14 ~-19 ~19 ~16 ~-19 ~19 minecraft:air
setblock ~17 ~-19 ~19 minecraft:cauldron
setblock ~18 ~-19 ~19 minecraft:light_gray_concrete
fill ~19 ~-19 ~19 ~30 ~-19 ~19 minecraft:black_concrete
setblock ~31 ~-19 ~19 minecraft:air
setblock ~32 ~-19 ~19 minecraft:light_gray_concrete
schedule function hive:weiter/14 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 13 von 18 fertig","color":"gray"}]