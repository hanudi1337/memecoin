fill ~22 ~-28 ~39 ~23 ~-28 ~39 minecraft:polished_andesite
setblock ~24 ~-28 ~39 minecraft:smooth_quartz
setblock ~25 ~-28 ~39 minecraft:polished_diorite
setblock ~26 ~-28 ~39 minecraft:smooth_quartz
setblock ~27 ~-28 ~39 minecraft:red_concrete
fill ~28 ~-28 ~39 ~40 ~-28 ~39 minecraft:air
setblock ~41 ~-28 ~39 minecraft:red_concrete
setblock ~42 ~-28 ~39 minecraft:smooth_quartz
setblock ~43 ~-28 ~39 minecraft:polished_diorite
setblock ~44 ~-28 ~39 minecraft:smooth_quartz
fill ~45 ~-28 ~39 ~46 ~-28 ~39 minecraft:polished_andesite
fill ~47 ~-28 ~39 ~49 ~-28 ~39 minecraft:white_concrete
setblock ~50 ~-28 ~39 minecraft:light_gray_concrete
fill ~51 ~-28 ~39 ~63 ~-28 ~39 minecraft:packed_ice
setblock ~64 ~-28 ~39 minecraft:light_gray_concrete
setblock ~4 ~-28 ~40 minecraft:light_gray_concrete
fill ~5 ~-28 ~40 ~17 ~-28 ~40 minecraft:dark_oak_planks
setblock ~18 ~-28 ~40 minecraft:light_gray_concrete
fill ~19 ~-28 ~40 ~22 ~-28 ~40 minecraft:white_concrete
setblock ~23 ~-28 ~40 minecraft:polished_andesite
setblock ~24 ~-28 ~40 minecraft:smooth_quartz
setblock ~25 ~-28 ~40 minecraft:polished_diorite
setblock ~26 ~-28 ~40 minecraft:smooth_quartz
setblock ~27 ~-28 ~40 minecraft:red_concrete
fill ~28 ~-28 ~40 ~40 ~-28 ~40 minecraft:air
setblock ~41 ~-28 ~40 minecraft:red_concrete
setblock ~42 ~-28 ~40 minecraft:smooth_quartz
setblock ~43 ~-28 ~40 minecraft:polished_diorite
setblock ~44 ~-28 ~40 minecraft:smooth_quartz
setblock ~45 ~-28 ~40 minecraft:polished_andesite
fill ~46 ~-28 ~40 ~49 ~-28 ~40 minecraft:white_concrete
setblock ~50 ~-28 ~40 minecraft:light_gray_concrete
fill ~51 ~-28 ~40 ~63 ~-28 ~40 minecraft:packed_ice
setblock ~64 ~-28 ~40 minecraft:light_gray_concrete
setblock ~4 ~-28 ~41 minecraft:light_gray_concrete
fill ~5 ~-28 ~41 ~17 ~-28 ~41 minecraft:dark_oak_planks
setblock ~18 ~-28 ~41 minecraft:light_gray_concrete
fill ~19 ~-28 ~41 ~23 ~-28 ~41 minecraft:white_concrete
setblock ~24 ~-28 ~41 minecraft:polished_andesite
setblock ~25 ~-28 ~41 minecraft:smooth_quartz
setblock ~26 ~-28 ~41 minecraft:polished_diorite
setblock ~27 ~-28 ~41 minecraft:smooth_quartz
fill ~28 ~-28 ~41 ~29 ~-28 ~41 minecraft:red_concrete
fill ~30 ~-28 ~41 ~38 ~-28 ~41 minecraft:air
fill ~39 ~-28 ~41 ~40 ~-28 ~41 minecraft:red_concrete
setblock ~41 ~-28 ~41 minecraft:smooth_quartz
setblock ~42 ~-28 ~41 minecraft:polished_diorite
setblock ~43 ~-28 ~41 minecraft:smooth_quartz
setblock ~44 ~-28 ~41 minecraft:polished_andesite
fill ~45 ~-28 ~41 ~49 ~-28 ~41 minecraft:white_concrete
setblock ~50 ~-28 ~41 minecraft:light_gray_concrete
fill ~51 ~-28 ~41 ~63 ~-28 ~41 minecraft:packed_ice
setblock ~64 ~-28 ~41 minecraft:light_gray_concrete
setblock ~4 ~-28 ~42 minecraft:light_gray_concrete
fill ~5 ~-28 ~42 ~17 ~-28 ~42 minecraft:dark_oak_planks
setblock ~18 ~-28 ~42 minecraft:light_gray_concrete
fill ~19 ~-28 ~42 ~23 ~-28 ~42 minecraft:white_concrete
fill ~24 ~-28 ~42 ~25 ~-28 ~42 minecraft:polished_andesite
setblock ~26 ~-28 ~42 minecraft:smooth_quartz
setblock ~27 ~-28 ~42 minecraft:polished_diorite
fill ~28 ~-28 ~42 ~29 ~-28 ~42 minecraft:smooth_quartz
fill ~30 ~-28 ~42 ~31 ~-28 ~42 minecraft:red_concrete
fill ~32 ~-28 ~42 ~36 ~-28 ~42 minecraft:air
fill ~37 ~-28 ~42 ~38 ~-28 ~42 minecraft:red_concrete
fill ~39 ~-28 ~42 ~40 ~-28 ~42 minecraft:smooth_quartz
setblock ~41 ~-28 ~42 minecraft:polished_diorite
setblock ~42 ~-28 ~42 minecraft:smooth_quartz
fill ~43 ~-28 ~42 ~44 ~-28 ~42 minecraft:polished_andesite
fill ~45 ~-28 ~42 ~49 ~-28 ~42 minecraft:white_concrete
setblock ~50 ~-28 ~42 minecraft:light_gray_concrete
fill ~51 ~-28 ~42 ~63 ~-28 ~42 minecraft:packed_ice
setblock ~64 ~-28 ~42 minecraft:light_gray_concrete
setblock ~4 ~-28 ~43 minecraft:light_gray_concrete
fill ~5 ~-28 ~43 ~17 ~-28 ~43 minecraft:dark_oak_planks
setblock ~18 ~-28 ~43 minecraft:light_gray_concrete
fill ~19 ~-28 ~43 ~24 ~-28 ~43 minecraft:white_concrete
fill ~25 ~-28 ~43 ~26 ~-28 ~43 minecraft:polished_andesite
setblock ~27 ~-28 ~43 minecraft:smooth_quartz
fill ~28 ~-28 ~43 ~29 ~-28 ~43 minecraft:polished_diorite
fill ~30 ~-28 ~43 ~31 ~-28 ~43 minecraft:smooth_quartz
fill ~32 ~-28 ~43 ~36 ~-28 ~43 minecraft:red_concrete
fill ~37 ~-28 ~43 ~38 ~-28 ~43 minecraft:smooth_quartz
fill ~39 ~-28 ~43 ~40 ~-28 ~43 minecraft:polished_diorite
setblock ~41 ~-28 ~43 minecraft:smooth_quartz
fill ~42 ~-28 ~43 ~43 ~-28 ~43 minecraft:polished_andesite
fill ~44 ~-28 ~43 ~49 ~-28 ~43 minecraft:white_concrete
setblock ~50 ~-28 ~43 minecraft:light_gray_concrete
fill ~51 ~-28 ~43 ~63 ~-28 ~43 minecraft:packed_ice
setblock ~64 ~-28 ~43 minecraft:light_gray_concrete
setblock ~4 ~-28 ~44 minecraft:light_gray_concrete
fill ~5 ~-28 ~44 ~17 ~-28 ~44 minecraft:dark_oak_planks
setblock ~18 ~-28 ~44 minecraft:light_gray_concrete
fill ~19 ~-28 ~44 ~25 ~-28 ~44 minecraft:white_concrete
fill ~26 ~-28 ~44 ~27 ~-28 ~44 minecraft:polished_andesite
fill ~28 ~-28 ~44 ~29 ~-28 ~44 minecraft:smooth_quartz
fill ~30 ~-28 ~44 ~33 ~-28 ~44 minecraft:polished_diorite
setblock ~34 ~-28 ~44 minecraft:smooth_quartz
fill ~35 ~-28 ~44 ~38 ~-28 ~44 minecraft:polished_diorite
fill ~39 ~-28 ~44 ~40 ~-28 ~44 minecraft:smooth_quartz
fill ~41 ~-28 ~44 ~42 ~-28 ~44 minecraft:polished_andesite
fill ~43 ~-28 ~44 ~49 ~-28 ~44 minecraft:white_concrete
setblock ~50 ~-28 ~44 minecraft:light_gray_concrete
fill ~51 ~-28 ~44 ~63 ~-28 ~44 minecraft:packed_ice
setblock ~64 ~-28 ~44 minecraft:light_gray_concrete
setblock ~4 ~-28 ~45 minecraft:light_gray_concrete
fill ~5 ~-28 ~45 ~17 ~-28 ~45 minecraft:dark_oak_planks
setblock ~18 ~-28 ~45 minecraft:light_gray_concrete
fill ~19 ~-28 ~45 ~27 ~-28 ~45 minecraft:white_concrete
fill ~28 ~-28 ~45 ~29 ~-28 ~45 minecraft:polished_andesite
fill ~30 ~-28 ~45 ~33 ~-28 ~45 minecraft:smooth_quartz
setblock ~34 ~-28 ~45 minecraft:polished_diorite
fill ~35 ~-28 ~45 ~38 ~-28 ~45 minecraft:smooth_quartz
fill ~39 ~-28 ~45 ~40 ~-28 ~45 minecraft:polished_andesite
fill ~41 ~-28 ~45 ~49 ~-28 ~45 minecraft:white_concrete
setblock ~50 ~-28 ~45 minecraft:light_gray_concrete
fill ~51 ~-28 ~45 ~63 ~-28 ~45 minecraft:packed_ice
setblock ~64 ~-28 ~45 minecraft:light_gray_concrete
setblock ~4 ~-28 ~46 minecraft:light_gray_concrete
fill ~5 ~-28 ~46 ~17 ~-28 ~46 minecraft:dark_oak_planks
setblock ~18 ~-28 ~46 minecraft:light_gray_concrete
fill ~19 ~-28 ~46 ~28 ~-28 ~46 minecraft:white_concrete
fill ~29 ~-28 ~46 ~32 ~-28 ~46 minecraft:polished_andesite
fill ~33 ~-28 ~46 ~35 ~-28 ~46 minecraft:smooth_quartz
fill ~36 ~-28 ~46 ~39 ~-28 ~46 minecraft:polished_andesite
fill ~40 ~-28 ~46 ~49 ~-28 ~46 minecraft:white_concrete
setblock ~50 ~-28 ~46 minecraft:light_gray_concrete
fill ~51 ~-28 ~46 ~63 ~-28 ~46 minecraft:packed_ice
setblock ~64 ~-28 ~46 minecraft:light_gray_concrete
setblock ~4 ~-28 ~47 minecraft:light_gray_concrete
fill ~5 ~-28 ~47 ~17 ~-28 ~47 minecraft:dark_oak_planks
setblock ~18 ~-28 ~47 minecraft:light_gray_concrete
fill ~19 ~-28 ~47 ~31 ~-28 ~47 minecraft:white_concrete
setblock ~32 ~-28 ~47 minecraft:light_gray_concrete
setblock ~33 ~-28 ~47 minecraft:white_concrete
setblock ~34 ~-28 ~47 minecraft:smooth_quartz
setblock ~35 ~-28 ~47 minecraft:white_concrete
setblock ~36 ~-28 ~47 minecraft:light_gray_concrete
fill ~37 ~-28 ~47 ~49 ~-28 ~47 minecraft:white_concrete
setblock ~50 ~-28 ~47 minecraft:light_gray_concrete
fill ~51 ~-28 ~47 ~63 ~-28 ~47 minecraft:packed_ice
setblock ~64 ~-28 ~47 minecraft:light_gray_concrete
setblock ~4 ~-28 ~48 minecraft:light_gray_concrete
fill ~5 ~-28 ~48 ~17 ~-28 ~48 minecraft:dark_oak_planks
setblock ~18 ~-28 ~48 minecraft:light_gray_concrete
fill ~19 ~-28 ~48 ~31 ~-28 ~48 minecraft:white_concrete
setblock ~32 ~-28 ~48 minecraft:light_gray_concrete
setblock ~33 ~-28 ~48 minecraft:white_concrete
setblock ~34 ~-28 ~48 minecraft:red_concrete
setblock ~35 ~-28 ~48 minecraft:white_concrete
setblock ~36 ~-28 ~48 minecraft:light_gray_concrete
fill ~37 ~-28 ~48 ~49 ~-28 ~48 minecraft:white_concrete
setblock ~50 ~-28 ~48 minecraft:light_gray_concrete
fill ~51 ~-28 ~48 ~63 ~-28 ~48 minecraft:packed_ice
setblock ~64 ~-28 ~48 minecraft:light_gray_concrete
setblock ~4 ~-28 ~49 minecraft:light_gray_concrete
fill ~5 ~-28 ~49 ~17 ~-28 ~49 minecraft:dark_oak_planks
setblock ~18 ~-28 ~49 minecraft:light_gray_concrete
fill ~19 ~-28 ~49 ~31 ~-28 ~49 minecraft:white_concrete
setblock ~32 ~-28 ~49 minecraft:light_gray_concrete
setblock ~33 ~-28 ~49 minecraft:white_concrete
setblock ~34 ~-28 ~49 minecraft:red_concrete
setblock ~35 ~-28 ~49 minecraft:white_concrete
setblock ~36 ~-28 ~49 minecraft:light_gray_concrete
fill ~37 ~-28 ~49 ~49 ~-28 ~49 minecraft:white_concrete
setblock ~50 ~-28 ~49 minecraft:light_gray_concrete
fill ~51 ~-28 ~49 ~63 ~-28 ~49 minecraft:packed_ice
setblock ~64 ~-28 ~49 minecraft:light_gray_concrete
fill ~4 ~-28 ~50 ~32 ~-28 ~50 minecraft:light_gray_concrete
setblock ~33 ~-28 ~50 minecraft:white_concrete
setblock ~34 ~-28 ~50 minecraft:red_concrete
setblock ~35 ~-28 ~50 minecraft:white_concrete
fill ~36 ~-28 ~50 ~64 ~-28 ~50 minecraft:light_gray_concrete
setblock ~4 ~-28 ~51 minecraft:light_gray_concrete
fill ~5 ~-28 ~51 ~17 ~-28 ~51 minecraft:dark_oak_planks
setblock ~18 ~-28 ~51 minecraft:light_gray_concrete
fill ~19 ~-28 ~51 ~31 ~-28 ~51 minecraft:spruce_planks
setblock ~32 ~-28 ~51 minecraft:light_gray_concrete
setblock ~33 ~-28 ~51 minecraft:white_concrete
setblock ~34 ~-28 ~51 minecraft:red_concrete
setblock ~35 ~-28 ~51 minecraft:white_concrete
setblock ~36 ~-28 ~51 minecraft:light_gray_concrete
fill ~37 ~-28 ~51 ~49 ~-28 ~51 minecraft:white_concrete
setblock ~50 ~-28 ~51 minecraft:light_gray_concrete
fill ~51 ~-28 ~51 ~63 ~-28 ~51 minecraft:white_concrete
setblock ~64 ~-28 ~51 minecraft:light_gray_concrete
setblock ~4 ~-28 ~52 minecraft:light_gray_concrete
fill ~5 ~-28 ~52 ~17 ~-28 ~52 minecraft:dark_oak_planks
setblock ~18 ~-28 ~52 minecraft:light_gray_concrete
fill ~19 ~-28 ~52 ~31 ~-28 ~52 minecraft:spruce_planks
setblock ~32 ~-28 ~52 minecraft:light_gray_concrete
setblock ~33 ~-28 ~52 minecraft:white_concrete
setblock ~34 ~-28 ~52 minecraft:red_concrete
setblock ~35 ~-28 ~52 minecraft:white_concrete
setblock ~36 ~-28 ~52 minecraft:light_gray_concrete
fill ~37 ~-28 ~52 ~49 ~-28 ~52 minecraft:white_concrete
setblock ~50 ~-28 ~52 minecraft:light_gray_concrete
fill ~51 ~-28 ~52 ~63 ~-28 ~52 minecraft:white_concrete
setblock ~64 ~-28 ~52 minecraft:light_gray_concrete
setblock ~4 ~-28 ~53 minecraft:light_gray_concrete
fill ~5 ~-28 ~53 ~17 ~-28 ~53 minecraft:dark_oak_planks
setblock ~18 ~-28 ~53 minecraft:light_gray_concrete
fill ~19 ~-28 ~53 ~31 ~-28 ~53 minecraft:spruce_planks
setblock ~32 ~-28 ~53 minecraft:light_gray_concrete
setblock ~33 ~-28 ~53 minecraft:white_concrete
setblock ~34 ~-28 ~53 minecraft:red_concrete
setblock ~35 ~-28 ~53 minecraft:white_concrete
setblock ~36 ~-28 ~53 minecraft:light_gray_concrete
fill ~37 ~-28 ~53 ~49 ~-28 ~53 minecraft:white_concrete
setblock ~50 ~-28 ~53 minecraft:light_gray_concrete
fill ~51 ~-28 ~53 ~63 ~-28 ~53 minecraft:white_concrete
setblock ~64 ~-28 ~53 minecraft:light_gray_concrete
setblock ~4 ~-28 ~54 minecraft:light_gray_concrete
fill ~5 ~-28 ~54 ~17 ~-28 ~54 minecraft:dark_oak_planks
setblock ~18 ~-28 ~54 minecraft:light_gray_concrete
fill ~19 ~-28 ~54 ~31 ~-28 ~54 minecraft:spruce_planks
setblock ~32 ~-28 ~54 minecraft:light_gray_concrete
setblock ~33 ~-28 ~54 minecraft:white_concrete
setblock ~34 ~-28 ~54 minecraft:red_concrete
setblock ~35 ~-28 ~54 minecraft:white_concrete
setblock ~36 ~-28 ~54 minecraft:light_gray_concrete
fill ~37 ~-28 ~54 ~49 ~-28 ~54 minecraft:white_concrete
setblock ~50 ~-28 ~54 minecraft:light_gray_concrete
fill ~51 ~-28 ~54 ~63 ~-28 ~54 minecraft:white_concrete
setblock ~64 ~-28 ~54 minecraft:light_gray_concrete
setblock ~4 ~-28 ~55 minecraft:light_gray_concrete
fill ~5 ~-28 ~55 ~17 ~-28 ~55 minecraft:dark_oak_planks
setblock ~18 ~-28 ~55 minecraft:light_gray_concrete
fill ~19 ~-28 ~55 ~31 ~-28 ~55 minecraft:spruce_planks
setblock ~32 ~-28 ~55 minecraft:light_gray_concrete
setblock ~33 ~-28 ~55 minecraft:white_concrete
setblock ~34 ~-28 ~55 minecraft:red_concrete
setblock ~35 ~-28 ~55 minecraft:white_concrete
setblock ~36 ~-28 ~55 minecraft:light_gray_concrete
fill ~37 ~-28 ~55 ~49 ~-28 ~55 minecraft:white_concrete
setblock ~50 ~-28 ~55 minecraft:light_gray_concrete
fill ~51 ~-28 ~55 ~63 ~-28 ~55 minecraft:white_concrete
setblock ~64 ~-28 ~55 minecraft:light_gray_concrete
setblock ~4 ~-28 ~56 minecraft:light_gray_concrete
fill ~5 ~-28 ~56 ~17 ~-28 ~56 minecraft:dark_oak_planks
setblock ~18 ~-28 ~56 minecraft:light_gray_concrete
fill ~19 ~-28 ~56 ~31 ~-28 ~56 minecraft:spruce_planks
setblock ~32 ~-28 ~56 minecraft:light_gray_concrete
setblock ~33 ~-28 ~56 minecraft:white_concrete
setblock ~34 ~-28 ~56 minecraft:red_concrete
setblock ~35 ~-28 ~56 minecraft:white_concrete
setblock ~36 ~-28 ~56 minecraft:light_gray_concrete
fill ~37 ~-28 ~56 ~49 ~-28 ~56 minecraft:white_concrete
setblock ~50 ~-28 ~56 minecraft:light_gray_concrete
fill ~51 ~-28 ~56 ~63 ~-28 ~56 minecraft:white_concrete
setblock ~64 ~-28 ~56 minecraft:light_gray_concrete
setblock ~4 ~-28 ~57 minecraft:light_gray_concrete
fill ~5 ~-28 ~57 ~17 ~-28 ~57 minecraft:dark_oak_planks
setblock ~18 ~-28 ~57 minecraft:light_gray_concrete
fill ~19 ~-28 ~57 ~31 ~-28 ~57 minecraft:spruce_planks
setblock ~32 ~-28 ~57 minecraft:light_gray_concrete
setblock ~33 ~-28 ~57 minecraft:white_concrete
setblock ~34 ~-28 ~57 minecraft:red_concrete
setblock ~35 ~-28 ~57 minecraft:white_concrete
setblock ~36 ~-28 ~57 minecraft:light_gray_concrete
fill ~37 ~-28 ~57 ~49 ~-28 ~57 minecraft:white_concrete
setblock ~50 ~-28 ~57 minecraft:light_gray_concrete
fill ~51 ~-28 ~57 ~63 ~-28 ~57 minecraft:white_concrete
setblock ~64 ~-28 ~57 minecraft:light_gray_concrete
setblock ~4 ~-28 ~58 minecraft:light_gray_concrete
fill ~5 ~-28 ~58 ~17 ~-28 ~58 minecraft:dark_oak_planks
setblock ~18 ~-28 ~58 minecraft:light_gray_concrete
fill ~19 ~-28 ~58 ~31 ~-28 ~58 minecraft:spruce_planks
setblock ~32 ~-28 ~58 minecraft:light_gray_concrete
setblock ~33 ~-28 ~58 minecraft:white_concrete
setblock ~34 ~-28 ~58 minecraft:red_concrete
setblock ~35 ~-28 ~58 minecraft:white_concrete
setblock ~36 ~-28 ~58 minecraft:light_gray_concrete
fill ~37 ~-28 ~58 ~49 ~-28 ~58 minecraft:white_concrete
setblock ~50 ~-28 ~58 minecraft:light_gray_concrete
fill ~51 ~-28 ~58 ~63 ~-28 ~58 minecraft:white_concrete
setblock ~64 ~-28 ~58 minecraft:light_gray_concrete
setblock ~4 ~-28 ~59 minecraft:light_gray_concrete
fill ~5 ~-28 ~59 ~17 ~-28 ~59 minecraft:dark_oak_planks
setblock ~18 ~-28 ~59 minecraft:light_gray_concrete
fill ~19 ~-28 ~59 ~31 ~-28 ~59 minecraft:spruce_planks
setblock ~32 ~-28 ~59 minecraft:light_gray_concrete
setblock ~33 ~-28 ~59 minecraft:white_concrete
setblock ~34 ~-28 ~59 minecraft:red_concrete
setblock ~35 ~-28 ~59 minecraft:white_concrete
setblock ~36 ~-28 ~59 minecraft:light_gray_concrete
fill ~37 ~-28 ~59 ~49 ~-28 ~59 minecraft:white_concrete
setblock ~50 ~-28 ~59 minecraft:light_gray_concrete
fill ~51 ~-28 ~59 ~63 ~-28 ~59 minecraft:white_concrete
setblock ~64 ~-28 ~59 minecraft:light_gray_concrete
setblock ~4 ~-28 ~60 minecraft:light_gray_concrete
fill ~5 ~-28 ~60 ~17 ~-28 ~60 minecraft:dark_oak_planks
setblock ~18 ~-28 ~60 minecraft:light_gray_concrete
fill ~19 ~-28 ~60 ~31 ~-28 ~60 minecraft:spruce_planks
setblock ~32 ~-28 ~60 minecraft:light_gray_concrete
setblock ~33 ~-28 ~60 minecraft:white_concrete
setblock ~34 ~-28 ~60 minecraft:red_concrete
setblock ~35 ~-28 ~60 minecraft:white_concrete
setblock ~36 ~-28 ~60 minecraft:light_gray_concrete
fill ~37 ~-28 ~60 ~49 ~-28 ~60 minecraft:white_concrete
setblock ~50 ~-28 ~60 minecraft:light_gray_concrete
fill ~51 ~-28 ~60 ~63 ~-28 ~60 minecraft:white_concrete
setblock ~64 ~-28 ~60 minecraft:light_gray_concrete
setblock ~4 ~-28 ~61 minecraft:light_gray_concrete
fill ~5 ~-28 ~61 ~17 ~-28 ~61 minecraft:dark_oak_planks
setblock ~18 ~-28 ~61 minecraft:light_gray_concrete
fill ~19 ~-28 ~61 ~31 ~-28 ~61 minecraft:spruce_planks
setblock ~32 ~-28 ~61 minecraft:light_gray_concrete
setblock ~33 ~-28 ~61 minecraft:white_concrete
setblock ~34 ~-28 ~61 minecraft:red_concrete
setblock ~35 ~-28 ~61 minecraft:white_concrete
setblock ~36 ~-28 ~61 minecraft:light_gray_concrete
fill ~37 ~-28 ~61 ~49 ~-28 ~61 minecraft:white_concrete
setblock ~50 ~-28 ~61 minecraft:light_gray_concrete
fill ~51 ~-28 ~61 ~63 ~-28 ~61 minecraft:white_concrete
setblock ~64 ~-28 ~61 minecraft:light_gray_concrete
setblock ~4 ~-28 ~62 minecraft:light_gray_concrete
fill ~5 ~-28 ~62 ~17 ~-28 ~62 minecraft:dark_oak_planks
setblock ~18 ~-28 ~62 minecraft:light_gray_concrete
fill ~19 ~-28 ~62 ~31 ~-28 ~62 minecraft:spruce_planks
setblock ~32 ~-28 ~62 minecraft:light_gray_concrete
setblock ~33 ~-28 ~62 minecraft:white_concrete
setblock ~34 ~-28 ~62 minecraft:red_concrete
setblock ~35 ~-28 ~62 minecraft:white_concrete
setblock ~36 ~-28 ~62 minecraft:light_gray_concrete
fill ~37 ~-28 ~62 ~49 ~-28 ~62 minecraft:white_concrete
setblock ~50 ~-28 ~62 minecraft:light_gray_concrete
fill ~51 ~-28 ~62 ~63 ~-28 ~62 minecraft:white_concrete
setblock ~64 ~-28 ~62 minecraft:light_gray_concrete
setblock ~4 ~-28 ~63 minecraft:light_gray_concrete
fill ~5 ~-28 ~63 ~17 ~-28 ~63 minecraft:dark_oak_planks
setblock ~18 ~-28 ~63 minecraft:light_gray_concrete
fill ~19 ~-28 ~63 ~31 ~-28 ~63 minecraft:spruce_planks
setblock ~32 ~-28 ~63 minecraft:light_gray_concrete
setblock ~33 ~-28 ~63 minecraft:white_concrete
setblock ~34 ~-28 ~63 minecraft:red_concrete
setblock ~35 ~-28 ~63 minecraft:white_concrete
setblock ~36 ~-28 ~63 minecraft:light_gray_concrete
fill ~37 ~-28 ~63 ~49 ~-28 ~63 minecraft:white_concrete
setblock ~50 ~-28 ~63 minecraft:light_gray_concrete
fill ~51 ~-28 ~63 ~63 ~-28 ~63 minecraft:white_concrete
setblock ~64 ~-28 ~63 minecraft:light_gray_concrete
fill ~4 ~-28 ~64 ~64 ~-28 ~64 minecraft:light_gray_concrete
setblock ~34 ~-28 ~65 minecraft:white_concrete
fill ~32 ~-28 ~66 ~36 ~-28 ~66 minecraft:polished_andesite
setblock ~32 ~-28 ~67 minecraft:polished_andesite
setblock ~33 ~-28 ~67 minecraft:air
setblock ~34 ~-28 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-28 ~67 minecraft:air
setblock ~36 ~-28 ~67 minecraft:polished_andesite
setblock ~32 ~-28 ~68 minecraft:polished_andesite
setblock ~33 ~-28 ~68 minecraft:air
setblock ~34 ~-28 ~68 minecraft:quartz_pillar
setblock ~35 ~-28 ~68 minecraft:air
setblock ~36 ~-28 ~68 minecraft:polished_andesite
setblock ~32 ~-28 ~69 minecraft:polished_andesite
fill ~33 ~-28 ~69 ~35 ~-28 ~69 minecraft:air
setblock ~36 ~-28 ~69 minecraft:polished_andesite
fill ~32 ~-28 ~70 ~36 ~-28 ~70 minecraft:polished_andesite
fill ~4 ~-27 ~4 ~64 ~-27 ~4 minecraft:light_gray_concrete
setblock ~4 ~-27 ~5 minecraft:light_gray_concrete
setblock ~5 ~-27 ~5 minecraft:cauldron
fill ~6 ~-27 ~5 ~7 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~8 ~-27 ~5 minecraft:cauldron
fill ~9 ~-27 ~5 ~10 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~11 ~-27 ~5 minecraft:cauldron
fill ~12 ~-27 ~5 ~13 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~14 ~-27 ~5 minecraft:cauldron
fill ~15 ~-27 ~5 ~16 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~17 ~-27 ~5 minecraft:cauldron
setblock ~18 ~-27 ~5 minecraft:light_gray_concrete
fill ~19 ~-27 ~5 ~31 ~-27 ~5 minecraft:chiseled_bookshelf[facing=south]
setblock ~32 ~-27 ~5 minecraft:light_gray_concrete
fill ~33 ~-27 ~5 ~35 ~-27 ~5 minecraft:air
setblock ~36 ~-27 ~5 minecraft:light_gray_concrete
fill ~37 ~-27 ~5 ~38 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~39 ~-27 ~5 minecraft:air
fill ~40 ~-27 ~5 ~41 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~42 ~-27 ~5 minecraft:air
fill ~43 ~-27 ~5 ~44 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~45 ~-27 ~5 minecraft:air
fill ~46 ~-27 ~5 ~47 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~48 ~-27 ~5 minecraft:air
setblock ~49 ~-27 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~5 minecraft:light_gray_concrete
setblock ~51 ~-27 ~5 minecraft:air
setblock ~52 ~-27 ~5 minecraft:flowering_azalea
setblock ~53 ~-27 ~5 minecraft:air
setblock ~54 ~-27 ~5 minecraft:flowering_azalea
setblock ~55 ~-27 ~5 minecraft:air
setblock ~56 ~-27 ~5 minecraft:flowering_azalea
setblock ~57 ~-27 ~5 minecraft:air
setblock ~58 ~-27 ~5 minecraft:flowering_azalea
setblock ~59 ~-27 ~5 minecraft:air
setblock ~60 ~-27 ~5 minecraft:flowering_azalea
setblock ~61 ~-27 ~5 minecraft:air
setblock ~62 ~-27 ~5 minecraft:flowering_azalea
setblock ~63 ~-27 ~5 minecraft:air
setblock ~64 ~-27 ~5 minecraft:light_gray_concrete
setblock ~4 ~-27 ~6 minecraft:light_gray_concrete
setblock ~5 ~-27 ~6 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~6 ~16 ~-27 ~6 minecraft:air
setblock ~17 ~-27 ~6 minecraft:smooth_stone_slab[type=top]
setblock ~18 ~-27 ~6 minecraft:light_gray_concrete
fill ~19 ~-27 ~6 ~31 ~-27 ~6 minecraft:air
setblock ~32 ~-27 ~6 minecraft:light_gray_concrete
fill ~33 ~-27 ~6 ~35 ~-27 ~6 minecraft:air
setblock ~36 ~-27 ~6 minecraft:light_gray_concrete
setblock ~37 ~-27 ~6 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-27 ~6 ~48 ~-27 ~6 minecraft:air
setblock ~49 ~-27 ~6 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~6 minecraft:light_gray_concrete
setblock ~51 ~-27 ~6 minecraft:flowering_azalea
fill ~52 ~-27 ~6 ~62 ~-27 ~6 minecraft:air
setblock ~63 ~-27 ~6 minecraft:flowering_azalea
setblock ~64 ~-27 ~6 minecraft:light_gray_concrete
setblock ~4 ~-27 ~7 minecraft:light_gray_concrete
setblock ~5 ~-27 ~7 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~7 ~16 ~-27 ~7 minecraft:air
setblock ~17 ~-27 ~7 minecraft:smooth_stone_slab[type=top]
setblock ~18 ~-27 ~7 minecraft:light_gray_concrete
fill ~19 ~-27 ~7 ~20 ~-27 ~7 minecraft:air
fill ~21 ~-27 ~7 ~29 ~-27 ~7 minecraft:red_carpet
fill ~30 ~-27 ~7 ~31 ~-27 ~7 minecraft:air
setblock ~32 ~-27 ~7 minecraft:light_gray_concrete
fill ~33 ~-27 ~7 ~35 ~-27 ~7 minecraft:air
setblock ~36 ~-27 ~7 minecraft:light_gray_concrete
fill ~37 ~-27 ~7 ~49 ~-27 ~7 minecraft:air
setblock ~50 ~-27 ~7 minecraft:light_gray_concrete
fill ~51 ~-27 ~7 ~63 ~-27 ~7 minecraft:air
setblock ~64 ~-27 ~7 minecraft:light_gray_concrete
setblock ~4 ~-27 ~8 minecraft:light_gray_concrete
setblock ~5 ~-27 ~8 minecraft:cauldron
fill ~6 ~-27 ~8 ~16 ~-27 ~8 minecraft:air
setblock ~17 ~-27 ~8 minecraft:cauldron
setblock ~18 ~-27 ~8 minecraft:light_gray_concrete
fill ~19 ~-27 ~8 ~20 ~-27 ~8 minecraft:air
fill ~21 ~-27 ~8 ~23 ~-27 ~8 minecraft:red_carpet
fill ~24 ~-27 ~8 ~26 ~-27 ~8 minecraft:smooth_stone_slab[type=top]
setblock ~27 ~-27 ~8 minecraft:lectern
fill ~28 ~-27 ~8 ~29 ~-27 ~8 minecraft:red_carpet
fill ~30 ~-27 ~8 ~31 ~-27 ~8 minecraft:air
setblock ~32 ~-27 ~8 minecraft:light_gray_concrete
fill ~33 ~-27 ~8 ~35 ~-27 ~8 minecraft:air
setblock ~36 ~-27 ~8 minecraft:light_gray_concrete
setblock ~37 ~-27 ~8 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-27 ~8 ~39 ~-27 ~8 minecraft:air
setblock ~40 ~-27 ~8 minecraft:iron_block
fill ~41 ~-27 ~8 ~43 ~-27 ~8 minecraft:air
setblock ~44 ~-27 ~8 minecraft:iron_block
fill ~45 ~-27 ~8 ~48 ~-27 ~8 minecraft:air
setblock ~49 ~-27 ~8 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~8 minecraft:light_gray_concrete
setblock ~51 ~-27 ~8 minecraft:flowering_azalea
fill ~52 ~-27 ~8 ~62 ~-27 ~8 minecraft:air
setblock ~63 ~-27 ~8 minecraft:flowering_azalea
setblock ~64 ~-27 ~8 minecraft:light_gray_concrete
setblock ~4 ~-27 ~9 minecraft:light_gray_concrete
setblock ~5 ~-27 ~9 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~9 ~7 ~-27 ~9 minecraft:air
fill ~8 ~-27 ~9 ~14 ~-27 ~9 minecraft:smooth_stone_slab[type=top]
fill ~15 ~-27 ~9 ~16 ~-27 ~9 minecraft:air
setblock ~17 ~-27 ~9 minecraft:smooth_stone_slab[type=top]
setblock ~18 ~-27 ~9 minecraft:light_gray_concrete
fill ~19 ~-27 ~9 ~20 ~-27 ~9 minecraft:air
fill ~21 ~-27 ~9 ~24 ~-27 ~9 minecraft:red_carpet
setblock ~25 ~-27 ~9 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~26 ~-27 ~9 ~29 ~-27 ~9 minecraft:red_carpet
fill ~30 ~-27 ~9 ~31 ~-27 ~9 minecraft:air
setblock ~32 ~-27 ~9 minecraft:light_gray_concrete
fill ~33 ~-27 ~9 ~35 ~-27 ~9 minecraft:air
setblock ~36 ~-27 ~9 minecraft:light_gray_concrete
setblock ~37 ~-27 ~9 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-27 ~9 ~48 ~-27 ~9 minecraft:air
setblock ~49 ~-27 ~9 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~9 minecraft:light_gray_concrete
fill ~51 ~-27 ~9 ~63 ~-27 ~9 minecraft:air
setblock ~64 ~-27 ~9 minecraft:light_gray_concrete
setblock ~4 ~-27 ~10 minecraft:light_gray_concrete
setblock ~5 ~-27 ~10 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~10 ~17 ~-27 ~10 minecraft:air
setblock ~18 ~-27 ~10 minecraft:light_gray_concrete
fill ~19 ~-27 ~10 ~20 ~-27 ~10 minecraft:air
fill ~21 ~-27 ~10 ~29 ~-27 ~10 minecraft:red_carpet
fill ~30 ~-27 ~10 ~31 ~-27 ~10 minecraft:air
setblock ~32 ~-27 ~10 minecraft:light_gray_concrete
fill ~33 ~-27 ~10 ~35 ~-27 ~10 minecraft:air
setblock ~36 ~-27 ~10 minecraft:light_gray_concrete
fill ~37 ~-27 ~10 ~49 ~-27 ~10 minecraft:air
setblock ~50 ~-27 ~10 minecraft:light_gray_concrete
fill ~51 ~-27 ~10 ~62 ~-27 ~10 minecraft:air
setblock ~63 ~-27 ~10 minecraft:flowering_azalea
setblock ~64 ~-27 ~10 minecraft:light_gray_concrete
setblock ~4 ~-27 ~11 minecraft:light_gray_concrete
setblock ~5 ~-27 ~11 minecraft:cauldron
fill ~6 ~-27 ~11 ~20 ~-27 ~11 minecraft:air
fill ~21 ~-27 ~11 ~29 ~-27 ~11 minecraft:red_carpet
fill ~30 ~-27 ~11 ~63 ~-27 ~11 minecraft:air
setblock ~64 ~-27 ~11 minecraft:light_gray_concrete
setblock ~4 ~-27 ~12 minecraft:light_gray_concrete
setblock ~5 ~-27 ~12 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~12 ~17 ~-27 ~12 minecraft:air
setblock ~18 ~-27 ~12 minecraft:light_gray_concrete
fill ~19 ~-27 ~12 ~20 ~-27 ~12 minecraft:air
fill ~21 ~-27 ~12 ~29 ~-27 ~12 minecraft:red_carpet
fill ~30 ~-27 ~12 ~31 ~-27 ~12 minecraft:air
setblock ~32 ~-27 ~12 minecraft:light_gray_concrete
fill ~33 ~-27 ~12 ~35 ~-27 ~12 minecraft:air
setblock ~36 ~-27 ~12 minecraft:light_gray_concrete
fill ~37 ~-27 ~12 ~39 ~-27 ~12 minecraft:air
setblock ~40 ~-27 ~12 minecraft:iron_block
fill ~41 ~-27 ~12 ~43 ~-27 ~12 minecraft:air
setblock ~44 ~-27 ~12 minecraft:iron_block
fill ~45 ~-27 ~12 ~49 ~-27 ~12 minecraft:air
setblock ~50 ~-27 ~12 minecraft:light_gray_concrete
fill ~51 ~-27 ~12 ~62 ~-27 ~12 minecraft:air
setblock ~63 ~-27 ~12 minecraft:flowering_azalea
setblock ~64 ~-27 ~12 minecraft:light_gray_concrete
setblock ~4 ~-27 ~13 minecraft:light_gray_concrete
setblock ~5 ~-27 ~13 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~13 ~7 ~-27 ~13 minecraft:air
fill ~8 ~-27 ~13 ~14 ~-27 ~13 minecraft:smooth_stone_slab[type=top]
fill ~15 ~-27 ~13 ~16 ~-27 ~13 minecraft:air
setblock ~17 ~-27 ~13 minecraft:smooth_stone_slab[type=top]
setblock ~18 ~-27 ~13 minecraft:light_gray_concrete
fill ~19 ~-27 ~13 ~20 ~-27 ~13 minecraft:air
fill ~21 ~-27 ~13 ~29 ~-27 ~13 minecraft:red_carpet
fill ~30 ~-27 ~13 ~31 ~-27 ~13 minecraft:air
setblock ~32 ~-27 ~13 minecraft:light_gray_concrete
fill ~33 ~-27 ~13 ~35 ~-27 ~13 minecraft:air
setblock ~36 ~-27 ~13 minecraft:light_gray_concrete
fill ~37 ~-27 ~13 ~49 ~-27 ~13 minecraft:air
setblock ~50 ~-27 ~13 minecraft:light_gray_concrete
fill ~51 ~-27 ~13 ~63 ~-27 ~13 minecraft:air
setblock ~64 ~-27 ~13 minecraft:light_gray_concrete
setblock ~4 ~-27 ~14 minecraft:light_gray_concrete
setblock ~5 ~-27 ~14 minecraft:cauldron
fill ~6 ~-27 ~14 ~16 ~-27 ~14 minecraft:air
setblock ~17 ~-27 ~14 minecraft:cauldron
setblock ~18 ~-27 ~14 minecraft:light_gray_concrete
fill ~19 ~-27 ~14 ~20 ~-27 ~14 minecraft:air
fill ~21 ~-27 ~14 ~29 ~-27 ~14 minecraft:red_carpet
fill ~30 ~-27 ~14 ~31 ~-27 ~14 minecraft:air
setblock ~32 ~-27 ~14 minecraft:light_gray_concrete
fill ~33 ~-27 ~14 ~35 ~-27 ~14 minecraft:air
setblock ~36 ~-27 ~14 minecraft:light_gray_concrete
setblock ~37 ~-27 ~14 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-27 ~14 ~48 ~-27 ~14 minecraft:air
setblock ~49 ~-27 ~14 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~14 minecraft:light_gray_concrete
setblock ~51 ~-27 ~14 minecraft:flowering_azalea
fill ~52 ~-27 ~14 ~62 ~-27 ~14 minecraft:air
setblock ~63 ~-27 ~14 minecraft:flowering_azalea
setblock ~64 ~-27 ~14 minecraft:light_gray_concrete
setblock ~4 ~-27 ~15 minecraft:light_gray_concrete
setblock ~5 ~-27 ~15 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~15 ~16 ~-27 ~15 minecraft:air
setblock ~17 ~-27 ~15 minecraft:smooth_stone_slab[type=top]
setblock ~18 ~-27 ~15 minecraft:light_gray_concrete
fill ~19 ~-27 ~15 ~20 ~-27 ~15 minecraft:air
fill ~21 ~-27 ~15 ~29 ~-27 ~15 minecraft:red_carpet
fill ~30 ~-27 ~15 ~31 ~-27 ~15 minecraft:air
setblock ~32 ~-27 ~15 minecraft:light_gray_concrete
fill ~33 ~-27 ~15 ~35 ~-27 ~15 minecraft:air
setblock ~36 ~-27 ~15 minecraft:light_gray_concrete
setblock ~37 ~-27 ~15 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-27 ~15 ~48 ~-27 ~15 minecraft:air
setblock ~49 ~-27 ~15 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~15 minecraft:light_gray_concrete
fill ~51 ~-27 ~15 ~63 ~-27 ~15 minecraft:air
setblock ~64 ~-27 ~15 minecraft:light_gray_concrete
setblock ~4 ~-27 ~16 minecraft:light_gray_concrete
setblock ~5 ~-27 ~16 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-27 ~16 ~16 ~-27 ~16 minecraft:air
setblock ~17 ~-27 ~16 minecraft:smooth_stone_slab[type=top]
setblock ~18 ~-27 ~16 minecraft:light_gray_concrete
fill ~19 ~-27 ~16 ~31 ~-27 ~16 minecraft:air
setblock ~32 ~-27 ~16 minecraft:light_gray_concrete
fill ~33 ~-27 ~16 ~35 ~-27 ~16 minecraft:air
setblock ~36 ~-27 ~16 minecraft:light_gray_concrete
fill ~37 ~-27 ~16 ~49 ~-27 ~16 minecraft:air
setblock ~50 ~-27 ~16 minecraft:light_gray_concrete
setblock ~51 ~-27 ~16 minecraft:flowering_azalea
fill ~52 ~-27 ~16 ~62 ~-27 ~16 minecraft:air
setblock ~63 ~-27 ~16 minecraft:flowering_azalea
setblock ~64 ~-27 ~16 minecraft:light_gray_concrete
setblock ~4 ~-27 ~17 minecraft:light_gray_concrete
setblock ~5 ~-27 ~17 minecraft:cauldron
fill ~6 ~-27 ~17 ~7 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~8 ~-27 ~17 minecraft:cauldron
setblock ~9 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
fill ~10 ~-27 ~17 ~12 ~-27 ~17 minecraft:air
setblock ~13 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~14 ~-27 ~17 minecraft:cauldron
fill ~15 ~-27 ~17 ~16 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~17 ~-27 ~17 minecraft:cauldron
setblock ~18 ~-27 ~17 minecraft:light_gray_concrete
fill ~19 ~-27 ~17 ~31 ~-27 ~17 minecraft:air
setblock ~32 ~-27 ~17 minecraft:light_gray_concrete
fill ~33 ~-27 ~17 ~35 ~-27 ~17 minecraft:air
setblock ~36 ~-27 ~17 minecraft:light_gray_concrete
fill ~37 ~-27 ~17 ~38 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~39 ~-27 ~17 minecraft:air
fill ~40 ~-27 ~17 ~41 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~42 ~-27 ~17 minecraft:air
fill ~43 ~-27 ~17 ~44 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~45 ~-27 ~17 minecraft:air
fill ~46 ~-27 ~17 ~47 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~48 ~-27 ~17 minecraft:air
setblock ~49 ~-27 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~17 minecraft:light_gray_concrete
setblock ~51 ~-27 ~17 minecraft:air
setblock ~52 ~-27 ~17 minecraft:flowering_azalea
setblock ~53 ~-27 ~17 minecraft:air
setblock ~54 ~-27 ~17 minecraft:flowering_azalea
fill ~55 ~-27 ~17 ~59 ~-27 ~17 minecraft:air
setblock ~60 ~-27 ~17 minecraft:flowering_azalea
setblock ~61 ~-27 ~17 minecraft:air
setblock ~62 ~-27 ~17 minecraft:flowering_azalea
setblock ~63 ~-27 ~17 minecraft:air
setblock ~64 ~-27 ~17 minecraft:light_gray_concrete
fill ~4 ~-27 ~18 ~10 ~-27 ~18 minecraft:light_gray_concrete
setblock ~11 ~-27 ~18 minecraft:air
fill ~12 ~-27 ~18 ~32 ~-27 ~18 minecraft:light_gray_concrete
fill ~33 ~-27 ~18 ~35 ~-27 ~18 minecraft:air
fill ~36 ~-27 ~18 ~56 ~-27 ~18 minecraft:light_gray_concrete
setblock ~57 ~-27 ~18 minecraft:air
fill ~58 ~-27 ~18 ~64 ~-27 ~18 minecraft:light_gray_concrete
setblock ~4 ~-27 ~19 minecraft:light_gray_concrete
fill ~5 ~-27 ~19 ~7 ~-27 ~19 minecraft:packed_ice
setblock ~8 ~-27 ~19 minecraft:air
setblock ~9 ~-27 ~19 minecraft:packed_ice
fill ~10 ~-27 ~19 ~12 ~-27 ~19 minecraft:air
fill ~13 ~-27 ~19 ~15 ~-27 ~19 minecraft:packed_ice
setblock ~16 ~-27 ~19 minecraft:air
setblock ~17 ~-27 ~19 minecraft:packed_ice
setblock ~18 ~-27 ~19 minecraft:light_gray_concrete
fill ~19 ~-27 ~19 ~20 ~-27 ~19 minecraft:air
setblock ~21 ~-27 ~19 minecraft:smooth_stone_slab[type=top]
fill ~22 ~-27 ~19 ~25 ~-27 ~19 minecraft:air
setblock ~26 ~-27 ~19 minecraft:smooth_stone_slab[type=top]
fill ~27 ~-27 ~19 ~31 ~-27 ~19 minecraft:air
setblock ~32 ~-27 ~19 minecraft:light_gray_concrete
fill ~33 ~-27 ~19 ~35 ~-27 ~19 minecraft:air
setblock ~36 ~-27 ~19 minecraft:light_gray_concrete
setblock ~37 ~-27 ~19 minecraft:air
setblock ~38 ~-27 ~19 minecraft:flowering_azalea
setblock ~39 ~-27 ~19 minecraft:air
setblock ~40 ~-27 ~19 minecraft:flowering_azalea
setblock ~41 ~-27 ~19 minecraft:air
setblock ~42 ~-27 ~19 minecraft:flowering_azalea
setblock ~43 ~-27 ~19 minecraft:air
setblock ~44 ~-27 ~19 minecraft:flowering_azalea
setblock ~45 ~-27 ~19 minecraft:air
setblock ~46 ~-27 ~19 minecraft:flowering_azalea
setblock ~47 ~-27 ~19 minecraft:air
setblock ~48 ~-27 ~19 minecraft:flowering_azalea
setblock ~49 ~-27 ~19 minecraft:air
setblock ~50 ~-27 ~19 minecraft:light_gray_concrete
setblock ~51 ~-27 ~19 minecraft:cauldron
fill ~52 ~-27 ~19 ~53 ~-27 ~19 minecraft:smooth_stone_slab[type=top]
setblock ~54 ~-27 ~19 minecraft:cauldron
setblock ~55 ~-27 ~19 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~19 ~58 ~-27 ~19 minecraft:air
setblock ~59 ~-27 ~19 minecraft:smooth_stone_slab[type=top]
setblock ~60 ~-27 ~19 minecraft:cauldron
fill ~61 ~-27 ~19 ~62 ~-27 ~19 minecraft:smooth_stone_slab[type=top]
setblock ~63 ~-27 ~19 minecraft:cauldron
setblock ~64 ~-27 ~19 minecraft:light_gray_concrete
setblock ~4 ~-27 ~20 minecraft:light_gray_concrete
setblock ~5 ~-27 ~20 minecraft:packed_ice
fill ~6 ~-27 ~20 ~16 ~-27 ~20 minecraft:air
setblock ~17 ~-27 ~20 minecraft:packed_ice
setblock ~18 ~-27 ~20 minecraft:light_gray_concrete
setblock ~19 ~-27 ~20 minecraft:air
fill ~20 ~-27 ~20 ~22 ~-27 ~20 minecraft:iron_block
setblock ~23 ~-27 ~20 minecraft:air
fill ~24 ~-27 ~20 ~26 ~-27 ~20 minecraft:iron_block
fill ~27 ~-27 ~20 ~48 ~-27 ~20 minecraft:air
setblock ~49 ~-27 ~20 minecraft:flowering_azalea
setblock ~50 ~-27 ~20 minecraft:light_gray_concrete
setblock ~51 ~-27 ~20 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~20 ~62 ~-27 ~20 minecraft:air
setblock ~63 ~-27 ~20 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~20 minecraft:light_gray_concrete
setblock ~4 ~-27 ~21 minecraft:light_gray_concrete
setblock ~5 ~-27 ~21 minecraft:packed_ice
fill ~6 ~-27 ~21 ~7 ~-27 ~21 minecraft:air
setblock ~8 ~-27 ~21 minecraft:barrel
fill ~9 ~-27 ~21 ~10 ~-27 ~21 minecraft:air
setblock ~11 ~-27 ~21 minecraft:barrel
fill ~12 ~-27 ~21 ~13 ~-27 ~21 minecraft:air
setblock ~14 ~-27 ~21 minecraft:barrel
fill ~15 ~-27 ~21 ~16 ~-27 ~21 minecraft:air
setblock ~17 ~-27 ~21 minecraft:packed_ice
setblock ~18 ~-27 ~21 minecraft:light_gray_concrete
setblock ~19 ~-27 ~21 minecraft:smooth_stone_slab[type=top]
setblock ~20 ~-27 ~21 minecraft:iron_block
setblock ~21 ~-27 ~21 minecraft:sea_lantern
setblock ~22 ~-27 ~21 minecraft:iron_block
setblock ~23 ~-27 ~21 minecraft:air
setblock ~24 ~-27 ~21 minecraft:iron_block
setblock ~25 ~-27 ~21 minecraft:sea_lantern
setblock ~26 ~-27 ~21 minecraft:iron_block
fill ~27 ~-27 ~21 ~28 ~-27 ~21 minecraft:air
setblock ~29 ~-27 ~21 minecraft:smooth_stone_slab[type=top]
fill ~30 ~-27 ~21 ~31 ~-27 ~21 minecraft:air
setblock ~32 ~-27 ~21 minecraft:light_gray_concrete
fill ~33 ~-27 ~21 ~35 ~-27 ~21 minecraft:air
setblock ~36 ~-27 ~21 minecraft:light_gray_concrete
setblock ~37 ~-27 ~21 minecraft:air
setblock ~38 ~-27 ~21 minecraft:flowering_azalea
fill ~39 ~-27 ~21 ~49 ~-27 ~21 minecraft:air
setblock ~50 ~-27 ~21 minecraft:light_gray_concrete
setblock ~51 ~-27 ~21 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~21 ~62 ~-27 ~21 minecraft:air
setblock ~63 ~-27 ~21 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~21 minecraft:light_gray_concrete
setblock ~4 ~-27 ~22 minecraft:light_gray_concrete
fill ~5 ~-27 ~22 ~7 ~-27 ~22 minecraft:air
setblock ~8 ~-27 ~22 minecraft:barrel
fill ~9 ~-27 ~22 ~10 ~-27 ~22 minecraft:air
setblock ~11 ~-27 ~22 minecraft:barrel
fill ~12 ~-27 ~22 ~13 ~-27 ~22 minecraft:air
setblock ~14 ~-27 ~22 minecraft:barrel
fill ~15 ~-27 ~22 ~17 ~-27 ~22 minecraft:air
setblock ~18 ~-27 ~22 minecraft:light_gray_concrete
setblock ~19 ~-27 ~22 minecraft:air
fill ~20 ~-27 ~22 ~22 ~-27 ~22 minecraft:iron_block
setblock ~23 ~-27 ~22 minecraft:air
fill ~24 ~-27 ~22 ~26 ~-27 ~22 minecraft:iron_block
fill ~27 ~-27 ~22 ~28 ~-27 ~22 minecraft:air
fill ~29 ~-27 ~22 ~32 ~-27 ~22 minecraft:polished_andesite
fill ~33 ~-27 ~22 ~35 ~-27 ~22 minecraft:air
fill ~36 ~-27 ~22 ~39 ~-27 ~22 minecraft:polished_andesite
fill ~40 ~-27 ~22 ~48 ~-27 ~22 minecraft:air
setblock ~49 ~-27 ~22 minecraft:flowering_azalea
setblock ~50 ~-27 ~22 minecraft:light_gray_concrete
setblock ~51 ~-27 ~22 minecraft:cauldron
fill ~52 ~-27 ~22 ~54 ~-27 ~22 minecraft:air
setblock ~55 ~-27 ~22 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~22 ~58 ~-27 ~22 minecraft:air
setblock ~59 ~-27 ~22 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-27 ~22 ~62 ~-27 ~22 minecraft:air
setblock ~63 ~-27 ~22 minecraft:cauldron
setblock ~64 ~-27 ~22 minecraft:light_gray_concrete
setblock ~4 ~-27 ~23 minecraft:light_gray_concrete
setblock ~5 ~-27 ~23 minecraft:packed_ice
fill ~6 ~-27 ~23 ~7 ~-27 ~23 minecraft:air
setblock ~8 ~-27 ~23 minecraft:barrel
fill ~9 ~-27 ~23 ~10 ~-27 ~23 minecraft:air
setblock ~11 ~-27 ~23 minecraft:barrel
fill ~12 ~-27 ~23 ~13 ~-27 ~23 minecraft:air
setblock ~14 ~-27 ~23 minecraft:barrel
fill ~15 ~-27 ~23 ~16 ~-27 ~23 minecraft:air
setblock ~17 ~-27 ~23 minecraft:packed_ice
setblock ~18 ~-27 ~23 minecraft:light_gray_concrete
fill ~19 ~-27 ~23 ~28 ~-27 ~23 minecraft:air
setblock ~29 ~-27 ~23 minecraft:polished_andesite
fill ~30 ~-27 ~23 ~38 ~-27 ~23 minecraft:air
setblock ~39 ~-27 ~23 minecraft:polished_andesite
fill ~40 ~-27 ~23 ~49 ~-27 ~23 minecraft:air
setblock ~50 ~-27 ~23 minecraft:light_gray_concrete
setblock ~51 ~-27 ~23 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~23 ~54 ~-27 ~23 minecraft:air
setblock ~55 ~-27 ~23 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~23 ~58 ~-27 ~23 minecraft:air
setblock ~59 ~-27 ~23 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-27 ~23 ~62 ~-27 ~23 minecraft:air
setblock ~63 ~-27 ~23 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~23 minecraft:light_gray_concrete
setblock ~4 ~-27 ~24 minecraft:light_gray_concrete
setblock ~5 ~-27 ~24 minecraft:packed_ice
fill ~6 ~-27 ~24 ~7 ~-27 ~24 minecraft:air
setblock ~8 ~-27 ~24 minecraft:barrel
fill ~9 ~-27 ~24 ~10 ~-27 ~24 minecraft:air
setblock ~11 ~-27 ~24 minecraft:barrel
fill ~12 ~-27 ~24 ~13 ~-27 ~24 minecraft:air
setblock ~14 ~-27 ~24 minecraft:barrel
fill ~15 ~-27 ~24 ~16 ~-27 ~24 minecraft:air
setblock ~17 ~-27 ~24 minecraft:packed_ice
setblock ~18 ~-27 ~24 minecraft:light_gray_concrete
setblock ~19 ~-27 ~24 minecraft:air
fill ~20 ~-27 ~24 ~22 ~-27 ~24 minecraft:iron_block
fill ~23 ~-27 ~24 ~25 ~-27 ~24 minecraft:air
fill ~26 ~-27 ~24 ~27 ~-27 ~24 minecraft:polished_andesite
fill ~28 ~-27 ~24 ~29 ~-27 ~24 minecraft:air
setblock ~30 ~-27 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-27 ~24 ~37 ~-27 ~24 minecraft:air
setblock ~38 ~-27 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-27 ~24 ~40 ~-27 ~24 minecraft:air
fill ~41 ~-27 ~24 ~42 ~-27 ~24 minecraft:polished_andesite
setblock ~43 ~-27 ~24 minecraft:flowering_azalea
fill ~44 ~-27 ~24 ~48 ~-27 ~24 minecraft:air
setblock ~49 ~-27 ~24 minecraft:flowering_azalea
setblock ~50 ~-27 ~24 minecraft:light_gray_concrete
setblock ~51 ~-27 ~24 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~24 ~54 ~-27 ~24 minecraft:air
setblock ~55 ~-27 ~24 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~24 ~58 ~-27 ~24 minecraft:air
setblock ~59 ~-27 ~24 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-27 ~24 ~62 ~-27 ~24 minecraft:air
setblock ~63 ~-27 ~24 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~24 minecraft:light_gray_concrete
setblock ~4 ~-27 ~25 minecraft:light_gray_concrete
setblock ~5 ~-27 ~25 minecraft:packed_ice
fill ~6 ~-27 ~25 ~16 ~-27 ~25 minecraft:air
setblock ~17 ~-27 ~25 minecraft:packed_ice
setblock ~18 ~-27 ~25 minecraft:light_gray_concrete
setblock ~19 ~-27 ~25 minecraft:air
setblock ~20 ~-27 ~25 minecraft:iron_block
setblock ~21 ~-27 ~25 minecraft:sea_lantern
setblock ~22 ~-27 ~25 minecraft:iron_block
fill ~23 ~-27 ~25 ~24 ~-27 ~25 minecraft:air
fill ~25 ~-27 ~25 ~26 ~-27 ~25 minecraft:polished_andesite
fill ~27 ~-27 ~25 ~31 ~-27 ~25 minecraft:air
setblock ~32 ~-27 ~25 minecraft:glass_pane[east=true]
fill ~33 ~-27 ~25 ~35 ~-27 ~25 minecraft:glass_pane[east=true,west=true]
setblock ~36 ~-27 ~25 minecraft:glass_pane[west=true]
fill ~37 ~-27 ~25 ~41 ~-27 ~25 minecraft:air
fill ~42 ~-27 ~25 ~43 ~-27 ~25 minecraft:polished_andesite
setblock ~44 ~-27 ~25 minecraft:flowering_azalea
fill ~45 ~-27 ~25 ~49 ~-27 ~25 minecraft:air
setblock ~50 ~-27 ~25 minecraft:light_gray_concrete
setblock ~51 ~-27 ~25 minecraft:cauldron
fill ~52 ~-27 ~25 ~54 ~-27 ~25 minecraft:air
setblock ~55 ~-27 ~25 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~25 ~58 ~-27 ~25 minecraft:air
setblock ~59 ~-27 ~25 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-27 ~25 ~62 ~-27 ~25 minecraft:air
setblock ~63 ~-27 ~25 minecraft:cauldron
setblock ~64 ~-27 ~25 minecraft:light_gray_concrete
setblock ~4 ~-27 ~26 minecraft:light_gray_concrete
fill ~5 ~-27 ~26 ~7 ~-27 ~26 minecraft:air
setblock ~8 ~-27 ~26 minecraft:barrel
fill ~9 ~-27 ~26 ~10 ~-27 ~26 minecraft:air
setblock ~11 ~-27 ~26 minecraft:barrel
fill ~12 ~-27 ~26 ~13 ~-27 ~26 minecraft:air
setblock ~14 ~-27 ~26 minecraft:barrel
fill ~15 ~-27 ~26 ~17 ~-27 ~26 minecraft:air
setblock ~18 ~-27 ~26 minecraft:light_gray_concrete
setblock ~19 ~-27 ~26 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~26 ~22 ~-27 ~26 minecraft:iron_block
setblock ~23 ~-27 ~26 minecraft:air
fill ~24 ~-27 ~26 ~25 ~-27 ~26 minecraft:polished_andesite
fill ~26 ~-27 ~26 ~29 ~-27 ~26 minecraft:air
setblock ~30 ~-27 ~26 minecraft:glass_pane[east=true]
setblock ~31 ~-27 ~26 minecraft:glass_pane[west=true]
fill ~32 ~-27 ~26 ~36 ~-27 ~26 minecraft:air
setblock ~37 ~-27 ~26 minecraft:glass_pane[east=true]
setblock ~38 ~-27 ~26 minecraft:glass_pane[west=true]
fill ~39 ~-27 ~26 ~42 ~-27 ~26 minecraft:air
fill ~43 ~-27 ~26 ~44 ~-27 ~26 minecraft:polished_andesite
setblock ~45 ~-27 ~26 minecraft:flowering_azalea
fill ~46 ~-27 ~26 ~48 ~-27 ~26 minecraft:air
setblock ~49 ~-27 ~26 minecraft:flowering_azalea
setblock ~50 ~-27 ~26 minecraft:light_gray_concrete
setblock ~51 ~-27 ~26 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~26 ~54 ~-27 ~26 minecraft:air
setblock ~55 ~-27 ~26 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~26 ~58 ~-27 ~26 minecraft:air
setblock ~59 ~-27 ~26 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-27 ~26 ~62 ~-27 ~26 minecraft:air
setblock ~63 ~-27 ~26 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~26 minecraft:light_gray_concrete
setblock ~4 ~-27 ~27 minecraft:light_gray_concrete
setblock ~5 ~-27 ~27 minecraft:packed_ice
fill ~6 ~-27 ~27 ~7 ~-27 ~27 minecraft:air
setblock ~8 ~-27 ~27 minecraft:barrel
fill ~9 ~-27 ~27 ~10 ~-27 ~27 minecraft:air
setblock ~11 ~-27 ~27 minecraft:barrel
fill ~12 ~-27 ~27 ~13 ~-27 ~27 minecraft:air
setblock ~14 ~-27 ~27 minecraft:barrel
fill ~15 ~-27 ~27 ~16 ~-27 ~27 minecraft:air
setblock ~17 ~-27 ~27 minecraft:packed_ice
setblock ~18 ~-27 ~27 minecraft:light_gray_concrete
fill ~19 ~-27 ~27 ~22 ~-27 ~27 minecraft:air
setblock ~23 ~-27 ~27 minecraft:smooth_stone_slab[type=top]
setblock ~24 ~-27 ~27 minecraft:polished_andesite
fill ~25 ~-27 ~27 ~27 ~-27 ~27 minecraft:air
setblock ~28 ~-27 ~27 minecraft:glass_pane[east=true]
setblock ~29 ~-27 ~27 minecraft:glass_pane[west=true]
fill ~30 ~-27 ~27 ~38 ~-27 ~27 minecraft:air
setblock ~39 ~-27 ~27 minecraft:glass_pane[east=true]
setblock ~40 ~-27 ~27 minecraft:glass_pane[west=true]
fill ~41 ~-27 ~27 ~43 ~-27 ~27 minecraft:air
setblock ~44 ~-27 ~27 minecraft:polished_andesite
fill ~45 ~-27 ~27 ~49 ~-27 ~27 minecraft:air
setblock ~50 ~-27 ~27 minecraft:light_gray_concrete
setblock ~51 ~-27 ~27 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~27 ~54 ~-27 ~27 minecraft:air
setblock ~55 ~-27 ~27 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~27 ~58 ~-27 ~27 minecraft:air
setblock ~59 ~-27 ~27 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-27 ~27 ~62 ~-27 ~27 minecraft:air
setblock ~63 ~-27 ~27 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~27 minecraft:light_gray_concrete
setblock ~4 ~-27 ~28 minecraft:light_gray_concrete
setblock ~5 ~-27 ~28 minecraft:packed_ice
fill ~6 ~-27 ~28 ~7 ~-27 ~28 minecraft:air
setblock ~8 ~-27 ~28 minecraft:barrel
fill ~9 ~-27 ~28 ~10 ~-27 ~28 minecraft:air
setblock ~11 ~-27 ~28 minecraft:barrel
fill ~12 ~-27 ~28 ~13 ~-27 ~28 minecraft:air
setblock ~14 ~-27 ~28 minecraft:barrel
fill ~15 ~-27 ~28 ~16 ~-27 ~28 minecraft:air
setblock ~17 ~-27 ~28 minecraft:packed_ice
setblock ~18 ~-27 ~28 minecraft:light_gray_concrete
fill ~19 ~-27 ~28 ~21 ~-27 ~28 minecraft:air
setblock ~22 ~-27 ~28 minecraft:smooth_stone_slab[type=top]
setblock ~23 ~-27 ~28 minecraft:polished_andesite
fill ~24 ~-27 ~28 ~26 ~-27 ~28 minecraft:air
setblock ~27 ~-27 ~28 minecraft:glass_pane[south=true]
fill ~28 ~-27 ~28 ~40 ~-27 ~28 minecraft:air
setblock ~41 ~-27 ~28 minecraft:glass_pane[south=true]
fill ~42 ~-27 ~28 ~44 ~-27 ~28 minecraft:air
setblock ~45 ~-27 ~28 minecraft:polished_andesite
fill ~46 ~-27 ~28 ~48 ~-27 ~28 minecraft:air
setblock ~49 ~-27 ~28 minecraft:flowering_azalea
setblock ~50 ~-27 ~28 minecraft:light_gray_concrete
setblock ~51 ~-27 ~28 minecraft:cauldron
fill ~52 ~-27 ~28 ~54 ~-27 ~28 minecraft:air
setblock ~55 ~-27 ~28 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~28 ~58 ~-27 ~28 minecraft:air
setblock ~59 ~-27 ~28 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-27 ~28 ~62 ~-27 ~28 minecraft:air
setblock ~63 ~-27 ~28 minecraft:cauldron
setblock ~64 ~-27 ~28 minecraft:light_gray_concrete
setblock ~4 ~-27 ~29 minecraft:light_gray_concrete
setblock ~5 ~-27 ~29 minecraft:packed_ice
fill ~6 ~-27 ~29 ~7 ~-27 ~29 minecraft:air
setblock ~8 ~-27 ~29 minecraft:barrel
fill ~9 ~-27 ~29 ~10 ~-27 ~29 minecraft:air
setblock ~11 ~-27 ~29 minecraft:barrel
fill ~12 ~-27 ~29 ~13 ~-27 ~29 minecraft:air
setblock ~14 ~-27 ~29 minecraft:barrel
fill ~15 ~-27 ~29 ~16 ~-27 ~29 minecraft:air
setblock ~17 ~-27 ~29 minecraft:packed_ice
setblock ~18 ~-27 ~29 minecraft:light_gray_concrete
fill ~19 ~-27 ~29 ~20 ~-27 ~29 minecraft:air
setblock ~21 ~-27 ~29 minecraft:smooth_stone_slab[type=top]
fill ~22 ~-27 ~29 ~23 ~-27 ~29 minecraft:polished_andesite
fill ~24 ~-27 ~29 ~26 ~-27 ~29 minecraft:air
setblock ~27 ~-27 ~29 minecraft:glass_pane[north=true]
fill ~28 ~-27 ~29 ~40 ~-27 ~29 minecraft:air
setblock ~41 ~-27 ~29 minecraft:glass_pane[north=true]
fill ~42 ~-27 ~29 ~44 ~-27 ~29 minecraft:air
fill ~45 ~-27 ~29 ~46 ~-27 ~29 minecraft:polished_andesite
fill ~47 ~-27 ~29 ~49 ~-27 ~29 minecraft:air
setblock ~50 ~-27 ~29 minecraft:light_gray_concrete
setblock ~51 ~-27 ~29 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~29 ~62 ~-27 ~29 minecraft:air
setblock ~63 ~-27 ~29 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~29 minecraft:light_gray_concrete
setblock ~4 ~-27 ~30 minecraft:light_gray_concrete
fill ~5 ~-27 ~30 ~17 ~-27 ~30 minecraft:air
setblock ~18 ~-27 ~30 minecraft:light_gray_concrete
fill ~19 ~-27 ~30 ~21 ~-27 ~30 minecraft:air
setblock ~22 ~-27 ~30 minecraft:polished_andesite
setblock ~23 ~-27 ~30 minecraft:air
setblock ~24 ~-27 ~30 minecraft:chiseled_quartz_block
setblock ~25 ~-27 ~30 minecraft:air
setblock ~26 ~-27 ~30 minecraft:glass_pane[south=true]
fill ~27 ~-27 ~30 ~41 ~-27 ~30 minecraft:air
setblock ~42 ~-27 ~30 minecraft:glass_pane[south=true]
setblock ~43 ~-27 ~30 minecraft:air
setblock ~44 ~-27 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-27 ~30 minecraft:air
setblock ~46 ~-27 ~30 minecraft:polished_andesite
setblock ~47 ~-27 ~30 minecraft:flowering_azalea
setblock ~48 ~-27 ~30 minecraft:air
setblock ~49 ~-27 ~30 minecraft:flowering_azalea
setblock ~50 ~-27 ~30 minecraft:light_gray_concrete
setblock ~51 ~-27 ~30 minecraft:smooth_stone_slab[type=top]
fill ~52 ~-27 ~30 ~62 ~-27 ~30 minecraft:air
setblock ~63 ~-27 ~30 minecraft:smooth_stone_slab[type=top]
setblock ~64 ~-27 ~30 minecraft:light_gray_concrete
setblock ~4 ~-27 ~31 minecraft:light_gray_concrete
fill ~5 ~-27 ~31 ~7 ~-27 ~31 minecraft:packed_ice
setblock ~8 ~-27 ~31 minecraft:air
setblock ~9 ~-27 ~31 minecraft:packed_ice
fill ~10 ~-27 ~31 ~12 ~-27 ~31 minecraft:air
fill ~13 ~-27 ~31 ~15 ~-27 ~31 minecraft:packed_ice
setblock ~16 ~-27 ~31 minecraft:air
setblock ~17 ~-27 ~31 minecraft:packed_ice
setblock ~18 ~-27 ~31 minecraft:light_gray_concrete
fill ~19 ~-27 ~31 ~21 ~-27 ~31 minecraft:air
setblock ~22 ~-27 ~31 minecraft:polished_andesite
fill ~23 ~-27 ~31 ~25 ~-27 ~31 minecraft:air
setblock ~26 ~-27 ~31 minecraft:glass_pane[north=true,south=true]
fill ~27 ~-27 ~31 ~41 ~-27 ~31 minecraft:air
setblock ~42 ~-27 ~31 minecraft:glass_pane[north=true]
fill ~43 ~-27 ~31 ~45 ~-27 ~31 minecraft:air
setblock ~46 ~-27 ~31 minecraft:polished_andesite
fill ~47 ~-27 ~31 ~49 ~-27 ~31 minecraft:air
setblock ~50 ~-27 ~31 minecraft:light_gray_concrete
setblock ~51 ~-27 ~31 minecraft:cauldron
fill ~52 ~-27 ~31 ~53 ~-27 ~31 minecraft:smooth_stone_slab[type=top]
setblock ~54 ~-27 ~31 minecraft:cauldron
setblock ~55 ~-27 ~31 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-27 ~31 ~58 ~-27 ~31 minecraft:air
setblock ~59 ~-27 ~31 minecraft:smooth_stone_slab[type=top]
setblock ~60 ~-27 ~31 minecraft:cauldron
fill ~61 ~-27 ~31 ~62 ~-27 ~31 minecraft:smooth_stone_slab[type=top]
setblock ~63 ~-27 ~31 minecraft:cauldron
setblock ~64 ~-27 ~31 minecraft:light_gray_concrete
fill ~4 ~-27 ~32 ~10 ~-27 ~32 minecraft:light_gray_concrete
setblock ~11 ~-27 ~32 minecraft:air
fill ~12 ~-27 ~32 ~19 ~-27 ~32 minecraft:light_gray_concrete
setblock ~20 ~-27 ~32 minecraft:air
setblock ~21 ~-27 ~32 minecraft:light_gray_concrete
setblock ~22 ~-27 ~32 minecraft:polished_andesite
fill ~23 ~-27 ~32 ~24 ~-27 ~32 minecraft:air
setblock ~25 ~-27 ~32 minecraft:glass_pane[east=true]
setblock ~26 ~-27 ~32 minecraft:iron_bars[north=true,east=true,west=true]
fill ~27 ~-27 ~32 ~30 ~-27 ~32 minecraft:iron_bars[east=true,west=true]
setblock ~31 ~-27 ~32 minecraft:iron_bars[west=true]
setblock ~32 ~-27 ~32 minecraft:air
fill ~33 ~-27 ~32 ~35 ~-27 ~32 minecraft:glass
fill ~36 ~-27 ~32 ~42 ~-27 ~32 minecraft:air
setblock ~43 ~-27 ~32 minecraft:glass_pane[south=true]
fill ~44 ~-27 ~32 ~45 ~-27 ~32 minecraft:air
setblock ~46 ~-27 ~32 minecraft:polished_andesite
setblock ~47 ~-27 ~32 minecraft:light_gray_concrete
setblock ~48 ~-27 ~32 minecraft:air
fill ~49 ~-27 ~32 ~56 ~-27 ~32 minecraft:light_gray_concrete
setblock ~57 ~-27 ~32 minecraft:air
fill ~58 ~-27 ~32 ~64 ~-27 ~32 minecraft:light_gray_concrete
setblock ~4 ~-27 ~33 minecraft:light_gray_concrete
fill ~5 ~-27 ~33 ~34 ~-27 ~33 minecraft:air
setblock ~35 ~-27 ~33 minecraft:glass
fill ~36 ~-27 ~33 ~42 ~-27 ~33 minecraft:air
setblock ~43 ~-27 ~33 minecraft:glass_pane[north=true,south=true]
fill ~44 ~-27 ~33 ~63 ~-27 ~33 minecraft:air
setblock ~64 ~-27 ~33 minecraft:light_gray_concrete
setblock ~4 ~-27 ~34 minecraft:light_gray_concrete
fill ~5 ~-27 ~34 ~32 ~-27 ~34 minecraft:air
fill ~33 ~-27 ~34 ~35 ~-27 ~34 minecraft:glass
fill ~36 ~-27 ~34 ~42 ~-27 ~34 minecraft:air
setblock ~43 ~-27 ~34 minecraft:glass_pane[north=true,south=true]
fill ~44 ~-27 ~34 ~63 ~-27 ~34 minecraft:air
setblock ~64 ~-27 ~34 minecraft:light_gray_concrete
setblock ~4 ~-27 ~35 minecraft:light_gray_concrete
fill ~5 ~-27 ~35 ~34 ~-27 ~35 minecraft:air
setblock ~35 ~-27 ~35 minecraft:glass
fill ~36 ~-27 ~35 ~42 ~-27 ~35 minecraft:air
setblock ~43 ~-27 ~35 minecraft:glass_pane[north=true,south=true]
fill ~44 ~-27 ~35 ~63 ~-27 ~35 minecraft:air
setblock ~64 ~-27 ~35 minecraft:light_gray_concrete
fill ~4 ~-27 ~36 ~10 ~-27 ~36 minecraft:light_gray_concrete
setblock ~11 ~-27 ~36 minecraft:air
fill ~12 ~-27 ~36 ~19 ~-27 ~36 minecraft:light_gray_concrete
setblock ~20 ~-27 ~36 minecraft:air
setblock ~21 ~-27 ~36 minecraft:light_gray_concrete
setblock ~22 ~-27 ~36 minecraft:polished_andesite
fill ~23 ~-27 ~36 ~24 ~-27 ~36 minecraft:air
setblock ~25 ~-27 ~36 minecraft:glass_pane[east=true]
setblock ~26 ~-27 ~36 minecraft:iron_bars[east=true,south=true,west=true]
fill ~27 ~-27 ~36 ~30 ~-27 ~36 minecraft:iron_bars[east=true,west=true]
setblock ~31 ~-27 ~36 minecraft:iron_bars[west=true]
setblock ~32 ~-27 ~36 minecraft:air
fill ~33 ~-27 ~36 ~35 ~-27 ~36 minecraft:glass
fill ~36 ~-27 ~36 ~42 ~-27 ~36 minecraft:air
setblock ~43 ~-27 ~36 minecraft:glass_pane[north=true]
fill ~44 ~-27 ~36 ~45 ~-27 ~36 minecraft:air
setblock ~46 ~-27 ~36 minecraft:polished_andesite
setblock ~47 ~-27 ~36 minecraft:light_gray_concrete
setblock ~48 ~-27 ~36 minecraft:air
fill ~49 ~-27 ~36 ~56 ~-27 ~36 minecraft:light_gray_concrete
setblock ~57 ~-27 ~36 minecraft:air
fill ~58 ~-27 ~36 ~64 ~-27 ~36 minecraft:light_gray_concrete
setblock ~4 ~-27 ~37 minecraft:light_gray_concrete
fill ~5 ~-27 ~37 ~17 ~-27 ~37 minecraft:air
setblock ~18 ~-27 ~37 minecraft:light_gray_concrete
fill ~19 ~-27 ~37 ~21 ~-27 ~37 minecraft:air
setblock ~22 ~-27 ~37 minecraft:polished_andesite
fill ~23 ~-27 ~37 ~25 ~-27 ~37 minecraft:air
setblock ~26 ~-27 ~37 minecraft:glass_pane[north=true,south=true]
fill ~27 ~-27 ~37 ~41 ~-27 ~37 minecraft:air
setblock ~42 ~-27 ~37 minecraft:glass_pane[south=true]
fill ~43 ~-27 ~37 ~45 ~-27 ~37 minecraft:air
setblock ~46 ~-27 ~37 minecraft:polished_andesite
fill ~47 ~-27 ~37 ~49 ~-27 ~37 minecraft:air
setblock ~50 ~-27 ~37 minecraft:light_gray_concrete
fill ~51 ~-27 ~37 ~53 ~-27 ~37 minecraft:packed_ice
setblock ~54 ~-27 ~37 minecraft:air
setblock ~55 ~-27 ~37 minecraft:packed_ice
fill ~56 ~-27 ~37 ~58 ~-27 ~37 minecraft:air
fill ~59 ~-27 ~37 ~61 ~-27 ~37 minecraft:packed_ice
setblock ~62 ~-27 ~37 minecraft:air
setblock ~63 ~-27 ~37 minecraft:packed_ice
setblock ~64 ~-27 ~37 minecraft:light_gray_concrete
setblock ~4 ~-27 ~38 minecraft:light_gray_concrete
fill ~5 ~-27 ~38 ~17 ~-27 ~38 minecraft:air
setblock ~18 ~-27 ~38 minecraft:light_gray_concrete
setblock ~19 ~-27 ~38 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~38 ~21 ~-27 ~38 minecraft:air
setblock ~22 ~-27 ~38 minecraft:polished_andesite
setblock ~23 ~-27 ~38 minecraft:air
setblock ~24 ~-27 ~38 minecraft:chiseled_quartz_block
setblock ~25 ~-27 ~38 minecraft:air
setblock ~26 ~-27 ~38 minecraft:glass_pane[north=true]
fill ~27 ~-27 ~38 ~41 ~-27 ~38 minecraft:air
setblock ~42 ~-27 ~38 minecraft:glass_pane[north=true]
setblock ~43 ~-27 ~38 minecraft:air
setblock ~44 ~-27 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-27 ~38 minecraft:air
setblock ~46 ~-27 ~38 minecraft:polished_andesite
setblock ~47 ~-27 ~38 minecraft:smooth_stone_slab[type=top]
fill ~48 ~-27 ~38 ~49 ~-27 ~38 minecraft:air
setblock ~50 ~-27 ~38 minecraft:light_gray_concrete
setblock ~51 ~-27 ~38 minecraft:packed_ice
fill ~52 ~-27 ~38 ~62 ~-27 ~38 minecraft:air
setblock ~63 ~-27 ~38 minecraft:packed_ice
setblock ~64 ~-27 ~38 minecraft:light_gray_concrete
setblock ~4 ~-27 ~39 minecraft:light_gray_concrete
fill ~5 ~-27 ~39 ~17 ~-27 ~39 minecraft:air
setblock ~18 ~-27 ~39 minecraft:light_gray_concrete
setblock ~19 ~-27 ~39 minecraft:smooth_stone_slab[type=top]
setblock ~20 ~-27 ~39 minecraft:air
setblock ~21 ~-27 ~39 minecraft:smooth_stone_slab[type=top]
fill ~22 ~-27 ~39 ~23 ~-27 ~39 minecraft:polished_andesite
fill ~24 ~-27 ~39 ~26 ~-27 ~39 minecraft:air
setblock ~27 ~-27 ~39 minecraft:glass_pane[south=true]
fill ~28 ~-27 ~39 ~40 ~-27 ~39 minecraft:air
setblock ~41 ~-27 ~39 minecraft:glass_pane[south=true]
fill ~42 ~-27 ~39 ~44 ~-27 ~39 minecraft:air
fill ~45 ~-27 ~39 ~46 ~-27 ~39 minecraft:polished_andesite
fill ~47 ~-27 ~39 ~49 ~-27 ~39 minecraft:air
setblock ~50 ~-27 ~39 minecraft:light_gray_concrete
setblock ~51 ~-27 ~39 minecraft:packed_ice
fill ~52 ~-27 ~39 ~53 ~-27 ~39 minecraft:air
setblock ~54 ~-27 ~39 minecraft:barrel
fill ~55 ~-27 ~39 ~56 ~-27 ~39 minecraft:air
setblock ~57 ~-27 ~39 minecraft:barrel
fill ~58 ~-27 ~39 ~59 ~-27 ~39 minecraft:air
setblock ~60 ~-27 ~39 minecraft:barrel
fill ~61 ~-27 ~39 ~62 ~-27 ~39 minecraft:air
setblock ~63 ~-27 ~39 minecraft:packed_ice
setblock ~64 ~-27 ~39 minecraft:light_gray_concrete
setblock ~4 ~-27 ~40 minecraft:light_gray_concrete
fill ~5 ~-27 ~40 ~8 ~-27 ~40 minecraft:air
setblock ~9 ~-27 ~40 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-27 ~40 ~11 ~-27 ~40 minecraft:spruce_slab[type=top]
setblock ~12 ~-27 ~40 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-27 ~40 ~17 ~-27 ~40 minecraft:air
setblock ~18 ~-27 ~40 minecraft:light_gray_concrete
fill ~19 ~-27 ~40 ~22 ~-27 ~40 minecraft:air
setblock ~23 ~-27 ~40 minecraft:polished_andesite
fill ~24 ~-27 ~40 ~26 ~-27 ~40 minecraft:air
setblock ~27 ~-27 ~40 minecraft:glass_pane[north=true]
fill ~28 ~-27 ~40 ~40 ~-27 ~40 minecraft:air
setblock ~41 ~-27 ~40 minecraft:glass_pane[north=true]
fill ~42 ~-27 ~40 ~44 ~-27 ~40 minecraft:air
setblock ~45 ~-27 ~40 minecraft:polished_andesite
fill ~46 ~-27 ~40 ~49 ~-27 ~40 minecraft:air
setblock ~50 ~-27 ~40 minecraft:light_gray_concrete
fill ~51 ~-27 ~40 ~53 ~-27 ~40 minecraft:air
setblock ~54 ~-27 ~40 minecraft:barrel
fill ~55 ~-27 ~40 ~56 ~-27 ~40 minecraft:air
setblock ~57 ~-27 ~40 minecraft:barrel
fill ~58 ~-27 ~40 ~59 ~-27 ~40 minecraft:air
setblock ~60 ~-27 ~40 minecraft:barrel
fill ~61 ~-27 ~40 ~63 ~-27 ~40 minecraft:air
setblock ~64 ~-27 ~40 minecraft:light_gray_concrete
setblock ~4 ~-27 ~41 minecraft:light_gray_concrete
fill ~5 ~-27 ~41 ~8 ~-27 ~41 minecraft:air
setblock ~9 ~-27 ~41 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-27 ~41 ~11 ~-27 ~41 minecraft:spruce_slab[type=top]
setblock ~12 ~-27 ~41 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-27 ~41 ~17 ~-27 ~41 minecraft:air
setblock ~18 ~-27 ~41 minecraft:light_gray_concrete
setblock ~19 ~-27 ~41 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~41 ~23 ~-27 ~41 minecraft:air
setblock ~24 ~-27 ~41 minecraft:polished_andesite
fill ~25 ~-27 ~41 ~27 ~-27 ~41 minecraft:air
setblock ~28 ~-27 ~41 minecraft:glass_pane[east=true]
setblock ~29 ~-27 ~41 minecraft:glass_pane[west=true]
fill ~30 ~-27 ~41 ~38 ~-27 ~41 minecraft:air
setblock ~39 ~-27 ~41 minecraft:glass_pane[east=true]
setblock ~40 ~-27 ~41 minecraft:glass_pane[west=true]
fill ~41 ~-27 ~41 ~43 ~-27 ~41 minecraft:air
setblock ~44 ~-27 ~41 minecraft:polished_andesite
fill ~45 ~-27 ~41 ~48 ~-27 ~41 minecraft:air
setblock ~49 ~-27 ~41 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~41 minecraft:light_gray_concrete
setblock ~51 ~-27 ~41 minecraft:packed_ice
fill ~52 ~-27 ~41 ~53 ~-27 ~41 minecraft:air
setblock ~54 ~-27 ~41 minecraft:barrel
fill ~55 ~-27 ~41 ~56 ~-27 ~41 minecraft:air
setblock ~57 ~-27 ~41 minecraft:barrel
fill ~58 ~-27 ~41 ~59 ~-27 ~41 minecraft:air
setblock ~60 ~-27 ~41 minecraft:barrel
fill ~61 ~-27 ~41 ~62 ~-27 ~41 minecraft:air
setblock ~63 ~-27 ~41 minecraft:packed_ice
setblock ~64 ~-27 ~41 minecraft:light_gray_concrete
setblock ~4 ~-27 ~42 minecraft:light_gray_concrete
setblock ~5 ~-27 ~42 minecraft:black_concrete
fill ~6 ~-27 ~42 ~8 ~-27 ~42 minecraft:air
setblock ~9 ~-27 ~42 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-27 ~42 ~11 ~-27 ~42 minecraft:spruce_slab[type=top]
setblock ~12 ~-27 ~42 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-27 ~42 ~17 ~-27 ~42 minecraft:air
setblock ~18 ~-27 ~42 minecraft:light_gray_concrete
setblock ~19 ~-27 ~42 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~42 ~21 ~-27 ~42 minecraft:air
setblock ~22 ~-27 ~42 minecraft:iron_block
setblock ~23 ~-27 ~42 minecraft:air
fill ~24 ~-27 ~42 ~25 ~-27 ~42 minecraft:polished_andesite
fill ~26 ~-27 ~42 ~29 ~-27 ~42 minecraft:air
setblock ~30 ~-27 ~42 minecraft:glass_pane[east=true]
setblock ~31 ~-27 ~42 minecraft:glass_pane[west=true]
fill ~32 ~-27 ~42 ~36 ~-27 ~42 minecraft:air
setblock ~37 ~-27 ~42 minecraft:glass_pane[east=true]
setblock ~38 ~-27 ~42 minecraft:glass_pane[west=true]
fill ~39 ~-27 ~42 ~42 ~-27 ~42 minecraft:air
fill ~43 ~-27 ~42 ~44 ~-27 ~42 minecraft:polished_andesite
setblock ~45 ~-27 ~42 minecraft:air
fill ~46 ~-27 ~42 ~48 ~-27 ~42 minecraft:iron_block
setblock ~49 ~-27 ~42 minecraft:air
setblock ~50 ~-27 ~42 minecraft:light_gray_concrete
setblock ~51 ~-27 ~42 minecraft:packed_ice
fill ~52 ~-27 ~42 ~53 ~-27 ~42 minecraft:air
setblock ~54 ~-27 ~42 minecraft:barrel
fill ~55 ~-27 ~42 ~56 ~-27 ~42 minecraft:air
setblock ~57 ~-27 ~42 minecraft:barrel
fill ~58 ~-27 ~42 ~59 ~-27 ~42 minecraft:air
setblock ~60 ~-27 ~42 minecraft:barrel
fill ~61 ~-27 ~42 ~62 ~-27 ~42 minecraft:air
setblock ~63 ~-27 ~42 minecraft:packed_ice
setblock ~64 ~-27 ~42 minecraft:light_gray_concrete
setblock ~4 ~-27 ~43 minecraft:light_gray_concrete
setblock ~5 ~-27 ~43 minecraft:black_concrete
fill ~6 ~-27 ~43 ~8 ~-27 ~43 minecraft:air
setblock ~9 ~-27 ~43 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-27 ~43 ~11 ~-27 ~43 minecraft:spruce_slab[type=top]
setblock ~12 ~-27 ~43 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-27 ~43 ~17 ~-27 ~43 minecraft:air
setblock ~18 ~-27 ~43 minecraft:light_gray_concrete
fill ~19 ~-27 ~43 ~23 ~-27 ~43 minecraft:air
setblock ~24 ~-27 ~43 minecraft:smooth_stone_slab[type=top]
fill ~25 ~-27 ~43 ~26 ~-27 ~43 minecraft:polished_andesite
fill ~27 ~-27 ~43 ~31 ~-27 ~43 minecraft:air
setblock ~32 ~-27 ~43 minecraft:glass_pane[east=true]
fill ~33 ~-27 ~43 ~35 ~-27 ~43 minecraft:glass_pane[east=true,west=true]
setblock ~36 ~-27 ~43 minecraft:glass_pane[west=true]
fill ~37 ~-27 ~43 ~41 ~-27 ~43 minecraft:air
fill ~42 ~-27 ~43 ~43 ~-27 ~43 minecraft:polished_andesite
fill ~44 ~-27 ~43 ~45 ~-27 ~43 minecraft:air
setblock ~46 ~-27 ~43 minecraft:iron_block
setblock ~47 ~-27 ~43 minecraft:sea_lantern
setblock ~48 ~-27 ~43 minecraft:iron_block
setblock ~49 ~-27 ~43 minecraft:air
setblock ~50 ~-27 ~43 minecraft:light_gray_concrete
setblock ~51 ~-27 ~43 minecraft:packed_ice
fill ~52 ~-27 ~43 ~62 ~-27 ~43 minecraft:air
setblock ~63 ~-27 ~43 minecraft:packed_ice
setblock ~64 ~-27 ~43 minecraft:light_gray_concrete
setblock ~4 ~-27 ~44 minecraft:light_gray_concrete
setblock ~5 ~-27 ~44 minecraft:black_concrete
fill ~6 ~-27 ~44 ~8 ~-27 ~44 minecraft:air
setblock ~9 ~-27 ~44 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-27 ~44 ~11 ~-27 ~44 minecraft:spruce_slab[type=top]
setblock ~12 ~-27 ~44 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-27 ~44 ~17 ~-27 ~44 minecraft:air
setblock ~18 ~-27 ~44 minecraft:light_gray_concrete
setblock ~19 ~-27 ~44 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~44 ~24 ~-27 ~44 minecraft:air
setblock ~25 ~-27 ~44 minecraft:smooth_stone_slab[type=top]
fill ~26 ~-27 ~44 ~27 ~-27 ~44 minecraft:polished_andesite
fill ~28 ~-27 ~44 ~29 ~-27 ~44 minecraft:air
setblock ~30 ~-27 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-27 ~44 ~37 ~-27 ~44 minecraft:air
setblock ~38 ~-27 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-27 ~44 ~40 ~-27 ~44 minecraft:air
fill ~41 ~-27 ~44 ~42 ~-27 ~44 minecraft:polished_andesite
fill ~43 ~-27 ~44 ~45 ~-27 ~44 minecraft:air
fill ~46 ~-27 ~44 ~48 ~-27 ~44 minecraft:iron_block
setblock ~49 ~-27 ~44 minecraft:air
setblock ~50 ~-27 ~44 minecraft:light_gray_concrete
fill ~51 ~-27 ~44 ~53 ~-27 ~44 minecraft:air
setblock ~54 ~-27 ~44 minecraft:barrel
fill ~55 ~-27 ~44 ~56 ~-27 ~44 minecraft:air
setblock ~57 ~-27 ~44 minecraft:barrel
fill ~58 ~-27 ~44 ~59 ~-27 ~44 minecraft:air
setblock ~60 ~-27 ~44 minecraft:barrel
fill ~61 ~-27 ~44 ~63 ~-27 ~44 minecraft:air
setblock ~64 ~-27 ~44 minecraft:light_gray_concrete
setblock ~4 ~-27 ~45 minecraft:light_gray_concrete
fill ~5 ~-27 ~45 ~8 ~-27 ~45 minecraft:air
setblock ~9 ~-27 ~45 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-27 ~45 ~11 ~-27 ~45 minecraft:spruce_slab[type=top]
setblock ~12 ~-27 ~45 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-27 ~45 ~17 ~-27 ~45 minecraft:air
setblock ~18 ~-27 ~45 minecraft:light_gray_concrete
setblock ~19 ~-27 ~45 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~45 ~28 ~-27 ~45 minecraft:air
setblock ~29 ~-27 ~45 minecraft:polished_andesite
fill ~30 ~-27 ~45 ~38 ~-27 ~45 minecraft:air
setblock ~39 ~-27 ~45 minecraft:polished_andesite
fill ~40 ~-27 ~45 ~49 ~-27 ~45 minecraft:air
setblock ~50 ~-27 ~45 minecraft:light_gray_concrete
setblock ~51 ~-27 ~45 minecraft:packed_ice
fill ~52 ~-27 ~45 ~53 ~-27 ~45 minecraft:air
setblock ~54 ~-27 ~45 minecraft:barrel
fill ~55 ~-27 ~45 ~56 ~-27 ~45 minecraft:air
setblock ~57 ~-27 ~45 minecraft:barrel
fill ~58 ~-27 ~45 ~59 ~-27 ~45 minecraft:air
setblock ~60 ~-27 ~45 minecraft:barrel
fill ~61 ~-27 ~45 ~62 ~-27 ~45 minecraft:air
setblock ~63 ~-27 ~45 minecraft:packed_ice
setblock ~64 ~-27 ~45 minecraft:light_gray_concrete
setblock ~4 ~-27 ~46 minecraft:light_gray_concrete
fill ~5 ~-27 ~46 ~8 ~-27 ~46 minecraft:air
setblock ~9 ~-27 ~46 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-27 ~46 ~11 ~-27 ~46 minecraft:spruce_slab[type=top]
setblock ~12 ~-27 ~46 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-27 ~46 ~17 ~-27 ~46 minecraft:air
setblock ~18 ~-27 ~46 minecraft:light_gray_concrete
fill ~19 ~-27 ~46 ~21 ~-27 ~46 minecraft:air
setblock ~22 ~-27 ~46 minecraft:iron_block
fill ~23 ~-27 ~46 ~28 ~-27 ~46 minecraft:air
fill ~29 ~-27 ~46 ~32 ~-27 ~46 minecraft:polished_andesite
fill ~33 ~-27 ~46 ~35 ~-27 ~46 minecraft:air
fill ~36 ~-27 ~46 ~39 ~-27 ~46 minecraft:polished_andesite
fill ~40 ~-27 ~46 ~41 ~-27 ~46 minecraft:air
fill ~42 ~-27 ~46 ~44 ~-27 ~46 minecraft:iron_block
setblock ~45 ~-27 ~46 minecraft:air
fill ~46 ~-27 ~46 ~48 ~-27 ~46 minecraft:iron_block
setblock ~49 ~-27 ~46 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-27 ~46 minecraft:light_gray_concrete
setblock ~51 ~-27 ~46 minecraft:packed_ice
fill ~52 ~-27 ~46 ~53 ~-27 ~46 minecraft:air
setblock ~54 ~-27 ~46 minecraft:barrel
fill ~55 ~-27 ~46 ~56 ~-27 ~46 minecraft:air
setblock ~57 ~-27 ~46 minecraft:barrel
fill ~58 ~-27 ~46 ~59 ~-27 ~46 minecraft:air
setblock ~60 ~-27 ~46 minecraft:barrel
fill ~61 ~-27 ~46 ~62 ~-27 ~46 minecraft:air
setblock ~63 ~-27 ~46 minecraft:packed_ice
setblock ~64 ~-27 ~46 minecraft:light_gray_concrete
setblock ~4 ~-27 ~47 minecraft:light_gray_concrete
fill ~5 ~-27 ~47 ~17 ~-27 ~47 minecraft:air
setblock ~18 ~-27 ~47 minecraft:light_gray_concrete
setblock ~19 ~-27 ~47 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~47 ~28 ~-27 ~47 minecraft:air
setblock ~29 ~-27 ~47 minecraft:smooth_stone_slab[type=top]
fill ~30 ~-27 ~47 ~31 ~-27 ~47 minecraft:air
setblock ~32 ~-27 ~47 minecraft:light_gray_concrete
fill ~33 ~-27 ~47 ~35 ~-27 ~47 minecraft:air
setblock ~36 ~-27 ~47 minecraft:light_gray_concrete
setblock ~37 ~-27 ~47 minecraft:air
setblock ~38 ~-27 ~47 minecraft:smooth_stone_slab[type=top]
fill ~39 ~-27 ~47 ~41 ~-27 ~47 minecraft:air
setblock ~42 ~-27 ~47 minecraft:iron_block
setblock ~43 ~-27 ~47 minecraft:sea_lantern
setblock ~44 ~-27 ~47 minecraft:iron_block
setblock ~45 ~-27 ~47 minecraft:air
setblock ~46 ~-27 ~47 minecraft:iron_block
setblock ~47 ~-27 ~47 minecraft:sea_lantern
setblock ~48 ~-27 ~47 minecraft:iron_block
setblock ~49 ~-27 ~47 minecraft:air
setblock ~50 ~-27 ~47 minecraft:light_gray_concrete
setblock ~51 ~-27 ~47 minecraft:packed_ice
fill ~52 ~-27 ~47 ~53 ~-27 ~47 minecraft:air
setblock ~54 ~-27 ~47 minecraft:barrel
fill ~55 ~-27 ~47 ~56 ~-27 ~47 minecraft:air
setblock ~57 ~-27 ~47 minecraft:barrel
fill ~58 ~-27 ~47 ~59 ~-27 ~47 minecraft:air
setblock ~60 ~-27 ~47 minecraft:barrel
fill ~61 ~-27 ~47 ~62 ~-27 ~47 minecraft:air
setblock ~63 ~-27 ~47 minecraft:packed_ice
setblock ~64 ~-27 ~47 minecraft:light_gray_concrete
setblock ~4 ~-27 ~48 minecraft:light_gray_concrete
fill ~5 ~-27 ~48 ~17 ~-27 ~48 minecraft:air
setblock ~18 ~-27 ~48 minecraft:light_gray_concrete
setblock ~19 ~-27 ~48 minecraft:smooth_stone_slab[type=top]
fill ~20 ~-27 ~48 ~41 ~-27 ~48 minecraft:air
fill ~42 ~-27 ~48 ~44 ~-27 ~48 minecraft:iron_block
setblock ~45 ~-27 ~48 minecraft:air
fill ~46 ~-27 ~48 ~48 ~-27 ~48 minecraft:iron_block
setblock ~49 ~-27 ~48 minecraft:air
setblock ~50 ~-27 ~48 minecraft:light_gray_concrete
fill ~51 ~-27 ~48 ~63 ~-27 ~48 minecraft:air
setblock ~64 ~-27 ~48 minecraft:light_gray_concrete
setblock ~4 ~-27 ~49 minecraft:light_gray_concrete
fill ~5 ~-27 ~49 ~17 ~-27 ~49 minecraft:air
setblock ~18 ~-27 ~49 minecraft:light_gray_concrete
setblock ~19 ~-27 ~49 minecraft:air
fill ~20 ~-27 ~49 ~21 ~-27 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~22 ~-27 ~49 minecraft:air
fill ~23 ~-27 ~49 ~24 ~-27 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~25 ~-27 ~49 minecraft:air
fill ~26 ~-27 ~49 ~27 ~-27 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~28 ~-27 ~49 minecraft:air
fill ~29 ~-27 ~49 ~30 ~-27 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~31 ~-27 ~49 minecraft:air
setblock ~32 ~-27 ~49 minecraft:light_gray_concrete
fill ~33 ~-27 ~49 ~35 ~-27 ~49 minecraft:air
setblock ~36 ~-27 ~49 minecraft:light_gray_concrete
fill ~37 ~-27 ~49 ~40 ~-27 ~49 minecraft:air
setblock ~41 ~-27 ~49 minecraft:smooth_stone_slab[type=top]
fill ~42 ~-27 ~49 ~45 ~-27 ~49 minecraft:air
setblock ~46 ~-27 ~49 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-27 ~49 ~49 ~-27 ~49 minecraft:air
setblock ~50 ~-27 ~49 minecraft:light_gray_concrete
fill ~51 ~-27 ~49 ~53 ~-27 ~49 minecraft:packed_ice
setblock ~54 ~-27 ~49 minecraft:air
setblock ~55 ~-27 ~49 minecraft:packed_ice
fill ~56 ~-27 ~49 ~58 ~-27 ~49 minecraft:air
fill ~59 ~-27 ~49 ~61 ~-27 ~49 minecraft:packed_ice
setblock ~62 ~-27 ~49 minecraft:air
setblock ~63 ~-27 ~49 minecraft:packed_ice
setblock ~64 ~-27 ~49 minecraft:light_gray_concrete
fill ~4 ~-27 ~50 ~10 ~-27 ~50 minecraft:light_gray_concrete
setblock ~11 ~-27 ~50 minecraft:air
fill ~12 ~-27 ~50 ~32 ~-27 ~50 minecraft:light_gray_concrete
fill ~33 ~-27 ~50 ~35 ~-27 ~50 minecraft:air
fill ~36 ~-27 ~50 ~56 ~-27 ~50 minecraft:light_gray_concrete
setblock ~57 ~-27 ~50 minecraft:air
fill ~58 ~-27 ~50 ~64 ~-27 ~50 minecraft:light_gray_concrete
setblock ~4 ~-27 ~51 minecraft:light_gray_concrete
fill ~5 ~-27 ~51 ~17 ~-27 ~51 minecraft:air
setblock ~18 ~-27 ~51 minecraft:light_gray_concrete
fill ~19 ~-27 ~51 ~31 ~-27 ~51 minecraft:air
setblock ~32 ~-27 ~51 minecraft:light_gray_concrete
fill ~33 ~-27 ~51 ~35 ~-27 ~51 minecraft:air
setblock ~36 ~-27 ~51 minecraft:light_gray_concrete
setblock ~37 ~-27 ~51 minecraft:crafting_table
setblock ~38 ~-27 ~51 minecraft:smithing_table
setblock ~39 ~-27 ~51 minecraft:barrel
setblock ~40 ~-27 ~51 minecraft:iron_block
setblock ~41 ~-27 ~51 minecraft:crafting_table
setblock ~42 ~-27 ~51 minecraft:smithing_table
setblock ~43 ~-27 ~51 minecraft:barrel
setblock ~44 ~-27 ~51 minecraft:iron_block
setblock ~45 ~-27 ~51 minecraft:crafting_table
setblock ~46 ~-27 ~51 minecraft:smithing_table
setblock ~47 ~-27 ~51 minecraft:barrel
setblock ~48 ~-27 ~51 minecraft:iron_block
setblock ~49 ~-27 ~51 minecraft:crafting_table
setblock ~50 ~-27 ~51 minecraft:light_gray_concrete
setblock ~51 ~-27 ~51 minecraft:chest[facing=south]
setblock ~52 ~-27 ~51 minecraft:air
setblock ~53 ~-27 ~51 minecraft:chest[facing=south]
setblock ~54 ~-27 ~51 minecraft:air
setblock ~55 ~-27 ~51 minecraft:chest[facing=south]
fill ~56 ~-27 ~51 ~58 ~-27 ~51 minecraft:air
setblock ~59 ~-27 ~51 minecraft:chest[facing=south]
setblock ~60 ~-27 ~51 minecraft:air
setblock ~61 ~-27 ~51 minecraft:chest[facing=south]
setblock ~62 ~-27 ~51 minecraft:air
setblock ~63 ~-27 ~51 minecraft:chest[facing=south]
setblock ~64 ~-27 ~51 minecraft:light_gray_concrete
setblock ~4 ~-27 ~52 minecraft:light_gray_concrete
setblock ~5 ~-27 ~52 minecraft:air
setblock ~6 ~-27 ~52 minecraft:lectern
fill ~7 ~-27 ~52 ~17 ~-27 ~52 minecraft:air
setblock ~18 ~-27 ~52 minecraft:light_gray_concrete
fill ~19 ~-27 ~52 ~31 ~-27 ~52 minecraft:air
setblock ~32 ~-27 ~52 minecraft:light_gray_concrete
fill ~33 ~-27 ~52 ~35 ~-27 ~52 minecraft:air
setblock ~36 ~-27 ~52 minecraft:light_gray_concrete
setblock ~37 ~-27 ~52 minecraft:smithing_table
fill ~38 ~-27 ~52 ~48 ~-27 ~52 minecraft:air
setblock ~49 ~-27 ~52 minecraft:smithing_table
setblock ~50 ~-27 ~52 minecraft:light_gray_concrete
setblock ~51 ~-27 ~52 minecraft:air
fill ~52 ~-27 ~52 ~55 ~-27 ~52 minecraft:barrel
fill ~56 ~-27 ~52 ~57 ~-27 ~52 minecraft:air
fill ~58 ~-27 ~52 ~60 ~-27 ~52 minecraft:barrel
setblock ~61 ~-27 ~52 minecraft:air
setblock ~62 ~-27 ~52 minecraft:barrel
setblock ~63 ~-27 ~52 minecraft:air
setblock ~64 ~-27 ~52 minecraft:light_gray_concrete
setblock ~4 ~-27 ~53 minecraft:light_gray_concrete
fill ~5 ~-27 ~53 ~10 ~-27 ~53 minecraft:air
setblock ~11 ~-27 ~53 minecraft:red_carpet
fill ~12 ~-27 ~53 ~17 ~-27 ~53 minecraft:air
setblock ~18 ~-27 ~53 minecraft:light_gray_concrete
fill ~19 ~-27 ~53 ~20 ~-27 ~53 minecraft:air
fill ~21 ~-27 ~53 ~29 ~-27 ~53 minecraft:red_carpet
fill ~30 ~-27 ~53 ~31 ~-27 ~53 minecraft:air
setblock ~32 ~-27 ~53 minecraft:light_gray_concrete
fill ~33 ~-27 ~53 ~35 ~-27 ~53 minecraft:air
setblock ~36 ~-27 ~53 minecraft:light_gray_concrete
setblock ~37 ~-27 ~53 minecraft:barrel
fill ~38 ~-27 ~53 ~48 ~-27 ~53 minecraft:air
setblock ~49 ~-27 ~53 minecraft:barrel
setblock ~50 ~-27 ~53 minecraft:light_gray_concrete
setblock ~51 ~-27 ~53 minecraft:chest[facing=east]
fill ~52 ~-27 ~53 ~62 ~-27 ~53 minecraft:air
setblock ~63 ~-27 ~53 minecraft:chest[facing=west]
setblock ~64 ~-27 ~53 minecraft:light_gray_concrete
setblock ~4 ~-27 ~54 minecraft:light_gray_concrete
setblock ~5 ~-27 ~54 minecraft:air
fill ~6 ~-27 ~54 ~10 ~-27 ~54 minecraft:chiseled_bookshelf[facing=south]
setblock ~11 ~-27 ~54 minecraft:red_carpet
fill ~12 ~-27 ~54 ~16 ~-27 ~54 minecraft:chiseled_bookshelf[facing=south]
setblock ~17 ~-27 ~54 minecraft:air
setblock ~18 ~-27 ~54 minecraft:light_gray_concrete
fill ~19 ~-27 ~54 ~20 ~-27 ~54 minecraft:air
fill ~21 ~-27 ~54 ~29 ~-27 ~54 minecraft:red_carpet
fill ~30 ~-27 ~54 ~31 ~-27 ~54 minecraft:air
setblock ~32 ~-27 ~54 minecraft:light_gray_concrete
fill ~33 ~-27 ~54 ~35 ~-27 ~54 minecraft:air
setblock ~36 ~-27 ~54 minecraft:light_gray_concrete
setblock ~37 ~-27 ~54 minecraft:iron_block
fill ~38 ~-27 ~54 ~48 ~-27 ~54 minecraft:air
setblock ~49 ~-27 ~54 minecraft:iron_block
setblock ~50 ~-27 ~54 minecraft:light_gray_concrete
fill ~51 ~-27 ~54 ~63 ~-27 ~54 minecraft:air
setblock ~64 ~-27 ~54 minecraft:light_gray_concrete
setblock ~4 ~-27 ~55 minecraft:light_gray_concrete
setblock ~5 ~-27 ~55 minecraft:air
setblock ~6 ~-27 ~55 minecraft:lectern
fill ~7 ~-27 ~55 ~10 ~-27 ~55 minecraft:air
setblock ~11 ~-27 ~55 minecraft:red_carpet
fill ~12 ~-27 ~55 ~17 ~-27 ~55 minecraft:air
setblock ~18 ~-27 ~55 minecraft:light_gray_concrete
fill ~19 ~-27 ~55 ~20 ~-27 ~55 minecraft:air
fill ~21 ~-27 ~55 ~29 ~-27 ~55 minecraft:red_carpet
fill ~30 ~-27 ~55 ~31 ~-27 ~55 minecraft:air
setblock ~32 ~-27 ~55 minecraft:light_gray_concrete
fill ~33 ~-27 ~55 ~35 ~-27 ~55 minecraft:air
setblock ~36 ~-27 ~55 minecraft:light_gray_concrete
setblock ~37 ~-27 ~55 minecraft:crafting_table
fill ~38 ~-27 ~55 ~39 ~-27 ~55 minecraft:air
fill ~40 ~-27 ~55 ~46 ~-27 ~55 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-27 ~55 ~48 ~-27 ~55 minecraft:air
setblock ~49 ~-27 ~55 minecraft:crafting_table
setblock ~50 ~-27 ~55 minecraft:light_gray_concrete
setblock ~51 ~-27 ~55 minecraft:chest[facing=east]
fill ~52 ~-27 ~55 ~55 ~-27 ~55 minecraft:barrel
setblock ~56 ~-27 ~55 minecraft:air
fill ~57 ~-27 ~55 ~60 ~-27 ~55 minecraft:barrel
setblock ~61 ~-27 ~55 minecraft:air
setblock ~62 ~-27 ~55 minecraft:barrel
setblock ~63 ~-27 ~55 minecraft:chest[facing=west]
setblock ~64 ~-27 ~55 minecraft:light_gray_concrete
setblock ~4 ~-27 ~56 minecraft:light_gray_concrete
fill ~5 ~-27 ~56 ~10 ~-27 ~56 minecraft:air
setblock ~11 ~-27 ~56 minecraft:red_carpet
fill ~12 ~-27 ~56 ~17 ~-27 ~56 minecraft:air
setblock ~18 ~-27 ~56 minecraft:light_gray_concrete
fill ~19 ~-27 ~56 ~20 ~-27 ~56 minecraft:air
fill ~21 ~-27 ~56 ~29 ~-27 ~56 minecraft:red_carpet
fill ~30 ~-27 ~56 ~31 ~-27 ~56 minecraft:air
setblock ~32 ~-27 ~56 minecraft:light_gray_concrete
fill ~33 ~-27 ~56 ~35 ~-27 ~56 minecraft:air
setblock ~36 ~-27 ~56 minecraft:light_gray_concrete
fill ~37 ~-27 ~56 ~49 ~-27 ~56 minecraft:air
setblock ~50 ~-27 ~56 minecraft:light_gray_concrete
fill ~51 ~-27 ~56 ~63 ~-27 ~56 minecraft:air
setblock ~64 ~-27 ~56 minecraft:light_gray_concrete
setblock ~4 ~-27 ~57 minecraft:light_gray_concrete
setblock ~5 ~-27 ~57 minecraft:air
fill ~6 ~-27 ~57 ~10 ~-27 ~57 minecraft:chiseled_bookshelf[facing=north]
setblock ~11 ~-27 ~57 minecraft:red_carpet
fill ~12 ~-27 ~57 ~15 ~-27 ~57 minecraft:chiseled_bookshelf[facing=north]
fill ~16 ~-27 ~57 ~20 ~-27 ~57 minecraft:air
fill ~21 ~-27 ~57 ~29 ~-27 ~57 minecraft:red_carpet
fill ~30 ~-27 ~57 ~62 ~-27 ~57 minecraft:air
setblock ~63 ~-27 ~57 minecraft:chest[facing=west]
setblock ~64 ~-27 ~57 minecraft:light_gray_concrete
setblock ~4 ~-27 ~58 minecraft:light_gray_concrete
setblock ~5 ~-27 ~58 minecraft:air
setblock ~6 ~-27 ~58 minecraft:lectern
fill ~7 ~-27 ~58 ~10 ~-27 ~58 minecraft:air
setblock ~11 ~-27 ~58 minecraft:red_carpet
fill ~12 ~-27 ~58 ~17 ~-27 ~58 minecraft:air
setblock ~18 ~-27 ~58 minecraft:light_gray_concrete
fill ~19 ~-27 ~58 ~20 ~-27 ~58 minecraft:air
fill ~21 ~-27 ~58 ~29 ~-27 ~58 minecraft:red_carpet
fill ~30 ~-27 ~58 ~31 ~-27 ~58 minecraft:air
setblock ~32 ~-27 ~58 minecraft:light_gray_concrete
fill ~33 ~-27 ~58 ~35 ~-27 ~58 minecraft:air
setblock ~36 ~-27 ~58 minecraft:light_gray_concrete
fill ~37 ~-27 ~58 ~49 ~-27 ~58 minecraft:air
setblock ~50 ~-27 ~58 minecraft:light_gray_concrete
setblock ~51 ~-27 ~58 minecraft:air
fill ~52 ~-27 ~58 ~55 ~-27 ~58 minecraft:barrel
setblock ~56 ~-27 ~58 minecraft:air
fill ~57 ~-27 ~58 ~60 ~-27 ~58 minecraft:barrel
setblock ~61 ~-27 ~58 minecraft:air
setblock ~62 ~-27 ~58 minecraft:barrel
setblock ~63 ~-27 ~58 minecraft:air
setblock ~64 ~-27 ~58 minecraft:light_gray_concrete
setblock ~4 ~-27 ~59 minecraft:light_gray_concrete
fill ~5 ~-27 ~59 ~10 ~-27 ~59 minecraft:air
setblock ~11 ~-27 ~59 minecraft:red_carpet
fill ~12 ~-27 ~59 ~17 ~-27 ~59 minecraft:air
setblock ~18 ~-27 ~59 minecraft:light_gray_concrete
fill ~19 ~-27 ~59 ~20 ~-27 ~59 minecraft:air
fill ~21 ~-27 ~59 ~24 ~-27 ~59 minecraft:red_carpet
setblock ~25 ~-27 ~59 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~26 ~-27 ~59 ~29 ~-27 ~59 minecraft:red_carpet
fill ~30 ~-27 ~59 ~31 ~-27 ~59 minecraft:air
setblock ~32 ~-27 ~59 minecraft:light_gray_concrete
fill ~33 ~-27 ~59 ~35 ~-27 ~59 minecraft:air
setblock ~36 ~-27 ~59 minecraft:light_gray_concrete
setblock ~37 ~-27 ~59 minecraft:crafting_table
fill ~38 ~-27 ~59 ~39 ~-27 ~59 minecraft:air
fill ~40 ~-27 ~59 ~46 ~-27 ~59 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-27 ~59 ~48 ~-27 ~59 minecraft:air
setblock ~49 ~-27 ~59 minecraft:crafting_table
setblock ~50 ~-27 ~59 minecraft:light_gray_concrete
setblock ~51 ~-27 ~59 minecraft:chest[facing=east]
fill ~52 ~-27 ~59 ~62 ~-27 ~59 minecraft:air
setblock ~63 ~-27 ~59 minecraft:chest[facing=west]
setblock ~64 ~-27 ~59 minecraft:light_gray_concrete
setblock ~4 ~-27 ~60 minecraft:light_gray_concrete
setblock ~5 ~-27 ~60 minecraft:air
fill ~6 ~-27 ~60 ~10 ~-27 ~60 minecraft:chiseled_bookshelf[facing=south]
setblock ~11 ~-27 ~60 minecraft:red_carpet
fill ~12 ~-27 ~60 ~16 ~-27 ~60 minecraft:chiseled_bookshelf[facing=south]
setblock ~17 ~-27 ~60 minecraft:air
setblock ~18 ~-27 ~60 minecraft:light_gray_concrete
fill ~19 ~-27 ~60 ~20 ~-27 ~60 minecraft:air
fill ~21 ~-27 ~60 ~23 ~-27 ~60 minecraft:red_carpet
fill ~24 ~-27 ~60 ~26 ~-27 ~60 minecraft:smooth_stone_slab[type=top]
setblock ~27 ~-27 ~60 minecraft:lectern
fill ~28 ~-27 ~60 ~29 ~-27 ~60 minecraft:red_carpet
fill ~30 ~-27 ~60 ~31 ~-27 ~60 minecraft:air
setblock ~32 ~-27 ~60 minecraft:light_gray_concrete
fill ~33 ~-27 ~60 ~35 ~-27 ~60 minecraft:air
setblock ~36 ~-27 ~60 minecraft:light_gray_concrete
setblock ~37 ~-27 ~60 minecraft:smithing_table
fill ~38 ~-27 ~60 ~48 ~-27 ~60 minecraft:air
setblock ~49 ~-27 ~60 minecraft:smithing_table
setblock ~50 ~-27 ~60 minecraft:light_gray_concrete
fill ~51 ~-27 ~60 ~63 ~-27 ~60 minecraft:air
setblock ~64 ~-27 ~60 minecraft:light_gray_concrete
setblock ~4 ~-27 ~61 minecraft:light_gray_concrete
setblock ~5 ~-27 ~61 minecraft:air
setblock ~6 ~-27 ~61 minecraft:lectern
fill ~7 ~-27 ~61 ~10 ~-27 ~61 minecraft:air
setblock ~11 ~-27 ~61 minecraft:red_carpet
fill ~12 ~-27 ~61 ~17 ~-27 ~61 minecraft:air
setblock ~18 ~-27 ~61 minecraft:light_gray_concrete
fill ~19 ~-27 ~61 ~20 ~-27 ~61 minecraft:air
fill ~21 ~-27 ~61 ~29 ~-27 ~61 minecraft:red_carpet
fill ~30 ~-27 ~61 ~31 ~-27 ~61 minecraft:air
setblock ~32 ~-27 ~61 minecraft:light_gray_concrete
fill ~33 ~-27 ~61 ~35 ~-27 ~61 minecraft:air
setblock ~36 ~-27 ~61 minecraft:light_gray_concrete
setblock ~37 ~-27 ~61 minecraft:barrel
fill ~38 ~-27 ~61 ~48 ~-27 ~61 minecraft:air
setblock ~49 ~-27 ~61 minecraft:barrel
setblock ~50 ~-27 ~61 minecraft:light_gray_concrete
setblock ~51 ~-27 ~61 minecraft:chest[facing=east]
fill ~52 ~-27 ~61 ~55 ~-27 ~61 minecraft:barrel
setblock ~56 ~-27 ~61 minecraft:air
fill ~57 ~-27 ~61 ~60 ~-27 ~61 minecraft:barrel
setblock ~61 ~-27 ~61 minecraft:air
setblock ~62 ~-27 ~61 minecraft:barrel
setblock ~63 ~-27 ~61 minecraft:chest[facing=west]
setblock ~64 ~-27 ~61 minecraft:light_gray_concrete
setblock ~4 ~-27 ~62 minecraft:light_gray_concrete
fill ~5 ~-27 ~62 ~10 ~-27 ~62 minecraft:air
setblock ~11 ~-27 ~62 minecraft:red_carpet
fill ~12 ~-27 ~62 ~17 ~-27 ~62 minecraft:air
setblock ~18 ~-27 ~62 minecraft:light_gray_concrete
fill ~19 ~-27 ~62 ~31 ~-27 ~62 minecraft:air
setblock ~32 ~-27 ~62 minecraft:light_gray_concrete
fill ~33 ~-27 ~62 ~35 ~-27 ~62 minecraft:air
setblock ~36 ~-27 ~62 minecraft:light_gray_concrete
setblock ~37 ~-27 ~62 minecraft:iron_block
fill ~38 ~-27 ~62 ~48 ~-27 ~62 minecraft:air
setblock ~49 ~-27 ~62 minecraft:iron_block
setblock ~50 ~-27 ~62 minecraft:light_gray_concrete
fill ~51 ~-27 ~62 ~63 ~-27 ~62 minecraft:air
setblock ~64 ~-27 ~62 minecraft:light_gray_concrete
setblock ~4 ~-27 ~63 minecraft:light_gray_concrete
fill ~5 ~-27 ~63 ~16 ~-27 ~63 minecraft:chiseled_bookshelf[facing=north]
setblock ~17 ~-27 ~63 minecraft:air
setblock ~18 ~-27 ~63 minecraft:light_gray_concrete
fill ~19 ~-27 ~63 ~30 ~-27 ~63 minecraft:chiseled_bookshelf[facing=north]
setblock ~31 ~-27 ~63 minecraft:air
setblock ~32 ~-27 ~63 minecraft:light_gray_concrete
fill ~33 ~-27 ~63 ~35 ~-27 ~63 minecraft:air
setblock ~36 ~-27 ~63 minecraft:light_gray_concrete
setblock ~37 ~-27 ~63 minecraft:crafting_table
setblock ~38 ~-27 ~63 minecraft:smithing_table
setblock ~39 ~-27 ~63 minecraft:barrel
setblock ~40 ~-27 ~63 minecraft:iron_block
setblock ~41 ~-27 ~63 minecraft:crafting_table
setblock ~42 ~-27 ~63 minecraft:smithing_table
setblock ~43 ~-27 ~63 minecraft:barrel
setblock ~44 ~-27 ~63 minecraft:iron_block
setblock ~45 ~-27 ~63 minecraft:crafting_table
setblock ~46 ~-27 ~63 minecraft:smithing_table
setblock ~47 ~-27 ~63 minecraft:barrel
setblock ~48 ~-27 ~63 minecraft:iron_block
setblock ~49 ~-27 ~63 minecraft:crafting_table
setblock ~50 ~-27 ~63 minecraft:light_gray_concrete
setblock ~51 ~-27 ~63 minecraft:chest[facing=north]
setblock ~52 ~-27 ~63 minecraft:air
setblock ~53 ~-27 ~63 minecraft:chest[facing=north]
setblock ~54 ~-27 ~63 minecraft:air
setblock ~55 ~-27 ~63 minecraft:chest[facing=north]
setblock ~56 ~-27 ~63 minecraft:air
setblock ~57 ~-27 ~63 minecraft:chest[facing=north]
setblock ~58 ~-27 ~63 minecraft:air
setblock ~59 ~-27 ~63 minecraft:chest[facing=north]
setblock ~60 ~-27 ~63 minecraft:air
setblock ~61 ~-27 ~63 minecraft:chest[facing=north]
setblock ~62 ~-27 ~63 minecraft:air
setblock ~63 ~-27 ~63 minecraft:chest[facing=west]
setblock ~64 ~-27 ~63 minecraft:light_gray_concrete
fill ~4 ~-27 ~64 ~33 ~-27 ~64 minecraft:light_gray_concrete
setblock ~34 ~-27 ~64 minecraft:air
fill ~35 ~-27 ~64 ~64 ~-27 ~64 minecraft:light_gray_concrete
setblock ~33 ~-27 ~65 minecraft:light_gray_concrete
setblock ~34 ~-27 ~65 minecraft:air
setblock ~35 ~-27 ~65 minecraft:light_gray_concrete
fill ~32 ~-27 ~66 ~33 ~-27 ~66 minecraft:polished_andesite
setblock ~34 ~-27 ~66 minecraft:air
fill ~35 ~-27 ~66 ~36 ~-27 ~66 minecraft:polished_andesite
setblock ~32 ~-27 ~67 minecraft:polished_andesite
fill ~33 ~-27 ~67 ~34 ~-27 ~67 minecraft:air
setblock ~35 ~-27 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-27 ~67 minecraft:polished_andesite
setblock ~32 ~-27 ~68 minecraft:polished_andesite
setblock ~33 ~-27 ~68 minecraft:air
setblock ~34 ~-27 ~68 minecraft:quartz_pillar
setblock ~35 ~-27 ~68 minecraft:air
setblock ~36 ~-27 ~68 minecraft:polished_andesite
setblock ~32 ~-27 ~69 minecraft:polished_andesite
fill ~33 ~-27 ~69 ~35 ~-27 ~69 minecraft:air
setblock ~36 ~-27 ~69 minecraft:polished_andesite
fill ~32 ~-27 ~70 ~36 ~-27 ~70 minecraft:polished_andesite
fill ~4 ~-26 ~4 ~64 ~-26 ~4 minecraft:light_gray_concrete
setblock ~4 ~-26 ~5 minecraft:light_gray_concrete
fill ~5 ~-26 ~5 ~17 ~-26 ~5 minecraft:air
setblock ~18 ~-26 ~5 minecraft:light_gray_concrete
fill ~19 ~-26 ~5 ~31 ~-26 ~5 minecraft:chiseled_bookshelf[facing=south]
setblock ~32 ~-26 ~5 minecraft:red_concrete
fill ~33 ~-26 ~5 ~35 ~-26 ~5 minecraft:air
setblock ~36 ~-26 ~5 minecraft:glass_pane[north=true,east=true,south=true]
setblock ~37 ~-26 ~5 minecraft:black_concrete
fill ~38 ~-26 ~5 ~39 ~-26 ~5 minecraft:air
setblock ~40 ~-26 ~5 minecraft:black_concrete
fill ~41 ~-26 ~5 ~42 ~-26 ~5 minecraft:air
setblock ~43 ~-26 ~5 minecraft:black_concrete
fill ~44 ~-26 ~5 ~45 ~-26 ~5 minecraft:air
setblock ~46 ~-26 ~5 minecraft:black_concrete
fill ~47 ~-26 ~5 ~48 ~-26 ~5 minecraft:air
setblock ~49 ~-26 ~5 minecraft:black_concrete
setblock ~50 ~-26 ~5 minecraft:light_gray_concrete
fill ~51 ~-26 ~5 ~63 ~-26 ~5 minecraft:air
setblock ~64 ~-26 ~5 minecraft:light_gray_concrete
setblock ~4 ~-26 ~6 minecraft:light_gray_concrete
fill ~5 ~-26 ~6 ~17 ~-26 ~6 minecraft:air
setblock ~18 ~-26 ~6 minecraft:light_gray_concrete
fill ~19 ~-26 ~6 ~31 ~-26 ~6 minecraft:air
setblock ~32 ~-26 ~6 minecraft:red_concrete
fill ~33 ~-26 ~6 ~35 ~-26 ~6 minecraft:air
setblock ~36 ~-26 ~6 minecraft:red_concrete
fill ~37 ~-26 ~6 ~49 ~-26 ~6 minecraft:air
setblock ~50 ~-26 ~6 minecraft:light_gray_concrete
fill ~51 ~-26 ~6 ~63 ~-26 ~6 minecraft:air
setblock ~64 ~-26 ~6 minecraft:light_gray_concrete
setblock ~4 ~-26 ~7 minecraft:light_gray_concrete
fill ~5 ~-26 ~7 ~17 ~-26 ~7 minecraft:air
setblock ~18 ~-26 ~7 minecraft:light_gray_concrete
fill ~19 ~-26 ~7 ~31 ~-26 ~7 minecraft:air
setblock ~32 ~-26 ~7 minecraft:red_concrete
fill ~33 ~-26 ~7 ~35 ~-26 ~7 minecraft:air
setblock ~36 ~-26 ~7 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~7 ~39 ~-26 ~7 minecraft:air
setblock ~40 ~-26 ~7 minecraft:glass_pane
fill ~41 ~-26 ~7 ~43 ~-26 ~7 minecraft:air
setblock ~44 ~-26 ~7 minecraft:glass_pane
fill ~45 ~-26 ~7 ~49 ~-26 ~7 minecraft:air
setblock ~50 ~-26 ~7 minecraft:light_gray_concrete
fill ~51 ~-26 ~7 ~63 ~-26 ~7 minecraft:air
setblock ~64 ~-26 ~7 minecraft:light_gray_concrete
setblock ~4 ~-26 ~8 minecraft:light_gray_concrete
fill ~5 ~-26 ~8 ~17 ~-26 ~8 minecraft:air
setblock ~18 ~-26 ~8 minecraft:light_gray_concrete
fill ~19 ~-26 ~8 ~24 ~-26 ~8 minecraft:air
setblock ~25 ~-26 ~8 minecraft:black_concrete
fill ~26 ~-26 ~8 ~31 ~-26 ~8 minecraft:air
setblock ~32 ~-26 ~8 minecraft:red_concrete
fill ~33 ~-26 ~8 ~35 ~-26 ~8 minecraft:air
setblock ~36 ~-26 ~8 minecraft:glass_pane[north=true,east=true,south=true]
setblock ~37 ~-26 ~8 minecraft:black_concrete
setblock ~38 ~-26 ~8 minecraft:air
setblock ~39 ~-26 ~8 minecraft:glass_pane
setblock ~40 ~-26 ~8 minecraft:air
setblock ~41 ~-26 ~8 minecraft:glass_pane
setblock ~42 ~-26 ~8 minecraft:air
setblock ~43 ~-26 ~8 minecraft:glass_pane
setblock ~44 ~-26 ~8 minecraft:air
setblock ~45 ~-26 ~8 minecraft:glass_pane
fill ~46 ~-26 ~8 ~48 ~-26 ~8 minecraft:air
setblock ~49 ~-26 ~8 minecraft:black_concrete
setblock ~50 ~-26 ~8 minecraft:light_gray_concrete
fill ~51 ~-26 ~8 ~63 ~-26 ~8 minecraft:air
setblock ~64 ~-26 ~8 minecraft:light_gray_concrete
setblock ~4 ~-26 ~9 minecraft:light_gray_concrete
fill ~5 ~-26 ~9 ~17 ~-26 ~9 minecraft:air
setblock ~18 ~-26 ~9 minecraft:light_gray_concrete
fill ~19 ~-26 ~9 ~31 ~-26 ~9 minecraft:air
setblock ~32 ~-26 ~9 minecraft:red_concrete
fill ~33 ~-26 ~9 ~35 ~-26 ~9 minecraft:air
setblock ~36 ~-26 ~9 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~9 ~39 ~-26 ~9 minecraft:air
setblock ~40 ~-26 ~9 minecraft:glass_pane
fill ~41 ~-26 ~9 ~43 ~-26 ~9 minecraft:air
setblock ~44 ~-26 ~9 minecraft:glass_pane
fill ~45 ~-26 ~9 ~49 ~-26 ~9 minecraft:air
setblock ~50 ~-26 ~9 minecraft:light_gray_concrete
fill ~51 ~-26 ~9 ~63 ~-26 ~9 minecraft:air
setblock ~64 ~-26 ~9 minecraft:light_gray_concrete
setblock ~4 ~-26 ~10 minecraft:light_gray_concrete
fill ~5 ~-26 ~10 ~17 ~-26 ~10 minecraft:air
setblock ~18 ~-26 ~10 minecraft:light_gray_concrete
fill ~19 ~-26 ~10 ~31 ~-26 ~10 minecraft:air
setblock ~32 ~-26 ~10 minecraft:red_concrete
fill ~33 ~-26 ~10 ~35 ~-26 ~10 minecraft:air
setblock ~36 ~-26 ~10 minecraft:red_concrete
fill ~37 ~-26 ~10 ~49 ~-26 ~10 minecraft:air
setblock ~50 ~-26 ~10 minecraft:light_gray_concrete
fill ~51 ~-26 ~10 ~63 ~-26 ~10 minecraft:air
setblock ~64 ~-26 ~10 minecraft:light_gray_concrete
setblock ~4 ~-26 ~11 minecraft:light_gray_concrete
fill ~5 ~-26 ~11 ~39 ~-26 ~11 minecraft:air
setblock ~40 ~-26 ~11 minecraft:glass_pane
fill ~41 ~-26 ~11 ~43 ~-26 ~11 minecraft:air
setblock ~44 ~-26 ~11 minecraft:glass_pane
fill ~45 ~-26 ~11 ~63 ~-26 ~11 minecraft:air
setblock ~64 ~-26 ~11 minecraft:light_gray_concrete
setblock ~4 ~-26 ~12 minecraft:light_gray_concrete
fill ~5 ~-26 ~12 ~17 ~-26 ~12 minecraft:air
setblock ~18 ~-26 ~12 minecraft:light_gray_concrete
fill ~19 ~-26 ~12 ~31 ~-26 ~12 minecraft:air
setblock ~32 ~-26 ~12 minecraft:red_concrete
fill ~33 ~-26 ~12 ~35 ~-26 ~12 minecraft:air
setblock ~36 ~-26 ~12 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~12 ~38 ~-26 ~12 minecraft:air
setblock ~39 ~-26 ~12 minecraft:glass_pane
setblock ~40 ~-26 ~12 minecraft:air
setblock ~41 ~-26 ~12 minecraft:glass_pane
setblock ~42 ~-26 ~12 minecraft:air
setblock ~43 ~-26 ~12 minecraft:glass_pane
setblock ~44 ~-26 ~12 minecraft:air
setblock ~45 ~-26 ~12 minecraft:glass_pane
fill ~46 ~-26 ~12 ~49 ~-26 ~12 minecraft:air
setblock ~50 ~-26 ~12 minecraft:light_gray_concrete
fill ~51 ~-26 ~12 ~63 ~-26 ~12 minecraft:air
setblock ~64 ~-26 ~12 minecraft:light_gray_concrete
setblock ~4 ~-26 ~13 minecraft:light_gray_concrete
fill ~5 ~-26 ~13 ~17 ~-26 ~13 minecraft:air
setblock ~18 ~-26 ~13 minecraft:light_gray_concrete
fill ~19 ~-26 ~13 ~31 ~-26 ~13 minecraft:air
setblock ~32 ~-26 ~13 minecraft:red_concrete
fill ~33 ~-26 ~13 ~35 ~-26 ~13 minecraft:air
setblock ~36 ~-26 ~13 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~13 ~39 ~-26 ~13 minecraft:air
setblock ~40 ~-26 ~13 minecraft:glass_pane
fill ~41 ~-26 ~13 ~43 ~-26 ~13 minecraft:air
setblock ~44 ~-26 ~13 minecraft:glass_pane
fill ~45 ~-26 ~13 ~49 ~-26 ~13 minecraft:air
setblock ~50 ~-26 ~13 minecraft:light_gray_concrete
fill ~51 ~-26 ~13 ~63 ~-26 ~13 minecraft:air
setblock ~64 ~-26 ~13 minecraft:light_gray_concrete
setblock ~4 ~-26 ~14 minecraft:light_gray_concrete
fill ~5 ~-26 ~14 ~17 ~-26 ~14 minecraft:air
setblock ~18 ~-26 ~14 minecraft:light_gray_concrete
fill ~19 ~-26 ~14 ~31 ~-26 ~14 minecraft:air
setblock ~32 ~-26 ~14 minecraft:red_concrete
fill ~33 ~-26 ~14 ~35 ~-26 ~14 minecraft:air
setblock ~36 ~-26 ~14 minecraft:red_concrete
setblock ~37 ~-26 ~14 minecraft:black_concrete
fill ~38 ~-26 ~14 ~48 ~-26 ~14 minecraft:air
setblock ~49 ~-26 ~14 minecraft:black_concrete
setblock ~50 ~-26 ~14 minecraft:light_gray_concrete
fill ~51 ~-26 ~14 ~63 ~-26 ~14 minecraft:air
setblock ~64 ~-26 ~14 minecraft:light_gray_concrete
setblock ~4 ~-26 ~15 minecraft:light_gray_concrete
fill ~5 ~-26 ~15 ~17 ~-26 ~15 minecraft:air
setblock ~18 ~-26 ~15 minecraft:light_gray_concrete
fill ~19 ~-26 ~15 ~31 ~-26 ~15 minecraft:air
setblock ~32 ~-26 ~15 minecraft:red_concrete
fill ~33 ~-26 ~15 ~35 ~-26 ~15 minecraft:air
setblock ~36 ~-26 ~15 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~15 ~49 ~-26 ~15 minecraft:air
setblock ~50 ~-26 ~15 minecraft:light_gray_concrete
fill ~51 ~-26 ~15 ~63 ~-26 ~15 minecraft:air
setblock ~64 ~-26 ~15 minecraft:light_gray_concrete
setblock ~4 ~-26 ~16 minecraft:light_gray_concrete
fill ~5 ~-26 ~16 ~17 ~-26 ~16 minecraft:air
setblock ~18 ~-26 ~16 minecraft:light_gray_concrete
fill ~19 ~-26 ~16 ~31 ~-26 ~16 minecraft:air
setblock ~32 ~-26 ~16 minecraft:red_concrete
fill ~33 ~-26 ~16 ~35 ~-26 ~16 minecraft:air
setblock ~36 ~-26 ~16 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~16 ~49 ~-26 ~16 minecraft:air
setblock ~50 ~-26 ~16 minecraft:light_gray_concrete
fill ~51 ~-26 ~16 ~63 ~-26 ~16 minecraft:air
setblock ~64 ~-26 ~16 minecraft:light_gray_concrete
setblock ~4 ~-26 ~17 minecraft:light_gray_concrete
fill ~5 ~-26 ~17 ~17 ~-26 ~17 minecraft:air
setblock ~18 ~-26 ~17 minecraft:light_gray_concrete
fill ~19 ~-26 ~17 ~31 ~-26 ~17 minecraft:air
setblock ~32 ~-26 ~17 minecraft:red_concrete
fill ~33 ~-26 ~17 ~35 ~-26 ~17 minecraft:air
setblock ~36 ~-26 ~17 minecraft:glass_pane[north=true,east=true,south=true]
setblock ~37 ~-26 ~17 minecraft:black_concrete
fill ~38 ~-26 ~17 ~39 ~-26 ~17 minecraft:air
setblock ~40 ~-26 ~17 minecraft:black_concrete
fill ~41 ~-26 ~17 ~42 ~-26 ~17 minecraft:air
setblock ~43 ~-26 ~17 minecraft:black_concrete
fill ~44 ~-26 ~17 ~45 ~-26 ~17 minecraft:air
setblock ~46 ~-26 ~17 minecraft:black_concrete
fill ~47 ~-26 ~17 ~48 ~-26 ~17 minecraft:air
setblock ~49 ~-26 ~17 minecraft:black_concrete
setblock ~50 ~-26 ~17 minecraft:light_gray_concrete
fill ~51 ~-26 ~17 ~63 ~-26 ~17 minecraft:air
setblock ~64 ~-26 ~17 minecraft:light_gray_concrete
fill ~4 ~-26 ~18 ~10 ~-26 ~18 minecraft:light_gray_concrete
setblock ~11 ~-26 ~18 minecraft:air
fill ~12 ~-26 ~18 ~31 ~-26 ~18 minecraft:light_gray_concrete
setblock ~32 ~-26 ~18 minecraft:red_concrete
fill ~33 ~-26 ~18 ~35 ~-26 ~18 minecraft:air
setblock ~36 ~-26 ~18 minecraft:red_concrete
fill ~37 ~-26 ~18 ~56 ~-26 ~18 minecraft:light_gray_concrete
setblock ~57 ~-26 ~18 minecraft:air
fill ~58 ~-26 ~18 ~64 ~-26 ~18 minecraft:light_gray_concrete
setblock ~4 ~-26 ~19 minecraft:light_gray_concrete
fill ~5 ~-26 ~19 ~7 ~-26 ~19 minecraft:packed_ice
setblock ~8 ~-26 ~19 minecraft:air
setblock ~9 ~-26 ~19 minecraft:packed_ice
fill ~10 ~-26 ~19 ~12 ~-26 ~19 minecraft:air
fill ~13 ~-26 ~19 ~15 ~-26 ~19 minecraft:packed_ice
setblock ~16 ~-26 ~19 minecraft:air
setblock ~17 ~-26 ~19 minecraft:packed_ice
setblock ~18 ~-26 ~19 minecraft:light_gray_concrete
fill ~19 ~-26 ~19 ~20 ~-26 ~19 minecraft:air
setblock ~21 ~-26 ~19 minecraft:black_concrete
fill ~22 ~-26 ~19 ~25 ~-26 ~19 minecraft:air
setblock ~26 ~-26 ~19 minecraft:black_concrete
fill ~27 ~-26 ~19 ~31 ~-26 ~19 minecraft:air
setblock ~32 ~-26 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-26 ~19 ~35 ~-26 ~19 minecraft:air
setblock ~36 ~-26 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~19 ~49 ~-26 ~19 minecraft:air
setblock ~50 ~-26 ~19 minecraft:light_gray_concrete
fill ~51 ~-26 ~19 ~63 ~-26 ~19 minecraft:air
setblock ~64 ~-26 ~19 minecraft:light_gray_concrete
setblock ~4 ~-26 ~20 minecraft:light_gray_concrete
setblock ~5 ~-26 ~20 minecraft:packed_ice
fill ~6 ~-26 ~20 ~16 ~-26 ~20 minecraft:air
setblock ~17 ~-26 ~20 minecraft:packed_ice
setblock ~18 ~-26 ~20 minecraft:light_gray_concrete
setblock ~19 ~-26 ~20 minecraft:air
fill ~20 ~-26 ~20 ~22 ~-26 ~20 minecraft:glass
setblock ~23 ~-26 ~20 minecraft:air
fill ~24 ~-26 ~20 ~26 ~-26 ~20 minecraft:glass
fill ~27 ~-26 ~20 ~49 ~-26 ~20 minecraft:air
setblock ~50 ~-26 ~20 minecraft:light_gray_concrete
fill ~51 ~-26 ~20 ~63 ~-26 ~20 minecraft:air
setblock ~64 ~-26 ~20 minecraft:light_gray_concrete
setblock ~4 ~-26 ~21 minecraft:light_gray_concrete
setblock ~5 ~-26 ~21 minecraft:packed_ice
fill ~6 ~-26 ~21 ~7 ~-26 ~21 minecraft:air
setblock ~8 ~-26 ~21 minecraft:barrel
fill ~9 ~-26 ~21 ~10 ~-26 ~21 minecraft:air
setblock ~11 ~-26 ~21 minecraft:barrel
fill ~12 ~-26 ~21 ~13 ~-26 ~21 minecraft:air
setblock ~14 ~-26 ~21 minecraft:barrel
fill ~15 ~-26 ~21 ~16 ~-26 ~21 minecraft:air
setblock ~17 ~-26 ~21 minecraft:packed_ice
setblock ~18 ~-26 ~21 minecraft:light_gray_concrete
setblock ~19 ~-26 ~21 minecraft:black_concrete
setblock ~20 ~-26 ~21 minecraft:glass
setblock ~21 ~-26 ~21 minecraft:air
setblock ~22 ~-26 ~21 minecraft:glass
setblock ~23 ~-26 ~21 minecraft:air
setblock ~24 ~-26 ~21 minecraft:glass
setblock ~25 ~-26 ~21 minecraft:air
setblock ~26 ~-26 ~21 minecraft:glass
fill ~27 ~-26 ~21 ~28 ~-26 ~21 minecraft:air
setblock ~29 ~-26 ~21 minecraft:black_concrete
fill ~30 ~-26 ~21 ~31 ~-26 ~21 minecraft:air
setblock ~32 ~-26 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-26 ~21 ~35 ~-26 ~21 minecraft:air
setblock ~36 ~-26 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~21 ~49 ~-26 ~21 minecraft:air
setblock ~50 ~-26 ~21 minecraft:light_gray_concrete
fill ~51 ~-26 ~21 ~63 ~-26 ~21 minecraft:air
setblock ~64 ~-26 ~21 minecraft:light_gray_concrete
setblock ~4 ~-26 ~22 minecraft:light_gray_concrete
fill ~5 ~-26 ~22 ~7 ~-26 ~22 minecraft:air
setblock ~8 ~-26 ~22 minecraft:barrel
fill ~9 ~-26 ~22 ~10 ~-26 ~22 minecraft:air
setblock ~11 ~-26 ~22 minecraft:barrel
fill ~12 ~-26 ~22 ~13 ~-26 ~22 minecraft:air
setblock ~14 ~-26 ~22 minecraft:barrel
fill ~15 ~-26 ~22 ~17 ~-26 ~22 minecraft:air
setblock ~18 ~-26 ~22 minecraft:light_gray_concrete
setblock ~19 ~-26 ~22 minecraft:air
fill ~20 ~-26 ~22 ~22 ~-26 ~22 minecraft:glass
setblock ~23 ~-26 ~22 minecraft:air
fill ~24 ~-26 ~22 ~26 ~-26 ~22 minecraft:glass
fill ~27 ~-26 ~22 ~28 ~-26 ~22 minecraft:air
setblock ~29 ~-26 ~22 minecraft:glass_pane[north=true,east=true,south=true]
setblock ~30 ~-26 ~22 minecraft:quartz_pillar
setblock ~31 ~-26 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-26 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-26 ~22 ~35 ~-26 ~22 minecraft:air
setblock ~36 ~-26 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-26 ~22 ~38 ~-26 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-26 ~22 minecraft:quartz_pillar
fill ~40 ~-26 ~22 ~49 ~-26 ~22 minecraft:air
setblock ~50 ~-26 ~22 minecraft:light_gray_concrete
fill ~51 ~-26 ~22 ~63 ~-26 ~22 minecraft:air
setblock ~64 ~-26 ~22 minecraft:light_gray_concrete
setblock ~4 ~-26 ~23 minecraft:light_gray_concrete
setblock ~5 ~-26 ~23 minecraft:packed_ice
fill ~6 ~-26 ~23 ~7 ~-26 ~23 minecraft:air
setblock ~8 ~-26 ~23 minecraft:barrel
fill ~9 ~-26 ~23 ~10 ~-26 ~23 minecraft:air
setblock ~11 ~-26 ~23 minecraft:barrel
fill ~12 ~-26 ~23 ~13 ~-26 ~23 minecraft:air
setblock ~14 ~-26 ~23 minecraft:barrel
fill ~15 ~-26 ~23 ~16 ~-26 ~23 minecraft:air
setblock ~17 ~-26 ~23 minecraft:packed_ice
setblock ~18 ~-26 ~23 minecraft:light_gray_concrete
fill ~19 ~-26 ~23 ~28 ~-26 ~23 minecraft:air
setblock ~29 ~-26 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-26 ~23 ~38 ~-26 ~23 minecraft:air
setblock ~39 ~-26 ~23 minecraft:quartz_pillar
fill ~40 ~-26 ~23 ~49 ~-26 ~23 minecraft:air
setblock ~50 ~-26 ~23 minecraft:light_gray_concrete
fill ~51 ~-26 ~23 ~63 ~-26 ~23 minecraft:air
setblock ~64 ~-26 ~23 minecraft:light_gray_concrete
setblock ~4 ~-26 ~24 minecraft:light_gray_concrete
setblock ~5 ~-26 ~24 minecraft:packed_ice
fill ~6 ~-26 ~24 ~7 ~-26 ~24 minecraft:air
setblock ~8 ~-26 ~24 minecraft:barrel
fill ~9 ~-26 ~24 ~10 ~-26 ~24 minecraft:air
setblock ~11 ~-26 ~24 minecraft:barrel
fill ~12 ~-26 ~24 ~13 ~-26 ~24 minecraft:air
setblock ~14 ~-26 ~24 minecraft:barrel
fill ~15 ~-26 ~24 ~16 ~-26 ~24 minecraft:air
setblock ~17 ~-26 ~24 minecraft:packed_ice
setblock ~18 ~-26 ~24 minecraft:light_gray_concrete
setblock ~19 ~-26 ~24 minecraft:air
fill ~20 ~-26 ~24 ~22 ~-26 ~24 minecraft:glass
fill ~23 ~-26 ~24 ~25 ~-26 ~24 minecraft:air
setblock ~26 ~-26 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-26 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-26 ~24 ~29 ~-26 ~24 minecraft:air
setblock ~30 ~-26 ~24 minecraft:quartz_pillar
fill ~31 ~-26 ~24 ~37 ~-26 ~24 minecraft:air
setblock ~38 ~-26 ~24 minecraft:quartz_pillar
fill ~39 ~-26 ~24 ~40 ~-26 ~24 minecraft:air
setblock ~41 ~-26 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-26 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-26 ~24 ~49 ~-26 ~24 minecraft:air
setblock ~50 ~-26 ~24 minecraft:light_gray_concrete
fill ~51 ~-26 ~24 ~63 ~-26 ~24 minecraft:air
setblock ~64 ~-26 ~24 minecraft:light_gray_concrete
setblock ~4 ~-26 ~25 minecraft:light_gray_concrete
setblock ~5 ~-26 ~25 minecraft:packed_ice
fill ~6 ~-26 ~25 ~16 ~-26 ~25 minecraft:air
setblock ~17 ~-26 ~25 minecraft:packed_ice
setblock ~18 ~-26 ~25 minecraft:light_gray_concrete
setblock ~19 ~-26 ~25 minecraft:air
setblock ~20 ~-26 ~25 minecraft:glass
setblock ~21 ~-26 ~25 minecraft:air
setblock ~22 ~-26 ~25 minecraft:glass
fill ~23 ~-26 ~25 ~24 ~-26 ~25 minecraft:air
fill ~25 ~-26 ~25 ~26 ~-26 ~25 minecraft:quartz_pillar
fill ~27 ~-26 ~25 ~41 ~-26 ~25 minecraft:air
setblock ~42 ~-26 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-26 ~25 minecraft:quartz_pillar
fill ~44 ~-26 ~25 ~49 ~-26 ~25 minecraft:air
setblock ~50 ~-26 ~25 minecraft:light_gray_concrete
fill ~51 ~-26 ~25 ~63 ~-26 ~25 minecraft:air
setblock ~64 ~-26 ~25 minecraft:light_gray_concrete
setblock ~4 ~-26 ~26 minecraft:light_gray_concrete
fill ~5 ~-26 ~26 ~7 ~-26 ~26 minecraft:air
setblock ~8 ~-26 ~26 minecraft:barrel
fill ~9 ~-26 ~26 ~10 ~-26 ~26 minecraft:air
setblock ~11 ~-26 ~26 minecraft:barrel
fill ~12 ~-26 ~26 ~13 ~-26 ~26 minecraft:air
setblock ~14 ~-26 ~26 minecraft:barrel
fill ~15 ~-26 ~26 ~17 ~-26 ~26 minecraft:air
setblock ~18 ~-26 ~26 minecraft:light_gray_concrete
setblock ~19 ~-26 ~26 minecraft:black_concrete
fill ~20 ~-26 ~26 ~22 ~-26 ~26 minecraft:glass
setblock ~23 ~-26 ~26 minecraft:air
setblock ~24 ~-26 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-26 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-26 ~26 ~42 ~-26 ~26 minecraft:air
setblock ~43 ~-26 ~26 minecraft:quartz_pillar
setblock ~44 ~-26 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-26 ~26 ~49 ~-26 ~26 minecraft:air
setblock ~50 ~-26 ~26 minecraft:light_gray_concrete
fill ~51 ~-26 ~26 ~63 ~-26 ~26 minecraft:air
setblock ~64 ~-26 ~26 minecraft:light_gray_concrete
setblock ~4 ~-26 ~27 minecraft:light_gray_concrete
setblock ~5 ~-26 ~27 minecraft:packed_ice
fill ~6 ~-26 ~27 ~7 ~-26 ~27 minecraft:air
setblock ~8 ~-26 ~27 minecraft:barrel
fill ~9 ~-26 ~27 ~10 ~-26 ~27 minecraft:air
setblock ~11 ~-26 ~27 minecraft:barrel
fill ~12 ~-26 ~27 ~13 ~-26 ~27 minecraft:air
setblock ~14 ~-26 ~27 minecraft:barrel
fill ~15 ~-26 ~27 ~16 ~-26 ~27 minecraft:air
setblock ~17 ~-26 ~27 minecraft:packed_ice
setblock ~18 ~-26 ~27 minecraft:light_gray_concrete
fill ~19 ~-26 ~27 ~22 ~-26 ~27 minecraft:air
setblock ~23 ~-26 ~27 minecraft:black_concrete
setblock ~24 ~-26 ~27 minecraft:glass_pane[north=true,west=true]
fill ~25 ~-26 ~27 ~43 ~-26 ~27 minecraft:air
setblock ~44 ~-26 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-26 ~27 ~49 ~-26 ~27 minecraft:air
setblock ~50 ~-26 ~27 minecraft:light_gray_concrete
fill ~51 ~-26 ~27 ~63 ~-26 ~27 minecraft:air
setblock ~64 ~-26 ~27 minecraft:light_gray_concrete
setblock ~4 ~-26 ~28 minecraft:light_gray_concrete
setblock ~5 ~-26 ~28 minecraft:packed_ice
fill ~6 ~-26 ~28 ~7 ~-26 ~28 minecraft:air
setblock ~8 ~-26 ~28 minecraft:barrel
fill ~9 ~-26 ~28 ~10 ~-26 ~28 minecraft:air
setblock ~11 ~-26 ~28 minecraft:barrel
fill ~12 ~-26 ~28 ~13 ~-26 ~28 minecraft:air
setblock ~14 ~-26 ~28 minecraft:barrel
fill ~15 ~-26 ~28 ~16 ~-26 ~28 minecraft:air
setblock ~17 ~-26 ~28 minecraft:packed_ice
setblock ~18 ~-26 ~28 minecraft:light_gray_concrete
fill ~19 ~-26 ~28 ~21 ~-26 ~28 minecraft:air
setblock ~22 ~-26 ~28 minecraft:black_concrete
setblock ~23 ~-26 ~28 minecraft:glass_pane[north=true,south=true,west=true]
fill ~24 ~-26 ~28 ~44 ~-26 ~28 minecraft:air
setblock ~45 ~-26 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-26 ~28 ~49 ~-26 ~28 minecraft:air
setblock ~50 ~-26 ~28 minecraft:light_gray_concrete
fill ~51 ~-26 ~28 ~63 ~-26 ~28 minecraft:air
setblock ~64 ~-26 ~28 minecraft:light_gray_concrete
setblock ~4 ~-26 ~29 minecraft:light_gray_concrete
setblock ~5 ~-26 ~29 minecraft:packed_ice
fill ~6 ~-26 ~29 ~7 ~-26 ~29 minecraft:air
setblock ~8 ~-26 ~29 minecraft:barrel
fill ~9 ~-26 ~29 ~10 ~-26 ~29 minecraft:air
setblock ~11 ~-26 ~29 minecraft:barrel
fill ~12 ~-26 ~29 ~13 ~-26 ~29 minecraft:air
setblock ~14 ~-26 ~29 minecraft:barrel
fill ~15 ~-26 ~29 ~16 ~-26 ~29 minecraft:air
setblock ~17 ~-26 ~29 minecraft:packed_ice
setblock ~18 ~-26 ~29 minecraft:light_gray_concrete
fill ~19 ~-26 ~29 ~20 ~-26 ~29 minecraft:air
setblock ~21 ~-26 ~29 minecraft:black_concrete
fill ~22 ~-26 ~29 ~23 ~-26 ~29 minecraft:quartz_pillar
fill ~24 ~-26 ~29 ~44 ~-26 ~29 minecraft:air
setblock ~45 ~-26 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-26 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-26 ~29 ~49 ~-26 ~29 minecraft:air
setblock ~50 ~-26 ~29 minecraft:light_gray_concrete
fill ~51 ~-26 ~29 ~63 ~-26 ~29 minecraft:air
setblock ~64 ~-26 ~29 minecraft:light_gray_concrete
setblock ~4 ~-26 ~30 minecraft:light_gray_concrete
fill ~5 ~-26 ~30 ~17 ~-26 ~30 minecraft:air
setblock ~18 ~-26 ~30 minecraft:light_gray_concrete
fill ~19 ~-26 ~30 ~21 ~-26 ~30 minecraft:air
setblock ~22 ~-26 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-26 ~30 minecraft:air
setblock ~24 ~-26 ~30 minecraft:quartz_pillar
fill ~25 ~-26 ~30 ~43 ~-26 ~30 minecraft:air
setblock ~44 ~-26 ~30 minecraft:quartz_pillar
setblock ~45 ~-26 ~30 minecraft:air
setblock ~46 ~-26 ~30 minecraft:quartz_pillar
fill ~47 ~-26 ~30 ~49 ~-26 ~30 minecraft:air
setblock ~50 ~-26 ~30 minecraft:light_gray_concrete
fill ~51 ~-26 ~30 ~63 ~-26 ~30 minecraft:air
setblock ~64 ~-26 ~30 minecraft:light_gray_concrete
setblock ~4 ~-26 ~31 minecraft:light_gray_concrete
fill ~5 ~-26 ~31 ~7 ~-26 ~31 minecraft:packed_ice
setblock ~8 ~-26 ~31 minecraft:air
setblock ~9 ~-26 ~31 minecraft:packed_ice
fill ~10 ~-26 ~31 ~12 ~-26 ~31 minecraft:air
fill ~13 ~-26 ~31 ~15 ~-26 ~31 minecraft:packed_ice
setblock ~16 ~-26 ~31 minecraft:air
setblock ~17 ~-26 ~31 minecraft:packed_ice
setblock ~18 ~-26 ~31 minecraft:light_gray_concrete
fill ~19 ~-26 ~31 ~21 ~-26 ~31 minecraft:air
setblock ~22 ~-26 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-26 ~31 ~45 ~-26 ~31 minecraft:air
setblock ~46 ~-26 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-26 ~31 ~49 ~-26 ~31 minecraft:air
setblock ~50 ~-26 ~31 minecraft:light_gray_concrete
fill ~51 ~-26 ~31 ~63 ~-26 ~31 minecraft:air
setblock ~64 ~-26 ~31 minecraft:light_gray_concrete
setblock ~4 ~-26 ~32 minecraft:light_gray_concrete
fill ~5 ~-26 ~32 ~10 ~-26 ~32 minecraft:red_concrete
setblock ~11 ~-26 ~32 minecraft:air
fill ~12 ~-26 ~32 ~18 ~-26 ~32 minecraft:red_concrete
setblock ~19 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-26 ~32 minecraft:air
setblock ~21 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-26 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-26 ~32 ~32 ~-26 ~32 minecraft:air
fill ~33 ~-26 ~32 ~35 ~-26 ~32 minecraft:glass
fill ~36 ~-26 ~32 ~45 ~-26 ~32 minecraft:air
setblock ~46 ~-26 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-26 ~32 minecraft:air
setblock ~49 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~50 ~-26 ~32 minecraft:red_concrete
fill ~51 ~-26 ~32 ~53 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~54 ~-26 ~32 minecraft:red_concrete
fill ~55 ~-26 ~32 ~56 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~57 ~-26 ~32 minecraft:air
setblock ~58 ~-26 ~32 minecraft:red_concrete
fill ~59 ~-26 ~32 ~61 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~62 ~-26 ~32 minecraft:red_concrete
setblock ~63 ~-26 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~64 ~-26 ~32 minecraft:light_gray_concrete
setblock ~4 ~-26 ~33 minecraft:light_gray_concrete
fill ~5 ~-26 ~33 ~34 ~-26 ~33 minecraft:air
setblock ~35 ~-26 ~33 minecraft:glass
fill ~36 ~-26 ~33 ~63 ~-26 ~33 minecraft:air
setblock ~64 ~-26 ~33 minecraft:light_gray_concrete
setblock ~4 ~-26 ~34 minecraft:light_gray_concrete
fill ~5 ~-26 ~34 ~32 ~-26 ~34 minecraft:air
fill ~33 ~-26 ~34 ~35 ~-26 ~34 minecraft:glass
fill ~36 ~-26 ~34 ~63 ~-26 ~34 minecraft:air
setblock ~64 ~-26 ~34 minecraft:light_gray_concrete
setblock ~4 ~-26 ~35 minecraft:light_gray_concrete
fill ~5 ~-26 ~35 ~34 ~-26 ~35 minecraft:air
setblock ~35 ~-26 ~35 minecraft:glass
fill ~36 ~-26 ~35 ~63 ~-26 ~35 minecraft:air
setblock ~64 ~-26 ~35 minecraft:light_gray_concrete
setblock ~4 ~-26 ~36 minecraft:light_gray_concrete
fill ~5 ~-26 ~36 ~10 ~-26 ~36 minecraft:red_concrete
setblock ~11 ~-26 ~36 minecraft:air
fill ~12 ~-26 ~36 ~18 ~-26 ~36 minecraft:red_concrete
setblock ~19 ~-26 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-26 ~36 minecraft:air
setblock ~21 ~-26 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-26 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-26 ~36 ~32 ~-26 ~36 minecraft:air
fill ~33 ~-26 ~36 ~35 ~-26 ~36 minecraft:glass
fill ~36 ~-26 ~36 ~45 ~-26 ~36 minecraft:air
setblock ~46 ~-26 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-26 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-26 ~36 minecraft:air
setblock ~49 ~-26 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-26 ~36 ~56 ~-26 ~36 minecraft:red_concrete
setblock ~57 ~-26 ~36 minecraft:air
fill ~58 ~-26 ~36 ~63 ~-26 ~36 minecraft:red_concrete
setblock ~64 ~-26 ~36 minecraft:light_gray_concrete
setblock ~4 ~-26 ~37 minecraft:light_gray_concrete
fill ~5 ~-26 ~37 ~17 ~-26 ~37 minecraft:air
setblock ~18 ~-26 ~37 minecraft:light_gray_concrete
fill ~19 ~-26 ~37 ~21 ~-26 ~37 minecraft:air
setblock ~22 ~-26 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-26 ~37 ~45 ~-26 ~37 minecraft:air
setblock ~46 ~-26 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-26 ~37 ~49 ~-26 ~37 minecraft:air
setblock ~50 ~-26 ~37 minecraft:light_gray_concrete
fill ~51 ~-26 ~37 ~53 ~-26 ~37 minecraft:packed_ice
setblock ~54 ~-26 ~37 minecraft:air
setblock ~55 ~-26 ~37 minecraft:packed_ice
fill ~56 ~-26 ~37 ~58 ~-26 ~37 minecraft:air
fill ~59 ~-26 ~37 ~61 ~-26 ~37 minecraft:packed_ice
setblock ~62 ~-26 ~37 minecraft:air
setblock ~63 ~-26 ~37 minecraft:packed_ice
setblock ~64 ~-26 ~37 minecraft:light_gray_concrete
setblock ~4 ~-26 ~38 minecraft:light_gray_concrete
fill ~5 ~-26 ~38 ~17 ~-26 ~38 minecraft:air
setblock ~18 ~-26 ~38 minecraft:light_gray_concrete
setblock ~19 ~-26 ~38 minecraft:black_concrete
fill ~20 ~-26 ~38 ~21 ~-26 ~38 minecraft:air
setblock ~22 ~-26 ~38 minecraft:quartz_pillar
setblock ~23 ~-26 ~38 minecraft:air
setblock ~24 ~-26 ~38 minecraft:quartz_pillar
fill ~25 ~-26 ~38 ~43 ~-26 ~38 minecraft:air
setblock ~44 ~-26 ~38 minecraft:quartz_pillar
setblock ~45 ~-26 ~38 minecraft:air
setblock ~46 ~-26 ~38 minecraft:glass_pane[north=true,east=true,south=true]
setblock ~47 ~-26 ~38 minecraft:black_concrete
fill ~48 ~-26 ~38 ~49 ~-26 ~38 minecraft:air
setblock ~50 ~-26 ~38 minecraft:light_gray_concrete
setblock ~51 ~-26 ~38 minecraft:packed_ice
fill ~52 ~-26 ~38 ~62 ~-26 ~38 minecraft:air
setblock ~63 ~-26 ~38 minecraft:packed_ice
setblock ~64 ~-26 ~38 minecraft:light_gray_concrete
setblock ~4 ~-26 ~39 minecraft:light_gray_concrete
fill ~5 ~-26 ~39 ~17 ~-26 ~39 minecraft:air
setblock ~18 ~-26 ~39 minecraft:light_gray_concrete
fill ~19 ~-26 ~39 ~20 ~-26 ~39 minecraft:air
setblock ~21 ~-26 ~39 minecraft:black_concrete
setblock ~22 ~-26 ~39 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~23 ~-26 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-26 ~39 ~44 ~-26 ~39 minecraft:air
fill ~45 ~-26 ~39 ~46 ~-26 ~39 minecraft:quartz_pillar
fill ~47 ~-26 ~39 ~49 ~-26 ~39 minecraft:air
setblock ~50 ~-26 ~39 minecraft:light_gray_concrete
setblock ~51 ~-26 ~39 minecraft:packed_ice
fill ~52 ~-26 ~39 ~53 ~-26 ~39 minecraft:air
setblock ~54 ~-26 ~39 minecraft:barrel
fill ~55 ~-26 ~39 ~56 ~-26 ~39 minecraft:air
setblock ~57 ~-26 ~39 minecraft:barrel
fill ~58 ~-26 ~39 ~59 ~-26 ~39 minecraft:air
setblock ~60 ~-26 ~39 minecraft:barrel
fill ~61 ~-26 ~39 ~62 ~-26 ~39 minecraft:air
setblock ~63 ~-26 ~39 minecraft:packed_ice
setblock ~64 ~-26 ~39 minecraft:light_gray_concrete
setblock ~4 ~-26 ~40 minecraft:light_gray_concrete
fill ~5 ~-26 ~40 ~17 ~-26 ~40 minecraft:air
setblock ~18 ~-26 ~40 minecraft:light_gray_concrete
fill ~19 ~-26 ~40 ~22 ~-26 ~40 minecraft:air
setblock ~23 ~-26 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-26 ~40 ~44 ~-26 ~40 minecraft:air
setblock ~45 ~-26 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-26 ~40 ~49 ~-26 ~40 minecraft:air
setblock ~50 ~-26 ~40 minecraft:light_gray_concrete
fill ~51 ~-26 ~40 ~53 ~-26 ~40 minecraft:air
setblock ~54 ~-26 ~40 minecraft:barrel
fill ~55 ~-26 ~40 ~56 ~-26 ~40 minecraft:air
setblock ~57 ~-26 ~40 minecraft:barrel
fill ~58 ~-26 ~40 ~59 ~-26 ~40 minecraft:air
setblock ~60 ~-26 ~40 minecraft:barrel
fill ~61 ~-26 ~40 ~63 ~-26 ~40 minecraft:air
setblock ~64 ~-26 ~40 minecraft:light_gray_concrete
setblock ~4 ~-26 ~41 minecraft:light_gray_concrete
fill ~5 ~-26 ~41 ~17 ~-26 ~41 minecraft:air
setblock ~18 ~-26 ~41 minecraft:light_gray_concrete
setblock ~19 ~-26 ~41 minecraft:black_concrete
fill ~20 ~-26 ~41 ~21 ~-26 ~41 minecraft:air
setblock ~22 ~-26 ~41 minecraft:glass_pane
setblock ~23 ~-26 ~41 minecraft:air
setblock ~24 ~-26 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-26 ~41 ~43 ~-26 ~41 minecraft:air
setblock ~44 ~-26 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-26 ~41 ~48 ~-26 ~41 minecraft:air
setblock ~49 ~-26 ~41 minecraft:black_concrete
setblock ~50 ~-26 ~41 minecraft:light_gray_concrete
setblock ~51 ~-26 ~41 minecraft:packed_ice
fill ~52 ~-26 ~41 ~53 ~-26 ~41 minecraft:air
setblock ~54 ~-26 ~41 minecraft:barrel
fill ~55 ~-26 ~41 ~56 ~-26 ~41 minecraft:air
setblock ~57 ~-26 ~41 minecraft:barrel
fill ~58 ~-26 ~41 ~59 ~-26 ~41 minecraft:air
setblock ~60 ~-26 ~41 minecraft:barrel
fill ~61 ~-26 ~41 ~62 ~-26 ~41 minecraft:air
setblock ~63 ~-26 ~41 minecraft:packed_ice
setblock ~64 ~-26 ~41 minecraft:light_gray_concrete
setblock ~4 ~-26 ~42 minecraft:light_gray_concrete
setblock ~5 ~-26 ~42 minecraft:black_concrete
fill ~6 ~-26 ~42 ~17 ~-26 ~42 minecraft:air
setblock ~18 ~-26 ~42 minecraft:light_gray_concrete
fill ~19 ~-26 ~42 ~20 ~-26 ~42 minecraft:air
setblock ~21 ~-26 ~42 minecraft:glass_pane
setblock ~22 ~-26 ~42 minecraft:air
setblock ~23 ~-26 ~42 minecraft:glass_pane[east=true]
setblock ~24 ~-26 ~42 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~25 ~-26 ~42 minecraft:quartz_pillar
fill ~26 ~-26 ~42 ~42 ~-26 ~42 minecraft:air
setblock ~43 ~-26 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-26 ~42 minecraft:glass_pane[north=true,west=true]
setblock ~45 ~-26 ~42 minecraft:air
fill ~46 ~-26 ~42 ~48 ~-26 ~42 minecraft:glass
setblock ~49 ~-26 ~42 minecraft:air
setblock ~50 ~-26 ~42 minecraft:light_gray_concrete
setblock ~51 ~-26 ~42 minecraft:packed_ice
fill ~52 ~-26 ~42 ~53 ~-26 ~42 minecraft:air
setblock ~54 ~-26 ~42 minecraft:barrel
fill ~55 ~-26 ~42 ~56 ~-26 ~42 minecraft:air
setblock ~57 ~-26 ~42 minecraft:barrel
fill ~58 ~-26 ~42 ~59 ~-26 ~42 minecraft:air
setblock ~60 ~-26 ~42 minecraft:barrel
fill ~61 ~-26 ~42 ~62 ~-26 ~42 minecraft:air
setblock ~63 ~-26 ~42 minecraft:packed_ice
setblock ~64 ~-26 ~42 minecraft:light_gray_concrete
setblock ~4 ~-26 ~43 minecraft:light_gray_concrete
setblock ~5 ~-26 ~43 minecraft:black_concrete
fill ~6 ~-26 ~43 ~17 ~-26 ~43 minecraft:air
setblock ~18 ~-26 ~43 minecraft:light_gray_concrete
fill ~19 ~-26 ~43 ~21 ~-26 ~43 minecraft:air
setblock ~22 ~-26 ~43 minecraft:glass_pane
fill ~23 ~-26 ~43 ~24 ~-26 ~43 minecraft:air
setblock ~25 ~-26 ~43 minecraft:quartz_pillar
setblock ~26 ~-26 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-26 ~43 ~41 ~-26 ~43 minecraft:air
fill ~42 ~-26 ~43 ~43 ~-26 ~43 minecraft:quartz_pillar
fill ~44 ~-26 ~43 ~45 ~-26 ~43 minecraft:air
setblock ~46 ~-26 ~43 minecraft:glass
setblock ~47 ~-26 ~43 minecraft:air
setblock ~48 ~-26 ~43 minecraft:glass
setblock ~49 ~-26 ~43 minecraft:air
setblock ~50 ~-26 ~43 minecraft:light_gray_concrete
setblock ~51 ~-26 ~43 minecraft:packed_ice
fill ~52 ~-26 ~43 ~62 ~-26 ~43 minecraft:air
setblock ~63 ~-26 ~43 minecraft:packed_ice
setblock ~64 ~-26 ~43 minecraft:light_gray_concrete
setblock ~4 ~-26 ~44 minecraft:light_gray_concrete
setblock ~5 ~-26 ~44 minecraft:black_concrete
fill ~6 ~-26 ~44 ~17 ~-26 ~44 minecraft:air
setblock ~18 ~-26 ~44 minecraft:light_gray_concrete
setblock ~19 ~-26 ~44 minecraft:black_concrete
fill ~20 ~-26 ~44 ~24 ~-26 ~44 minecraft:air
setblock ~25 ~-26 ~44 minecraft:black_concrete
setblock ~26 ~-26 ~44 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~27 ~-26 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-26 ~44 ~29 ~-26 ~44 minecraft:air
setblock ~30 ~-26 ~44 minecraft:quartz_pillar
fill ~31 ~-26 ~44 ~37 ~-26 ~44 minecraft:air
setblock ~38 ~-26 ~44 minecraft:quartz_pillar
fill ~39 ~-26 ~44 ~40 ~-26 ~44 minecraft:air
setblock ~41 ~-26 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-26 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-26 ~44 ~45 ~-26 ~44 minecraft:air
fill ~46 ~-26 ~44 ~48 ~-26 ~44 minecraft:glass
setblock ~49 ~-26 ~44 minecraft:air
setblock ~50 ~-26 ~44 minecraft:light_gray_concrete
fill ~51 ~-26 ~44 ~53 ~-26 ~44 minecraft:air
setblock ~54 ~-26 ~44 minecraft:barrel
fill ~55 ~-26 ~44 ~56 ~-26 ~44 minecraft:air
setblock ~57 ~-26 ~44 minecraft:barrel
fill ~58 ~-26 ~44 ~59 ~-26 ~44 minecraft:air
setblock ~60 ~-26 ~44 minecraft:barrel
fill ~61 ~-26 ~44 ~63 ~-26 ~44 minecraft:air
setblock ~64 ~-26 ~44 minecraft:light_gray_concrete
setblock ~4 ~-26 ~45 minecraft:light_gray_concrete
fill ~5 ~-26 ~45 ~17 ~-26 ~45 minecraft:air
setblock ~18 ~-26 ~45 minecraft:light_gray_concrete
fill ~19 ~-26 ~45 ~21 ~-26 ~45 minecraft:air
setblock ~22 ~-26 ~45 minecraft:glass_pane
fill ~23 ~-26 ~45 ~28 ~-26 ~45 minecraft:air
setblock ~29 ~-26 ~45 minecraft:quartz_pillar
fill ~30 ~-26 ~45 ~38 ~-26 ~45 minecraft:air
setblock ~39 ~-26 ~45 minecraft:glass_pane[east=true,south=true]
fill ~40 ~-26 ~45 ~49 ~-26 ~45 minecraft:air
setblock ~50 ~-26 ~45 minecraft:light_gray_concrete
setblock ~51 ~-26 ~45 minecraft:packed_ice
fill ~52 ~-26 ~45 ~53 ~-26 ~45 minecraft:air
setblock ~54 ~-26 ~45 minecraft:barrel
fill ~55 ~-26 ~45 ~56 ~-26 ~45 minecraft:air
setblock ~57 ~-26 ~45 minecraft:barrel
fill ~58 ~-26 ~45 ~59 ~-26 ~45 minecraft:air
setblock ~60 ~-26 ~45 minecraft:barrel
fill ~61 ~-26 ~45 ~62 ~-26 ~45 minecraft:air
setblock ~63 ~-26 ~45 minecraft:packed_ice
setblock ~64 ~-26 ~45 minecraft:light_gray_concrete
setblock ~4 ~-26 ~46 minecraft:light_gray_concrete
fill ~5 ~-26 ~46 ~17 ~-26 ~46 minecraft:air
setblock ~18 ~-26 ~46 minecraft:light_gray_concrete
fill ~19 ~-26 ~46 ~20 ~-26 ~46 minecraft:air
setblock ~21 ~-26 ~46 minecraft:glass_pane
setblock ~22 ~-26 ~46 minecraft:air
setblock ~23 ~-26 ~46 minecraft:glass_pane
fill ~24 ~-26 ~46 ~28 ~-26 ~46 minecraft:air
setblock ~29 ~-26 ~46 minecraft:quartz_pillar
fill ~30 ~-26 ~46 ~31 ~-26 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-26 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-26 ~46 ~35 ~-26 ~46 minecraft:air
setblock ~36 ~-26 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-26 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-26 ~46 minecraft:quartz_pillar
setblock ~39 ~-26 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-26 ~46 ~41 ~-26 ~46 minecraft:air
fill ~42 ~-26 ~46 ~44 ~-26 ~46 minecraft:glass
setblock ~45 ~-26 ~46 minecraft:air
fill ~46 ~-26 ~46 ~48 ~-26 ~46 minecraft:glass
setblock ~49 ~-26 ~46 minecraft:black_concrete
setblock ~50 ~-26 ~46 minecraft:light_gray_concrete
setblock ~51 ~-26 ~46 minecraft:packed_ice
fill ~52 ~-26 ~46 ~53 ~-26 ~46 minecraft:air
setblock ~54 ~-26 ~46 minecraft:barrel
fill ~55 ~-26 ~46 ~56 ~-26 ~46 minecraft:air
setblock ~57 ~-26 ~46 minecraft:barrel
fill ~58 ~-26 ~46 ~59 ~-26 ~46 minecraft:air
setblock ~60 ~-26 ~46 minecraft:barrel
fill ~61 ~-26 ~46 ~62 ~-26 ~46 minecraft:air
setblock ~63 ~-26 ~46 minecraft:packed_ice
setblock ~64 ~-26 ~46 minecraft:light_gray_concrete
setblock ~4 ~-26 ~47 minecraft:light_gray_concrete
fill ~5 ~-26 ~47 ~17 ~-26 ~47 minecraft:air
setblock ~18 ~-26 ~47 minecraft:light_gray_concrete
setblock ~19 ~-26 ~47 minecraft:black_concrete
fill ~20 ~-26 ~47 ~21 ~-26 ~47 minecraft:air
setblock ~22 ~-26 ~47 minecraft:glass_pane
fill ~23 ~-26 ~47 ~31 ~-26 ~47 minecraft:air
setblock ~32 ~-26 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-26 ~47 ~35 ~-26 ~47 minecraft:air
setblock ~36 ~-26 ~47 minecraft:glass_pane[north=true,south=true]
setblock ~37 ~-26 ~47 minecraft:air
setblock ~38 ~-26 ~47 minecraft:black_concrete
fill ~39 ~-26 ~47 ~41 ~-26 ~47 minecraft:air
setblock ~42 ~-26 ~47 minecraft:glass
setblock ~43 ~-26 ~47 minecraft:air
setblock ~44 ~-26 ~47 minecraft:glass
setblock ~45 ~-26 ~47 minecraft:air
setblock ~46 ~-26 ~47 minecraft:glass
schedule function hive:weiter/12 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 11 von 18 fertig","color":"gray"}]