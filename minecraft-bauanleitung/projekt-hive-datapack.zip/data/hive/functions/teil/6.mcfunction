setblock ~49 ~-42 ~16 minecraft:air
setblock ~50 ~-42 ~16 minecraft:light_gray_concrete
setblock ~51 ~-42 ~16 minecraft:iron_block
fill ~52 ~-42 ~16 ~62 ~-42 ~16 minecraft:air
setblock ~63 ~-42 ~16 minecraft:iron_block
setblock ~64 ~-42 ~16 minecraft:light_gray_concrete
setblock ~4 ~-42 ~17 minecraft:light_gray_concrete
fill ~5 ~-42 ~17 ~17 ~-42 ~17 minecraft:air
setblock ~18 ~-42 ~17 minecraft:light_gray_concrete
fill ~19 ~-42 ~17 ~31 ~-42 ~17 minecraft:air
setblock ~32 ~-42 ~17 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~17 ~35 ~-42 ~17 minecraft:air
setblock ~36 ~-42 ~17 minecraft:red_concrete
fill ~37 ~-42 ~17 ~39 ~-42 ~17 minecraft:air
setblock ~40 ~-42 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-42 ~17 ~43 ~-42 ~17 minecraft:air
setblock ~44 ~-42 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-42 ~17 ~47 ~-42 ~17 minecraft:air
setblock ~48 ~-42 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-42 ~17 minecraft:air
setblock ~50 ~-42 ~17 minecraft:light_gray_concrete
fill ~51 ~-42 ~17 ~55 ~-42 ~17 minecraft:iron_block
fill ~56 ~-42 ~17 ~58 ~-42 ~17 minecraft:air
fill ~59 ~-42 ~17 ~63 ~-42 ~17 minecraft:iron_block
setblock ~64 ~-42 ~17 minecraft:light_gray_concrete
fill ~4 ~-42 ~18 ~10 ~-42 ~18 minecraft:light_gray_concrete
setblock ~11 ~-42 ~18 minecraft:air
fill ~12 ~-42 ~18 ~31 ~-42 ~18 minecraft:light_gray_concrete
setblock ~32 ~-42 ~18 minecraft:red_concrete
fill ~33 ~-42 ~18 ~35 ~-42 ~18 minecraft:air
setblock ~36 ~-42 ~18 minecraft:red_concrete
fill ~37 ~-42 ~18 ~56 ~-42 ~18 minecraft:light_gray_concrete
setblock ~57 ~-42 ~18 minecraft:air
fill ~58 ~-42 ~18 ~64 ~-42 ~18 minecraft:light_gray_concrete
setblock ~4 ~-42 ~19 minecraft:light_gray_concrete
setblock ~5 ~-42 ~19 minecraft:blast_furnace[facing=south]
setblock ~6 ~-42 ~19 minecraft:waxed_cut_copper
setblock ~7 ~-42 ~19 minecraft:redstone_lamp[lit=true]
setblock ~8 ~-42 ~19 minecraft:blast_furnace[facing=south]
setblock ~9 ~-42 ~19 minecraft:waxed_cut_copper
fill ~10 ~-42 ~19 ~12 ~-42 ~19 minecraft:air
setblock ~13 ~-42 ~19 minecraft:redstone_lamp[lit=true]
setblock ~14 ~-42 ~19 minecraft:blast_furnace[facing=south]
setblock ~15 ~-42 ~19 minecraft:waxed_cut_copper
setblock ~16 ~-42 ~19 minecraft:redstone_lamp[lit=true]
setblock ~17 ~-42 ~19 minecraft:blast_furnace[facing=south]
setblock ~18 ~-42 ~19 minecraft:light_gray_concrete
fill ~19 ~-42 ~19 ~30 ~-42 ~19 minecraft:black_concrete
setblock ~31 ~-42 ~19 minecraft:air
setblock ~32 ~-42 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~19 ~35 ~-42 ~19 minecraft:air
setblock ~36 ~-42 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-42 ~19 ~49 ~-42 ~19 minecraft:air
setblock ~50 ~-42 ~19 minecraft:light_gray_concrete
fill ~51 ~-42 ~19 ~63 ~-42 ~19 minecraft:air
setblock ~64 ~-42 ~19 minecraft:light_gray_concrete
setblock ~4 ~-42 ~20 minecraft:light_gray_concrete
setblock ~5 ~-42 ~20 minecraft:waxed_cut_copper
fill ~6 ~-42 ~20 ~16 ~-42 ~20 minecraft:air
setblock ~17 ~-42 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-42 ~20 minecraft:light_gray_concrete
fill ~19 ~-42 ~20 ~49 ~-42 ~20 minecraft:air
setblock ~50 ~-42 ~20 minecraft:light_gray_concrete
fill ~51 ~-42 ~20 ~62 ~-42 ~20 minecraft:air
setblock ~63 ~-42 ~20 minecraft:black_concrete
setblock ~64 ~-42 ~20 minecraft:light_gray_concrete
setblock ~4 ~-42 ~21 minecraft:light_gray_concrete
setblock ~5 ~-42 ~21 minecraft:redstone_lamp[lit=true]
fill ~6 ~-42 ~21 ~16 ~-42 ~21 minecraft:air
setblock ~17 ~-42 ~21 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-42 ~21 minecraft:light_gray_concrete
fill ~19 ~-42 ~21 ~31 ~-42 ~21 minecraft:air
setblock ~32 ~-42 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~21 ~35 ~-42 ~21 minecraft:air
setblock ~36 ~-42 ~21 minecraft:glass_pane[north=true,south=true]
setblock ~37 ~-42 ~21 minecraft:air
setblock ~38 ~-42 ~21 minecraft:observer[facing=south]
fill ~39 ~-42 ~21 ~40 ~-42 ~21 minecraft:air
fill ~41 ~-42 ~21 ~42 ~-42 ~21 minecraft:observer[facing=south]
setblock ~43 ~-42 ~21 minecraft:air
fill ~44 ~-42 ~21 ~46 ~-42 ~21 minecraft:observer[facing=south]
setblock ~47 ~-42 ~21 minecraft:air
setblock ~48 ~-42 ~21 minecraft:observer[facing=south]
setblock ~49 ~-42 ~21 minecraft:air
setblock ~50 ~-42 ~21 minecraft:light_gray_concrete
fill ~51 ~-42 ~21 ~63 ~-42 ~21 minecraft:air
setblock ~64 ~-42 ~21 minecraft:light_gray_concrete
setblock ~4 ~-42 ~22 minecraft:light_gray_concrete
setblock ~5 ~-42 ~22 minecraft:blast_furnace[facing=east]
fill ~6 ~-42 ~22 ~9 ~-42 ~22 minecraft:air
setblock ~10 ~-42 ~22 minecraft:waxed_cut_copper
fill ~11 ~-42 ~22 ~13 ~-42 ~22 minecraft:air
setblock ~14 ~-42 ~22 minecraft:waxed_cut_copper
fill ~15 ~-42 ~22 ~16 ~-42 ~22 minecraft:air
setblock ~17 ~-42 ~22 minecraft:blast_furnace[facing=west]
setblock ~18 ~-42 ~22 minecraft:light_gray_concrete
setblock ~19 ~-42 ~22 minecraft:air
fill ~20 ~-42 ~22 ~22 ~-42 ~22 minecraft:black_concrete
setblock ~23 ~-42 ~22 minecraft:air
fill ~24 ~-42 ~22 ~25 ~-42 ~22 minecraft:black_concrete
fill ~26 ~-42 ~22 ~28 ~-42 ~22 minecraft:air
setblock ~29 ~-42 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-42 ~22 minecraft:quartz_pillar
setblock ~31 ~-42 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-42 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-42 ~22 ~35 ~-42 ~22 minecraft:air
setblock ~36 ~-42 ~22 minecraft:glass_pane[north=true,east=true]
setblock ~37 ~-42 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-42 ~22 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~39 ~-42 ~22 minecraft:quartz_pillar
fill ~40 ~-42 ~22 ~49 ~-42 ~22 minecraft:air
setblock ~50 ~-42 ~22 minecraft:light_gray_concrete
fill ~51 ~-42 ~22 ~63 ~-42 ~22 minecraft:air
setblock ~64 ~-42 ~22 minecraft:light_gray_concrete
setblock ~4 ~-42 ~23 minecraft:light_gray_concrete
setblock ~5 ~-42 ~23 minecraft:waxed_cut_copper
fill ~6 ~-42 ~23 ~16 ~-42 ~23 minecraft:air
setblock ~17 ~-42 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-42 ~23 minecraft:light_gray_concrete
fill ~19 ~-42 ~23 ~28 ~-42 ~23 minecraft:air
setblock ~29 ~-42 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-42 ~23 ~38 ~-42 ~23 minecraft:air
setblock ~39 ~-42 ~23 minecraft:quartz_pillar
fill ~40 ~-42 ~23 ~49 ~-42 ~23 minecraft:air
setblock ~50 ~-42 ~23 minecraft:light_gray_concrete
fill ~51 ~-42 ~23 ~62 ~-42 ~23 minecraft:air
setblock ~63 ~-42 ~23 minecraft:black_concrete
setblock ~64 ~-42 ~23 minecraft:light_gray_concrete
setblock ~4 ~-42 ~24 minecraft:light_gray_concrete
setblock ~5 ~-42 ~24 minecraft:redstone_lamp[lit=true]
fill ~6 ~-42 ~24 ~16 ~-42 ~24 minecraft:air
setblock ~17 ~-42 ~24 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-42 ~24 minecraft:light_gray_concrete
fill ~19 ~-42 ~24 ~25 ~-42 ~24 minecraft:air
setblock ~26 ~-42 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-42 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-42 ~24 ~29 ~-42 ~24 minecraft:air
setblock ~30 ~-42 ~24 minecraft:quartz_pillar
fill ~31 ~-42 ~24 ~37 ~-42 ~24 minecraft:air
setblock ~38 ~-42 ~24 minecraft:quartz_pillar
fill ~39 ~-42 ~24 ~40 ~-42 ~24 minecraft:air
setblock ~41 ~-42 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-42 ~24 minecraft:glass_pane[south=true,west=true]
setblock ~43 ~-42 ~24 minecraft:air
fill ~44 ~-42 ~24 ~46 ~-42 ~24 minecraft:observer[facing=north]
setblock ~47 ~-42 ~24 minecraft:air
setblock ~48 ~-42 ~24 minecraft:observer[facing=north]
setblock ~49 ~-42 ~24 minecraft:air
setblock ~50 ~-42 ~24 minecraft:light_gray_concrete
fill ~51 ~-42 ~24 ~63 ~-42 ~24 minecraft:air
setblock ~64 ~-42 ~24 minecraft:light_gray_concrete
setblock ~4 ~-42 ~25 minecraft:light_gray_concrete
setblock ~5 ~-42 ~25 minecraft:blast_furnace[facing=east]
fill ~6 ~-42 ~25 ~16 ~-42 ~25 minecraft:air
setblock ~17 ~-42 ~25 minecraft:blast_furnace[facing=west]
setblock ~18 ~-42 ~25 minecraft:light_gray_concrete
fill ~19 ~-42 ~25 ~24 ~-42 ~25 minecraft:air
fill ~25 ~-42 ~25 ~26 ~-42 ~25 minecraft:quartz_pillar
fill ~27 ~-42 ~25 ~41 ~-42 ~25 minecraft:air
setblock ~42 ~-42 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-42 ~25 minecraft:quartz_pillar
fill ~44 ~-42 ~25 ~49 ~-42 ~25 minecraft:air
setblock ~50 ~-42 ~25 minecraft:light_gray_concrete
fill ~51 ~-42 ~25 ~63 ~-42 ~25 minecraft:air
setblock ~64 ~-42 ~25 minecraft:light_gray_concrete
setblock ~4 ~-42 ~26 minecraft:light_gray_concrete
setblock ~5 ~-42 ~26 minecraft:waxed_cut_copper
fill ~6 ~-42 ~26 ~9 ~-42 ~26 minecraft:air
setblock ~10 ~-42 ~26 minecraft:waxed_cut_copper
fill ~11 ~-42 ~26 ~13 ~-42 ~26 minecraft:air
setblock ~14 ~-42 ~26 minecraft:waxed_cut_copper
fill ~15 ~-42 ~26 ~16 ~-42 ~26 minecraft:air
setblock ~17 ~-42 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-42 ~26 minecraft:light_gray_concrete
fill ~19 ~-42 ~26 ~23 ~-42 ~26 minecraft:air
setblock ~24 ~-42 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-42 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-42 ~26 ~42 ~-42 ~26 minecraft:air
setblock ~43 ~-42 ~26 minecraft:quartz_pillar
setblock ~44 ~-42 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-42 ~26 ~49 ~-42 ~26 minecraft:air
setblock ~50 ~-42 ~26 minecraft:light_gray_concrete
fill ~51 ~-42 ~26 ~62 ~-42 ~26 minecraft:air
setblock ~63 ~-42 ~26 minecraft:black_concrete
setblock ~64 ~-42 ~26 minecraft:light_gray_concrete
setblock ~4 ~-42 ~27 minecraft:light_gray_concrete
setblock ~5 ~-42 ~27 minecraft:redstone_lamp[lit=true]
fill ~6 ~-42 ~27 ~16 ~-42 ~27 minecraft:air
setblock ~17 ~-42 ~27 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-42 ~27 minecraft:light_gray_concrete
fill ~19 ~-42 ~27 ~23 ~-42 ~27 minecraft:air
setblock ~24 ~-42 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-42 ~27 ~43 ~-42 ~27 minecraft:air
setblock ~44 ~-42 ~27 minecraft:glass_pane[north=true,east=true]
fill ~45 ~-42 ~27 ~46 ~-42 ~27 minecraft:observer[facing=south]
setblock ~47 ~-42 ~27 minecraft:air
setblock ~48 ~-42 ~27 minecraft:observer[facing=south]
setblock ~49 ~-42 ~27 minecraft:air
setblock ~50 ~-42 ~27 minecraft:light_gray_concrete
fill ~51 ~-42 ~27 ~63 ~-42 ~27 minecraft:air
setblock ~64 ~-42 ~27 minecraft:light_gray_concrete
setblock ~4 ~-42 ~28 minecraft:light_gray_concrete
setblock ~5 ~-42 ~28 minecraft:blast_furnace[facing=east]
fill ~6 ~-42 ~28 ~16 ~-42 ~28 minecraft:air
setblock ~17 ~-42 ~28 minecraft:blast_furnace[facing=west]
setblock ~18 ~-42 ~28 minecraft:light_gray_concrete
fill ~19 ~-42 ~28 ~22 ~-42 ~28 minecraft:air
setblock ~23 ~-42 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-42 ~28 ~44 ~-42 ~28 minecraft:air
setblock ~45 ~-42 ~28 minecraft:glass_pane[north=true,south=true]
fill ~46 ~-42 ~28 ~49 ~-42 ~28 minecraft:air
setblock ~50 ~-42 ~28 minecraft:light_gray_concrete
fill ~51 ~-42 ~28 ~63 ~-42 ~28 minecraft:air
setblock ~64 ~-42 ~28 minecraft:light_gray_concrete
setblock ~4 ~-42 ~29 minecraft:light_gray_concrete
setblock ~5 ~-42 ~29 minecraft:waxed_cut_copper
fill ~6 ~-42 ~29 ~16 ~-42 ~29 minecraft:air
setblock ~17 ~-42 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-42 ~29 minecraft:light_gray_concrete
fill ~19 ~-42 ~29 ~21 ~-42 ~29 minecraft:air
fill ~22 ~-42 ~29 ~23 ~-42 ~29 minecraft:quartz_pillar
fill ~24 ~-42 ~29 ~44 ~-42 ~29 minecraft:air
setblock ~45 ~-42 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-42 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-42 ~29 ~49 ~-42 ~29 minecraft:air
setblock ~50 ~-42 ~29 minecraft:light_gray_concrete
fill ~51 ~-42 ~29 ~62 ~-42 ~29 minecraft:air
setblock ~63 ~-42 ~29 minecraft:black_concrete
setblock ~64 ~-42 ~29 minecraft:light_gray_concrete
setblock ~4 ~-42 ~30 minecraft:light_gray_concrete
setblock ~5 ~-42 ~30 minecraft:redstone_lamp[lit=true]
fill ~6 ~-42 ~30 ~16 ~-42 ~30 minecraft:air
setblock ~17 ~-42 ~30 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-42 ~30 minecraft:light_gray_concrete
fill ~19 ~-42 ~30 ~21 ~-42 ~30 minecraft:air
setblock ~22 ~-42 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-42 ~30 minecraft:air
setblock ~24 ~-42 ~30 minecraft:quartz_pillar
fill ~25 ~-42 ~30 ~43 ~-42 ~30 minecraft:air
setblock ~44 ~-42 ~30 minecraft:quartz_pillar
setblock ~45 ~-42 ~30 minecraft:air
setblock ~46 ~-42 ~30 minecraft:quartz_pillar
fill ~47 ~-42 ~30 ~49 ~-42 ~30 minecraft:air
setblock ~50 ~-42 ~30 minecraft:light_gray_concrete
fill ~51 ~-42 ~30 ~63 ~-42 ~30 minecraft:air
setblock ~64 ~-42 ~30 minecraft:light_gray_concrete
setblock ~4 ~-42 ~31 minecraft:light_gray_concrete
setblock ~5 ~-42 ~31 minecraft:blast_furnace[facing=north]
setblock ~6 ~-42 ~31 minecraft:waxed_cut_copper
setblock ~7 ~-42 ~31 minecraft:redstone_lamp[lit=true]
setblock ~8 ~-42 ~31 minecraft:blast_furnace[facing=north]
setblock ~9 ~-42 ~31 minecraft:waxed_cut_copper
fill ~10 ~-42 ~31 ~12 ~-42 ~31 minecraft:air
setblock ~13 ~-42 ~31 minecraft:redstone_lamp[lit=true]
setblock ~14 ~-42 ~31 minecraft:blast_furnace[facing=north]
setblock ~15 ~-42 ~31 minecraft:waxed_cut_copper
setblock ~16 ~-42 ~31 minecraft:redstone_lamp[lit=true]
setblock ~17 ~-42 ~31 minecraft:blast_furnace[facing=west]
setblock ~18 ~-42 ~31 minecraft:light_gray_concrete
fill ~19 ~-42 ~31 ~21 ~-42 ~31 minecraft:air
setblock ~22 ~-42 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-42 ~31 ~45 ~-42 ~31 minecraft:air
setblock ~46 ~-42 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-42 ~31 ~49 ~-42 ~31 minecraft:air
setblock ~50 ~-42 ~31 minecraft:light_gray_concrete
fill ~51 ~-42 ~31 ~63 ~-42 ~31 minecraft:air
setblock ~64 ~-42 ~31 minecraft:light_gray_concrete
setblock ~4 ~-42 ~32 minecraft:light_gray_concrete
fill ~5 ~-42 ~32 ~10 ~-42 ~32 minecraft:red_concrete
setblock ~11 ~-42 ~32 minecraft:air
fill ~12 ~-42 ~32 ~18 ~-42 ~32 minecraft:red_concrete
setblock ~19 ~-42 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-42 ~32 minecraft:air
setblock ~21 ~-42 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-42 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-42 ~32 ~32 ~-42 ~32 minecraft:air
fill ~33 ~-42 ~32 ~35 ~-42 ~32 minecraft:glass
fill ~36 ~-42 ~32 ~45 ~-42 ~32 minecraft:air
setblock ~46 ~-42 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-42 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-42 ~32 minecraft:air
setblock ~49 ~-42 ~32 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-42 ~32 ~56 ~-42 ~32 minecraft:red_concrete
setblock ~57 ~-42 ~32 minecraft:air
fill ~58 ~-42 ~32 ~63 ~-42 ~32 minecraft:red_concrete
setblock ~64 ~-42 ~32 minecraft:light_gray_concrete
setblock ~4 ~-42 ~33 minecraft:light_gray_concrete
fill ~5 ~-42 ~33 ~32 ~-42 ~33 minecraft:air
setblock ~33 ~-42 ~33 minecraft:glass
fill ~34 ~-42 ~33 ~63 ~-42 ~33 minecraft:air
setblock ~64 ~-42 ~33 minecraft:light_gray_concrete
setblock ~4 ~-42 ~34 minecraft:light_gray_concrete
fill ~5 ~-42 ~34 ~32 ~-42 ~34 minecraft:air
fill ~33 ~-42 ~34 ~35 ~-42 ~34 minecraft:glass
fill ~36 ~-42 ~34 ~63 ~-42 ~34 minecraft:air
setblock ~64 ~-42 ~34 minecraft:light_gray_concrete
setblock ~4 ~-42 ~35 minecraft:light_gray_concrete
fill ~5 ~-42 ~35 ~32 ~-42 ~35 minecraft:air
setblock ~33 ~-42 ~35 minecraft:glass
fill ~34 ~-42 ~35 ~63 ~-42 ~35 minecraft:air
setblock ~64 ~-42 ~35 minecraft:light_gray_concrete
setblock ~4 ~-42 ~36 minecraft:light_gray_concrete
fill ~5 ~-42 ~36 ~10 ~-42 ~36 minecraft:red_concrete
setblock ~11 ~-42 ~36 minecraft:air
fill ~12 ~-42 ~36 ~18 ~-42 ~36 minecraft:red_concrete
setblock ~19 ~-42 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-42 ~36 minecraft:air
setblock ~21 ~-42 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-42 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-42 ~36 ~32 ~-42 ~36 minecraft:air
fill ~33 ~-42 ~36 ~35 ~-42 ~36 minecraft:glass
fill ~36 ~-42 ~36 ~45 ~-42 ~36 minecraft:air
setblock ~46 ~-42 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-42 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-42 ~36 minecraft:air
setblock ~49 ~-42 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-42 ~36 ~56 ~-42 ~36 minecraft:red_concrete
setblock ~57 ~-42 ~36 minecraft:air
fill ~58 ~-42 ~36 ~63 ~-42 ~36 minecraft:red_concrete
setblock ~64 ~-42 ~36 minecraft:light_gray_concrete
setblock ~4 ~-42 ~37 minecraft:light_gray_concrete
fill ~5 ~-42 ~37 ~17 ~-42 ~37 minecraft:air
setblock ~18 ~-42 ~37 minecraft:light_gray_concrete
fill ~19 ~-42 ~37 ~21 ~-42 ~37 minecraft:air
setblock ~22 ~-42 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-42 ~37 ~45 ~-42 ~37 minecraft:air
setblock ~46 ~-42 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-42 ~37 ~49 ~-42 ~37 minecraft:air
setblock ~50 ~-42 ~37 minecraft:light_gray_concrete
fill ~51 ~-42 ~37 ~63 ~-42 ~37 minecraft:air
setblock ~64 ~-42 ~37 minecraft:light_gray_concrete
setblock ~4 ~-42 ~38 minecraft:light_gray_concrete
fill ~5 ~-42 ~38 ~17 ~-42 ~38 minecraft:air
setblock ~18 ~-42 ~38 minecraft:light_gray_concrete
fill ~19 ~-42 ~38 ~21 ~-42 ~38 minecraft:air
setblock ~22 ~-42 ~38 minecraft:quartz_pillar
setblock ~23 ~-42 ~38 minecraft:air
setblock ~24 ~-42 ~38 minecraft:quartz_pillar
fill ~25 ~-42 ~38 ~43 ~-42 ~38 minecraft:air
setblock ~44 ~-42 ~38 minecraft:quartz_pillar
setblock ~45 ~-42 ~38 minecraft:air
setblock ~46 ~-42 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-42 ~38 ~49 ~-42 ~38 minecraft:air
setblock ~50 ~-42 ~38 minecraft:light_gray_concrete
fill ~51 ~-42 ~38 ~62 ~-42 ~38 minecraft:air
setblock ~63 ~-42 ~38 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~38 minecraft:light_gray_concrete
setblock ~4 ~-42 ~39 minecraft:light_gray_concrete
fill ~5 ~-42 ~39 ~17 ~-42 ~39 minecraft:air
setblock ~18 ~-42 ~39 minecraft:light_gray_concrete
fill ~19 ~-42 ~39 ~21 ~-42 ~39 minecraft:air
setblock ~22 ~-42 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-42 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-42 ~39 ~44 ~-42 ~39 minecraft:air
fill ~45 ~-42 ~39 ~46 ~-42 ~39 minecraft:quartz_pillar
fill ~47 ~-42 ~39 ~49 ~-42 ~39 minecraft:air
setblock ~50 ~-42 ~39 minecraft:light_gray_concrete
fill ~51 ~-42 ~39 ~62 ~-42 ~39 minecraft:air
setblock ~63 ~-42 ~39 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~39 minecraft:light_gray_concrete
setblock ~4 ~-42 ~40 minecraft:light_gray_concrete
fill ~5 ~-42 ~40 ~17 ~-42 ~40 minecraft:air
setblock ~18 ~-42 ~40 minecraft:light_gray_concrete
fill ~19 ~-42 ~40 ~22 ~-42 ~40 minecraft:air
setblock ~23 ~-42 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-42 ~40 ~44 ~-42 ~40 minecraft:air
setblock ~45 ~-42 ~40 minecraft:glass_pane[north=true,south=true]
fill ~46 ~-42 ~40 ~49 ~-42 ~40 minecraft:air
setblock ~50 ~-42 ~40 minecraft:light_gray_concrete
fill ~51 ~-42 ~40 ~62 ~-42 ~40 minecraft:air
setblock ~63 ~-42 ~40 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~40 minecraft:light_gray_concrete
setblock ~4 ~-42 ~41 minecraft:light_gray_concrete
fill ~5 ~-42 ~41 ~17 ~-42 ~41 minecraft:air
setblock ~18 ~-42 ~41 minecraft:light_gray_concrete
fill ~19 ~-42 ~41 ~23 ~-42 ~41 minecraft:air
setblock ~24 ~-42 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-42 ~41 ~43 ~-42 ~41 minecraft:air
setblock ~44 ~-42 ~41 minecraft:glass_pane[east=true,south=true]
fill ~45 ~-42 ~41 ~46 ~-42 ~41 minecraft:observer[facing=north]
setblock ~47 ~-42 ~41 minecraft:air
setblock ~48 ~-42 ~41 minecraft:observer[facing=north]
setblock ~49 ~-42 ~41 minecraft:air
setblock ~50 ~-42 ~41 minecraft:light_gray_concrete
fill ~51 ~-42 ~41 ~62 ~-42 ~41 minecraft:air
setblock ~63 ~-42 ~41 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~41 minecraft:light_gray_concrete
setblock ~4 ~-42 ~42 minecraft:light_gray_concrete
setblock ~5 ~-42 ~42 minecraft:black_concrete
fill ~6 ~-42 ~42 ~17 ~-42 ~42 minecraft:air
setblock ~18 ~-42 ~42 minecraft:light_gray_concrete
fill ~19 ~-42 ~42 ~23 ~-42 ~42 minecraft:air
setblock ~24 ~-42 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-42 ~42 minecraft:quartz_pillar
fill ~26 ~-42 ~42 ~42 ~-42 ~42 minecraft:air
setblock ~43 ~-42 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-42 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-42 ~42 ~49 ~-42 ~42 minecraft:air
setblock ~50 ~-42 ~42 minecraft:light_gray_concrete
fill ~51 ~-42 ~42 ~62 ~-42 ~42 minecraft:air
setblock ~63 ~-42 ~42 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~42 minecraft:light_gray_concrete
setblock ~4 ~-42 ~43 minecraft:light_gray_concrete
setblock ~5 ~-42 ~43 minecraft:black_concrete
fill ~6 ~-42 ~43 ~17 ~-42 ~43 minecraft:air
setblock ~18 ~-42 ~43 minecraft:light_gray_concrete
fill ~19 ~-42 ~43 ~24 ~-42 ~43 minecraft:air
setblock ~25 ~-42 ~43 minecraft:quartz_pillar
setblock ~26 ~-42 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-42 ~43 ~41 ~-42 ~43 minecraft:air
fill ~42 ~-42 ~43 ~43 ~-42 ~43 minecraft:quartz_pillar
fill ~44 ~-42 ~43 ~49 ~-42 ~43 minecraft:air
setblock ~50 ~-42 ~43 minecraft:light_gray_concrete
fill ~51 ~-42 ~43 ~59 ~-42 ~43 minecraft:air
setblock ~60 ~-42 ~43 minecraft:black_concrete
fill ~61 ~-42 ~43 ~62 ~-42 ~43 minecraft:air
setblock ~63 ~-42 ~43 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~43 minecraft:light_gray_concrete
setblock ~4 ~-42 ~44 minecraft:light_gray_concrete
setblock ~5 ~-42 ~44 minecraft:black_concrete
fill ~6 ~-42 ~44 ~17 ~-42 ~44 minecraft:air
setblock ~18 ~-42 ~44 minecraft:light_gray_concrete
fill ~19 ~-42 ~44 ~25 ~-42 ~44 minecraft:air
setblock ~26 ~-42 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-42 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-42 ~44 ~29 ~-42 ~44 minecraft:air
setblock ~30 ~-42 ~44 minecraft:quartz_pillar
fill ~31 ~-42 ~44 ~37 ~-42 ~44 minecraft:air
setblock ~38 ~-42 ~44 minecraft:quartz_pillar
fill ~39 ~-42 ~44 ~40 ~-42 ~44 minecraft:air
setblock ~41 ~-42 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-42 ~44 minecraft:glass_pane[north=true,west=true]
setblock ~43 ~-42 ~44 minecraft:air
fill ~44 ~-42 ~44 ~46 ~-42 ~44 minecraft:observer[facing=south]
setblock ~47 ~-42 ~44 minecraft:air
setblock ~48 ~-42 ~44 minecraft:observer[facing=south]
setblock ~49 ~-42 ~44 minecraft:air
setblock ~50 ~-42 ~44 minecraft:light_gray_concrete
fill ~51 ~-42 ~44 ~62 ~-42 ~44 minecraft:air
setblock ~63 ~-42 ~44 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~44 minecraft:light_gray_concrete
setblock ~4 ~-42 ~45 minecraft:light_gray_concrete
fill ~5 ~-42 ~45 ~17 ~-42 ~45 minecraft:air
setblock ~18 ~-42 ~45 minecraft:light_gray_concrete
fill ~19 ~-42 ~45 ~28 ~-42 ~45 minecraft:air
setblock ~29 ~-42 ~45 minecraft:quartz_pillar
fill ~30 ~-42 ~45 ~38 ~-42 ~45 minecraft:air
setblock ~39 ~-42 ~45 minecraft:glass_pane[east=true,south=true]
fill ~40 ~-42 ~45 ~49 ~-42 ~45 minecraft:air
setblock ~50 ~-42 ~45 minecraft:light_gray_concrete
fill ~51 ~-42 ~45 ~62 ~-42 ~45 minecraft:air
setblock ~63 ~-42 ~45 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~45 minecraft:light_gray_concrete
setblock ~4 ~-42 ~46 minecraft:light_gray_concrete
fill ~5 ~-42 ~46 ~17 ~-42 ~46 minecraft:air
setblock ~18 ~-42 ~46 minecraft:light_gray_concrete
setblock ~19 ~-42 ~46 minecraft:air
fill ~20 ~-42 ~46 ~22 ~-42 ~46 minecraft:black_concrete
setblock ~23 ~-42 ~46 minecraft:air
fill ~24 ~-42 ~46 ~25 ~-42 ~46 minecraft:black_concrete
fill ~26 ~-42 ~46 ~28 ~-42 ~46 minecraft:air
setblock ~29 ~-42 ~46 minecraft:quartz_pillar
fill ~30 ~-42 ~46 ~31 ~-42 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-42 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-42 ~46 ~35 ~-42 ~46 minecraft:air
setblock ~36 ~-42 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-42 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-42 ~46 minecraft:quartz_pillar
setblock ~39 ~-42 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-42 ~46 ~49 ~-42 ~46 minecraft:air
setblock ~50 ~-42 ~46 minecraft:light_gray_concrete
fill ~51 ~-42 ~46 ~62 ~-42 ~46 minecraft:air
setblock ~63 ~-42 ~46 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~46 minecraft:light_gray_concrete
setblock ~4 ~-42 ~47 minecraft:light_gray_concrete
fill ~5 ~-42 ~47 ~17 ~-42 ~47 minecraft:air
setblock ~18 ~-42 ~47 minecraft:light_gray_concrete
fill ~19 ~-42 ~47 ~31 ~-42 ~47 minecraft:air
setblock ~32 ~-42 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~47 ~35 ~-42 ~47 minecraft:air
setblock ~36 ~-42 ~47 minecraft:glass_pane[north=true,south=true]
setblock ~37 ~-42 ~47 minecraft:air
setblock ~38 ~-42 ~47 minecraft:observer[facing=north]
fill ~39 ~-42 ~47 ~40 ~-42 ~47 minecraft:air
fill ~41 ~-42 ~47 ~42 ~-42 ~47 minecraft:observer[facing=north]
setblock ~43 ~-42 ~47 minecraft:air
fill ~44 ~-42 ~47 ~46 ~-42 ~47 minecraft:observer[facing=north]
setblock ~47 ~-42 ~47 minecraft:air
setblock ~48 ~-42 ~47 minecraft:observer[facing=north]
setblock ~49 ~-42 ~47 minecraft:air
setblock ~50 ~-42 ~47 minecraft:light_gray_concrete
fill ~51 ~-42 ~47 ~62 ~-42 ~47 minecraft:air
setblock ~63 ~-42 ~47 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~47 minecraft:light_gray_concrete
setblock ~4 ~-42 ~48 minecraft:light_gray_concrete
fill ~5 ~-42 ~48 ~17 ~-42 ~48 minecraft:air
setblock ~18 ~-42 ~48 minecraft:light_gray_concrete
fill ~19 ~-42 ~48 ~49 ~-42 ~48 minecraft:air
setblock ~50 ~-42 ~48 minecraft:light_gray_concrete
fill ~51 ~-42 ~48 ~62 ~-42 ~48 minecraft:air
setblock ~63 ~-42 ~48 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~48 minecraft:light_gray_concrete
setblock ~4 ~-42 ~49 minecraft:light_gray_concrete
fill ~5 ~-42 ~49 ~17 ~-42 ~49 minecraft:air
setblock ~18 ~-42 ~49 minecraft:light_gray_concrete
fill ~19 ~-42 ~49 ~30 ~-42 ~49 minecraft:black_concrete
setblock ~31 ~-42 ~49 minecraft:air
setblock ~32 ~-42 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-42 ~49 ~35 ~-42 ~49 minecraft:air
setblock ~36 ~-42 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-42 ~49 ~49 ~-42 ~49 minecraft:air
setblock ~50 ~-42 ~49 minecraft:light_gray_concrete
fill ~51 ~-42 ~49 ~62 ~-42 ~49 minecraft:air
setblock ~63 ~-42 ~49 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-42 ~49 minecraft:light_gray_concrete
fill ~4 ~-42 ~50 ~10 ~-42 ~50 minecraft:light_gray_concrete
setblock ~11 ~-42 ~50 minecraft:air
fill ~12 ~-42 ~50 ~31 ~-42 ~50 minecraft:light_gray_concrete
setblock ~32 ~-42 ~50 minecraft:red_concrete
fill ~33 ~-42 ~50 ~35 ~-42 ~50 minecraft:air
setblock ~36 ~-42 ~50 minecraft:red_concrete
fill ~37 ~-42 ~50 ~56 ~-42 ~50 minecraft:light_gray_concrete
setblock ~57 ~-42 ~50 minecraft:air
fill ~58 ~-42 ~50 ~64 ~-42 ~50 minecraft:light_gray_concrete
setblock ~4 ~-42 ~51 minecraft:light_gray_concrete
fill ~5 ~-42 ~51 ~17 ~-42 ~51 minecraft:air
setblock ~18 ~-42 ~51 minecraft:light_gray_concrete
setblock ~19 ~-42 ~51 minecraft:waxed_cut_copper
setblock ~20 ~-42 ~51 minecraft:redstone_lamp[lit=true]
setblock ~21 ~-42 ~51 minecraft:blast_furnace[facing=south]
setblock ~22 ~-42 ~51 minecraft:waxed_cut_copper
setblock ~23 ~-42 ~51 minecraft:redstone_lamp[lit=true]
setblock ~24 ~-42 ~51 minecraft:blast_furnace[facing=south]
setblock ~25 ~-42 ~51 minecraft:waxed_cut_copper
setblock ~26 ~-42 ~51 minecraft:redstone_lamp[lit=true]
setblock ~27 ~-42 ~51 minecraft:blast_furnace[facing=south]
setblock ~28 ~-42 ~51 minecraft:waxed_cut_copper
setblock ~29 ~-42 ~51 minecraft:redstone_lamp[lit=true]
setblock ~30 ~-42 ~51 minecraft:blast_furnace[facing=south]
setblock ~31 ~-42 ~51 minecraft:waxed_cut_copper
setblock ~32 ~-42 ~51 minecraft:red_concrete
fill ~33 ~-42 ~51 ~35 ~-42 ~51 minecraft:air
setblock ~36 ~-42 ~51 minecraft:red_concrete
fill ~37 ~-42 ~51 ~49 ~-42 ~51 minecraft:air
setblock ~50 ~-42 ~51 minecraft:light_gray_concrete
fill ~51 ~-42 ~51 ~63 ~-42 ~51 minecraft:air
setblock ~64 ~-42 ~51 minecraft:light_gray_concrete
setblock ~4 ~-42 ~52 minecraft:light_gray_concrete
setblock ~5 ~-42 ~52 minecraft:air
setblock ~6 ~-42 ~52 minecraft:observer[facing=south]
setblock ~7 ~-42 ~52 minecraft:air
fill ~8 ~-42 ~52 ~10 ~-42 ~52 minecraft:observer[facing=south]
setblock ~11 ~-42 ~52 minecraft:air
fill ~12 ~-42 ~52 ~14 ~-42 ~52 minecraft:observer[facing=south]
setblock ~15 ~-42 ~52 minecraft:air
setblock ~16 ~-42 ~52 minecraft:observer[facing=south]
setblock ~17 ~-42 ~52 minecraft:air
setblock ~18 ~-42 ~52 minecraft:light_gray_concrete
setblock ~19 ~-42 ~52 minecraft:redstone_lamp[lit=true]
fill ~20 ~-42 ~52 ~30 ~-42 ~52 minecraft:air
setblock ~31 ~-42 ~52 minecraft:redstone_lamp[lit=true]
setblock ~32 ~-42 ~52 minecraft:red_concrete
fill ~33 ~-42 ~52 ~35 ~-42 ~52 minecraft:air
setblock ~36 ~-42 ~52 minecraft:red_concrete
fill ~37 ~-42 ~52 ~49 ~-42 ~52 minecraft:air
setblock ~50 ~-42 ~52 minecraft:light_gray_concrete
setblock ~51 ~-42 ~52 minecraft:air
fill ~52 ~-42 ~52 ~55 ~-42 ~52 minecraft:barrel
fill ~56 ~-42 ~52 ~57 ~-42 ~52 minecraft:air
fill ~58 ~-42 ~52 ~60 ~-42 ~52 minecraft:barrel
setblock ~61 ~-42 ~52 minecraft:air
setblock ~62 ~-42 ~52 minecraft:barrel
setblock ~63 ~-42 ~52 minecraft:air
setblock ~64 ~-42 ~52 minecraft:light_gray_concrete
setblock ~4 ~-42 ~53 minecraft:light_gray_concrete
fill ~5 ~-42 ~53 ~17 ~-42 ~53 minecraft:air
setblock ~18 ~-42 ~53 minecraft:light_gray_concrete
setblock ~19 ~-42 ~53 minecraft:blast_furnace[facing=east]
fill ~20 ~-42 ~53 ~30 ~-42 ~53 minecraft:air
setblock ~31 ~-42 ~53 minecraft:blast_furnace[facing=west]
setblock ~32 ~-42 ~53 minecraft:red_concrete
fill ~33 ~-42 ~53 ~35 ~-42 ~53 minecraft:air
setblock ~36 ~-42 ~53 minecraft:red_concrete
fill ~37 ~-42 ~53 ~49 ~-42 ~53 minecraft:air
setblock ~50 ~-42 ~53 minecraft:light_gray_concrete
fill ~51 ~-42 ~53 ~63 ~-42 ~53 minecraft:air
setblock ~64 ~-42 ~53 minecraft:light_gray_concrete
setblock ~4 ~-42 ~54 minecraft:light_gray_concrete
fill ~5 ~-42 ~54 ~17 ~-42 ~54 minecraft:air
setblock ~18 ~-42 ~54 minecraft:light_gray_concrete
setblock ~19 ~-42 ~54 minecraft:waxed_cut_copper
fill ~20 ~-42 ~54 ~21 ~-42 ~54 minecraft:air
setblock ~22 ~-42 ~54 minecraft:waxed_cut_copper
fill ~23 ~-42 ~54 ~25 ~-42 ~54 minecraft:air
setblock ~26 ~-42 ~54 minecraft:waxed_cut_copper
fill ~27 ~-42 ~54 ~30 ~-42 ~54 minecraft:air
setblock ~31 ~-42 ~54 minecraft:waxed_cut_copper
setblock ~32 ~-42 ~54 minecraft:red_concrete
fill ~33 ~-42 ~54 ~35 ~-42 ~54 minecraft:air
setblock ~36 ~-42 ~54 minecraft:red_concrete
fill ~37 ~-42 ~54 ~49 ~-42 ~54 minecraft:air
setblock ~50 ~-42 ~54 minecraft:light_gray_concrete
fill ~51 ~-42 ~54 ~63 ~-42 ~54 minecraft:air
setblock ~64 ~-42 ~54 minecraft:light_gray_concrete
setblock ~4 ~-42 ~55 minecraft:light_gray_concrete
setblock ~5 ~-42 ~55 minecraft:air
setblock ~6 ~-42 ~55 minecraft:observer[facing=north]
setblock ~7 ~-42 ~55 minecraft:air
fill ~8 ~-42 ~55 ~10 ~-42 ~55 minecraft:observer[facing=north]
setblock ~11 ~-42 ~55 minecraft:air
fill ~12 ~-42 ~55 ~14 ~-42 ~55 minecraft:observer[facing=north]
setblock ~15 ~-42 ~55 minecraft:air
setblock ~16 ~-42 ~55 minecraft:observer[facing=north]
setblock ~17 ~-42 ~55 minecraft:air
setblock ~18 ~-42 ~55 minecraft:light_gray_concrete
setblock ~19 ~-42 ~55 minecraft:redstone_lamp[lit=true]
fill ~20 ~-42 ~55 ~30 ~-42 ~55 minecraft:air
setblock ~31 ~-42 ~55 minecraft:redstone_lamp[lit=true]
setblock ~32 ~-42 ~55 minecraft:red_concrete
fill ~33 ~-42 ~55 ~35 ~-42 ~55 minecraft:air
setblock ~36 ~-42 ~55 minecraft:red_concrete
fill ~37 ~-42 ~55 ~49 ~-42 ~55 minecraft:air
setblock ~50 ~-42 ~55 minecraft:light_gray_concrete
setblock ~51 ~-42 ~55 minecraft:air
fill ~52 ~-42 ~55 ~55 ~-42 ~55 minecraft:barrel
setblock ~56 ~-42 ~55 minecraft:air
fill ~57 ~-42 ~55 ~60 ~-42 ~55 minecraft:barrel
setblock ~61 ~-42 ~55 minecraft:air
setblock ~62 ~-42 ~55 minecraft:barrel
setblock ~63 ~-42 ~55 minecraft:air
setblock ~64 ~-42 ~55 minecraft:light_gray_concrete
setblock ~4 ~-42 ~56 minecraft:light_gray_concrete
fill ~5 ~-42 ~56 ~17 ~-42 ~56 minecraft:air
setblock ~18 ~-42 ~56 minecraft:light_gray_concrete
fill ~19 ~-42 ~56 ~31 ~-42 ~56 minecraft:air
setblock ~32 ~-42 ~56 minecraft:red_concrete
fill ~33 ~-42 ~56 ~35 ~-42 ~56 minecraft:air
setblock ~36 ~-42 ~56 minecraft:red_concrete
fill ~37 ~-42 ~56 ~49 ~-42 ~56 minecraft:air
setblock ~50 ~-42 ~56 minecraft:light_gray_concrete
fill ~51 ~-42 ~56 ~63 ~-42 ~56 minecraft:air
setblock ~64 ~-42 ~56 minecraft:light_gray_concrete
setblock ~4 ~-42 ~57 minecraft:light_gray_concrete
fill ~5 ~-42 ~57 ~63 ~-42 ~57 minecraft:air
setblock ~64 ~-42 ~57 minecraft:light_gray_concrete
setblock ~4 ~-42 ~58 minecraft:light_gray_concrete
setblock ~5 ~-42 ~58 minecraft:air
setblock ~6 ~-42 ~58 minecraft:observer[facing=south]
setblock ~7 ~-42 ~58 minecraft:air
fill ~8 ~-42 ~58 ~10 ~-42 ~58 minecraft:observer[facing=south]
setblock ~11 ~-42 ~58 minecraft:air
fill ~12 ~-42 ~58 ~14 ~-42 ~58 minecraft:observer[facing=south]
setblock ~15 ~-42 ~58 minecraft:air
setblock ~16 ~-42 ~58 minecraft:observer[facing=south]
setblock ~17 ~-42 ~58 minecraft:air
setblock ~18 ~-42 ~58 minecraft:light_gray_concrete
fill ~19 ~-42 ~58 ~21 ~-42 ~58 minecraft:air
setblock ~22 ~-42 ~58 minecraft:waxed_cut_copper
fill ~23 ~-42 ~58 ~25 ~-42 ~58 minecraft:air
setblock ~26 ~-42 ~58 minecraft:waxed_cut_copper
fill ~27 ~-42 ~58 ~31 ~-42 ~58 minecraft:air
setblock ~32 ~-42 ~58 minecraft:red_concrete
fill ~33 ~-42 ~58 ~35 ~-42 ~58 minecraft:air
setblock ~36 ~-42 ~58 minecraft:red_concrete
fill ~37 ~-42 ~58 ~49 ~-42 ~58 minecraft:air
setblock ~50 ~-42 ~58 minecraft:light_gray_concrete
setblock ~51 ~-42 ~58 minecraft:air
fill ~52 ~-42 ~58 ~55 ~-42 ~58 minecraft:barrel
setblock ~56 ~-42 ~58 minecraft:air
fill ~57 ~-42 ~58 ~60 ~-42 ~58 minecraft:barrel
setblock ~61 ~-42 ~58 minecraft:air
setblock ~62 ~-42 ~58 minecraft:barrel
setblock ~63 ~-42 ~58 minecraft:air
setblock ~64 ~-42 ~58 minecraft:light_gray_concrete
setblock ~4 ~-42 ~59 minecraft:light_gray_concrete
fill ~5 ~-42 ~59 ~17 ~-42 ~59 minecraft:air
setblock ~18 ~-42 ~59 minecraft:light_gray_concrete
setblock ~19 ~-42 ~59 minecraft:blast_furnace[facing=east]
fill ~20 ~-42 ~59 ~30 ~-42 ~59 minecraft:air
setblock ~31 ~-42 ~59 minecraft:blast_furnace[facing=west]
setblock ~32 ~-42 ~59 minecraft:red_concrete
fill ~33 ~-42 ~59 ~35 ~-42 ~59 minecraft:air
setblock ~36 ~-42 ~59 minecraft:red_concrete
fill ~37 ~-42 ~59 ~49 ~-42 ~59 minecraft:air
setblock ~50 ~-42 ~59 minecraft:light_gray_concrete
fill ~51 ~-42 ~59 ~63 ~-42 ~59 minecraft:air
setblock ~64 ~-42 ~59 minecraft:light_gray_concrete
setblock ~4 ~-42 ~60 minecraft:light_gray_concrete
fill ~5 ~-42 ~60 ~17 ~-42 ~60 minecraft:air
setblock ~18 ~-42 ~60 minecraft:light_gray_concrete
setblock ~19 ~-42 ~60 minecraft:waxed_cut_copper
fill ~20 ~-42 ~60 ~30 ~-42 ~60 minecraft:air
setblock ~31 ~-42 ~60 minecraft:waxed_cut_copper
setblock ~32 ~-42 ~60 minecraft:red_concrete
fill ~33 ~-42 ~60 ~35 ~-42 ~60 minecraft:air
setblock ~36 ~-42 ~60 minecraft:red_concrete
fill ~37 ~-42 ~60 ~49 ~-42 ~60 minecraft:air
setblock ~50 ~-42 ~60 minecraft:light_gray_concrete
fill ~51 ~-42 ~60 ~63 ~-42 ~60 minecraft:air
setblock ~64 ~-42 ~60 minecraft:light_gray_concrete
setblock ~4 ~-42 ~61 minecraft:light_gray_concrete
setblock ~5 ~-42 ~61 minecraft:air
setblock ~6 ~-42 ~61 minecraft:observer[facing=north]
setblock ~7 ~-42 ~61 minecraft:air
fill ~8 ~-42 ~61 ~10 ~-42 ~61 minecraft:observer[facing=north]
setblock ~11 ~-42 ~61 minecraft:air
fill ~12 ~-42 ~61 ~14 ~-42 ~61 minecraft:observer[facing=north]
setblock ~15 ~-42 ~61 minecraft:air
setblock ~16 ~-42 ~61 minecraft:observer[facing=north]
setblock ~17 ~-42 ~61 minecraft:air
setblock ~18 ~-42 ~61 minecraft:light_gray_concrete
setblock ~19 ~-42 ~61 minecraft:redstone_lamp[lit=true]
fill ~20 ~-42 ~61 ~30 ~-42 ~61 minecraft:air
setblock ~31 ~-42 ~61 minecraft:redstone_lamp[lit=true]
setblock ~32 ~-42 ~61 minecraft:red_concrete
fill ~33 ~-42 ~61 ~35 ~-42 ~61 minecraft:air
setblock ~36 ~-42 ~61 minecraft:red_concrete
fill ~37 ~-42 ~61 ~49 ~-42 ~61 minecraft:air
setblock ~50 ~-42 ~61 minecraft:light_gray_concrete
setblock ~51 ~-42 ~61 minecraft:air
fill ~52 ~-42 ~61 ~55 ~-42 ~61 minecraft:barrel
setblock ~56 ~-42 ~61 minecraft:air
fill ~57 ~-42 ~61 ~60 ~-42 ~61 minecraft:barrel
setblock ~61 ~-42 ~61 minecraft:air
setblock ~62 ~-42 ~61 minecraft:barrel
setblock ~63 ~-42 ~61 minecraft:air
setblock ~64 ~-42 ~61 minecraft:light_gray_concrete
setblock ~4 ~-42 ~62 minecraft:light_gray_concrete
fill ~5 ~-42 ~62 ~17 ~-42 ~62 minecraft:air
setblock ~18 ~-42 ~62 minecraft:light_gray_concrete
setblock ~19 ~-42 ~62 minecraft:blast_furnace[facing=east]
fill ~20 ~-42 ~62 ~30 ~-42 ~62 minecraft:air
setblock ~31 ~-42 ~62 minecraft:blast_furnace[facing=west]
setblock ~32 ~-42 ~62 minecraft:red_concrete
fill ~33 ~-42 ~62 ~35 ~-42 ~62 minecraft:air
setblock ~36 ~-42 ~62 minecraft:red_concrete
fill ~37 ~-42 ~62 ~49 ~-42 ~62 minecraft:air
setblock ~50 ~-42 ~62 minecraft:light_gray_concrete
fill ~51 ~-42 ~62 ~63 ~-42 ~62 minecraft:air
setblock ~64 ~-42 ~62 minecraft:light_gray_concrete
setblock ~4 ~-42 ~63 minecraft:light_gray_concrete
fill ~5 ~-42 ~63 ~17 ~-42 ~63 minecraft:air
setblock ~18 ~-42 ~63 minecraft:light_gray_concrete
setblock ~19 ~-42 ~63 minecraft:waxed_cut_copper
setblock ~20 ~-42 ~63 minecraft:redstone_lamp[lit=true]
setblock ~21 ~-42 ~63 minecraft:blast_furnace[facing=north]
setblock ~22 ~-42 ~63 minecraft:waxed_cut_copper
setblock ~23 ~-42 ~63 minecraft:redstone_lamp[lit=true]
setblock ~24 ~-42 ~63 minecraft:blast_furnace[facing=north]
setblock ~25 ~-42 ~63 minecraft:waxed_cut_copper
setblock ~26 ~-42 ~63 minecraft:redstone_lamp[lit=true]
setblock ~27 ~-42 ~63 minecraft:blast_furnace[facing=north]
setblock ~28 ~-42 ~63 minecraft:waxed_cut_copper
setblock ~29 ~-42 ~63 minecraft:redstone_lamp[lit=true]
setblock ~30 ~-42 ~63 minecraft:blast_furnace[facing=north]
setblock ~31 ~-42 ~63 minecraft:waxed_cut_copper
setblock ~32 ~-42 ~63 minecraft:red_concrete
fill ~33 ~-42 ~63 ~35 ~-42 ~63 minecraft:air
setblock ~36 ~-42 ~63 minecraft:red_concrete
fill ~37 ~-42 ~63 ~49 ~-42 ~63 minecraft:air
setblock ~50 ~-42 ~63 minecraft:light_gray_concrete
fill ~51 ~-42 ~63 ~63 ~-42 ~63 minecraft:air
setblock ~64 ~-42 ~63 minecraft:light_gray_concrete
fill ~4 ~-42 ~64 ~33 ~-42 ~64 minecraft:light_gray_concrete
setblock ~34 ~-42 ~64 minecraft:air
fill ~35 ~-42 ~64 ~64 ~-42 ~64 minecraft:light_gray_concrete
setblock ~33 ~-42 ~65 minecraft:light_gray_concrete
setblock ~34 ~-42 ~65 minecraft:air
setblock ~35 ~-42 ~65 minecraft:light_gray_concrete
fill ~32 ~-42 ~66 ~33 ~-42 ~66 minecraft:polished_andesite
setblock ~34 ~-42 ~66 minecraft:air
fill ~35 ~-42 ~66 ~36 ~-42 ~66 minecraft:polished_andesite
setblock ~32 ~-42 ~67 minecraft:polished_andesite
fill ~33 ~-42 ~67 ~35 ~-42 ~67 minecraft:air
setblock ~36 ~-42 ~67 minecraft:polished_andesite
setblock ~32 ~-42 ~68 minecraft:polished_andesite
setblock ~33 ~-42 ~68 minecraft:air
setblock ~34 ~-42 ~68 minecraft:quartz_pillar
setblock ~35 ~-42 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-42 ~68 minecraft:polished_andesite
setblock ~32 ~-42 ~69 minecraft:polished_andesite
fill ~33 ~-42 ~69 ~35 ~-42 ~69 minecraft:air
setblock ~36 ~-42 ~69 minecraft:polished_andesite
fill ~32 ~-42 ~70 ~36 ~-42 ~70 minecraft:polished_andesite
fill ~4 ~-41 ~4 ~64 ~-41 ~4 minecraft:light_gray_concrete
setblock ~4 ~-41 ~5 minecraft:light_gray_concrete
fill ~5 ~-41 ~5 ~17 ~-41 ~5 minecraft:air
setblock ~18 ~-41 ~5 minecraft:light_gray_concrete
fill ~19 ~-41 ~5 ~31 ~-41 ~5 minecraft:air
setblock ~32 ~-41 ~5 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~5 ~35 ~-41 ~5 minecraft:air
setblock ~36 ~-41 ~5 minecraft:light_gray_concrete
setblock ~37 ~-41 ~5 minecraft:air
setblock ~38 ~-41 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~5 ~41 ~-41 ~5 minecraft:air
setblock ~42 ~-41 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~5 ~45 ~-41 ~5 minecraft:air
setblock ~46 ~-41 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~5 ~49 ~-41 ~5 minecraft:air
setblock ~50 ~-41 ~5 minecraft:light_gray_concrete
fill ~51 ~-41 ~5 ~63 ~-41 ~5 minecraft:iron_block
setblock ~64 ~-41 ~5 minecraft:light_gray_concrete
setblock ~4 ~-41 ~6 minecraft:light_gray_concrete
fill ~5 ~-41 ~6 ~17 ~-41 ~6 minecraft:air
setblock ~18 ~-41 ~6 minecraft:light_gray_concrete
fill ~19 ~-41 ~6 ~31 ~-41 ~6 minecraft:air
setblock ~32 ~-41 ~6 minecraft:light_gray_concrete
fill ~33 ~-41 ~6 ~35 ~-41 ~6 minecraft:air
setblock ~36 ~-41 ~6 minecraft:light_gray_concrete
setblock ~37 ~-41 ~6 minecraft:air
setblock ~38 ~-41 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~6 ~41 ~-41 ~6 minecraft:air
setblock ~42 ~-41 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~6 ~45 ~-41 ~6 minecraft:air
setblock ~46 ~-41 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~6 ~49 ~-41 ~6 minecraft:air
setblock ~50 ~-41 ~6 minecraft:light_gray_concrete
setblock ~51 ~-41 ~6 minecraft:iron_block
fill ~52 ~-41 ~6 ~62 ~-41 ~6 minecraft:air
setblock ~63 ~-41 ~6 minecraft:iron_block
setblock ~64 ~-41 ~6 minecraft:light_gray_concrete
setblock ~4 ~-41 ~7 minecraft:light_gray_concrete
setblock ~5 ~-41 ~7 minecraft:air
setblock ~6 ~-41 ~7 minecraft:observer[facing=south]
setblock ~7 ~-41 ~7 minecraft:air
fill ~8 ~-41 ~7 ~10 ~-41 ~7 minecraft:observer[facing=south]
setblock ~11 ~-41 ~7 minecraft:air
fill ~12 ~-41 ~7 ~14 ~-41 ~7 minecraft:observer[facing=south]
setblock ~15 ~-41 ~7 minecraft:air
setblock ~16 ~-41 ~7 minecraft:observer[facing=south]
setblock ~17 ~-41 ~7 minecraft:air
setblock ~18 ~-41 ~7 minecraft:light_gray_concrete
setblock ~19 ~-41 ~7 minecraft:air
setblock ~20 ~-41 ~7 minecraft:observer[facing=south]
setblock ~21 ~-41 ~7 minecraft:air
fill ~22 ~-41 ~7 ~24 ~-41 ~7 minecraft:observer[facing=south]
setblock ~25 ~-41 ~7 minecraft:air
fill ~26 ~-41 ~7 ~28 ~-41 ~7 minecraft:observer[facing=south]
setblock ~29 ~-41 ~7 minecraft:air
setblock ~30 ~-41 ~7 minecraft:observer[facing=south]
setblock ~31 ~-41 ~7 minecraft:air
setblock ~32 ~-41 ~7 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~7 ~35 ~-41 ~7 minecraft:air
setblock ~36 ~-41 ~7 minecraft:light_gray_concrete
setblock ~37 ~-41 ~7 minecraft:air
setblock ~38 ~-41 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~7 ~41 ~-41 ~7 minecraft:air
setblock ~42 ~-41 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~7 ~45 ~-41 ~7 minecraft:air
setblock ~46 ~-41 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~7 ~49 ~-41 ~7 minecraft:air
setblock ~50 ~-41 ~7 minecraft:light_gray_concrete
setblock ~51 ~-41 ~7 minecraft:iron_block
fill ~52 ~-41 ~7 ~62 ~-41 ~7 minecraft:air
setblock ~63 ~-41 ~7 minecraft:iron_block
setblock ~64 ~-41 ~7 minecraft:light_gray_concrete
setblock ~4 ~-41 ~8 minecraft:light_gray_concrete
fill ~5 ~-41 ~8 ~17 ~-41 ~8 minecraft:air
setblock ~18 ~-41 ~8 minecraft:light_gray_concrete
fill ~19 ~-41 ~8 ~31 ~-41 ~8 minecraft:air
setblock ~32 ~-41 ~8 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~8 ~35 ~-41 ~8 minecraft:air
setblock ~36 ~-41 ~8 minecraft:light_gray_concrete
setblock ~37 ~-41 ~8 minecraft:air
setblock ~38 ~-41 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~8 ~41 ~-41 ~8 minecraft:air
setblock ~42 ~-41 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~8 ~45 ~-41 ~8 minecraft:air
setblock ~46 ~-41 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~8 ~49 ~-41 ~8 minecraft:air
setblock ~50 ~-41 ~8 minecraft:light_gray_concrete
setblock ~51 ~-41 ~8 minecraft:iron_block
fill ~52 ~-41 ~8 ~62 ~-41 ~8 minecraft:air
setblock ~63 ~-41 ~8 minecraft:iron_block
setblock ~64 ~-41 ~8 minecraft:light_gray_concrete
setblock ~4 ~-41 ~9 minecraft:light_gray_concrete
fill ~5 ~-41 ~9 ~17 ~-41 ~9 minecraft:air
setblock ~18 ~-41 ~9 minecraft:light_gray_concrete
fill ~19 ~-41 ~9 ~31 ~-41 ~9 minecraft:air
setblock ~32 ~-41 ~9 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~9 ~35 ~-41 ~9 minecraft:air
setblock ~36 ~-41 ~9 minecraft:light_gray_concrete
setblock ~37 ~-41 ~9 minecraft:air
setblock ~38 ~-41 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~9 ~41 ~-41 ~9 minecraft:air
setblock ~42 ~-41 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~9 ~45 ~-41 ~9 minecraft:air
setblock ~46 ~-41 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~9 ~49 ~-41 ~9 minecraft:air
setblock ~50 ~-41 ~9 minecraft:light_gray_concrete
setblock ~51 ~-41 ~9 minecraft:iron_block
fill ~52 ~-41 ~9 ~62 ~-41 ~9 minecraft:air
setblock ~63 ~-41 ~9 minecraft:iron_block
setblock ~64 ~-41 ~9 minecraft:light_gray_concrete
setblock ~4 ~-41 ~10 minecraft:light_gray_concrete
setblock ~5 ~-41 ~10 minecraft:air
setblock ~6 ~-41 ~10 minecraft:observer[facing=north]
setblock ~7 ~-41 ~10 minecraft:air
fill ~8 ~-41 ~10 ~10 ~-41 ~10 minecraft:observer[facing=north]
setblock ~11 ~-41 ~10 minecraft:air
fill ~12 ~-41 ~10 ~14 ~-41 ~10 minecraft:observer[facing=north]
setblock ~15 ~-41 ~10 minecraft:air
setblock ~16 ~-41 ~10 minecraft:observer[facing=north]
setblock ~17 ~-41 ~10 minecraft:air
setblock ~18 ~-41 ~10 minecraft:light_gray_concrete
setblock ~19 ~-41 ~10 minecraft:air
setblock ~20 ~-41 ~10 minecraft:observer[facing=north]
setblock ~21 ~-41 ~10 minecraft:air
fill ~22 ~-41 ~10 ~24 ~-41 ~10 minecraft:observer[facing=north]
setblock ~25 ~-41 ~10 minecraft:air
fill ~26 ~-41 ~10 ~28 ~-41 ~10 minecraft:observer[facing=north]
setblock ~29 ~-41 ~10 minecraft:air
setblock ~30 ~-41 ~10 minecraft:observer[facing=north]
setblock ~31 ~-41 ~10 minecraft:air
setblock ~32 ~-41 ~10 minecraft:light_gray_concrete
fill ~33 ~-41 ~10 ~35 ~-41 ~10 minecraft:air
setblock ~36 ~-41 ~10 minecraft:light_gray_concrete
setblock ~37 ~-41 ~10 minecraft:air
setblock ~38 ~-41 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~10 ~41 ~-41 ~10 minecraft:air
setblock ~42 ~-41 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~10 ~45 ~-41 ~10 minecraft:air
setblock ~46 ~-41 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~10 ~49 ~-41 ~10 minecraft:air
setblock ~50 ~-41 ~10 minecraft:light_gray_concrete
fill ~51 ~-41 ~10 ~62 ~-41 ~10 minecraft:air
setblock ~63 ~-41 ~10 minecraft:iron_block
setblock ~64 ~-41 ~10 minecraft:light_gray_concrete
setblock ~4 ~-41 ~11 minecraft:light_gray_concrete
fill ~5 ~-41 ~11 ~17 ~-41 ~11 minecraft:air
setblock ~18 ~-41 ~11 minecraft:light_gray_concrete
fill ~19 ~-41 ~11 ~31 ~-41 ~11 minecraft:air
setblock ~32 ~-41 ~11 minecraft:light_gray_concrete
fill ~33 ~-41 ~11 ~35 ~-41 ~11 minecraft:air
setblock ~36 ~-41 ~11 minecraft:light_gray_concrete
fill ~37 ~-41 ~11 ~41 ~-41 ~11 minecraft:air
setblock ~42 ~-41 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~11 ~45 ~-41 ~11 minecraft:air
setblock ~46 ~-41 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~11 ~49 ~-41 ~11 minecraft:air
setblock ~50 ~-41 ~11 minecraft:light_gray_concrete
fill ~51 ~-41 ~11 ~62 ~-41 ~11 minecraft:air
setblock ~63 ~-41 ~11 minecraft:iron_block
setblock ~64 ~-41 ~11 minecraft:light_gray_concrete
setblock ~4 ~-41 ~12 minecraft:light_gray_concrete
fill ~5 ~-41 ~12 ~17 ~-41 ~12 minecraft:air
setblock ~18 ~-41 ~12 minecraft:light_gray_concrete
fill ~19 ~-41 ~12 ~31 ~-41 ~12 minecraft:air
setblock ~32 ~-41 ~12 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~12 ~35 ~-41 ~12 minecraft:air
setblock ~36 ~-41 ~12 minecraft:light_gray_concrete
setblock ~37 ~-41 ~12 minecraft:air
setblock ~38 ~-41 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~12 ~41 ~-41 ~12 minecraft:air
setblock ~42 ~-41 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~12 ~45 ~-41 ~12 minecraft:air
setblock ~46 ~-41 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~12 ~49 ~-41 ~12 minecraft:air
setblock ~50 ~-41 ~12 minecraft:light_gray_concrete
fill ~51 ~-41 ~12 ~62 ~-41 ~12 minecraft:air
setblock ~63 ~-41 ~12 minecraft:iron_block
setblock ~64 ~-41 ~12 minecraft:light_gray_concrete
setblock ~4 ~-41 ~13 minecraft:light_gray_concrete
setblock ~5 ~-41 ~13 minecraft:air
setblock ~6 ~-41 ~13 minecraft:observer[facing=south]
setblock ~7 ~-41 ~13 minecraft:air
fill ~8 ~-41 ~13 ~10 ~-41 ~13 minecraft:observer[facing=south]
setblock ~11 ~-41 ~13 minecraft:air
fill ~12 ~-41 ~13 ~14 ~-41 ~13 minecraft:observer[facing=south]
setblock ~15 ~-41 ~13 minecraft:air
setblock ~16 ~-41 ~13 minecraft:observer[facing=south]
setblock ~17 ~-41 ~13 minecraft:air
setblock ~18 ~-41 ~13 minecraft:light_gray_concrete
setblock ~19 ~-41 ~13 minecraft:air
setblock ~20 ~-41 ~13 minecraft:observer[facing=south]
setblock ~21 ~-41 ~13 minecraft:air
fill ~22 ~-41 ~13 ~24 ~-41 ~13 minecraft:observer[facing=south]
setblock ~25 ~-41 ~13 minecraft:air
fill ~26 ~-41 ~13 ~28 ~-41 ~13 minecraft:observer[facing=south]
setblock ~29 ~-41 ~13 minecraft:air
setblock ~30 ~-41 ~13 minecraft:observer[facing=south]
setblock ~31 ~-41 ~13 minecraft:air
setblock ~32 ~-41 ~13 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~13 ~35 ~-41 ~13 minecraft:air
setblock ~36 ~-41 ~13 minecraft:light_gray_concrete
setblock ~37 ~-41 ~13 minecraft:air
setblock ~38 ~-41 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~13 ~41 ~-41 ~13 minecraft:air
setblock ~42 ~-41 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~13 ~45 ~-41 ~13 minecraft:air
setblock ~46 ~-41 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~13 ~49 ~-41 ~13 minecraft:air
setblock ~50 ~-41 ~13 minecraft:light_gray_concrete
setblock ~51 ~-41 ~13 minecraft:iron_block
fill ~52 ~-41 ~13 ~62 ~-41 ~13 minecraft:air
setblock ~63 ~-41 ~13 minecraft:iron_block
setblock ~64 ~-41 ~13 minecraft:light_gray_concrete
setblock ~4 ~-41 ~14 minecraft:light_gray_concrete
fill ~5 ~-41 ~14 ~17 ~-41 ~14 minecraft:air
setblock ~18 ~-41 ~14 minecraft:light_gray_concrete
fill ~19 ~-41 ~14 ~31 ~-41 ~14 minecraft:air
setblock ~32 ~-41 ~14 minecraft:light_gray_concrete
fill ~33 ~-41 ~14 ~35 ~-41 ~14 minecraft:air
setblock ~36 ~-41 ~14 minecraft:light_gray_concrete
setblock ~37 ~-41 ~14 minecraft:air
setblock ~38 ~-41 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~14 ~41 ~-41 ~14 minecraft:air
setblock ~42 ~-41 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~14 ~45 ~-41 ~14 minecraft:air
setblock ~46 ~-41 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~14 ~49 ~-41 ~14 minecraft:air
setblock ~50 ~-41 ~14 minecraft:light_gray_concrete
setblock ~51 ~-41 ~14 minecraft:iron_block
fill ~52 ~-41 ~14 ~62 ~-41 ~14 minecraft:air
setblock ~63 ~-41 ~14 minecraft:iron_block
setblock ~64 ~-41 ~14 minecraft:light_gray_concrete
setblock ~4 ~-41 ~15 minecraft:light_gray_concrete
fill ~5 ~-41 ~15 ~17 ~-41 ~15 minecraft:air
setblock ~18 ~-41 ~15 minecraft:light_gray_concrete
fill ~19 ~-41 ~15 ~31 ~-41 ~15 minecraft:air
setblock ~32 ~-41 ~15 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~15 ~35 ~-41 ~15 minecraft:air
setblock ~36 ~-41 ~15 minecraft:light_gray_concrete
setblock ~37 ~-41 ~15 minecraft:air
setblock ~38 ~-41 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~15 ~41 ~-41 ~15 minecraft:air
setblock ~42 ~-41 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~15 ~45 ~-41 ~15 minecraft:air
setblock ~46 ~-41 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~15 ~49 ~-41 ~15 minecraft:air
setblock ~50 ~-41 ~15 minecraft:light_gray_concrete
setblock ~51 ~-41 ~15 minecraft:iron_block
fill ~52 ~-41 ~15 ~62 ~-41 ~15 minecraft:air
setblock ~63 ~-41 ~15 minecraft:iron_block
setblock ~64 ~-41 ~15 minecraft:light_gray_concrete
setblock ~4 ~-41 ~16 minecraft:light_gray_concrete
setblock ~5 ~-41 ~16 minecraft:air
setblock ~6 ~-41 ~16 minecraft:observer[facing=north]
setblock ~7 ~-41 ~16 minecraft:air
fill ~8 ~-41 ~16 ~10 ~-41 ~16 minecraft:observer[facing=north]
setblock ~11 ~-41 ~16 minecraft:air
fill ~12 ~-41 ~16 ~14 ~-41 ~16 minecraft:observer[facing=north]
setblock ~15 ~-41 ~16 minecraft:air
setblock ~16 ~-41 ~16 minecraft:observer[facing=north]
setblock ~17 ~-41 ~16 minecraft:air
setblock ~18 ~-41 ~16 minecraft:light_gray_concrete
setblock ~19 ~-41 ~16 minecraft:air
setblock ~20 ~-41 ~16 minecraft:observer[facing=north]
setblock ~21 ~-41 ~16 minecraft:air
fill ~22 ~-41 ~16 ~24 ~-41 ~16 minecraft:observer[facing=north]
setblock ~25 ~-41 ~16 minecraft:air
fill ~26 ~-41 ~16 ~28 ~-41 ~16 minecraft:observer[facing=north]
setblock ~29 ~-41 ~16 minecraft:air
setblock ~30 ~-41 ~16 minecraft:observer[facing=north]
setblock ~31 ~-41 ~16 minecraft:air
setblock ~32 ~-41 ~16 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~16 ~35 ~-41 ~16 minecraft:air
setblock ~36 ~-41 ~16 minecraft:light_gray_concrete
setblock ~37 ~-41 ~16 minecraft:air
setblock ~38 ~-41 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~16 ~41 ~-41 ~16 minecraft:air
setblock ~42 ~-41 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~16 ~45 ~-41 ~16 minecraft:air
setblock ~46 ~-41 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~16 ~49 ~-41 ~16 minecraft:air
setblock ~50 ~-41 ~16 minecraft:light_gray_concrete
setblock ~51 ~-41 ~16 minecraft:iron_block
fill ~52 ~-41 ~16 ~62 ~-41 ~16 minecraft:air
setblock ~63 ~-41 ~16 minecraft:iron_block
setblock ~64 ~-41 ~16 minecraft:light_gray_concrete
setblock ~4 ~-41 ~17 minecraft:light_gray_concrete
fill ~5 ~-41 ~17 ~17 ~-41 ~17 minecraft:air
setblock ~18 ~-41 ~17 minecraft:light_gray_concrete
fill ~19 ~-41 ~17 ~31 ~-41 ~17 minecraft:air
setblock ~32 ~-41 ~17 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~17 ~35 ~-41 ~17 minecraft:air
setblock ~36 ~-41 ~17 minecraft:light_gray_concrete
setblock ~37 ~-41 ~17 minecraft:air
setblock ~38 ~-41 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~39 ~-41 ~17 ~41 ~-41 ~17 minecraft:air
setblock ~42 ~-41 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~43 ~-41 ~17 ~45 ~-41 ~17 minecraft:air
setblock ~46 ~-41 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~47 ~-41 ~17 ~49 ~-41 ~17 minecraft:air
setblock ~50 ~-41 ~17 minecraft:light_gray_concrete
fill ~51 ~-41 ~17 ~55 ~-41 ~17 minecraft:iron_block
fill ~56 ~-41 ~17 ~58 ~-41 ~17 minecraft:air
fill ~59 ~-41 ~17 ~63 ~-41 ~17 minecraft:iron_block
setblock ~64 ~-41 ~17 minecraft:light_gray_concrete
fill ~4 ~-41 ~18 ~32 ~-41 ~18 minecraft:light_gray_concrete
fill ~33 ~-41 ~18 ~35 ~-41 ~18 minecraft:air
fill ~36 ~-41 ~18 ~64 ~-41 ~18 minecraft:light_gray_concrete
setblock ~4 ~-41 ~19 minecraft:light_gray_concrete
setblock ~5 ~-41 ~19 minecraft:air
setblock ~6 ~-41 ~19 minecraft:waxed_cut_copper
fill ~7 ~-41 ~19 ~8 ~-41 ~19 minecraft:air
setblock ~9 ~-41 ~19 minecraft:waxed_cut_copper
fill ~10 ~-41 ~19 ~14 ~-41 ~19 minecraft:air
setblock ~15 ~-41 ~19 minecraft:waxed_cut_copper
fill ~16 ~-41 ~19 ~17 ~-41 ~19 minecraft:air
setblock ~18 ~-41 ~19 minecraft:light_gray_concrete
fill ~19 ~-41 ~19 ~30 ~-41 ~19 minecraft:black_concrete
setblock ~31 ~-41 ~19 minecraft:air
setblock ~32 ~-41 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~19 ~35 ~-41 ~19 minecraft:air
setblock ~36 ~-41 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-41 ~19 ~49 ~-41 ~19 minecraft:air
setblock ~50 ~-41 ~19 minecraft:light_gray_concrete
fill ~51 ~-41 ~19 ~63 ~-41 ~19 minecraft:air
setblock ~64 ~-41 ~19 minecraft:light_gray_concrete
setblock ~4 ~-41 ~20 minecraft:light_gray_concrete
setblock ~5 ~-41 ~20 minecraft:waxed_cut_copper
fill ~6 ~-41 ~20 ~16 ~-41 ~20 minecraft:air
setblock ~17 ~-41 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-41 ~20 minecraft:light_gray_concrete
fill ~19 ~-41 ~20 ~31 ~-41 ~20 minecraft:air
setblock ~32 ~-41 ~20 minecraft:light_gray_concrete
fill ~33 ~-41 ~20 ~35 ~-41 ~20 minecraft:air
setblock ~36 ~-41 ~20 minecraft:light_gray_concrete
fill ~37 ~-41 ~20 ~49 ~-41 ~20 minecraft:air
setblock ~50 ~-41 ~20 minecraft:light_gray_concrete
fill ~51 ~-41 ~20 ~63 ~-41 ~20 minecraft:air
setblock ~64 ~-41 ~20 minecraft:light_gray_concrete
setblock ~4 ~-41 ~21 minecraft:light_gray_concrete
fill ~5 ~-41 ~21 ~17 ~-41 ~21 minecraft:air
setblock ~18 ~-41 ~21 minecraft:light_gray_concrete
fill ~19 ~-41 ~21 ~31 ~-41 ~21 minecraft:air
setblock ~32 ~-41 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~21 ~35 ~-41 ~21 minecraft:air
setblock ~36 ~-41 ~21 minecraft:glass_pane[north=true,south=true]
setblock ~37 ~-41 ~21 minecraft:air
setblock ~38 ~-41 ~21 minecraft:observer[facing=south]
fill ~39 ~-41 ~21 ~40 ~-41 ~21 minecraft:air
fill ~41 ~-41 ~21 ~42 ~-41 ~21 minecraft:observer[facing=south]
setblock ~43 ~-41 ~21 minecraft:air
fill ~44 ~-41 ~21 ~46 ~-41 ~21 minecraft:observer[facing=south]
setblock ~47 ~-41 ~21 minecraft:air
setblock ~48 ~-41 ~21 minecraft:observer[facing=south]
setblock ~49 ~-41 ~21 minecraft:air
setblock ~50 ~-41 ~21 minecraft:light_gray_concrete
fill ~51 ~-41 ~21 ~63 ~-41 ~21 minecraft:air
setblock ~64 ~-41 ~21 minecraft:light_gray_concrete
setblock ~4 ~-41 ~22 minecraft:light_gray_concrete
fill ~5 ~-41 ~22 ~9 ~-41 ~22 minecraft:air
setblock ~10 ~-41 ~22 minecraft:lightning_rod[facing=up]
fill ~11 ~-41 ~22 ~13 ~-41 ~22 minecraft:air
setblock ~14 ~-41 ~22 minecraft:lightning_rod[facing=up]
fill ~15 ~-41 ~22 ~17 ~-41 ~22 minecraft:air
setblock ~18 ~-41 ~22 minecraft:light_gray_concrete
fill ~19 ~-41 ~22 ~28 ~-41 ~22 minecraft:air
setblock ~29 ~-41 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-41 ~22 minecraft:quartz_pillar
setblock ~31 ~-41 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-41 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-41 ~22 ~35 ~-41 ~22 minecraft:air
setblock ~36 ~-41 ~22 minecraft:glass_pane[north=true,east=true]
setblock ~37 ~-41 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-41 ~22 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~39 ~-41 ~22 minecraft:quartz_pillar
fill ~40 ~-41 ~22 ~49 ~-41 ~22 minecraft:air
setblock ~50 ~-41 ~22 minecraft:light_gray_concrete
fill ~51 ~-41 ~22 ~63 ~-41 ~22 minecraft:air
setblock ~64 ~-41 ~22 minecraft:light_gray_concrete
setblock ~4 ~-41 ~23 minecraft:light_gray_concrete
setblock ~5 ~-41 ~23 minecraft:waxed_cut_copper
fill ~6 ~-41 ~23 ~16 ~-41 ~23 minecraft:air
setblock ~17 ~-41 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-41 ~23 minecraft:light_gray_concrete
fill ~19 ~-41 ~23 ~27 ~-41 ~23 minecraft:air
setblock ~28 ~-41 ~23 minecraft:smooth_quartz
setblock ~29 ~-41 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-41 ~23 ~38 ~-41 ~23 minecraft:air
setblock ~39 ~-41 ~23 minecraft:quartz_pillar
setblock ~40 ~-41 ~23 minecraft:smooth_quartz
fill ~41 ~-41 ~23 ~49 ~-41 ~23 minecraft:air
setblock ~50 ~-41 ~23 minecraft:light_gray_concrete
fill ~51 ~-41 ~23 ~63 ~-41 ~23 minecraft:air
setblock ~64 ~-41 ~23 minecraft:light_gray_concrete
setblock ~4 ~-41 ~24 minecraft:light_gray_concrete
fill ~5 ~-41 ~24 ~17 ~-41 ~24 minecraft:air
setblock ~18 ~-41 ~24 minecraft:light_gray_concrete
fill ~19 ~-41 ~24 ~25 ~-41 ~24 minecraft:air
setblock ~26 ~-41 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-41 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-41 ~24 ~29 ~-41 ~24 minecraft:air
setblock ~30 ~-41 ~24 minecraft:quartz_pillar
fill ~31 ~-41 ~24 ~37 ~-41 ~24 minecraft:air
setblock ~38 ~-41 ~24 minecraft:quartz_pillar
fill ~39 ~-41 ~24 ~40 ~-41 ~24 minecraft:air
setblock ~41 ~-41 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-41 ~24 minecraft:glass_pane[south=true,west=true]
setblock ~43 ~-41 ~24 minecraft:air
fill ~44 ~-41 ~24 ~46 ~-41 ~24 minecraft:observer[facing=north]
setblock ~47 ~-41 ~24 minecraft:air
setblock ~48 ~-41 ~24 minecraft:observer[facing=north]
setblock ~49 ~-41 ~24 minecraft:air
setblock ~50 ~-41 ~24 minecraft:light_gray_concrete
fill ~51 ~-41 ~24 ~63 ~-41 ~24 minecraft:air
setblock ~64 ~-41 ~24 minecraft:light_gray_concrete
setblock ~4 ~-41 ~25 minecraft:light_gray_concrete
fill ~5 ~-41 ~25 ~17 ~-41 ~25 minecraft:air
setblock ~18 ~-41 ~25 minecraft:light_gray_concrete
fill ~19 ~-41 ~25 ~24 ~-41 ~25 minecraft:air
fill ~25 ~-41 ~25 ~26 ~-41 ~25 minecraft:quartz_pillar
fill ~27 ~-41 ~25 ~41 ~-41 ~25 minecraft:air
setblock ~42 ~-41 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-41 ~25 minecraft:quartz_pillar
fill ~44 ~-41 ~25 ~49 ~-41 ~25 minecraft:air
setblock ~50 ~-41 ~25 minecraft:light_gray_concrete
fill ~51 ~-41 ~25 ~63 ~-41 ~25 minecraft:air
setblock ~64 ~-41 ~25 minecraft:light_gray_concrete
setblock ~4 ~-41 ~26 minecraft:light_gray_concrete
setblock ~5 ~-41 ~26 minecraft:waxed_cut_copper
fill ~6 ~-41 ~26 ~9 ~-41 ~26 minecraft:air
setblock ~10 ~-41 ~26 minecraft:lightning_rod[facing=up]
fill ~11 ~-41 ~26 ~13 ~-41 ~26 minecraft:air
setblock ~14 ~-41 ~26 minecraft:lightning_rod[facing=up]
fill ~15 ~-41 ~26 ~16 ~-41 ~26 minecraft:air
setblock ~17 ~-41 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-41 ~26 minecraft:light_gray_concrete
fill ~19 ~-41 ~26 ~23 ~-41 ~26 minecraft:air
setblock ~24 ~-41 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-41 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-41 ~26 ~42 ~-41 ~26 minecraft:air
setblock ~43 ~-41 ~26 minecraft:quartz_pillar
setblock ~44 ~-41 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-41 ~26 ~49 ~-41 ~26 minecraft:air
setblock ~50 ~-41 ~26 minecraft:light_gray_concrete
fill ~51 ~-41 ~26 ~63 ~-41 ~26 minecraft:air
setblock ~64 ~-41 ~26 minecraft:light_gray_concrete
setblock ~4 ~-41 ~27 minecraft:light_gray_concrete
fill ~5 ~-41 ~27 ~17 ~-41 ~27 minecraft:air
setblock ~18 ~-41 ~27 minecraft:light_gray_concrete
fill ~19 ~-41 ~27 ~23 ~-41 ~27 minecraft:air
setblock ~24 ~-41 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-41 ~27 ~43 ~-41 ~27 minecraft:air
setblock ~44 ~-41 ~27 minecraft:glass_pane[north=true,east=true]
fill ~45 ~-41 ~27 ~46 ~-41 ~27 minecraft:observer[facing=south]
setblock ~47 ~-41 ~27 minecraft:air
setblock ~48 ~-41 ~27 minecraft:observer[facing=south]
setblock ~49 ~-41 ~27 minecraft:air
setblock ~50 ~-41 ~27 minecraft:light_gray_concrete
fill ~51 ~-41 ~27 ~63 ~-41 ~27 minecraft:air
setblock ~64 ~-41 ~27 minecraft:light_gray_concrete
setblock ~4 ~-41 ~28 minecraft:light_gray_concrete
fill ~5 ~-41 ~28 ~17 ~-41 ~28 minecraft:air
setblock ~18 ~-41 ~28 minecraft:light_gray_concrete
fill ~19 ~-41 ~28 ~22 ~-41 ~28 minecraft:air
setblock ~23 ~-41 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-41 ~28 ~44 ~-41 ~28 minecraft:air
setblock ~45 ~-41 ~28 minecraft:glass_pane[north=true,south=true]
fill ~46 ~-41 ~28 ~49 ~-41 ~28 minecraft:air
setblock ~50 ~-41 ~28 minecraft:light_gray_concrete
fill ~51 ~-41 ~28 ~63 ~-41 ~28 minecraft:air
setblock ~64 ~-41 ~28 minecraft:light_gray_concrete
setblock ~4 ~-41 ~29 minecraft:light_gray_concrete
setblock ~5 ~-41 ~29 minecraft:waxed_cut_copper
fill ~6 ~-41 ~29 ~16 ~-41 ~29 minecraft:air
setblock ~17 ~-41 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-41 ~29 minecraft:light_gray_concrete
fill ~19 ~-41 ~29 ~21 ~-41 ~29 minecraft:air
fill ~22 ~-41 ~29 ~23 ~-41 ~29 minecraft:quartz_pillar
fill ~24 ~-41 ~29 ~44 ~-41 ~29 minecraft:air
setblock ~45 ~-41 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-41 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-41 ~29 ~49 ~-41 ~29 minecraft:air
setblock ~50 ~-41 ~29 minecraft:light_gray_concrete
fill ~51 ~-41 ~29 ~63 ~-41 ~29 minecraft:air
setblock ~64 ~-41 ~29 minecraft:light_gray_concrete
setblock ~4 ~-41 ~30 minecraft:light_gray_concrete
fill ~5 ~-41 ~30 ~17 ~-41 ~30 minecraft:air
setblock ~18 ~-41 ~30 minecraft:light_gray_concrete
fill ~19 ~-41 ~30 ~21 ~-41 ~30 minecraft:air
setblock ~22 ~-41 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-41 ~30 minecraft:air
setblock ~24 ~-41 ~30 minecraft:quartz_pillar
fill ~25 ~-41 ~30 ~43 ~-41 ~30 minecraft:air
setblock ~44 ~-41 ~30 minecraft:quartz_pillar
setblock ~45 ~-41 ~30 minecraft:air
setblock ~46 ~-41 ~30 minecraft:quartz_pillar
fill ~47 ~-41 ~30 ~49 ~-41 ~30 minecraft:air
setblock ~50 ~-41 ~30 minecraft:light_gray_concrete
fill ~51 ~-41 ~30 ~63 ~-41 ~30 minecraft:air
setblock ~64 ~-41 ~30 minecraft:light_gray_concrete
setblock ~4 ~-41 ~31 minecraft:light_gray_concrete
setblock ~5 ~-41 ~31 minecraft:air
setblock ~6 ~-41 ~31 minecraft:waxed_cut_copper
fill ~7 ~-41 ~31 ~8 ~-41 ~31 minecraft:air
setblock ~9 ~-41 ~31 minecraft:waxed_cut_copper
fill ~10 ~-41 ~31 ~14 ~-41 ~31 minecraft:air
setblock ~15 ~-41 ~31 minecraft:waxed_cut_copper
fill ~16 ~-41 ~31 ~17 ~-41 ~31 minecraft:air
setblock ~18 ~-41 ~31 minecraft:light_gray_concrete
fill ~19 ~-41 ~31 ~21 ~-41 ~31 minecraft:air
setblock ~22 ~-41 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-41 ~31 ~45 ~-41 ~31 minecraft:air
setblock ~46 ~-41 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-41 ~31 ~49 ~-41 ~31 minecraft:air
setblock ~50 ~-41 ~31 minecraft:light_gray_concrete
fill ~51 ~-41 ~31 ~63 ~-41 ~31 minecraft:air
setblock ~64 ~-41 ~31 minecraft:light_gray_concrete
fill ~4 ~-41 ~32 ~18 ~-41 ~32 minecraft:light_gray_concrete
setblock ~19 ~-41 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-41 ~32 minecraft:light_gray_concrete
setblock ~21 ~-41 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-41 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-41 ~32 ~32 ~-41 ~32 minecraft:air
fill ~33 ~-41 ~32 ~35 ~-41 ~32 minecraft:glass
fill ~36 ~-41 ~32 ~45 ~-41 ~32 minecraft:air
setblock ~46 ~-41 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-41 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-41 ~32 minecraft:light_gray_concrete
setblock ~49 ~-41 ~32 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-41 ~32 ~64 ~-41 ~32 minecraft:light_gray_concrete
setblock ~4 ~-41 ~33 minecraft:light_gray_concrete
fill ~5 ~-41 ~33 ~32 ~-41 ~33 minecraft:air
setblock ~33 ~-41 ~33 minecraft:glass
setblock ~34 ~-41 ~33 minecraft:air
setblock ~35 ~-41 ~33 minecraft:glass
fill ~36 ~-41 ~33 ~63 ~-41 ~33 minecraft:air
setblock ~64 ~-41 ~33 minecraft:light_gray_concrete
setblock ~4 ~-41 ~34 minecraft:light_gray_concrete
fill ~5 ~-41 ~34 ~32 ~-41 ~34 minecraft:air
fill ~33 ~-41 ~34 ~35 ~-41 ~34 minecraft:glass
fill ~36 ~-41 ~34 ~63 ~-41 ~34 minecraft:air
setblock ~64 ~-41 ~34 minecraft:light_gray_concrete
setblock ~4 ~-41 ~35 minecraft:light_gray_concrete
fill ~5 ~-41 ~35 ~32 ~-41 ~35 minecraft:air
setblock ~33 ~-41 ~35 minecraft:glass
setblock ~34 ~-41 ~35 minecraft:air
setblock ~35 ~-41 ~35 minecraft:glass
fill ~36 ~-41 ~35 ~63 ~-41 ~35 minecraft:air
setblock ~64 ~-41 ~35 minecraft:light_gray_concrete
fill ~4 ~-41 ~36 ~18 ~-41 ~36 minecraft:light_gray_concrete
setblock ~19 ~-41 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-41 ~36 minecraft:light_gray_concrete
setblock ~21 ~-41 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-41 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-41 ~36 ~32 ~-41 ~36 minecraft:air
fill ~33 ~-41 ~36 ~35 ~-41 ~36 minecraft:glass
fill ~36 ~-41 ~36 ~45 ~-41 ~36 minecraft:air
setblock ~46 ~-41 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-41 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-41 ~36 minecraft:light_gray_concrete
setblock ~49 ~-41 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-41 ~36 ~64 ~-41 ~36 minecraft:light_gray_concrete
setblock ~4 ~-41 ~37 minecraft:light_gray_concrete
fill ~5 ~-41 ~37 ~17 ~-41 ~37 minecraft:air
setblock ~18 ~-41 ~37 minecraft:light_gray_concrete
fill ~19 ~-41 ~37 ~21 ~-41 ~37 minecraft:air
setblock ~22 ~-41 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-41 ~37 ~45 ~-41 ~37 minecraft:air
setblock ~46 ~-41 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-41 ~37 ~49 ~-41 ~37 minecraft:air
setblock ~50 ~-41 ~37 minecraft:light_gray_concrete
fill ~51 ~-41 ~37 ~63 ~-41 ~37 minecraft:air
setblock ~64 ~-41 ~37 minecraft:light_gray_concrete
setblock ~4 ~-41 ~38 minecraft:light_gray_concrete
fill ~5 ~-41 ~38 ~17 ~-41 ~38 minecraft:air
setblock ~18 ~-41 ~38 minecraft:light_gray_concrete
fill ~19 ~-41 ~38 ~21 ~-41 ~38 minecraft:air
setblock ~22 ~-41 ~38 minecraft:quartz_pillar
setblock ~23 ~-41 ~38 minecraft:air
setblock ~24 ~-41 ~38 minecraft:quartz_pillar
fill ~25 ~-41 ~38 ~43 ~-41 ~38 minecraft:air
setblock ~44 ~-41 ~38 minecraft:quartz_pillar
setblock ~45 ~-41 ~38 minecraft:air
setblock ~46 ~-41 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-41 ~38 ~49 ~-41 ~38 minecraft:air
setblock ~50 ~-41 ~38 minecraft:light_gray_concrete
fill ~51 ~-41 ~38 ~62 ~-41 ~38 minecraft:air
setblock ~63 ~-41 ~38 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~38 minecraft:light_gray_concrete
setblock ~4 ~-41 ~39 minecraft:light_gray_concrete
fill ~5 ~-41 ~39 ~17 ~-41 ~39 minecraft:air
setblock ~18 ~-41 ~39 minecraft:light_gray_concrete
fill ~19 ~-41 ~39 ~21 ~-41 ~39 minecraft:air
setblock ~22 ~-41 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-41 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-41 ~39 ~44 ~-41 ~39 minecraft:air
fill ~45 ~-41 ~39 ~46 ~-41 ~39 minecraft:quartz_pillar
fill ~47 ~-41 ~39 ~49 ~-41 ~39 minecraft:air
setblock ~50 ~-41 ~39 minecraft:light_gray_concrete
fill ~51 ~-41 ~39 ~62 ~-41 ~39 minecraft:air
setblock ~63 ~-41 ~39 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~39 minecraft:light_gray_concrete
setblock ~4 ~-41 ~40 minecraft:light_gray_concrete
fill ~5 ~-41 ~40 ~17 ~-41 ~40 minecraft:air
setblock ~18 ~-41 ~40 minecraft:light_gray_concrete
fill ~19 ~-41 ~40 ~22 ~-41 ~40 minecraft:air
setblock ~23 ~-41 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-41 ~40 ~44 ~-41 ~40 minecraft:air
setblock ~45 ~-41 ~40 minecraft:glass_pane[north=true,south=true]
fill ~46 ~-41 ~40 ~49 ~-41 ~40 minecraft:air
setblock ~50 ~-41 ~40 minecraft:light_gray_concrete
fill ~51 ~-41 ~40 ~62 ~-41 ~40 minecraft:air
setblock ~63 ~-41 ~40 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~40 minecraft:light_gray_concrete
setblock ~4 ~-41 ~41 minecraft:light_gray_concrete
fill ~5 ~-41 ~41 ~17 ~-41 ~41 minecraft:air
setblock ~18 ~-41 ~41 minecraft:light_gray_concrete
fill ~19 ~-41 ~41 ~23 ~-41 ~41 minecraft:air
setblock ~24 ~-41 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-41 ~41 ~43 ~-41 ~41 minecraft:air
setblock ~44 ~-41 ~41 minecraft:glass_pane[east=true,south=true]
fill ~45 ~-41 ~41 ~46 ~-41 ~41 minecraft:observer[facing=north]
setblock ~47 ~-41 ~41 minecraft:air
setblock ~48 ~-41 ~41 minecraft:observer[facing=north]
setblock ~49 ~-41 ~41 minecraft:air
setblock ~50 ~-41 ~41 minecraft:light_gray_concrete
fill ~51 ~-41 ~41 ~62 ~-41 ~41 minecraft:air
setblock ~63 ~-41 ~41 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~41 minecraft:light_gray_concrete
setblock ~4 ~-41 ~42 minecraft:light_gray_concrete
setblock ~5 ~-41 ~42 minecraft:black_concrete
fill ~6 ~-41 ~42 ~17 ~-41 ~42 minecraft:air
setblock ~18 ~-41 ~42 minecraft:light_gray_concrete
fill ~19 ~-41 ~42 ~23 ~-41 ~42 minecraft:air
setblock ~24 ~-41 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-41 ~42 minecraft:quartz_pillar
fill ~26 ~-41 ~42 ~42 ~-41 ~42 minecraft:air
setblock ~43 ~-41 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-41 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-41 ~42 ~49 ~-41 ~42 minecraft:air
setblock ~50 ~-41 ~42 minecraft:light_gray_concrete
fill ~51 ~-41 ~42 ~62 ~-41 ~42 minecraft:air
setblock ~63 ~-41 ~42 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~42 minecraft:light_gray_concrete
setblock ~4 ~-41 ~43 minecraft:light_gray_concrete
setblock ~5 ~-41 ~43 minecraft:black_concrete
fill ~6 ~-41 ~43 ~17 ~-41 ~43 minecraft:air
setblock ~18 ~-41 ~43 minecraft:light_gray_concrete
fill ~19 ~-41 ~43 ~24 ~-41 ~43 minecraft:air
setblock ~25 ~-41 ~43 minecraft:quartz_pillar
setblock ~26 ~-41 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-41 ~43 ~41 ~-41 ~43 minecraft:air
fill ~42 ~-41 ~43 ~43 ~-41 ~43 minecraft:quartz_pillar
fill ~44 ~-41 ~43 ~49 ~-41 ~43 minecraft:air
setblock ~50 ~-41 ~43 minecraft:light_gray_concrete
fill ~51 ~-41 ~43 ~62 ~-41 ~43 minecraft:air
setblock ~63 ~-41 ~43 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~43 minecraft:light_gray_concrete
setblock ~4 ~-41 ~44 minecraft:light_gray_concrete
setblock ~5 ~-41 ~44 minecraft:black_concrete
fill ~6 ~-41 ~44 ~17 ~-41 ~44 minecraft:air
setblock ~18 ~-41 ~44 minecraft:light_gray_concrete
fill ~19 ~-41 ~44 ~25 ~-41 ~44 minecraft:air
setblock ~26 ~-41 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-41 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-41 ~44 ~29 ~-41 ~44 minecraft:air
setblock ~30 ~-41 ~44 minecraft:quartz_pillar
fill ~31 ~-41 ~44 ~37 ~-41 ~44 minecraft:air
setblock ~38 ~-41 ~44 minecraft:quartz_pillar
fill ~39 ~-41 ~44 ~40 ~-41 ~44 minecraft:air
setblock ~41 ~-41 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-41 ~44 minecraft:glass_pane[north=true,west=true]
setblock ~43 ~-41 ~44 minecraft:air
fill ~44 ~-41 ~44 ~46 ~-41 ~44 minecraft:observer[facing=south]
setblock ~47 ~-41 ~44 minecraft:air
setblock ~48 ~-41 ~44 minecraft:observer[facing=south]
setblock ~49 ~-41 ~44 minecraft:air
setblock ~50 ~-41 ~44 minecraft:light_gray_concrete
fill ~51 ~-41 ~44 ~62 ~-41 ~44 minecraft:air
setblock ~63 ~-41 ~44 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~44 minecraft:light_gray_concrete
setblock ~4 ~-41 ~45 minecraft:light_gray_concrete
fill ~5 ~-41 ~45 ~17 ~-41 ~45 minecraft:air
setblock ~18 ~-41 ~45 minecraft:light_gray_concrete
fill ~19 ~-41 ~45 ~27 ~-41 ~45 minecraft:air
setblock ~28 ~-41 ~45 minecraft:smooth_quartz
setblock ~29 ~-41 ~45 minecraft:quartz_pillar
fill ~30 ~-41 ~45 ~38 ~-41 ~45 minecraft:air
setblock ~39 ~-41 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-41 ~45 minecraft:smooth_quartz
fill ~41 ~-41 ~45 ~49 ~-41 ~45 minecraft:air
setblock ~50 ~-41 ~45 minecraft:light_gray_concrete
fill ~51 ~-41 ~45 ~62 ~-41 ~45 minecraft:air
setblock ~63 ~-41 ~45 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~45 minecraft:light_gray_concrete
setblock ~4 ~-41 ~46 minecraft:light_gray_concrete
fill ~5 ~-41 ~46 ~17 ~-41 ~46 minecraft:air
setblock ~18 ~-41 ~46 minecraft:light_gray_concrete
fill ~19 ~-41 ~46 ~28 ~-41 ~46 minecraft:air
setblock ~29 ~-41 ~46 minecraft:quartz_pillar
fill ~30 ~-41 ~46 ~31 ~-41 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-41 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-41 ~46 ~35 ~-41 ~46 minecraft:air
setblock ~36 ~-41 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-41 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-41 ~46 minecraft:quartz_pillar
setblock ~39 ~-41 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-41 ~46 ~49 ~-41 ~46 minecraft:air
setblock ~50 ~-41 ~46 minecraft:light_gray_concrete
fill ~51 ~-41 ~46 ~62 ~-41 ~46 minecraft:air
setblock ~63 ~-41 ~46 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~46 minecraft:light_gray_concrete
setblock ~4 ~-41 ~47 minecraft:light_gray_concrete
fill ~5 ~-41 ~47 ~17 ~-41 ~47 minecraft:air
setblock ~18 ~-41 ~47 minecraft:light_gray_concrete
fill ~19 ~-41 ~47 ~31 ~-41 ~47 minecraft:air
setblock ~32 ~-41 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~47 ~35 ~-41 ~47 minecraft:air
setblock ~36 ~-41 ~47 minecraft:glass_pane[north=true,south=true]
setblock ~37 ~-41 ~47 minecraft:air
setblock ~38 ~-41 ~47 minecraft:observer[facing=north]
fill ~39 ~-41 ~47 ~40 ~-41 ~47 minecraft:air
fill ~41 ~-41 ~47 ~42 ~-41 ~47 minecraft:observer[facing=north]
setblock ~43 ~-41 ~47 minecraft:air
fill ~44 ~-41 ~47 ~46 ~-41 ~47 minecraft:observer[facing=north]
setblock ~47 ~-41 ~47 minecraft:air
setblock ~48 ~-41 ~47 minecraft:observer[facing=north]
setblock ~49 ~-41 ~47 minecraft:air
setblock ~50 ~-41 ~47 minecraft:light_gray_concrete
fill ~51 ~-41 ~47 ~62 ~-41 ~47 minecraft:air
setblock ~63 ~-41 ~47 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~47 minecraft:light_gray_concrete
setblock ~4 ~-41 ~48 minecraft:light_gray_concrete
fill ~5 ~-41 ~48 ~17 ~-41 ~48 minecraft:air
setblock ~18 ~-41 ~48 minecraft:light_gray_concrete
fill ~19 ~-41 ~48 ~31 ~-41 ~48 minecraft:air
setblock ~32 ~-41 ~48 minecraft:light_gray_concrete
fill ~33 ~-41 ~48 ~35 ~-41 ~48 minecraft:air
setblock ~36 ~-41 ~48 minecraft:light_gray_concrete
fill ~37 ~-41 ~48 ~49 ~-41 ~48 minecraft:air
setblock ~50 ~-41 ~48 minecraft:light_gray_concrete
fill ~51 ~-41 ~48 ~62 ~-41 ~48 minecraft:air
setblock ~63 ~-41 ~48 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~48 minecraft:light_gray_concrete
setblock ~4 ~-41 ~49 minecraft:light_gray_concrete
fill ~5 ~-41 ~49 ~17 ~-41 ~49 minecraft:air
setblock ~18 ~-41 ~49 minecraft:light_gray_concrete
fill ~19 ~-41 ~49 ~30 ~-41 ~49 minecraft:black_concrete
setblock ~31 ~-41 ~49 minecraft:air
setblock ~32 ~-41 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-41 ~49 ~35 ~-41 ~49 minecraft:air
setblock ~36 ~-41 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-41 ~49 ~49 ~-41 ~49 minecraft:air
setblock ~50 ~-41 ~49 minecraft:light_gray_concrete
fill ~51 ~-41 ~49 ~62 ~-41 ~49 minecraft:air
setblock ~63 ~-41 ~49 minecraft:chiseled_bookshelf[facing=west]
setblock ~64 ~-41 ~49 minecraft:light_gray_concrete
fill ~4 ~-41 ~50 ~32 ~-41 ~50 minecraft:light_gray_concrete
fill ~33 ~-41 ~50 ~35 ~-41 ~50 minecraft:air
fill ~36 ~-41 ~50 ~64 ~-41 ~50 minecraft:light_gray_concrete
setblock ~4 ~-41 ~51 minecraft:light_gray_concrete
fill ~5 ~-41 ~51 ~17 ~-41 ~51 minecraft:air
setblock ~18 ~-41 ~51 minecraft:light_gray_concrete
setblock ~19 ~-41 ~51 minecraft:waxed_cut_copper
fill ~20 ~-41 ~51 ~21 ~-41 ~51 minecraft:air
setblock ~22 ~-41 ~51 minecraft:waxed_cut_copper
fill ~23 ~-41 ~51 ~24 ~-41 ~51 minecraft:air
setblock ~25 ~-41 ~51 minecraft:waxed_cut_copper
fill ~26 ~-41 ~51 ~27 ~-41 ~51 minecraft:air
setblock ~28 ~-41 ~51 minecraft:waxed_cut_copper
fill ~29 ~-41 ~51 ~30 ~-41 ~51 minecraft:air
setblock ~31 ~-41 ~51 minecraft:waxed_cut_copper
setblock ~32 ~-41 ~51 minecraft:light_gray_concrete
fill ~33 ~-41 ~51 ~35 ~-41 ~51 minecraft:air
setblock ~36 ~-41 ~51 minecraft:light_gray_concrete
fill ~37 ~-41 ~51 ~49 ~-41 ~51 minecraft:air
setblock ~50 ~-41 ~51 minecraft:light_gray_concrete
fill ~51 ~-41 ~51 ~63 ~-41 ~51 minecraft:air
setblock ~64 ~-41 ~51 minecraft:light_gray_concrete
setblock ~4 ~-41 ~52 minecraft:light_gray_concrete
setblock ~5 ~-41 ~52 minecraft:air
setblock ~6 ~-41 ~52 minecraft:observer[facing=south]
setblock ~7 ~-41 ~52 minecraft:air
fill ~8 ~-41 ~52 ~10 ~-41 ~52 minecraft:observer[facing=south]
setblock ~11 ~-41 ~52 minecraft:air
fill ~12 ~-41 ~52 ~14 ~-41 ~52 minecraft:observer[facing=south]
setblock ~15 ~-41 ~52 minecraft:air
setblock ~16 ~-41 ~52 minecraft:observer[facing=south]
setblock ~17 ~-41 ~52 minecraft:air
setblock ~18 ~-41 ~52 minecraft:light_gray_concrete
fill ~19 ~-41 ~52 ~31 ~-41 ~52 minecraft:air
setblock ~32 ~-41 ~52 minecraft:light_gray_concrete
fill ~33 ~-41 ~52 ~35 ~-41 ~52 minecraft:air
setblock ~36 ~-41 ~52 minecraft:light_gray_concrete
fill ~37 ~-41 ~52 ~49 ~-41 ~52 minecraft:air
setblock ~50 ~-41 ~52 minecraft:light_gray_concrete
setblock ~51 ~-41 ~52 minecraft:air
fill ~52 ~-41 ~52 ~55 ~-41 ~52 minecraft:barrel
fill ~56 ~-41 ~52 ~57 ~-41 ~52 minecraft:air
fill ~58 ~-41 ~52 ~60 ~-41 ~52 minecraft:barrel
setblock ~61 ~-41 ~52 minecraft:air
setblock ~62 ~-41 ~52 minecraft:barrel
setblock ~63 ~-41 ~52 minecraft:air
setblock ~64 ~-41 ~52 minecraft:light_gray_concrete
setblock ~4 ~-41 ~53 minecraft:light_gray_concrete
fill ~5 ~-41 ~53 ~17 ~-41 ~53 minecraft:air
setblock ~18 ~-41 ~53 minecraft:light_gray_concrete
fill ~19 ~-41 ~53 ~31 ~-41 ~53 minecraft:air
setblock ~32 ~-41 ~53 minecraft:light_gray_concrete
fill ~33 ~-41 ~53 ~35 ~-41 ~53 minecraft:air
setblock ~36 ~-41 ~53 minecraft:light_gray_concrete
fill ~37 ~-41 ~53 ~49 ~-41 ~53 minecraft:air
setblock ~50 ~-41 ~53 minecraft:light_gray_concrete
fill ~51 ~-41 ~53 ~63 ~-41 ~53 minecraft:air
setblock ~64 ~-41 ~53 minecraft:light_gray_concrete
setblock ~4 ~-41 ~54 minecraft:light_gray_concrete
fill ~5 ~-41 ~54 ~17 ~-41 ~54 minecraft:air
setblock ~18 ~-41 ~54 minecraft:light_gray_concrete
setblock ~19 ~-41 ~54 minecraft:waxed_cut_copper
fill ~20 ~-41 ~54 ~21 ~-41 ~54 minecraft:air
setblock ~22 ~-41 ~54 minecraft:lightning_rod[facing=up]
fill ~23 ~-41 ~54 ~25 ~-41 ~54 minecraft:air
setblock ~26 ~-41 ~54 minecraft:lightning_rod[facing=up]
fill ~27 ~-41 ~54 ~30 ~-41 ~54 minecraft:air
setblock ~31 ~-41 ~54 minecraft:waxed_cut_copper
setblock ~32 ~-41 ~54 minecraft:light_gray_concrete
fill ~33 ~-41 ~54 ~35 ~-41 ~54 minecraft:air
setblock ~36 ~-41 ~54 minecraft:light_gray_concrete
fill ~37 ~-41 ~54 ~49 ~-41 ~54 minecraft:air
setblock ~50 ~-41 ~54 minecraft:light_gray_concrete
fill ~51 ~-41 ~54 ~63 ~-41 ~54 minecraft:air
setblock ~64 ~-41 ~54 minecraft:light_gray_concrete
setblock ~4 ~-41 ~55 minecraft:light_gray_concrete
setblock ~5 ~-41 ~55 minecraft:air
setblock ~6 ~-41 ~55 minecraft:observer[facing=north]
setblock ~7 ~-41 ~55 minecraft:air
fill ~8 ~-41 ~55 ~10 ~-41 ~55 minecraft:observer[facing=north]
setblock ~11 ~-41 ~55 minecraft:air
fill ~12 ~-41 ~55 ~14 ~-41 ~55 minecraft:observer[facing=north]
setblock ~15 ~-41 ~55 minecraft:air
setblock ~16 ~-41 ~55 minecraft:observer[facing=north]
setblock ~17 ~-41 ~55 minecraft:air
setblock ~18 ~-41 ~55 minecraft:light_gray_concrete
fill ~19 ~-41 ~55 ~31 ~-41 ~55 minecraft:air
setblock ~32 ~-41 ~55 minecraft:light_gray_concrete
fill ~33 ~-41 ~55 ~35 ~-41 ~55 minecraft:air
setblock ~36 ~-41 ~55 minecraft:light_gray_concrete
fill ~37 ~-41 ~55 ~49 ~-41 ~55 minecraft:air
setblock ~50 ~-41 ~55 minecraft:light_gray_concrete
setblock ~51 ~-41 ~55 minecraft:air
fill ~52 ~-41 ~55 ~55 ~-41 ~55 minecraft:barrel
setblock ~56 ~-41 ~55 minecraft:air
fill ~57 ~-41 ~55 ~60 ~-41 ~55 minecraft:barrel
setblock ~61 ~-41 ~55 minecraft:air
setblock ~62 ~-41 ~55 minecraft:barrel
setblock ~63 ~-41 ~55 minecraft:air
setblock ~64 ~-41 ~55 minecraft:light_gray_concrete
setblock ~4 ~-41 ~56 minecraft:light_gray_concrete
fill ~5 ~-41 ~56 ~17 ~-41 ~56 minecraft:air
setblock ~18 ~-41 ~56 minecraft:light_gray_concrete
fill ~19 ~-41 ~56 ~31 ~-41 ~56 minecraft:air
setblock ~32 ~-41 ~56 minecraft:light_gray_concrete
fill ~33 ~-41 ~56 ~35 ~-41 ~56 minecraft:air
setblock ~36 ~-41 ~56 minecraft:light_gray_concrete
fill ~37 ~-41 ~56 ~49 ~-41 ~56 minecraft:air
setblock ~50 ~-41 ~56 minecraft:light_gray_concrete
fill ~51 ~-41 ~56 ~63 ~-41 ~56 minecraft:air
setblock ~64 ~-41 ~56 minecraft:light_gray_concrete
setblock ~4 ~-41 ~57 minecraft:light_gray_concrete
fill ~5 ~-41 ~57 ~17 ~-41 ~57 minecraft:air
setblock ~18 ~-41 ~57 minecraft:light_gray_concrete
fill ~19 ~-41 ~57 ~31 ~-41 ~57 minecraft:air
setblock ~32 ~-41 ~57 minecraft:light_gray_concrete
fill ~33 ~-41 ~57 ~35 ~-41 ~57 minecraft:air
setblock ~36 ~-41 ~57 minecraft:light_gray_concrete
fill ~37 ~-41 ~57 ~49 ~-41 ~57 minecraft:air
setblock ~50 ~-41 ~57 minecraft:light_gray_concrete
fill ~51 ~-41 ~57 ~63 ~-41 ~57 minecraft:air
setblock ~64 ~-41 ~57 minecraft:light_gray_concrete
setblock ~4 ~-41 ~58 minecraft:light_gray_concrete
setblock ~5 ~-41 ~58 minecraft:air
setblock ~6 ~-41 ~58 minecraft:observer[facing=south]
setblock ~7 ~-41 ~58 minecraft:air
fill ~8 ~-41 ~58 ~10 ~-41 ~58 minecraft:observer[facing=south]
setblock ~11 ~-41 ~58 minecraft:air
fill ~12 ~-41 ~58 ~14 ~-41 ~58 minecraft:observer[facing=south]
setblock ~15 ~-41 ~58 minecraft:air
setblock ~16 ~-41 ~58 minecraft:observer[facing=south]
setblock ~17 ~-41 ~58 minecraft:air
setblock ~18 ~-41 ~58 minecraft:light_gray_concrete
fill ~19 ~-41 ~58 ~21 ~-41 ~58 minecraft:air
setblock ~22 ~-41 ~58 minecraft:lightning_rod[facing=up]
fill ~23 ~-41 ~58 ~25 ~-41 ~58 minecraft:air
setblock ~26 ~-41 ~58 minecraft:lightning_rod[facing=up]
fill ~27 ~-41 ~58 ~31 ~-41 ~58 minecraft:air
setblock ~32 ~-41 ~58 minecraft:light_gray_concrete
fill ~33 ~-41 ~58 ~35 ~-41 ~58 minecraft:air
setblock ~36 ~-41 ~58 minecraft:light_gray_concrete
fill ~37 ~-41 ~58 ~49 ~-41 ~58 minecraft:air
setblock ~50 ~-41 ~58 minecraft:light_gray_concrete
setblock ~51 ~-41 ~58 minecraft:air
fill ~52 ~-41 ~58 ~55 ~-41 ~58 minecraft:barrel
setblock ~56 ~-41 ~58 minecraft:air
fill ~57 ~-41 ~58 ~60 ~-41 ~58 minecraft:barrel
setblock ~61 ~-41 ~58 minecraft:air
setblock ~62 ~-41 ~58 minecraft:barrel
setblock ~63 ~-41 ~58 minecraft:air
setblock ~64 ~-41 ~58 minecraft:light_gray_concrete
setblock ~4 ~-41 ~59 minecraft:light_gray_concrete
fill ~5 ~-41 ~59 ~17 ~-41 ~59 minecraft:air
setblock ~18 ~-41 ~59 minecraft:light_gray_concrete
fill ~19 ~-41 ~59 ~31 ~-41 ~59 minecraft:air
setblock ~32 ~-41 ~59 minecraft:light_gray_concrete
fill ~33 ~-41 ~59 ~35 ~-41 ~59 minecraft:air
setblock ~36 ~-41 ~59 minecraft:light_gray_concrete
fill ~37 ~-41 ~59 ~49 ~-41 ~59 minecraft:air
setblock ~50 ~-41 ~59 minecraft:light_gray_concrete
fill ~51 ~-41 ~59 ~63 ~-41 ~59 minecraft:air
setblock ~64 ~-41 ~59 minecraft:light_gray_concrete
setblock ~4 ~-41 ~60 minecraft:light_gray_concrete
fill ~5 ~-41 ~60 ~17 ~-41 ~60 minecraft:air
setblock ~18 ~-41 ~60 minecraft:light_gray_concrete
setblock ~19 ~-41 ~60 minecraft:waxed_cut_copper
fill ~20 ~-41 ~60 ~30 ~-41 ~60 minecraft:air
setblock ~31 ~-41 ~60 minecraft:waxed_cut_copper
setblock ~32 ~-41 ~60 minecraft:light_gray_concrete
fill ~33 ~-41 ~60 ~35 ~-41 ~60 minecraft:air
setblock ~36 ~-41 ~60 minecraft:light_gray_concrete
fill ~37 ~-41 ~60 ~49 ~-41 ~60 minecraft:air
setblock ~50 ~-41 ~60 minecraft:light_gray_concrete
fill ~51 ~-41 ~60 ~63 ~-41 ~60 minecraft:air
setblock ~64 ~-41 ~60 minecraft:light_gray_concrete
setblock ~4 ~-41 ~61 minecraft:light_gray_concrete
setblock ~5 ~-41 ~61 minecraft:air
setblock ~6 ~-41 ~61 minecraft:observer[facing=north]
setblock ~7 ~-41 ~61 minecraft:air
fill ~8 ~-41 ~61 ~10 ~-41 ~61 minecraft:observer[facing=north]
setblock ~11 ~-41 ~61 minecraft:air
fill ~12 ~-41 ~61 ~14 ~-41 ~61 minecraft:observer[facing=north]
setblock ~15 ~-41 ~61 minecraft:air
setblock ~16 ~-41 ~61 minecraft:observer[facing=north]
setblock ~17 ~-41 ~61 minecraft:air
setblock ~18 ~-41 ~61 minecraft:light_gray_concrete
fill ~19 ~-41 ~61 ~31 ~-41 ~61 minecraft:air
setblock ~32 ~-41 ~61 minecraft:light_gray_concrete
fill ~33 ~-41 ~61 ~35 ~-41 ~61 minecraft:air
setblock ~36 ~-41 ~61 minecraft:light_gray_concrete
fill ~37 ~-41 ~61 ~49 ~-41 ~61 minecraft:air
setblock ~50 ~-41 ~61 minecraft:light_gray_concrete
setblock ~51 ~-41 ~61 minecraft:air
fill ~52 ~-41 ~61 ~55 ~-41 ~61 minecraft:barrel
setblock ~56 ~-41 ~61 minecraft:air
fill ~57 ~-41 ~61 ~60 ~-41 ~61 minecraft:barrel
setblock ~61 ~-41 ~61 minecraft:air
setblock ~62 ~-41 ~61 minecraft:barrel
setblock ~63 ~-41 ~61 minecraft:air
setblock ~64 ~-41 ~61 minecraft:light_gray_concrete
setblock ~4 ~-41 ~62 minecraft:light_gray_concrete
fill ~5 ~-41 ~62 ~17 ~-41 ~62 minecraft:air
setblock ~18 ~-41 ~62 minecraft:light_gray_concrete
fill ~19 ~-41 ~62 ~31 ~-41 ~62 minecraft:air
setblock ~32 ~-41 ~62 minecraft:light_gray_concrete
fill ~33 ~-41 ~62 ~35 ~-41 ~62 minecraft:air
setblock ~36 ~-41 ~62 minecraft:light_gray_concrete
fill ~37 ~-41 ~62 ~49 ~-41 ~62 minecraft:air
setblock ~50 ~-41 ~62 minecraft:light_gray_concrete
fill ~51 ~-41 ~62 ~63 ~-41 ~62 minecraft:air
setblock ~64 ~-41 ~62 minecraft:light_gray_concrete
setblock ~4 ~-41 ~63 minecraft:light_gray_concrete
fill ~5 ~-41 ~63 ~17 ~-41 ~63 minecraft:air
setblock ~18 ~-41 ~63 minecraft:light_gray_concrete
setblock ~19 ~-41 ~63 minecraft:waxed_cut_copper
fill ~20 ~-41 ~63 ~21 ~-41 ~63 minecraft:air
setblock ~22 ~-41 ~63 minecraft:waxed_cut_copper
fill ~23 ~-41 ~63 ~24 ~-41 ~63 minecraft:air
setblock ~25 ~-41 ~63 minecraft:waxed_cut_copper
fill ~26 ~-41 ~63 ~27 ~-41 ~63 minecraft:air
setblock ~28 ~-41 ~63 minecraft:waxed_cut_copper
fill ~29 ~-41 ~63 ~30 ~-41 ~63 minecraft:air
setblock ~31 ~-41 ~63 minecraft:waxed_cut_copper
setblock ~32 ~-41 ~63 minecraft:light_gray_concrete
fill ~33 ~-41 ~63 ~35 ~-41 ~63 minecraft:air
setblock ~36 ~-41 ~63 minecraft:light_gray_concrete
fill ~37 ~-41 ~63 ~49 ~-41 ~63 minecraft:air
setblock ~50 ~-41 ~63 minecraft:light_gray_concrete
fill ~51 ~-41 ~63 ~63 ~-41 ~63 minecraft:air
setblock ~64 ~-41 ~63 minecraft:light_gray_concrete
fill ~4 ~-41 ~64 ~64 ~-41 ~64 minecraft:light_gray_concrete
setblock ~34 ~-41 ~65 minecraft:light_gray_concrete
fill ~32 ~-41 ~66 ~36 ~-41 ~66 minecraft:polished_andesite
setblock ~32 ~-41 ~67 minecraft:polished_andesite
fill ~33 ~-41 ~67 ~35 ~-41 ~67 minecraft:air
setblock ~36 ~-41 ~67 minecraft:polished_andesite
setblock ~32 ~-41 ~68 minecraft:polished_andesite
setblock ~33 ~-41 ~68 minecraft:air
setblock ~34 ~-41 ~68 minecraft:quartz_pillar
setblock ~35 ~-41 ~68 minecraft:air
setblock ~36 ~-41 ~68 minecraft:polished_andesite
setblock ~32 ~-41 ~69 minecraft:polished_andesite
fill ~33 ~-41 ~69 ~34 ~-41 ~69 minecraft:air
setblock ~35 ~-41 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-41 ~69 minecraft:polished_andesite
fill ~32 ~-41 ~70 ~36 ~-41 ~70 minecraft:polished_andesite
fill ~4 ~-40 ~4 ~64 ~-40 ~4 minecraft:light_gray_concrete
setblock ~4 ~-40 ~5 minecraft:light_gray_concrete
fill ~5 ~-40 ~5 ~17 ~-40 ~5 minecraft:air
setblock ~18 ~-40 ~5 minecraft:light_gray_concrete
fill ~19 ~-40 ~5 ~31 ~-40 ~5 minecraft:air
setblock ~32 ~-40 ~5 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~5 ~35 ~-40 ~5 minecraft:air
setblock ~36 ~-40 ~5 minecraft:light_gray_concrete
fill ~37 ~-40 ~5 ~39 ~-40 ~5 minecraft:air
setblock ~40 ~-40 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~5 ~43 ~-40 ~5 minecraft:air
setblock ~44 ~-40 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~5 ~47 ~-40 ~5 minecraft:air
setblock ~48 ~-40 ~5 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~5 minecraft:air
setblock ~50 ~-40 ~5 minecraft:light_gray_concrete
fill ~51 ~-40 ~5 ~63 ~-40 ~5 minecraft:iron_block
setblock ~64 ~-40 ~5 minecraft:light_gray_concrete
setblock ~4 ~-40 ~6 minecraft:light_gray_concrete
fill ~5 ~-40 ~6 ~17 ~-40 ~6 minecraft:air
setblock ~18 ~-40 ~6 minecraft:light_gray_concrete
fill ~19 ~-40 ~6 ~31 ~-40 ~6 minecraft:air
setblock ~32 ~-40 ~6 minecraft:light_gray_concrete
fill ~33 ~-40 ~6 ~35 ~-40 ~6 minecraft:air
setblock ~36 ~-40 ~6 minecraft:light_gray_concrete
fill ~37 ~-40 ~6 ~39 ~-40 ~6 minecraft:air
setblock ~40 ~-40 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~6 ~43 ~-40 ~6 minecraft:air
setblock ~44 ~-40 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~6 ~47 ~-40 ~6 minecraft:air
setblock ~48 ~-40 ~6 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~6 minecraft:air
setblock ~50 ~-40 ~6 minecraft:light_gray_concrete
setblock ~51 ~-40 ~6 minecraft:iron_block
fill ~52 ~-40 ~6 ~62 ~-40 ~6 minecraft:air
setblock ~63 ~-40 ~6 minecraft:iron_block
setblock ~64 ~-40 ~6 minecraft:light_gray_concrete
setblock ~4 ~-40 ~7 minecraft:light_gray_concrete
fill ~5 ~-40 ~7 ~17 ~-40 ~7 minecraft:air
setblock ~18 ~-40 ~7 minecraft:light_gray_concrete
fill ~19 ~-40 ~7 ~31 ~-40 ~7 minecraft:air
setblock ~32 ~-40 ~7 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~7 ~35 ~-40 ~7 minecraft:air
setblock ~36 ~-40 ~7 minecraft:light_gray_concrete
fill ~37 ~-40 ~7 ~39 ~-40 ~7 minecraft:air
setblock ~40 ~-40 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~7 ~43 ~-40 ~7 minecraft:air
setblock ~44 ~-40 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~7 ~47 ~-40 ~7 minecraft:air
setblock ~48 ~-40 ~7 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~7 minecraft:air
setblock ~50 ~-40 ~7 minecraft:light_gray_concrete
setblock ~51 ~-40 ~7 minecraft:iron_block
fill ~52 ~-40 ~7 ~62 ~-40 ~7 minecraft:air
setblock ~63 ~-40 ~7 minecraft:iron_block
setblock ~64 ~-40 ~7 minecraft:light_gray_concrete
setblock ~4 ~-40 ~8 minecraft:light_gray_concrete
fill ~5 ~-40 ~8 ~17 ~-40 ~8 minecraft:air
setblock ~18 ~-40 ~8 minecraft:light_gray_concrete
fill ~19 ~-40 ~8 ~31 ~-40 ~8 minecraft:air
setblock ~32 ~-40 ~8 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~8 ~35 ~-40 ~8 minecraft:air
setblock ~36 ~-40 ~8 minecraft:light_gray_concrete
fill ~37 ~-40 ~8 ~39 ~-40 ~8 minecraft:air
setblock ~40 ~-40 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~8 ~43 ~-40 ~8 minecraft:air
setblock ~44 ~-40 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~8 ~47 ~-40 ~8 minecraft:air
setblock ~48 ~-40 ~8 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~8 minecraft:air
setblock ~50 ~-40 ~8 minecraft:light_gray_concrete
setblock ~51 ~-40 ~8 minecraft:iron_block
fill ~52 ~-40 ~8 ~62 ~-40 ~8 minecraft:air
setblock ~63 ~-40 ~8 minecraft:iron_block
setblock ~64 ~-40 ~8 minecraft:light_gray_concrete
setblock ~4 ~-40 ~9 minecraft:light_gray_concrete
fill ~5 ~-40 ~9 ~17 ~-40 ~9 minecraft:air
setblock ~18 ~-40 ~9 minecraft:light_gray_concrete
fill ~19 ~-40 ~9 ~31 ~-40 ~9 minecraft:air
setblock ~32 ~-40 ~9 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~9 ~35 ~-40 ~9 minecraft:air
setblock ~36 ~-40 ~9 minecraft:light_gray_concrete
fill ~37 ~-40 ~9 ~39 ~-40 ~9 minecraft:air
setblock ~40 ~-40 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~9 ~43 ~-40 ~9 minecraft:air
setblock ~44 ~-40 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~9 ~47 ~-40 ~9 minecraft:air
setblock ~48 ~-40 ~9 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~9 minecraft:air
setblock ~50 ~-40 ~9 minecraft:light_gray_concrete
setblock ~51 ~-40 ~9 minecraft:iron_block
fill ~52 ~-40 ~9 ~62 ~-40 ~9 minecraft:air
setblock ~63 ~-40 ~9 minecraft:iron_block
setblock ~64 ~-40 ~9 minecraft:light_gray_concrete
setblock ~4 ~-40 ~10 minecraft:light_gray_concrete
fill ~5 ~-40 ~10 ~17 ~-40 ~10 minecraft:air
setblock ~18 ~-40 ~10 minecraft:light_gray_concrete
fill ~19 ~-40 ~10 ~31 ~-40 ~10 minecraft:air
setblock ~32 ~-40 ~10 minecraft:light_gray_concrete
fill ~33 ~-40 ~10 ~35 ~-40 ~10 minecraft:air
setblock ~36 ~-40 ~10 minecraft:light_gray_concrete
fill ~37 ~-40 ~10 ~39 ~-40 ~10 minecraft:air
setblock ~40 ~-40 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~10 ~43 ~-40 ~10 minecraft:air
setblock ~44 ~-40 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~10 ~47 ~-40 ~10 minecraft:air
setblock ~48 ~-40 ~10 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~10 minecraft:air
setblock ~50 ~-40 ~10 minecraft:light_gray_concrete
fill ~51 ~-40 ~10 ~62 ~-40 ~10 minecraft:air
setblock ~63 ~-40 ~10 minecraft:iron_block
setblock ~64 ~-40 ~10 minecraft:light_gray_concrete
setblock ~4 ~-40 ~11 minecraft:light_gray_concrete
fill ~5 ~-40 ~11 ~17 ~-40 ~11 minecraft:air
setblock ~18 ~-40 ~11 minecraft:light_gray_concrete
fill ~19 ~-40 ~11 ~31 ~-40 ~11 minecraft:air
setblock ~32 ~-40 ~11 minecraft:light_gray_concrete
fill ~33 ~-40 ~11 ~35 ~-40 ~11 minecraft:air
setblock ~36 ~-40 ~11 minecraft:light_gray_concrete
fill ~37 ~-40 ~11 ~39 ~-40 ~11 minecraft:air
setblock ~40 ~-40 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~11 ~43 ~-40 ~11 minecraft:air
setblock ~44 ~-40 ~11 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~11 ~49 ~-40 ~11 minecraft:air
setblock ~50 ~-40 ~11 minecraft:light_gray_concrete
fill ~51 ~-40 ~11 ~62 ~-40 ~11 minecraft:air
setblock ~63 ~-40 ~11 minecraft:iron_block
setblock ~64 ~-40 ~11 minecraft:light_gray_concrete
setblock ~4 ~-40 ~12 minecraft:light_gray_concrete
fill ~5 ~-40 ~12 ~17 ~-40 ~12 minecraft:air
setblock ~18 ~-40 ~12 minecraft:light_gray_concrete
fill ~19 ~-40 ~12 ~31 ~-40 ~12 minecraft:air
setblock ~32 ~-40 ~12 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~12 ~35 ~-40 ~12 minecraft:air
setblock ~36 ~-40 ~12 minecraft:light_gray_concrete
fill ~37 ~-40 ~12 ~39 ~-40 ~12 minecraft:air
setblock ~40 ~-40 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~12 ~43 ~-40 ~12 minecraft:air
setblock ~44 ~-40 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~12 ~47 ~-40 ~12 minecraft:air
setblock ~48 ~-40 ~12 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~12 minecraft:air
setblock ~50 ~-40 ~12 minecraft:light_gray_concrete
fill ~51 ~-40 ~12 ~62 ~-40 ~12 minecraft:air
setblock ~63 ~-40 ~12 minecraft:iron_block
setblock ~64 ~-40 ~12 minecraft:light_gray_concrete
setblock ~4 ~-40 ~13 minecraft:light_gray_concrete
fill ~5 ~-40 ~13 ~17 ~-40 ~13 minecraft:air
setblock ~18 ~-40 ~13 minecraft:light_gray_concrete
fill ~19 ~-40 ~13 ~31 ~-40 ~13 minecraft:air
setblock ~32 ~-40 ~13 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~13 ~35 ~-40 ~13 minecraft:air
setblock ~36 ~-40 ~13 minecraft:light_gray_concrete
fill ~37 ~-40 ~13 ~39 ~-40 ~13 minecraft:air
setblock ~40 ~-40 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~13 ~43 ~-40 ~13 minecraft:air
setblock ~44 ~-40 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~13 ~47 ~-40 ~13 minecraft:air
setblock ~48 ~-40 ~13 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~13 minecraft:air
setblock ~50 ~-40 ~13 minecraft:light_gray_concrete
setblock ~51 ~-40 ~13 minecraft:iron_block
fill ~52 ~-40 ~13 ~62 ~-40 ~13 minecraft:air
setblock ~63 ~-40 ~13 minecraft:iron_block
setblock ~64 ~-40 ~13 minecraft:light_gray_concrete
setblock ~4 ~-40 ~14 minecraft:light_gray_concrete
fill ~5 ~-40 ~14 ~17 ~-40 ~14 minecraft:air
setblock ~18 ~-40 ~14 minecraft:light_gray_concrete
fill ~19 ~-40 ~14 ~31 ~-40 ~14 minecraft:air
setblock ~32 ~-40 ~14 minecraft:light_gray_concrete
fill ~33 ~-40 ~14 ~35 ~-40 ~14 minecraft:air
setblock ~36 ~-40 ~14 minecraft:light_gray_concrete
fill ~37 ~-40 ~14 ~39 ~-40 ~14 minecraft:air
setblock ~40 ~-40 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~14 ~43 ~-40 ~14 minecraft:air
setblock ~44 ~-40 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~14 ~47 ~-40 ~14 minecraft:air
setblock ~48 ~-40 ~14 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~14 minecraft:air
setblock ~50 ~-40 ~14 minecraft:light_gray_concrete
setblock ~51 ~-40 ~14 minecraft:iron_block
fill ~52 ~-40 ~14 ~62 ~-40 ~14 minecraft:air
setblock ~63 ~-40 ~14 minecraft:iron_block
setblock ~64 ~-40 ~14 minecraft:light_gray_concrete
setblock ~4 ~-40 ~15 minecraft:light_gray_concrete
fill ~5 ~-40 ~15 ~17 ~-40 ~15 minecraft:air
setblock ~18 ~-40 ~15 minecraft:light_gray_concrete
fill ~19 ~-40 ~15 ~31 ~-40 ~15 minecraft:air
setblock ~32 ~-40 ~15 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~15 ~35 ~-40 ~15 minecraft:air
setblock ~36 ~-40 ~15 minecraft:light_gray_concrete
fill ~37 ~-40 ~15 ~39 ~-40 ~15 minecraft:air
setblock ~40 ~-40 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~15 ~43 ~-40 ~15 minecraft:air
setblock ~44 ~-40 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~15 ~47 ~-40 ~15 minecraft:air
setblock ~48 ~-40 ~15 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~15 minecraft:air
setblock ~50 ~-40 ~15 minecraft:light_gray_concrete
setblock ~51 ~-40 ~15 minecraft:iron_block
fill ~52 ~-40 ~15 ~62 ~-40 ~15 minecraft:air
setblock ~63 ~-40 ~15 minecraft:iron_block
setblock ~64 ~-40 ~15 minecraft:light_gray_concrete
setblock ~4 ~-40 ~16 minecraft:light_gray_concrete
fill ~5 ~-40 ~16 ~17 ~-40 ~16 minecraft:air
setblock ~18 ~-40 ~16 minecraft:light_gray_concrete
fill ~19 ~-40 ~16 ~31 ~-40 ~16 minecraft:air
setblock ~32 ~-40 ~16 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~16 ~35 ~-40 ~16 minecraft:air
setblock ~36 ~-40 ~16 minecraft:light_gray_concrete
fill ~37 ~-40 ~16 ~39 ~-40 ~16 minecraft:air
setblock ~40 ~-40 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~16 ~43 ~-40 ~16 minecraft:air
setblock ~44 ~-40 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~16 ~47 ~-40 ~16 minecraft:air
setblock ~48 ~-40 ~16 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~16 minecraft:air
setblock ~50 ~-40 ~16 minecraft:light_gray_concrete
setblock ~51 ~-40 ~16 minecraft:iron_block
fill ~52 ~-40 ~16 ~62 ~-40 ~16 minecraft:air
setblock ~63 ~-40 ~16 minecraft:iron_block
setblock ~64 ~-40 ~16 minecraft:light_gray_concrete
setblock ~4 ~-40 ~17 minecraft:light_gray_concrete
fill ~5 ~-40 ~17 ~17 ~-40 ~17 minecraft:air
setblock ~18 ~-40 ~17 minecraft:light_gray_concrete
fill ~19 ~-40 ~17 ~31 ~-40 ~17 minecraft:air
setblock ~32 ~-40 ~17 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~17 ~35 ~-40 ~17 minecraft:air
setblock ~36 ~-40 ~17 minecraft:light_gray_concrete
fill ~37 ~-40 ~17 ~39 ~-40 ~17 minecraft:air
setblock ~40 ~-40 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~41 ~-40 ~17 ~43 ~-40 ~17 minecraft:air
setblock ~44 ~-40 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
fill ~45 ~-40 ~17 ~47 ~-40 ~17 minecraft:air
setblock ~48 ~-40 ~17 minecraft:red_stained_glass_pane[north=true,south=true]
setblock ~49 ~-40 ~17 minecraft:air
setblock ~50 ~-40 ~17 minecraft:light_gray_concrete
fill ~51 ~-40 ~17 ~55 ~-40 ~17 minecraft:iron_block
fill ~56 ~-40 ~17 ~58 ~-40 ~17 minecraft:air
fill ~59 ~-40 ~17 ~63 ~-40 ~17 minecraft:iron_block
setblock ~64 ~-40 ~17 minecraft:light_gray_concrete
fill ~4 ~-40 ~18 ~32 ~-40 ~18 minecraft:light_gray_concrete
fill ~33 ~-40 ~18 ~35 ~-40 ~18 minecraft:air
fill ~36 ~-40 ~18 ~64 ~-40 ~18 minecraft:light_gray_concrete
setblock ~4 ~-40 ~19 minecraft:light_gray_concrete
setblock ~5 ~-40 ~19 minecraft:air
setblock ~6 ~-40 ~19 minecraft:waxed_cut_copper
fill ~7 ~-40 ~19 ~8 ~-40 ~19 minecraft:air
setblock ~9 ~-40 ~19 minecraft:waxed_cut_copper
fill ~10 ~-40 ~19 ~14 ~-40 ~19 minecraft:air
setblock ~15 ~-40 ~19 minecraft:waxed_cut_copper
fill ~16 ~-40 ~19 ~17 ~-40 ~19 minecraft:air
setblock ~18 ~-40 ~19 minecraft:light_gray_concrete
fill ~19 ~-40 ~19 ~30 ~-40 ~19 minecraft:black_concrete
setblock ~31 ~-40 ~19 minecraft:air
setblock ~32 ~-40 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~19 ~35 ~-40 ~19 minecraft:air
setblock ~36 ~-40 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-40 ~19 ~49 ~-40 ~19 minecraft:air
setblock ~50 ~-40 ~19 minecraft:light_gray_concrete
fill ~51 ~-40 ~19 ~63 ~-40 ~19 minecraft:air
setblock ~64 ~-40 ~19 minecraft:light_gray_concrete
setblock ~4 ~-40 ~20 minecraft:light_gray_concrete
setblock ~5 ~-40 ~20 minecraft:waxed_cut_copper
fill ~6 ~-40 ~20 ~16 ~-40 ~20 minecraft:air
setblock ~17 ~-40 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-40 ~20 minecraft:light_gray_concrete
fill ~19 ~-40 ~20 ~31 ~-40 ~20 minecraft:air
setblock ~32 ~-40 ~20 minecraft:light_gray_concrete
fill ~33 ~-40 ~20 ~35 ~-40 ~20 minecraft:air
setblock ~36 ~-40 ~20 minecraft:light_gray_concrete
fill ~37 ~-40 ~20 ~49 ~-40 ~20 minecraft:air
setblock ~50 ~-40 ~20 minecraft:light_gray_concrete
fill ~51 ~-40 ~20 ~63 ~-40 ~20 minecraft:air
setblock ~64 ~-40 ~20 minecraft:light_gray_concrete
setblock ~4 ~-40 ~21 minecraft:light_gray_concrete
fill ~5 ~-40 ~21 ~17 ~-40 ~21 minecraft:air
setblock ~18 ~-40 ~21 minecraft:light_gray_concrete
fill ~19 ~-40 ~21 ~31 ~-40 ~21 minecraft:air
setblock ~32 ~-40 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~21 ~35 ~-40 ~21 minecraft:air
setblock ~36 ~-40 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-40 ~21 ~49 ~-40 ~21 minecraft:air
setblock ~50 ~-40 ~21 minecraft:light_gray_concrete
fill ~51 ~-40 ~21 ~63 ~-40 ~21 minecraft:air
setblock ~64 ~-40 ~21 minecraft:light_gray_concrete
setblock ~4 ~-40 ~22 minecraft:light_gray_concrete
fill ~5 ~-40 ~22 ~17 ~-40 ~22 minecraft:air
setblock ~18 ~-40 ~22 minecraft:light_gray_concrete
fill ~19 ~-40 ~22 ~28 ~-40 ~22 minecraft:air
setblock ~29 ~-40 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-40 ~22 minecraft:quartz_pillar
setblock ~31 ~-40 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-40 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-40 ~22 ~35 ~-40 ~22 minecraft:air
setblock ~36 ~-40 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-40 ~22 ~38 ~-40 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-40 ~22 minecraft:quartz_pillar
fill ~40 ~-40 ~22 ~49 ~-40 ~22 minecraft:air
setblock ~50 ~-40 ~22 minecraft:light_gray_concrete
fill ~51 ~-40 ~22 ~63 ~-40 ~22 minecraft:air
setblock ~64 ~-40 ~22 minecraft:light_gray_concrete
setblock ~4 ~-40 ~23 minecraft:light_gray_concrete
setblock ~5 ~-40 ~23 minecraft:waxed_cut_copper
fill ~6 ~-40 ~23 ~16 ~-40 ~23 minecraft:air
setblock ~17 ~-40 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-40 ~23 minecraft:light_gray_concrete
fill ~19 ~-40 ~23 ~27 ~-40 ~23 minecraft:air
setblock ~28 ~-40 ~23 minecraft:smooth_quartz
setblock ~29 ~-40 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-40 ~23 ~38 ~-40 ~23 minecraft:air
setblock ~39 ~-40 ~23 minecraft:quartz_pillar
setblock ~40 ~-40 ~23 minecraft:smooth_quartz
fill ~41 ~-40 ~23 ~49 ~-40 ~23 minecraft:air
setblock ~50 ~-40 ~23 minecraft:light_gray_concrete
fill ~51 ~-40 ~23 ~63 ~-40 ~23 minecraft:air
setblock ~64 ~-40 ~23 minecraft:light_gray_concrete
setblock ~4 ~-40 ~24 minecraft:light_gray_concrete
fill ~5 ~-40 ~24 ~17 ~-40 ~24 minecraft:air
setblock ~18 ~-40 ~24 minecraft:light_gray_concrete
fill ~19 ~-40 ~24 ~25 ~-40 ~24 minecraft:air
setblock ~26 ~-40 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-40 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-40 ~24 ~29 ~-40 ~24 minecraft:air
setblock ~30 ~-40 ~24 minecraft:quartz_pillar
fill ~31 ~-40 ~24 ~37 ~-40 ~24 minecraft:air
setblock ~38 ~-40 ~24 minecraft:quartz_pillar
fill ~39 ~-40 ~24 ~40 ~-40 ~24 minecraft:air
setblock ~41 ~-40 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-40 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-40 ~24 ~49 ~-40 ~24 minecraft:air
setblock ~50 ~-40 ~24 minecraft:light_gray_concrete
fill ~51 ~-40 ~24 ~63 ~-40 ~24 minecraft:air
setblock ~64 ~-40 ~24 minecraft:light_gray_concrete
setblock ~4 ~-40 ~25 minecraft:light_gray_concrete
fill ~5 ~-40 ~25 ~17 ~-40 ~25 minecraft:air
setblock ~18 ~-40 ~25 minecraft:light_gray_concrete
fill ~19 ~-40 ~25 ~24 ~-40 ~25 minecraft:air
fill ~25 ~-40 ~25 ~26 ~-40 ~25 minecraft:quartz_pillar
fill ~27 ~-40 ~25 ~41 ~-40 ~25 minecraft:air
setblock ~42 ~-40 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-40 ~25 minecraft:quartz_pillar
fill ~44 ~-40 ~25 ~49 ~-40 ~25 minecraft:air
setblock ~50 ~-40 ~25 minecraft:light_gray_concrete
fill ~51 ~-40 ~25 ~63 ~-40 ~25 minecraft:air
setblock ~64 ~-40 ~25 minecraft:light_gray_concrete
setblock ~4 ~-40 ~26 minecraft:light_gray_concrete
setblock ~5 ~-40 ~26 minecraft:waxed_cut_copper
fill ~6 ~-40 ~26 ~16 ~-40 ~26 minecraft:air
setblock ~17 ~-40 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-40 ~26 minecraft:light_gray_concrete
fill ~19 ~-40 ~26 ~23 ~-40 ~26 minecraft:air
setblock ~24 ~-40 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-40 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-40 ~26 ~42 ~-40 ~26 minecraft:air
setblock ~43 ~-40 ~26 minecraft:quartz_pillar
setblock ~44 ~-40 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-40 ~26 ~49 ~-40 ~26 minecraft:air
setblock ~50 ~-40 ~26 minecraft:light_gray_concrete
fill ~51 ~-40 ~26 ~63 ~-40 ~26 minecraft:air
setblock ~64 ~-40 ~26 minecraft:light_gray_concrete
setblock ~4 ~-40 ~27 minecraft:light_gray_concrete
fill ~5 ~-40 ~27 ~17 ~-40 ~27 minecraft:air
setblock ~18 ~-40 ~27 minecraft:light_gray_concrete
fill ~19 ~-40 ~27 ~23 ~-40 ~27 minecraft:air
setblock ~24 ~-40 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-40 ~27 ~43 ~-40 ~27 minecraft:air
setblock ~44 ~-40 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-40 ~27 ~49 ~-40 ~27 minecraft:air
setblock ~50 ~-40 ~27 minecraft:light_gray_concrete
fill ~51 ~-40 ~27 ~63 ~-40 ~27 minecraft:air
setblock ~64 ~-40 ~27 minecraft:light_gray_concrete
setblock ~4 ~-40 ~28 minecraft:light_gray_concrete
fill ~5 ~-40 ~28 ~17 ~-40 ~28 minecraft:air
setblock ~18 ~-40 ~28 minecraft:light_gray_concrete
fill ~19 ~-40 ~28 ~22 ~-40 ~28 minecraft:air
setblock ~23 ~-40 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-40 ~28 ~44 ~-40 ~28 minecraft:air
setblock ~45 ~-40 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-40 ~28 ~49 ~-40 ~28 minecraft:air
setblock ~50 ~-40 ~28 minecraft:light_gray_concrete
fill ~51 ~-40 ~28 ~63 ~-40 ~28 minecraft:air
setblock ~64 ~-40 ~28 minecraft:light_gray_concrete
setblock ~4 ~-40 ~29 minecraft:light_gray_concrete
setblock ~5 ~-40 ~29 minecraft:waxed_cut_copper
fill ~6 ~-40 ~29 ~16 ~-40 ~29 minecraft:air
setblock ~17 ~-40 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-40 ~29 minecraft:light_gray_concrete
fill ~19 ~-40 ~29 ~21 ~-40 ~29 minecraft:air
fill ~22 ~-40 ~29 ~23 ~-40 ~29 minecraft:quartz_pillar
fill ~24 ~-40 ~29 ~44 ~-40 ~29 minecraft:air
setblock ~45 ~-40 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-40 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-40 ~29 ~49 ~-40 ~29 minecraft:air
setblock ~50 ~-40 ~29 minecraft:light_gray_concrete
fill ~51 ~-40 ~29 ~63 ~-40 ~29 minecraft:air
setblock ~64 ~-40 ~29 minecraft:light_gray_concrete
setblock ~4 ~-40 ~30 minecraft:light_gray_concrete
fill ~5 ~-40 ~30 ~17 ~-40 ~30 minecraft:air
setblock ~18 ~-40 ~30 minecraft:light_gray_concrete
fill ~19 ~-40 ~30 ~21 ~-40 ~30 minecraft:air
setblock ~22 ~-40 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-40 ~30 minecraft:air
setblock ~24 ~-40 ~30 minecraft:quartz_pillar
fill ~25 ~-40 ~30 ~43 ~-40 ~30 minecraft:air
setblock ~44 ~-40 ~30 minecraft:quartz_pillar
setblock ~45 ~-40 ~30 minecraft:air
setblock ~46 ~-40 ~30 minecraft:quartz_pillar
fill ~47 ~-40 ~30 ~49 ~-40 ~30 minecraft:air
setblock ~50 ~-40 ~30 minecraft:light_gray_concrete
fill ~51 ~-40 ~30 ~63 ~-40 ~30 minecraft:air
setblock ~64 ~-40 ~30 minecraft:light_gray_concrete
setblock ~4 ~-40 ~31 minecraft:light_gray_concrete
setblock ~5 ~-40 ~31 minecraft:air
setblock ~6 ~-40 ~31 minecraft:waxed_cut_copper
fill ~7 ~-40 ~31 ~8 ~-40 ~31 minecraft:air
setblock ~9 ~-40 ~31 minecraft:waxed_cut_copper
fill ~10 ~-40 ~31 ~14 ~-40 ~31 minecraft:air
setblock ~15 ~-40 ~31 minecraft:waxed_cut_copper
fill ~16 ~-40 ~31 ~17 ~-40 ~31 minecraft:air
setblock ~18 ~-40 ~31 minecraft:light_gray_concrete
fill ~19 ~-40 ~31 ~21 ~-40 ~31 minecraft:air
setblock ~22 ~-40 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-40 ~31 ~45 ~-40 ~31 minecraft:air
setblock ~46 ~-40 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-40 ~31 ~49 ~-40 ~31 minecraft:air
setblock ~50 ~-40 ~31 minecraft:light_gray_concrete
fill ~51 ~-40 ~31 ~63 ~-40 ~31 minecraft:air
setblock ~64 ~-40 ~31 minecraft:light_gray_concrete
fill ~4 ~-40 ~32 ~18 ~-40 ~32 minecraft:light_gray_concrete
setblock ~19 ~-40 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-40 ~32 minecraft:light_gray_concrete
setblock ~21 ~-40 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-40 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-40 ~32 ~32 ~-40 ~32 minecraft:air
fill ~33 ~-40 ~32 ~35 ~-40 ~32 minecraft:glass
fill ~36 ~-40 ~32 ~45 ~-40 ~32 minecraft:air
setblock ~46 ~-40 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-40 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-40 ~32 minecraft:light_gray_concrete
setblock ~49 ~-40 ~32 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-40 ~32 ~64 ~-40 ~32 minecraft:light_gray_concrete
setblock ~4 ~-40 ~33 minecraft:light_gray_concrete
fill ~5 ~-40 ~33 ~32 ~-40 ~33 minecraft:air
setblock ~33 ~-40 ~33 minecraft:glass
setblock ~34 ~-40 ~33 minecraft:air
setblock ~35 ~-40 ~33 minecraft:glass
fill ~36 ~-40 ~33 ~63 ~-40 ~33 minecraft:air
setblock ~64 ~-40 ~33 minecraft:light_gray_concrete
setblock ~4 ~-40 ~34 minecraft:light_gray_concrete
fill ~5 ~-40 ~34 ~32 ~-40 ~34 minecraft:air
fill ~33 ~-40 ~34 ~35 ~-40 ~34 minecraft:glass
fill ~36 ~-40 ~34 ~63 ~-40 ~34 minecraft:air
setblock ~64 ~-40 ~34 minecraft:light_gray_concrete
setblock ~4 ~-40 ~35 minecraft:light_gray_concrete
fill ~5 ~-40 ~35 ~32 ~-40 ~35 minecraft:air
setblock ~33 ~-40 ~35 minecraft:glass
setblock ~34 ~-40 ~35 minecraft:air
setblock ~35 ~-40 ~35 minecraft:glass
fill ~36 ~-40 ~35 ~63 ~-40 ~35 minecraft:air
setblock ~64 ~-40 ~35 minecraft:light_gray_concrete
fill ~4 ~-40 ~36 ~18 ~-40 ~36 minecraft:light_gray_concrete
setblock ~19 ~-40 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-40 ~36 minecraft:light_gray_concrete
setblock ~21 ~-40 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-40 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-40 ~36 ~32 ~-40 ~36 minecraft:air
fill ~33 ~-40 ~36 ~35 ~-40 ~36 minecraft:glass
fill ~36 ~-40 ~36 ~45 ~-40 ~36 minecraft:air
setblock ~46 ~-40 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-40 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-40 ~36 minecraft:light_gray_concrete
setblock ~49 ~-40 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-40 ~36 ~64 ~-40 ~36 minecraft:light_gray_concrete
setblock ~4 ~-40 ~37 minecraft:light_gray_concrete
fill ~5 ~-40 ~37 ~17 ~-40 ~37 minecraft:air
setblock ~18 ~-40 ~37 minecraft:light_gray_concrete
fill ~19 ~-40 ~37 ~21 ~-40 ~37 minecraft:air
setblock ~22 ~-40 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-40 ~37 ~45 ~-40 ~37 minecraft:air
setblock ~46 ~-40 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-40 ~37 ~49 ~-40 ~37 minecraft:air
setblock ~50 ~-40 ~37 minecraft:light_gray_concrete
fill ~51 ~-40 ~37 ~63 ~-40 ~37 minecraft:air
setblock ~64 ~-40 ~37 minecraft:light_gray_concrete
setblock ~4 ~-40 ~38 minecraft:light_gray_concrete
fill ~5 ~-40 ~38 ~17 ~-40 ~38 minecraft:air
setblock ~18 ~-40 ~38 minecraft:light_gray_concrete
fill ~19 ~-40 ~38 ~21 ~-40 ~38 minecraft:air
setblock ~22 ~-40 ~38 minecraft:quartz_pillar
setblock ~23 ~-40 ~38 minecraft:air
setblock ~24 ~-40 ~38 minecraft:quartz_pillar
fill ~25 ~-40 ~38 ~43 ~-40 ~38 minecraft:air
setblock ~44 ~-40 ~38 minecraft:quartz_pillar
setblock ~45 ~-40 ~38 minecraft:air
setblock ~46 ~-40 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-40 ~38 ~49 ~-40 ~38 minecraft:air
setblock ~50 ~-40 ~38 minecraft:light_gray_concrete
fill ~51 ~-40 ~38 ~63 ~-40 ~38 minecraft:air
setblock ~64 ~-40 ~38 minecraft:light_gray_concrete
setblock ~4 ~-40 ~39 minecraft:light_gray_concrete
fill ~5 ~-40 ~39 ~17 ~-40 ~39 minecraft:air
setblock ~18 ~-40 ~39 minecraft:light_gray_concrete
fill ~19 ~-40 ~39 ~21 ~-40 ~39 minecraft:air
setblock ~22 ~-40 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-40 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-40 ~39 ~44 ~-40 ~39 minecraft:air
fill ~45 ~-40 ~39 ~46 ~-40 ~39 minecraft:quartz_pillar
fill ~47 ~-40 ~39 ~49 ~-40 ~39 minecraft:air
setblock ~50 ~-40 ~39 minecraft:light_gray_concrete
fill ~51 ~-40 ~39 ~63 ~-40 ~39 minecraft:air
setblock ~64 ~-40 ~39 minecraft:light_gray_concrete
setblock ~4 ~-40 ~40 minecraft:light_gray_concrete
fill ~5 ~-40 ~40 ~17 ~-40 ~40 minecraft:air
setblock ~18 ~-40 ~40 minecraft:light_gray_concrete
fill ~19 ~-40 ~40 ~22 ~-40 ~40 minecraft:air
setblock ~23 ~-40 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-40 ~40 ~44 ~-40 ~40 minecraft:air
setblock ~45 ~-40 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-40 ~40 ~49 ~-40 ~40 minecraft:air
setblock ~50 ~-40 ~40 minecraft:light_gray_concrete
fill ~51 ~-40 ~40 ~63 ~-40 ~40 minecraft:air
setblock ~64 ~-40 ~40 minecraft:light_gray_concrete
setblock ~4 ~-40 ~41 minecraft:light_gray_concrete
fill ~5 ~-40 ~41 ~17 ~-40 ~41 minecraft:air
setblock ~18 ~-40 ~41 minecraft:light_gray_concrete
fill ~19 ~-40 ~41 ~23 ~-40 ~41 minecraft:air
setblock ~24 ~-40 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-40 ~41 ~43 ~-40 ~41 minecraft:air
setblock ~44 ~-40 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-40 ~41 ~49 ~-40 ~41 minecraft:air
setblock ~50 ~-40 ~41 minecraft:light_gray_concrete
fill ~51 ~-40 ~41 ~63 ~-40 ~41 minecraft:air
setblock ~64 ~-40 ~41 minecraft:light_gray_concrete
setblock ~4 ~-40 ~42 minecraft:light_gray_concrete
setblock ~5 ~-40 ~42 minecraft:black_concrete
fill ~6 ~-40 ~42 ~17 ~-40 ~42 minecraft:air
setblock ~18 ~-40 ~42 minecraft:light_gray_concrete
fill ~19 ~-40 ~42 ~23 ~-40 ~42 minecraft:air
setblock ~24 ~-40 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-40 ~42 minecraft:quartz_pillar
fill ~26 ~-40 ~42 ~42 ~-40 ~42 minecraft:air
setblock ~43 ~-40 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-40 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-40 ~42 ~49 ~-40 ~42 minecraft:air
setblock ~50 ~-40 ~42 minecraft:light_gray_concrete
fill ~51 ~-40 ~42 ~63 ~-40 ~42 minecraft:air
setblock ~64 ~-40 ~42 minecraft:light_gray_concrete
setblock ~4 ~-40 ~43 minecraft:light_gray_concrete
setblock ~5 ~-40 ~43 minecraft:black_concrete
fill ~6 ~-40 ~43 ~17 ~-40 ~43 minecraft:air
setblock ~18 ~-40 ~43 minecraft:light_gray_concrete
fill ~19 ~-40 ~43 ~24 ~-40 ~43 minecraft:air
setblock ~25 ~-40 ~43 minecraft:quartz_pillar
setblock ~26 ~-40 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-40 ~43 ~41 ~-40 ~43 minecraft:air
fill ~42 ~-40 ~43 ~43 ~-40 ~43 minecraft:quartz_pillar
fill ~44 ~-40 ~43 ~49 ~-40 ~43 minecraft:air
setblock ~50 ~-40 ~43 minecraft:light_gray_concrete
fill ~51 ~-40 ~43 ~63 ~-40 ~43 minecraft:air
setblock ~64 ~-40 ~43 minecraft:light_gray_concrete
setblock ~4 ~-40 ~44 minecraft:light_gray_concrete
setblock ~5 ~-40 ~44 minecraft:black_concrete
fill ~6 ~-40 ~44 ~17 ~-40 ~44 minecraft:air
setblock ~18 ~-40 ~44 minecraft:light_gray_concrete
fill ~19 ~-40 ~44 ~25 ~-40 ~44 minecraft:air
setblock ~26 ~-40 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-40 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-40 ~44 ~29 ~-40 ~44 minecraft:air
setblock ~30 ~-40 ~44 minecraft:quartz_pillar
fill ~31 ~-40 ~44 ~37 ~-40 ~44 minecraft:air
setblock ~38 ~-40 ~44 minecraft:quartz_pillar
fill ~39 ~-40 ~44 ~40 ~-40 ~44 minecraft:air
setblock ~41 ~-40 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-40 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-40 ~44 ~49 ~-40 ~44 minecraft:air
setblock ~50 ~-40 ~44 minecraft:light_gray_concrete
fill ~51 ~-40 ~44 ~63 ~-40 ~44 minecraft:air
setblock ~64 ~-40 ~44 minecraft:light_gray_concrete
setblock ~4 ~-40 ~45 minecraft:light_gray_concrete
fill ~5 ~-40 ~45 ~17 ~-40 ~45 minecraft:air
setblock ~18 ~-40 ~45 minecraft:light_gray_concrete
fill ~19 ~-40 ~45 ~27 ~-40 ~45 minecraft:air
setblock ~28 ~-40 ~45 minecraft:smooth_quartz
setblock ~29 ~-40 ~45 minecraft:quartz_pillar
fill ~30 ~-40 ~45 ~38 ~-40 ~45 minecraft:air
setblock ~39 ~-40 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-40 ~45 minecraft:smooth_quartz
fill ~41 ~-40 ~45 ~49 ~-40 ~45 minecraft:air
setblock ~50 ~-40 ~45 minecraft:light_gray_concrete
fill ~51 ~-40 ~45 ~63 ~-40 ~45 minecraft:air
setblock ~64 ~-40 ~45 minecraft:light_gray_concrete
setblock ~4 ~-40 ~46 minecraft:light_gray_concrete
fill ~5 ~-40 ~46 ~17 ~-40 ~46 minecraft:air
setblock ~18 ~-40 ~46 minecraft:light_gray_concrete
fill ~19 ~-40 ~46 ~28 ~-40 ~46 minecraft:air
setblock ~29 ~-40 ~46 minecraft:quartz_pillar
fill ~30 ~-40 ~46 ~31 ~-40 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-40 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-40 ~46 ~35 ~-40 ~46 minecraft:air
setblock ~36 ~-40 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-40 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-40 ~46 minecraft:quartz_pillar
setblock ~39 ~-40 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-40 ~46 ~49 ~-40 ~46 minecraft:air
setblock ~50 ~-40 ~46 minecraft:light_gray_concrete
fill ~51 ~-40 ~46 ~63 ~-40 ~46 minecraft:air
setblock ~64 ~-40 ~46 minecraft:light_gray_concrete
setblock ~4 ~-40 ~47 minecraft:light_gray_concrete
fill ~5 ~-40 ~47 ~17 ~-40 ~47 minecraft:air
setblock ~18 ~-40 ~47 minecraft:light_gray_concrete
fill ~19 ~-40 ~47 ~31 ~-40 ~47 minecraft:air
setblock ~32 ~-40 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~47 ~35 ~-40 ~47 minecraft:air
setblock ~36 ~-40 ~47 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-40 ~47 ~49 ~-40 ~47 minecraft:air
setblock ~50 ~-40 ~47 minecraft:light_gray_concrete
fill ~51 ~-40 ~47 ~63 ~-40 ~47 minecraft:air
setblock ~64 ~-40 ~47 minecraft:light_gray_concrete
setblock ~4 ~-40 ~48 minecraft:light_gray_concrete
fill ~5 ~-40 ~48 ~17 ~-40 ~48 minecraft:air
setblock ~18 ~-40 ~48 minecraft:light_gray_concrete
fill ~19 ~-40 ~48 ~31 ~-40 ~48 minecraft:air
setblock ~32 ~-40 ~48 minecraft:light_gray_concrete
fill ~33 ~-40 ~48 ~35 ~-40 ~48 minecraft:air
setblock ~36 ~-40 ~48 minecraft:light_gray_concrete
fill ~37 ~-40 ~48 ~49 ~-40 ~48 minecraft:air
setblock ~50 ~-40 ~48 minecraft:light_gray_concrete
fill ~51 ~-40 ~48 ~63 ~-40 ~48 minecraft:air
setblock ~64 ~-40 ~48 minecraft:light_gray_concrete
setblock ~4 ~-40 ~49 minecraft:light_gray_concrete
fill ~5 ~-40 ~49 ~17 ~-40 ~49 minecraft:air
setblock ~18 ~-40 ~49 minecraft:light_gray_concrete
fill ~19 ~-40 ~49 ~30 ~-40 ~49 minecraft:black_concrete
setblock ~31 ~-40 ~49 minecraft:air
setblock ~32 ~-40 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-40 ~49 ~35 ~-40 ~49 minecraft:air
setblock ~36 ~-40 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-40 ~49 ~49 ~-40 ~49 minecraft:air
setblock ~50 ~-40 ~49 minecraft:light_gray_concrete
fill ~51 ~-40 ~49 ~63 ~-40 ~49 minecraft:air
setblock ~64 ~-40 ~49 minecraft:light_gray_concrete
fill ~4 ~-40 ~50 ~32 ~-40 ~50 minecraft:light_gray_concrete
fill ~33 ~-40 ~50 ~35 ~-40 ~50 minecraft:air
fill ~36 ~-40 ~50 ~64 ~-40 ~50 minecraft:light_gray_concrete
setblock ~4 ~-40 ~51 minecraft:light_gray_concrete
fill ~5 ~-40 ~51 ~17 ~-40 ~51 minecraft:air
setblock ~18 ~-40 ~51 minecraft:light_gray_concrete
setblock ~19 ~-40 ~51 minecraft:waxed_cut_copper
fill ~20 ~-40 ~51 ~21 ~-40 ~51 minecraft:air
setblock ~22 ~-40 ~51 minecraft:waxed_cut_copper
fill ~23 ~-40 ~51 ~24 ~-40 ~51 minecraft:air
setblock ~25 ~-40 ~51 minecraft:waxed_cut_copper
fill ~26 ~-40 ~51 ~27 ~-40 ~51 minecraft:air
setblock ~28 ~-40 ~51 minecraft:waxed_cut_copper
fill ~29 ~-40 ~51 ~30 ~-40 ~51 minecraft:air
setblock ~31 ~-40 ~51 minecraft:waxed_cut_copper
setblock ~32 ~-40 ~51 minecraft:light_gray_concrete
fill ~33 ~-40 ~51 ~35 ~-40 ~51 minecraft:air
setblock ~36 ~-40 ~51 minecraft:light_gray_concrete
fill ~37 ~-40 ~51 ~49 ~-40 ~51 minecraft:air
setblock ~50 ~-40 ~51 minecraft:light_gray_concrete
fill ~51 ~-40 ~51 ~63 ~-40 ~51 minecraft:air
setblock ~64 ~-40 ~51 minecraft:light_gray_concrete
setblock ~4 ~-40 ~52 minecraft:light_gray_concrete
fill ~5 ~-40 ~52 ~17 ~-40 ~52 minecraft:air
setblock ~18 ~-40 ~52 minecraft:light_gray_concrete
fill ~19 ~-40 ~52 ~31 ~-40 ~52 minecraft:air
setblock ~32 ~-40 ~52 minecraft:light_gray_concrete
fill ~33 ~-40 ~52 ~35 ~-40 ~52 minecraft:air
setblock ~36 ~-40 ~52 minecraft:light_gray_concrete
fill ~37 ~-40 ~52 ~49 ~-40 ~52 minecraft:air
setblock ~50 ~-40 ~52 minecraft:light_gray_concrete
fill ~51 ~-40 ~52 ~63 ~-40 ~52 minecraft:air
setblock ~64 ~-40 ~52 minecraft:light_gray_concrete
setblock ~4 ~-40 ~53 minecraft:light_gray_concrete
fill ~5 ~-40 ~53 ~17 ~-40 ~53 minecraft:air
setblock ~18 ~-40 ~53 minecraft:light_gray_concrete
fill ~19 ~-40 ~53 ~31 ~-40 ~53 minecraft:air
setblock ~32 ~-40 ~53 minecraft:light_gray_concrete
fill ~33 ~-40 ~53 ~35 ~-40 ~53 minecraft:air
setblock ~36 ~-40 ~53 minecraft:light_gray_concrete
fill ~37 ~-40 ~53 ~49 ~-40 ~53 minecraft:air
setblock ~50 ~-40 ~53 minecraft:light_gray_concrete
fill ~51 ~-40 ~53 ~63 ~-40 ~53 minecraft:air
setblock ~64 ~-40 ~53 minecraft:light_gray_concrete
setblock ~4 ~-40 ~54 minecraft:light_gray_concrete
fill ~5 ~-40 ~54 ~17 ~-40 ~54 minecraft:air
setblock ~18 ~-40 ~54 minecraft:light_gray_concrete
setblock ~19 ~-40 ~54 minecraft:waxed_cut_copper
fill ~20 ~-40 ~54 ~30 ~-40 ~54 minecraft:air
setblock ~31 ~-40 ~54 minecraft:waxed_cut_copper
setblock ~32 ~-40 ~54 minecraft:light_gray_concrete
fill ~33 ~-40 ~54 ~35 ~-40 ~54 minecraft:air
setblock ~36 ~-40 ~54 minecraft:light_gray_concrete
fill ~37 ~-40 ~54 ~49 ~-40 ~54 minecraft:air
setblock ~50 ~-40 ~54 minecraft:light_gray_concrete
fill ~51 ~-40 ~54 ~63 ~-40 ~54 minecraft:air
setblock ~64 ~-40 ~54 minecraft:light_gray_concrete
setblock ~4 ~-40 ~55 minecraft:light_gray_concrete
fill ~5 ~-40 ~55 ~17 ~-40 ~55 minecraft:air
setblock ~18 ~-40 ~55 minecraft:light_gray_concrete
fill ~19 ~-40 ~55 ~31 ~-40 ~55 minecraft:air
setblock ~32 ~-40 ~55 minecraft:light_gray_concrete
fill ~33 ~-40 ~55 ~35 ~-40 ~55 minecraft:air
setblock ~36 ~-40 ~55 minecraft:light_gray_concrete
fill ~37 ~-40 ~55 ~49 ~-40 ~55 minecraft:air
setblock ~50 ~-40 ~55 minecraft:light_gray_concrete
fill ~51 ~-40 ~55 ~63 ~-40 ~55 minecraft:air
setblock ~64 ~-40 ~55 minecraft:light_gray_concrete
setblock ~4 ~-40 ~56 minecraft:light_gray_concrete
fill ~5 ~-40 ~56 ~17 ~-40 ~56 minecraft:air
setblock ~18 ~-40 ~56 minecraft:light_gray_concrete
schedule function hive:weiter/7 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 6 von 18 fertig","color":"gray"}]