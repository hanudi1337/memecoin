fill ~39 ~-69 ~7 ~47 ~-69 ~7 minecraft:polished_deepslate
fill ~53 ~-69 ~7 ~61 ~-69 ~7 minecraft:polished_deepslate
fill ~39 ~-69 ~8 ~47 ~-69 ~8 minecraft:polished_deepslate
fill ~53 ~-69 ~8 ~61 ~-69 ~8 minecraft:polished_deepslate
fill ~39 ~-69 ~9 ~47 ~-69 ~9 minecraft:polished_deepslate
fill ~53 ~-69 ~9 ~61 ~-69 ~9 minecraft:polished_deepslate
fill ~39 ~-69 ~10 ~47 ~-69 ~10 minecraft:polished_deepslate
fill ~53 ~-69 ~10 ~61 ~-69 ~10 minecraft:polished_deepslate
fill ~39 ~-69 ~11 ~47 ~-69 ~11 minecraft:polished_deepslate
fill ~53 ~-69 ~11 ~61 ~-69 ~11 minecraft:polished_deepslate
fill ~39 ~-69 ~12 ~47 ~-69 ~12 minecraft:polished_deepslate
fill ~53 ~-69 ~12 ~61 ~-69 ~12 minecraft:polished_deepslate
fill ~39 ~-69 ~13 ~47 ~-69 ~13 minecraft:polished_deepslate
fill ~53 ~-69 ~13 ~61 ~-69 ~13 minecraft:polished_deepslate
fill ~39 ~-69 ~14 ~47 ~-69 ~14 minecraft:polished_deepslate
fill ~53 ~-69 ~14 ~61 ~-69 ~14 minecraft:polished_deepslate
fill ~39 ~-69 ~15 ~47 ~-69 ~15 minecraft:polished_deepslate
fill ~53 ~-69 ~15 ~61 ~-69 ~15 minecraft:polished_deepslate
fill ~50 ~-69 ~34 ~55 ~-69 ~34 minecraft:polished_deepslate
setblock ~56 ~-69 ~34 minecraft:redstone_block
fill ~57 ~-69 ~34 ~63 ~-69 ~34 minecraft:polished_deepslate
setblock ~64 ~-69 ~34 minecraft:redstone_block
fill ~65 ~-69 ~34 ~68 ~-69 ~34 minecraft:polished_deepslate
fill ~53 ~-69 ~53 ~61 ~-69 ~53 minecraft:polished_deepslate
fill ~53 ~-69 ~54 ~61 ~-69 ~54 minecraft:polished_deepslate
fill ~53 ~-69 ~55 ~61 ~-69 ~55 minecraft:polished_deepslate
fill ~53 ~-69 ~56 ~61 ~-69 ~56 minecraft:polished_deepslate
fill ~53 ~-69 ~57 ~61 ~-69 ~57 minecraft:polished_deepslate
fill ~53 ~-69 ~58 ~61 ~-69 ~58 minecraft:polished_deepslate
fill ~53 ~-69 ~59 ~61 ~-69 ~59 minecraft:polished_deepslate
fill ~53 ~-69 ~60 ~61 ~-69 ~60 minecraft:polished_deepslate
fill ~53 ~-69 ~61 ~61 ~-69 ~61 minecraft:polished_deepslate
fill ~4 ~-68 ~4 ~64 ~-68 ~4 minecraft:deepslate_tiles
setblock ~4 ~-68 ~5 minecraft:deepslate_tiles
fill ~5 ~-68 ~5 ~17 ~-68 ~5 minecraft:polished_deepslate
setblock ~18 ~-68 ~5 minecraft:deepslate_tiles
fill ~19 ~-68 ~5 ~31 ~-68 ~5 minecraft:polished_deepslate
setblock ~32 ~-68 ~5 minecraft:deepslate_tiles
setblock ~33 ~-68 ~5 minecraft:polished_deepslate
setblock ~34 ~-68 ~5 minecraft:yellow_concrete
setblock ~35 ~-68 ~5 minecraft:polished_deepslate
setblock ~36 ~-68 ~5 minecraft:deepslate_tiles
fill ~37 ~-68 ~5 ~49 ~-68 ~5 minecraft:polished_deepslate
setblock ~50 ~-68 ~5 minecraft:deepslate_tiles
fill ~51 ~-68 ~5 ~63 ~-68 ~5 minecraft:polished_deepslate
setblock ~64 ~-68 ~5 minecraft:deepslate_tiles
setblock ~4 ~-68 ~6 minecraft:deepslate_tiles
fill ~5 ~-68 ~6 ~17 ~-68 ~6 minecraft:polished_deepslate
setblock ~18 ~-68 ~6 minecraft:deepslate_tiles
fill ~19 ~-68 ~6 ~31 ~-68 ~6 minecraft:polished_deepslate
setblock ~32 ~-68 ~6 minecraft:deepslate_tiles
setblock ~33 ~-68 ~6 minecraft:polished_deepslate
setblock ~34 ~-68 ~6 minecraft:yellow_concrete
setblock ~35 ~-68 ~6 minecraft:polished_deepslate
setblock ~36 ~-68 ~6 minecraft:deepslate_tiles
fill ~37 ~-68 ~6 ~49 ~-68 ~6 minecraft:polished_deepslate
setblock ~50 ~-68 ~6 minecraft:deepslate_tiles
fill ~51 ~-68 ~6 ~63 ~-68 ~6 minecraft:polished_deepslate
setblock ~64 ~-68 ~6 minecraft:deepslate_tiles
setblock ~4 ~-68 ~7 minecraft:deepslate_tiles
fill ~5 ~-68 ~7 ~17 ~-68 ~7 minecraft:polished_deepslate
setblock ~18 ~-68 ~7 minecraft:deepslate_tiles
fill ~19 ~-68 ~7 ~31 ~-68 ~7 minecraft:polished_deepslate
setblock ~32 ~-68 ~7 minecraft:deepslate_tiles
setblock ~33 ~-68 ~7 minecraft:polished_deepslate
setblock ~34 ~-68 ~7 minecraft:yellow_concrete
setblock ~35 ~-68 ~7 minecraft:polished_deepslate
setblock ~36 ~-68 ~7 minecraft:deepslate_tiles
fill ~37 ~-68 ~7 ~38 ~-68 ~7 minecraft:polished_deepslate
fill ~39 ~-68 ~7 ~47 ~-68 ~7 minecraft:air
fill ~48 ~-68 ~7 ~49 ~-68 ~7 minecraft:polished_deepslate
setblock ~50 ~-68 ~7 minecraft:deepslate_tiles
fill ~51 ~-68 ~7 ~52 ~-68 ~7 minecraft:polished_deepslate
fill ~53 ~-68 ~7 ~61 ~-68 ~7 minecraft:air
fill ~62 ~-68 ~7 ~63 ~-68 ~7 minecraft:polished_deepslate
setblock ~64 ~-68 ~7 minecraft:deepslate_tiles
setblock ~4 ~-68 ~8 minecraft:deepslate_tiles
fill ~5 ~-68 ~8 ~17 ~-68 ~8 minecraft:polished_deepslate
setblock ~18 ~-68 ~8 minecraft:deepslate_tiles
fill ~19 ~-68 ~8 ~31 ~-68 ~8 minecraft:polished_deepslate
setblock ~32 ~-68 ~8 minecraft:deepslate_tiles
setblock ~33 ~-68 ~8 minecraft:polished_deepslate
setblock ~34 ~-68 ~8 minecraft:yellow_concrete
setblock ~35 ~-68 ~8 minecraft:polished_deepslate
setblock ~36 ~-68 ~8 minecraft:deepslate_tiles
fill ~37 ~-68 ~8 ~38 ~-68 ~8 minecraft:polished_deepslate
fill ~39 ~-68 ~8 ~47 ~-68 ~8 minecraft:air
fill ~48 ~-68 ~8 ~49 ~-68 ~8 minecraft:polished_deepslate
setblock ~50 ~-68 ~8 minecraft:deepslate_tiles
fill ~51 ~-68 ~8 ~52 ~-68 ~8 minecraft:polished_deepslate
fill ~53 ~-68 ~8 ~61 ~-68 ~8 minecraft:air
fill ~62 ~-68 ~8 ~63 ~-68 ~8 minecraft:polished_deepslate
setblock ~64 ~-68 ~8 minecraft:deepslate_tiles
setblock ~4 ~-68 ~9 minecraft:deepslate_tiles
fill ~5 ~-68 ~9 ~17 ~-68 ~9 minecraft:polished_deepslate
setblock ~18 ~-68 ~9 minecraft:deepslate_tiles
fill ~19 ~-68 ~9 ~31 ~-68 ~9 minecraft:polished_deepslate
setblock ~32 ~-68 ~9 minecraft:deepslate_tiles
setblock ~33 ~-68 ~9 minecraft:polished_deepslate
setblock ~34 ~-68 ~9 minecraft:yellow_concrete
setblock ~35 ~-68 ~9 minecraft:polished_deepslate
setblock ~36 ~-68 ~9 minecraft:deepslate_tiles
fill ~37 ~-68 ~9 ~38 ~-68 ~9 minecraft:polished_deepslate
fill ~39 ~-68 ~9 ~47 ~-68 ~9 minecraft:air
fill ~48 ~-68 ~9 ~49 ~-68 ~9 minecraft:polished_deepslate
setblock ~50 ~-68 ~9 minecraft:deepslate_tiles
fill ~51 ~-68 ~9 ~52 ~-68 ~9 minecraft:polished_deepslate
fill ~53 ~-68 ~9 ~61 ~-68 ~9 minecraft:air
fill ~62 ~-68 ~9 ~63 ~-68 ~9 minecraft:polished_deepslate
setblock ~64 ~-68 ~9 minecraft:deepslate_tiles
setblock ~4 ~-68 ~10 minecraft:deepslate_tiles
fill ~5 ~-68 ~10 ~17 ~-68 ~10 minecraft:polished_deepslate
setblock ~18 ~-68 ~10 minecraft:deepslate_tiles
fill ~19 ~-68 ~10 ~31 ~-68 ~10 minecraft:polished_deepslate
setblock ~32 ~-68 ~10 minecraft:deepslate_tiles
setblock ~33 ~-68 ~10 minecraft:polished_deepslate
setblock ~34 ~-68 ~10 minecraft:yellow_concrete
setblock ~35 ~-68 ~10 minecraft:polished_deepslate
setblock ~36 ~-68 ~10 minecraft:deepslate_tiles
fill ~37 ~-68 ~10 ~38 ~-68 ~10 minecraft:polished_deepslate
fill ~39 ~-68 ~10 ~47 ~-68 ~10 minecraft:air
fill ~48 ~-68 ~10 ~49 ~-68 ~10 minecraft:polished_deepslate
setblock ~50 ~-68 ~10 minecraft:deepslate_tiles
fill ~51 ~-68 ~10 ~52 ~-68 ~10 minecraft:polished_deepslate
fill ~53 ~-68 ~10 ~61 ~-68 ~10 minecraft:air
fill ~62 ~-68 ~10 ~63 ~-68 ~10 minecraft:polished_deepslate
setblock ~64 ~-68 ~10 minecraft:deepslate_tiles
setblock ~4 ~-68 ~11 minecraft:deepslate_tiles
fill ~5 ~-68 ~11 ~17 ~-68 ~11 minecraft:polished_deepslate
setblock ~18 ~-68 ~11 minecraft:deepslate_tiles
fill ~19 ~-68 ~11 ~31 ~-68 ~11 minecraft:polished_deepslate
setblock ~32 ~-68 ~11 minecraft:deepslate_tiles
setblock ~33 ~-68 ~11 minecraft:polished_deepslate
setblock ~34 ~-68 ~11 minecraft:yellow_concrete
setblock ~35 ~-68 ~11 minecraft:polished_deepslate
setblock ~36 ~-68 ~11 minecraft:deepslate_tiles
fill ~37 ~-68 ~11 ~38 ~-68 ~11 minecraft:polished_deepslate
fill ~39 ~-68 ~11 ~47 ~-68 ~11 minecraft:air
fill ~48 ~-68 ~11 ~49 ~-68 ~11 minecraft:polished_deepslate
setblock ~50 ~-68 ~11 minecraft:deepslate_tiles
fill ~51 ~-68 ~11 ~52 ~-68 ~11 minecraft:polished_deepslate
fill ~53 ~-68 ~11 ~61 ~-68 ~11 minecraft:air
fill ~62 ~-68 ~11 ~63 ~-68 ~11 minecraft:polished_deepslate
setblock ~64 ~-68 ~11 minecraft:deepslate_tiles
setblock ~4 ~-68 ~12 minecraft:deepslate_tiles
fill ~5 ~-68 ~12 ~17 ~-68 ~12 minecraft:polished_deepslate
setblock ~18 ~-68 ~12 minecraft:deepslate_tiles
fill ~19 ~-68 ~12 ~31 ~-68 ~12 minecraft:polished_deepslate
setblock ~32 ~-68 ~12 minecraft:deepslate_tiles
setblock ~33 ~-68 ~12 minecraft:polished_deepslate
setblock ~34 ~-68 ~12 minecraft:yellow_concrete
setblock ~35 ~-68 ~12 minecraft:polished_deepslate
setblock ~36 ~-68 ~12 minecraft:deepslate_tiles
fill ~37 ~-68 ~12 ~38 ~-68 ~12 minecraft:polished_deepslate
fill ~39 ~-68 ~12 ~47 ~-68 ~12 minecraft:air
fill ~48 ~-68 ~12 ~49 ~-68 ~12 minecraft:polished_deepslate
setblock ~50 ~-68 ~12 minecraft:deepslate_tiles
fill ~51 ~-68 ~12 ~52 ~-68 ~12 minecraft:polished_deepslate
fill ~53 ~-68 ~12 ~61 ~-68 ~12 minecraft:air
fill ~62 ~-68 ~12 ~63 ~-68 ~12 minecraft:polished_deepslate
setblock ~64 ~-68 ~12 minecraft:deepslate_tiles
setblock ~4 ~-68 ~13 minecraft:deepslate_tiles
fill ~5 ~-68 ~13 ~17 ~-68 ~13 minecraft:polished_deepslate
setblock ~18 ~-68 ~13 minecraft:deepslate_tiles
fill ~19 ~-68 ~13 ~31 ~-68 ~13 minecraft:polished_deepslate
setblock ~32 ~-68 ~13 minecraft:deepslate_tiles
setblock ~33 ~-68 ~13 minecraft:polished_deepslate
setblock ~34 ~-68 ~13 minecraft:yellow_concrete
setblock ~35 ~-68 ~13 minecraft:polished_deepslate
setblock ~36 ~-68 ~13 minecraft:deepslate_tiles
fill ~37 ~-68 ~13 ~38 ~-68 ~13 minecraft:polished_deepslate
fill ~39 ~-68 ~13 ~47 ~-68 ~13 minecraft:air
fill ~48 ~-68 ~13 ~49 ~-68 ~13 minecraft:polished_deepslate
setblock ~50 ~-68 ~13 minecraft:deepslate_tiles
fill ~51 ~-68 ~13 ~52 ~-68 ~13 minecraft:polished_deepslate
fill ~53 ~-68 ~13 ~61 ~-68 ~13 minecraft:air
fill ~62 ~-68 ~13 ~63 ~-68 ~13 minecraft:polished_deepslate
setblock ~64 ~-68 ~13 minecraft:deepslate_tiles
setblock ~4 ~-68 ~14 minecraft:deepslate_tiles
fill ~5 ~-68 ~14 ~17 ~-68 ~14 minecraft:polished_deepslate
setblock ~18 ~-68 ~14 minecraft:deepslate_tiles
fill ~19 ~-68 ~14 ~31 ~-68 ~14 minecraft:polished_deepslate
setblock ~32 ~-68 ~14 minecraft:deepslate_tiles
setblock ~33 ~-68 ~14 minecraft:polished_deepslate
setblock ~34 ~-68 ~14 minecraft:yellow_concrete
setblock ~35 ~-68 ~14 minecraft:polished_deepslate
setblock ~36 ~-68 ~14 minecraft:deepslate_tiles
fill ~37 ~-68 ~14 ~38 ~-68 ~14 minecraft:polished_deepslate
fill ~39 ~-68 ~14 ~47 ~-68 ~14 minecraft:air
fill ~48 ~-68 ~14 ~49 ~-68 ~14 minecraft:polished_deepslate
setblock ~50 ~-68 ~14 minecraft:deepslate_tiles
fill ~51 ~-68 ~14 ~52 ~-68 ~14 minecraft:polished_deepslate
fill ~53 ~-68 ~14 ~61 ~-68 ~14 minecraft:air
fill ~62 ~-68 ~14 ~63 ~-68 ~14 minecraft:polished_deepslate
setblock ~64 ~-68 ~14 minecraft:deepslate_tiles
setblock ~4 ~-68 ~15 minecraft:deepslate_tiles
fill ~5 ~-68 ~15 ~17 ~-68 ~15 minecraft:polished_deepslate
setblock ~18 ~-68 ~15 minecraft:deepslate_tiles
fill ~19 ~-68 ~15 ~31 ~-68 ~15 minecraft:polished_deepslate
setblock ~32 ~-68 ~15 minecraft:deepslate_tiles
setblock ~33 ~-68 ~15 minecraft:polished_deepslate
setblock ~34 ~-68 ~15 minecraft:yellow_concrete
setblock ~35 ~-68 ~15 minecraft:polished_deepslate
setblock ~36 ~-68 ~15 minecraft:deepslate_tiles
fill ~37 ~-68 ~15 ~38 ~-68 ~15 minecraft:polished_deepslate
fill ~39 ~-68 ~15 ~47 ~-68 ~15 minecraft:air
fill ~48 ~-68 ~15 ~49 ~-68 ~15 minecraft:polished_deepslate
setblock ~50 ~-68 ~15 minecraft:deepslate_tiles
fill ~51 ~-68 ~15 ~52 ~-68 ~15 minecraft:polished_deepslate
fill ~53 ~-68 ~15 ~61 ~-68 ~15 minecraft:air
fill ~62 ~-68 ~15 ~63 ~-68 ~15 minecraft:polished_deepslate
setblock ~64 ~-68 ~15 minecraft:deepslate_tiles
setblock ~4 ~-68 ~16 minecraft:deepslate_tiles
fill ~5 ~-68 ~16 ~17 ~-68 ~16 minecraft:polished_deepslate
setblock ~18 ~-68 ~16 minecraft:deepslate_tiles
fill ~19 ~-68 ~16 ~31 ~-68 ~16 minecraft:polished_deepslate
setblock ~32 ~-68 ~16 minecraft:deepslate_tiles
setblock ~33 ~-68 ~16 minecraft:polished_deepslate
setblock ~34 ~-68 ~16 minecraft:yellow_concrete
setblock ~35 ~-68 ~16 minecraft:polished_deepslate
setblock ~36 ~-68 ~16 minecraft:deepslate_tiles
fill ~37 ~-68 ~16 ~49 ~-68 ~16 minecraft:polished_deepslate
setblock ~50 ~-68 ~16 minecraft:deepslate_tiles
fill ~51 ~-68 ~16 ~63 ~-68 ~16 minecraft:polished_deepslate
setblock ~64 ~-68 ~16 minecraft:deepslate_tiles
setblock ~4 ~-68 ~17 minecraft:deepslate_tiles
fill ~5 ~-68 ~17 ~17 ~-68 ~17 minecraft:polished_deepslate
setblock ~18 ~-68 ~17 minecraft:deepslate_tiles
fill ~19 ~-68 ~17 ~31 ~-68 ~17 minecraft:polished_deepslate
setblock ~32 ~-68 ~17 minecraft:deepslate_tiles
setblock ~33 ~-68 ~17 minecraft:polished_deepslate
setblock ~34 ~-68 ~17 minecraft:yellow_concrete
setblock ~35 ~-68 ~17 minecraft:polished_deepslate
setblock ~36 ~-68 ~17 minecraft:deepslate_tiles
fill ~37 ~-68 ~17 ~49 ~-68 ~17 minecraft:polished_deepslate
setblock ~50 ~-68 ~17 minecraft:deepslate_tiles
fill ~51 ~-68 ~17 ~63 ~-68 ~17 minecraft:polished_deepslate
setblock ~64 ~-68 ~17 minecraft:deepslate_tiles
fill ~4 ~-68 ~18 ~32 ~-68 ~18 minecraft:deepslate_tiles
setblock ~33 ~-68 ~18 minecraft:polished_deepslate
setblock ~34 ~-68 ~18 minecraft:yellow_concrete
setblock ~35 ~-68 ~18 minecraft:polished_deepslate
fill ~36 ~-68 ~18 ~64 ~-68 ~18 minecraft:deepslate_tiles
setblock ~4 ~-68 ~19 minecraft:deepslate_tiles
fill ~5 ~-68 ~19 ~17 ~-68 ~19 minecraft:polished_andesite
setblock ~18 ~-68 ~19 minecraft:deepslate_tiles
fill ~19 ~-68 ~19 ~31 ~-68 ~19 minecraft:polished_deepslate
setblock ~32 ~-68 ~19 minecraft:deepslate_tiles
fill ~33 ~-68 ~19 ~35 ~-68 ~19 minecraft:polished_deepslate
setblock ~36 ~-68 ~19 minecraft:deepslate_tiles
fill ~37 ~-68 ~19 ~49 ~-68 ~19 minecraft:polished_deepslate
setblock ~50 ~-68 ~19 minecraft:deepslate_tiles
fill ~51 ~-68 ~19 ~63 ~-68 ~19 minecraft:polished_deepslate
setblock ~64 ~-68 ~19 minecraft:deepslate_tiles
setblock ~4 ~-68 ~20 minecraft:deepslate_tiles
fill ~5 ~-68 ~20 ~17 ~-68 ~20 minecraft:polished_andesite
setblock ~18 ~-68 ~20 minecraft:deepslate_tiles
fill ~19 ~-68 ~20 ~49 ~-68 ~20 minecraft:polished_deepslate
setblock ~50 ~-68 ~20 minecraft:deepslate_tiles
fill ~51 ~-68 ~20 ~63 ~-68 ~20 minecraft:polished_deepslate
setblock ~64 ~-68 ~20 minecraft:deepslate_tiles
setblock ~4 ~-68 ~21 minecraft:deepslate_tiles
fill ~5 ~-68 ~21 ~17 ~-68 ~21 minecraft:polished_andesite
setblock ~18 ~-68 ~21 minecraft:deepslate_tiles
fill ~19 ~-68 ~21 ~49 ~-68 ~21 minecraft:polished_deepslate
setblock ~50 ~-68 ~21 minecraft:deepslate_tiles
fill ~51 ~-68 ~21 ~63 ~-68 ~21 minecraft:polished_deepslate
setblock ~64 ~-68 ~21 minecraft:deepslate_tiles
setblock ~4 ~-68 ~22 minecraft:deepslate_tiles
fill ~5 ~-68 ~22 ~17 ~-68 ~22 minecraft:polished_andesite
setblock ~18 ~-68 ~22 minecraft:deepslate_tiles
fill ~19 ~-68 ~22 ~30 ~-68 ~22 minecraft:polished_deepslate
fill ~31 ~-68 ~22 ~37 ~-68 ~22 minecraft:deepslate_tiles
fill ~38 ~-68 ~22 ~49 ~-68 ~22 minecraft:polished_deepslate
setblock ~50 ~-68 ~22 minecraft:deepslate_tiles
fill ~51 ~-68 ~22 ~63 ~-68 ~22 minecraft:polished_deepslate
setblock ~64 ~-68 ~22 minecraft:deepslate_tiles
setblock ~4 ~-68 ~23 minecraft:deepslate_tiles
fill ~5 ~-68 ~23 ~17 ~-68 ~23 minecraft:polished_andesite
setblock ~18 ~-68 ~23 minecraft:deepslate_tiles
fill ~19 ~-68 ~23 ~28 ~-68 ~23 minecraft:polished_deepslate
setblock ~29 ~-68 ~23 minecraft:deepslate_tiles
fill ~30 ~-68 ~23 ~38 ~-68 ~23 minecraft:polished_deepslate
setblock ~39 ~-68 ~23 minecraft:deepslate_tiles
fill ~40 ~-68 ~23 ~49 ~-68 ~23 minecraft:polished_deepslate
setblock ~50 ~-68 ~23 minecraft:deepslate_tiles
fill ~51 ~-68 ~23 ~63 ~-68 ~23 minecraft:polished_deepslate
setblock ~64 ~-68 ~23 minecraft:deepslate_tiles
setblock ~4 ~-68 ~24 minecraft:deepslate_tiles
fill ~5 ~-68 ~24 ~17 ~-68 ~24 minecraft:polished_andesite
setblock ~18 ~-68 ~24 minecraft:deepslate_tiles
fill ~19 ~-68 ~24 ~26 ~-68 ~24 minecraft:polished_deepslate
setblock ~27 ~-68 ~24 minecraft:deepslate_tiles
fill ~28 ~-68 ~24 ~40 ~-68 ~24 minecraft:polished_deepslate
setblock ~41 ~-68 ~24 minecraft:deepslate_tiles
fill ~42 ~-68 ~24 ~49 ~-68 ~24 minecraft:polished_deepslate
setblock ~50 ~-68 ~24 minecraft:deepslate_tiles
fill ~51 ~-68 ~24 ~63 ~-68 ~24 minecraft:polished_deepslate
setblock ~64 ~-68 ~24 minecraft:deepslate_tiles
setblock ~4 ~-68 ~25 minecraft:deepslate_tiles
fill ~5 ~-68 ~25 ~17 ~-68 ~25 minecraft:polished_andesite
setblock ~18 ~-68 ~25 minecraft:deepslate_tiles
fill ~19 ~-68 ~25 ~25 ~-68 ~25 minecraft:polished_deepslate
setblock ~26 ~-68 ~25 minecraft:deepslate_tiles
fill ~27 ~-68 ~25 ~41 ~-68 ~25 minecraft:polished_deepslate
setblock ~42 ~-68 ~25 minecraft:deepslate_tiles
fill ~43 ~-68 ~25 ~49 ~-68 ~25 minecraft:polished_deepslate
setblock ~50 ~-68 ~25 minecraft:deepslate_tiles
fill ~51 ~-68 ~25 ~63 ~-68 ~25 minecraft:polished_deepslate
setblock ~64 ~-68 ~25 minecraft:deepslate_tiles
setblock ~4 ~-68 ~26 minecraft:deepslate_tiles
fill ~5 ~-68 ~26 ~17 ~-68 ~26 minecraft:polished_andesite
setblock ~18 ~-68 ~26 minecraft:deepslate_tiles
fill ~19 ~-68 ~26 ~24 ~-68 ~26 minecraft:polished_deepslate
setblock ~25 ~-68 ~26 minecraft:deepslate_tiles
fill ~26 ~-68 ~26 ~33 ~-68 ~26 minecraft:polished_deepslate
setblock ~34 ~-68 ~26 minecraft:yellow_concrete
fill ~35 ~-68 ~26 ~42 ~-68 ~26 minecraft:polished_deepslate
setblock ~43 ~-68 ~26 minecraft:deepslate_tiles
fill ~44 ~-68 ~26 ~49 ~-68 ~26 minecraft:polished_deepslate
setblock ~50 ~-68 ~26 minecraft:deepslate_tiles
fill ~51 ~-68 ~26 ~63 ~-68 ~26 minecraft:polished_deepslate
setblock ~64 ~-68 ~26 minecraft:deepslate_tiles
setblock ~4 ~-68 ~27 minecraft:deepslate_tiles
fill ~5 ~-68 ~27 ~17 ~-68 ~27 minecraft:polished_andesite
setblock ~18 ~-68 ~27 minecraft:deepslate_tiles
fill ~19 ~-68 ~27 ~23 ~-68 ~27 minecraft:polished_deepslate
setblock ~24 ~-68 ~27 minecraft:deepslate_tiles
fill ~25 ~-68 ~27 ~30 ~-68 ~27 minecraft:polished_deepslate
setblock ~31 ~-68 ~27 minecraft:yellow_concrete
fill ~32 ~-68 ~27 ~36 ~-68 ~27 minecraft:polished_deepslate
setblock ~37 ~-68 ~27 minecraft:yellow_concrete
fill ~38 ~-68 ~27 ~43 ~-68 ~27 minecraft:polished_deepslate
setblock ~44 ~-68 ~27 minecraft:deepslate_tiles
fill ~45 ~-68 ~27 ~49 ~-68 ~27 minecraft:polished_deepslate
setblock ~50 ~-68 ~27 minecraft:deepslate_tiles
fill ~51 ~-68 ~27 ~63 ~-68 ~27 minecraft:polished_deepslate
setblock ~64 ~-68 ~27 minecraft:deepslate_tiles
setblock ~4 ~-68 ~28 minecraft:deepslate_tiles
fill ~5 ~-68 ~28 ~17 ~-68 ~28 minecraft:polished_andesite
setblock ~18 ~-68 ~28 minecraft:deepslate_tiles
fill ~19 ~-68 ~28 ~28 ~-68 ~28 minecraft:polished_deepslate
setblock ~29 ~-68 ~28 minecraft:yellow_concrete
fill ~30 ~-68 ~28 ~38 ~-68 ~28 minecraft:polished_deepslate
setblock ~39 ~-68 ~28 minecraft:yellow_concrete
fill ~40 ~-68 ~28 ~49 ~-68 ~28 minecraft:polished_deepslate
setblock ~50 ~-68 ~28 minecraft:deepslate_tiles
fill ~51 ~-68 ~28 ~63 ~-68 ~28 minecraft:polished_deepslate
setblock ~64 ~-68 ~28 minecraft:deepslate_tiles
setblock ~4 ~-68 ~29 minecraft:deepslate_tiles
fill ~5 ~-68 ~29 ~17 ~-68 ~29 minecraft:polished_andesite
setblock ~18 ~-68 ~29 minecraft:deepslate_tiles
fill ~19 ~-68 ~29 ~22 ~-68 ~29 minecraft:polished_deepslate
setblock ~23 ~-68 ~29 minecraft:deepslate_tiles
fill ~24 ~-68 ~29 ~27 ~-68 ~29 minecraft:polished_deepslate
setblock ~28 ~-68 ~29 minecraft:yellow_concrete
fill ~29 ~-68 ~29 ~39 ~-68 ~29 minecraft:polished_deepslate
setblock ~40 ~-68 ~29 minecraft:yellow_concrete
fill ~41 ~-68 ~29 ~44 ~-68 ~29 minecraft:polished_deepslate
setblock ~45 ~-68 ~29 minecraft:deepslate_tiles
fill ~46 ~-68 ~29 ~49 ~-68 ~29 minecraft:polished_deepslate
setblock ~50 ~-68 ~29 minecraft:deepslate_tiles
fill ~51 ~-68 ~29 ~63 ~-68 ~29 minecraft:polished_deepslate
setblock ~64 ~-68 ~29 minecraft:deepslate_tiles
setblock ~4 ~-68 ~30 minecraft:deepslate_tiles
fill ~5 ~-68 ~30 ~17 ~-68 ~30 minecraft:polished_andesite
setblock ~18 ~-68 ~30 minecraft:deepslate_tiles
fill ~19 ~-68 ~30 ~49 ~-68 ~30 minecraft:polished_deepslate
setblock ~50 ~-68 ~30 minecraft:deepslate_tiles
fill ~51 ~-68 ~30 ~63 ~-68 ~30 minecraft:polished_deepslate
setblock ~64 ~-68 ~30 minecraft:deepslate_tiles
setblock ~4 ~-68 ~31 minecraft:deepslate_tiles
fill ~5 ~-68 ~31 ~17 ~-68 ~31 minecraft:polished_andesite
setblock ~18 ~-68 ~31 minecraft:deepslate_tiles
fill ~19 ~-68 ~31 ~21 ~-68 ~31 minecraft:polished_deepslate
setblock ~22 ~-68 ~31 minecraft:deepslate_tiles
fill ~23 ~-68 ~31 ~26 ~-68 ~31 minecraft:polished_deepslate
setblock ~27 ~-68 ~31 minecraft:yellow_concrete
fill ~28 ~-68 ~31 ~40 ~-68 ~31 minecraft:polished_deepslate
setblock ~41 ~-68 ~31 minecraft:yellow_concrete
fill ~42 ~-68 ~31 ~45 ~-68 ~31 minecraft:polished_deepslate
setblock ~46 ~-68 ~31 minecraft:deepslate_tiles
fill ~47 ~-68 ~31 ~49 ~-68 ~31 minecraft:polished_deepslate
setblock ~50 ~-68 ~31 minecraft:deepslate_tiles
fill ~51 ~-68 ~31 ~63 ~-68 ~31 minecraft:polished_deepslate
setblock ~64 ~-68 ~31 minecraft:deepslate_tiles
fill ~4 ~-68 ~32 ~19 ~-68 ~32 minecraft:deepslate_tiles
fill ~20 ~-68 ~32 ~21 ~-68 ~32 minecraft:polished_deepslate
setblock ~22 ~-68 ~32 minecraft:deepslate_tiles
fill ~23 ~-68 ~32 ~45 ~-68 ~32 minecraft:polished_deepslate
setblock ~46 ~-68 ~32 minecraft:deepslate_tiles
fill ~47 ~-68 ~32 ~48 ~-68 ~32 minecraft:polished_deepslate
fill ~49 ~-68 ~32 ~64 ~-68 ~32 minecraft:deepslate_tiles
setblock ~4 ~-68 ~33 minecraft:deepslate_tiles
fill ~5 ~-68 ~33 ~21 ~-68 ~33 minecraft:polished_deepslate
setblock ~22 ~-68 ~33 minecraft:deepslate_tiles
fill ~23 ~-68 ~33 ~45 ~-68 ~33 minecraft:polished_deepslate
setblock ~46 ~-68 ~33 minecraft:deepslate_tiles
fill ~47 ~-68 ~33 ~49 ~-68 ~33 minecraft:polished_deepslate
fill ~50 ~-68 ~33 ~63 ~-68 ~33 minecraft:yellow_concrete
fill ~64 ~-68 ~33 ~68 ~-68 ~33 minecraft:deepslate_bricks
setblock ~4 ~-68 ~34 minecraft:deepslate_tiles
fill ~5 ~-68 ~34 ~18 ~-68 ~34 minecraft:yellow_concrete
fill ~19 ~-68 ~34 ~21 ~-68 ~34 minecraft:polished_deepslate
setblock ~22 ~-68 ~34 minecraft:deepslate_tiles
fill ~23 ~-68 ~34 ~25 ~-68 ~34 minecraft:polished_deepslate
setblock ~26 ~-68 ~34 minecraft:yellow_concrete
fill ~27 ~-68 ~34 ~41 ~-68 ~34 minecraft:polished_deepslate
setblock ~42 ~-68 ~34 minecraft:yellow_concrete
fill ~43 ~-68 ~34 ~45 ~-68 ~34 minecraft:polished_deepslate
setblock ~46 ~-68 ~34 minecraft:deepslate_tiles
fill ~47 ~-68 ~34 ~49 ~-68 ~34 minecraft:polished_deepslate
setblock ~50 ~-68 ~34 minecraft:iron_block
fill ~51 ~-68 ~34 ~68 ~-68 ~34 minecraft:air
setblock ~4 ~-68 ~35 minecraft:deepslate_tiles
fill ~5 ~-68 ~35 ~21 ~-68 ~35 minecraft:polished_deepslate
setblock ~22 ~-68 ~35 minecraft:deepslate_tiles
fill ~23 ~-68 ~35 ~45 ~-68 ~35 minecraft:polished_deepslate
setblock ~46 ~-68 ~35 minecraft:deepslate_tiles
fill ~47 ~-68 ~35 ~49 ~-68 ~35 minecraft:polished_deepslate
fill ~50 ~-68 ~35 ~63 ~-68 ~35 minecraft:yellow_concrete
fill ~64 ~-68 ~35 ~68 ~-68 ~35 minecraft:deepslate_bricks
fill ~4 ~-68 ~36 ~19 ~-68 ~36 minecraft:deepslate_tiles
fill ~20 ~-68 ~36 ~21 ~-68 ~36 minecraft:polished_deepslate
setblock ~22 ~-68 ~36 minecraft:deepslate_tiles
fill ~23 ~-68 ~36 ~45 ~-68 ~36 minecraft:polished_deepslate
setblock ~46 ~-68 ~36 minecraft:deepslate_tiles
fill ~47 ~-68 ~36 ~48 ~-68 ~36 minecraft:polished_deepslate
fill ~49 ~-68 ~36 ~64 ~-68 ~36 minecraft:deepslate_tiles
setblock ~4 ~-68 ~37 minecraft:deepslate_tiles
fill ~5 ~-68 ~37 ~17 ~-68 ~37 minecraft:polished_andesite
setblock ~18 ~-68 ~37 minecraft:deepslate_tiles
fill ~19 ~-68 ~37 ~21 ~-68 ~37 minecraft:polished_deepslate
setblock ~22 ~-68 ~37 minecraft:deepslate_tiles
fill ~23 ~-68 ~37 ~26 ~-68 ~37 minecraft:polished_deepslate
setblock ~27 ~-68 ~37 minecraft:yellow_concrete
fill ~28 ~-68 ~37 ~40 ~-68 ~37 minecraft:polished_deepslate
setblock ~41 ~-68 ~37 minecraft:yellow_concrete
fill ~42 ~-68 ~37 ~45 ~-68 ~37 minecraft:polished_deepslate
setblock ~46 ~-68 ~37 minecraft:deepslate_tiles
fill ~47 ~-68 ~37 ~49 ~-68 ~37 minecraft:polished_deepslate
setblock ~50 ~-68 ~37 minecraft:deepslate_tiles
fill ~51 ~-68 ~37 ~63 ~-68 ~37 minecraft:polished_deepslate
setblock ~64 ~-68 ~37 minecraft:deepslate_tiles
setblock ~4 ~-68 ~38 minecraft:deepslate_tiles
fill ~5 ~-68 ~38 ~17 ~-68 ~38 minecraft:polished_andesite
setblock ~18 ~-68 ~38 minecraft:deepslate_tiles
fill ~19 ~-68 ~38 ~49 ~-68 ~38 minecraft:polished_deepslate
setblock ~50 ~-68 ~38 minecraft:deepslate_tiles
fill ~51 ~-68 ~38 ~63 ~-68 ~38 minecraft:polished_deepslate
setblock ~64 ~-68 ~38 minecraft:deepslate_tiles
setblock ~4 ~-68 ~39 minecraft:deepslate_tiles
fill ~5 ~-68 ~39 ~17 ~-68 ~39 minecraft:polished_andesite
setblock ~18 ~-68 ~39 minecraft:deepslate_tiles
fill ~19 ~-68 ~39 ~22 ~-68 ~39 minecraft:polished_deepslate
setblock ~23 ~-68 ~39 minecraft:deepslate_tiles
fill ~24 ~-68 ~39 ~27 ~-68 ~39 minecraft:polished_deepslate
setblock ~28 ~-68 ~39 minecraft:yellow_concrete
fill ~29 ~-68 ~39 ~39 ~-68 ~39 minecraft:polished_deepslate
setblock ~40 ~-68 ~39 minecraft:yellow_concrete
fill ~41 ~-68 ~39 ~44 ~-68 ~39 minecraft:polished_deepslate
setblock ~45 ~-68 ~39 minecraft:deepslate_tiles
fill ~46 ~-68 ~39 ~49 ~-68 ~39 minecraft:polished_deepslate
setblock ~50 ~-68 ~39 minecraft:deepslate_tiles
fill ~51 ~-68 ~39 ~63 ~-68 ~39 minecraft:polished_deepslate
setblock ~64 ~-68 ~39 minecraft:deepslate_tiles
setblock ~4 ~-68 ~40 minecraft:deepslate_tiles
fill ~5 ~-68 ~40 ~17 ~-68 ~40 minecraft:polished_andesite
setblock ~18 ~-68 ~40 minecraft:deepslate_tiles
fill ~19 ~-68 ~40 ~28 ~-68 ~40 minecraft:polished_deepslate
setblock ~29 ~-68 ~40 minecraft:yellow_concrete
fill ~30 ~-68 ~40 ~38 ~-68 ~40 minecraft:polished_deepslate
setblock ~39 ~-68 ~40 minecraft:yellow_concrete
fill ~40 ~-68 ~40 ~49 ~-68 ~40 minecraft:polished_deepslate
setblock ~50 ~-68 ~40 minecraft:deepslate_tiles
fill ~51 ~-68 ~40 ~63 ~-68 ~40 minecraft:polished_deepslate
setblock ~64 ~-68 ~40 minecraft:deepslate_tiles
setblock ~4 ~-68 ~41 minecraft:deepslate_tiles
fill ~5 ~-68 ~41 ~17 ~-68 ~41 minecraft:polished_andesite
setblock ~18 ~-68 ~41 minecraft:deepslate_tiles
fill ~19 ~-68 ~41 ~23 ~-68 ~41 minecraft:polished_deepslate
setblock ~24 ~-68 ~41 minecraft:deepslate_tiles
fill ~25 ~-68 ~41 ~30 ~-68 ~41 minecraft:polished_deepslate
setblock ~31 ~-68 ~41 minecraft:yellow_concrete
fill ~32 ~-68 ~41 ~36 ~-68 ~41 minecraft:polished_deepslate
setblock ~37 ~-68 ~41 minecraft:yellow_concrete
fill ~38 ~-68 ~41 ~43 ~-68 ~41 minecraft:polished_deepslate
setblock ~44 ~-68 ~41 minecraft:deepslate_tiles
fill ~45 ~-68 ~41 ~49 ~-68 ~41 minecraft:polished_deepslate
setblock ~50 ~-68 ~41 minecraft:deepslate_tiles
fill ~51 ~-68 ~41 ~63 ~-68 ~41 minecraft:polished_deepslate
setblock ~64 ~-68 ~41 minecraft:deepslate_tiles
setblock ~4 ~-68 ~42 minecraft:deepslate_tiles
fill ~5 ~-68 ~42 ~17 ~-68 ~42 minecraft:polished_andesite
setblock ~18 ~-68 ~42 minecraft:deepslate_tiles
fill ~19 ~-68 ~42 ~24 ~-68 ~42 minecraft:polished_deepslate
setblock ~25 ~-68 ~42 minecraft:deepslate_tiles
fill ~26 ~-68 ~42 ~33 ~-68 ~42 minecraft:polished_deepslate
setblock ~34 ~-68 ~42 minecraft:yellow_concrete
fill ~35 ~-68 ~42 ~42 ~-68 ~42 minecraft:polished_deepslate
setblock ~43 ~-68 ~42 minecraft:deepslate_tiles
fill ~44 ~-68 ~42 ~49 ~-68 ~42 minecraft:polished_deepslate
setblock ~50 ~-68 ~42 minecraft:deepslate_tiles
fill ~51 ~-68 ~42 ~63 ~-68 ~42 minecraft:polished_deepslate
setblock ~64 ~-68 ~42 minecraft:deepslate_tiles
setblock ~4 ~-68 ~43 minecraft:deepslate_tiles
fill ~5 ~-68 ~43 ~17 ~-68 ~43 minecraft:polished_andesite
setblock ~18 ~-68 ~43 minecraft:deepslate_tiles
fill ~19 ~-68 ~43 ~25 ~-68 ~43 minecraft:polished_deepslate
setblock ~26 ~-68 ~43 minecraft:deepslate_tiles
fill ~27 ~-68 ~43 ~41 ~-68 ~43 minecraft:polished_deepslate
setblock ~42 ~-68 ~43 minecraft:deepslate_tiles
fill ~43 ~-68 ~43 ~49 ~-68 ~43 minecraft:polished_deepslate
setblock ~50 ~-68 ~43 minecraft:deepslate_tiles
fill ~51 ~-68 ~43 ~63 ~-68 ~43 minecraft:polished_deepslate
setblock ~64 ~-68 ~43 minecraft:deepslate_tiles
setblock ~4 ~-68 ~44 minecraft:deepslate_tiles
fill ~5 ~-68 ~44 ~17 ~-68 ~44 minecraft:polished_andesite
setblock ~18 ~-68 ~44 minecraft:deepslate_tiles
fill ~19 ~-68 ~44 ~26 ~-68 ~44 minecraft:polished_deepslate
setblock ~27 ~-68 ~44 minecraft:deepslate_tiles
fill ~28 ~-68 ~44 ~40 ~-68 ~44 minecraft:polished_deepslate
setblock ~41 ~-68 ~44 minecraft:deepslate_tiles
fill ~42 ~-68 ~44 ~49 ~-68 ~44 minecraft:polished_deepslate
setblock ~50 ~-68 ~44 minecraft:deepslate_tiles
fill ~51 ~-68 ~44 ~63 ~-68 ~44 minecraft:polished_deepslate
setblock ~64 ~-68 ~44 minecraft:deepslate_tiles
setblock ~4 ~-68 ~45 minecraft:deepslate_tiles
fill ~5 ~-68 ~45 ~17 ~-68 ~45 minecraft:polished_andesite
setblock ~18 ~-68 ~45 minecraft:deepslate_tiles
fill ~19 ~-68 ~45 ~28 ~-68 ~45 minecraft:polished_deepslate
setblock ~29 ~-68 ~45 minecraft:deepslate_tiles
fill ~30 ~-68 ~45 ~38 ~-68 ~45 minecraft:polished_deepslate
setblock ~39 ~-68 ~45 minecraft:deepslate_tiles
fill ~40 ~-68 ~45 ~49 ~-68 ~45 minecraft:polished_deepslate
setblock ~50 ~-68 ~45 minecraft:deepslate_tiles
fill ~51 ~-68 ~45 ~63 ~-68 ~45 minecraft:polished_deepslate
setblock ~64 ~-68 ~45 minecraft:deepslate_tiles
setblock ~4 ~-68 ~46 minecraft:deepslate_tiles
fill ~5 ~-68 ~46 ~17 ~-68 ~46 minecraft:polished_andesite
setblock ~18 ~-68 ~46 minecraft:deepslate_tiles
fill ~19 ~-68 ~46 ~30 ~-68 ~46 minecraft:polished_deepslate
fill ~31 ~-68 ~46 ~37 ~-68 ~46 minecraft:deepslate_tiles
fill ~38 ~-68 ~46 ~49 ~-68 ~46 minecraft:polished_deepslate
setblock ~50 ~-68 ~46 minecraft:deepslate_tiles
fill ~51 ~-68 ~46 ~63 ~-68 ~46 minecraft:polished_deepslate
setblock ~64 ~-68 ~46 minecraft:deepslate_tiles
setblock ~4 ~-68 ~47 minecraft:deepslate_tiles
fill ~5 ~-68 ~47 ~17 ~-68 ~47 minecraft:polished_andesite
setblock ~18 ~-68 ~47 minecraft:deepslate_tiles
fill ~19 ~-68 ~47 ~49 ~-68 ~47 minecraft:polished_deepslate
setblock ~50 ~-68 ~47 minecraft:deepslate_tiles
fill ~51 ~-68 ~47 ~63 ~-68 ~47 minecraft:polished_deepslate
setblock ~64 ~-68 ~47 minecraft:deepslate_tiles
setblock ~4 ~-68 ~48 minecraft:deepslate_tiles
fill ~5 ~-68 ~48 ~17 ~-68 ~48 minecraft:polished_andesite
setblock ~18 ~-68 ~48 minecraft:deepslate_tiles
fill ~19 ~-68 ~48 ~49 ~-68 ~48 minecraft:polished_deepslate
setblock ~50 ~-68 ~48 minecraft:deepslate_tiles
fill ~51 ~-68 ~48 ~63 ~-68 ~48 minecraft:polished_deepslate
setblock ~64 ~-68 ~48 minecraft:deepslate_tiles
setblock ~4 ~-68 ~49 minecraft:deepslate_tiles
fill ~5 ~-68 ~49 ~17 ~-68 ~49 minecraft:polished_andesite
setblock ~18 ~-68 ~49 minecraft:deepslate_tiles
fill ~19 ~-68 ~49 ~31 ~-68 ~49 minecraft:polished_deepslate
setblock ~32 ~-68 ~49 minecraft:deepslate_tiles
fill ~33 ~-68 ~49 ~35 ~-68 ~49 minecraft:polished_deepslate
setblock ~36 ~-68 ~49 minecraft:deepslate_tiles
fill ~37 ~-68 ~49 ~49 ~-68 ~49 minecraft:polished_deepslate
setblock ~50 ~-68 ~49 minecraft:deepslate_tiles
fill ~51 ~-68 ~49 ~63 ~-68 ~49 minecraft:polished_deepslate
setblock ~64 ~-68 ~49 minecraft:deepslate_tiles
fill ~4 ~-68 ~50 ~32 ~-68 ~50 minecraft:deepslate_tiles
setblock ~33 ~-68 ~50 minecraft:polished_deepslate
setblock ~34 ~-68 ~50 minecraft:yellow_concrete
setblock ~35 ~-68 ~50 minecraft:polished_deepslate
fill ~36 ~-68 ~50 ~64 ~-68 ~50 minecraft:deepslate_tiles
setblock ~4 ~-68 ~51 minecraft:deepslate_tiles
fill ~5 ~-68 ~51 ~17 ~-68 ~51 minecraft:polished_deepslate
setblock ~18 ~-68 ~51 minecraft:deepslate_tiles
fill ~19 ~-68 ~51 ~31 ~-68 ~51 minecraft:polished_deepslate
setblock ~32 ~-68 ~51 minecraft:deepslate_tiles
setblock ~33 ~-68 ~51 minecraft:polished_deepslate
setblock ~34 ~-68 ~51 minecraft:yellow_concrete
setblock ~35 ~-68 ~51 minecraft:polished_deepslate
setblock ~36 ~-68 ~51 minecraft:deepslate_tiles
fill ~37 ~-68 ~51 ~49 ~-68 ~51 minecraft:polished_deepslate
setblock ~50 ~-68 ~51 minecraft:deepslate_tiles
fill ~51 ~-68 ~51 ~63 ~-68 ~51 minecraft:polished_deepslate
setblock ~64 ~-68 ~51 minecraft:deepslate_tiles
setblock ~4 ~-68 ~52 minecraft:deepslate_tiles
fill ~5 ~-68 ~52 ~17 ~-68 ~52 minecraft:polished_deepslate
setblock ~18 ~-68 ~52 minecraft:deepslate_tiles
fill ~19 ~-68 ~52 ~31 ~-68 ~52 minecraft:polished_deepslate
setblock ~32 ~-68 ~52 minecraft:deepslate_tiles
setblock ~33 ~-68 ~52 minecraft:polished_deepslate
setblock ~34 ~-68 ~52 minecraft:yellow_concrete
setblock ~35 ~-68 ~52 minecraft:polished_deepslate
setblock ~36 ~-68 ~52 minecraft:deepslate_tiles
fill ~37 ~-68 ~52 ~49 ~-68 ~52 minecraft:polished_deepslate
setblock ~50 ~-68 ~52 minecraft:deepslate_tiles
fill ~51 ~-68 ~52 ~63 ~-68 ~52 minecraft:polished_deepslate
setblock ~64 ~-68 ~52 minecraft:deepslate_tiles
setblock ~4 ~-68 ~53 minecraft:deepslate_tiles
fill ~5 ~-68 ~53 ~17 ~-68 ~53 minecraft:polished_deepslate
setblock ~18 ~-68 ~53 minecraft:deepslate_tiles
fill ~19 ~-68 ~53 ~31 ~-68 ~53 minecraft:polished_deepslate
setblock ~32 ~-68 ~53 minecraft:deepslate_tiles
setblock ~33 ~-68 ~53 minecraft:polished_deepslate
setblock ~34 ~-68 ~53 minecraft:yellow_concrete
setblock ~35 ~-68 ~53 minecraft:polished_deepslate
setblock ~36 ~-68 ~53 minecraft:deepslate_tiles
fill ~37 ~-68 ~53 ~49 ~-68 ~53 minecraft:polished_deepslate
setblock ~50 ~-68 ~53 minecraft:deepslate_tiles
fill ~51 ~-68 ~53 ~52 ~-68 ~53 minecraft:polished_deepslate
fill ~53 ~-68 ~53 ~61 ~-68 ~53 minecraft:air
fill ~62 ~-68 ~53 ~63 ~-68 ~53 minecraft:polished_deepslate
setblock ~64 ~-68 ~53 minecraft:deepslate_tiles
setblock ~4 ~-68 ~54 minecraft:deepslate_tiles
fill ~5 ~-68 ~54 ~17 ~-68 ~54 minecraft:polished_deepslate
setblock ~18 ~-68 ~54 minecraft:deepslate_tiles
fill ~19 ~-68 ~54 ~31 ~-68 ~54 minecraft:polished_deepslate
setblock ~32 ~-68 ~54 minecraft:deepslate_tiles
setblock ~33 ~-68 ~54 minecraft:polished_deepslate
setblock ~34 ~-68 ~54 minecraft:yellow_concrete
setblock ~35 ~-68 ~54 minecraft:polished_deepslate
setblock ~36 ~-68 ~54 minecraft:deepslate_tiles
fill ~37 ~-68 ~54 ~49 ~-68 ~54 minecraft:polished_deepslate
setblock ~50 ~-68 ~54 minecraft:deepslate_tiles
fill ~51 ~-68 ~54 ~52 ~-68 ~54 minecraft:polished_deepslate
fill ~53 ~-68 ~54 ~61 ~-68 ~54 minecraft:air
fill ~62 ~-68 ~54 ~63 ~-68 ~54 minecraft:polished_deepslate
setblock ~64 ~-68 ~54 minecraft:deepslate_tiles
setblock ~4 ~-68 ~55 minecraft:deepslate_tiles
fill ~5 ~-68 ~55 ~17 ~-68 ~55 minecraft:polished_deepslate
setblock ~18 ~-68 ~55 minecraft:deepslate_tiles
fill ~19 ~-68 ~55 ~31 ~-68 ~55 minecraft:polished_deepslate
setblock ~32 ~-68 ~55 minecraft:deepslate_tiles
setblock ~33 ~-68 ~55 minecraft:polished_deepslate
setblock ~34 ~-68 ~55 minecraft:yellow_concrete
setblock ~35 ~-68 ~55 minecraft:polished_deepslate
setblock ~36 ~-68 ~55 minecraft:deepslate_tiles
fill ~37 ~-68 ~55 ~49 ~-68 ~55 minecraft:polished_deepslate
setblock ~50 ~-68 ~55 minecraft:deepslate_tiles
fill ~51 ~-68 ~55 ~52 ~-68 ~55 minecraft:polished_deepslate
fill ~53 ~-68 ~55 ~61 ~-68 ~55 minecraft:air
fill ~62 ~-68 ~55 ~63 ~-68 ~55 minecraft:polished_deepslate
setblock ~64 ~-68 ~55 minecraft:deepslate_tiles
setblock ~4 ~-68 ~56 minecraft:deepslate_tiles
fill ~5 ~-68 ~56 ~17 ~-68 ~56 minecraft:polished_deepslate
setblock ~18 ~-68 ~56 minecraft:deepslate_tiles
fill ~19 ~-68 ~56 ~31 ~-68 ~56 minecraft:polished_deepslate
setblock ~32 ~-68 ~56 minecraft:deepslate_tiles
setblock ~33 ~-68 ~56 minecraft:polished_deepslate
setblock ~34 ~-68 ~56 minecraft:yellow_concrete
setblock ~35 ~-68 ~56 minecraft:polished_deepslate
setblock ~36 ~-68 ~56 minecraft:deepslate_tiles
fill ~37 ~-68 ~56 ~49 ~-68 ~56 minecraft:polished_deepslate
setblock ~50 ~-68 ~56 minecraft:deepslate_tiles
fill ~51 ~-68 ~56 ~52 ~-68 ~56 minecraft:polished_deepslate
fill ~53 ~-68 ~56 ~61 ~-68 ~56 minecraft:air
fill ~62 ~-68 ~56 ~63 ~-68 ~56 minecraft:polished_deepslate
setblock ~64 ~-68 ~56 minecraft:deepslate_tiles
setblock ~4 ~-68 ~57 minecraft:deepslate_tiles
fill ~5 ~-68 ~57 ~17 ~-68 ~57 minecraft:polished_deepslate
setblock ~18 ~-68 ~57 minecraft:deepslate_tiles
fill ~19 ~-68 ~57 ~31 ~-68 ~57 minecraft:polished_deepslate
setblock ~32 ~-68 ~57 minecraft:deepslate_tiles
setblock ~33 ~-68 ~57 minecraft:polished_deepslate
setblock ~34 ~-68 ~57 minecraft:yellow_concrete
setblock ~35 ~-68 ~57 minecraft:polished_deepslate
setblock ~36 ~-68 ~57 minecraft:deepslate_tiles
fill ~37 ~-68 ~57 ~49 ~-68 ~57 minecraft:polished_deepslate
setblock ~50 ~-68 ~57 minecraft:deepslate_tiles
fill ~51 ~-68 ~57 ~52 ~-68 ~57 minecraft:polished_deepslate
fill ~53 ~-68 ~57 ~61 ~-68 ~57 minecraft:air
fill ~62 ~-68 ~57 ~63 ~-68 ~57 minecraft:polished_deepslate
setblock ~64 ~-68 ~57 minecraft:deepslate_tiles
setblock ~4 ~-68 ~58 minecraft:deepslate_tiles
fill ~5 ~-68 ~58 ~17 ~-68 ~58 minecraft:polished_deepslate
setblock ~18 ~-68 ~58 minecraft:deepslate_tiles
fill ~19 ~-68 ~58 ~31 ~-68 ~58 minecraft:polished_deepslate
setblock ~32 ~-68 ~58 minecraft:deepslate_tiles
setblock ~33 ~-68 ~58 minecraft:polished_deepslate
setblock ~34 ~-68 ~58 minecraft:yellow_concrete
setblock ~35 ~-68 ~58 minecraft:polished_deepslate
setblock ~36 ~-68 ~58 minecraft:deepslate_tiles
fill ~37 ~-68 ~58 ~49 ~-68 ~58 minecraft:polished_deepslate
setblock ~50 ~-68 ~58 minecraft:deepslate_tiles
fill ~51 ~-68 ~58 ~52 ~-68 ~58 minecraft:polished_deepslate
fill ~53 ~-68 ~58 ~61 ~-68 ~58 minecraft:air
fill ~62 ~-68 ~58 ~63 ~-68 ~58 minecraft:polished_deepslate
setblock ~64 ~-68 ~58 minecraft:deepslate_tiles
setblock ~4 ~-68 ~59 minecraft:deepslate_tiles
fill ~5 ~-68 ~59 ~17 ~-68 ~59 minecraft:polished_deepslate
setblock ~18 ~-68 ~59 minecraft:deepslate_tiles
fill ~19 ~-68 ~59 ~31 ~-68 ~59 minecraft:polished_deepslate
setblock ~32 ~-68 ~59 minecraft:deepslate_tiles
setblock ~33 ~-68 ~59 minecraft:polished_deepslate
setblock ~34 ~-68 ~59 minecraft:yellow_concrete
setblock ~35 ~-68 ~59 minecraft:polished_deepslate
setblock ~36 ~-68 ~59 minecraft:deepslate_tiles
fill ~37 ~-68 ~59 ~49 ~-68 ~59 minecraft:polished_deepslate
setblock ~50 ~-68 ~59 minecraft:deepslate_tiles
fill ~51 ~-68 ~59 ~52 ~-68 ~59 minecraft:polished_deepslate
fill ~53 ~-68 ~59 ~61 ~-68 ~59 minecraft:air
fill ~62 ~-68 ~59 ~63 ~-68 ~59 minecraft:polished_deepslate
setblock ~64 ~-68 ~59 minecraft:deepslate_tiles
setblock ~4 ~-68 ~60 minecraft:deepslate_tiles
fill ~5 ~-68 ~60 ~17 ~-68 ~60 minecraft:polished_deepslate
setblock ~18 ~-68 ~60 minecraft:deepslate_tiles
fill ~19 ~-68 ~60 ~31 ~-68 ~60 minecraft:polished_deepslate
setblock ~32 ~-68 ~60 minecraft:deepslate_tiles
setblock ~33 ~-68 ~60 minecraft:polished_deepslate
setblock ~34 ~-68 ~60 minecraft:yellow_concrete
setblock ~35 ~-68 ~60 minecraft:polished_deepslate
setblock ~36 ~-68 ~60 minecraft:deepslate_tiles
fill ~37 ~-68 ~60 ~49 ~-68 ~60 minecraft:polished_deepslate
setblock ~50 ~-68 ~60 minecraft:deepslate_tiles
fill ~51 ~-68 ~60 ~52 ~-68 ~60 minecraft:polished_deepslate
fill ~53 ~-68 ~60 ~61 ~-68 ~60 minecraft:air
fill ~62 ~-68 ~60 ~63 ~-68 ~60 minecraft:polished_deepslate
setblock ~64 ~-68 ~60 minecraft:deepslate_tiles
setblock ~4 ~-68 ~61 minecraft:deepslate_tiles
fill ~5 ~-68 ~61 ~17 ~-68 ~61 minecraft:polished_deepslate
setblock ~18 ~-68 ~61 minecraft:deepslate_tiles
fill ~19 ~-68 ~61 ~31 ~-68 ~61 minecraft:polished_deepslate
setblock ~32 ~-68 ~61 minecraft:deepslate_tiles
setblock ~33 ~-68 ~61 minecraft:polished_deepslate
setblock ~34 ~-68 ~61 minecraft:yellow_concrete
setblock ~35 ~-68 ~61 minecraft:polished_deepslate
setblock ~36 ~-68 ~61 minecraft:deepslate_tiles
fill ~37 ~-68 ~61 ~49 ~-68 ~61 minecraft:polished_deepslate
setblock ~50 ~-68 ~61 minecraft:deepslate_tiles
fill ~51 ~-68 ~61 ~52 ~-68 ~61 minecraft:polished_deepslate
fill ~53 ~-68 ~61 ~61 ~-68 ~61 minecraft:air
fill ~62 ~-68 ~61 ~63 ~-68 ~61 minecraft:polished_deepslate
setblock ~64 ~-68 ~61 minecraft:deepslate_tiles
setblock ~4 ~-68 ~62 minecraft:deepslate_tiles
fill ~5 ~-68 ~62 ~17 ~-68 ~62 minecraft:polished_deepslate
setblock ~18 ~-68 ~62 minecraft:deepslate_tiles
fill ~19 ~-68 ~62 ~31 ~-68 ~62 minecraft:polished_deepslate
setblock ~32 ~-68 ~62 minecraft:deepslate_tiles
setblock ~33 ~-68 ~62 minecraft:polished_deepslate
setblock ~34 ~-68 ~62 minecraft:yellow_concrete
setblock ~35 ~-68 ~62 minecraft:polished_deepslate
setblock ~36 ~-68 ~62 minecraft:deepslate_tiles
fill ~37 ~-68 ~62 ~49 ~-68 ~62 minecraft:polished_deepslate
setblock ~50 ~-68 ~62 minecraft:deepslate_tiles
fill ~51 ~-68 ~62 ~63 ~-68 ~62 minecraft:polished_deepslate
setblock ~64 ~-68 ~62 minecraft:deepslate_tiles
setblock ~4 ~-68 ~63 minecraft:deepslate_tiles
fill ~5 ~-68 ~63 ~17 ~-68 ~63 minecraft:polished_deepslate
setblock ~18 ~-68 ~63 minecraft:deepslate_tiles
fill ~19 ~-68 ~63 ~31 ~-68 ~63 minecraft:polished_deepslate
setblock ~32 ~-68 ~63 minecraft:deepslate_tiles
setblock ~33 ~-68 ~63 minecraft:polished_deepslate
setblock ~34 ~-68 ~63 minecraft:yellow_concrete
setblock ~35 ~-68 ~63 minecraft:polished_deepslate
setblock ~36 ~-68 ~63 minecraft:deepslate_tiles
fill ~37 ~-68 ~63 ~49 ~-68 ~63 minecraft:polished_deepslate
setblock ~50 ~-68 ~63 minecraft:deepslate_tiles
fill ~51 ~-68 ~63 ~63 ~-68 ~63 minecraft:polished_deepslate
setblock ~64 ~-68 ~63 minecraft:deepslate_tiles
fill ~4 ~-68 ~64 ~64 ~-68 ~64 minecraft:deepslate_tiles
setblock ~34 ~-68 ~65 minecraft:polished_deepslate
fill ~32 ~-68 ~66 ~36 ~-68 ~66 minecraft:polished_andesite
setblock ~32 ~-68 ~67 minecraft:polished_andesite
setblock ~34 ~-68 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~36 ~-68 ~67 minecraft:polished_andesite
setblock ~32 ~-68 ~68 minecraft:polished_andesite
setblock ~34 ~-68 ~68 minecraft:quartz_pillar
setblock ~36 ~-68 ~68 minecraft:polished_andesite
setblock ~32 ~-68 ~69 minecraft:polished_andesite
setblock ~36 ~-68 ~69 minecraft:polished_andesite
fill ~32 ~-68 ~70 ~36 ~-68 ~70 minecraft:polished_andesite
fill ~4 ~-67 ~4 ~64 ~-67 ~4 minecraft:deepslate_tiles
setblock ~4 ~-67 ~5 minecraft:deepslate_tiles
setblock ~5 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~6 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~8 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~9 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~10 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~11 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~12 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~13 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~14 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~15 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~16 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~17 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~18 ~-67 ~5 minecraft:deepslate_tiles
setblock ~19 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~20 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~21 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~22 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~23 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~24 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~25 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~26 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~27 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~28 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~29 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~30 ~-67 ~5 minecraft:waxed_cut_copper
setblock ~31 ~-67 ~5 minecraft:blast_furnace[facing=south]
setblock ~32 ~-67 ~5 minecraft:deepslate_tiles
fill ~33 ~-67 ~5 ~35 ~-67 ~5 minecraft:air
setblock ~36 ~-67 ~5 minecraft:deepslate_tiles
setblock ~37 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~38 ~-67 ~5 ~39 ~-67 ~5 minecraft:air
setblock ~40 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~41 ~-67 ~5 ~42 ~-67 ~5 minecraft:air
setblock ~43 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~44 ~-67 ~5 ~45 ~-67 ~5 minecraft:air
setblock ~46 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~47 ~-67 ~5 ~48 ~-67 ~5 minecraft:air
setblock ~49 ~-67 ~5 minecraft:dispenser[facing=south]
setblock ~50 ~-67 ~5 minecraft:deepslate_tiles
setblock ~51 ~-67 ~5 minecraft:air
setblock ~52 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~53 ~-67 ~5 ~54 ~-67 ~5 minecraft:air
setblock ~55 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~56 ~-67 ~5 ~57 ~-67 ~5 minecraft:air
setblock ~58 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~59 ~-67 ~5 ~60 ~-67 ~5 minecraft:air
setblock ~61 ~-67 ~5 minecraft:dispenser[facing=south]
fill ~62 ~-67 ~5 ~63 ~-67 ~5 minecraft:air
setblock ~64 ~-67 ~5 minecraft:deepslate_tiles
setblock ~4 ~-67 ~6 minecraft:deepslate_tiles
setblock ~5 ~-67 ~6 minecraft:waxed_cut_copper
fill ~6 ~-67 ~6 ~16 ~-67 ~6 minecraft:air
setblock ~17 ~-67 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~6 minecraft:deepslate_tiles
setblock ~19 ~-67 ~6 minecraft:waxed_cut_copper
fill ~20 ~-67 ~6 ~30 ~-67 ~6 minecraft:air
setblock ~31 ~-67 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-67 ~6 minecraft:deepslate_tiles
fill ~33 ~-67 ~6 ~35 ~-67 ~6 minecraft:air
setblock ~36 ~-67 ~6 minecraft:deepslate_tiles
fill ~37 ~-67 ~6 ~49 ~-67 ~6 minecraft:air
setblock ~50 ~-67 ~6 minecraft:deepslate_tiles
setblock ~51 ~-67 ~6 minecraft:dispenser[facing=east]
fill ~52 ~-67 ~6 ~62 ~-67 ~6 minecraft:air
setblock ~63 ~-67 ~6 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~6 minecraft:deepslate_tiles
setblock ~4 ~-67 ~7 minecraft:deepslate_tiles
setblock ~5 ~-67 ~7 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~7 ~16 ~-67 ~7 minecraft:air
setblock ~17 ~-67 ~7 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~7 minecraft:deepslate_tiles
setblock ~19 ~-67 ~7 minecraft:blast_furnace[facing=east]
fill ~20 ~-67 ~7 ~30 ~-67 ~7 minecraft:air
setblock ~31 ~-67 ~7 minecraft:blast_furnace[facing=west]
setblock ~32 ~-67 ~7 minecraft:deepslate_tiles
fill ~33 ~-67 ~7 ~35 ~-67 ~7 minecraft:air
setblock ~36 ~-67 ~7 minecraft:deepslate_tiles
fill ~37 ~-67 ~7 ~49 ~-67 ~7 minecraft:air
setblock ~50 ~-67 ~7 minecraft:deepslate_tiles
fill ~51 ~-67 ~7 ~63 ~-67 ~7 minecraft:air
setblock ~64 ~-67 ~7 minecraft:deepslate_tiles
setblock ~4 ~-67 ~8 minecraft:deepslate_tiles
setblock ~5 ~-67 ~8 minecraft:waxed_cut_copper
fill ~6 ~-67 ~8 ~16 ~-67 ~8 minecraft:air
setblock ~17 ~-67 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~8 minecraft:deepslate_tiles
setblock ~19 ~-67 ~8 minecraft:waxed_cut_copper
fill ~20 ~-67 ~8 ~30 ~-67 ~8 minecraft:air
setblock ~31 ~-67 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-67 ~8 minecraft:deepslate_tiles
fill ~33 ~-67 ~8 ~35 ~-67 ~8 minecraft:air
setblock ~36 ~-67 ~8 minecraft:deepslate_tiles
setblock ~37 ~-67 ~8 minecraft:dispenser[facing=east]
fill ~38 ~-67 ~8 ~48 ~-67 ~8 minecraft:air
setblock ~49 ~-67 ~8 minecraft:dispenser[facing=west]
setblock ~50 ~-67 ~8 minecraft:deepslate_tiles
fill ~51 ~-67 ~8 ~63 ~-67 ~8 minecraft:air
setblock ~64 ~-67 ~8 minecraft:deepslate_tiles
setblock ~4 ~-67 ~9 minecraft:deepslate_tiles
setblock ~5 ~-67 ~9 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~9 ~16 ~-67 ~9 minecraft:air
setblock ~17 ~-67 ~9 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~9 minecraft:deepslate_tiles
setblock ~19 ~-67 ~9 minecraft:blast_furnace[facing=east]
fill ~20 ~-67 ~9 ~30 ~-67 ~9 minecraft:air
setblock ~31 ~-67 ~9 minecraft:blast_furnace[facing=west]
setblock ~32 ~-67 ~9 minecraft:deepslate_tiles
fill ~33 ~-67 ~9 ~35 ~-67 ~9 minecraft:air
setblock ~36 ~-67 ~9 minecraft:deepslate_tiles
fill ~37 ~-67 ~9 ~49 ~-67 ~9 minecraft:air
setblock ~50 ~-67 ~9 minecraft:deepslate_tiles
setblock ~51 ~-67 ~9 minecraft:dispenser[facing=east]
fill ~52 ~-67 ~9 ~62 ~-67 ~9 minecraft:air
setblock ~63 ~-67 ~9 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~9 minecraft:deepslate_tiles
setblock ~4 ~-67 ~10 minecraft:deepslate_tiles
setblock ~5 ~-67 ~10 minecraft:waxed_cut_copper
fill ~6 ~-67 ~10 ~17 ~-67 ~10 minecraft:air
setblock ~18 ~-67 ~10 minecraft:deepslate_tiles
fill ~19 ~-67 ~10 ~31 ~-67 ~10 minecraft:air
setblock ~32 ~-67 ~10 minecraft:deepslate_tiles
fill ~33 ~-67 ~10 ~35 ~-67 ~10 minecraft:air
setblock ~36 ~-67 ~10 minecraft:deepslate_tiles
fill ~37 ~-67 ~10 ~49 ~-67 ~10 minecraft:air
setblock ~50 ~-67 ~10 minecraft:deepslate_tiles
fill ~51 ~-67 ~10 ~63 ~-67 ~10 minecraft:air
setblock ~64 ~-67 ~10 minecraft:deepslate_tiles
setblock ~4 ~-67 ~11 minecraft:deepslate_tiles
setblock ~5 ~-67 ~11 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~11 ~63 ~-67 ~11 minecraft:air
setblock ~64 ~-67 ~11 minecraft:deepslate_tiles
setblock ~4 ~-67 ~12 minecraft:deepslate_tiles
setblock ~5 ~-67 ~12 minecraft:waxed_cut_copper
fill ~6 ~-67 ~12 ~11 ~-67 ~12 minecraft:air
setblock ~12 ~-67 ~12 minecraft:waxed_cut_copper
fill ~13 ~-67 ~12 ~17 ~-67 ~12 minecraft:air
setblock ~18 ~-67 ~12 minecraft:deepslate_tiles
fill ~19 ~-67 ~12 ~21 ~-67 ~12 minecraft:air
setblock ~22 ~-67 ~12 minecraft:waxed_cut_copper
fill ~23 ~-67 ~12 ~26 ~-67 ~12 minecraft:air
setblock ~27 ~-67 ~12 minecraft:waxed_cut_copper
fill ~28 ~-67 ~12 ~31 ~-67 ~12 minecraft:air
setblock ~32 ~-67 ~12 minecraft:deepslate_tiles
fill ~33 ~-67 ~12 ~35 ~-67 ~12 minecraft:air
setblock ~36 ~-67 ~12 minecraft:deepslate_tiles
fill ~37 ~-67 ~12 ~49 ~-67 ~12 minecraft:air
setblock ~50 ~-67 ~12 minecraft:deepslate_tiles
fill ~51 ~-67 ~12 ~62 ~-67 ~12 minecraft:air
setblock ~63 ~-67 ~12 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~12 minecraft:deepslate_tiles
setblock ~4 ~-67 ~13 minecraft:deepslate_tiles
setblock ~5 ~-67 ~13 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~13 ~16 ~-67 ~13 minecraft:air
setblock ~17 ~-67 ~13 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~13 minecraft:deepslate_tiles
setblock ~19 ~-67 ~13 minecraft:blast_furnace[facing=east]
fill ~20 ~-67 ~13 ~30 ~-67 ~13 minecraft:air
setblock ~31 ~-67 ~13 minecraft:blast_furnace[facing=west]
setblock ~32 ~-67 ~13 minecraft:deepslate_tiles
fill ~33 ~-67 ~13 ~35 ~-67 ~13 minecraft:air
setblock ~36 ~-67 ~13 minecraft:deepslate_tiles
fill ~37 ~-67 ~13 ~49 ~-67 ~13 minecraft:air
setblock ~50 ~-67 ~13 minecraft:deepslate_tiles
fill ~51 ~-67 ~13 ~63 ~-67 ~13 minecraft:air
setblock ~64 ~-67 ~13 minecraft:deepslate_tiles
setblock ~4 ~-67 ~14 minecraft:deepslate_tiles
setblock ~5 ~-67 ~14 minecraft:waxed_cut_copper
fill ~6 ~-67 ~14 ~16 ~-67 ~14 minecraft:air
setblock ~17 ~-67 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~14 minecraft:deepslate_tiles
setblock ~19 ~-67 ~14 minecraft:waxed_cut_copper
fill ~20 ~-67 ~14 ~30 ~-67 ~14 minecraft:air
setblock ~31 ~-67 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-67 ~14 minecraft:deepslate_tiles
fill ~33 ~-67 ~14 ~35 ~-67 ~14 minecraft:air
setblock ~36 ~-67 ~14 minecraft:deepslate_tiles
setblock ~37 ~-67 ~14 minecraft:dispenser[facing=east]
fill ~38 ~-67 ~14 ~48 ~-67 ~14 minecraft:air
setblock ~49 ~-67 ~14 minecraft:dispenser[facing=west]
setblock ~50 ~-67 ~14 minecraft:deepslate_tiles
fill ~51 ~-67 ~14 ~63 ~-67 ~14 minecraft:air
setblock ~64 ~-67 ~14 minecraft:deepslate_tiles
setblock ~4 ~-67 ~15 minecraft:deepslate_tiles
setblock ~5 ~-67 ~15 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~15 ~16 ~-67 ~15 minecraft:air
setblock ~17 ~-67 ~15 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~15 minecraft:deepslate_tiles
setblock ~19 ~-67 ~15 minecraft:blast_furnace[facing=east]
fill ~20 ~-67 ~15 ~30 ~-67 ~15 minecraft:air
setblock ~31 ~-67 ~15 minecraft:blast_furnace[facing=west]
setblock ~32 ~-67 ~15 minecraft:deepslate_tiles
fill ~33 ~-67 ~15 ~35 ~-67 ~15 minecraft:air
setblock ~36 ~-67 ~15 minecraft:deepslate_tiles
fill ~37 ~-67 ~15 ~49 ~-67 ~15 minecraft:air
setblock ~50 ~-67 ~15 minecraft:deepslate_tiles
setblock ~51 ~-67 ~15 minecraft:dispenser[facing=east]
fill ~52 ~-67 ~15 ~62 ~-67 ~15 minecraft:air
setblock ~63 ~-67 ~15 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~15 minecraft:deepslate_tiles
setblock ~4 ~-67 ~16 minecraft:deepslate_tiles
setblock ~5 ~-67 ~16 minecraft:waxed_cut_copper
fill ~6 ~-67 ~16 ~16 ~-67 ~16 minecraft:air
setblock ~17 ~-67 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~16 minecraft:deepslate_tiles
setblock ~19 ~-67 ~16 minecraft:waxed_cut_copper
fill ~20 ~-67 ~16 ~30 ~-67 ~16 minecraft:air
setblock ~31 ~-67 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-67 ~16 minecraft:deepslate_tiles
fill ~33 ~-67 ~16 ~35 ~-67 ~16 minecraft:air
setblock ~36 ~-67 ~16 minecraft:deepslate_tiles
fill ~37 ~-67 ~16 ~49 ~-67 ~16 minecraft:air
setblock ~50 ~-67 ~16 minecraft:deepslate_tiles
fill ~51 ~-67 ~16 ~63 ~-67 ~16 minecraft:air
setblock ~64 ~-67 ~16 minecraft:deepslate_tiles
setblock ~4 ~-67 ~17 minecraft:deepslate_tiles
setblock ~5 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~6 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~8 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~9 ~-67 ~17 minecraft:blast_furnace[facing=north]
fill ~10 ~-67 ~17 ~12 ~-67 ~17 minecraft:air
setblock ~13 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~14 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~15 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~16 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~17 ~-67 ~17 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~17 minecraft:deepslate_tiles
setblock ~19 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~20 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~21 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~22 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~23 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~24 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~25 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~26 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~27 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~28 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~29 ~-67 ~17 minecraft:blast_furnace[facing=north]
setblock ~30 ~-67 ~17 minecraft:waxed_cut_copper
setblock ~31 ~-67 ~17 minecraft:blast_furnace[facing=west]
setblock ~32 ~-67 ~17 minecraft:deepslate_tiles
fill ~33 ~-67 ~17 ~35 ~-67 ~17 minecraft:air
setblock ~36 ~-67 ~17 minecraft:deepslate_tiles
setblock ~37 ~-67 ~17 minecraft:dispenser[facing=north]
fill ~38 ~-67 ~17 ~39 ~-67 ~17 minecraft:air
setblock ~40 ~-67 ~17 minecraft:dispenser[facing=north]
fill ~41 ~-67 ~17 ~42 ~-67 ~17 minecraft:air
setblock ~43 ~-67 ~17 minecraft:dispenser[facing=north]
fill ~44 ~-67 ~17 ~45 ~-67 ~17 minecraft:air
setblock ~46 ~-67 ~17 minecraft:dispenser[facing=north]
fill ~47 ~-67 ~17 ~48 ~-67 ~17 minecraft:air
setblock ~49 ~-67 ~17 minecraft:dispenser[facing=west]
setblock ~50 ~-67 ~17 minecraft:deepslate_tiles
setblock ~51 ~-67 ~17 minecraft:air
setblock ~52 ~-67 ~17 minecraft:dispenser[facing=north]
fill ~53 ~-67 ~17 ~54 ~-67 ~17 minecraft:air
setblock ~55 ~-67 ~17 minecraft:dispenser[facing=north]
fill ~56 ~-67 ~17 ~60 ~-67 ~17 minecraft:air
setblock ~61 ~-67 ~17 minecraft:dispenser[facing=north]
fill ~62 ~-67 ~17 ~63 ~-67 ~17 minecraft:air
setblock ~64 ~-67 ~17 minecraft:deepslate_tiles
fill ~4 ~-67 ~18 ~10 ~-67 ~18 minecraft:deepslate_tiles
setblock ~11 ~-67 ~18 minecraft:air
fill ~12 ~-67 ~18 ~32 ~-67 ~18 minecraft:deepslate_tiles
fill ~33 ~-67 ~18 ~35 ~-67 ~18 minecraft:air
fill ~36 ~-67 ~18 ~56 ~-67 ~18 minecraft:deepslate_tiles
setblock ~57 ~-67 ~18 minecraft:air
fill ~58 ~-67 ~18 ~64 ~-67 ~18 minecraft:deepslate_tiles
setblock ~4 ~-67 ~19 minecraft:deepslate_tiles
setblock ~5 ~-67 ~19 minecraft:blast_furnace[facing=south]
setblock ~6 ~-67 ~19 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~19 minecraft:dispenser[facing=south]
setblock ~8 ~-67 ~19 minecraft:blast_furnace[facing=south]
setblock ~9 ~-67 ~19 minecraft:waxed_cut_copper
fill ~10 ~-67 ~19 ~12 ~-67 ~19 minecraft:air
setblock ~13 ~-67 ~19 minecraft:dispenser[facing=south]
setblock ~14 ~-67 ~19 minecraft:blast_furnace[facing=south]
setblock ~15 ~-67 ~19 minecraft:waxed_cut_copper
setblock ~16 ~-67 ~19 minecraft:dispenser[facing=south]
setblock ~17 ~-67 ~19 minecraft:blast_furnace[facing=south]
setblock ~18 ~-67 ~19 minecraft:deepslate_tiles
setblock ~19 ~-67 ~19 minecraft:chest[facing=south]
setblock ~20 ~-67 ~19 minecraft:air
setblock ~21 ~-67 ~19 minecraft:chest[facing=south]
setblock ~22 ~-67 ~19 minecraft:air
setblock ~23 ~-67 ~19 minecraft:chest[facing=south]
setblock ~24 ~-67 ~19 minecraft:air
setblock ~25 ~-67 ~19 minecraft:chest[facing=south]
setblock ~26 ~-67 ~19 minecraft:air
setblock ~27 ~-67 ~19 minecraft:chest[facing=south]
setblock ~28 ~-67 ~19 minecraft:air
setblock ~29 ~-67 ~19 minecraft:chest[facing=south]
fill ~30 ~-67 ~19 ~38 ~-67 ~19 minecraft:air
setblock ~39 ~-67 ~19 minecraft:chest[facing=south]
setblock ~40 ~-67 ~19 minecraft:air
setblock ~41 ~-67 ~19 minecraft:chest[facing=south]
setblock ~42 ~-67 ~19 minecraft:air
setblock ~43 ~-67 ~19 minecraft:chest[facing=south]
setblock ~44 ~-67 ~19 minecraft:air
setblock ~45 ~-67 ~19 minecraft:chest[facing=south]
setblock ~46 ~-67 ~19 minecraft:air
setblock ~47 ~-67 ~19 minecraft:chest[facing=south]
setblock ~48 ~-67 ~19 minecraft:air
setblock ~49 ~-67 ~19 minecraft:chest[facing=south]
setblock ~50 ~-67 ~19 minecraft:deepslate_tiles
setblock ~51 ~-67 ~19 minecraft:barrel
setblock ~52 ~-67 ~19 minecraft:iron_block
setblock ~53 ~-67 ~19 minecraft:crafting_table
setblock ~54 ~-67 ~19 minecraft:smithing_table
setblock ~55 ~-67 ~19 minecraft:barrel
fill ~56 ~-67 ~19 ~58 ~-67 ~19 minecraft:air
setblock ~59 ~-67 ~19 minecraft:barrel
setblock ~60 ~-67 ~19 minecraft:iron_block
setblock ~61 ~-67 ~19 minecraft:crafting_table
setblock ~62 ~-67 ~19 minecraft:smithing_table
setblock ~63 ~-67 ~19 minecraft:barrel
setblock ~64 ~-67 ~19 minecraft:deepslate_tiles
setblock ~4 ~-67 ~20 minecraft:deepslate_tiles
setblock ~5 ~-67 ~20 minecraft:waxed_cut_copper
fill ~6 ~-67 ~20 ~16 ~-67 ~20 minecraft:air
setblock ~17 ~-67 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~20 minecraft:deepslate_tiles
fill ~19 ~-67 ~20 ~27 ~-67 ~20 minecraft:air
setblock ~28 ~-67 ~20 minecraft:chest[facing=west]
fill ~29 ~-67 ~20 ~32 ~-67 ~20 minecraft:deepslate_tiles
fill ~33 ~-67 ~20 ~35 ~-67 ~20 minecraft:air
fill ~36 ~-67 ~20 ~39 ~-67 ~20 minecraft:deepslate_tiles
setblock ~40 ~-67 ~20 minecraft:chest[facing=north]
fill ~41 ~-67 ~20 ~49 ~-67 ~20 minecraft:air
setblock ~50 ~-67 ~20 minecraft:deepslate_tiles
setblock ~51 ~-67 ~20 minecraft:iron_block
fill ~52 ~-67 ~20 ~62 ~-67 ~20 minecraft:air
setblock ~63 ~-67 ~20 minecraft:iron_block
setblock ~64 ~-67 ~20 minecraft:deepslate_tiles
setblock ~4 ~-67 ~21 minecraft:deepslate_tiles
setblock ~5 ~-67 ~21 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~21 ~16 ~-67 ~21 minecraft:air
setblock ~17 ~-67 ~21 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~21 minecraft:deepslate_tiles
setblock ~19 ~-67 ~21 minecraft:chest[facing=east]
fill ~20 ~-67 ~21 ~23 ~-67 ~21 minecraft:barrel
setblock ~24 ~-67 ~21 minecraft:air
fill ~25 ~-67 ~21 ~26 ~-67 ~21 minecraft:barrel
fill ~27 ~-67 ~21 ~28 ~-67 ~21 minecraft:deepslate_tiles
fill ~29 ~-67 ~21 ~39 ~-67 ~21 minecraft:air
fill ~40 ~-67 ~21 ~41 ~-67 ~21 minecraft:deepslate_tiles
setblock ~42 ~-67 ~21 minecraft:air
fill ~43 ~-67 ~21 ~46 ~-67 ~21 minecraft:barrel
setblock ~47 ~-67 ~21 minecraft:air
setblock ~48 ~-67 ~21 minecraft:barrel
setblock ~49 ~-67 ~21 minecraft:chest[facing=west]
setblock ~50 ~-67 ~21 minecraft:deepslate_tiles
setblock ~51 ~-67 ~21 minecraft:crafting_table
fill ~52 ~-67 ~21 ~62 ~-67 ~21 minecraft:air
setblock ~63 ~-67 ~21 minecraft:crafting_table
setblock ~64 ~-67 ~21 minecraft:deepslate_tiles
setblock ~4 ~-67 ~22 minecraft:deepslate_tiles
setblock ~5 ~-67 ~22 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~22 ~9 ~-67 ~22 minecraft:air
setblock ~10 ~-67 ~22 minecraft:waxed_cut_copper
fill ~11 ~-67 ~22 ~13 ~-67 ~22 minecraft:air
setblock ~14 ~-67 ~22 minecraft:waxed_cut_copper
fill ~15 ~-67 ~22 ~16 ~-67 ~22 minecraft:air
setblock ~17 ~-67 ~22 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~22 minecraft:deepslate_tiles
fill ~19 ~-67 ~22 ~23 ~-67 ~22 minecraft:air
setblock ~24 ~-67 ~22 minecraft:chest[facing=west]
fill ~25 ~-67 ~22 ~26 ~-67 ~22 minecraft:deepslate_tiles
fill ~27 ~-67 ~22 ~41 ~-67 ~22 minecraft:air
fill ~42 ~-67 ~22 ~43 ~-67 ~22 minecraft:deepslate_tiles
setblock ~44 ~-67 ~22 minecraft:chest[facing=north]
fill ~45 ~-67 ~22 ~49 ~-67 ~22 minecraft:air
setblock ~50 ~-67 ~22 minecraft:deepslate_tiles
setblock ~51 ~-67 ~22 minecraft:smithing_table
fill ~52 ~-67 ~22 ~54 ~-67 ~22 minecraft:air
setblock ~55 ~-67 ~22 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-67 ~22 ~58 ~-67 ~22 minecraft:air
setblock ~59 ~-67 ~22 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-67 ~22 ~62 ~-67 ~22 minecraft:air
setblock ~63 ~-67 ~22 minecraft:smithing_table
setblock ~64 ~-67 ~22 minecraft:deepslate_tiles
setblock ~4 ~-67 ~23 minecraft:deepslate_tiles
setblock ~5 ~-67 ~23 minecraft:waxed_cut_copper
fill ~6 ~-67 ~23 ~16 ~-67 ~23 minecraft:air
setblock ~17 ~-67 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~23 minecraft:deepslate_tiles
setblock ~19 ~-67 ~23 minecraft:chest[facing=east]
fill ~20 ~-67 ~23 ~22 ~-67 ~23 minecraft:air
setblock ~23 ~-67 ~23 minecraft:chest[facing=west]
fill ~24 ~-67 ~23 ~25 ~-67 ~23 minecraft:deepslate_tiles
fill ~26 ~-67 ~23 ~32 ~-67 ~23 minecraft:air
fill ~33 ~-67 ~23 ~35 ~-67 ~23 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~36 ~-67 ~23 ~42 ~-67 ~23 minecraft:air
fill ~43 ~-67 ~23 ~44 ~-67 ~23 minecraft:deepslate_tiles
setblock ~45 ~-67 ~23 minecraft:chest[facing=north]
fill ~46 ~-67 ~23 ~48 ~-67 ~23 minecraft:air
setblock ~49 ~-67 ~23 minecraft:chest[facing=west]
setblock ~50 ~-67 ~23 minecraft:deepslate_tiles
setblock ~51 ~-67 ~23 minecraft:barrel
fill ~52 ~-67 ~23 ~54 ~-67 ~23 minecraft:air
setblock ~55 ~-67 ~23 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-67 ~23 ~58 ~-67 ~23 minecraft:air
setblock ~59 ~-67 ~23 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-67 ~23 ~62 ~-67 ~23 minecraft:air
setblock ~63 ~-67 ~23 minecraft:barrel
setblock ~64 ~-67 ~23 minecraft:deepslate_tiles
setblock ~4 ~-67 ~24 minecraft:deepslate_tiles
setblock ~5 ~-67 ~24 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~24 ~16 ~-67 ~24 minecraft:air
setblock ~17 ~-67 ~24 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~24 minecraft:deepslate_tiles
setblock ~19 ~-67 ~24 minecraft:air
fill ~20 ~-67 ~24 ~22 ~-67 ~24 minecraft:barrel
fill ~23 ~-67 ~24 ~24 ~-67 ~24 minecraft:deepslate_tiles
fill ~25 ~-67 ~24 ~32 ~-67 ~24 minecraft:air
fill ~33 ~-67 ~24 ~35 ~-67 ~24 minecraft:smooth_stone_slab[type=top]
fill ~36 ~-67 ~24 ~43 ~-67 ~24 minecraft:air
fill ~44 ~-67 ~24 ~45 ~-67 ~24 minecraft:deepslate_tiles
setblock ~46 ~-67 ~24 minecraft:barrel
setblock ~47 ~-67 ~24 minecraft:air
setblock ~48 ~-67 ~24 minecraft:barrel
setblock ~49 ~-67 ~24 minecraft:air
setblock ~50 ~-67 ~24 minecraft:deepslate_tiles
setblock ~51 ~-67 ~24 minecraft:iron_block
fill ~52 ~-67 ~24 ~54 ~-67 ~24 minecraft:air
setblock ~55 ~-67 ~24 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-67 ~24 ~58 ~-67 ~24 minecraft:air
setblock ~59 ~-67 ~24 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-67 ~24 ~62 ~-67 ~24 minecraft:air
setblock ~63 ~-67 ~24 minecraft:iron_block
setblock ~64 ~-67 ~24 minecraft:deepslate_tiles
setblock ~4 ~-67 ~25 minecraft:deepslate_tiles
setblock ~5 ~-67 ~25 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~25 ~16 ~-67 ~25 minecraft:air
setblock ~17 ~-67 ~25 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~25 minecraft:deepslate_tiles
setblock ~19 ~-67 ~25 minecraft:chest[facing=east]
setblock ~20 ~-67 ~25 minecraft:air
setblock ~21 ~-67 ~25 minecraft:chest[facing=west]
fill ~22 ~-67 ~25 ~23 ~-67 ~25 minecraft:deepslate_tiles
fill ~24 ~-67 ~25 ~44 ~-67 ~25 minecraft:air
fill ~45 ~-67 ~25 ~46 ~-67 ~25 minecraft:deepslate_tiles
setblock ~47 ~-67 ~25 minecraft:chest[facing=east]
setblock ~48 ~-67 ~25 minecraft:air
setblock ~49 ~-67 ~25 minecraft:chest[facing=west]
setblock ~50 ~-67 ~25 minecraft:deepslate_tiles
setblock ~51 ~-67 ~25 minecraft:crafting_table
fill ~52 ~-67 ~25 ~54 ~-67 ~25 minecraft:air
setblock ~55 ~-67 ~25 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-67 ~25 ~58 ~-67 ~25 minecraft:air
setblock ~59 ~-67 ~25 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-67 ~25 ~62 ~-67 ~25 minecraft:air
setblock ~63 ~-67 ~25 minecraft:crafting_table
setblock ~64 ~-67 ~25 minecraft:deepslate_tiles
setblock ~4 ~-67 ~26 minecraft:deepslate_tiles
setblock ~5 ~-67 ~26 minecraft:waxed_cut_copper
fill ~6 ~-67 ~26 ~9 ~-67 ~26 minecraft:air
setblock ~10 ~-67 ~26 minecraft:waxed_cut_copper
fill ~11 ~-67 ~26 ~13 ~-67 ~26 minecraft:air
setblock ~14 ~-67 ~26 minecraft:waxed_cut_copper
fill ~15 ~-67 ~26 ~16 ~-67 ~26 minecraft:air
setblock ~17 ~-67 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~26 minecraft:deepslate_tiles
fill ~19 ~-67 ~26 ~21 ~-67 ~26 minecraft:air
setblock ~22 ~-67 ~26 minecraft:deepslate_tiles
fill ~23 ~-67 ~26 ~25 ~-67 ~26 minecraft:air
setblock ~26 ~-67 ~26 minecraft:waxed_cut_copper
fill ~27 ~-67 ~26 ~41 ~-67 ~26 minecraft:air
setblock ~42 ~-67 ~26 minecraft:waxed_cut_copper
fill ~43 ~-67 ~26 ~45 ~-67 ~26 minecraft:air
setblock ~46 ~-67 ~26 minecraft:deepslate_tiles
fill ~47 ~-67 ~26 ~49 ~-67 ~26 minecraft:air
setblock ~50 ~-67 ~26 minecraft:deepslate_tiles
setblock ~51 ~-67 ~26 minecraft:smithing_table
fill ~52 ~-67 ~26 ~54 ~-67 ~26 minecraft:air
setblock ~55 ~-67 ~26 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-67 ~26 ~58 ~-67 ~26 minecraft:air
setblock ~59 ~-67 ~26 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-67 ~26 ~62 ~-67 ~26 minecraft:air
setblock ~63 ~-67 ~26 minecraft:smithing_table
setblock ~64 ~-67 ~26 minecraft:deepslate_tiles
setblock ~4 ~-67 ~27 minecraft:deepslate_tiles
setblock ~5 ~-67 ~27 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~27 ~16 ~-67 ~27 minecraft:air
setblock ~17 ~-67 ~27 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~27 minecraft:deepslate_tiles
setblock ~19 ~-67 ~27 minecraft:chest[facing=east]
setblock ~20 ~-67 ~27 minecraft:barrel
setblock ~21 ~-67 ~27 minecraft:deepslate_tiles
fill ~22 ~-67 ~27 ~31 ~-67 ~27 minecraft:air
setblock ~32 ~-67 ~27 minecraft:iron_bars
fill ~33 ~-67 ~27 ~35 ~-67 ~27 minecraft:air
setblock ~36 ~-67 ~27 minecraft:iron_bars
fill ~37 ~-67 ~27 ~46 ~-67 ~27 minecraft:air
setblock ~47 ~-67 ~27 minecraft:deepslate_tiles
setblock ~48 ~-67 ~27 minecraft:barrel
setblock ~49 ~-67 ~27 minecraft:chest[facing=west]
setblock ~50 ~-67 ~27 minecraft:deepslate_tiles
setblock ~51 ~-67 ~27 minecraft:barrel
fill ~52 ~-67 ~27 ~54 ~-67 ~27 minecraft:air
setblock ~55 ~-67 ~27 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-67 ~27 ~58 ~-67 ~27 minecraft:air
setblock ~59 ~-67 ~27 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-67 ~27 ~62 ~-67 ~27 minecraft:air
setblock ~63 ~-67 ~27 minecraft:barrel
setblock ~64 ~-67 ~27 minecraft:deepslate_tiles
setblock ~4 ~-67 ~28 minecraft:deepslate_tiles
setblock ~5 ~-67 ~28 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~28 ~16 ~-67 ~28 minecraft:air
setblock ~17 ~-67 ~28 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~28 minecraft:deepslate_tiles
setblock ~19 ~-67 ~28 minecraft:air
setblock ~20 ~-67 ~28 minecraft:chest[facing=west]
setblock ~21 ~-67 ~28 minecraft:deepslate_tiles
fill ~22 ~-67 ~28 ~29 ~-67 ~28 minecraft:air
setblock ~30 ~-67 ~28 minecraft:iron_bars[east=true]
setblock ~31 ~-67 ~28 minecraft:iron_bars[west=true]
fill ~32 ~-67 ~28 ~36 ~-67 ~28 minecraft:air
setblock ~37 ~-67 ~28 minecraft:iron_bars[east=true]
setblock ~38 ~-67 ~28 minecraft:iron_bars[west=true]
fill ~39 ~-67 ~28 ~46 ~-67 ~28 minecraft:air
setblock ~47 ~-67 ~28 minecraft:deepslate_tiles
setblock ~48 ~-67 ~28 minecraft:chest[facing=north]
setblock ~49 ~-67 ~28 minecraft:air
setblock ~50 ~-67 ~28 minecraft:deepslate_tiles
setblock ~51 ~-67 ~28 minecraft:iron_block
fill ~52 ~-67 ~28 ~54 ~-67 ~28 minecraft:air
setblock ~55 ~-67 ~28 minecraft:smooth_stone_slab[type=top]
fill ~56 ~-67 ~28 ~58 ~-67 ~28 minecraft:air
setblock ~59 ~-67 ~28 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-67 ~28 ~62 ~-67 ~28 minecraft:air
setblock ~63 ~-67 ~28 minecraft:iron_block
setblock ~64 ~-67 ~28 minecraft:deepslate_tiles
setblock ~4 ~-67 ~29 minecraft:deepslate_tiles
setblock ~5 ~-67 ~29 minecraft:waxed_cut_copper
fill ~6 ~-67 ~29 ~16 ~-67 ~29 minecraft:air
setblock ~17 ~-67 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~29 minecraft:deepslate_tiles
setblock ~19 ~-67 ~29 minecraft:chest[facing=west]
setblock ~20 ~-67 ~29 minecraft:deepslate_tiles
fill ~21 ~-67 ~29 ~28 ~-67 ~29 minecraft:air
setblock ~29 ~-67 ~29 minecraft:iron_bars
fill ~30 ~-67 ~29 ~33 ~-67 ~29 minecraft:air
setblock ~34 ~-67 ~29 minecraft:lightning_rod[facing=up]
fill ~35 ~-67 ~29 ~38 ~-67 ~29 minecraft:air
setblock ~39 ~-67 ~29 minecraft:iron_bars
fill ~40 ~-67 ~29 ~47 ~-67 ~29 minecraft:air
setblock ~48 ~-67 ~29 minecraft:deepslate_tiles
setblock ~49 ~-67 ~29 minecraft:chest[facing=west]
setblock ~50 ~-67 ~29 minecraft:deepslate_tiles
setblock ~51 ~-67 ~29 minecraft:crafting_table
fill ~52 ~-67 ~29 ~62 ~-67 ~29 minecraft:air
setblock ~63 ~-67 ~29 minecraft:crafting_table
setblock ~64 ~-67 ~29 minecraft:deepslate_tiles
setblock ~4 ~-67 ~30 minecraft:deepslate_tiles
setblock ~5 ~-67 ~30 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~30 ~16 ~-67 ~30 minecraft:air
setblock ~17 ~-67 ~30 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~30 minecraft:deepslate_tiles
setblock ~19 ~-67 ~30 minecraft:air
setblock ~20 ~-67 ~30 minecraft:deepslate_tiles
fill ~21 ~-67 ~30 ~27 ~-67 ~30 minecraft:air
setblock ~28 ~-67 ~30 minecraft:iron_bars[south=true]
setblock ~29 ~-67 ~30 minecraft:air
setblock ~30 ~-67 ~30 minecraft:lightning_rod[facing=up]
fill ~31 ~-67 ~30 ~37 ~-67 ~30 minecraft:air
setblock ~38 ~-67 ~30 minecraft:lightning_rod[facing=up]
setblock ~39 ~-67 ~30 minecraft:air
setblock ~40 ~-67 ~30 minecraft:iron_bars[south=true]
fill ~41 ~-67 ~30 ~47 ~-67 ~30 minecraft:air
setblock ~48 ~-67 ~30 minecraft:deepslate_tiles
setblock ~49 ~-67 ~30 minecraft:air
setblock ~50 ~-67 ~30 minecraft:deepslate_tiles
setblock ~51 ~-67 ~30 minecraft:smithing_table
fill ~52 ~-67 ~30 ~62 ~-67 ~30 minecraft:air
setblock ~63 ~-67 ~30 minecraft:smithing_table
setblock ~64 ~-67 ~30 minecraft:deepslate_tiles
setblock ~4 ~-67 ~31 minecraft:deepslate_tiles
setblock ~5 ~-67 ~31 minecraft:blast_furnace[facing=north]
setblock ~6 ~-67 ~31 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~31 minecraft:dispenser[facing=north]
setblock ~8 ~-67 ~31 minecraft:blast_furnace[facing=north]
setblock ~9 ~-67 ~31 minecraft:waxed_cut_copper
fill ~10 ~-67 ~31 ~12 ~-67 ~31 minecraft:air
setblock ~13 ~-67 ~31 minecraft:dispenser[facing=north]
setblock ~14 ~-67 ~31 minecraft:blast_furnace[facing=north]
setblock ~15 ~-67 ~31 minecraft:waxed_cut_copper
setblock ~16 ~-67 ~31 minecraft:dispenser[facing=north]
setblock ~17 ~-67 ~31 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~31 minecraft:deepslate_tiles
setblock ~19 ~-67 ~31 minecraft:air
setblock ~20 ~-67 ~31 minecraft:deepslate_tiles
fill ~21 ~-67 ~31 ~27 ~-67 ~31 minecraft:air
setblock ~28 ~-67 ~31 minecraft:iron_bars[north=true]
fill ~29 ~-67 ~31 ~31 ~-67 ~31 minecraft:air
fill ~32 ~-67 ~31 ~36 ~-67 ~31 minecraft:waxed_cut_copper
fill ~37 ~-67 ~31 ~39 ~-67 ~31 minecraft:air
setblock ~40 ~-67 ~31 minecraft:iron_bars[north=true]
fill ~41 ~-67 ~31 ~47 ~-67 ~31 minecraft:air
setblock ~48 ~-67 ~31 minecraft:deepslate_tiles
setblock ~49 ~-67 ~31 minecraft:air
setblock ~50 ~-67 ~31 minecraft:deepslate_tiles
setblock ~51 ~-67 ~31 minecraft:barrel
setblock ~52 ~-67 ~31 minecraft:iron_block
setblock ~53 ~-67 ~31 minecraft:crafting_table
setblock ~54 ~-67 ~31 minecraft:smithing_table
setblock ~55 ~-67 ~31 minecraft:barrel
fill ~56 ~-67 ~31 ~58 ~-67 ~31 minecraft:air
setblock ~59 ~-67 ~31 minecraft:barrel
setblock ~60 ~-67 ~31 minecraft:iron_block
setblock ~61 ~-67 ~31 minecraft:crafting_table
setblock ~62 ~-67 ~31 minecraft:smithing_table
setblock ~63 ~-67 ~31 minecraft:barrel
setblock ~64 ~-67 ~31 minecraft:deepslate_tiles
fill ~4 ~-67 ~32 ~10 ~-67 ~32 minecraft:deepslate_tiles
setblock ~11 ~-67 ~32 minecraft:air
fill ~12 ~-67 ~32 ~18 ~-67 ~32 minecraft:deepslate_tiles
setblock ~19 ~-67 ~32 minecraft:air
setblock ~20 ~-67 ~32 minecraft:deepslate_tiles
fill ~21 ~-67 ~32 ~26 ~-67 ~32 minecraft:air
setblock ~27 ~-67 ~32 minecraft:iron_bars
fill ~28 ~-67 ~32 ~30 ~-67 ~32 minecraft:air
fill ~31 ~-67 ~32 ~37 ~-67 ~32 minecraft:waxed_cut_copper
fill ~38 ~-67 ~32 ~40 ~-67 ~32 minecraft:air
setblock ~41 ~-67 ~32 minecraft:iron_bars
fill ~42 ~-67 ~32 ~47 ~-67 ~32 minecraft:air
setblock ~48 ~-67 ~32 minecraft:deepslate_tiles
setblock ~49 ~-67 ~32 minecraft:air
fill ~50 ~-67 ~32 ~56 ~-67 ~32 minecraft:deepslate_tiles
setblock ~57 ~-67 ~32 minecraft:air
fill ~58 ~-67 ~32 ~64 ~-67 ~32 minecraft:deepslate_tiles
setblock ~4 ~-67 ~33 minecraft:deepslate_tiles
fill ~5 ~-67 ~33 ~22 ~-67 ~33 minecraft:air
setblock ~23 ~-67 ~33 minecraft:spruce_stairs[facing=west,half=bottom]
setblock ~24 ~-67 ~33 minecraft:smooth_stone_slab[type=top]
fill ~25 ~-67 ~33 ~30 ~-67 ~33 minecraft:air
fill ~31 ~-67 ~33 ~37 ~-67 ~33 minecraft:waxed_cut_copper
fill ~38 ~-67 ~33 ~43 ~-67 ~33 minecraft:air
setblock ~44 ~-67 ~33 minecraft:smooth_stone_slab[type=top]
setblock ~45 ~-67 ~33 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~46 ~-67 ~33 ~63 ~-67 ~33 minecraft:air
fill ~64 ~-67 ~33 ~68 ~-67 ~33 minecraft:deepslate_bricks
setblock ~4 ~-67 ~34 minecraft:deepslate_tiles
fill ~5 ~-67 ~34 ~22 ~-67 ~34 minecraft:air
setblock ~23 ~-67 ~34 minecraft:spruce_stairs[facing=west,half=bottom]
setblock ~24 ~-67 ~34 minecraft:smooth_stone_slab[type=top]
fill ~25 ~-67 ~34 ~28 ~-67 ~34 minecraft:air
setblock ~29 ~-67 ~34 minecraft:lightning_rod[facing=up]
setblock ~30 ~-67 ~34 minecraft:air
fill ~31 ~-67 ~34 ~37 ~-67 ~34 minecraft:waxed_cut_copper
setblock ~38 ~-67 ~34 minecraft:air
setblock ~39 ~-67 ~34 minecraft:lightning_rod[facing=up]
fill ~40 ~-67 ~34 ~43 ~-67 ~34 minecraft:air
setblock ~44 ~-67 ~34 minecraft:smooth_stone_slab[type=top]
setblock ~45 ~-67 ~34 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~46 ~-67 ~34 ~68 ~-67 ~34 minecraft:air
setblock ~4 ~-67 ~35 minecraft:deepslate_tiles
fill ~5 ~-67 ~35 ~22 ~-67 ~35 minecraft:air
setblock ~23 ~-67 ~35 minecraft:spruce_stairs[facing=west,half=bottom]
setblock ~24 ~-67 ~35 minecraft:smooth_stone_slab[type=top]
fill ~25 ~-67 ~35 ~30 ~-67 ~35 minecraft:air
fill ~31 ~-67 ~35 ~37 ~-67 ~35 minecraft:waxed_cut_copper
fill ~38 ~-67 ~35 ~43 ~-67 ~35 minecraft:air
setblock ~44 ~-67 ~35 minecraft:smooth_stone_slab[type=top]
setblock ~45 ~-67 ~35 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~46 ~-67 ~35 ~63 ~-67 ~35 minecraft:air
fill ~64 ~-67 ~35 ~68 ~-67 ~35 minecraft:deepslate_bricks
fill ~4 ~-67 ~36 ~10 ~-67 ~36 minecraft:deepslate_tiles
setblock ~11 ~-67 ~36 minecraft:air
fill ~12 ~-67 ~36 ~18 ~-67 ~36 minecraft:deepslate_tiles
setblock ~19 ~-67 ~36 minecraft:air
setblock ~20 ~-67 ~36 minecraft:deepslate_tiles
fill ~21 ~-67 ~36 ~26 ~-67 ~36 minecraft:air
setblock ~27 ~-67 ~36 minecraft:iron_bars
fill ~28 ~-67 ~36 ~30 ~-67 ~36 minecraft:air
fill ~31 ~-67 ~36 ~37 ~-67 ~36 minecraft:waxed_cut_copper
fill ~38 ~-67 ~36 ~40 ~-67 ~36 minecraft:air
setblock ~41 ~-67 ~36 minecraft:iron_bars
fill ~42 ~-67 ~36 ~47 ~-67 ~36 minecraft:air
setblock ~48 ~-67 ~36 minecraft:deepslate_tiles
setblock ~49 ~-67 ~36 minecraft:air
fill ~50 ~-67 ~36 ~56 ~-67 ~36 minecraft:deepslate_tiles
setblock ~57 ~-67 ~36 minecraft:air
fill ~58 ~-67 ~36 ~64 ~-67 ~36 minecraft:deepslate_tiles
setblock ~4 ~-67 ~37 minecraft:deepslate_tiles
setblock ~5 ~-67 ~37 minecraft:blast_furnace[facing=south]
setblock ~6 ~-67 ~37 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~37 minecraft:dispenser[facing=south]
setblock ~8 ~-67 ~37 minecraft:blast_furnace[facing=south]
setblock ~9 ~-67 ~37 minecraft:waxed_cut_copper
fill ~10 ~-67 ~37 ~12 ~-67 ~37 minecraft:air
setblock ~13 ~-67 ~37 minecraft:dispenser[facing=south]
setblock ~14 ~-67 ~37 minecraft:blast_furnace[facing=south]
setblock ~15 ~-67 ~37 minecraft:waxed_cut_copper
setblock ~16 ~-67 ~37 minecraft:dispenser[facing=south]
setblock ~17 ~-67 ~37 minecraft:blast_furnace[facing=south]
setblock ~18 ~-67 ~37 minecraft:deepslate_tiles
setblock ~19 ~-67 ~37 minecraft:air
setblock ~20 ~-67 ~37 minecraft:deepslate_tiles
fill ~21 ~-67 ~37 ~27 ~-67 ~37 minecraft:air
setblock ~28 ~-67 ~37 minecraft:iron_bars[south=true]
fill ~29 ~-67 ~37 ~31 ~-67 ~37 minecraft:air
fill ~32 ~-67 ~37 ~36 ~-67 ~37 minecraft:waxed_cut_copper
fill ~37 ~-67 ~37 ~39 ~-67 ~37 minecraft:air
setblock ~40 ~-67 ~37 minecraft:iron_bars[south=true]
fill ~41 ~-67 ~37 ~47 ~-67 ~37 minecraft:air
setblock ~48 ~-67 ~37 minecraft:deepslate_tiles
setblock ~49 ~-67 ~37 minecraft:air
setblock ~50 ~-67 ~37 minecraft:deepslate_tiles
setblock ~51 ~-67 ~37 minecraft:chest[facing=south]
setblock ~52 ~-67 ~37 minecraft:air
setblock ~53 ~-67 ~37 minecraft:chest[facing=south]
setblock ~54 ~-67 ~37 minecraft:air
setblock ~55 ~-67 ~37 minecraft:chest[facing=south]
fill ~56 ~-67 ~37 ~58 ~-67 ~37 minecraft:air
setblock ~59 ~-67 ~37 minecraft:chest[facing=south]
setblock ~60 ~-67 ~37 minecraft:air
setblock ~61 ~-67 ~37 minecraft:chest[facing=south]
setblock ~62 ~-67 ~37 minecraft:air
setblock ~63 ~-67 ~37 minecraft:chest[facing=south]
setblock ~64 ~-67 ~37 minecraft:deepslate_tiles
setblock ~4 ~-67 ~38 minecraft:deepslate_tiles
setblock ~5 ~-67 ~38 minecraft:waxed_cut_copper
fill ~6 ~-67 ~38 ~16 ~-67 ~38 minecraft:air
setblock ~17 ~-67 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~38 minecraft:deepslate_tiles
setblock ~19 ~-67 ~38 minecraft:air
setblock ~20 ~-67 ~38 minecraft:deepslate_tiles
fill ~21 ~-67 ~38 ~27 ~-67 ~38 minecraft:air
setblock ~28 ~-67 ~38 minecraft:iron_bars[north=true]
setblock ~29 ~-67 ~38 minecraft:air
setblock ~30 ~-67 ~38 minecraft:lightning_rod[facing=up]
fill ~31 ~-67 ~38 ~37 ~-67 ~38 minecraft:air
setblock ~38 ~-67 ~38 minecraft:lightning_rod[facing=up]
setblock ~39 ~-67 ~38 minecraft:air
setblock ~40 ~-67 ~38 minecraft:iron_bars[north=true]
fill ~41 ~-67 ~38 ~47 ~-67 ~38 minecraft:air
setblock ~48 ~-67 ~38 minecraft:deepslate_tiles
setblock ~49 ~-67 ~38 minecraft:air
setblock ~50 ~-67 ~38 minecraft:deepslate_tiles
setblock ~51 ~-67 ~38 minecraft:air
setblock ~52 ~-67 ~38 minecraft:barrel
fill ~53 ~-67 ~38 ~54 ~-67 ~38 minecraft:air
setblock ~55 ~-67 ~38 minecraft:barrel
fill ~56 ~-67 ~38 ~57 ~-67 ~38 minecraft:air
setblock ~58 ~-67 ~38 minecraft:barrel
fill ~59 ~-67 ~38 ~60 ~-67 ~38 minecraft:air
setblock ~61 ~-67 ~38 minecraft:barrel
fill ~62 ~-67 ~38 ~63 ~-67 ~38 minecraft:air
setblock ~64 ~-67 ~38 minecraft:deepslate_tiles
setblock ~4 ~-67 ~39 minecraft:deepslate_tiles
setblock ~5 ~-67 ~39 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~39 ~16 ~-67 ~39 minecraft:air
setblock ~17 ~-67 ~39 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~39 minecraft:deepslate_tiles
setblock ~19 ~-67 ~39 minecraft:chest[facing=west]
setblock ~20 ~-67 ~39 minecraft:deepslate_tiles
fill ~21 ~-67 ~39 ~28 ~-67 ~39 minecraft:air
setblock ~29 ~-67 ~39 minecraft:iron_bars
fill ~30 ~-67 ~39 ~33 ~-67 ~39 minecraft:air
setblock ~34 ~-67 ~39 minecraft:lightning_rod[facing=up]
fill ~35 ~-67 ~39 ~38 ~-67 ~39 minecraft:air
setblock ~39 ~-67 ~39 minecraft:iron_bars
fill ~40 ~-67 ~39 ~47 ~-67 ~39 minecraft:air
setblock ~48 ~-67 ~39 minecraft:deepslate_tiles
setblock ~49 ~-67 ~39 minecraft:chest[facing=west]
setblock ~50 ~-67 ~39 minecraft:deepslate_tiles
setblock ~51 ~-67 ~39 minecraft:chest[facing=east]
setblock ~52 ~-67 ~39 minecraft:barrel
fill ~53 ~-67 ~39 ~54 ~-67 ~39 minecraft:air
setblock ~55 ~-67 ~39 minecraft:barrel
fill ~56 ~-67 ~39 ~57 ~-67 ~39 minecraft:air
setblock ~58 ~-67 ~39 minecraft:barrel
fill ~59 ~-67 ~39 ~60 ~-67 ~39 minecraft:air
setblock ~61 ~-67 ~39 minecraft:barrel
setblock ~62 ~-67 ~39 minecraft:air
setblock ~63 ~-67 ~39 minecraft:chest[facing=west]
setblock ~64 ~-67 ~39 minecraft:deepslate_tiles
setblock ~4 ~-67 ~40 minecraft:deepslate_tiles
setblock ~5 ~-67 ~40 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~40 ~16 ~-67 ~40 minecraft:air
setblock ~17 ~-67 ~40 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~40 minecraft:deepslate_tiles
setblock ~19 ~-67 ~40 minecraft:air
setblock ~20 ~-67 ~40 minecraft:chest[facing=south]
setblock ~21 ~-67 ~40 minecraft:deepslate_tiles
fill ~22 ~-67 ~40 ~29 ~-67 ~40 minecraft:air
setblock ~30 ~-67 ~40 minecraft:iron_bars[east=true]
setblock ~31 ~-67 ~40 minecraft:iron_bars[west=true]
fill ~32 ~-67 ~40 ~36 ~-67 ~40 minecraft:air
setblock ~37 ~-67 ~40 minecraft:iron_bars[east=true]
setblock ~38 ~-67 ~40 minecraft:iron_bars[west=true]
fill ~39 ~-67 ~40 ~46 ~-67 ~40 minecraft:air
setblock ~47 ~-67 ~40 minecraft:deepslate_tiles
setblock ~48 ~-67 ~40 minecraft:chest[facing=south]
setblock ~49 ~-67 ~40 minecraft:air
setblock ~50 ~-67 ~40 minecraft:deepslate_tiles
setblock ~51 ~-67 ~40 minecraft:air
setblock ~52 ~-67 ~40 minecraft:barrel
fill ~53 ~-67 ~40 ~54 ~-67 ~40 minecraft:air
setblock ~55 ~-67 ~40 minecraft:barrel
fill ~56 ~-67 ~40 ~57 ~-67 ~40 minecraft:air
setblock ~58 ~-67 ~40 minecraft:barrel
fill ~59 ~-67 ~40 ~60 ~-67 ~40 minecraft:air
setblock ~61 ~-67 ~40 minecraft:barrel
fill ~62 ~-67 ~40 ~63 ~-67 ~40 minecraft:air
setblock ~64 ~-67 ~40 minecraft:deepslate_tiles
setblock ~4 ~-67 ~41 minecraft:deepslate_tiles
setblock ~5 ~-67 ~41 minecraft:waxed_cut_copper
fill ~6 ~-67 ~41 ~16 ~-67 ~41 minecraft:air
setblock ~17 ~-67 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~41 minecraft:deepslate_tiles
setblock ~19 ~-67 ~41 minecraft:chest[facing=east]
setblock ~20 ~-67 ~41 minecraft:barrel
setblock ~21 ~-67 ~41 minecraft:deepslate_tiles
fill ~22 ~-67 ~41 ~31 ~-67 ~41 minecraft:air
setblock ~32 ~-67 ~41 minecraft:iron_bars
fill ~33 ~-67 ~41 ~35 ~-67 ~41 minecraft:air
setblock ~36 ~-67 ~41 minecraft:iron_bars
fill ~37 ~-67 ~41 ~46 ~-67 ~41 minecraft:air
setblock ~47 ~-67 ~41 minecraft:deepslate_tiles
setblock ~48 ~-67 ~41 minecraft:barrel
setblock ~49 ~-67 ~41 minecraft:chest[facing=west]
setblock ~50 ~-67 ~41 minecraft:deepslate_tiles
setblock ~51 ~-67 ~41 minecraft:chest[facing=east]
setblock ~52 ~-67 ~41 minecraft:barrel
fill ~53 ~-67 ~41 ~54 ~-67 ~41 minecraft:air
setblock ~55 ~-67 ~41 minecraft:barrel
fill ~56 ~-67 ~41 ~57 ~-67 ~41 minecraft:air
setblock ~58 ~-67 ~41 minecraft:barrel
fill ~59 ~-67 ~41 ~60 ~-67 ~41 minecraft:air
setblock ~61 ~-67 ~41 minecraft:barrel
setblock ~62 ~-67 ~41 minecraft:air
setblock ~63 ~-67 ~41 minecraft:chest[facing=west]
setblock ~64 ~-67 ~41 minecraft:deepslate_tiles
setblock ~4 ~-67 ~42 minecraft:deepslate_tiles
setblock ~5 ~-67 ~42 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~42 ~9 ~-67 ~42 minecraft:air
setblock ~10 ~-67 ~42 minecraft:waxed_cut_copper
fill ~11 ~-67 ~42 ~13 ~-67 ~42 minecraft:air
setblock ~14 ~-67 ~42 minecraft:waxed_cut_copper
fill ~15 ~-67 ~42 ~16 ~-67 ~42 minecraft:air
setblock ~17 ~-67 ~42 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~42 minecraft:deepslate_tiles
fill ~19 ~-67 ~42 ~21 ~-67 ~42 minecraft:air
setblock ~22 ~-67 ~42 minecraft:deepslate_tiles
fill ~23 ~-67 ~42 ~25 ~-67 ~42 minecraft:air
setblock ~26 ~-67 ~42 minecraft:waxed_cut_copper
fill ~27 ~-67 ~42 ~41 ~-67 ~42 minecraft:air
setblock ~42 ~-67 ~42 minecraft:waxed_cut_copper
fill ~43 ~-67 ~42 ~45 ~-67 ~42 minecraft:air
setblock ~46 ~-67 ~42 minecraft:deepslate_tiles
fill ~47 ~-67 ~42 ~49 ~-67 ~42 minecraft:air
setblock ~50 ~-67 ~42 minecraft:deepslate_tiles
fill ~51 ~-67 ~42 ~63 ~-67 ~42 minecraft:air
setblock ~64 ~-67 ~42 minecraft:deepslate_tiles
setblock ~4 ~-67 ~43 minecraft:deepslate_tiles
setblock ~5 ~-67 ~43 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~43 ~16 ~-67 ~43 minecraft:air
setblock ~17 ~-67 ~43 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~43 minecraft:deepslate_tiles
setblock ~19 ~-67 ~43 minecraft:chest[facing=east]
setblock ~20 ~-67 ~43 minecraft:air
setblock ~21 ~-67 ~43 minecraft:chest[facing=west]
fill ~22 ~-67 ~43 ~23 ~-67 ~43 minecraft:deepslate_tiles
fill ~24 ~-67 ~43 ~44 ~-67 ~43 minecraft:air
fill ~45 ~-67 ~43 ~46 ~-67 ~43 minecraft:deepslate_tiles
setblock ~47 ~-67 ~43 minecraft:chest[facing=east]
setblock ~48 ~-67 ~43 minecraft:air
setblock ~49 ~-67 ~43 minecraft:chest[facing=west]
setblock ~50 ~-67 ~43 minecraft:deepslate_tiles
setblock ~51 ~-67 ~43 minecraft:chest[facing=east]
setblock ~52 ~-67 ~43 minecraft:barrel
fill ~53 ~-67 ~43 ~54 ~-67 ~43 minecraft:air
setblock ~55 ~-67 ~43 minecraft:barrel
fill ~56 ~-67 ~43 ~57 ~-67 ~43 minecraft:air
setblock ~58 ~-67 ~43 minecraft:barrel
fill ~59 ~-67 ~43 ~60 ~-67 ~43 minecraft:air
setblock ~61 ~-67 ~43 minecraft:barrel
setblock ~62 ~-67 ~43 minecraft:air
setblock ~63 ~-67 ~43 minecraft:chest[facing=west]
setblock ~64 ~-67 ~43 minecraft:deepslate_tiles
setblock ~4 ~-67 ~44 minecraft:deepslate_tiles
setblock ~5 ~-67 ~44 minecraft:waxed_cut_copper
fill ~6 ~-67 ~44 ~16 ~-67 ~44 minecraft:air
setblock ~17 ~-67 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~44 minecraft:deepslate_tiles
setblock ~19 ~-67 ~44 minecraft:air
fill ~20 ~-67 ~44 ~22 ~-67 ~44 minecraft:barrel
fill ~23 ~-67 ~44 ~24 ~-67 ~44 minecraft:deepslate_tiles
fill ~25 ~-67 ~44 ~32 ~-67 ~44 minecraft:air
fill ~33 ~-67 ~44 ~35 ~-67 ~44 minecraft:smooth_stone_slab[type=top]
fill ~36 ~-67 ~44 ~43 ~-67 ~44 minecraft:air
fill ~44 ~-67 ~44 ~45 ~-67 ~44 minecraft:deepslate_tiles
setblock ~46 ~-67 ~44 minecraft:barrel
setblock ~47 ~-67 ~44 minecraft:air
setblock ~48 ~-67 ~44 minecraft:barrel
setblock ~49 ~-67 ~44 minecraft:air
setblock ~50 ~-67 ~44 minecraft:deepslate_tiles
setblock ~51 ~-67 ~44 minecraft:air
setblock ~52 ~-67 ~44 minecraft:barrel
fill ~53 ~-67 ~44 ~54 ~-67 ~44 minecraft:air
setblock ~55 ~-67 ~44 minecraft:barrel
fill ~56 ~-67 ~44 ~57 ~-67 ~44 minecraft:air
setblock ~58 ~-67 ~44 minecraft:barrel
fill ~59 ~-67 ~44 ~60 ~-67 ~44 minecraft:air
setblock ~61 ~-67 ~44 minecraft:barrel
fill ~62 ~-67 ~44 ~63 ~-67 ~44 minecraft:air
setblock ~64 ~-67 ~44 minecraft:deepslate_tiles
setblock ~4 ~-67 ~45 minecraft:deepslate_tiles
setblock ~5 ~-67 ~45 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~45 ~16 ~-67 ~45 minecraft:air
setblock ~17 ~-67 ~45 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~45 minecraft:deepslate_tiles
setblock ~19 ~-67 ~45 minecraft:chest[facing=east]
fill ~20 ~-67 ~45 ~22 ~-67 ~45 minecraft:air
setblock ~23 ~-67 ~45 minecraft:chest[facing=south]
fill ~24 ~-67 ~45 ~25 ~-67 ~45 minecraft:deepslate_tiles
fill ~26 ~-67 ~45 ~32 ~-67 ~45 minecraft:air
fill ~33 ~-67 ~45 ~35 ~-67 ~45 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~36 ~-67 ~45 ~42 ~-67 ~45 minecraft:air
fill ~43 ~-67 ~45 ~44 ~-67 ~45 minecraft:deepslate_tiles
setblock ~45 ~-67 ~45 minecraft:chest[facing=south]
fill ~46 ~-67 ~45 ~48 ~-67 ~45 minecraft:air
setblock ~49 ~-67 ~45 minecraft:chest[facing=west]
setblock ~50 ~-67 ~45 minecraft:deepslate_tiles
setblock ~51 ~-67 ~45 minecraft:chest[facing=east]
setblock ~52 ~-67 ~45 minecraft:barrel
fill ~53 ~-67 ~45 ~54 ~-67 ~45 minecraft:air
setblock ~55 ~-67 ~45 minecraft:barrel
fill ~56 ~-67 ~45 ~57 ~-67 ~45 minecraft:air
setblock ~58 ~-67 ~45 minecraft:barrel
fill ~59 ~-67 ~45 ~60 ~-67 ~45 minecraft:air
setblock ~61 ~-67 ~45 minecraft:barrel
setblock ~62 ~-67 ~45 minecraft:air
setblock ~63 ~-67 ~45 minecraft:chest[facing=west]
setblock ~64 ~-67 ~45 minecraft:deepslate_tiles
setblock ~4 ~-67 ~46 minecraft:deepslate_tiles
setblock ~5 ~-67 ~46 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~46 ~9 ~-67 ~46 minecraft:air
setblock ~10 ~-67 ~46 minecraft:waxed_cut_copper
fill ~11 ~-67 ~46 ~13 ~-67 ~46 minecraft:air
setblock ~14 ~-67 ~46 minecraft:waxed_cut_copper
fill ~15 ~-67 ~46 ~16 ~-67 ~46 minecraft:air
setblock ~17 ~-67 ~46 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~46 minecraft:deepslate_tiles
fill ~19 ~-67 ~46 ~23 ~-67 ~46 minecraft:air
setblock ~24 ~-67 ~46 minecraft:chest[facing=south]
fill ~25 ~-67 ~46 ~26 ~-67 ~46 minecraft:deepslate_tiles
fill ~27 ~-67 ~46 ~41 ~-67 ~46 minecraft:air
fill ~42 ~-67 ~46 ~43 ~-67 ~46 minecraft:deepslate_tiles
setblock ~44 ~-67 ~46 minecraft:chest[facing=south]
fill ~45 ~-67 ~46 ~49 ~-67 ~46 minecraft:air
setblock ~50 ~-67 ~46 minecraft:deepslate_tiles
setblock ~51 ~-67 ~46 minecraft:air
setblock ~52 ~-67 ~46 minecraft:barrel
fill ~53 ~-67 ~46 ~54 ~-67 ~46 minecraft:air
setblock ~55 ~-67 ~46 minecraft:barrel
fill ~56 ~-67 ~46 ~57 ~-67 ~46 minecraft:air
setblock ~58 ~-67 ~46 minecraft:barrel
fill ~59 ~-67 ~46 ~60 ~-67 ~46 minecraft:air
setblock ~61 ~-67 ~46 minecraft:barrel
fill ~62 ~-67 ~46 ~63 ~-67 ~46 minecraft:air
setblock ~64 ~-67 ~46 minecraft:deepslate_tiles
setblock ~4 ~-67 ~47 minecraft:deepslate_tiles
setblock ~5 ~-67 ~47 minecraft:waxed_cut_copper
fill ~6 ~-67 ~47 ~16 ~-67 ~47 minecraft:air
setblock ~17 ~-67 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~47 minecraft:deepslate_tiles
setblock ~19 ~-67 ~47 minecraft:chest[facing=east]
fill ~20 ~-67 ~47 ~23 ~-67 ~47 minecraft:barrel
setblock ~24 ~-67 ~47 minecraft:air
fill ~25 ~-67 ~47 ~26 ~-67 ~47 minecraft:barrel
fill ~27 ~-67 ~47 ~28 ~-67 ~47 minecraft:deepslate_tiles
fill ~29 ~-67 ~47 ~39 ~-67 ~47 minecraft:air
fill ~40 ~-67 ~47 ~41 ~-67 ~47 minecraft:deepslate_tiles
setblock ~42 ~-67 ~47 minecraft:air
fill ~43 ~-67 ~47 ~46 ~-67 ~47 minecraft:barrel
setblock ~47 ~-67 ~47 minecraft:air
setblock ~48 ~-67 ~47 minecraft:barrel
setblock ~49 ~-67 ~47 minecraft:chest[facing=west]
setblock ~50 ~-67 ~47 minecraft:deepslate_tiles
setblock ~51 ~-67 ~47 minecraft:chest[facing=east]
fill ~52 ~-67 ~47 ~62 ~-67 ~47 minecraft:air
setblock ~63 ~-67 ~47 minecraft:chest[facing=west]
setblock ~64 ~-67 ~47 minecraft:deepslate_tiles
setblock ~4 ~-67 ~48 minecraft:deepslate_tiles
setblock ~5 ~-67 ~48 minecraft:dispenser[facing=east]
fill ~6 ~-67 ~48 ~16 ~-67 ~48 minecraft:air
setblock ~17 ~-67 ~48 minecraft:dispenser[facing=west]
setblock ~18 ~-67 ~48 minecraft:deepslate_tiles
fill ~19 ~-67 ~48 ~27 ~-67 ~48 minecraft:air
setblock ~28 ~-67 ~48 minecraft:chest[facing=south]
fill ~29 ~-67 ~48 ~32 ~-67 ~48 minecraft:deepslate_tiles
fill ~33 ~-67 ~48 ~35 ~-67 ~48 minecraft:air
fill ~36 ~-67 ~48 ~39 ~-67 ~48 minecraft:deepslate_tiles
setblock ~40 ~-67 ~48 minecraft:chest[facing=south]
fill ~41 ~-67 ~48 ~49 ~-67 ~48 minecraft:air
setblock ~50 ~-67 ~48 minecraft:deepslate_tiles
setblock ~51 ~-67 ~48 minecraft:air
setblock ~52 ~-67 ~48 minecraft:barrel
fill ~53 ~-67 ~48 ~54 ~-67 ~48 minecraft:air
setblock ~55 ~-67 ~48 minecraft:barrel
fill ~56 ~-67 ~48 ~57 ~-67 ~48 minecraft:air
setblock ~58 ~-67 ~48 minecraft:barrel
fill ~59 ~-67 ~48 ~60 ~-67 ~48 minecraft:air
setblock ~61 ~-67 ~48 minecraft:barrel
fill ~62 ~-67 ~48 ~63 ~-67 ~48 minecraft:air
setblock ~64 ~-67 ~48 minecraft:deepslate_tiles
setblock ~4 ~-67 ~49 minecraft:deepslate_tiles
setblock ~5 ~-67 ~49 minecraft:blast_furnace[facing=north]
setblock ~6 ~-67 ~49 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~49 minecraft:dispenser[facing=north]
setblock ~8 ~-67 ~49 minecraft:blast_furnace[facing=north]
setblock ~9 ~-67 ~49 minecraft:waxed_cut_copper
fill ~10 ~-67 ~49 ~12 ~-67 ~49 minecraft:air
setblock ~13 ~-67 ~49 minecraft:dispenser[facing=north]
setblock ~14 ~-67 ~49 minecraft:blast_furnace[facing=north]
setblock ~15 ~-67 ~49 minecraft:waxed_cut_copper
setblock ~16 ~-67 ~49 minecraft:dispenser[facing=north]
setblock ~17 ~-67 ~49 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~49 minecraft:deepslate_tiles
setblock ~19 ~-67 ~49 minecraft:chest[facing=north]
setblock ~20 ~-67 ~49 minecraft:air
setblock ~21 ~-67 ~49 minecraft:chest[facing=north]
setblock ~22 ~-67 ~49 minecraft:air
setblock ~23 ~-67 ~49 minecraft:chest[facing=north]
setblock ~24 ~-67 ~49 minecraft:air
setblock ~25 ~-67 ~49 minecraft:chest[facing=north]
setblock ~26 ~-67 ~49 minecraft:air
setblock ~27 ~-67 ~49 minecraft:chest[facing=north]
setblock ~28 ~-67 ~49 minecraft:air
setblock ~29 ~-67 ~49 minecraft:chest[facing=south]
fill ~30 ~-67 ~49 ~38 ~-67 ~49 minecraft:air
setblock ~39 ~-67 ~49 minecraft:chest[facing=south]
setblock ~40 ~-67 ~49 minecraft:air
setblock ~41 ~-67 ~49 minecraft:chest[facing=north]
setblock ~42 ~-67 ~49 minecraft:air
setblock ~43 ~-67 ~49 minecraft:chest[facing=north]
setblock ~44 ~-67 ~49 minecraft:air
setblock ~45 ~-67 ~49 minecraft:chest[facing=north]
setblock ~46 ~-67 ~49 minecraft:air
setblock ~47 ~-67 ~49 minecraft:chest[facing=north]
setblock ~48 ~-67 ~49 minecraft:air
setblock ~49 ~-67 ~49 minecraft:chest[facing=west]
setblock ~50 ~-67 ~49 minecraft:deepslate_tiles
setblock ~51 ~-67 ~49 minecraft:chest[facing=north]
setblock ~52 ~-67 ~49 minecraft:air
setblock ~53 ~-67 ~49 minecraft:chest[facing=north]
setblock ~54 ~-67 ~49 minecraft:air
setblock ~55 ~-67 ~49 minecraft:chest[facing=north]
fill ~56 ~-67 ~49 ~58 ~-67 ~49 minecraft:air
setblock ~59 ~-67 ~49 minecraft:chest[facing=north]
setblock ~60 ~-67 ~49 minecraft:air
setblock ~61 ~-67 ~49 minecraft:chest[facing=north]
setblock ~62 ~-67 ~49 minecraft:air
setblock ~63 ~-67 ~49 minecraft:chest[facing=west]
setblock ~64 ~-67 ~49 minecraft:deepslate_tiles
fill ~4 ~-67 ~50 ~10 ~-67 ~50 minecraft:deepslate_tiles
setblock ~11 ~-67 ~50 minecraft:air
fill ~12 ~-67 ~50 ~32 ~-67 ~50 minecraft:deepslate_tiles
fill ~33 ~-67 ~50 ~35 ~-67 ~50 minecraft:air
fill ~36 ~-67 ~50 ~56 ~-67 ~50 minecraft:deepslate_tiles
setblock ~57 ~-67 ~50 minecraft:air
fill ~58 ~-67 ~50 ~64 ~-67 ~50 minecraft:deepslate_tiles
setblock ~4 ~-67 ~51 minecraft:deepslate_tiles
setblock ~5 ~-67 ~51 minecraft:blast_furnace[facing=south]
setblock ~6 ~-67 ~51 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~51 minecraft:blast_furnace[facing=south]
setblock ~8 ~-67 ~51 minecraft:waxed_cut_copper
setblock ~9 ~-67 ~51 minecraft:blast_furnace[facing=south]
fill ~10 ~-67 ~51 ~12 ~-67 ~51 minecraft:air
setblock ~13 ~-67 ~51 minecraft:blast_furnace[facing=south]
setblock ~14 ~-67 ~51 minecraft:waxed_cut_copper
setblock ~15 ~-67 ~51 minecraft:blast_furnace[facing=south]
setblock ~16 ~-67 ~51 minecraft:waxed_cut_copper
setblock ~17 ~-67 ~51 minecraft:blast_furnace[facing=south]
setblock ~18 ~-67 ~51 minecraft:deepslate_tiles
setblock ~19 ~-67 ~51 minecraft:chest[facing=south]
setblock ~20 ~-67 ~51 minecraft:air
setblock ~21 ~-67 ~51 minecraft:chest[facing=south]
setblock ~22 ~-67 ~51 minecraft:air
setblock ~23 ~-67 ~51 minecraft:chest[facing=south]
setblock ~24 ~-67 ~51 minecraft:air
setblock ~25 ~-67 ~51 minecraft:chest[facing=south]
setblock ~26 ~-67 ~51 minecraft:air
setblock ~27 ~-67 ~51 minecraft:chest[facing=south]
setblock ~28 ~-67 ~51 minecraft:air
setblock ~29 ~-67 ~51 minecraft:chest[facing=south]
setblock ~30 ~-67 ~51 minecraft:air
setblock ~31 ~-67 ~51 minecraft:chest[facing=south]
setblock ~32 ~-67 ~51 minecraft:deepslate_tiles
fill ~33 ~-67 ~51 ~35 ~-67 ~51 minecraft:air
setblock ~36 ~-67 ~51 minecraft:deepslate_tiles
setblock ~37 ~-67 ~51 minecraft:crafting_table
setblock ~38 ~-67 ~51 minecraft:smithing_table
setblock ~39 ~-67 ~51 minecraft:barrel
setblock ~40 ~-67 ~51 minecraft:iron_block
setblock ~41 ~-67 ~51 minecraft:crafting_table
setblock ~42 ~-67 ~51 minecraft:smithing_table
setblock ~43 ~-67 ~51 minecraft:barrel
setblock ~44 ~-67 ~51 minecraft:iron_block
setblock ~45 ~-67 ~51 minecraft:crafting_table
setblock ~46 ~-67 ~51 minecraft:smithing_table
setblock ~47 ~-67 ~51 minecraft:barrel
setblock ~48 ~-67 ~51 minecraft:iron_block
setblock ~49 ~-67 ~51 minecraft:crafting_table
setblock ~50 ~-67 ~51 minecraft:deepslate_tiles
setblock ~51 ~-67 ~51 minecraft:dispenser[facing=south]
fill ~52 ~-67 ~51 ~53 ~-67 ~51 minecraft:air
setblock ~54 ~-67 ~51 minecraft:dispenser[facing=south]
fill ~55 ~-67 ~51 ~59 ~-67 ~51 minecraft:air
setblock ~60 ~-67 ~51 minecraft:dispenser[facing=south]
fill ~61 ~-67 ~51 ~62 ~-67 ~51 minecraft:air
setblock ~63 ~-67 ~51 minecraft:dispenser[facing=south]
setblock ~64 ~-67 ~51 minecraft:deepslate_tiles
setblock ~4 ~-67 ~52 minecraft:deepslate_tiles
setblock ~5 ~-67 ~52 minecraft:waxed_cut_copper
fill ~6 ~-67 ~52 ~16 ~-67 ~52 minecraft:air
setblock ~17 ~-67 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~52 minecraft:deepslate_tiles
setblock ~19 ~-67 ~52 minecraft:air
fill ~20 ~-67 ~52 ~23 ~-67 ~52 minecraft:barrel
setblock ~24 ~-67 ~52 minecraft:air
fill ~25 ~-67 ~52 ~28 ~-67 ~52 minecraft:barrel
setblock ~29 ~-67 ~52 minecraft:air
setblock ~30 ~-67 ~52 minecraft:barrel
setblock ~31 ~-67 ~52 minecraft:air
setblock ~32 ~-67 ~52 minecraft:deepslate_tiles
fill ~33 ~-67 ~52 ~35 ~-67 ~52 minecraft:air
setblock ~36 ~-67 ~52 minecraft:deepslate_tiles
setblock ~37 ~-67 ~52 minecraft:smithing_table
fill ~38 ~-67 ~52 ~48 ~-67 ~52 minecraft:air
setblock ~49 ~-67 ~52 minecraft:smithing_table
setblock ~50 ~-67 ~52 minecraft:deepslate_tiles
fill ~51 ~-67 ~52 ~63 ~-67 ~52 minecraft:air
setblock ~64 ~-67 ~52 minecraft:deepslate_tiles
setblock ~4 ~-67 ~53 minecraft:deepslate_tiles
setblock ~5 ~-67 ~53 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~53 ~16 ~-67 ~53 minecraft:air
setblock ~17 ~-67 ~53 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~53 minecraft:deepslate_tiles
setblock ~19 ~-67 ~53 minecraft:chest[facing=east]
fill ~20 ~-67 ~53 ~30 ~-67 ~53 minecraft:air
setblock ~31 ~-67 ~53 minecraft:chest[facing=west]
setblock ~32 ~-67 ~53 minecraft:deepslate_tiles
fill ~33 ~-67 ~53 ~35 ~-67 ~53 minecraft:air
setblock ~36 ~-67 ~53 minecraft:deepslate_tiles
setblock ~37 ~-67 ~53 minecraft:barrel
fill ~38 ~-67 ~53 ~48 ~-67 ~53 minecraft:air
setblock ~49 ~-67 ~53 minecraft:barrel
setblock ~50 ~-67 ~53 minecraft:deepslate_tiles
fill ~51 ~-67 ~53 ~63 ~-67 ~53 minecraft:air
setblock ~64 ~-67 ~53 minecraft:deepslate_tiles
setblock ~4 ~-67 ~54 minecraft:deepslate_tiles
setblock ~5 ~-67 ~54 minecraft:waxed_cut_copper
fill ~6 ~-67 ~54 ~16 ~-67 ~54 minecraft:air
setblock ~17 ~-67 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~54 minecraft:deepslate_tiles
fill ~19 ~-67 ~54 ~31 ~-67 ~54 minecraft:air
setblock ~32 ~-67 ~54 minecraft:deepslate_tiles
fill ~33 ~-67 ~54 ~35 ~-67 ~54 minecraft:air
setblock ~36 ~-67 ~54 minecraft:deepslate_tiles
setblock ~37 ~-67 ~54 minecraft:iron_block
fill ~38 ~-67 ~54 ~48 ~-67 ~54 minecraft:air
setblock ~49 ~-67 ~54 minecraft:iron_block
setblock ~50 ~-67 ~54 minecraft:deepslate_tiles
setblock ~51 ~-67 ~54 minecraft:dispenser[facing=east]
fill ~52 ~-67 ~54 ~62 ~-67 ~54 minecraft:air
setblock ~63 ~-67 ~54 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~54 minecraft:deepslate_tiles
setblock ~4 ~-67 ~55 minecraft:deepslate_tiles
setblock ~5 ~-67 ~55 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~55 ~16 ~-67 ~55 minecraft:air
setblock ~17 ~-67 ~55 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~55 minecraft:deepslate_tiles
setblock ~19 ~-67 ~55 minecraft:chest[facing=east]
fill ~20 ~-67 ~55 ~23 ~-67 ~55 minecraft:barrel
setblock ~24 ~-67 ~55 minecraft:air
fill ~25 ~-67 ~55 ~28 ~-67 ~55 minecraft:barrel
setblock ~29 ~-67 ~55 minecraft:air
setblock ~30 ~-67 ~55 minecraft:barrel
setblock ~31 ~-67 ~55 minecraft:chest[facing=west]
setblock ~32 ~-67 ~55 minecraft:deepslate_tiles
fill ~33 ~-67 ~55 ~35 ~-67 ~55 minecraft:air
setblock ~36 ~-67 ~55 minecraft:deepslate_tiles
setblock ~37 ~-67 ~55 minecraft:crafting_table
fill ~38 ~-67 ~55 ~39 ~-67 ~55 minecraft:air
fill ~40 ~-67 ~55 ~46 ~-67 ~55 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-67 ~55 ~48 ~-67 ~55 minecraft:air
setblock ~49 ~-67 ~55 minecraft:crafting_table
setblock ~50 ~-67 ~55 minecraft:deepslate_tiles
fill ~51 ~-67 ~55 ~63 ~-67 ~55 minecraft:air
setblock ~64 ~-67 ~55 minecraft:deepslate_tiles
setblock ~4 ~-67 ~56 minecraft:deepslate_tiles
setblock ~5 ~-67 ~56 minecraft:waxed_cut_copper
fill ~6 ~-67 ~56 ~17 ~-67 ~56 minecraft:air
setblock ~18 ~-67 ~56 minecraft:deepslate_tiles
fill ~19 ~-67 ~56 ~31 ~-67 ~56 minecraft:air
setblock ~32 ~-67 ~56 minecraft:deepslate_tiles
fill ~33 ~-67 ~56 ~35 ~-67 ~56 minecraft:air
setblock ~36 ~-67 ~56 minecraft:deepslate_tiles
fill ~37 ~-67 ~56 ~49 ~-67 ~56 minecraft:air
setblock ~50 ~-67 ~56 minecraft:deepslate_tiles
fill ~51 ~-67 ~56 ~63 ~-67 ~56 minecraft:air
setblock ~64 ~-67 ~56 minecraft:deepslate_tiles
setblock ~4 ~-67 ~57 minecraft:deepslate_tiles
setblock ~5 ~-67 ~57 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~57 ~11 ~-67 ~57 minecraft:air
setblock ~12 ~-67 ~57 minecraft:waxed_cut_copper
fill ~13 ~-67 ~57 ~62 ~-67 ~57 minecraft:air
setblock ~63 ~-67 ~57 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~57 minecraft:deepslate_tiles
setblock ~4 ~-67 ~58 minecraft:deepslate_tiles
setblock ~5 ~-67 ~58 minecraft:waxed_cut_copper
fill ~6 ~-67 ~58 ~17 ~-67 ~58 minecraft:air
setblock ~18 ~-67 ~58 minecraft:deepslate_tiles
setblock ~19 ~-67 ~58 minecraft:air
fill ~20 ~-67 ~58 ~23 ~-67 ~58 minecraft:barrel
setblock ~24 ~-67 ~58 minecraft:air
fill ~25 ~-67 ~58 ~28 ~-67 ~58 minecraft:barrel
setblock ~29 ~-67 ~58 minecraft:air
setblock ~30 ~-67 ~58 minecraft:barrel
setblock ~31 ~-67 ~58 minecraft:air
setblock ~32 ~-67 ~58 minecraft:deepslate_tiles
fill ~33 ~-67 ~58 ~35 ~-67 ~58 minecraft:air
setblock ~36 ~-67 ~58 minecraft:deepslate_tiles
fill ~37 ~-67 ~58 ~49 ~-67 ~58 minecraft:air
setblock ~50 ~-67 ~58 minecraft:deepslate_tiles
fill ~51 ~-67 ~58 ~63 ~-67 ~58 minecraft:air
setblock ~64 ~-67 ~58 minecraft:deepslate_tiles
setblock ~4 ~-67 ~59 minecraft:deepslate_tiles
setblock ~5 ~-67 ~59 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~59 ~16 ~-67 ~59 minecraft:air
setblock ~17 ~-67 ~59 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~59 minecraft:deepslate_tiles
setblock ~19 ~-67 ~59 minecraft:chest[facing=east]
fill ~20 ~-67 ~59 ~30 ~-67 ~59 minecraft:air
setblock ~31 ~-67 ~59 minecraft:chest[facing=west]
setblock ~32 ~-67 ~59 minecraft:deepslate_tiles
fill ~33 ~-67 ~59 ~35 ~-67 ~59 minecraft:air
setblock ~36 ~-67 ~59 minecraft:deepslate_tiles
setblock ~37 ~-67 ~59 minecraft:crafting_table
fill ~38 ~-67 ~59 ~39 ~-67 ~59 minecraft:air
fill ~40 ~-67 ~59 ~46 ~-67 ~59 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-67 ~59 ~48 ~-67 ~59 minecraft:air
setblock ~49 ~-67 ~59 minecraft:crafting_table
setblock ~50 ~-67 ~59 minecraft:deepslate_tiles
fill ~51 ~-67 ~59 ~63 ~-67 ~59 minecraft:air
setblock ~64 ~-67 ~59 minecraft:deepslate_tiles
setblock ~4 ~-67 ~60 minecraft:deepslate_tiles
setblock ~5 ~-67 ~60 minecraft:waxed_cut_copper
fill ~6 ~-67 ~60 ~16 ~-67 ~60 minecraft:air
setblock ~17 ~-67 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~60 minecraft:deepslate_tiles
fill ~19 ~-67 ~60 ~31 ~-67 ~60 minecraft:air
setblock ~32 ~-67 ~60 minecraft:deepslate_tiles
fill ~33 ~-67 ~60 ~35 ~-67 ~60 minecraft:air
setblock ~36 ~-67 ~60 minecraft:deepslate_tiles
setblock ~37 ~-67 ~60 minecraft:smithing_table
fill ~38 ~-67 ~60 ~48 ~-67 ~60 minecraft:air
setblock ~49 ~-67 ~60 minecraft:smithing_table
setblock ~50 ~-67 ~60 minecraft:deepslate_tiles
setblock ~51 ~-67 ~60 minecraft:dispenser[facing=east]
fill ~52 ~-67 ~60 ~62 ~-67 ~60 minecraft:air
setblock ~63 ~-67 ~60 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~60 minecraft:deepslate_tiles
setblock ~4 ~-67 ~61 minecraft:deepslate_tiles
setblock ~5 ~-67 ~61 minecraft:blast_furnace[facing=east]
fill ~6 ~-67 ~61 ~16 ~-67 ~61 minecraft:air
setblock ~17 ~-67 ~61 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~61 minecraft:deepslate_tiles
setblock ~19 ~-67 ~61 minecraft:chest[facing=east]
fill ~20 ~-67 ~61 ~23 ~-67 ~61 minecraft:barrel
setblock ~24 ~-67 ~61 minecraft:air
fill ~25 ~-67 ~61 ~28 ~-67 ~61 minecraft:barrel
setblock ~29 ~-67 ~61 minecraft:air
setblock ~30 ~-67 ~61 minecraft:barrel
setblock ~31 ~-67 ~61 minecraft:chest[facing=west]
setblock ~32 ~-67 ~61 minecraft:deepslate_tiles
fill ~33 ~-67 ~61 ~35 ~-67 ~61 minecraft:air
setblock ~36 ~-67 ~61 minecraft:deepslate_tiles
setblock ~37 ~-67 ~61 minecraft:barrel
fill ~38 ~-67 ~61 ~48 ~-67 ~61 minecraft:air
setblock ~49 ~-67 ~61 minecraft:barrel
setblock ~50 ~-67 ~61 minecraft:deepslate_tiles
fill ~51 ~-67 ~61 ~63 ~-67 ~61 minecraft:air
setblock ~64 ~-67 ~61 minecraft:deepslate_tiles
setblock ~4 ~-67 ~62 minecraft:deepslate_tiles
setblock ~5 ~-67 ~62 minecraft:waxed_cut_copper
fill ~6 ~-67 ~62 ~16 ~-67 ~62 minecraft:air
setblock ~17 ~-67 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-67 ~62 minecraft:deepslate_tiles
fill ~19 ~-67 ~62 ~31 ~-67 ~62 minecraft:air
setblock ~32 ~-67 ~62 minecraft:deepslate_tiles
fill ~33 ~-67 ~62 ~35 ~-67 ~62 minecraft:air
setblock ~36 ~-67 ~62 minecraft:deepslate_tiles
setblock ~37 ~-67 ~62 minecraft:iron_block
fill ~38 ~-67 ~62 ~48 ~-67 ~62 minecraft:air
setblock ~49 ~-67 ~62 minecraft:iron_block
setblock ~50 ~-67 ~62 minecraft:deepslate_tiles
fill ~51 ~-67 ~62 ~63 ~-67 ~62 minecraft:air
setblock ~64 ~-67 ~62 minecraft:deepslate_tiles
setblock ~4 ~-67 ~63 minecraft:deepslate_tiles
setblock ~5 ~-67 ~63 minecraft:blast_furnace[facing=north]
setblock ~6 ~-67 ~63 minecraft:waxed_cut_copper
setblock ~7 ~-67 ~63 minecraft:blast_furnace[facing=north]
setblock ~8 ~-67 ~63 minecraft:waxed_cut_copper
setblock ~9 ~-67 ~63 minecraft:blast_furnace[facing=north]
setblock ~10 ~-67 ~63 minecraft:waxed_cut_copper
setblock ~11 ~-67 ~63 minecraft:blast_furnace[facing=north]
setblock ~12 ~-67 ~63 minecraft:waxed_cut_copper
setblock ~13 ~-67 ~63 minecraft:blast_furnace[facing=north]
setblock ~14 ~-67 ~63 minecraft:waxed_cut_copper
setblock ~15 ~-67 ~63 minecraft:blast_furnace[facing=north]
setblock ~16 ~-67 ~63 minecraft:waxed_cut_copper
setblock ~17 ~-67 ~63 minecraft:blast_furnace[facing=west]
setblock ~18 ~-67 ~63 minecraft:deepslate_tiles
setblock ~19 ~-67 ~63 minecraft:chest[facing=north]
setblock ~20 ~-67 ~63 minecraft:air
setblock ~21 ~-67 ~63 minecraft:chest[facing=north]
setblock ~22 ~-67 ~63 minecraft:air
setblock ~23 ~-67 ~63 minecraft:chest[facing=north]
setblock ~24 ~-67 ~63 minecraft:air
setblock ~25 ~-67 ~63 minecraft:chest[facing=north]
setblock ~26 ~-67 ~63 minecraft:air
setblock ~27 ~-67 ~63 minecraft:chest[facing=north]
setblock ~28 ~-67 ~63 minecraft:air
setblock ~29 ~-67 ~63 minecraft:chest[facing=north]
setblock ~30 ~-67 ~63 minecraft:air
setblock ~31 ~-67 ~63 minecraft:chest[facing=west]
setblock ~32 ~-67 ~63 minecraft:deepslate_tiles
fill ~33 ~-67 ~63 ~35 ~-67 ~63 minecraft:air
setblock ~36 ~-67 ~63 minecraft:deepslate_tiles
setblock ~37 ~-67 ~63 minecraft:crafting_table
setblock ~38 ~-67 ~63 minecraft:smithing_table
setblock ~39 ~-67 ~63 minecraft:barrel
setblock ~40 ~-67 ~63 minecraft:iron_block
setblock ~41 ~-67 ~63 minecraft:crafting_table
setblock ~42 ~-67 ~63 minecraft:smithing_table
setblock ~43 ~-67 ~63 minecraft:barrel
setblock ~44 ~-67 ~63 minecraft:iron_block
setblock ~45 ~-67 ~63 minecraft:crafting_table
setblock ~46 ~-67 ~63 minecraft:smithing_table
setblock ~47 ~-67 ~63 minecraft:barrel
setblock ~48 ~-67 ~63 minecraft:iron_block
setblock ~49 ~-67 ~63 minecraft:crafting_table
setblock ~50 ~-67 ~63 minecraft:deepslate_tiles
setblock ~51 ~-67 ~63 minecraft:dispenser[facing=north]
fill ~52 ~-67 ~63 ~53 ~-67 ~63 minecraft:air
setblock ~54 ~-67 ~63 minecraft:dispenser[facing=north]
fill ~55 ~-67 ~63 ~56 ~-67 ~63 minecraft:air
setblock ~57 ~-67 ~63 minecraft:dispenser[facing=north]
fill ~58 ~-67 ~63 ~59 ~-67 ~63 minecraft:air
setblock ~60 ~-67 ~63 minecraft:dispenser[facing=north]
fill ~61 ~-67 ~63 ~62 ~-67 ~63 minecraft:air
setblock ~63 ~-67 ~63 minecraft:dispenser[facing=west]
setblock ~64 ~-67 ~63 minecraft:deepslate_tiles
fill ~4 ~-67 ~64 ~33 ~-67 ~64 minecraft:deepslate_tiles
setblock ~34 ~-67 ~64 minecraft:air
fill ~35 ~-67 ~64 ~64 ~-67 ~64 minecraft:deepslate_tiles
setblock ~33 ~-67 ~65 minecraft:deepslate_tiles
setblock ~34 ~-67 ~65 minecraft:air
setblock ~35 ~-67 ~65 minecraft:deepslate_tiles
fill ~32 ~-67 ~66 ~33 ~-67 ~66 minecraft:polished_andesite
setblock ~34 ~-67 ~66 minecraft:air
fill ~35 ~-67 ~66 ~36 ~-67 ~66 minecraft:polished_andesite
setblock ~32 ~-67 ~67 minecraft:polished_andesite
fill ~33 ~-67 ~67 ~34 ~-67 ~67 minecraft:air
setblock ~35 ~-67 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-67 ~67 minecraft:polished_andesite
setblock ~32 ~-67 ~68 minecraft:polished_andesite
setblock ~33 ~-67 ~68 minecraft:air
setblock ~34 ~-67 ~68 minecraft:quartz_pillar
setblock ~35 ~-67 ~68 minecraft:air
setblock ~36 ~-67 ~68 minecraft:polished_andesite
setblock ~32 ~-67 ~69 minecraft:polished_andesite
fill ~33 ~-67 ~69 ~35 ~-67 ~69 minecraft:air
setblock ~36 ~-67 ~69 minecraft:polished_andesite
fill ~32 ~-67 ~70 ~36 ~-67 ~70 minecraft:polished_andesite
fill ~4 ~-66 ~4 ~64 ~-66 ~4 minecraft:deepslate_tiles
setblock ~4 ~-66 ~5 minecraft:deepslate_tiles
setblock ~5 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~6 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~8 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~9 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~10 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~11 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~12 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~13 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~14 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~15 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~16 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~17 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~18 ~-66 ~5 minecraft:deepslate_tiles
setblock ~19 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~20 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~21 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~22 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~23 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~24 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~25 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~26 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~27 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~28 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~29 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~30 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~31 ~-66 ~5 minecraft:blast_furnace[facing=south]
setblock ~32 ~-66 ~5 minecraft:yellow_concrete
fill ~33 ~-66 ~5 ~35 ~-66 ~5 minecraft:air
setblock ~36 ~-66 ~5 minecraft:yellow_concrete
setblock ~37 ~-66 ~5 minecraft:waxed_cut_copper
fill ~38 ~-66 ~5 ~39 ~-66 ~5 minecraft:air
setblock ~40 ~-66 ~5 minecraft:waxed_cut_copper
fill ~41 ~-66 ~5 ~42 ~-66 ~5 minecraft:air
setblock ~43 ~-66 ~5 minecraft:waxed_cut_copper
fill ~44 ~-66 ~5 ~45 ~-66 ~5 minecraft:air
setblock ~46 ~-66 ~5 minecraft:waxed_cut_copper
fill ~47 ~-66 ~5 ~48 ~-66 ~5 minecraft:air
setblock ~49 ~-66 ~5 minecraft:waxed_cut_copper
setblock ~50 ~-66 ~5 minecraft:deepslate_tiles
setblock ~51 ~-66 ~5 minecraft:air
setblock ~52 ~-66 ~5 minecraft:waxed_cut_copper
fill ~53 ~-66 ~5 ~54 ~-66 ~5 minecraft:air
setblock ~55 ~-66 ~5 minecraft:waxed_cut_copper
fill ~56 ~-66 ~5 ~57 ~-66 ~5 minecraft:air
setblock ~58 ~-66 ~5 minecraft:waxed_cut_copper
fill ~59 ~-66 ~5 ~60 ~-66 ~5 minecraft:air
setblock ~61 ~-66 ~5 minecraft:waxed_cut_copper
fill ~62 ~-66 ~5 ~63 ~-66 ~5 minecraft:air
setblock ~64 ~-66 ~5 minecraft:deepslate_tiles
setblock ~4 ~-66 ~6 minecraft:deepslate_tiles
setblock ~5 ~-66 ~6 minecraft:waxed_cut_copper
fill ~6 ~-66 ~6 ~16 ~-66 ~6 minecraft:air
setblock ~17 ~-66 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~6 minecraft:deepslate_tiles
setblock ~19 ~-66 ~6 minecraft:waxed_cut_copper
fill ~20 ~-66 ~6 ~30 ~-66 ~6 minecraft:air
setblock ~31 ~-66 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-66 ~6 minecraft:yellow_concrete
fill ~33 ~-66 ~6 ~35 ~-66 ~6 minecraft:air
setblock ~36 ~-66 ~6 minecraft:yellow_concrete
fill ~37 ~-66 ~6 ~49 ~-66 ~6 minecraft:air
setblock ~50 ~-66 ~6 minecraft:deepslate_tiles
setblock ~51 ~-66 ~6 minecraft:waxed_cut_copper
fill ~52 ~-66 ~6 ~62 ~-66 ~6 minecraft:air
setblock ~63 ~-66 ~6 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~6 minecraft:deepslate_tiles
setblock ~4 ~-66 ~7 minecraft:deepslate_tiles
setblock ~5 ~-66 ~7 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~7 ~16 ~-66 ~7 minecraft:air
setblock ~17 ~-66 ~7 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~7 minecraft:deepslate_tiles
setblock ~19 ~-66 ~7 minecraft:blast_furnace[facing=east]
fill ~20 ~-66 ~7 ~30 ~-66 ~7 minecraft:air
setblock ~31 ~-66 ~7 minecraft:blast_furnace[facing=west]
setblock ~32 ~-66 ~7 minecraft:yellow_concrete
fill ~33 ~-66 ~7 ~35 ~-66 ~7 minecraft:air
setblock ~36 ~-66 ~7 minecraft:yellow_concrete
fill ~37 ~-66 ~7 ~49 ~-66 ~7 minecraft:air
setblock ~50 ~-66 ~7 minecraft:deepslate_tiles
fill ~51 ~-66 ~7 ~63 ~-66 ~7 minecraft:air
setblock ~64 ~-66 ~7 minecraft:deepslate_tiles
setblock ~4 ~-66 ~8 minecraft:deepslate_tiles
setblock ~5 ~-66 ~8 minecraft:waxed_cut_copper
fill ~6 ~-66 ~8 ~16 ~-66 ~8 minecraft:air
setblock ~17 ~-66 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~8 minecraft:deepslate_tiles
setblock ~19 ~-66 ~8 minecraft:waxed_cut_copper
fill ~20 ~-66 ~8 ~30 ~-66 ~8 minecraft:air
setblock ~31 ~-66 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-66 ~8 minecraft:yellow_concrete
fill ~33 ~-66 ~8 ~35 ~-66 ~8 minecraft:air
setblock ~36 ~-66 ~8 minecraft:yellow_concrete
setblock ~37 ~-66 ~8 minecraft:waxed_cut_copper
fill ~38 ~-66 ~8 ~48 ~-66 ~8 minecraft:air
setblock ~49 ~-66 ~8 minecraft:waxed_cut_copper
setblock ~50 ~-66 ~8 minecraft:deepslate_tiles
fill ~51 ~-66 ~8 ~63 ~-66 ~8 minecraft:air
setblock ~64 ~-66 ~8 minecraft:deepslate_tiles
setblock ~4 ~-66 ~9 minecraft:deepslate_tiles
setblock ~5 ~-66 ~9 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~9 ~16 ~-66 ~9 minecraft:air
setblock ~17 ~-66 ~9 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~9 minecraft:deepslate_tiles
setblock ~19 ~-66 ~9 minecraft:blast_furnace[facing=east]
fill ~20 ~-66 ~9 ~30 ~-66 ~9 minecraft:air
setblock ~31 ~-66 ~9 minecraft:blast_furnace[facing=west]
setblock ~32 ~-66 ~9 minecraft:yellow_concrete
fill ~33 ~-66 ~9 ~35 ~-66 ~9 minecraft:air
setblock ~36 ~-66 ~9 minecraft:yellow_concrete
fill ~37 ~-66 ~9 ~49 ~-66 ~9 minecraft:air
setblock ~50 ~-66 ~9 minecraft:deepslate_tiles
setblock ~51 ~-66 ~9 minecraft:waxed_cut_copper
fill ~52 ~-66 ~9 ~62 ~-66 ~9 minecraft:air
setblock ~63 ~-66 ~9 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~9 minecraft:deepslate_tiles
setblock ~4 ~-66 ~10 minecraft:deepslate_tiles
setblock ~5 ~-66 ~10 minecraft:waxed_cut_copper
fill ~6 ~-66 ~10 ~17 ~-66 ~10 minecraft:air
setblock ~18 ~-66 ~10 minecraft:deepslate_tiles
fill ~19 ~-66 ~10 ~31 ~-66 ~10 minecraft:air
setblock ~32 ~-66 ~10 minecraft:yellow_concrete
fill ~33 ~-66 ~10 ~35 ~-66 ~10 minecraft:air
setblock ~36 ~-66 ~10 minecraft:yellow_concrete
fill ~37 ~-66 ~10 ~49 ~-66 ~10 minecraft:air
setblock ~50 ~-66 ~10 minecraft:deepslate_tiles
fill ~51 ~-66 ~10 ~63 ~-66 ~10 minecraft:air
setblock ~64 ~-66 ~10 minecraft:deepslate_tiles
setblock ~4 ~-66 ~11 minecraft:deepslate_tiles
setblock ~5 ~-66 ~11 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~11 ~63 ~-66 ~11 minecraft:air
setblock ~64 ~-66 ~11 minecraft:deepslate_tiles
setblock ~4 ~-66 ~12 minecraft:deepslate_tiles
setblock ~5 ~-66 ~12 minecraft:waxed_cut_copper
fill ~6 ~-66 ~12 ~11 ~-66 ~12 minecraft:air
setblock ~12 ~-66 ~12 minecraft:waxed_cut_copper
fill ~13 ~-66 ~12 ~17 ~-66 ~12 minecraft:air
setblock ~18 ~-66 ~12 minecraft:deepslate_tiles
fill ~19 ~-66 ~12 ~21 ~-66 ~12 minecraft:air
setblock ~22 ~-66 ~12 minecraft:waxed_cut_copper
fill ~23 ~-66 ~12 ~26 ~-66 ~12 minecraft:air
setblock ~27 ~-66 ~12 minecraft:waxed_cut_copper
fill ~28 ~-66 ~12 ~31 ~-66 ~12 minecraft:air
setblock ~32 ~-66 ~12 minecraft:yellow_concrete
fill ~33 ~-66 ~12 ~35 ~-66 ~12 minecraft:air
setblock ~36 ~-66 ~12 minecraft:yellow_concrete
fill ~37 ~-66 ~12 ~49 ~-66 ~12 minecraft:air
setblock ~50 ~-66 ~12 minecraft:deepslate_tiles
fill ~51 ~-66 ~12 ~62 ~-66 ~12 minecraft:air
setblock ~63 ~-66 ~12 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~12 minecraft:deepslate_tiles
setblock ~4 ~-66 ~13 minecraft:deepslate_tiles
setblock ~5 ~-66 ~13 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~13 ~16 ~-66 ~13 minecraft:air
setblock ~17 ~-66 ~13 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~13 minecraft:deepslate_tiles
setblock ~19 ~-66 ~13 minecraft:blast_furnace[facing=east]
fill ~20 ~-66 ~13 ~30 ~-66 ~13 minecraft:air
setblock ~31 ~-66 ~13 minecraft:blast_furnace[facing=west]
setblock ~32 ~-66 ~13 minecraft:yellow_concrete
fill ~33 ~-66 ~13 ~35 ~-66 ~13 minecraft:air
setblock ~36 ~-66 ~13 minecraft:yellow_concrete
fill ~37 ~-66 ~13 ~49 ~-66 ~13 minecraft:air
setblock ~50 ~-66 ~13 minecraft:deepslate_tiles
fill ~51 ~-66 ~13 ~63 ~-66 ~13 minecraft:air
setblock ~64 ~-66 ~13 minecraft:deepslate_tiles
setblock ~4 ~-66 ~14 minecraft:deepslate_tiles
setblock ~5 ~-66 ~14 minecraft:waxed_cut_copper
fill ~6 ~-66 ~14 ~16 ~-66 ~14 minecraft:air
setblock ~17 ~-66 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~14 minecraft:deepslate_tiles
setblock ~19 ~-66 ~14 minecraft:waxed_cut_copper
fill ~20 ~-66 ~14 ~30 ~-66 ~14 minecraft:air
setblock ~31 ~-66 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-66 ~14 minecraft:yellow_concrete
fill ~33 ~-66 ~14 ~35 ~-66 ~14 minecraft:air
setblock ~36 ~-66 ~14 minecraft:yellow_concrete
setblock ~37 ~-66 ~14 minecraft:waxed_cut_copper
fill ~38 ~-66 ~14 ~48 ~-66 ~14 minecraft:air
setblock ~49 ~-66 ~14 minecraft:waxed_cut_copper
setblock ~50 ~-66 ~14 minecraft:deepslate_tiles
fill ~51 ~-66 ~14 ~63 ~-66 ~14 minecraft:air
setblock ~64 ~-66 ~14 minecraft:deepslate_tiles
setblock ~4 ~-66 ~15 minecraft:deepslate_tiles
setblock ~5 ~-66 ~15 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~15 ~16 ~-66 ~15 minecraft:air
setblock ~17 ~-66 ~15 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~15 minecraft:deepslate_tiles
setblock ~19 ~-66 ~15 minecraft:blast_furnace[facing=east]
fill ~20 ~-66 ~15 ~30 ~-66 ~15 minecraft:air
setblock ~31 ~-66 ~15 minecraft:blast_furnace[facing=west]
setblock ~32 ~-66 ~15 minecraft:yellow_concrete
fill ~33 ~-66 ~15 ~35 ~-66 ~15 minecraft:air
setblock ~36 ~-66 ~15 minecraft:yellow_concrete
fill ~37 ~-66 ~15 ~49 ~-66 ~15 minecraft:air
setblock ~50 ~-66 ~15 minecraft:deepslate_tiles
setblock ~51 ~-66 ~15 minecraft:waxed_cut_copper
fill ~52 ~-66 ~15 ~62 ~-66 ~15 minecraft:air
setblock ~63 ~-66 ~15 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~15 minecraft:deepslate_tiles
setblock ~4 ~-66 ~16 minecraft:deepslate_tiles
setblock ~5 ~-66 ~16 minecraft:waxed_cut_copper
fill ~6 ~-66 ~16 ~16 ~-66 ~16 minecraft:air
setblock ~17 ~-66 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~16 minecraft:deepslate_tiles
setblock ~19 ~-66 ~16 minecraft:waxed_cut_copper
fill ~20 ~-66 ~16 ~30 ~-66 ~16 minecraft:air
setblock ~31 ~-66 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-66 ~16 minecraft:yellow_concrete
fill ~33 ~-66 ~16 ~35 ~-66 ~16 minecraft:air
setblock ~36 ~-66 ~16 minecraft:yellow_concrete
fill ~37 ~-66 ~16 ~49 ~-66 ~16 minecraft:air
setblock ~50 ~-66 ~16 minecraft:deepslate_tiles
fill ~51 ~-66 ~16 ~63 ~-66 ~16 minecraft:air
setblock ~64 ~-66 ~16 minecraft:deepslate_tiles
setblock ~4 ~-66 ~17 minecraft:deepslate_tiles
setblock ~5 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~6 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~8 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~9 ~-66 ~17 minecraft:blast_furnace[facing=north]
fill ~10 ~-66 ~17 ~12 ~-66 ~17 minecraft:air
setblock ~13 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~14 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~15 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~16 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~17 ~-66 ~17 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~17 minecraft:deepslate_tiles
setblock ~19 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~20 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~21 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~22 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~23 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~24 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~25 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~26 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~27 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~28 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~29 ~-66 ~17 minecraft:blast_furnace[facing=north]
setblock ~30 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~31 ~-66 ~17 minecraft:blast_furnace[facing=west]
setblock ~32 ~-66 ~17 minecraft:yellow_concrete
fill ~33 ~-66 ~17 ~35 ~-66 ~17 minecraft:air
setblock ~36 ~-66 ~17 minecraft:yellow_concrete
setblock ~37 ~-66 ~17 minecraft:waxed_cut_copper
fill ~38 ~-66 ~17 ~39 ~-66 ~17 minecraft:air
setblock ~40 ~-66 ~17 minecraft:waxed_cut_copper
fill ~41 ~-66 ~17 ~42 ~-66 ~17 minecraft:air
setblock ~43 ~-66 ~17 minecraft:waxed_cut_copper
fill ~44 ~-66 ~17 ~45 ~-66 ~17 minecraft:air
setblock ~46 ~-66 ~17 minecraft:waxed_cut_copper
fill ~47 ~-66 ~17 ~48 ~-66 ~17 minecraft:air
setblock ~49 ~-66 ~17 minecraft:waxed_cut_copper
setblock ~50 ~-66 ~17 minecraft:deepslate_tiles
setblock ~51 ~-66 ~17 minecraft:air
setblock ~52 ~-66 ~17 minecraft:waxed_cut_copper
fill ~53 ~-66 ~17 ~54 ~-66 ~17 minecraft:air
setblock ~55 ~-66 ~17 minecraft:waxed_cut_copper
fill ~56 ~-66 ~17 ~60 ~-66 ~17 minecraft:air
setblock ~61 ~-66 ~17 minecraft:waxed_cut_copper
fill ~62 ~-66 ~17 ~63 ~-66 ~17 minecraft:air
setblock ~64 ~-66 ~17 minecraft:deepslate_tiles
fill ~4 ~-66 ~18 ~10 ~-66 ~18 minecraft:deepslate_tiles
setblock ~11 ~-66 ~18 minecraft:air
fill ~12 ~-66 ~18 ~31 ~-66 ~18 minecraft:deepslate_tiles
setblock ~32 ~-66 ~18 minecraft:yellow_concrete
fill ~33 ~-66 ~18 ~35 ~-66 ~18 minecraft:air
setblock ~36 ~-66 ~18 minecraft:yellow_concrete
fill ~37 ~-66 ~18 ~56 ~-66 ~18 minecraft:deepslate_tiles
setblock ~57 ~-66 ~18 minecraft:air
fill ~58 ~-66 ~18 ~64 ~-66 ~18 minecraft:deepslate_tiles
setblock ~4 ~-66 ~19 minecraft:deepslate_tiles
setblock ~5 ~-66 ~19 minecraft:blast_furnace[facing=south]
setblock ~6 ~-66 ~19 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~19 minecraft:redstone_lamp[lit=true]
setblock ~8 ~-66 ~19 minecraft:blast_furnace[facing=south]
setblock ~9 ~-66 ~19 minecraft:waxed_cut_copper
fill ~10 ~-66 ~19 ~12 ~-66 ~19 minecraft:air
setblock ~13 ~-66 ~19 minecraft:redstone_lamp[lit=true]
setblock ~14 ~-66 ~19 minecraft:blast_furnace[facing=south]
setblock ~15 ~-66 ~19 minecraft:waxed_cut_copper
setblock ~16 ~-66 ~19 minecraft:redstone_lamp[lit=true]
setblock ~17 ~-66 ~19 minecraft:blast_furnace[facing=south]
setblock ~18 ~-66 ~19 minecraft:deepslate_tiles
fill ~19 ~-66 ~19 ~49 ~-66 ~19 minecraft:air
setblock ~50 ~-66 ~19 minecraft:deepslate_tiles
fill ~51 ~-66 ~19 ~63 ~-66 ~19 minecraft:air
setblock ~64 ~-66 ~19 minecraft:deepslate_tiles
setblock ~4 ~-66 ~20 minecraft:deepslate_tiles
setblock ~5 ~-66 ~20 minecraft:waxed_cut_copper
fill ~6 ~-66 ~20 ~16 ~-66 ~20 minecraft:air
setblock ~17 ~-66 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~20 minecraft:deepslate_tiles
fill ~19 ~-66 ~20 ~28 ~-66 ~20 minecraft:air
fill ~29 ~-66 ~20 ~32 ~-66 ~20 minecraft:deepslate_tiles
fill ~33 ~-66 ~20 ~35 ~-66 ~20 minecraft:air
fill ~36 ~-66 ~20 ~39 ~-66 ~20 minecraft:deepslate_tiles
fill ~40 ~-66 ~20 ~49 ~-66 ~20 minecraft:air
setblock ~50 ~-66 ~20 minecraft:deepslate_tiles
fill ~51 ~-66 ~20 ~63 ~-66 ~20 minecraft:air
setblock ~64 ~-66 ~20 minecraft:deepslate_tiles
setblock ~4 ~-66 ~21 minecraft:deepslate_tiles
setblock ~5 ~-66 ~21 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~21 ~16 ~-66 ~21 minecraft:air
setblock ~17 ~-66 ~21 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~21 minecraft:deepslate_tiles
setblock ~19 ~-66 ~21 minecraft:air
fill ~20 ~-66 ~21 ~23 ~-66 ~21 minecraft:barrel
setblock ~24 ~-66 ~21 minecraft:air
fill ~25 ~-66 ~21 ~26 ~-66 ~21 minecraft:barrel
fill ~27 ~-66 ~21 ~28 ~-66 ~21 minecraft:deepslate_tiles
fill ~29 ~-66 ~21 ~39 ~-66 ~21 minecraft:air
fill ~40 ~-66 ~21 ~41 ~-66 ~21 minecraft:deepslate_tiles
setblock ~42 ~-66 ~21 minecraft:air
fill ~43 ~-66 ~21 ~46 ~-66 ~21 minecraft:barrel
setblock ~47 ~-66 ~21 minecraft:air
setblock ~48 ~-66 ~21 minecraft:barrel
setblock ~49 ~-66 ~21 minecraft:air
setblock ~50 ~-66 ~21 minecraft:deepslate_tiles
fill ~51 ~-66 ~21 ~63 ~-66 ~21 minecraft:air
setblock ~64 ~-66 ~21 minecraft:deepslate_tiles
setblock ~4 ~-66 ~22 minecraft:deepslate_tiles
setblock ~5 ~-66 ~22 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~22 ~9 ~-66 ~22 minecraft:air
setblock ~10 ~-66 ~22 minecraft:waxed_cut_copper
fill ~11 ~-66 ~22 ~13 ~-66 ~22 minecraft:air
setblock ~14 ~-66 ~22 minecraft:waxed_cut_copper
fill ~15 ~-66 ~22 ~16 ~-66 ~22 minecraft:air
setblock ~17 ~-66 ~22 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~22 minecraft:deepslate_tiles
fill ~19 ~-66 ~22 ~24 ~-66 ~22 minecraft:air
fill ~25 ~-66 ~22 ~26 ~-66 ~22 minecraft:deepslate_tiles
fill ~27 ~-66 ~22 ~41 ~-66 ~22 minecraft:air
fill ~42 ~-66 ~22 ~43 ~-66 ~22 minecraft:deepslate_tiles
fill ~44 ~-66 ~22 ~49 ~-66 ~22 minecraft:air
setblock ~50 ~-66 ~22 minecraft:deepslate_tiles
fill ~51 ~-66 ~22 ~63 ~-66 ~22 minecraft:air
setblock ~64 ~-66 ~22 minecraft:deepslate_tiles
setblock ~4 ~-66 ~23 minecraft:deepslate_tiles
schedule function hive:weiter/2 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 1 von 18 fertig","color":"gray"}]