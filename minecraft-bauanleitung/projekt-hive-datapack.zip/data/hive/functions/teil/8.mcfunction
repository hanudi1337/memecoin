setblock ~64 ~-36 ~23 minecraft:light_gray_concrete
setblock ~4 ~-36 ~24 minecraft:light_gray_concrete
fill ~5 ~-36 ~24 ~17 ~-36 ~24 minecraft:white_concrete
setblock ~18 ~-36 ~24 minecraft:light_gray_concrete
fill ~19 ~-36 ~24 ~25 ~-36 ~24 minecraft:white_concrete
fill ~26 ~-36 ~24 ~27 ~-36 ~24 minecraft:polished_andesite
fill ~28 ~-36 ~24 ~29 ~-36 ~24 minecraft:smooth_quartz
fill ~30 ~-36 ~24 ~33 ~-36 ~24 minecraft:polished_diorite
setblock ~34 ~-36 ~24 minecraft:smooth_quartz
fill ~35 ~-36 ~24 ~38 ~-36 ~24 minecraft:polished_diorite
fill ~39 ~-36 ~24 ~40 ~-36 ~24 minecraft:smooth_quartz
fill ~41 ~-36 ~24 ~42 ~-36 ~24 minecraft:polished_andesite
fill ~43 ~-36 ~24 ~49 ~-36 ~24 minecraft:white_concrete
setblock ~50 ~-36 ~24 minecraft:light_gray_concrete
fill ~51 ~-36 ~24 ~53 ~-36 ~24 minecraft:white_concrete
fill ~54 ~-36 ~24 ~59 ~-36 ~24 minecraft:cyan_concrete
fill ~60 ~-36 ~24 ~63 ~-36 ~24 minecraft:white_concrete
setblock ~64 ~-36 ~24 minecraft:light_gray_concrete
setblock ~4 ~-36 ~25 minecraft:light_gray_concrete
fill ~5 ~-36 ~25 ~17 ~-36 ~25 minecraft:white_concrete
setblock ~18 ~-36 ~25 minecraft:light_gray_concrete
fill ~19 ~-36 ~25 ~24 ~-36 ~25 minecraft:white_concrete
fill ~25 ~-36 ~25 ~26 ~-36 ~25 minecraft:polished_andesite
setblock ~27 ~-36 ~25 minecraft:smooth_quartz
fill ~28 ~-36 ~25 ~29 ~-36 ~25 minecraft:polished_diorite
fill ~30 ~-36 ~25 ~31 ~-36 ~25 minecraft:smooth_quartz
fill ~32 ~-36 ~25 ~36 ~-36 ~25 minecraft:red_concrete
fill ~37 ~-36 ~25 ~38 ~-36 ~25 minecraft:smooth_quartz
fill ~39 ~-36 ~25 ~40 ~-36 ~25 minecraft:polished_diorite
setblock ~41 ~-36 ~25 minecraft:smooth_quartz
fill ~42 ~-36 ~25 ~43 ~-36 ~25 minecraft:polished_andesite
fill ~44 ~-36 ~25 ~49 ~-36 ~25 minecraft:white_concrete
setblock ~50 ~-36 ~25 minecraft:light_gray_concrete
fill ~51 ~-36 ~25 ~53 ~-36 ~25 minecraft:white_concrete
fill ~54 ~-36 ~25 ~59 ~-36 ~25 minecraft:cyan_concrete
fill ~60 ~-36 ~25 ~63 ~-36 ~25 minecraft:white_concrete
setblock ~64 ~-36 ~25 minecraft:light_gray_concrete
setblock ~4 ~-36 ~26 minecraft:light_gray_concrete
fill ~5 ~-36 ~26 ~17 ~-36 ~26 minecraft:white_concrete
setblock ~18 ~-36 ~26 minecraft:light_gray_concrete
fill ~19 ~-36 ~26 ~23 ~-36 ~26 minecraft:white_concrete
fill ~24 ~-36 ~26 ~25 ~-36 ~26 minecraft:polished_andesite
setblock ~26 ~-36 ~26 minecraft:smooth_quartz
setblock ~27 ~-36 ~26 minecraft:polished_diorite
fill ~28 ~-36 ~26 ~29 ~-36 ~26 minecraft:smooth_quartz
fill ~30 ~-36 ~26 ~31 ~-36 ~26 minecraft:red_concrete
fill ~32 ~-36 ~26 ~36 ~-36 ~26 minecraft:air
fill ~37 ~-36 ~26 ~38 ~-36 ~26 minecraft:red_concrete
fill ~39 ~-36 ~26 ~40 ~-36 ~26 minecraft:smooth_quartz
setblock ~41 ~-36 ~26 minecraft:polished_diorite
setblock ~42 ~-36 ~26 minecraft:smooth_quartz
fill ~43 ~-36 ~26 ~44 ~-36 ~26 minecraft:polished_andesite
fill ~45 ~-36 ~26 ~49 ~-36 ~26 minecraft:white_concrete
setblock ~50 ~-36 ~26 minecraft:light_gray_concrete
fill ~51 ~-36 ~26 ~53 ~-36 ~26 minecraft:white_concrete
fill ~54 ~-36 ~26 ~59 ~-36 ~26 minecraft:cyan_concrete
fill ~60 ~-36 ~26 ~63 ~-36 ~26 minecraft:white_concrete
setblock ~64 ~-36 ~26 minecraft:light_gray_concrete
setblock ~4 ~-36 ~27 minecraft:light_gray_concrete
fill ~5 ~-36 ~27 ~17 ~-36 ~27 minecraft:white_concrete
setblock ~18 ~-36 ~27 minecraft:light_gray_concrete
fill ~19 ~-36 ~27 ~23 ~-36 ~27 minecraft:white_concrete
setblock ~24 ~-36 ~27 minecraft:polished_andesite
setblock ~25 ~-36 ~27 minecraft:smooth_quartz
setblock ~26 ~-36 ~27 minecraft:polished_diorite
setblock ~27 ~-36 ~27 minecraft:smooth_quartz
fill ~28 ~-36 ~27 ~29 ~-36 ~27 minecraft:red_concrete
fill ~30 ~-36 ~27 ~38 ~-36 ~27 minecraft:air
fill ~39 ~-36 ~27 ~40 ~-36 ~27 minecraft:red_concrete
setblock ~41 ~-36 ~27 minecraft:smooth_quartz
setblock ~42 ~-36 ~27 minecraft:polished_diorite
setblock ~43 ~-36 ~27 minecraft:smooth_quartz
setblock ~44 ~-36 ~27 minecraft:polished_andesite
fill ~45 ~-36 ~27 ~49 ~-36 ~27 minecraft:white_concrete
setblock ~50 ~-36 ~27 minecraft:light_gray_concrete
fill ~51 ~-36 ~27 ~53 ~-36 ~27 minecraft:white_concrete
fill ~54 ~-36 ~27 ~59 ~-36 ~27 minecraft:cyan_concrete
fill ~60 ~-36 ~27 ~63 ~-36 ~27 minecraft:white_concrete
setblock ~64 ~-36 ~27 minecraft:light_gray_concrete
setblock ~4 ~-36 ~28 minecraft:light_gray_concrete
fill ~5 ~-36 ~28 ~17 ~-36 ~28 minecraft:white_concrete
setblock ~18 ~-36 ~28 minecraft:light_gray_concrete
fill ~19 ~-36 ~28 ~22 ~-36 ~28 minecraft:white_concrete
setblock ~23 ~-36 ~28 minecraft:polished_andesite
setblock ~24 ~-36 ~28 minecraft:smooth_quartz
setblock ~25 ~-36 ~28 minecraft:polished_diorite
setblock ~26 ~-36 ~28 minecraft:smooth_quartz
setblock ~27 ~-36 ~28 minecraft:red_concrete
fill ~28 ~-36 ~28 ~40 ~-36 ~28 minecraft:air
setblock ~41 ~-36 ~28 minecraft:red_concrete
setblock ~42 ~-36 ~28 minecraft:smooth_quartz
setblock ~43 ~-36 ~28 minecraft:polished_diorite
setblock ~44 ~-36 ~28 minecraft:smooth_quartz
setblock ~45 ~-36 ~28 minecraft:polished_andesite
fill ~46 ~-36 ~28 ~49 ~-36 ~28 minecraft:white_concrete
setblock ~50 ~-36 ~28 minecraft:light_gray_concrete
fill ~51 ~-36 ~28 ~63 ~-36 ~28 minecraft:white_concrete
setblock ~64 ~-36 ~28 minecraft:light_gray_concrete
setblock ~4 ~-36 ~29 minecraft:light_gray_concrete
fill ~5 ~-36 ~29 ~17 ~-36 ~29 minecraft:white_concrete
setblock ~18 ~-36 ~29 minecraft:light_gray_concrete
fill ~19 ~-36 ~29 ~21 ~-36 ~29 minecraft:white_concrete
fill ~22 ~-36 ~29 ~23 ~-36 ~29 minecraft:polished_andesite
setblock ~24 ~-36 ~29 minecraft:smooth_quartz
setblock ~25 ~-36 ~29 minecraft:polished_diorite
setblock ~26 ~-36 ~29 minecraft:smooth_quartz
setblock ~27 ~-36 ~29 minecraft:red_concrete
fill ~28 ~-36 ~29 ~40 ~-36 ~29 minecraft:air
setblock ~41 ~-36 ~29 minecraft:red_concrete
setblock ~42 ~-36 ~29 minecraft:smooth_quartz
setblock ~43 ~-36 ~29 minecraft:polished_diorite
setblock ~44 ~-36 ~29 minecraft:smooth_quartz
fill ~45 ~-36 ~29 ~46 ~-36 ~29 minecraft:polished_andesite
fill ~47 ~-36 ~29 ~49 ~-36 ~29 minecraft:white_concrete
setblock ~50 ~-36 ~29 minecraft:light_gray_concrete
fill ~51 ~-36 ~29 ~63 ~-36 ~29 minecraft:white_concrete
setblock ~64 ~-36 ~29 minecraft:light_gray_concrete
setblock ~4 ~-36 ~30 minecraft:light_gray_concrete
fill ~5 ~-36 ~30 ~17 ~-36 ~30 minecraft:white_concrete
setblock ~18 ~-36 ~30 minecraft:light_gray_concrete
fill ~19 ~-36 ~30 ~21 ~-36 ~30 minecraft:white_concrete
setblock ~22 ~-36 ~30 minecraft:polished_andesite
setblock ~23 ~-36 ~30 minecraft:smooth_quartz
setblock ~24 ~-36 ~30 minecraft:polished_diorite
setblock ~25 ~-36 ~30 minecraft:smooth_quartz
setblock ~26 ~-36 ~30 minecraft:red_concrete
fill ~27 ~-36 ~30 ~41 ~-36 ~30 minecraft:air
setblock ~42 ~-36 ~30 minecraft:red_concrete
setblock ~43 ~-36 ~30 minecraft:smooth_quartz
setblock ~44 ~-36 ~30 minecraft:polished_diorite
setblock ~45 ~-36 ~30 minecraft:smooth_quartz
setblock ~46 ~-36 ~30 minecraft:polished_andesite
fill ~47 ~-36 ~30 ~49 ~-36 ~30 minecraft:white_concrete
setblock ~50 ~-36 ~30 minecraft:light_gray_concrete
fill ~51 ~-36 ~30 ~63 ~-36 ~30 minecraft:white_concrete
setblock ~64 ~-36 ~30 minecraft:light_gray_concrete
setblock ~4 ~-36 ~31 minecraft:light_gray_concrete
fill ~5 ~-36 ~31 ~17 ~-36 ~31 minecraft:white_concrete
setblock ~18 ~-36 ~31 minecraft:light_gray_concrete
fill ~19 ~-36 ~31 ~21 ~-36 ~31 minecraft:white_concrete
setblock ~22 ~-36 ~31 minecraft:polished_andesite
setblock ~23 ~-36 ~31 minecraft:smooth_quartz
setblock ~24 ~-36 ~31 minecraft:polished_diorite
setblock ~25 ~-36 ~31 minecraft:smooth_quartz
setblock ~26 ~-36 ~31 minecraft:red_concrete
fill ~27 ~-36 ~31 ~31 ~-36 ~31 minecraft:air
fill ~32 ~-36 ~31 ~36 ~-36 ~31 minecraft:iron_block
fill ~37 ~-36 ~31 ~41 ~-36 ~31 minecraft:air
setblock ~42 ~-36 ~31 minecraft:red_concrete
setblock ~43 ~-36 ~31 minecraft:smooth_quartz
setblock ~44 ~-36 ~31 minecraft:polished_diorite
setblock ~45 ~-36 ~31 minecraft:smooth_quartz
setblock ~46 ~-36 ~31 minecraft:polished_andesite
fill ~47 ~-36 ~31 ~49 ~-36 ~31 minecraft:white_concrete
setblock ~50 ~-36 ~31 minecraft:light_gray_concrete
fill ~51 ~-36 ~31 ~63 ~-36 ~31 minecraft:white_concrete
setblock ~64 ~-36 ~31 minecraft:light_gray_concrete
fill ~4 ~-36 ~32 ~21 ~-36 ~32 minecraft:light_gray_concrete
setblock ~22 ~-36 ~32 minecraft:polished_andesite
setblock ~23 ~-36 ~32 minecraft:smooth_quartz
setblock ~24 ~-36 ~32 minecraft:polished_diorite
setblock ~25 ~-36 ~32 minecraft:red_concrete
fill ~26 ~-36 ~32 ~31 ~-36 ~32 minecraft:air
setblock ~32 ~-36 ~32 minecraft:iron_block
fill ~33 ~-36 ~32 ~35 ~-36 ~32 minecraft:glass
fill ~36 ~-36 ~32 ~42 ~-36 ~32 minecraft:iron_block
setblock ~43 ~-36 ~32 minecraft:red_concrete
setblock ~44 ~-36 ~32 minecraft:polished_diorite
setblock ~45 ~-36 ~32 minecraft:smooth_quartz
setblock ~46 ~-36 ~32 minecraft:polished_andesite
fill ~47 ~-36 ~32 ~64 ~-36 ~32 minecraft:light_gray_concrete
setblock ~4 ~-36 ~33 minecraft:light_gray_concrete
fill ~5 ~-36 ~33 ~21 ~-36 ~33 minecraft:white_concrete
fill ~22 ~-36 ~33 ~23 ~-36 ~33 minecraft:smooth_quartz
setblock ~24 ~-36 ~33 minecraft:polished_diorite
setblock ~25 ~-36 ~33 minecraft:red_concrete
fill ~26 ~-36 ~33 ~31 ~-36 ~33 minecraft:air
setblock ~32 ~-36 ~33 minecraft:iron_block
setblock ~33 ~-36 ~33 minecraft:glass
setblock ~34 ~-36 ~33 minecraft:air
setblock ~35 ~-36 ~33 minecraft:glass
setblock ~36 ~-36 ~33 minecraft:iron_block
fill ~37 ~-36 ~33 ~42 ~-36 ~33 minecraft:polished_andesite
setblock ~43 ~-36 ~33 minecraft:red_concrete
setblock ~44 ~-36 ~33 minecraft:polished_diorite
fill ~45 ~-36 ~33 ~46 ~-36 ~33 minecraft:smooth_quartz
fill ~47 ~-36 ~33 ~63 ~-36 ~33 minecraft:white_concrete
setblock ~64 ~-36 ~33 minecraft:light_gray_concrete
setblock ~4 ~-36 ~34 minecraft:light_gray_concrete
fill ~5 ~-36 ~34 ~20 ~-36 ~34 minecraft:red_concrete
fill ~21 ~-36 ~34 ~22 ~-36 ~34 minecraft:smooth_quartz
setblock ~23 ~-36 ~34 minecraft:polished_diorite
setblock ~24 ~-36 ~34 minecraft:smooth_quartz
setblock ~25 ~-36 ~34 minecraft:red_concrete
fill ~26 ~-36 ~34 ~31 ~-36 ~34 minecraft:air
setblock ~32 ~-36 ~34 minecraft:iron_block
fill ~33 ~-36 ~34 ~35 ~-36 ~34 minecraft:glass
setblock ~36 ~-36 ~34 minecraft:iron_block
fill ~37 ~-36 ~34 ~42 ~-36 ~34 minecraft:polished_andesite
setblock ~43 ~-36 ~34 minecraft:red_concrete
setblock ~44 ~-36 ~34 minecraft:smooth_quartz
setblock ~45 ~-36 ~34 minecraft:polished_diorite
fill ~46 ~-36 ~34 ~47 ~-36 ~34 minecraft:smooth_quartz
fill ~48 ~-36 ~34 ~63 ~-36 ~34 minecraft:red_concrete
setblock ~64 ~-36 ~34 minecraft:light_gray_concrete
setblock ~4 ~-36 ~35 minecraft:light_gray_concrete
fill ~5 ~-36 ~35 ~21 ~-36 ~35 minecraft:white_concrete
fill ~22 ~-36 ~35 ~23 ~-36 ~35 minecraft:smooth_quartz
setblock ~24 ~-36 ~35 minecraft:polished_diorite
setblock ~25 ~-36 ~35 minecraft:red_concrete
fill ~26 ~-36 ~35 ~31 ~-36 ~35 minecraft:air
setblock ~32 ~-36 ~35 minecraft:iron_block
setblock ~33 ~-36 ~35 minecraft:glass
setblock ~34 ~-36 ~35 minecraft:air
setblock ~35 ~-36 ~35 minecraft:glass
setblock ~36 ~-36 ~35 minecraft:iron_block
fill ~37 ~-36 ~35 ~42 ~-36 ~35 minecraft:polished_andesite
setblock ~43 ~-36 ~35 minecraft:red_concrete
setblock ~44 ~-36 ~35 minecraft:polished_diorite
fill ~45 ~-36 ~35 ~46 ~-36 ~35 minecraft:smooth_quartz
fill ~47 ~-36 ~35 ~63 ~-36 ~35 minecraft:white_concrete
setblock ~64 ~-36 ~35 minecraft:light_gray_concrete
fill ~4 ~-36 ~36 ~21 ~-36 ~36 minecraft:light_gray_concrete
setblock ~22 ~-36 ~36 minecraft:polished_andesite
setblock ~23 ~-36 ~36 minecraft:smooth_quartz
setblock ~24 ~-36 ~36 minecraft:polished_diorite
setblock ~25 ~-36 ~36 minecraft:red_concrete
fill ~26 ~-36 ~36 ~31 ~-36 ~36 minecraft:air
setblock ~32 ~-36 ~36 minecraft:iron_block
fill ~33 ~-36 ~36 ~35 ~-36 ~36 minecraft:glass
fill ~36 ~-36 ~36 ~42 ~-36 ~36 minecraft:iron_block
setblock ~43 ~-36 ~36 minecraft:red_concrete
setblock ~44 ~-36 ~36 minecraft:polished_diorite
setblock ~45 ~-36 ~36 minecraft:smooth_quartz
setblock ~46 ~-36 ~36 minecraft:polished_andesite
fill ~47 ~-36 ~36 ~64 ~-36 ~36 minecraft:light_gray_concrete
setblock ~4 ~-36 ~37 minecraft:light_gray_concrete
fill ~5 ~-36 ~37 ~17 ~-36 ~37 minecraft:white_concrete
setblock ~18 ~-36 ~37 minecraft:light_gray_concrete
fill ~19 ~-36 ~37 ~21 ~-36 ~37 minecraft:white_concrete
setblock ~22 ~-36 ~37 minecraft:polished_andesite
setblock ~23 ~-36 ~37 minecraft:smooth_quartz
setblock ~24 ~-36 ~37 minecraft:polished_diorite
setblock ~25 ~-36 ~37 minecraft:smooth_quartz
setblock ~26 ~-36 ~37 minecraft:red_concrete
fill ~27 ~-36 ~37 ~31 ~-36 ~37 minecraft:air
fill ~32 ~-36 ~37 ~36 ~-36 ~37 minecraft:iron_block
fill ~37 ~-36 ~37 ~41 ~-36 ~37 minecraft:air
setblock ~42 ~-36 ~37 minecraft:red_concrete
setblock ~43 ~-36 ~37 minecraft:smooth_quartz
setblock ~44 ~-36 ~37 minecraft:polished_diorite
setblock ~45 ~-36 ~37 minecraft:smooth_quartz
setblock ~46 ~-36 ~37 minecraft:polished_andesite
fill ~47 ~-36 ~37 ~49 ~-36 ~37 minecraft:white_concrete
setblock ~50 ~-36 ~37 minecraft:light_gray_concrete
fill ~51 ~-36 ~37 ~63 ~-36 ~37 minecraft:packed_ice
setblock ~64 ~-36 ~37 minecraft:light_gray_concrete
setblock ~4 ~-36 ~38 minecraft:light_gray_concrete
fill ~5 ~-36 ~38 ~17 ~-36 ~38 minecraft:white_concrete
setblock ~18 ~-36 ~38 minecraft:light_gray_concrete
fill ~19 ~-36 ~38 ~21 ~-36 ~38 minecraft:white_concrete
setblock ~22 ~-36 ~38 minecraft:polished_andesite
setblock ~23 ~-36 ~38 minecraft:smooth_quartz
setblock ~24 ~-36 ~38 minecraft:polished_diorite
setblock ~25 ~-36 ~38 minecraft:smooth_quartz
setblock ~26 ~-36 ~38 minecraft:red_concrete
fill ~27 ~-36 ~38 ~41 ~-36 ~38 minecraft:air
setblock ~42 ~-36 ~38 minecraft:red_concrete
setblock ~43 ~-36 ~38 minecraft:smooth_quartz
setblock ~44 ~-36 ~38 minecraft:polished_diorite
setblock ~45 ~-36 ~38 minecraft:smooth_quartz
setblock ~46 ~-36 ~38 minecraft:polished_andesite
fill ~47 ~-36 ~38 ~49 ~-36 ~38 minecraft:white_concrete
setblock ~50 ~-36 ~38 minecraft:light_gray_concrete
fill ~51 ~-36 ~38 ~63 ~-36 ~38 minecraft:packed_ice
setblock ~64 ~-36 ~38 minecraft:light_gray_concrete
setblock ~4 ~-36 ~39 minecraft:light_gray_concrete
fill ~5 ~-36 ~39 ~17 ~-36 ~39 minecraft:white_concrete
setblock ~18 ~-36 ~39 minecraft:light_gray_concrete
fill ~19 ~-36 ~39 ~21 ~-36 ~39 minecraft:white_concrete
fill ~22 ~-36 ~39 ~23 ~-36 ~39 minecraft:polished_andesite
setblock ~24 ~-36 ~39 minecraft:smooth_quartz
setblock ~25 ~-36 ~39 minecraft:polished_diorite
setblock ~26 ~-36 ~39 minecraft:smooth_quartz
setblock ~27 ~-36 ~39 minecraft:red_concrete
fill ~28 ~-36 ~39 ~40 ~-36 ~39 minecraft:air
setblock ~41 ~-36 ~39 minecraft:red_concrete
setblock ~42 ~-36 ~39 minecraft:smooth_quartz
setblock ~43 ~-36 ~39 minecraft:polished_diorite
setblock ~44 ~-36 ~39 minecraft:smooth_quartz
fill ~45 ~-36 ~39 ~46 ~-36 ~39 minecraft:polished_andesite
fill ~47 ~-36 ~39 ~49 ~-36 ~39 minecraft:white_concrete
setblock ~50 ~-36 ~39 minecraft:light_gray_concrete
fill ~51 ~-36 ~39 ~63 ~-36 ~39 minecraft:packed_ice
setblock ~64 ~-36 ~39 minecraft:light_gray_concrete
setblock ~4 ~-36 ~40 minecraft:light_gray_concrete
fill ~5 ~-36 ~40 ~17 ~-36 ~40 minecraft:white_concrete
setblock ~18 ~-36 ~40 minecraft:light_gray_concrete
fill ~19 ~-36 ~40 ~22 ~-36 ~40 minecraft:white_concrete
setblock ~23 ~-36 ~40 minecraft:polished_andesite
setblock ~24 ~-36 ~40 minecraft:smooth_quartz
setblock ~25 ~-36 ~40 minecraft:polished_diorite
setblock ~26 ~-36 ~40 minecraft:smooth_quartz
setblock ~27 ~-36 ~40 minecraft:red_concrete
fill ~28 ~-36 ~40 ~40 ~-36 ~40 minecraft:air
setblock ~41 ~-36 ~40 minecraft:red_concrete
setblock ~42 ~-36 ~40 minecraft:smooth_quartz
setblock ~43 ~-36 ~40 minecraft:polished_diorite
setblock ~44 ~-36 ~40 minecraft:smooth_quartz
setblock ~45 ~-36 ~40 minecraft:polished_andesite
fill ~46 ~-36 ~40 ~49 ~-36 ~40 minecraft:white_concrete
setblock ~50 ~-36 ~40 minecraft:light_gray_concrete
fill ~51 ~-36 ~40 ~63 ~-36 ~40 minecraft:packed_ice
setblock ~64 ~-36 ~40 minecraft:light_gray_concrete
setblock ~4 ~-36 ~41 minecraft:light_gray_concrete
fill ~5 ~-36 ~41 ~17 ~-36 ~41 minecraft:white_concrete
setblock ~18 ~-36 ~41 minecraft:light_gray_concrete
fill ~19 ~-36 ~41 ~23 ~-36 ~41 minecraft:white_concrete
setblock ~24 ~-36 ~41 minecraft:polished_andesite
setblock ~25 ~-36 ~41 minecraft:smooth_quartz
setblock ~26 ~-36 ~41 minecraft:polished_diorite
setblock ~27 ~-36 ~41 minecraft:smooth_quartz
fill ~28 ~-36 ~41 ~29 ~-36 ~41 minecraft:red_concrete
fill ~30 ~-36 ~41 ~38 ~-36 ~41 minecraft:air
fill ~39 ~-36 ~41 ~40 ~-36 ~41 minecraft:red_concrete
setblock ~41 ~-36 ~41 minecraft:smooth_quartz
setblock ~42 ~-36 ~41 minecraft:polished_diorite
setblock ~43 ~-36 ~41 minecraft:smooth_quartz
setblock ~44 ~-36 ~41 minecraft:polished_andesite
fill ~45 ~-36 ~41 ~49 ~-36 ~41 minecraft:white_concrete
setblock ~50 ~-36 ~41 minecraft:light_gray_concrete
fill ~51 ~-36 ~41 ~63 ~-36 ~41 minecraft:packed_ice
setblock ~64 ~-36 ~41 minecraft:light_gray_concrete
setblock ~4 ~-36 ~42 minecraft:light_gray_concrete
fill ~5 ~-36 ~42 ~17 ~-36 ~42 minecraft:white_concrete
setblock ~18 ~-36 ~42 minecraft:light_gray_concrete
fill ~19 ~-36 ~42 ~23 ~-36 ~42 minecraft:white_concrete
fill ~24 ~-36 ~42 ~25 ~-36 ~42 minecraft:polished_andesite
setblock ~26 ~-36 ~42 minecraft:smooth_quartz
setblock ~27 ~-36 ~42 minecraft:polished_diorite
fill ~28 ~-36 ~42 ~29 ~-36 ~42 minecraft:smooth_quartz
fill ~30 ~-36 ~42 ~31 ~-36 ~42 minecraft:red_concrete
fill ~32 ~-36 ~42 ~36 ~-36 ~42 minecraft:air
fill ~37 ~-36 ~42 ~38 ~-36 ~42 minecraft:red_concrete
fill ~39 ~-36 ~42 ~40 ~-36 ~42 minecraft:smooth_quartz
setblock ~41 ~-36 ~42 minecraft:polished_diorite
setblock ~42 ~-36 ~42 minecraft:smooth_quartz
fill ~43 ~-36 ~42 ~44 ~-36 ~42 minecraft:polished_andesite
fill ~45 ~-36 ~42 ~49 ~-36 ~42 minecraft:white_concrete
setblock ~50 ~-36 ~42 minecraft:light_gray_concrete
fill ~51 ~-36 ~42 ~63 ~-36 ~42 minecraft:packed_ice
setblock ~64 ~-36 ~42 minecraft:light_gray_concrete
setblock ~4 ~-36 ~43 minecraft:light_gray_concrete
fill ~5 ~-36 ~43 ~17 ~-36 ~43 minecraft:white_concrete
setblock ~18 ~-36 ~43 minecraft:light_gray_concrete
fill ~19 ~-36 ~43 ~24 ~-36 ~43 minecraft:white_concrete
fill ~25 ~-36 ~43 ~26 ~-36 ~43 minecraft:polished_andesite
setblock ~27 ~-36 ~43 minecraft:smooth_quartz
fill ~28 ~-36 ~43 ~29 ~-36 ~43 minecraft:polished_diorite
fill ~30 ~-36 ~43 ~31 ~-36 ~43 minecraft:smooth_quartz
fill ~32 ~-36 ~43 ~36 ~-36 ~43 minecraft:red_concrete
fill ~37 ~-36 ~43 ~38 ~-36 ~43 minecraft:smooth_quartz
fill ~39 ~-36 ~43 ~40 ~-36 ~43 minecraft:polished_diorite
setblock ~41 ~-36 ~43 minecraft:smooth_quartz
fill ~42 ~-36 ~43 ~43 ~-36 ~43 minecraft:polished_andesite
fill ~44 ~-36 ~43 ~49 ~-36 ~43 minecraft:white_concrete
setblock ~50 ~-36 ~43 minecraft:light_gray_concrete
fill ~51 ~-36 ~43 ~63 ~-36 ~43 minecraft:packed_ice
setblock ~64 ~-36 ~43 minecraft:light_gray_concrete
setblock ~4 ~-36 ~44 minecraft:light_gray_concrete
fill ~5 ~-36 ~44 ~17 ~-36 ~44 minecraft:white_concrete
setblock ~18 ~-36 ~44 minecraft:light_gray_concrete
fill ~19 ~-36 ~44 ~25 ~-36 ~44 minecraft:white_concrete
fill ~26 ~-36 ~44 ~27 ~-36 ~44 minecraft:polished_andesite
fill ~28 ~-36 ~44 ~29 ~-36 ~44 minecraft:smooth_quartz
fill ~30 ~-36 ~44 ~33 ~-36 ~44 minecraft:polished_diorite
setblock ~34 ~-36 ~44 minecraft:smooth_quartz
fill ~35 ~-36 ~44 ~38 ~-36 ~44 minecraft:polished_diorite
fill ~39 ~-36 ~44 ~40 ~-36 ~44 minecraft:smooth_quartz
fill ~41 ~-36 ~44 ~42 ~-36 ~44 minecraft:polished_andesite
fill ~43 ~-36 ~44 ~49 ~-36 ~44 minecraft:white_concrete
setblock ~50 ~-36 ~44 minecraft:light_gray_concrete
fill ~51 ~-36 ~44 ~63 ~-36 ~44 minecraft:packed_ice
setblock ~64 ~-36 ~44 minecraft:light_gray_concrete
setblock ~4 ~-36 ~45 minecraft:light_gray_concrete
fill ~5 ~-36 ~45 ~17 ~-36 ~45 minecraft:white_concrete
setblock ~18 ~-36 ~45 minecraft:light_gray_concrete
fill ~19 ~-36 ~45 ~27 ~-36 ~45 minecraft:white_concrete
fill ~28 ~-36 ~45 ~29 ~-36 ~45 minecraft:polished_andesite
fill ~30 ~-36 ~45 ~33 ~-36 ~45 minecraft:smooth_quartz
setblock ~34 ~-36 ~45 minecraft:polished_diorite
fill ~35 ~-36 ~45 ~38 ~-36 ~45 minecraft:smooth_quartz
fill ~39 ~-36 ~45 ~40 ~-36 ~45 minecraft:polished_andesite
fill ~41 ~-36 ~45 ~49 ~-36 ~45 minecraft:white_concrete
setblock ~50 ~-36 ~45 minecraft:light_gray_concrete
fill ~51 ~-36 ~45 ~63 ~-36 ~45 minecraft:packed_ice
setblock ~64 ~-36 ~45 minecraft:light_gray_concrete
setblock ~4 ~-36 ~46 minecraft:light_gray_concrete
fill ~5 ~-36 ~46 ~17 ~-36 ~46 minecraft:white_concrete
setblock ~18 ~-36 ~46 minecraft:light_gray_concrete
fill ~19 ~-36 ~46 ~21 ~-36 ~46 minecraft:white_concrete
setblock ~22 ~-36 ~46 minecraft:soul_sand
fill ~23 ~-36 ~46 ~28 ~-36 ~46 minecraft:white_concrete
fill ~29 ~-36 ~46 ~32 ~-36 ~46 minecraft:polished_andesite
fill ~33 ~-36 ~46 ~35 ~-36 ~46 minecraft:smooth_quartz
fill ~36 ~-36 ~46 ~39 ~-36 ~46 minecraft:polished_andesite
fill ~40 ~-36 ~46 ~49 ~-36 ~46 minecraft:white_concrete
setblock ~50 ~-36 ~46 minecraft:light_gray_concrete
fill ~51 ~-36 ~46 ~63 ~-36 ~46 minecraft:packed_ice
setblock ~64 ~-36 ~46 minecraft:light_gray_concrete
setblock ~4 ~-36 ~47 minecraft:light_gray_concrete
fill ~5 ~-36 ~47 ~17 ~-36 ~47 minecraft:white_concrete
setblock ~18 ~-36 ~47 minecraft:light_gray_concrete
fill ~19 ~-36 ~47 ~31 ~-36 ~47 minecraft:white_concrete
setblock ~32 ~-36 ~47 minecraft:light_gray_concrete
setblock ~33 ~-36 ~47 minecraft:white_concrete
setblock ~34 ~-36 ~47 minecraft:smooth_quartz
setblock ~35 ~-36 ~47 minecraft:white_concrete
setblock ~36 ~-36 ~47 minecraft:light_gray_concrete
setblock ~37 ~-36 ~47 minecraft:white_concrete
fill ~38 ~-36 ~47 ~39 ~-36 ~47 minecraft:polished_andesite
fill ~40 ~-36 ~47 ~41 ~-36 ~47 minecraft:white_concrete
fill ~42 ~-36 ~47 ~44 ~-36 ~47 minecraft:polished_andesite
setblock ~45 ~-36 ~47 minecraft:white_concrete
fill ~46 ~-36 ~47 ~48 ~-36 ~47 minecraft:polished_andesite
setblock ~49 ~-36 ~47 minecraft:white_concrete
setblock ~50 ~-36 ~47 minecraft:light_gray_concrete
fill ~51 ~-36 ~47 ~63 ~-36 ~47 minecraft:packed_ice
setblock ~64 ~-36 ~47 minecraft:light_gray_concrete
setblock ~4 ~-36 ~48 minecraft:light_gray_concrete
fill ~5 ~-36 ~48 ~17 ~-36 ~48 minecraft:white_concrete
setblock ~18 ~-36 ~48 minecraft:light_gray_concrete
fill ~19 ~-36 ~48 ~31 ~-36 ~48 minecraft:white_concrete
setblock ~32 ~-36 ~48 minecraft:light_gray_concrete
setblock ~33 ~-36 ~48 minecraft:white_concrete
setblock ~34 ~-36 ~48 minecraft:red_concrete
setblock ~35 ~-36 ~48 minecraft:white_concrete
setblock ~36 ~-36 ~48 minecraft:light_gray_concrete
fill ~37 ~-36 ~48 ~38 ~-36 ~48 minecraft:white_concrete
fill ~39 ~-36 ~48 ~40 ~-36 ~48 minecraft:polished_andesite
setblock ~41 ~-36 ~48 minecraft:white_concrete
fill ~42 ~-36 ~48 ~44 ~-36 ~48 minecraft:polished_andesite
setblock ~45 ~-36 ~48 minecraft:white_concrete
fill ~46 ~-36 ~48 ~48 ~-36 ~48 minecraft:polished_andesite
setblock ~49 ~-36 ~48 minecraft:white_concrete
setblock ~50 ~-36 ~48 minecraft:light_gray_concrete
fill ~51 ~-36 ~48 ~63 ~-36 ~48 minecraft:packed_ice
setblock ~64 ~-36 ~48 minecraft:light_gray_concrete
setblock ~4 ~-36 ~49 minecraft:light_gray_concrete
fill ~5 ~-36 ~49 ~17 ~-36 ~49 minecraft:white_concrete
setblock ~18 ~-36 ~49 minecraft:light_gray_concrete
fill ~19 ~-36 ~49 ~31 ~-36 ~49 minecraft:white_concrete
setblock ~32 ~-36 ~49 minecraft:light_gray_concrete
setblock ~33 ~-36 ~49 minecraft:white_concrete
setblock ~34 ~-36 ~49 minecraft:red_concrete
setblock ~35 ~-36 ~49 minecraft:white_concrete
setblock ~36 ~-36 ~49 minecraft:light_gray_concrete
setblock ~37 ~-36 ~49 minecraft:white_concrete
fill ~38 ~-36 ~49 ~40 ~-36 ~49 minecraft:polished_andesite
setblock ~41 ~-36 ~49 minecraft:white_concrete
fill ~42 ~-36 ~49 ~44 ~-36 ~49 minecraft:polished_andesite
setblock ~45 ~-36 ~49 minecraft:white_concrete
fill ~46 ~-36 ~49 ~48 ~-36 ~49 minecraft:polished_andesite
setblock ~49 ~-36 ~49 minecraft:white_concrete
setblock ~50 ~-36 ~49 minecraft:light_gray_concrete
fill ~51 ~-36 ~49 ~63 ~-36 ~49 minecraft:packed_ice
setblock ~64 ~-36 ~49 minecraft:light_gray_concrete
fill ~4 ~-36 ~50 ~32 ~-36 ~50 minecraft:light_gray_concrete
setblock ~33 ~-36 ~50 minecraft:white_concrete
setblock ~34 ~-36 ~50 minecraft:red_concrete
setblock ~35 ~-36 ~50 minecraft:white_concrete
fill ~36 ~-36 ~50 ~64 ~-36 ~50 minecraft:light_gray_concrete
setblock ~4 ~-36 ~51 minecraft:light_gray_concrete
fill ~5 ~-36 ~51 ~17 ~-36 ~51 minecraft:white_concrete
setblock ~18 ~-36 ~51 minecraft:light_gray_concrete
fill ~19 ~-36 ~51 ~31 ~-36 ~51 minecraft:white_concrete
setblock ~32 ~-36 ~51 minecraft:light_gray_concrete
setblock ~33 ~-36 ~51 minecraft:white_concrete
setblock ~34 ~-36 ~51 minecraft:red_concrete
setblock ~35 ~-36 ~51 minecraft:white_concrete
setblock ~36 ~-36 ~51 minecraft:light_gray_concrete
fill ~37 ~-36 ~51 ~49 ~-36 ~51 minecraft:white_concrete
setblock ~50 ~-36 ~51 minecraft:light_gray_concrete
fill ~51 ~-36 ~51 ~63 ~-36 ~51 minecraft:white_concrete
setblock ~64 ~-36 ~51 minecraft:light_gray_concrete
setblock ~4 ~-36 ~52 minecraft:light_gray_concrete
fill ~5 ~-36 ~52 ~17 ~-36 ~52 minecraft:white_concrete
setblock ~18 ~-36 ~52 minecraft:light_gray_concrete
fill ~19 ~-36 ~52 ~31 ~-36 ~52 minecraft:white_concrete
setblock ~32 ~-36 ~52 minecraft:light_gray_concrete
setblock ~33 ~-36 ~52 minecraft:white_concrete
setblock ~34 ~-36 ~52 minecraft:red_concrete
setblock ~35 ~-36 ~52 minecraft:white_concrete
setblock ~36 ~-36 ~52 minecraft:light_gray_concrete
fill ~37 ~-36 ~52 ~49 ~-36 ~52 minecraft:white_concrete
setblock ~50 ~-36 ~52 minecraft:light_gray_concrete
fill ~51 ~-36 ~52 ~63 ~-36 ~52 minecraft:white_concrete
setblock ~64 ~-36 ~52 minecraft:light_gray_concrete
setblock ~4 ~-36 ~53 minecraft:light_gray_concrete
fill ~5 ~-36 ~53 ~17 ~-36 ~53 minecraft:white_concrete
setblock ~18 ~-36 ~53 minecraft:light_gray_concrete
fill ~19 ~-36 ~53 ~31 ~-36 ~53 minecraft:white_concrete
setblock ~32 ~-36 ~53 minecraft:light_gray_concrete
setblock ~33 ~-36 ~53 minecraft:white_concrete
setblock ~34 ~-36 ~53 minecraft:red_concrete
setblock ~35 ~-36 ~53 minecraft:white_concrete
setblock ~36 ~-36 ~53 minecraft:light_gray_concrete
fill ~37 ~-36 ~53 ~49 ~-36 ~53 minecraft:white_concrete
setblock ~50 ~-36 ~53 minecraft:light_gray_concrete
fill ~51 ~-36 ~53 ~63 ~-36 ~53 minecraft:white_concrete
setblock ~64 ~-36 ~53 minecraft:light_gray_concrete
setblock ~4 ~-36 ~54 minecraft:light_gray_concrete
fill ~5 ~-36 ~54 ~17 ~-36 ~54 minecraft:white_concrete
setblock ~18 ~-36 ~54 minecraft:light_gray_concrete
fill ~19 ~-36 ~54 ~31 ~-36 ~54 minecraft:white_concrete
setblock ~32 ~-36 ~54 minecraft:light_gray_concrete
setblock ~33 ~-36 ~54 minecraft:white_concrete
setblock ~34 ~-36 ~54 minecraft:red_concrete
setblock ~35 ~-36 ~54 minecraft:white_concrete
setblock ~36 ~-36 ~54 minecraft:light_gray_concrete
fill ~37 ~-36 ~54 ~38 ~-36 ~54 minecraft:white_concrete
setblock ~39 ~-36 ~54 minecraft:campfire[lit=true]
fill ~40 ~-36 ~54 ~41 ~-36 ~54 minecraft:white_concrete
setblock ~42 ~-36 ~54 minecraft:campfire[lit=true]
fill ~43 ~-36 ~54 ~44 ~-36 ~54 minecraft:white_concrete
setblock ~45 ~-36 ~54 minecraft:campfire[lit=true]
fill ~46 ~-36 ~54 ~47 ~-36 ~54 minecraft:white_concrete
setblock ~48 ~-36 ~54 minecraft:campfire[lit=true]
setblock ~49 ~-36 ~54 minecraft:white_concrete
setblock ~50 ~-36 ~54 minecraft:light_gray_concrete
fill ~51 ~-36 ~54 ~63 ~-36 ~54 minecraft:white_concrete
setblock ~64 ~-36 ~54 minecraft:light_gray_concrete
setblock ~4 ~-36 ~55 minecraft:light_gray_concrete
fill ~5 ~-36 ~55 ~17 ~-36 ~55 minecraft:white_concrete
setblock ~18 ~-36 ~55 minecraft:light_gray_concrete
fill ~19 ~-36 ~55 ~31 ~-36 ~55 minecraft:white_concrete
setblock ~32 ~-36 ~55 minecraft:light_gray_concrete
setblock ~33 ~-36 ~55 minecraft:white_concrete
setblock ~34 ~-36 ~55 minecraft:red_concrete
setblock ~35 ~-36 ~55 minecraft:white_concrete
setblock ~36 ~-36 ~55 minecraft:light_gray_concrete
fill ~37 ~-36 ~55 ~49 ~-36 ~55 minecraft:white_concrete
setblock ~50 ~-36 ~55 minecraft:light_gray_concrete
fill ~51 ~-36 ~55 ~63 ~-36 ~55 minecraft:white_concrete
setblock ~64 ~-36 ~55 minecraft:light_gray_concrete
setblock ~4 ~-36 ~56 minecraft:light_gray_concrete
fill ~5 ~-36 ~56 ~17 ~-36 ~56 minecraft:white_concrete
setblock ~18 ~-36 ~56 minecraft:light_gray_concrete
fill ~19 ~-36 ~56 ~31 ~-36 ~56 minecraft:white_concrete
setblock ~32 ~-36 ~56 minecraft:light_gray_concrete
setblock ~33 ~-36 ~56 minecraft:white_concrete
setblock ~34 ~-36 ~56 minecraft:red_concrete
setblock ~35 ~-36 ~56 minecraft:white_concrete
setblock ~36 ~-36 ~56 minecraft:light_gray_concrete
fill ~37 ~-36 ~56 ~49 ~-36 ~56 minecraft:white_concrete
setblock ~50 ~-36 ~56 minecraft:light_gray_concrete
fill ~51 ~-36 ~56 ~63 ~-36 ~56 minecraft:white_concrete
setblock ~64 ~-36 ~56 minecraft:light_gray_concrete
setblock ~4 ~-36 ~57 minecraft:light_gray_concrete
fill ~5 ~-36 ~57 ~17 ~-36 ~57 minecraft:white_concrete
setblock ~18 ~-36 ~57 minecraft:light_gray_concrete
fill ~19 ~-36 ~57 ~31 ~-36 ~57 minecraft:white_concrete
setblock ~32 ~-36 ~57 minecraft:light_gray_concrete
setblock ~33 ~-36 ~57 minecraft:white_concrete
setblock ~34 ~-36 ~57 minecraft:red_concrete
setblock ~35 ~-36 ~57 minecraft:white_concrete
setblock ~36 ~-36 ~57 minecraft:light_gray_concrete
fill ~37 ~-36 ~57 ~38 ~-36 ~57 minecraft:white_concrete
setblock ~39 ~-36 ~57 minecraft:campfire[lit=true]
fill ~40 ~-36 ~57 ~41 ~-36 ~57 minecraft:white_concrete
setblock ~42 ~-36 ~57 minecraft:campfire[lit=true]
fill ~43 ~-36 ~57 ~44 ~-36 ~57 minecraft:white_concrete
setblock ~45 ~-36 ~57 minecraft:campfire[lit=true]
fill ~46 ~-36 ~57 ~49 ~-36 ~57 minecraft:white_concrete
setblock ~50 ~-36 ~57 minecraft:light_gray_concrete
fill ~51 ~-36 ~57 ~63 ~-36 ~57 minecraft:white_concrete
setblock ~64 ~-36 ~57 minecraft:light_gray_concrete
setblock ~4 ~-36 ~58 minecraft:light_gray_concrete
fill ~5 ~-36 ~58 ~17 ~-36 ~58 minecraft:white_concrete
setblock ~18 ~-36 ~58 minecraft:light_gray_concrete
fill ~19 ~-36 ~58 ~31 ~-36 ~58 minecraft:white_concrete
setblock ~32 ~-36 ~58 minecraft:light_gray_concrete
setblock ~33 ~-36 ~58 minecraft:white_concrete
setblock ~34 ~-36 ~58 minecraft:red_concrete
setblock ~35 ~-36 ~58 minecraft:white_concrete
setblock ~36 ~-36 ~58 minecraft:light_gray_concrete
fill ~37 ~-36 ~58 ~49 ~-36 ~58 minecraft:white_concrete
setblock ~50 ~-36 ~58 minecraft:light_gray_concrete
fill ~51 ~-36 ~58 ~63 ~-36 ~58 minecraft:white_concrete
setblock ~64 ~-36 ~58 minecraft:light_gray_concrete
setblock ~4 ~-36 ~59 minecraft:light_gray_concrete
fill ~5 ~-36 ~59 ~17 ~-36 ~59 minecraft:white_concrete
setblock ~18 ~-36 ~59 minecraft:light_gray_concrete
fill ~19 ~-36 ~59 ~31 ~-36 ~59 minecraft:white_concrete
setblock ~32 ~-36 ~59 minecraft:light_gray_concrete
setblock ~33 ~-36 ~59 minecraft:white_concrete
setblock ~34 ~-36 ~59 minecraft:red_concrete
setblock ~35 ~-36 ~59 minecraft:white_concrete
setblock ~36 ~-36 ~59 minecraft:light_gray_concrete
fill ~37 ~-36 ~59 ~49 ~-36 ~59 minecraft:white_concrete
setblock ~50 ~-36 ~59 minecraft:light_gray_concrete
fill ~51 ~-36 ~59 ~63 ~-36 ~59 minecraft:white_concrete
setblock ~64 ~-36 ~59 minecraft:light_gray_concrete
setblock ~4 ~-36 ~60 minecraft:light_gray_concrete
fill ~5 ~-36 ~60 ~17 ~-36 ~60 minecraft:white_concrete
setblock ~18 ~-36 ~60 minecraft:light_gray_concrete
fill ~19 ~-36 ~60 ~31 ~-36 ~60 minecraft:white_concrete
setblock ~32 ~-36 ~60 minecraft:light_gray_concrete
setblock ~33 ~-36 ~60 minecraft:white_concrete
setblock ~34 ~-36 ~60 minecraft:red_concrete
setblock ~35 ~-36 ~60 minecraft:white_concrete
setblock ~36 ~-36 ~60 minecraft:light_gray_concrete
fill ~37 ~-36 ~60 ~38 ~-36 ~60 minecraft:white_concrete
setblock ~39 ~-36 ~60 minecraft:campfire[lit=true]
fill ~40 ~-36 ~60 ~41 ~-36 ~60 minecraft:white_concrete
setblock ~42 ~-36 ~60 minecraft:campfire[lit=true]
fill ~43 ~-36 ~60 ~44 ~-36 ~60 minecraft:white_concrete
setblock ~45 ~-36 ~60 minecraft:campfire[lit=true]
fill ~46 ~-36 ~60 ~47 ~-36 ~60 minecraft:white_concrete
setblock ~48 ~-36 ~60 minecraft:campfire[lit=true]
setblock ~49 ~-36 ~60 minecraft:white_concrete
setblock ~50 ~-36 ~60 minecraft:light_gray_concrete
fill ~51 ~-36 ~60 ~63 ~-36 ~60 minecraft:white_concrete
setblock ~64 ~-36 ~60 minecraft:light_gray_concrete
setblock ~4 ~-36 ~61 minecraft:light_gray_concrete
fill ~5 ~-36 ~61 ~17 ~-36 ~61 minecraft:white_concrete
setblock ~18 ~-36 ~61 minecraft:light_gray_concrete
fill ~19 ~-36 ~61 ~31 ~-36 ~61 minecraft:white_concrete
setblock ~32 ~-36 ~61 minecraft:light_gray_concrete
setblock ~33 ~-36 ~61 minecraft:white_concrete
setblock ~34 ~-36 ~61 minecraft:red_concrete
setblock ~35 ~-36 ~61 minecraft:white_concrete
setblock ~36 ~-36 ~61 minecraft:light_gray_concrete
fill ~37 ~-36 ~61 ~49 ~-36 ~61 minecraft:white_concrete
setblock ~50 ~-36 ~61 minecraft:light_gray_concrete
fill ~51 ~-36 ~61 ~63 ~-36 ~61 minecraft:white_concrete
setblock ~64 ~-36 ~61 minecraft:light_gray_concrete
setblock ~4 ~-36 ~62 minecraft:light_gray_concrete
fill ~5 ~-36 ~62 ~17 ~-36 ~62 minecraft:white_concrete
setblock ~18 ~-36 ~62 minecraft:light_gray_concrete
fill ~19 ~-36 ~62 ~31 ~-36 ~62 minecraft:white_concrete
setblock ~32 ~-36 ~62 minecraft:light_gray_concrete
setblock ~33 ~-36 ~62 minecraft:white_concrete
setblock ~34 ~-36 ~62 minecraft:red_concrete
setblock ~35 ~-36 ~62 minecraft:white_concrete
setblock ~36 ~-36 ~62 minecraft:light_gray_concrete
fill ~37 ~-36 ~62 ~49 ~-36 ~62 minecraft:white_concrete
setblock ~50 ~-36 ~62 minecraft:light_gray_concrete
fill ~51 ~-36 ~62 ~63 ~-36 ~62 minecraft:white_concrete
setblock ~64 ~-36 ~62 minecraft:light_gray_concrete
setblock ~4 ~-36 ~63 minecraft:light_gray_concrete
fill ~5 ~-36 ~63 ~17 ~-36 ~63 minecraft:white_concrete
setblock ~18 ~-36 ~63 minecraft:light_gray_concrete
fill ~19 ~-36 ~63 ~31 ~-36 ~63 minecraft:white_concrete
setblock ~32 ~-36 ~63 minecraft:light_gray_concrete
setblock ~33 ~-36 ~63 minecraft:white_concrete
setblock ~34 ~-36 ~63 minecraft:red_concrete
setblock ~35 ~-36 ~63 minecraft:white_concrete
setblock ~36 ~-36 ~63 minecraft:light_gray_concrete
fill ~37 ~-36 ~63 ~49 ~-36 ~63 minecraft:white_concrete
setblock ~50 ~-36 ~63 minecraft:light_gray_concrete
fill ~51 ~-36 ~63 ~63 ~-36 ~63 minecraft:white_concrete
setblock ~64 ~-36 ~63 minecraft:light_gray_concrete
fill ~4 ~-36 ~64 ~64 ~-36 ~64 minecraft:light_gray_concrete
setblock ~34 ~-36 ~65 minecraft:white_concrete
fill ~32 ~-36 ~66 ~36 ~-36 ~66 minecraft:polished_andesite
setblock ~32 ~-36 ~67 minecraft:polished_andesite
setblock ~33 ~-36 ~67 minecraft:air
setblock ~34 ~-36 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-36 ~67 minecraft:air
setblock ~36 ~-36 ~67 minecraft:polished_andesite
setblock ~32 ~-36 ~68 minecraft:polished_andesite
setblock ~33 ~-36 ~68 minecraft:air
setblock ~34 ~-36 ~68 minecraft:quartz_pillar
setblock ~35 ~-36 ~68 minecraft:air
setblock ~36 ~-36 ~68 minecraft:polished_andesite
setblock ~32 ~-36 ~69 minecraft:polished_andesite
fill ~33 ~-36 ~69 ~35 ~-36 ~69 minecraft:air
setblock ~36 ~-36 ~69 minecraft:polished_andesite
fill ~32 ~-36 ~70 ~36 ~-36 ~70 minecraft:polished_andesite
fill ~4 ~-35 ~4 ~64 ~-35 ~4 minecraft:light_gray_concrete
setblock ~4 ~-35 ~5 minecraft:light_gray_concrete
setblock ~5 ~-35 ~5 minecraft:barrel
setblock ~6 ~-35 ~5 minecraft:air
setblock ~7 ~-35 ~5 minecraft:barrel
setblock ~8 ~-35 ~5 minecraft:air
setblock ~9 ~-35 ~5 minecraft:barrel
setblock ~10 ~-35 ~5 minecraft:air
setblock ~11 ~-35 ~5 minecraft:barrel
setblock ~12 ~-35 ~5 minecraft:air
setblock ~13 ~-35 ~5 minecraft:barrel
setblock ~14 ~-35 ~5 minecraft:air
setblock ~15 ~-35 ~5 minecraft:barrel
setblock ~16 ~-35 ~5 minecraft:air
setblock ~17 ~-35 ~5 minecraft:barrel
setblock ~18 ~-35 ~5 minecraft:light_gray_concrete
setblock ~19 ~-35 ~5 minecraft:air
setblock ~20 ~-35 ~5 minecraft:cauldron
fill ~21 ~-35 ~5 ~23 ~-35 ~5 minecraft:air
setblock ~24 ~-35 ~5 minecraft:cauldron
fill ~25 ~-35 ~5 ~27 ~-35 ~5 minecraft:air
setblock ~28 ~-35 ~5 minecraft:cauldron
fill ~29 ~-35 ~5 ~31 ~-35 ~5 minecraft:air
setblock ~32 ~-35 ~5 minecraft:light_gray_concrete
fill ~33 ~-35 ~5 ~35 ~-35 ~5 minecraft:air
setblock ~36 ~-35 ~5 minecraft:light_gray_concrete
setblock ~37 ~-35 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~38 ~-35 ~5 minecraft:cauldron
fill ~39 ~-35 ~5 ~40 ~-35 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~41 ~-35 ~5 minecraft:cauldron
fill ~42 ~-35 ~5 ~43 ~-35 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~44 ~-35 ~5 minecraft:cauldron
fill ~45 ~-35 ~5 ~46 ~-35 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~47 ~-35 ~5 minecraft:cauldron
fill ~48 ~-35 ~5 ~49 ~-35 ~5 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-35 ~5 minecraft:light_gray_concrete
setblock ~51 ~-35 ~5 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-35 ~5 ~54 ~-35 ~5 minecraft:air
setblock ~55 ~-35 ~5 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-35 ~5 ~58 ~-35 ~5 minecraft:air
setblock ~59 ~-35 ~5 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-35 ~5 ~62 ~-35 ~5 minecraft:air
setblock ~63 ~-35 ~5 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-35 ~5 minecraft:light_gray_concrete
setblock ~4 ~-35 ~6 minecraft:light_gray_concrete
fill ~5 ~-35 ~6 ~17 ~-35 ~6 minecraft:air
setblock ~18 ~-35 ~6 minecraft:light_gray_concrete
fill ~19 ~-35 ~6 ~31 ~-35 ~6 minecraft:air
setblock ~32 ~-35 ~6 minecraft:light_gray_concrete
fill ~33 ~-35 ~6 ~35 ~-35 ~6 minecraft:air
setblock ~36 ~-35 ~6 minecraft:light_gray_concrete
setblock ~37 ~-35 ~6 minecraft:cauldron
fill ~38 ~-35 ~6 ~48 ~-35 ~6 minecraft:air
setblock ~49 ~-35 ~6 minecraft:cauldron
setblock ~50 ~-35 ~6 minecraft:light_gray_concrete
setblock ~51 ~-35 ~6 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-35 ~6 ~54 ~-35 ~6 minecraft:air
setblock ~55 ~-35 ~6 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-35 ~6 ~58 ~-35 ~6 minecraft:air
setblock ~59 ~-35 ~6 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-35 ~6 ~62 ~-35 ~6 minecraft:air
setblock ~63 ~-35 ~6 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-35 ~6 minecraft:light_gray_concrete
setblock ~4 ~-35 ~7 minecraft:light_gray_concrete
setblock ~5 ~-35 ~7 minecraft:barrel
fill ~6 ~-35 ~7 ~16 ~-35 ~7 minecraft:air
setblock ~17 ~-35 ~7 minecraft:barrel
setblock ~18 ~-35 ~7 minecraft:light_gray_concrete
fill ~19 ~-35 ~7 ~31 ~-35 ~7 minecraft:air
setblock ~32 ~-35 ~7 minecraft:light_gray_concrete
fill ~33 ~-35 ~7 ~35 ~-35 ~7 minecraft:air
setblock ~36 ~-35 ~7 minecraft:light_gray_concrete
setblock ~37 ~-35 ~7 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-35 ~7 ~48 ~-35 ~7 minecraft:air
setblock ~49 ~-35 ~7 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-35 ~7 minecraft:light_gray_concrete
setblock ~51 ~-35 ~7 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-35 ~7 ~54 ~-35 ~7 minecraft:air
setblock ~55 ~-35 ~7 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-35 ~7 ~58 ~-35 ~7 minecraft:air
setblock ~59 ~-35 ~7 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-35 ~7 ~62 ~-35 ~7 minecraft:air
setblock ~63 ~-35 ~7 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-35 ~7 minecraft:light_gray_concrete
setblock ~4 ~-35 ~8 minecraft:light_gray_concrete
fill ~5 ~-35 ~8 ~17 ~-35 ~8 minecraft:air
setblock ~18 ~-35 ~8 minecraft:light_gray_concrete
fill ~19 ~-35 ~8 ~31 ~-35 ~8 minecraft:air
setblock ~32 ~-35 ~8 minecraft:light_gray_concrete
fill ~33 ~-35 ~8 ~35 ~-35 ~8 minecraft:air
setblock ~36 ~-35 ~8 minecraft:light_gray_concrete
setblock ~37 ~-35 ~8 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-35 ~8 ~48 ~-35 ~8 minecraft:air
setblock ~49 ~-35 ~8 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-35 ~8 minecraft:light_gray_concrete
setblock ~51 ~-35 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~52 ~-35 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~53 ~-35 ~8 minecraft:air
setblock ~54 ~-35 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~55 ~-35 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~56 ~-35 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~57 ~-35 ~8 minecraft:air
setblock ~58 ~-35 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~59 ~-35 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~60 ~-35 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~61 ~-35 ~8 minecraft:air
setblock ~62 ~-35 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~63 ~-35 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~64 ~-35 ~8 minecraft:light_gray_concrete
setblock ~4 ~-35 ~9 minecraft:light_gray_concrete
setblock ~5 ~-35 ~9 minecraft:barrel
fill ~6 ~-35 ~9 ~10 ~-35 ~9 minecraft:air
setblock ~11 ~-35 ~9 minecraft:cauldron
fill ~12 ~-35 ~9 ~16 ~-35 ~9 minecraft:air
setblock ~17 ~-35 ~9 minecraft:barrel
setblock ~18 ~-35 ~9 minecraft:light_gray_concrete
fill ~19 ~-35 ~9 ~31 ~-35 ~9 minecraft:air
setblock ~32 ~-35 ~9 minecraft:light_gray_concrete
fill ~33 ~-35 ~9 ~35 ~-35 ~9 minecraft:air
setblock ~36 ~-35 ~9 minecraft:light_gray_concrete
setblock ~37 ~-35 ~9 minecraft:cauldron
fill ~38 ~-35 ~9 ~39 ~-35 ~9 minecraft:air
fill ~40 ~-35 ~9 ~46 ~-35 ~9 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-35 ~9 ~48 ~-35 ~9 minecraft:air
setblock ~49 ~-35 ~9 minecraft:cauldron
setblock ~50 ~-35 ~9 minecraft:light_gray_concrete
fill ~51 ~-35 ~9 ~63 ~-35 ~9 minecraft:air
setblock ~64 ~-35 ~9 minecraft:light_gray_concrete
setblock ~4 ~-35 ~10 minecraft:light_gray_concrete
fill ~5 ~-35 ~10 ~17 ~-35 ~10 minecraft:air
setblock ~18 ~-35 ~10 minecraft:light_gray_concrete
fill ~19 ~-35 ~10 ~31 ~-35 ~10 minecraft:air
setblock ~32 ~-35 ~10 minecraft:light_gray_concrete
fill ~33 ~-35 ~10 ~35 ~-35 ~10 minecraft:air
setblock ~36 ~-35 ~10 minecraft:light_gray_concrete
fill ~37 ~-35 ~10 ~49 ~-35 ~10 minecraft:air
setblock ~50 ~-35 ~10 minecraft:light_gray_concrete
fill ~51 ~-35 ~10 ~63 ~-35 ~10 minecraft:air
setblock ~64 ~-35 ~10 minecraft:light_gray_concrete
setblock ~4 ~-35 ~11 minecraft:light_gray_concrete
setblock ~5 ~-35 ~11 minecraft:barrel
fill ~6 ~-35 ~11 ~8 ~-35 ~11 minecraft:air
setblock ~9 ~-35 ~11 minecraft:smooth_stone_slab[type=top]
setblock ~10 ~-35 ~11 minecraft:air
setblock ~11 ~-35 ~11 minecraft:smooth_stone_slab[type=top]
setblock ~12 ~-35 ~11 minecraft:air
setblock ~13 ~-35 ~11 minecraft:smooth_stone_slab[type=top]
fill ~14 ~-35 ~11 ~22 ~-35 ~11 minecraft:air
fill ~23 ~-35 ~11 ~27 ~-35 ~11 minecraft:smooth_stone_slab[type=top]
fill ~28 ~-35 ~11 ~63 ~-35 ~11 minecraft:air
setblock ~64 ~-35 ~11 minecraft:light_gray_concrete
setblock ~4 ~-35 ~12 minecraft:light_gray_concrete
fill ~5 ~-35 ~12 ~8 ~-35 ~12 minecraft:air
setblock ~9 ~-35 ~12 minecraft:smooth_stone_slab[type=top]
setblock ~10 ~-35 ~12 minecraft:air
setblock ~11 ~-35 ~12 minecraft:smooth_stone_slab[type=top]
setblock ~12 ~-35 ~12 minecraft:air
setblock ~13 ~-35 ~12 minecraft:smooth_stone_slab[type=top]
fill ~14 ~-35 ~12 ~17 ~-35 ~12 minecraft:air
setblock ~18 ~-35 ~12 minecraft:light_gray_concrete
fill ~19 ~-35 ~12 ~31 ~-35 ~12 minecraft:air
setblock ~32 ~-35 ~12 minecraft:light_gray_concrete
fill ~33 ~-35 ~12 ~35 ~-35 ~12 minecraft:air
setblock ~36 ~-35 ~12 minecraft:light_gray_concrete
fill ~37 ~-35 ~12 ~49 ~-35 ~12 minecraft:air
setblock ~50 ~-35 ~12 minecraft:light_gray_concrete
fill ~51 ~-35 ~12 ~56 ~-35 ~12 minecraft:air
setblock ~57 ~-35 ~12 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-35 ~12 ~63 ~-35 ~12 minecraft:air
setblock ~64 ~-35 ~12 minecraft:light_gray_concrete
setblock ~4 ~-35 ~13 minecraft:light_gray_concrete
setblock ~5 ~-35 ~13 minecraft:barrel
fill ~6 ~-35 ~13 ~16 ~-35 ~13 minecraft:air
setblock ~17 ~-35 ~13 minecraft:barrel
setblock ~18 ~-35 ~13 minecraft:light_gray_concrete
fill ~19 ~-35 ~13 ~31 ~-35 ~13 minecraft:air
setblock ~32 ~-35 ~13 minecraft:light_gray_concrete
fill ~33 ~-35 ~13 ~35 ~-35 ~13 minecraft:air
setblock ~36 ~-35 ~13 minecraft:light_gray_concrete
setblock ~37 ~-35 ~13 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-35 ~13 ~39 ~-35 ~13 minecraft:air
fill ~40 ~-35 ~13 ~46 ~-35 ~13 minecraft:smooth_stone_slab[type=top]
fill ~47 ~-35 ~13 ~48 ~-35 ~13 minecraft:air
setblock ~49 ~-35 ~13 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-35 ~13 minecraft:light_gray_concrete
fill ~51 ~-35 ~13 ~63 ~-35 ~13 minecraft:air
setblock ~64 ~-35 ~13 minecraft:light_gray_concrete
setblock ~4 ~-35 ~14 minecraft:light_gray_concrete
fill ~5 ~-35 ~14 ~10 ~-35 ~14 minecraft:air
setblock ~11 ~-35 ~14 minecraft:cauldron
fill ~12 ~-35 ~14 ~17 ~-35 ~14 minecraft:air
setblock ~18 ~-35 ~14 minecraft:light_gray_concrete
setblock ~19 ~-35 ~14 minecraft:cauldron
fill ~20 ~-35 ~14 ~30 ~-35 ~14 minecraft:air
setblock ~31 ~-35 ~14 minecraft:cauldron
setblock ~32 ~-35 ~14 minecraft:light_gray_concrete
fill ~33 ~-35 ~14 ~35 ~-35 ~14 minecraft:air
setblock ~36 ~-35 ~14 minecraft:light_gray_concrete
setblock ~37 ~-35 ~14 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-35 ~14 ~48 ~-35 ~14 minecraft:air
setblock ~49 ~-35 ~14 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-35 ~14 minecraft:light_gray_concrete
fill ~51 ~-35 ~14 ~63 ~-35 ~14 minecraft:air
setblock ~64 ~-35 ~14 minecraft:light_gray_concrete
setblock ~4 ~-35 ~15 minecraft:light_gray_concrete
setblock ~5 ~-35 ~15 minecraft:barrel
fill ~6 ~-35 ~15 ~16 ~-35 ~15 minecraft:air
setblock ~17 ~-35 ~15 minecraft:barrel
setblock ~18 ~-35 ~15 minecraft:light_gray_concrete
fill ~19 ~-35 ~15 ~31 ~-35 ~15 minecraft:air
setblock ~32 ~-35 ~15 minecraft:light_gray_concrete
fill ~33 ~-35 ~15 ~35 ~-35 ~15 minecraft:air
setblock ~36 ~-35 ~15 minecraft:light_gray_concrete
setblock ~37 ~-35 ~15 minecraft:cauldron
fill ~38 ~-35 ~15 ~48 ~-35 ~15 minecraft:air
setblock ~49 ~-35 ~15 minecraft:cauldron
setblock ~50 ~-35 ~15 minecraft:light_gray_concrete
fill ~51 ~-35 ~15 ~63 ~-35 ~15 minecraft:air
setblock ~64 ~-35 ~15 minecraft:light_gray_concrete
setblock ~4 ~-35 ~16 minecraft:light_gray_concrete
fill ~5 ~-35 ~16 ~17 ~-35 ~16 minecraft:air
setblock ~18 ~-35 ~16 minecraft:light_gray_concrete
fill ~19 ~-35 ~16 ~31 ~-35 ~16 minecraft:air
setblock ~32 ~-35 ~16 minecraft:light_gray_concrete
fill ~33 ~-35 ~16 ~35 ~-35 ~16 minecraft:air
setblock ~36 ~-35 ~16 minecraft:light_gray_concrete
setblock ~37 ~-35 ~16 minecraft:smooth_stone_slab[type=top]
fill ~38 ~-35 ~16 ~48 ~-35 ~16 minecraft:air
setblock ~49 ~-35 ~16 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-35 ~16 minecraft:light_gray_concrete
fill ~51 ~-35 ~16 ~63 ~-35 ~16 minecraft:air
setblock ~64 ~-35 ~16 minecraft:light_gray_concrete
setblock ~4 ~-35 ~17 minecraft:light_gray_concrete
setblock ~5 ~-35 ~17 minecraft:barrel
setblock ~6 ~-35 ~17 minecraft:air
setblock ~7 ~-35 ~17 minecraft:barrel
setblock ~8 ~-35 ~17 minecraft:air
setblock ~9 ~-35 ~17 minecraft:barrel
fill ~10 ~-35 ~17 ~12 ~-35 ~17 minecraft:air
setblock ~13 ~-35 ~17 minecraft:barrel
setblock ~14 ~-35 ~17 minecraft:air
setblock ~15 ~-35 ~17 minecraft:barrel
setblock ~16 ~-35 ~17 minecraft:air
setblock ~17 ~-35 ~17 minecraft:barrel
setblock ~18 ~-35 ~17 minecraft:light_gray_concrete
setblock ~19 ~-35 ~17 minecraft:air
setblock ~20 ~-35 ~17 minecraft:cauldron
fill ~21 ~-35 ~17 ~23 ~-35 ~17 minecraft:air
setblock ~24 ~-35 ~17 minecraft:cauldron
fill ~25 ~-35 ~17 ~27 ~-35 ~17 minecraft:air
setblock ~28 ~-35 ~17 minecraft:cauldron
fill ~29 ~-35 ~17 ~31 ~-35 ~17 minecraft:air
setblock ~32 ~-35 ~17 minecraft:light_gray_concrete
fill ~33 ~-35 ~17 ~35 ~-35 ~17 minecraft:air
setblock ~36 ~-35 ~17 minecraft:light_gray_concrete
setblock ~37 ~-35 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~38 ~-35 ~17 minecraft:cauldron
fill ~39 ~-35 ~17 ~40 ~-35 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~41 ~-35 ~17 minecraft:cauldron
fill ~42 ~-35 ~17 ~43 ~-35 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~44 ~-35 ~17 minecraft:cauldron
fill ~45 ~-35 ~17 ~46 ~-35 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~47 ~-35 ~17 minecraft:cauldron
fill ~48 ~-35 ~17 ~49 ~-35 ~17 minecraft:smooth_stone_slab[type=top]
setblock ~50 ~-35 ~17 minecraft:light_gray_concrete
fill ~51 ~-35 ~17 ~63 ~-35 ~17 minecraft:air
setblock ~64 ~-35 ~17 minecraft:light_gray_concrete
fill ~4 ~-35 ~18 ~10 ~-35 ~18 minecraft:light_gray_concrete
setblock ~11 ~-35 ~18 minecraft:air
fill ~12 ~-35 ~18 ~32 ~-35 ~18 minecraft:light_gray_concrete
fill ~33 ~-35 ~18 ~35 ~-35 ~18 minecraft:air
fill ~36 ~-35 ~18 ~56 ~-35 ~18 minecraft:light_gray_concrete
setblock ~57 ~-35 ~18 minecraft:air
fill ~58 ~-35 ~18 ~64 ~-35 ~18 minecraft:light_gray_concrete
setblock ~4 ~-35 ~19 minecraft:light_gray_concrete
fill ~5 ~-35 ~19 ~9 ~-35 ~19 minecraft:iron_block
fill ~10 ~-35 ~19 ~12 ~-35 ~19 minecraft:air
fill ~13 ~-35 ~19 ~17 ~-35 ~19 minecraft:iron_block
setblock ~18 ~-35 ~19 minecraft:light_gray_concrete
setblock ~19 ~-35 ~19 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-35 ~19 ~22 ~-35 ~19 minecraft:air
setblock ~23 ~-35 ~19 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-35 ~19 ~26 ~-35 ~19 minecraft:air
setblock ~27 ~-35 ~19 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-35 ~19 ~31 ~-35 ~19 minecraft:air
setblock ~32 ~-35 ~19 minecraft:light_gray_concrete
fill ~33 ~-35 ~19 ~35 ~-35 ~19 minecraft:air
setblock ~36 ~-35 ~19 minecraft:light_gray_concrete
fill ~37 ~-35 ~19 ~49 ~-35 ~19 minecraft:air
setblock ~50 ~-35 ~19 minecraft:light_gray_concrete
setblock ~51 ~-35 ~19 minecraft:barrel
setblock ~52 ~-35 ~19 minecraft:air
setblock ~53 ~-35 ~19 minecraft:barrel
setblock ~54 ~-35 ~19 minecraft:air
setblock ~55 ~-35 ~19 minecraft:barrel
fill ~56 ~-35 ~19 ~58 ~-35 ~19 minecraft:air
setblock ~59 ~-35 ~19 minecraft:barrel
setblock ~60 ~-35 ~19 minecraft:air
setblock ~61 ~-35 ~19 minecraft:barrel
setblock ~62 ~-35 ~19 minecraft:air
setblock ~63 ~-35 ~19 minecraft:barrel
setblock ~64 ~-35 ~19 minecraft:light_gray_concrete
setblock ~4 ~-35 ~20 minecraft:light_gray_concrete
fill ~5 ~-35 ~20 ~9 ~-35 ~20 minecraft:iron_trapdoor[open=true,facing=south]
fill ~10 ~-35 ~20 ~12 ~-35 ~20 minecraft:air
fill ~13 ~-35 ~20 ~17 ~-35 ~20 minecraft:iron_trapdoor[open=true,facing=south]
setblock ~18 ~-35 ~20 minecraft:light_gray_concrete
setblock ~19 ~-35 ~20 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-35 ~20 ~22 ~-35 ~20 minecraft:air
setblock ~23 ~-35 ~20 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-35 ~20 ~26 ~-35 ~20 minecraft:air
setblock ~27 ~-35 ~20 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-35 ~20 ~49 ~-35 ~20 minecraft:air
setblock ~50 ~-35 ~20 minecraft:light_gray_concrete
fill ~51 ~-35 ~20 ~63 ~-35 ~20 minecraft:air
setblock ~64 ~-35 ~20 minecraft:light_gray_concrete
setblock ~4 ~-35 ~21 minecraft:light_gray_concrete
setblock ~5 ~-35 ~21 minecraft:iron_block
setblock ~6 ~-35 ~21 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~21 ~17 ~-35 ~21 minecraft:air
setblock ~18 ~-35 ~21 minecraft:light_gray_concrete
setblock ~19 ~-35 ~21 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-35 ~21 ~22 ~-35 ~21 minecraft:air
setblock ~23 ~-35 ~21 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-35 ~21 ~26 ~-35 ~21 minecraft:air
setblock ~27 ~-35 ~21 minecraft:iron_bars[north=true]
fill ~28 ~-35 ~21 ~31 ~-35 ~21 minecraft:air
setblock ~32 ~-35 ~21 minecraft:light_gray_concrete
fill ~33 ~-35 ~21 ~35 ~-35 ~21 minecraft:air
setblock ~36 ~-35 ~21 minecraft:light_gray_concrete
fill ~37 ~-35 ~21 ~42 ~-35 ~21 minecraft:air
setblock ~43 ~-35 ~21 minecraft:iron_bars[east=true]
setblock ~44 ~-35 ~21 minecraft:iron_bars[east=true,west=true]
fill ~45 ~-35 ~21 ~46 ~-35 ~21 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~47 ~-35 ~21 minecraft:iron_bars[south=true,west=true]
fill ~48 ~-35 ~21 ~49 ~-35 ~21 minecraft:air
setblock ~50 ~-35 ~21 minecraft:light_gray_concrete
setblock ~51 ~-35 ~21 minecraft:barrel
fill ~52 ~-35 ~21 ~62 ~-35 ~21 minecraft:air
setblock ~63 ~-35 ~21 minecraft:barrel
setblock ~64 ~-35 ~21 minecraft:light_gray_concrete
setblock ~4 ~-35 ~22 minecraft:light_gray_concrete
setblock ~5 ~-35 ~22 minecraft:iron_block
setblock ~6 ~-35 ~22 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~22 ~17 ~-35 ~22 minecraft:air
setblock ~18 ~-35 ~22 minecraft:light_gray_concrete
setblock ~19 ~-35 ~22 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~20 ~-35 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~21 ~-35 ~22 minecraft:air
setblock ~22 ~-35 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-35 ~22 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-35 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-35 ~22 minecraft:air
setblock ~26 ~-35 ~22 minecraft:iron_bars[west=true]
fill ~27 ~-35 ~22 ~28 ~-35 ~22 minecraft:air
fill ~29 ~-35 ~22 ~32 ~-35 ~22 minecraft:polished_andesite
fill ~33 ~-35 ~22 ~35 ~-35 ~22 minecraft:air
fill ~36 ~-35 ~22 ~39 ~-35 ~22 minecraft:polished_andesite
fill ~40 ~-35 ~22 ~44 ~-35 ~22 minecraft:air
setblock ~45 ~-35 ~22 minecraft:iron_bars[north=true,east=true]
setblock ~46 ~-35 ~22 minecraft:bone_block
setblock ~47 ~-35 ~22 minecraft:iron_bars[north=true,south=true,west=true]
fill ~48 ~-35 ~22 ~49 ~-35 ~22 minecraft:air
setblock ~50 ~-35 ~22 minecraft:light_gray_concrete
fill ~51 ~-35 ~22 ~63 ~-35 ~22 minecraft:air
setblock ~64 ~-35 ~22 minecraft:light_gray_concrete
setblock ~4 ~-35 ~23 minecraft:light_gray_concrete
setblock ~5 ~-35 ~23 minecraft:iron_block
setblock ~6 ~-35 ~23 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~23 ~10 ~-35 ~23 minecraft:air
setblock ~11 ~-35 ~23 minecraft:smooth_stone_slab[type=top]
fill ~12 ~-35 ~23 ~17 ~-35 ~23 minecraft:air
setblock ~18 ~-35 ~23 minecraft:light_gray_concrete
fill ~19 ~-35 ~23 ~28 ~-35 ~23 minecraft:air
setblock ~29 ~-35 ~23 minecraft:polished_andesite
fill ~30 ~-35 ~23 ~38 ~-35 ~23 minecraft:air
setblock ~39 ~-35 ~23 minecraft:polished_andesite
fill ~40 ~-35 ~23 ~45 ~-35 ~23 minecraft:air
setblock ~46 ~-35 ~23 minecraft:iron_bars[north=true,east=true]
setblock ~47 ~-35 ~23 minecraft:iron_bars[north=true,south=true,west=true]
fill ~48 ~-35 ~23 ~49 ~-35 ~23 minecraft:air
setblock ~50 ~-35 ~23 minecraft:light_gray_concrete
setblock ~51 ~-35 ~23 minecraft:barrel
fill ~52 ~-35 ~23 ~55 ~-35 ~23 minecraft:air
fill ~56 ~-35 ~23 ~57 ~-35 ~23 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-35 ~23 ~62 ~-35 ~23 minecraft:air
setblock ~63 ~-35 ~23 minecraft:barrel
setblock ~64 ~-35 ~23 minecraft:light_gray_concrete
setblock ~4 ~-35 ~24 minecraft:light_gray_concrete
setblock ~5 ~-35 ~24 minecraft:iron_block
setblock ~6 ~-35 ~24 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~24 ~17 ~-35 ~24 minecraft:air
setblock ~18 ~-35 ~24 minecraft:light_gray_concrete
fill ~19 ~-35 ~24 ~25 ~-35 ~24 minecraft:air
fill ~26 ~-35 ~24 ~27 ~-35 ~24 minecraft:polished_andesite
fill ~28 ~-35 ~24 ~29 ~-35 ~24 minecraft:air
setblock ~30 ~-35 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-35 ~24 ~37 ~-35 ~24 minecraft:air
setblock ~38 ~-35 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-35 ~24 ~40 ~-35 ~24 minecraft:air
fill ~41 ~-35 ~24 ~42 ~-35 ~24 minecraft:polished_andesite
fill ~43 ~-35 ~24 ~46 ~-35 ~24 minecraft:air
setblock ~47 ~-35 ~24 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-35 ~24 ~49 ~-35 ~24 minecraft:air
setblock ~50 ~-35 ~24 minecraft:light_gray_concrete
fill ~51 ~-35 ~24 ~63 ~-35 ~24 minecraft:air
setblock ~64 ~-35 ~24 minecraft:light_gray_concrete
setblock ~4 ~-35 ~25 minecraft:light_gray_concrete
setblock ~5 ~-35 ~25 minecraft:iron_block
setblock ~6 ~-35 ~25 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~25 ~17 ~-35 ~25 minecraft:air
setblock ~18 ~-35 ~25 minecraft:light_gray_concrete
fill ~19 ~-35 ~25 ~24 ~-35 ~25 minecraft:air
fill ~25 ~-35 ~25 ~26 ~-35 ~25 minecraft:polished_andesite
fill ~27 ~-35 ~25 ~31 ~-35 ~25 minecraft:air
setblock ~32 ~-35 ~25 minecraft:glass_pane[east=true]
fill ~33 ~-35 ~25 ~35 ~-35 ~25 minecraft:glass_pane[east=true,west=true]
setblock ~36 ~-35 ~25 minecraft:glass_pane[west=true]
fill ~37 ~-35 ~25 ~41 ~-35 ~25 minecraft:air
fill ~42 ~-35 ~25 ~43 ~-35 ~25 minecraft:polished_andesite
fill ~44 ~-35 ~25 ~46 ~-35 ~25 minecraft:air
setblock ~47 ~-35 ~25 minecraft:iron_bars[north=true]
fill ~48 ~-35 ~25 ~49 ~-35 ~25 minecraft:air
setblock ~50 ~-35 ~25 minecraft:light_gray_concrete
setblock ~51 ~-35 ~25 minecraft:barrel
fill ~52 ~-35 ~25 ~53 ~-35 ~25 minecraft:air
setblock ~54 ~-35 ~25 minecraft:cauldron
setblock ~55 ~-35 ~25 minecraft:air
fill ~56 ~-35 ~25 ~57 ~-35 ~25 minecraft:smooth_stone_slab[type=top]
setblock ~58 ~-35 ~25 minecraft:air
setblock ~59 ~-35 ~25 minecraft:cauldron
fill ~60 ~-35 ~25 ~62 ~-35 ~25 minecraft:air
setblock ~63 ~-35 ~25 minecraft:barrel
setblock ~64 ~-35 ~25 minecraft:light_gray_concrete
setblock ~4 ~-35 ~26 minecraft:light_gray_concrete
setblock ~5 ~-35 ~26 minecraft:iron_block
setblock ~6 ~-35 ~26 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~26 ~17 ~-35 ~26 minecraft:air
setblock ~18 ~-35 ~26 minecraft:light_gray_concrete
fill ~19 ~-35 ~26 ~23 ~-35 ~26 minecraft:air
fill ~24 ~-35 ~26 ~25 ~-35 ~26 minecraft:polished_andesite
fill ~26 ~-35 ~26 ~29 ~-35 ~26 minecraft:air
setblock ~30 ~-35 ~26 minecraft:glass_pane[east=true]
setblock ~31 ~-35 ~26 minecraft:glass_pane[west=true]
fill ~32 ~-35 ~26 ~36 ~-35 ~26 minecraft:air
setblock ~37 ~-35 ~26 minecraft:glass_pane[east=true]
setblock ~38 ~-35 ~26 minecraft:glass_pane[west=true]
fill ~39 ~-35 ~26 ~42 ~-35 ~26 minecraft:air
fill ~43 ~-35 ~26 ~44 ~-35 ~26 minecraft:polished_andesite
fill ~45 ~-35 ~26 ~49 ~-35 ~26 minecraft:air
setblock ~50 ~-35 ~26 minecraft:light_gray_concrete
fill ~51 ~-35 ~26 ~63 ~-35 ~26 minecraft:air
setblock ~64 ~-35 ~26 minecraft:light_gray_concrete
setblock ~4 ~-35 ~27 minecraft:light_gray_concrete
setblock ~5 ~-35 ~27 minecraft:iron_block
setblock ~6 ~-35 ~27 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~27 ~10 ~-35 ~27 minecraft:air
setblock ~11 ~-35 ~27 minecraft:smooth_stone_slab[type=top]
fill ~12 ~-35 ~27 ~17 ~-35 ~27 minecraft:air
setblock ~18 ~-35 ~27 minecraft:light_gray_concrete
fill ~19 ~-35 ~27 ~23 ~-35 ~27 minecraft:air
setblock ~24 ~-35 ~27 minecraft:polished_andesite
fill ~25 ~-35 ~27 ~27 ~-35 ~27 minecraft:air
setblock ~28 ~-35 ~27 minecraft:glass_pane[east=true]
setblock ~29 ~-35 ~27 minecraft:glass_pane[west=true]
fill ~30 ~-35 ~27 ~38 ~-35 ~27 minecraft:air
setblock ~39 ~-35 ~27 minecraft:glass_pane[east=true]
setblock ~40 ~-35 ~27 minecraft:glass_pane[west=true]
fill ~41 ~-35 ~27 ~43 ~-35 ~27 minecraft:air
setblock ~44 ~-35 ~27 minecraft:polished_andesite
fill ~45 ~-35 ~27 ~49 ~-35 ~27 minecraft:air
setblock ~50 ~-35 ~27 minecraft:light_gray_concrete
setblock ~51 ~-35 ~27 minecraft:barrel
fill ~52 ~-35 ~27 ~55 ~-35 ~27 minecraft:air
fill ~56 ~-35 ~27 ~57 ~-35 ~27 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-35 ~27 ~62 ~-35 ~27 minecraft:air
setblock ~63 ~-35 ~27 minecraft:barrel
setblock ~64 ~-35 ~27 minecraft:light_gray_concrete
setblock ~4 ~-35 ~28 minecraft:light_gray_concrete
setblock ~5 ~-35 ~28 minecraft:iron_block
setblock ~6 ~-35 ~28 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~28 ~17 ~-35 ~28 minecraft:air
setblock ~18 ~-35 ~28 minecraft:light_gray_concrete
fill ~19 ~-35 ~28 ~22 ~-35 ~28 minecraft:air
setblock ~23 ~-35 ~28 minecraft:polished_andesite
fill ~24 ~-35 ~28 ~26 ~-35 ~28 minecraft:air
setblock ~27 ~-35 ~28 minecraft:glass_pane[south=true]
fill ~28 ~-35 ~28 ~40 ~-35 ~28 minecraft:air
setblock ~41 ~-35 ~28 minecraft:glass_pane[south=true]
fill ~42 ~-35 ~28 ~44 ~-35 ~28 minecraft:air
setblock ~45 ~-35 ~28 minecraft:polished_andesite
fill ~46 ~-35 ~28 ~49 ~-35 ~28 minecraft:air
setblock ~50 ~-35 ~28 minecraft:light_gray_concrete
fill ~51 ~-35 ~28 ~63 ~-35 ~28 minecraft:air
setblock ~64 ~-35 ~28 minecraft:light_gray_concrete
setblock ~4 ~-35 ~29 minecraft:light_gray_concrete
setblock ~5 ~-35 ~29 minecraft:iron_block
setblock ~6 ~-35 ~29 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~29 ~17 ~-35 ~29 minecraft:air
setblock ~18 ~-35 ~29 minecraft:light_gray_concrete
fill ~19 ~-35 ~29 ~21 ~-35 ~29 minecraft:air
fill ~22 ~-35 ~29 ~23 ~-35 ~29 minecraft:polished_andesite
fill ~24 ~-35 ~29 ~26 ~-35 ~29 minecraft:air
setblock ~27 ~-35 ~29 minecraft:glass_pane[north=true]
fill ~28 ~-35 ~29 ~40 ~-35 ~29 minecraft:air
setblock ~41 ~-35 ~29 minecraft:glass_pane[north=true]
fill ~42 ~-35 ~29 ~44 ~-35 ~29 minecraft:air
fill ~45 ~-35 ~29 ~46 ~-35 ~29 minecraft:polished_andesite
fill ~47 ~-35 ~29 ~49 ~-35 ~29 minecraft:air
setblock ~50 ~-35 ~29 minecraft:light_gray_concrete
setblock ~51 ~-35 ~29 minecraft:barrel
fill ~52 ~-35 ~29 ~62 ~-35 ~29 minecraft:air
setblock ~63 ~-35 ~29 minecraft:barrel
setblock ~64 ~-35 ~29 minecraft:light_gray_concrete
setblock ~4 ~-35 ~30 minecraft:light_gray_concrete
setblock ~5 ~-35 ~30 minecraft:iron_block
setblock ~6 ~-35 ~30 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~30 ~9 ~-35 ~30 minecraft:iron_trapdoor[open=true,facing=north]
fill ~10 ~-35 ~30 ~12 ~-35 ~30 minecraft:air
fill ~13 ~-35 ~30 ~16 ~-35 ~30 minecraft:iron_trapdoor[open=true,facing=north]
setblock ~17 ~-35 ~30 minecraft:air
setblock ~18 ~-35 ~30 minecraft:light_gray_concrete
fill ~19 ~-35 ~30 ~21 ~-35 ~30 minecraft:air
setblock ~22 ~-35 ~30 minecraft:polished_andesite
setblock ~23 ~-35 ~30 minecraft:air
setblock ~24 ~-35 ~30 minecraft:chiseled_quartz_block
setblock ~25 ~-35 ~30 minecraft:air
setblock ~26 ~-35 ~30 minecraft:glass_pane[south=true]
fill ~27 ~-35 ~30 ~41 ~-35 ~30 minecraft:air
setblock ~42 ~-35 ~30 minecraft:glass_pane[south=true]
setblock ~43 ~-35 ~30 minecraft:air
setblock ~44 ~-35 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-35 ~30 minecraft:air
setblock ~46 ~-35 ~30 minecraft:polished_andesite
fill ~47 ~-35 ~30 ~49 ~-35 ~30 minecraft:air
setblock ~50 ~-35 ~30 minecraft:light_gray_concrete
fill ~51 ~-35 ~30 ~63 ~-35 ~30 minecraft:air
setblock ~64 ~-35 ~30 minecraft:light_gray_concrete
setblock ~4 ~-35 ~31 minecraft:light_gray_concrete
fill ~5 ~-35 ~31 ~6 ~-35 ~31 minecraft:air
fill ~7 ~-35 ~31 ~9 ~-35 ~31 minecraft:iron_block
fill ~10 ~-35 ~31 ~12 ~-35 ~31 minecraft:air
fill ~13 ~-35 ~31 ~16 ~-35 ~31 minecraft:iron_block
setblock ~17 ~-35 ~31 minecraft:air
setblock ~18 ~-35 ~31 minecraft:light_gray_concrete
fill ~19 ~-35 ~31 ~21 ~-35 ~31 minecraft:air
setblock ~22 ~-35 ~31 minecraft:polished_andesite
fill ~23 ~-35 ~31 ~25 ~-35 ~31 minecraft:air
setblock ~26 ~-35 ~31 minecraft:glass_pane[north=true]
fill ~27 ~-35 ~31 ~41 ~-35 ~31 minecraft:air
setblock ~42 ~-35 ~31 minecraft:glass_pane[north=true,south=true]
fill ~43 ~-35 ~31 ~45 ~-35 ~31 minecraft:air
setblock ~46 ~-35 ~31 minecraft:polished_andesite
fill ~47 ~-35 ~31 ~49 ~-35 ~31 minecraft:air
setblock ~50 ~-35 ~31 minecraft:light_gray_concrete
setblock ~51 ~-35 ~31 minecraft:barrel
setblock ~52 ~-35 ~31 minecraft:air
setblock ~53 ~-35 ~31 minecraft:barrel
setblock ~54 ~-35 ~31 minecraft:air
setblock ~55 ~-35 ~31 minecraft:barrel
fill ~56 ~-35 ~31 ~58 ~-35 ~31 minecraft:air
setblock ~59 ~-35 ~31 minecraft:barrel
setblock ~60 ~-35 ~31 minecraft:air
setblock ~61 ~-35 ~31 minecraft:barrel
setblock ~62 ~-35 ~31 minecraft:air
setblock ~63 ~-35 ~31 minecraft:barrel
setblock ~64 ~-35 ~31 minecraft:light_gray_concrete
fill ~4 ~-35 ~32 ~10 ~-35 ~32 minecraft:light_gray_concrete
setblock ~11 ~-35 ~32 minecraft:air
fill ~12 ~-35 ~32 ~19 ~-35 ~32 minecraft:light_gray_concrete
setblock ~20 ~-35 ~32 minecraft:air
setblock ~21 ~-35 ~32 minecraft:light_gray_concrete
setblock ~22 ~-35 ~32 minecraft:polished_andesite
fill ~23 ~-35 ~32 ~24 ~-35 ~32 minecraft:air
setblock ~25 ~-35 ~32 minecraft:glass_pane[south=true]
fill ~26 ~-35 ~32 ~32 ~-35 ~32 minecraft:air
fill ~33 ~-35 ~32 ~35 ~-35 ~32 minecraft:glass
setblock ~36 ~-35 ~32 minecraft:air
setblock ~37 ~-35 ~32 minecraft:iron_bars[east=true]
fill ~38 ~-35 ~32 ~41 ~-35 ~32 minecraft:iron_bars[east=true,west=true]
setblock ~42 ~-35 ~32 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~43 ~-35 ~32 minecraft:glass_pane[west=true]
fill ~44 ~-35 ~32 ~45 ~-35 ~32 minecraft:air
setblock ~46 ~-35 ~32 minecraft:polished_andesite
setblock ~47 ~-35 ~32 minecraft:light_gray_concrete
setblock ~48 ~-35 ~32 minecraft:air
fill ~49 ~-35 ~32 ~56 ~-35 ~32 minecraft:light_gray_concrete
setblock ~57 ~-35 ~32 minecraft:air
fill ~58 ~-35 ~32 ~64 ~-35 ~32 minecraft:light_gray_concrete
setblock ~4 ~-35 ~33 minecraft:light_gray_concrete
fill ~5 ~-35 ~33 ~24 ~-35 ~33 minecraft:air
setblock ~25 ~-35 ~33 minecraft:glass_pane[north=true,south=true]
fill ~26 ~-35 ~33 ~32 ~-35 ~33 minecraft:air
setblock ~33 ~-35 ~33 minecraft:glass
fill ~34 ~-35 ~33 ~63 ~-35 ~33 minecraft:air
setblock ~64 ~-35 ~33 minecraft:light_gray_concrete
setblock ~4 ~-35 ~34 minecraft:light_gray_concrete
fill ~5 ~-35 ~34 ~24 ~-35 ~34 minecraft:air
setblock ~25 ~-35 ~34 minecraft:glass_pane[north=true,south=true]
fill ~26 ~-35 ~34 ~32 ~-35 ~34 minecraft:air
fill ~33 ~-35 ~34 ~35 ~-35 ~34 minecraft:glass
fill ~36 ~-35 ~34 ~63 ~-35 ~34 minecraft:air
setblock ~64 ~-35 ~34 minecraft:light_gray_concrete
setblock ~4 ~-35 ~35 minecraft:light_gray_concrete
fill ~5 ~-35 ~35 ~24 ~-35 ~35 minecraft:air
setblock ~25 ~-35 ~35 minecraft:glass_pane[north=true,south=true]
fill ~26 ~-35 ~35 ~32 ~-35 ~35 minecraft:air
setblock ~33 ~-35 ~35 minecraft:glass
fill ~34 ~-35 ~35 ~63 ~-35 ~35 minecraft:air
setblock ~64 ~-35 ~35 minecraft:light_gray_concrete
fill ~4 ~-35 ~36 ~10 ~-35 ~36 minecraft:light_gray_concrete
setblock ~11 ~-35 ~36 minecraft:air
fill ~12 ~-35 ~36 ~19 ~-35 ~36 minecraft:light_gray_concrete
setblock ~20 ~-35 ~36 minecraft:air
setblock ~21 ~-35 ~36 minecraft:light_gray_concrete
setblock ~22 ~-35 ~36 minecraft:polished_andesite
fill ~23 ~-35 ~36 ~24 ~-35 ~36 minecraft:air
setblock ~25 ~-35 ~36 minecraft:glass_pane[north=true]
fill ~26 ~-35 ~36 ~32 ~-35 ~36 minecraft:air
fill ~33 ~-35 ~36 ~35 ~-35 ~36 minecraft:glass
setblock ~36 ~-35 ~36 minecraft:air
setblock ~37 ~-35 ~36 minecraft:iron_bars[east=true]
fill ~38 ~-35 ~36 ~41 ~-35 ~36 minecraft:iron_bars[east=true,west=true]
setblock ~42 ~-35 ~36 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~43 ~-35 ~36 minecraft:glass_pane[west=true]
fill ~44 ~-35 ~36 ~45 ~-35 ~36 minecraft:air
setblock ~46 ~-35 ~36 minecraft:polished_andesite
setblock ~47 ~-35 ~36 minecraft:light_gray_concrete
setblock ~48 ~-35 ~36 minecraft:air
fill ~49 ~-35 ~36 ~56 ~-35 ~36 minecraft:light_gray_concrete
setblock ~57 ~-35 ~36 minecraft:air
fill ~58 ~-35 ~36 ~64 ~-35 ~36 minecraft:light_gray_concrete
setblock ~4 ~-35 ~37 minecraft:light_gray_concrete
setblock ~5 ~-35 ~37 minecraft:air
setblock ~6 ~-35 ~37 minecraft:barrel
fill ~7 ~-35 ~37 ~8 ~-35 ~37 minecraft:air
setblock ~9 ~-35 ~37 minecraft:barrel
fill ~10 ~-35 ~37 ~14 ~-35 ~37 minecraft:air
setblock ~15 ~-35 ~37 minecraft:barrel
fill ~16 ~-35 ~37 ~17 ~-35 ~37 minecraft:air
setblock ~18 ~-35 ~37 minecraft:light_gray_concrete
fill ~19 ~-35 ~37 ~21 ~-35 ~37 minecraft:air
setblock ~22 ~-35 ~37 minecraft:polished_andesite
fill ~23 ~-35 ~37 ~25 ~-35 ~37 minecraft:air
setblock ~26 ~-35 ~37 minecraft:glass_pane[south=true]
fill ~27 ~-35 ~37 ~41 ~-35 ~37 minecraft:air
setblock ~42 ~-35 ~37 minecraft:glass_pane[north=true,south=true]
fill ~43 ~-35 ~37 ~45 ~-35 ~37 minecraft:air
setblock ~46 ~-35 ~37 minecraft:polished_andesite
fill ~47 ~-35 ~37 ~49 ~-35 ~37 minecraft:air
setblock ~50 ~-35 ~37 minecraft:light_gray_concrete
fill ~51 ~-35 ~37 ~53 ~-35 ~37 minecraft:packed_ice
setblock ~54 ~-35 ~37 minecraft:air
setblock ~55 ~-35 ~37 minecraft:packed_ice
fill ~56 ~-35 ~37 ~58 ~-35 ~37 minecraft:air
fill ~59 ~-35 ~37 ~61 ~-35 ~37 minecraft:packed_ice
setblock ~62 ~-35 ~37 minecraft:air
setblock ~63 ~-35 ~37 minecraft:packed_ice
setblock ~64 ~-35 ~37 minecraft:light_gray_concrete
setblock ~4 ~-35 ~38 minecraft:light_gray_concrete
setblock ~5 ~-35 ~38 minecraft:barrel
fill ~6 ~-35 ~38 ~16 ~-35 ~38 minecraft:air
setblock ~17 ~-35 ~38 minecraft:barrel
setblock ~18 ~-35 ~38 minecraft:light_gray_concrete
fill ~19 ~-35 ~38 ~21 ~-35 ~38 minecraft:air
setblock ~22 ~-35 ~38 minecraft:polished_andesite
setblock ~23 ~-35 ~38 minecraft:air
setblock ~24 ~-35 ~38 minecraft:chiseled_quartz_block
setblock ~25 ~-35 ~38 minecraft:air
setblock ~26 ~-35 ~38 minecraft:glass_pane[north=true]
fill ~27 ~-35 ~38 ~41 ~-35 ~38 minecraft:air
setblock ~42 ~-35 ~38 minecraft:glass_pane[north=true]
setblock ~43 ~-35 ~38 minecraft:air
setblock ~44 ~-35 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-35 ~38 minecraft:air
setblock ~46 ~-35 ~38 minecraft:polished_andesite
fill ~47 ~-35 ~38 ~49 ~-35 ~38 minecraft:air
setblock ~50 ~-35 ~38 minecraft:light_gray_concrete
setblock ~51 ~-35 ~38 minecraft:packed_ice
fill ~52 ~-35 ~38 ~62 ~-35 ~38 minecraft:air
setblock ~63 ~-35 ~38 minecraft:packed_ice
setblock ~64 ~-35 ~38 minecraft:light_gray_concrete
setblock ~4 ~-35 ~39 minecraft:light_gray_concrete
setblock ~5 ~-35 ~39 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-35 ~39 ~17 ~-35 ~39 minecraft:air
setblock ~18 ~-35 ~39 minecraft:light_gray_concrete
fill ~19 ~-35 ~39 ~21 ~-35 ~39 minecraft:air
fill ~22 ~-35 ~39 ~23 ~-35 ~39 minecraft:polished_andesite
fill ~24 ~-35 ~39 ~26 ~-35 ~39 minecraft:air
setblock ~27 ~-35 ~39 minecraft:glass_pane[south=true]
fill ~28 ~-35 ~39 ~40 ~-35 ~39 minecraft:air
setblock ~41 ~-35 ~39 minecraft:glass_pane[south=true]
fill ~42 ~-35 ~39 ~44 ~-35 ~39 minecraft:air
fill ~45 ~-35 ~39 ~46 ~-35 ~39 minecraft:polished_andesite
fill ~47 ~-35 ~39 ~49 ~-35 ~39 minecraft:air
setblock ~50 ~-35 ~39 minecraft:light_gray_concrete
setblock ~51 ~-35 ~39 minecraft:packed_ice
fill ~52 ~-35 ~39 ~53 ~-35 ~39 minecraft:air
setblock ~54 ~-35 ~39 minecraft:barrel
fill ~55 ~-35 ~39 ~56 ~-35 ~39 minecraft:air
setblock ~57 ~-35 ~39 minecraft:barrel
fill ~58 ~-35 ~39 ~59 ~-35 ~39 minecraft:air
setblock ~60 ~-35 ~39 minecraft:barrel
fill ~61 ~-35 ~39 ~62 ~-35 ~39 minecraft:air
setblock ~63 ~-35 ~39 minecraft:packed_ice
setblock ~64 ~-35 ~39 minecraft:light_gray_concrete
setblock ~4 ~-35 ~40 minecraft:light_gray_concrete
fill ~5 ~-35 ~40 ~17 ~-35 ~40 minecraft:air
setblock ~18 ~-35 ~40 minecraft:light_gray_concrete
fill ~19 ~-35 ~40 ~22 ~-35 ~40 minecraft:air
setblock ~23 ~-35 ~40 minecraft:polished_andesite
fill ~24 ~-35 ~40 ~26 ~-35 ~40 minecraft:air
setblock ~27 ~-35 ~40 minecraft:glass_pane[north=true]
fill ~28 ~-35 ~40 ~40 ~-35 ~40 minecraft:air
setblock ~41 ~-35 ~40 minecraft:glass_pane[north=true]
fill ~42 ~-35 ~40 ~44 ~-35 ~40 minecraft:air
setblock ~45 ~-35 ~40 minecraft:polished_andesite
fill ~46 ~-35 ~40 ~49 ~-35 ~40 minecraft:air
setblock ~50 ~-35 ~40 minecraft:light_gray_concrete
fill ~51 ~-35 ~40 ~53 ~-35 ~40 minecraft:air
setblock ~54 ~-35 ~40 minecraft:barrel
fill ~55 ~-35 ~40 ~56 ~-35 ~40 minecraft:air
setblock ~57 ~-35 ~40 minecraft:barrel
fill ~58 ~-35 ~40 ~59 ~-35 ~40 minecraft:air
setblock ~60 ~-35 ~40 minecraft:barrel
fill ~61 ~-35 ~40 ~63 ~-35 ~40 minecraft:air
setblock ~64 ~-35 ~40 minecraft:light_gray_concrete
setblock ~4 ~-35 ~41 minecraft:light_gray_concrete
setblock ~5 ~-35 ~41 minecraft:barrel
fill ~6 ~-35 ~41 ~16 ~-35 ~41 minecraft:air
setblock ~17 ~-35 ~41 minecraft:barrel
setblock ~18 ~-35 ~41 minecraft:light_gray_concrete
fill ~19 ~-35 ~41 ~23 ~-35 ~41 minecraft:air
setblock ~24 ~-35 ~41 minecraft:polished_andesite
fill ~25 ~-35 ~41 ~27 ~-35 ~41 minecraft:air
setblock ~28 ~-35 ~41 minecraft:glass_pane[east=true]
setblock ~29 ~-35 ~41 minecraft:glass_pane[west=true]
fill ~30 ~-35 ~41 ~38 ~-35 ~41 minecraft:air
setblock ~39 ~-35 ~41 minecraft:glass_pane[east=true]
setblock ~40 ~-35 ~41 minecraft:glass_pane[west=true]
fill ~41 ~-35 ~41 ~43 ~-35 ~41 minecraft:air
setblock ~44 ~-35 ~41 minecraft:polished_andesite
fill ~45 ~-35 ~41 ~49 ~-35 ~41 minecraft:air
setblock ~50 ~-35 ~41 minecraft:light_gray_concrete
setblock ~51 ~-35 ~41 minecraft:packed_ice
fill ~52 ~-35 ~41 ~53 ~-35 ~41 minecraft:air
setblock ~54 ~-35 ~41 minecraft:barrel
fill ~55 ~-35 ~41 ~56 ~-35 ~41 minecraft:air
setblock ~57 ~-35 ~41 minecraft:barrel
fill ~58 ~-35 ~41 ~59 ~-35 ~41 minecraft:air
setblock ~60 ~-35 ~41 minecraft:barrel
fill ~61 ~-35 ~41 ~62 ~-35 ~41 minecraft:air
setblock ~63 ~-35 ~41 minecraft:packed_ice
setblock ~64 ~-35 ~41 minecraft:light_gray_concrete
setblock ~4 ~-35 ~42 minecraft:light_gray_concrete
setblock ~5 ~-35 ~42 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-35 ~42 ~8 ~-35 ~42 minecraft:air
setblock ~9 ~-35 ~42 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-35 ~42 ~11 ~-35 ~42 minecraft:spruce_slab[type=top]
setblock ~12 ~-35 ~42 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-35 ~42 ~17 ~-35 ~42 minecraft:air
setblock ~18 ~-35 ~42 minecraft:light_gray_concrete
fill ~19 ~-35 ~42 ~23 ~-35 ~42 minecraft:air
fill ~24 ~-35 ~42 ~25 ~-35 ~42 minecraft:polished_andesite
fill ~26 ~-35 ~42 ~29 ~-35 ~42 minecraft:air
setblock ~30 ~-35 ~42 minecraft:glass_pane[east=true]
setblock ~31 ~-35 ~42 minecraft:glass_pane[west=true]
fill ~32 ~-35 ~42 ~36 ~-35 ~42 minecraft:air
setblock ~37 ~-35 ~42 minecraft:glass_pane[east=true]
setblock ~38 ~-35 ~42 minecraft:glass_pane[west=true]
fill ~39 ~-35 ~42 ~42 ~-35 ~42 minecraft:air
fill ~43 ~-35 ~42 ~44 ~-35 ~42 minecraft:polished_andesite
fill ~45 ~-35 ~42 ~49 ~-35 ~42 minecraft:air
setblock ~50 ~-35 ~42 minecraft:light_gray_concrete
setblock ~51 ~-35 ~42 minecraft:packed_ice
fill ~52 ~-35 ~42 ~53 ~-35 ~42 minecraft:air
setblock ~54 ~-35 ~42 minecraft:barrel
fill ~55 ~-35 ~42 ~56 ~-35 ~42 minecraft:air
setblock ~57 ~-35 ~42 minecraft:barrel
fill ~58 ~-35 ~42 ~59 ~-35 ~42 minecraft:air
setblock ~60 ~-35 ~42 minecraft:barrel
fill ~61 ~-35 ~42 ~62 ~-35 ~42 minecraft:air
setblock ~63 ~-35 ~42 minecraft:packed_ice
setblock ~64 ~-35 ~42 minecraft:light_gray_concrete
setblock ~4 ~-35 ~43 minecraft:light_gray_concrete
fill ~5 ~-35 ~43 ~8 ~-35 ~43 minecraft:air
setblock ~9 ~-35 ~43 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~10 ~-35 ~43 ~11 ~-35 ~43 minecraft:spruce_slab[type=top]
setblock ~12 ~-35 ~43 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~13 ~-35 ~43 ~17 ~-35 ~43 minecraft:air
setblock ~18 ~-35 ~43 minecraft:light_gray_concrete
fill ~19 ~-35 ~43 ~20 ~-35 ~43 minecraft:air
setblock ~21 ~-35 ~43 minecraft:iron_bars[south=true]
fill ~22 ~-35 ~43 ~24 ~-35 ~43 minecraft:air
fill ~25 ~-35 ~43 ~26 ~-35 ~43 minecraft:polished_andesite
fill ~27 ~-35 ~43 ~31 ~-35 ~43 minecraft:air
setblock ~32 ~-35 ~43 minecraft:glass_pane[east=true]
fill ~33 ~-35 ~43 ~35 ~-35 ~43 minecraft:glass_pane[east=true,west=true]
setblock ~36 ~-35 ~43 minecraft:glass_pane[west=true]
fill ~37 ~-35 ~43 ~41 ~-35 ~43 minecraft:air
fill ~42 ~-35 ~43 ~43 ~-35 ~43 minecraft:polished_andesite
fill ~44 ~-35 ~43 ~49 ~-35 ~43 minecraft:air
setblock ~50 ~-35 ~43 minecraft:light_gray_concrete
setblock ~51 ~-35 ~43 minecraft:packed_ice
fill ~52 ~-35 ~43 ~62 ~-35 ~43 minecraft:air
setblock ~63 ~-35 ~43 minecraft:packed_ice
setblock ~64 ~-35 ~43 minecraft:light_gray_concrete
setblock ~4 ~-35 ~44 minecraft:light_gray_concrete
setblock ~5 ~-35 ~44 minecraft:barrel
fill ~6 ~-35 ~44 ~16 ~-35 ~44 minecraft:air
setblock ~17 ~-35 ~44 minecraft:barrel
setblock ~18 ~-35 ~44 minecraft:light_gray_concrete
fill ~19 ~-35 ~44 ~20 ~-35 ~44 minecraft:air
setblock ~21 ~-35 ~44 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-35 ~44 ~25 ~-35 ~44 minecraft:air
fill ~26 ~-35 ~44 ~27 ~-35 ~44 minecraft:polished_andesite
fill ~28 ~-35 ~44 ~29 ~-35 ~44 minecraft:air
setblock ~30 ~-35 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-35 ~44 ~37 ~-35 ~44 minecraft:air
setblock ~38 ~-35 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-35 ~44 ~40 ~-35 ~44 minecraft:air
fill ~41 ~-35 ~44 ~42 ~-35 ~44 minecraft:polished_andesite
fill ~43 ~-35 ~44 ~49 ~-35 ~44 minecraft:air
setblock ~50 ~-35 ~44 minecraft:light_gray_concrete
fill ~51 ~-35 ~44 ~53 ~-35 ~44 minecraft:air
setblock ~54 ~-35 ~44 minecraft:barrel
fill ~55 ~-35 ~44 ~56 ~-35 ~44 minecraft:air
setblock ~57 ~-35 ~44 minecraft:barrel
fill ~58 ~-35 ~44 ~59 ~-35 ~44 minecraft:air
setblock ~60 ~-35 ~44 minecraft:barrel
fill ~61 ~-35 ~44 ~63 ~-35 ~44 minecraft:air
setblock ~64 ~-35 ~44 minecraft:light_gray_concrete
setblock ~4 ~-35 ~45 minecraft:light_gray_concrete
setblock ~5 ~-35 ~45 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-35 ~45 ~17 ~-35 ~45 minecraft:air
setblock ~18 ~-35 ~45 minecraft:light_gray_concrete
fill ~19 ~-35 ~45 ~20 ~-35 ~45 minecraft:air
setblock ~21 ~-35 ~45 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~22 ~-35 ~45 minecraft:iron_bars[south=true,west=true]
fill ~23 ~-35 ~45 ~28 ~-35 ~45 minecraft:air
setblock ~29 ~-35 ~45 minecraft:polished_andesite
fill ~30 ~-35 ~45 ~38 ~-35 ~45 minecraft:air
setblock ~39 ~-35 ~45 minecraft:polished_andesite
fill ~40 ~-35 ~45 ~49 ~-35 ~45 minecraft:air
setblock ~50 ~-35 ~45 minecraft:light_gray_concrete
setblock ~51 ~-35 ~45 minecraft:packed_ice
fill ~52 ~-35 ~45 ~53 ~-35 ~45 minecraft:air
setblock ~54 ~-35 ~45 minecraft:barrel
fill ~55 ~-35 ~45 ~56 ~-35 ~45 minecraft:air
setblock ~57 ~-35 ~45 minecraft:barrel
fill ~58 ~-35 ~45 ~59 ~-35 ~45 minecraft:air
setblock ~60 ~-35 ~45 minecraft:barrel
fill ~61 ~-35 ~45 ~62 ~-35 ~45 minecraft:air
setblock ~63 ~-35 ~45 minecraft:packed_ice
setblock ~64 ~-35 ~45 minecraft:light_gray_concrete
setblock ~4 ~-35 ~46 minecraft:light_gray_concrete
fill ~5 ~-35 ~46 ~17 ~-35 ~46 minecraft:air
setblock ~18 ~-35 ~46 minecraft:light_gray_concrete
fill ~19 ~-35 ~46 ~20 ~-35 ~46 minecraft:air
setblock ~21 ~-35 ~46 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~22 ~-35 ~46 minecraft:bone_block
setblock ~23 ~-35 ~46 minecraft:iron_bars[south=true,west=true]
fill ~24 ~-35 ~46 ~28 ~-35 ~46 minecraft:air
fill ~29 ~-35 ~46 ~32 ~-35 ~46 minecraft:polished_andesite
fill ~33 ~-35 ~46 ~35 ~-35 ~46 minecraft:air
fill ~36 ~-35 ~46 ~39 ~-35 ~46 minecraft:polished_andesite
fill ~40 ~-35 ~46 ~41 ~-35 ~46 minecraft:air
setblock ~42 ~-35 ~46 minecraft:iron_bars[east=true]
setblock ~43 ~-35 ~46 minecraft:air
setblock ~44 ~-35 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-35 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~46 ~-35 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~47 ~-35 ~46 minecraft:air
setblock ~48 ~-35 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~49 ~-35 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~50 ~-35 ~46 minecraft:light_gray_concrete
setblock ~51 ~-35 ~46 minecraft:packed_ice
fill ~52 ~-35 ~46 ~53 ~-35 ~46 minecraft:air
setblock ~54 ~-35 ~46 minecraft:barrel
fill ~55 ~-35 ~46 ~56 ~-35 ~46 minecraft:air
setblock ~57 ~-35 ~46 minecraft:barrel
fill ~58 ~-35 ~46 ~59 ~-35 ~46 minecraft:air
setblock ~60 ~-35 ~46 minecraft:barrel
fill ~61 ~-35 ~46 ~62 ~-35 ~46 minecraft:air
setblock ~63 ~-35 ~46 minecraft:packed_ice
setblock ~64 ~-35 ~46 minecraft:light_gray_concrete
setblock ~4 ~-35 ~47 minecraft:light_gray_concrete
setblock ~5 ~-35 ~47 minecraft:barrel
fill ~6 ~-35 ~47 ~16 ~-35 ~47 minecraft:air
setblock ~17 ~-35 ~47 minecraft:barrel
setblock ~18 ~-35 ~47 minecraft:light_gray_concrete
fill ~19 ~-35 ~47 ~20 ~-35 ~47 minecraft:air
setblock ~21 ~-35 ~47 minecraft:iron_bars[north=true,east=true]
fill ~22 ~-35 ~47 ~23 ~-35 ~47 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-35 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-35 ~47 minecraft:iron_bars[west=true]
fill ~26 ~-35 ~47 ~31 ~-35 ~47 minecraft:air
setblock ~32 ~-35 ~47 minecraft:light_gray_concrete
fill ~33 ~-35 ~47 ~35 ~-35 ~47 minecraft:air
setblock ~36 ~-35 ~47 minecraft:light_gray_concrete
fill ~37 ~-35 ~47 ~40 ~-35 ~47 minecraft:air
setblock ~41 ~-35 ~47 minecraft:iron_bars[south=true]
fill ~42 ~-35 ~47 ~44 ~-35 ~47 minecraft:air
setblock ~45 ~-35 ~47 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-35 ~47 ~48 ~-35 ~47 minecraft:air
setblock ~49 ~-35 ~47 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-35 ~47 minecraft:light_gray_concrete
setblock ~51 ~-35 ~47 minecraft:packed_ice
fill ~52 ~-35 ~47 ~53 ~-35 ~47 minecraft:air
setblock ~54 ~-35 ~47 minecraft:barrel
fill ~55 ~-35 ~47 ~56 ~-35 ~47 minecraft:air
setblock ~57 ~-35 ~47 minecraft:barrel
fill ~58 ~-35 ~47 ~59 ~-35 ~47 minecraft:air
setblock ~60 ~-35 ~47 minecraft:barrel
fill ~61 ~-35 ~47 ~62 ~-35 ~47 minecraft:air
setblock ~63 ~-35 ~47 minecraft:packed_ice
setblock ~64 ~-35 ~47 minecraft:light_gray_concrete
setblock ~4 ~-35 ~48 minecraft:light_gray_concrete
setblock ~5 ~-35 ~48 minecraft:smooth_stone_slab[type=top]
fill ~6 ~-35 ~48 ~17 ~-35 ~48 minecraft:air
setblock ~18 ~-35 ~48 minecraft:light_gray_concrete
fill ~19 ~-35 ~48 ~40 ~-35 ~48 minecraft:air
setblock ~41 ~-35 ~48 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-35 ~48 ~44 ~-35 ~48 minecraft:air
setblock ~45 ~-35 ~48 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-35 ~48 ~48 ~-35 ~48 minecraft:air
setblock ~49 ~-35 ~48 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-35 ~48 minecraft:light_gray_concrete
fill ~51 ~-35 ~48 ~63 ~-35 ~48 minecraft:air
setblock ~64 ~-35 ~48 minecraft:light_gray_concrete
setblock ~4 ~-35 ~49 minecraft:light_gray_concrete
setblock ~5 ~-35 ~49 minecraft:air
setblock ~6 ~-35 ~49 minecraft:barrel
fill ~7 ~-35 ~49 ~8 ~-35 ~49 minecraft:air
setblock ~9 ~-35 ~49 minecraft:barrel
fill ~10 ~-35 ~49 ~14 ~-35 ~49 minecraft:air
setblock ~15 ~-35 ~49 minecraft:barrel
fill ~16 ~-35 ~49 ~17 ~-35 ~49 minecraft:air
setblock ~18 ~-35 ~49 minecraft:light_gray_concrete
fill ~19 ~-35 ~49 ~31 ~-35 ~49 minecraft:air
setblock ~32 ~-35 ~49 minecraft:light_gray_concrete
fill ~33 ~-35 ~49 ~35 ~-35 ~49 minecraft:air
setblock ~36 ~-35 ~49 minecraft:light_gray_concrete
fill ~37 ~-35 ~49 ~40 ~-35 ~49 minecraft:air
setblock ~41 ~-35 ~49 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-35 ~49 ~44 ~-35 ~49 minecraft:air
setblock ~45 ~-35 ~49 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-35 ~49 ~48 ~-35 ~49 minecraft:air
setblock ~49 ~-35 ~49 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-35 ~49 minecraft:light_gray_concrete
fill ~51 ~-35 ~49 ~53 ~-35 ~49 minecraft:packed_ice
setblock ~54 ~-35 ~49 minecraft:air
setblock ~55 ~-35 ~49 minecraft:packed_ice
fill ~56 ~-35 ~49 ~58 ~-35 ~49 minecraft:air
fill ~59 ~-35 ~49 ~61 ~-35 ~49 minecraft:packed_ice
setblock ~62 ~-35 ~49 minecraft:air
setblock ~63 ~-35 ~49 minecraft:packed_ice
setblock ~64 ~-35 ~49 minecraft:light_gray_concrete
fill ~4 ~-35 ~50 ~10 ~-35 ~50 minecraft:light_gray_concrete
setblock ~11 ~-35 ~50 minecraft:air
fill ~12 ~-35 ~50 ~32 ~-35 ~50 minecraft:light_gray_concrete
fill ~33 ~-35 ~50 ~35 ~-35 ~50 minecraft:air
fill ~36 ~-35 ~50 ~56 ~-35 ~50 minecraft:light_gray_concrete
setblock ~57 ~-35 ~50 minecraft:air
fill ~58 ~-35 ~50 ~64 ~-35 ~50 minecraft:light_gray_concrete
setblock ~4 ~-35 ~51 minecraft:light_gray_concrete
fill ~5 ~-35 ~51 ~17 ~-35 ~51 minecraft:air
setblock ~18 ~-35 ~51 minecraft:light_gray_concrete
setblock ~19 ~-35 ~51 minecraft:chest[facing=south]
setblock ~20 ~-35 ~51 minecraft:air
setblock ~21 ~-35 ~51 minecraft:chest[facing=south]
setblock ~22 ~-35 ~51 minecraft:air
setblock ~23 ~-35 ~51 minecraft:chest[facing=south]
setblock ~24 ~-35 ~51 minecraft:air
setblock ~25 ~-35 ~51 minecraft:chest[facing=south]
setblock ~26 ~-35 ~51 minecraft:air
setblock ~27 ~-35 ~51 minecraft:chest[facing=south]
setblock ~28 ~-35 ~51 minecraft:air
setblock ~29 ~-35 ~51 minecraft:chest[facing=south]
setblock ~30 ~-35 ~51 minecraft:air
setblock ~31 ~-35 ~51 minecraft:chest[facing=south]
setblock ~32 ~-35 ~51 minecraft:light_gray_concrete
fill ~33 ~-35 ~51 ~35 ~-35 ~51 minecraft:air
setblock ~36 ~-35 ~51 minecraft:light_gray_concrete
setblock ~37 ~-35 ~51 minecraft:cauldron
fill ~38 ~-35 ~51 ~40 ~-35 ~51 minecraft:air
setblock ~41 ~-35 ~51 minecraft:cauldron
fill ~42 ~-35 ~51 ~44 ~-35 ~51 minecraft:air
setblock ~45 ~-35 ~51 minecraft:cauldron
fill ~46 ~-35 ~51 ~48 ~-35 ~51 minecraft:air
setblock ~49 ~-35 ~51 minecraft:cauldron
setblock ~50 ~-35 ~51 minecraft:light_gray_concrete
fill ~51 ~-35 ~51 ~53 ~-35 ~51 minecraft:air
setblock ~54 ~-35 ~51 minecraft:cauldron
fill ~55 ~-35 ~51 ~61 ~-35 ~51 minecraft:air
setblock ~62 ~-35 ~51 minecraft:cauldron
setblock ~63 ~-35 ~51 minecraft:air
setblock ~64 ~-35 ~51 minecraft:light_gray_concrete
setblock ~4 ~-35 ~52 minecraft:light_gray_concrete
setblock ~5 ~-35 ~52 minecraft:iron_block
setblock ~6 ~-35 ~52 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~52 ~15 ~-35 ~52 minecraft:air
setblock ~16 ~-35 ~52 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~52 minecraft:iron_block
setblock ~18 ~-35 ~52 minecraft:light_gray_concrete
setblock ~19 ~-35 ~52 minecraft:air
fill ~20 ~-35 ~52 ~23 ~-35 ~52 minecraft:barrel
setblock ~24 ~-35 ~52 minecraft:air
fill ~25 ~-35 ~52 ~28 ~-35 ~52 minecraft:barrel
setblock ~29 ~-35 ~52 minecraft:air
setblock ~30 ~-35 ~52 minecraft:barrel
setblock ~31 ~-35 ~52 minecraft:air
setblock ~32 ~-35 ~52 minecraft:light_gray_concrete
fill ~33 ~-35 ~52 ~35 ~-35 ~52 minecraft:air
setblock ~36 ~-35 ~52 minecraft:light_gray_concrete
fill ~37 ~-35 ~52 ~49 ~-35 ~52 minecraft:air
setblock ~50 ~-35 ~52 minecraft:light_gray_concrete
fill ~51 ~-35 ~52 ~63 ~-35 ~52 minecraft:air
setblock ~64 ~-35 ~52 minecraft:light_gray_concrete
setblock ~4 ~-35 ~53 minecraft:light_gray_concrete
setblock ~5 ~-35 ~53 minecraft:iron_block
setblock ~6 ~-35 ~53 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~53 ~15 ~-35 ~53 minecraft:air
setblock ~16 ~-35 ~53 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~53 minecraft:iron_block
setblock ~18 ~-35 ~53 minecraft:light_gray_concrete
setblock ~19 ~-35 ~53 minecraft:chest[facing=east]
fill ~20 ~-35 ~53 ~30 ~-35 ~53 minecraft:air
setblock ~31 ~-35 ~53 minecraft:chest[facing=west]
setblock ~32 ~-35 ~53 minecraft:light_gray_concrete
fill ~33 ~-35 ~53 ~35 ~-35 ~53 minecraft:air
setblock ~36 ~-35 ~53 minecraft:light_gray_concrete
fill ~37 ~-35 ~53 ~49 ~-35 ~53 minecraft:air
setblock ~50 ~-35 ~53 minecraft:light_gray_concrete
fill ~51 ~-35 ~53 ~63 ~-35 ~53 minecraft:air
setblock ~64 ~-35 ~53 minecraft:light_gray_concrete
setblock ~4 ~-35 ~54 minecraft:light_gray_concrete
setblock ~5 ~-35 ~54 minecraft:iron_block
setblock ~6 ~-35 ~54 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~54 ~15 ~-35 ~54 minecraft:air
setblock ~16 ~-35 ~54 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~54 minecraft:iron_block
setblock ~18 ~-35 ~54 minecraft:light_gray_concrete
fill ~19 ~-35 ~54 ~31 ~-35 ~54 minecraft:air
setblock ~32 ~-35 ~54 minecraft:light_gray_concrete
fill ~33 ~-35 ~54 ~35 ~-35 ~54 minecraft:air
setblock ~36 ~-35 ~54 minecraft:light_gray_concrete
fill ~37 ~-35 ~54 ~38 ~-35 ~54 minecraft:air
setblock ~39 ~-35 ~54 minecraft:iron_trapdoor[half=bottom]
setblock ~40 ~-35 ~54 minecraft:white_stained_glass_pane
setblock ~41 ~-35 ~54 minecraft:air
setblock ~42 ~-35 ~54 minecraft:iron_trapdoor[half=bottom]
setblock ~43 ~-35 ~54 minecraft:white_stained_glass_pane
setblock ~44 ~-35 ~54 minecraft:air
setblock ~45 ~-35 ~54 minecraft:iron_trapdoor[half=bottom]
setblock ~46 ~-35 ~54 minecraft:white_stained_glass_pane
setblock ~47 ~-35 ~54 minecraft:air
setblock ~48 ~-35 ~54 minecraft:iron_trapdoor[half=bottom]
setblock ~49 ~-35 ~54 minecraft:white_stained_glass_pane[east=true,south=true]
setblock ~50 ~-35 ~54 minecraft:light_gray_concrete
setblock ~51 ~-35 ~54 minecraft:cauldron
fill ~52 ~-35 ~54 ~62 ~-35 ~54 minecraft:air
setblock ~63 ~-35 ~54 minecraft:cauldron
setblock ~64 ~-35 ~54 minecraft:light_gray_concrete
setblock ~4 ~-35 ~55 minecraft:light_gray_concrete
setblock ~5 ~-35 ~55 minecraft:iron_block
setblock ~6 ~-35 ~55 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~55 ~15 ~-35 ~55 minecraft:air
setblock ~16 ~-35 ~55 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~55 minecraft:iron_block
setblock ~18 ~-35 ~55 minecraft:light_gray_concrete
setblock ~19 ~-35 ~55 minecraft:chest[facing=east]
fill ~20 ~-35 ~55 ~23 ~-35 ~55 minecraft:barrel
setblock ~24 ~-35 ~55 minecraft:air
fill ~25 ~-35 ~55 ~28 ~-35 ~55 minecraft:barrel
setblock ~29 ~-35 ~55 minecraft:air
setblock ~30 ~-35 ~55 minecraft:barrel
setblock ~31 ~-35 ~55 minecraft:chest[facing=west]
setblock ~32 ~-35 ~55 minecraft:light_gray_concrete
fill ~33 ~-35 ~55 ~35 ~-35 ~55 minecraft:air
setblock ~36 ~-35 ~55 minecraft:light_gray_concrete
setblock ~37 ~-35 ~55 minecraft:cauldron
setblock ~38 ~-35 ~55 minecraft:air
setblock ~39 ~-35 ~55 minecraft:white_stained_glass_pane
fill ~40 ~-35 ~55 ~41 ~-35 ~55 minecraft:air
setblock ~42 ~-35 ~55 minecraft:white_stained_glass_pane
fill ~43 ~-35 ~55 ~44 ~-35 ~55 minecraft:air
setblock ~45 ~-35 ~55 minecraft:white_stained_glass_pane
fill ~46 ~-35 ~55 ~47 ~-35 ~55 minecraft:air
setblock ~48 ~-35 ~55 minecraft:white_stained_glass_pane[east=true]
setblock ~49 ~-35 ~55 minecraft:cauldron
setblock ~50 ~-35 ~55 minecraft:light_gray_concrete
fill ~51 ~-35 ~55 ~63 ~-35 ~55 minecraft:air
setblock ~64 ~-35 ~55 minecraft:light_gray_concrete
setblock ~4 ~-35 ~56 minecraft:light_gray_concrete
setblock ~5 ~-35 ~56 minecraft:iron_block
setblock ~6 ~-35 ~56 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~56 ~17 ~-35 ~56 minecraft:air
setblock ~18 ~-35 ~56 minecraft:light_gray_concrete
fill ~19 ~-35 ~56 ~31 ~-35 ~56 minecraft:air
setblock ~32 ~-35 ~56 minecraft:light_gray_concrete
fill ~33 ~-35 ~56 ~35 ~-35 ~56 minecraft:air
setblock ~36 ~-35 ~56 minecraft:light_gray_concrete
fill ~37 ~-35 ~56 ~49 ~-35 ~56 minecraft:air
setblock ~50 ~-35 ~56 minecraft:light_gray_concrete
fill ~51 ~-35 ~56 ~63 ~-35 ~56 minecraft:air
setblock ~64 ~-35 ~56 minecraft:light_gray_concrete
setblock ~4 ~-35 ~57 minecraft:light_gray_concrete
setblock ~5 ~-35 ~57 minecraft:iron_block
setblock ~6 ~-35 ~57 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~57 ~8 ~-35 ~57 minecraft:air
setblock ~9 ~-35 ~57 minecraft:smooth_stone_slab[type=top]
fill ~10 ~-35 ~57 ~12 ~-35 ~57 minecraft:air
setblock ~13 ~-35 ~57 minecraft:smooth_stone_slab[type=top]
fill ~14 ~-35 ~57 ~38 ~-35 ~57 minecraft:air
setblock ~39 ~-35 ~57 minecraft:iron_trapdoor[half=bottom]
setblock ~40 ~-35 ~57 minecraft:white_stained_glass_pane
setblock ~41 ~-35 ~57 minecraft:air
setblock ~42 ~-35 ~57 minecraft:iron_trapdoor[half=bottom]
setblock ~43 ~-35 ~57 minecraft:white_stained_glass_pane
setblock ~44 ~-35 ~57 minecraft:air
setblock ~45 ~-35 ~57 minecraft:iron_trapdoor[half=bottom]
setblock ~46 ~-35 ~57 minecraft:white_stained_glass_pane
fill ~47 ~-35 ~57 ~54 ~-35 ~57 minecraft:air
fill ~55 ~-35 ~57 ~59 ~-35 ~57 minecraft:smooth_stone_slab[type=top]
fill ~60 ~-35 ~57 ~63 ~-35 ~57 minecraft:air
setblock ~64 ~-35 ~57 minecraft:light_gray_concrete
setblock ~4 ~-35 ~58 minecraft:light_gray_concrete
setblock ~5 ~-35 ~58 minecraft:iron_block
setblock ~6 ~-35 ~58 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~58 ~17 ~-35 ~58 minecraft:air
setblock ~18 ~-35 ~58 minecraft:light_gray_concrete
setblock ~19 ~-35 ~58 minecraft:air
fill ~20 ~-35 ~58 ~23 ~-35 ~58 minecraft:barrel
setblock ~24 ~-35 ~58 minecraft:air
fill ~25 ~-35 ~58 ~28 ~-35 ~58 minecraft:barrel
setblock ~29 ~-35 ~58 minecraft:air
setblock ~30 ~-35 ~58 minecraft:barrel
setblock ~31 ~-35 ~58 minecraft:air
setblock ~32 ~-35 ~58 minecraft:light_gray_concrete
fill ~33 ~-35 ~58 ~35 ~-35 ~58 minecraft:air
setblock ~36 ~-35 ~58 minecraft:light_gray_concrete
fill ~37 ~-35 ~58 ~38 ~-35 ~58 minecraft:air
setblock ~39 ~-35 ~58 minecraft:white_stained_glass_pane
fill ~40 ~-35 ~58 ~41 ~-35 ~58 minecraft:air
setblock ~42 ~-35 ~58 minecraft:white_stained_glass_pane
fill ~43 ~-35 ~58 ~44 ~-35 ~58 minecraft:air
setblock ~45 ~-35 ~58 minecraft:white_stained_glass_pane
fill ~46 ~-35 ~58 ~49 ~-35 ~58 minecraft:air
setblock ~50 ~-35 ~58 minecraft:light_gray_concrete
fill ~51 ~-35 ~58 ~62 ~-35 ~58 minecraft:air
setblock ~63 ~-35 ~58 minecraft:cauldron
setblock ~64 ~-35 ~58 minecraft:light_gray_concrete
setblock ~4 ~-35 ~59 minecraft:light_gray_concrete
setblock ~5 ~-35 ~59 minecraft:iron_block
setblock ~6 ~-35 ~59 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~59 ~15 ~-35 ~59 minecraft:air
setblock ~16 ~-35 ~59 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~59 minecraft:iron_block
setblock ~18 ~-35 ~59 minecraft:light_gray_concrete
setblock ~19 ~-35 ~59 minecraft:chest[facing=east]
fill ~20 ~-35 ~59 ~30 ~-35 ~59 minecraft:air
setblock ~31 ~-35 ~59 minecraft:chest[facing=west]
setblock ~32 ~-35 ~59 minecraft:light_gray_concrete
fill ~33 ~-35 ~59 ~35 ~-35 ~59 minecraft:air
setblock ~36 ~-35 ~59 minecraft:light_gray_concrete
setblock ~37 ~-35 ~59 minecraft:cauldron
fill ~38 ~-35 ~59 ~48 ~-35 ~59 minecraft:air
setblock ~49 ~-35 ~59 minecraft:cauldron
setblock ~50 ~-35 ~59 minecraft:light_gray_concrete
fill ~51 ~-35 ~59 ~63 ~-35 ~59 minecraft:air
setblock ~64 ~-35 ~59 minecraft:light_gray_concrete
setblock ~4 ~-35 ~60 minecraft:light_gray_concrete
setblock ~5 ~-35 ~60 minecraft:iron_block
setblock ~6 ~-35 ~60 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~60 ~15 ~-35 ~60 minecraft:air
setblock ~16 ~-35 ~60 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~60 minecraft:iron_block
setblock ~18 ~-35 ~60 minecraft:light_gray_concrete
fill ~19 ~-35 ~60 ~31 ~-35 ~60 minecraft:air
setblock ~32 ~-35 ~60 minecraft:light_gray_concrete
fill ~33 ~-35 ~60 ~35 ~-35 ~60 minecraft:air
setblock ~36 ~-35 ~60 minecraft:light_gray_concrete
fill ~37 ~-35 ~60 ~38 ~-35 ~60 minecraft:air
setblock ~39 ~-35 ~60 minecraft:iron_trapdoor[half=bottom]
setblock ~40 ~-35 ~60 minecraft:white_stained_glass_pane
setblock ~41 ~-35 ~60 minecraft:air
setblock ~42 ~-35 ~60 minecraft:iron_trapdoor[half=bottom]
setblock ~43 ~-35 ~60 minecraft:white_stained_glass_pane
setblock ~44 ~-35 ~60 minecraft:air
setblock ~45 ~-35 ~60 minecraft:iron_trapdoor[half=bottom]
setblock ~46 ~-35 ~60 minecraft:white_stained_glass_pane
setblock ~47 ~-35 ~60 minecraft:air
setblock ~48 ~-35 ~60 minecraft:iron_trapdoor[half=bottom]
setblock ~49 ~-35 ~60 minecraft:white_stained_glass_pane[north=true,east=true]
setblock ~50 ~-35 ~60 minecraft:light_gray_concrete
fill ~51 ~-35 ~60 ~63 ~-35 ~60 minecraft:air
setblock ~64 ~-35 ~60 minecraft:light_gray_concrete
setblock ~4 ~-35 ~61 minecraft:light_gray_concrete
setblock ~5 ~-35 ~61 minecraft:iron_block
setblock ~6 ~-35 ~61 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~61 ~15 ~-35 ~61 minecraft:air
setblock ~16 ~-35 ~61 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~61 minecraft:iron_block
setblock ~18 ~-35 ~61 minecraft:light_gray_concrete
setblock ~19 ~-35 ~61 minecraft:chest[facing=east]
fill ~20 ~-35 ~61 ~23 ~-35 ~61 minecraft:barrel
setblock ~24 ~-35 ~61 minecraft:air
fill ~25 ~-35 ~61 ~28 ~-35 ~61 minecraft:barrel
setblock ~29 ~-35 ~61 minecraft:air
setblock ~30 ~-35 ~61 minecraft:barrel
setblock ~31 ~-35 ~61 minecraft:chest[facing=west]
setblock ~32 ~-35 ~61 minecraft:light_gray_concrete
fill ~33 ~-35 ~61 ~35 ~-35 ~61 minecraft:air
setblock ~36 ~-35 ~61 minecraft:light_gray_concrete
fill ~37 ~-35 ~61 ~38 ~-35 ~61 minecraft:air
setblock ~39 ~-35 ~61 minecraft:white_stained_glass_pane
fill ~40 ~-35 ~61 ~41 ~-35 ~61 minecraft:air
setblock ~42 ~-35 ~61 minecraft:white_stained_glass_pane
fill ~43 ~-35 ~61 ~44 ~-35 ~61 minecraft:air
setblock ~45 ~-35 ~61 minecraft:white_stained_glass_pane
fill ~46 ~-35 ~61 ~47 ~-35 ~61 minecraft:air
setblock ~48 ~-35 ~61 minecraft:white_stained_glass_pane
setblock ~49 ~-35 ~61 minecraft:air
setblock ~50 ~-35 ~61 minecraft:light_gray_concrete
fill ~51 ~-35 ~61 ~63 ~-35 ~61 minecraft:air
setblock ~64 ~-35 ~61 minecraft:light_gray_concrete
setblock ~4 ~-35 ~62 minecraft:light_gray_concrete
setblock ~5 ~-35 ~62 minecraft:iron_block
setblock ~6 ~-35 ~62 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-35 ~62 ~15 ~-35 ~62 minecraft:iron_trapdoor[open=true,facing=north]
setblock ~16 ~-35 ~62 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~62 minecraft:iron_block
setblock ~18 ~-35 ~62 minecraft:light_gray_concrete
fill ~19 ~-35 ~62 ~31 ~-35 ~62 minecraft:air
setblock ~32 ~-35 ~62 minecraft:light_gray_concrete
fill ~33 ~-35 ~62 ~35 ~-35 ~62 minecraft:air
setblock ~36 ~-35 ~62 minecraft:light_gray_concrete
fill ~37 ~-35 ~62 ~49 ~-35 ~62 minecraft:air
setblock ~50 ~-35 ~62 minecraft:light_gray_concrete
setblock ~51 ~-35 ~62 minecraft:cauldron
fill ~52 ~-35 ~62 ~62 ~-35 ~62 minecraft:air
setblock ~63 ~-35 ~62 minecraft:cauldron
setblock ~64 ~-35 ~62 minecraft:light_gray_concrete
setblock ~4 ~-35 ~63 minecraft:light_gray_concrete
fill ~5 ~-35 ~63 ~6 ~-35 ~63 minecraft:air
fill ~7 ~-35 ~63 ~15 ~-35 ~63 minecraft:iron_block
setblock ~16 ~-35 ~63 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-35 ~63 minecraft:iron_block
setblock ~18 ~-35 ~63 minecraft:light_gray_concrete
setblock ~19 ~-35 ~63 minecraft:chest[facing=north]
setblock ~20 ~-35 ~63 minecraft:air
setblock ~21 ~-35 ~63 minecraft:chest[facing=north]
setblock ~22 ~-35 ~63 minecraft:air
setblock ~23 ~-35 ~63 minecraft:chest[facing=north]
setblock ~24 ~-35 ~63 minecraft:air
setblock ~25 ~-35 ~63 minecraft:chest[facing=north]
setblock ~26 ~-35 ~63 minecraft:air
setblock ~27 ~-35 ~63 minecraft:chest[facing=north]
setblock ~28 ~-35 ~63 minecraft:air
setblock ~29 ~-35 ~63 minecraft:chest[facing=north]
setblock ~30 ~-35 ~63 minecraft:air
setblock ~31 ~-35 ~63 minecraft:chest[facing=west]
setblock ~32 ~-35 ~63 minecraft:light_gray_concrete
fill ~33 ~-35 ~63 ~35 ~-35 ~63 minecraft:air
setblock ~36 ~-35 ~63 minecraft:light_gray_concrete
setblock ~37 ~-35 ~63 minecraft:cauldron
fill ~38 ~-35 ~63 ~40 ~-35 ~63 minecraft:air
setblock ~41 ~-35 ~63 minecraft:cauldron
fill ~42 ~-35 ~63 ~44 ~-35 ~63 minecraft:air
setblock ~45 ~-35 ~63 minecraft:cauldron
fill ~46 ~-35 ~63 ~48 ~-35 ~63 minecraft:air
setblock ~49 ~-35 ~63 minecraft:cauldron
setblock ~50 ~-35 ~63 minecraft:light_gray_concrete
fill ~51 ~-35 ~63 ~53 ~-35 ~63 minecraft:air
setblock ~54 ~-35 ~63 minecraft:cauldron
fill ~55 ~-35 ~63 ~57 ~-35 ~63 minecraft:air
setblock ~58 ~-35 ~63 minecraft:cauldron
fill ~59 ~-35 ~63 ~61 ~-35 ~63 minecraft:air
setblock ~62 ~-35 ~63 minecraft:cauldron
setblock ~63 ~-35 ~63 minecraft:air
setblock ~64 ~-35 ~63 minecraft:light_gray_concrete
fill ~4 ~-35 ~64 ~33 ~-35 ~64 minecraft:light_gray_concrete
setblock ~34 ~-35 ~64 minecraft:air
fill ~35 ~-35 ~64 ~64 ~-35 ~64 minecraft:light_gray_concrete
setblock ~33 ~-35 ~65 minecraft:light_gray_concrete
setblock ~34 ~-35 ~65 minecraft:air
setblock ~35 ~-35 ~65 minecraft:light_gray_concrete
fill ~32 ~-35 ~66 ~33 ~-35 ~66 minecraft:polished_andesite
setblock ~34 ~-35 ~66 minecraft:air
fill ~35 ~-35 ~66 ~36 ~-35 ~66 minecraft:polished_andesite
setblock ~32 ~-35 ~67 minecraft:polished_andesite
fill ~33 ~-35 ~67 ~34 ~-35 ~67 minecraft:air
setblock ~35 ~-35 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-35 ~67 minecraft:polished_andesite
setblock ~32 ~-35 ~68 minecraft:polished_andesite
setblock ~33 ~-35 ~68 minecraft:air
setblock ~34 ~-35 ~68 minecraft:quartz_pillar
setblock ~35 ~-35 ~68 minecraft:air
setblock ~36 ~-35 ~68 minecraft:polished_andesite
setblock ~32 ~-35 ~69 minecraft:polished_andesite
fill ~33 ~-35 ~69 ~35 ~-35 ~69 minecraft:air
setblock ~36 ~-35 ~69 minecraft:polished_andesite
fill ~32 ~-35 ~70 ~36 ~-35 ~70 minecraft:polished_andesite
fill ~4 ~-34 ~4 ~64 ~-34 ~4 minecraft:light_gray_concrete
setblock ~4 ~-34 ~5 minecraft:light_gray_concrete
setblock ~5 ~-34 ~5 minecraft:iron_block
setblock ~6 ~-34 ~5 minecraft:air
setblock ~7 ~-34 ~5 minecraft:iron_block
setblock ~8 ~-34 ~5 minecraft:air
setblock ~9 ~-34 ~5 minecraft:iron_block
setblock ~10 ~-34 ~5 minecraft:air
setblock ~11 ~-34 ~5 minecraft:iron_block
setblock ~12 ~-34 ~5 minecraft:air
setblock ~13 ~-34 ~5 minecraft:iron_block
setblock ~14 ~-34 ~5 minecraft:air
setblock ~15 ~-34 ~5 minecraft:iron_block
setblock ~16 ~-34 ~5 minecraft:air
setblock ~17 ~-34 ~5 minecraft:iron_block
setblock ~18 ~-34 ~5 minecraft:light_gray_concrete
fill ~19 ~-34 ~5 ~31 ~-34 ~5 minecraft:air
setblock ~32 ~-34 ~5 minecraft:red_concrete
fill ~33 ~-34 ~5 ~35 ~-34 ~5 minecraft:air
setblock ~36 ~-34 ~5 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~5 ~49 ~-34 ~5 minecraft:air
setblock ~50 ~-34 ~5 minecraft:light_gray_concrete
setblock ~51 ~-34 ~5 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-34 ~5 ~54 ~-34 ~5 minecraft:air
setblock ~55 ~-34 ~5 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-34 ~5 ~58 ~-34 ~5 minecraft:air
setblock ~59 ~-34 ~5 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-34 ~5 ~62 ~-34 ~5 minecraft:air
setblock ~63 ~-34 ~5 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-34 ~5 minecraft:light_gray_concrete
setblock ~4 ~-34 ~6 minecraft:light_gray_concrete
fill ~5 ~-34 ~6 ~17 ~-34 ~6 minecraft:air
setblock ~18 ~-34 ~6 minecraft:light_gray_concrete
fill ~19 ~-34 ~6 ~31 ~-34 ~6 minecraft:air
setblock ~32 ~-34 ~6 minecraft:red_concrete
fill ~33 ~-34 ~6 ~35 ~-34 ~6 minecraft:air
setblock ~36 ~-34 ~6 minecraft:red_concrete
fill ~37 ~-34 ~6 ~49 ~-34 ~6 minecraft:air
setblock ~50 ~-34 ~6 minecraft:light_gray_concrete
setblock ~51 ~-34 ~6 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-34 ~6 ~54 ~-34 ~6 minecraft:air
setblock ~55 ~-34 ~6 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-34 ~6 ~58 ~-34 ~6 minecraft:air
setblock ~59 ~-34 ~6 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-34 ~6 ~62 ~-34 ~6 minecraft:air
setblock ~63 ~-34 ~6 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-34 ~6 minecraft:light_gray_concrete
setblock ~4 ~-34 ~7 minecraft:light_gray_concrete
setblock ~5 ~-34 ~7 minecraft:iron_block
fill ~6 ~-34 ~7 ~16 ~-34 ~7 minecraft:air
setblock ~17 ~-34 ~7 minecraft:iron_block
setblock ~18 ~-34 ~7 minecraft:light_gray_concrete
fill ~19 ~-34 ~7 ~31 ~-34 ~7 minecraft:air
setblock ~32 ~-34 ~7 minecraft:red_concrete
fill ~33 ~-34 ~7 ~35 ~-34 ~7 minecraft:air
setblock ~36 ~-34 ~7 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~7 ~49 ~-34 ~7 minecraft:air
setblock ~50 ~-34 ~7 minecraft:light_gray_concrete
setblock ~51 ~-34 ~7 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-34 ~7 ~54 ~-34 ~7 minecraft:air
setblock ~55 ~-34 ~7 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-34 ~7 ~58 ~-34 ~7 minecraft:air
setblock ~59 ~-34 ~7 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-34 ~7 ~62 ~-34 ~7 minecraft:air
setblock ~63 ~-34 ~7 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-34 ~7 minecraft:light_gray_concrete
setblock ~4 ~-34 ~8 minecraft:light_gray_concrete
fill ~5 ~-34 ~8 ~17 ~-34 ~8 minecraft:air
setblock ~18 ~-34 ~8 minecraft:light_gray_concrete
fill ~19 ~-34 ~8 ~31 ~-34 ~8 minecraft:air
setblock ~32 ~-34 ~8 minecraft:red_concrete
fill ~33 ~-34 ~8 ~35 ~-34 ~8 minecraft:air
setblock ~36 ~-34 ~8 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~8 ~49 ~-34 ~8 minecraft:air
setblock ~50 ~-34 ~8 minecraft:light_gray_concrete
setblock ~51 ~-34 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~52 ~-34 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~53 ~-34 ~8 minecraft:air
setblock ~54 ~-34 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~55 ~-34 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~56 ~-34 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~57 ~-34 ~8 minecraft:air
setblock ~58 ~-34 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~59 ~-34 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~60 ~-34 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~61 ~-34 ~8 minecraft:air
setblock ~62 ~-34 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~63 ~-34 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~64 ~-34 ~8 minecraft:light_gray_concrete
setblock ~4 ~-34 ~9 minecraft:light_gray_concrete
setblock ~5 ~-34 ~9 minecraft:iron_block
fill ~6 ~-34 ~9 ~16 ~-34 ~9 minecraft:air
setblock ~17 ~-34 ~9 minecraft:iron_block
setblock ~18 ~-34 ~9 minecraft:light_gray_concrete
fill ~19 ~-34 ~9 ~31 ~-34 ~9 minecraft:air
setblock ~32 ~-34 ~9 minecraft:red_concrete
fill ~33 ~-34 ~9 ~35 ~-34 ~9 minecraft:air
setblock ~36 ~-34 ~9 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~9 ~49 ~-34 ~9 minecraft:air
setblock ~50 ~-34 ~9 minecraft:light_gray_concrete
fill ~51 ~-34 ~9 ~63 ~-34 ~9 minecraft:air
setblock ~64 ~-34 ~9 minecraft:light_gray_concrete
setblock ~4 ~-34 ~10 minecraft:light_gray_concrete
fill ~5 ~-34 ~10 ~17 ~-34 ~10 minecraft:air
setblock ~18 ~-34 ~10 minecraft:light_gray_concrete
fill ~19 ~-34 ~10 ~31 ~-34 ~10 minecraft:air
setblock ~32 ~-34 ~10 minecraft:red_concrete
fill ~33 ~-34 ~10 ~35 ~-34 ~10 minecraft:air
setblock ~36 ~-34 ~10 minecraft:red_concrete
fill ~37 ~-34 ~10 ~49 ~-34 ~10 minecraft:air
setblock ~50 ~-34 ~10 minecraft:light_gray_concrete
fill ~51 ~-34 ~10 ~63 ~-34 ~10 minecraft:air
setblock ~64 ~-34 ~10 minecraft:light_gray_concrete
setblock ~4 ~-34 ~11 minecraft:light_gray_concrete
setblock ~5 ~-34 ~11 minecraft:iron_block
fill ~6 ~-34 ~11 ~10 ~-34 ~11 minecraft:air
setblock ~11 ~-34 ~11 minecraft:white_carpet
setblock ~12 ~-34 ~11 minecraft:air
setblock ~13 ~-34 ~11 minecraft:black_concrete
fill ~14 ~-34 ~11 ~63 ~-34 ~11 minecraft:air
setblock ~64 ~-34 ~11 minecraft:light_gray_concrete
setblock ~4 ~-34 ~12 minecraft:light_gray_concrete
fill ~5 ~-34 ~12 ~10 ~-34 ~12 minecraft:air
setblock ~11 ~-34 ~12 minecraft:white_carpet
fill ~12 ~-34 ~12 ~17 ~-34 ~12 minecraft:air
setblock ~18 ~-34 ~12 minecraft:light_gray_concrete
fill ~19 ~-34 ~12 ~31 ~-34 ~12 minecraft:air
setblock ~32 ~-34 ~12 minecraft:red_concrete
fill ~33 ~-34 ~12 ~35 ~-34 ~12 minecraft:air
setblock ~36 ~-34 ~12 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~12 ~49 ~-34 ~12 minecraft:air
setblock ~50 ~-34 ~12 minecraft:light_gray_concrete
fill ~51 ~-34 ~12 ~56 ~-34 ~12 minecraft:air
setblock ~57 ~-34 ~12 minecraft:black_concrete
fill ~58 ~-34 ~12 ~63 ~-34 ~12 minecraft:air
setblock ~64 ~-34 ~12 minecraft:light_gray_concrete
setblock ~4 ~-34 ~13 minecraft:light_gray_concrete
setblock ~5 ~-34 ~13 minecraft:iron_block
fill ~6 ~-34 ~13 ~16 ~-34 ~13 minecraft:air
setblock ~17 ~-34 ~13 minecraft:iron_block
setblock ~18 ~-34 ~13 minecraft:light_gray_concrete
fill ~19 ~-34 ~13 ~31 ~-34 ~13 minecraft:air
setblock ~32 ~-34 ~13 minecraft:red_concrete
fill ~33 ~-34 ~13 ~35 ~-34 ~13 minecraft:air
setblock ~36 ~-34 ~13 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~13 ~49 ~-34 ~13 minecraft:air
setblock ~50 ~-34 ~13 minecraft:light_gray_concrete
fill ~51 ~-34 ~13 ~63 ~-34 ~13 minecraft:air
setblock ~64 ~-34 ~13 minecraft:light_gray_concrete
setblock ~4 ~-34 ~14 minecraft:light_gray_concrete
fill ~5 ~-34 ~14 ~17 ~-34 ~14 minecraft:air
setblock ~18 ~-34 ~14 minecraft:light_gray_concrete
fill ~19 ~-34 ~14 ~31 ~-34 ~14 minecraft:air
setblock ~32 ~-34 ~14 minecraft:red_concrete
fill ~33 ~-34 ~14 ~35 ~-34 ~14 minecraft:air
setblock ~36 ~-34 ~14 minecraft:red_concrete
fill ~37 ~-34 ~14 ~49 ~-34 ~14 minecraft:air
setblock ~50 ~-34 ~14 minecraft:light_gray_concrete
fill ~51 ~-34 ~14 ~63 ~-34 ~14 minecraft:air
setblock ~64 ~-34 ~14 minecraft:light_gray_concrete
setblock ~4 ~-34 ~15 minecraft:light_gray_concrete
setblock ~5 ~-34 ~15 minecraft:iron_block
fill ~6 ~-34 ~15 ~16 ~-34 ~15 minecraft:air
setblock ~17 ~-34 ~15 minecraft:iron_block
setblock ~18 ~-34 ~15 minecraft:light_gray_concrete
fill ~19 ~-34 ~15 ~31 ~-34 ~15 minecraft:air
setblock ~32 ~-34 ~15 minecraft:red_concrete
fill ~33 ~-34 ~15 ~35 ~-34 ~15 minecraft:air
setblock ~36 ~-34 ~15 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~15 ~49 ~-34 ~15 minecraft:air
setblock ~50 ~-34 ~15 minecraft:light_gray_concrete
fill ~51 ~-34 ~15 ~63 ~-34 ~15 minecraft:air
setblock ~64 ~-34 ~15 minecraft:light_gray_concrete
setblock ~4 ~-34 ~16 minecraft:light_gray_concrete
fill ~5 ~-34 ~16 ~17 ~-34 ~16 minecraft:air
setblock ~18 ~-34 ~16 minecraft:light_gray_concrete
fill ~19 ~-34 ~16 ~31 ~-34 ~16 minecraft:air
setblock ~32 ~-34 ~16 minecraft:red_concrete
fill ~33 ~-34 ~16 ~35 ~-34 ~16 minecraft:air
setblock ~36 ~-34 ~16 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~16 ~49 ~-34 ~16 minecraft:air
setblock ~50 ~-34 ~16 minecraft:light_gray_concrete
fill ~51 ~-34 ~16 ~63 ~-34 ~16 minecraft:air
setblock ~64 ~-34 ~16 minecraft:light_gray_concrete
setblock ~4 ~-34 ~17 minecraft:light_gray_concrete
setblock ~5 ~-34 ~17 minecraft:iron_block
setblock ~6 ~-34 ~17 minecraft:air
setblock ~7 ~-34 ~17 minecraft:iron_block
setblock ~8 ~-34 ~17 minecraft:air
setblock ~9 ~-34 ~17 minecraft:iron_block
fill ~10 ~-34 ~17 ~12 ~-34 ~17 minecraft:air
setblock ~13 ~-34 ~17 minecraft:iron_block
setblock ~14 ~-34 ~17 minecraft:air
setblock ~15 ~-34 ~17 minecraft:iron_block
setblock ~16 ~-34 ~17 minecraft:air
setblock ~17 ~-34 ~17 minecraft:iron_block
setblock ~18 ~-34 ~17 minecraft:light_gray_concrete
fill ~19 ~-34 ~17 ~31 ~-34 ~17 minecraft:air
setblock ~32 ~-34 ~17 minecraft:red_concrete
fill ~33 ~-34 ~17 ~35 ~-34 ~17 minecraft:air
setblock ~36 ~-34 ~17 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~17 ~49 ~-34 ~17 minecraft:air
setblock ~50 ~-34 ~17 minecraft:light_gray_concrete
fill ~51 ~-34 ~17 ~63 ~-34 ~17 minecraft:air
setblock ~64 ~-34 ~17 minecraft:light_gray_concrete
fill ~4 ~-34 ~18 ~10 ~-34 ~18 minecraft:light_gray_concrete
setblock ~11 ~-34 ~18 minecraft:air
fill ~12 ~-34 ~18 ~31 ~-34 ~18 minecraft:light_gray_concrete
setblock ~32 ~-34 ~18 minecraft:red_concrete
fill ~33 ~-34 ~18 ~35 ~-34 ~18 minecraft:air
setblock ~36 ~-34 ~18 minecraft:red_concrete
fill ~37 ~-34 ~18 ~56 ~-34 ~18 minecraft:light_gray_concrete
setblock ~57 ~-34 ~18 minecraft:air
fill ~58 ~-34 ~18 ~64 ~-34 ~18 minecraft:light_gray_concrete
setblock ~4 ~-34 ~19 minecraft:light_gray_concrete
fill ~5 ~-34 ~19 ~9 ~-34 ~19 minecraft:iron_block
fill ~10 ~-34 ~19 ~12 ~-34 ~19 minecraft:air
fill ~13 ~-34 ~19 ~17 ~-34 ~19 minecraft:iron_block
setblock ~18 ~-34 ~19 minecraft:light_gray_concrete
setblock ~19 ~-34 ~19 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-34 ~19 ~22 ~-34 ~19 minecraft:air
setblock ~23 ~-34 ~19 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-34 ~19 ~26 ~-34 ~19 minecraft:air
setblock ~27 ~-34 ~19 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-34 ~19 ~31 ~-34 ~19 minecraft:air
setblock ~32 ~-34 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-34 ~19 ~35 ~-34 ~19 minecraft:air
setblock ~36 ~-34 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~19 ~49 ~-34 ~19 minecraft:air
setblock ~50 ~-34 ~19 minecraft:light_gray_concrete
setblock ~51 ~-34 ~19 minecraft:iron_block
setblock ~52 ~-34 ~19 minecraft:air
setblock ~53 ~-34 ~19 minecraft:iron_block
setblock ~54 ~-34 ~19 minecraft:air
setblock ~55 ~-34 ~19 minecraft:iron_block
fill ~56 ~-34 ~19 ~58 ~-34 ~19 minecraft:air
setblock ~59 ~-34 ~19 minecraft:iron_block
setblock ~60 ~-34 ~19 minecraft:air
setblock ~61 ~-34 ~19 minecraft:iron_block
setblock ~62 ~-34 ~19 minecraft:air
setblock ~63 ~-34 ~19 minecraft:iron_block
setblock ~64 ~-34 ~19 minecraft:light_gray_concrete
setblock ~4 ~-34 ~20 minecraft:light_gray_concrete
fill ~5 ~-34 ~20 ~9 ~-34 ~20 minecraft:iron_trapdoor[open=true,facing=south]
fill ~10 ~-34 ~20 ~12 ~-34 ~20 minecraft:air
fill ~13 ~-34 ~20 ~17 ~-34 ~20 minecraft:iron_trapdoor[open=true,facing=south]
setblock ~18 ~-34 ~20 minecraft:light_gray_concrete
setblock ~19 ~-34 ~20 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-34 ~20 ~22 ~-34 ~20 minecraft:air
setblock ~23 ~-34 ~20 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-34 ~20 ~26 ~-34 ~20 minecraft:air
setblock ~27 ~-34 ~20 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-34 ~20 ~49 ~-34 ~20 minecraft:air
setblock ~50 ~-34 ~20 minecraft:light_gray_concrete
fill ~51 ~-34 ~20 ~63 ~-34 ~20 minecraft:air
setblock ~64 ~-34 ~20 minecraft:light_gray_concrete
setblock ~4 ~-34 ~21 minecraft:light_gray_concrete
setblock ~5 ~-34 ~21 minecraft:iron_block
setblock ~6 ~-34 ~21 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~21 ~17 ~-34 ~21 minecraft:air
setblock ~18 ~-34 ~21 minecraft:light_gray_concrete
setblock ~19 ~-34 ~21 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-34 ~21 ~22 ~-34 ~21 minecraft:air
setblock ~23 ~-34 ~21 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-34 ~21 ~26 ~-34 ~21 minecraft:air
setblock ~27 ~-34 ~21 minecraft:iron_bars[north=true]
fill ~28 ~-34 ~21 ~31 ~-34 ~21 minecraft:air
setblock ~32 ~-34 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-34 ~21 ~35 ~-34 ~21 minecraft:air
setblock ~36 ~-34 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~21 ~42 ~-34 ~21 minecraft:air
setblock ~43 ~-34 ~21 minecraft:iron_bars[east=true]
setblock ~44 ~-34 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-34 ~21 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~46 ~-34 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~47 ~-34 ~21 minecraft:iron_bars[south=true,west=true]
fill ~48 ~-34 ~21 ~49 ~-34 ~21 minecraft:air
setblock ~50 ~-34 ~21 minecraft:light_gray_concrete
setblock ~51 ~-34 ~21 minecraft:iron_block
fill ~52 ~-34 ~21 ~62 ~-34 ~21 minecraft:air
setblock ~63 ~-34 ~21 minecraft:iron_block
setblock ~64 ~-34 ~21 minecraft:light_gray_concrete
setblock ~4 ~-34 ~22 minecraft:light_gray_concrete
setblock ~5 ~-34 ~22 minecraft:iron_block
setblock ~6 ~-34 ~22 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~22 ~17 ~-34 ~22 minecraft:air
setblock ~18 ~-34 ~22 minecraft:light_gray_concrete
setblock ~19 ~-34 ~22 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~20 ~-34 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~21 ~-34 ~22 minecraft:air
setblock ~22 ~-34 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-34 ~22 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-34 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-34 ~22 minecraft:air
setblock ~26 ~-34 ~22 minecraft:iron_bars[west=true]
fill ~27 ~-34 ~22 ~28 ~-34 ~22 minecraft:air
setblock ~29 ~-34 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-34 ~22 minecraft:quartz_pillar
setblock ~31 ~-34 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-34 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-34 ~22 ~35 ~-34 ~22 minecraft:air
setblock ~36 ~-34 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-34 ~22 ~38 ~-34 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-34 ~22 minecraft:quartz_pillar
fill ~40 ~-34 ~22 ~44 ~-34 ~22 minecraft:air
setblock ~45 ~-34 ~22 minecraft:iron_bars[north=true]
setblock ~46 ~-34 ~22 minecraft:air
setblock ~47 ~-34 ~22 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-34 ~22 ~49 ~-34 ~22 minecraft:air
setblock ~50 ~-34 ~22 minecraft:light_gray_concrete
fill ~51 ~-34 ~22 ~63 ~-34 ~22 minecraft:air
setblock ~64 ~-34 ~22 minecraft:light_gray_concrete
setblock ~4 ~-34 ~23 minecraft:light_gray_concrete
setblock ~5 ~-34 ~23 minecraft:iron_block
setblock ~6 ~-34 ~23 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~23 ~10 ~-34 ~23 minecraft:air
setblock ~11 ~-34 ~23 minecraft:white_carpet
fill ~12 ~-34 ~23 ~17 ~-34 ~23 minecraft:air
setblock ~18 ~-34 ~23 minecraft:light_gray_concrete
fill ~19 ~-34 ~23 ~28 ~-34 ~23 minecraft:air
setblock ~29 ~-34 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-34 ~23 ~38 ~-34 ~23 minecraft:air
setblock ~39 ~-34 ~23 minecraft:quartz_pillar
fill ~40 ~-34 ~23 ~45 ~-34 ~23 minecraft:air
setblock ~46 ~-34 ~23 minecraft:iron_bars[east=true]
setblock ~47 ~-34 ~23 minecraft:iron_bars[north=true,south=true,west=true]
fill ~48 ~-34 ~23 ~49 ~-34 ~23 minecraft:air
setblock ~50 ~-34 ~23 minecraft:light_gray_concrete
setblock ~51 ~-34 ~23 minecraft:iron_block
fill ~52 ~-34 ~23 ~62 ~-34 ~23 minecraft:air
setblock ~63 ~-34 ~23 minecraft:iron_block
setblock ~64 ~-34 ~23 minecraft:light_gray_concrete
setblock ~4 ~-34 ~24 minecraft:light_gray_concrete
setblock ~5 ~-34 ~24 minecraft:iron_block
setblock ~6 ~-34 ~24 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~24 ~17 ~-34 ~24 minecraft:air
setblock ~18 ~-34 ~24 minecraft:light_gray_concrete
fill ~19 ~-34 ~24 ~25 ~-34 ~24 minecraft:air
setblock ~26 ~-34 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-34 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-34 ~24 ~29 ~-34 ~24 minecraft:air
setblock ~30 ~-34 ~24 minecraft:quartz_pillar
fill ~31 ~-34 ~24 ~37 ~-34 ~24 minecraft:air
setblock ~38 ~-34 ~24 minecraft:quartz_pillar
fill ~39 ~-34 ~24 ~40 ~-34 ~24 minecraft:air
setblock ~41 ~-34 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-34 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-34 ~24 ~46 ~-34 ~24 minecraft:air
setblock ~47 ~-34 ~24 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-34 ~24 ~49 ~-34 ~24 minecraft:air
setblock ~50 ~-34 ~24 minecraft:light_gray_concrete
fill ~51 ~-34 ~24 ~63 ~-34 ~24 minecraft:air
setblock ~64 ~-34 ~24 minecraft:light_gray_concrete
setblock ~4 ~-34 ~25 minecraft:light_gray_concrete
setblock ~5 ~-34 ~25 minecraft:iron_block
setblock ~6 ~-34 ~25 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~25 ~17 ~-34 ~25 minecraft:air
setblock ~18 ~-34 ~25 minecraft:light_gray_concrete
fill ~19 ~-34 ~25 ~24 ~-34 ~25 minecraft:air
fill ~25 ~-34 ~25 ~26 ~-34 ~25 minecraft:quartz_pillar
fill ~27 ~-34 ~25 ~41 ~-34 ~25 minecraft:air
setblock ~42 ~-34 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-34 ~25 minecraft:quartz_pillar
fill ~44 ~-34 ~25 ~46 ~-34 ~25 minecraft:air
setblock ~47 ~-34 ~25 minecraft:iron_bars[north=true]
fill ~48 ~-34 ~25 ~49 ~-34 ~25 minecraft:air
setblock ~50 ~-34 ~25 minecraft:light_gray_concrete
setblock ~51 ~-34 ~25 minecraft:iron_block
fill ~52 ~-34 ~25 ~55 ~-34 ~25 minecraft:air
fill ~56 ~-34 ~25 ~57 ~-34 ~25 minecraft:white_carpet
fill ~58 ~-34 ~25 ~62 ~-34 ~25 minecraft:air
setblock ~63 ~-34 ~25 minecraft:iron_block
setblock ~64 ~-34 ~25 minecraft:light_gray_concrete
setblock ~4 ~-34 ~26 minecraft:light_gray_concrete
setblock ~5 ~-34 ~26 minecraft:iron_block
setblock ~6 ~-34 ~26 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~26 ~17 ~-34 ~26 minecraft:air
setblock ~18 ~-34 ~26 minecraft:light_gray_concrete
fill ~19 ~-34 ~26 ~23 ~-34 ~26 minecraft:air
setblock ~24 ~-34 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-34 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-34 ~26 ~42 ~-34 ~26 minecraft:air
setblock ~43 ~-34 ~26 minecraft:quartz_pillar
setblock ~44 ~-34 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-34 ~26 ~49 ~-34 ~26 minecraft:air
setblock ~50 ~-34 ~26 minecraft:light_gray_concrete
fill ~51 ~-34 ~26 ~63 ~-34 ~26 minecraft:air
setblock ~64 ~-34 ~26 minecraft:light_gray_concrete
setblock ~4 ~-34 ~27 minecraft:light_gray_concrete
setblock ~5 ~-34 ~27 minecraft:iron_block
setblock ~6 ~-34 ~27 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~27 ~10 ~-34 ~27 minecraft:air
setblock ~11 ~-34 ~27 minecraft:white_carpet
fill ~12 ~-34 ~27 ~17 ~-34 ~27 minecraft:air
setblock ~18 ~-34 ~27 minecraft:light_gray_concrete
fill ~19 ~-34 ~27 ~23 ~-34 ~27 minecraft:air
setblock ~24 ~-34 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-34 ~27 ~43 ~-34 ~27 minecraft:air
setblock ~44 ~-34 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-34 ~27 ~49 ~-34 ~27 minecraft:air
setblock ~50 ~-34 ~27 minecraft:light_gray_concrete
setblock ~51 ~-34 ~27 minecraft:iron_block
fill ~52 ~-34 ~27 ~56 ~-34 ~27 minecraft:air
setblock ~57 ~-34 ~27 minecraft:black_concrete
fill ~58 ~-34 ~27 ~62 ~-34 ~27 minecraft:air
setblock ~63 ~-34 ~27 minecraft:iron_block
setblock ~64 ~-34 ~27 minecraft:light_gray_concrete
setblock ~4 ~-34 ~28 minecraft:light_gray_concrete
setblock ~5 ~-34 ~28 minecraft:iron_block
setblock ~6 ~-34 ~28 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~28 ~17 ~-34 ~28 minecraft:air
setblock ~18 ~-34 ~28 minecraft:light_gray_concrete
fill ~19 ~-34 ~28 ~22 ~-34 ~28 minecraft:air
setblock ~23 ~-34 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-34 ~28 ~44 ~-34 ~28 minecraft:air
setblock ~45 ~-34 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-34 ~28 ~49 ~-34 ~28 minecraft:air
setblock ~50 ~-34 ~28 minecraft:light_gray_concrete
fill ~51 ~-34 ~28 ~63 ~-34 ~28 minecraft:air
setblock ~64 ~-34 ~28 minecraft:light_gray_concrete
setblock ~4 ~-34 ~29 minecraft:light_gray_concrete
setblock ~5 ~-34 ~29 minecraft:iron_block
setblock ~6 ~-34 ~29 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~29 ~17 ~-34 ~29 minecraft:air
setblock ~18 ~-34 ~29 minecraft:light_gray_concrete
fill ~19 ~-34 ~29 ~21 ~-34 ~29 minecraft:air
fill ~22 ~-34 ~29 ~23 ~-34 ~29 minecraft:quartz_pillar
fill ~24 ~-34 ~29 ~44 ~-34 ~29 minecraft:air
setblock ~45 ~-34 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-34 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-34 ~29 ~49 ~-34 ~29 minecraft:air
setblock ~50 ~-34 ~29 minecraft:light_gray_concrete
setblock ~51 ~-34 ~29 minecraft:iron_block
fill ~52 ~-34 ~29 ~62 ~-34 ~29 minecraft:air
setblock ~63 ~-34 ~29 minecraft:iron_block
setblock ~64 ~-34 ~29 minecraft:light_gray_concrete
setblock ~4 ~-34 ~30 minecraft:light_gray_concrete
setblock ~5 ~-34 ~30 minecraft:iron_block
setblock ~6 ~-34 ~30 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~30 ~9 ~-34 ~30 minecraft:iron_trapdoor[open=true,facing=north]
fill ~10 ~-34 ~30 ~12 ~-34 ~30 minecraft:air
fill ~13 ~-34 ~30 ~16 ~-34 ~30 minecraft:iron_trapdoor[open=true,facing=north]
setblock ~17 ~-34 ~30 minecraft:air
setblock ~18 ~-34 ~30 minecraft:light_gray_concrete
fill ~19 ~-34 ~30 ~21 ~-34 ~30 minecraft:air
setblock ~22 ~-34 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-34 ~30 minecraft:air
setblock ~24 ~-34 ~30 minecraft:quartz_pillar
fill ~25 ~-34 ~30 ~43 ~-34 ~30 minecraft:air
setblock ~44 ~-34 ~30 minecraft:quartz_pillar
setblock ~45 ~-34 ~30 minecraft:air
setblock ~46 ~-34 ~30 minecraft:quartz_pillar
fill ~47 ~-34 ~30 ~49 ~-34 ~30 minecraft:air
setblock ~50 ~-34 ~30 minecraft:light_gray_concrete
fill ~51 ~-34 ~30 ~63 ~-34 ~30 minecraft:air
setblock ~64 ~-34 ~30 minecraft:light_gray_concrete
setblock ~4 ~-34 ~31 minecraft:light_gray_concrete
fill ~5 ~-34 ~31 ~6 ~-34 ~31 minecraft:air
fill ~7 ~-34 ~31 ~9 ~-34 ~31 minecraft:iron_block
fill ~10 ~-34 ~31 ~12 ~-34 ~31 minecraft:air
fill ~13 ~-34 ~31 ~16 ~-34 ~31 minecraft:iron_block
setblock ~17 ~-34 ~31 minecraft:air
setblock ~18 ~-34 ~31 minecraft:light_gray_concrete
fill ~19 ~-34 ~31 ~21 ~-34 ~31 minecraft:air
setblock ~22 ~-34 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-34 ~31 ~45 ~-34 ~31 minecraft:air
setblock ~46 ~-34 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-34 ~31 ~49 ~-34 ~31 minecraft:air
setblock ~50 ~-34 ~31 minecraft:light_gray_concrete
setblock ~51 ~-34 ~31 minecraft:iron_block
setblock ~52 ~-34 ~31 minecraft:air
setblock ~53 ~-34 ~31 minecraft:iron_block
setblock ~54 ~-34 ~31 minecraft:air
setblock ~55 ~-34 ~31 minecraft:iron_block
fill ~56 ~-34 ~31 ~58 ~-34 ~31 minecraft:air
setblock ~59 ~-34 ~31 minecraft:iron_block
setblock ~60 ~-34 ~31 minecraft:air
setblock ~61 ~-34 ~31 minecraft:iron_block
setblock ~62 ~-34 ~31 minecraft:air
setblock ~63 ~-34 ~31 minecraft:iron_block
setblock ~64 ~-34 ~31 minecraft:light_gray_concrete
setblock ~4 ~-34 ~32 minecraft:light_gray_concrete
fill ~5 ~-34 ~32 ~10 ~-34 ~32 minecraft:red_concrete
setblock ~11 ~-34 ~32 minecraft:air
fill ~12 ~-34 ~32 ~18 ~-34 ~32 minecraft:red_concrete
setblock ~19 ~-34 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-34 ~32 minecraft:air
setblock ~21 ~-34 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-34 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-34 ~32 ~32 ~-34 ~32 minecraft:air
fill ~33 ~-34 ~32 ~35 ~-34 ~32 minecraft:glass
fill ~36 ~-34 ~32 ~45 ~-34 ~32 minecraft:air
setblock ~46 ~-34 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-34 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-34 ~32 minecraft:air
setblock ~49 ~-34 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~50 ~-34 ~32 minecraft:red_concrete
setblock ~51 ~-34 ~32 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~52 ~-34 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~53 ~-34 ~32 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~54 ~-34 ~32 minecraft:red_concrete
setblock ~55 ~-34 ~32 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~56 ~-34 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~57 ~-34 ~32 minecraft:air
setblock ~58 ~-34 ~32 minecraft:red_concrete
setblock ~59 ~-34 ~32 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~60 ~-34 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~61 ~-34 ~32 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~62 ~-34 ~32 minecraft:red_concrete
setblock ~63 ~-34 ~32 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~64 ~-34 ~32 minecraft:light_gray_concrete
setblock ~4 ~-34 ~33 minecraft:light_gray_concrete
fill ~5 ~-34 ~33 ~32 ~-34 ~33 minecraft:air
setblock ~33 ~-34 ~33 minecraft:glass
fill ~34 ~-34 ~33 ~63 ~-34 ~33 minecraft:air
setblock ~64 ~-34 ~33 minecraft:light_gray_concrete
schedule function hive:weiter/9 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 8 von 18 fertig","color":"gray"}]