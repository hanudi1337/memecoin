setblock ~5 ~-66 ~23 minecraft:waxed_cut_copper
fill ~6 ~-66 ~23 ~16 ~-66 ~23 minecraft:air
setblock ~17 ~-66 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~23 minecraft:deepslate_tiles
fill ~19 ~-66 ~23 ~23 ~-66 ~23 minecraft:air
fill ~24 ~-66 ~23 ~25 ~-66 ~23 minecraft:deepslate_tiles
fill ~26 ~-66 ~23 ~42 ~-66 ~23 minecraft:air
fill ~43 ~-66 ~23 ~44 ~-66 ~23 minecraft:deepslate_tiles
fill ~45 ~-66 ~23 ~49 ~-66 ~23 minecraft:air
setblock ~50 ~-66 ~23 minecraft:deepslate_tiles
fill ~51 ~-66 ~23 ~63 ~-66 ~23 minecraft:air
setblock ~64 ~-66 ~23 minecraft:deepslate_tiles
setblock ~4 ~-66 ~24 minecraft:deepslate_tiles
setblock ~5 ~-66 ~24 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~24 ~16 ~-66 ~24 minecraft:air
setblock ~17 ~-66 ~24 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~24 minecraft:deepslate_tiles
setblock ~19 ~-66 ~24 minecraft:air
fill ~20 ~-66 ~24 ~22 ~-66 ~24 minecraft:barrel
fill ~23 ~-66 ~24 ~24 ~-66 ~24 minecraft:deepslate_tiles
fill ~25 ~-66 ~24 ~32 ~-66 ~24 minecraft:air
fill ~33 ~-66 ~24 ~35 ~-66 ~24 minecraft:black_concrete
fill ~36 ~-66 ~24 ~43 ~-66 ~24 minecraft:air
fill ~44 ~-66 ~24 ~45 ~-66 ~24 minecraft:deepslate_tiles
setblock ~46 ~-66 ~24 minecraft:barrel
setblock ~47 ~-66 ~24 minecraft:air
setblock ~48 ~-66 ~24 minecraft:barrel
setblock ~49 ~-66 ~24 minecraft:air
setblock ~50 ~-66 ~24 minecraft:deepslate_tiles
fill ~51 ~-66 ~24 ~63 ~-66 ~24 minecraft:air
setblock ~64 ~-66 ~24 minecraft:deepslate_tiles
setblock ~4 ~-66 ~25 minecraft:deepslate_tiles
setblock ~5 ~-66 ~25 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~25 ~16 ~-66 ~25 minecraft:air
setblock ~17 ~-66 ~25 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~25 minecraft:deepslate_tiles
fill ~19 ~-66 ~25 ~21 ~-66 ~25 minecraft:air
fill ~22 ~-66 ~25 ~23 ~-66 ~25 minecraft:deepslate_tiles
fill ~24 ~-66 ~25 ~44 ~-66 ~25 minecraft:air
fill ~45 ~-66 ~25 ~46 ~-66 ~25 minecraft:deepslate_tiles
fill ~47 ~-66 ~25 ~49 ~-66 ~25 minecraft:air
setblock ~50 ~-66 ~25 minecraft:deepslate_tiles
fill ~51 ~-66 ~25 ~63 ~-66 ~25 minecraft:air
setblock ~64 ~-66 ~25 minecraft:deepslate_tiles
setblock ~4 ~-66 ~26 minecraft:deepslate_tiles
setblock ~5 ~-66 ~26 minecraft:waxed_cut_copper
fill ~6 ~-66 ~26 ~9 ~-66 ~26 minecraft:air
setblock ~10 ~-66 ~26 minecraft:waxed_cut_copper
fill ~11 ~-66 ~26 ~13 ~-66 ~26 minecraft:air
setblock ~14 ~-66 ~26 minecraft:waxed_cut_copper
fill ~15 ~-66 ~26 ~16 ~-66 ~26 minecraft:air
setblock ~17 ~-66 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~26 minecraft:deepslate_tiles
fill ~19 ~-66 ~26 ~21 ~-66 ~26 minecraft:air
setblock ~22 ~-66 ~26 minecraft:deepslate_tiles
fill ~23 ~-66 ~26 ~25 ~-66 ~26 minecraft:air
setblock ~26 ~-66 ~26 minecraft:waxed_cut_copper
fill ~27 ~-66 ~26 ~41 ~-66 ~26 minecraft:air
setblock ~42 ~-66 ~26 minecraft:waxed_cut_copper
fill ~43 ~-66 ~26 ~45 ~-66 ~26 minecraft:air
setblock ~46 ~-66 ~26 minecraft:deepslate_tiles
fill ~47 ~-66 ~26 ~49 ~-66 ~26 minecraft:air
setblock ~50 ~-66 ~26 minecraft:deepslate_tiles
fill ~51 ~-66 ~26 ~63 ~-66 ~26 minecraft:air
setblock ~64 ~-66 ~26 minecraft:deepslate_tiles
setblock ~4 ~-66 ~27 minecraft:deepslate_tiles
setblock ~5 ~-66 ~27 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~27 ~16 ~-66 ~27 minecraft:air
setblock ~17 ~-66 ~27 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~27 minecraft:deepslate_tiles
setblock ~19 ~-66 ~27 minecraft:air
setblock ~20 ~-66 ~27 minecraft:barrel
setblock ~21 ~-66 ~27 minecraft:deepslate_tiles
fill ~22 ~-66 ~27 ~46 ~-66 ~27 minecraft:air
setblock ~47 ~-66 ~27 minecraft:deepslate_tiles
setblock ~48 ~-66 ~27 minecraft:barrel
setblock ~49 ~-66 ~27 minecraft:air
setblock ~50 ~-66 ~27 minecraft:deepslate_tiles
fill ~51 ~-66 ~27 ~63 ~-66 ~27 minecraft:air
setblock ~64 ~-66 ~27 minecraft:deepslate_tiles
setblock ~4 ~-66 ~28 minecraft:deepslate_tiles
setblock ~5 ~-66 ~28 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~28 ~16 ~-66 ~28 minecraft:air
setblock ~17 ~-66 ~28 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~28 minecraft:deepslate_tiles
fill ~19 ~-66 ~28 ~20 ~-66 ~28 minecraft:air
setblock ~21 ~-66 ~28 minecraft:deepslate_tiles
fill ~22 ~-66 ~28 ~46 ~-66 ~28 minecraft:air
setblock ~47 ~-66 ~28 minecraft:deepslate_tiles
fill ~48 ~-66 ~28 ~49 ~-66 ~28 minecraft:air
setblock ~50 ~-66 ~28 minecraft:deepslate_tiles
fill ~51 ~-66 ~28 ~63 ~-66 ~28 minecraft:air
setblock ~64 ~-66 ~28 minecraft:deepslate_tiles
setblock ~4 ~-66 ~29 minecraft:deepslate_tiles
setblock ~5 ~-66 ~29 minecraft:waxed_cut_copper
fill ~6 ~-66 ~29 ~16 ~-66 ~29 minecraft:air
setblock ~17 ~-66 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~29 minecraft:deepslate_tiles
setblock ~19 ~-66 ~29 minecraft:air
setblock ~20 ~-66 ~29 minecraft:deepslate_tiles
fill ~21 ~-66 ~29 ~47 ~-66 ~29 minecraft:air
setblock ~48 ~-66 ~29 minecraft:deepslate_tiles
setblock ~49 ~-66 ~29 minecraft:air
setblock ~50 ~-66 ~29 minecraft:deepslate_tiles
fill ~51 ~-66 ~29 ~63 ~-66 ~29 minecraft:air
setblock ~64 ~-66 ~29 minecraft:deepslate_tiles
setblock ~4 ~-66 ~30 minecraft:deepslate_tiles
setblock ~5 ~-66 ~30 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~30 ~16 ~-66 ~30 minecraft:air
setblock ~17 ~-66 ~30 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~30 minecraft:deepslate_tiles
setblock ~19 ~-66 ~30 minecraft:air
setblock ~20 ~-66 ~30 minecraft:deepslate_tiles
fill ~21 ~-66 ~30 ~47 ~-66 ~30 minecraft:air
setblock ~48 ~-66 ~30 minecraft:deepslate_tiles
setblock ~49 ~-66 ~30 minecraft:air
setblock ~50 ~-66 ~30 minecraft:deepslate_tiles
fill ~51 ~-66 ~30 ~63 ~-66 ~30 minecraft:air
setblock ~64 ~-66 ~30 minecraft:deepslate_tiles
setblock ~4 ~-66 ~31 minecraft:deepslate_tiles
setblock ~5 ~-66 ~31 minecraft:blast_furnace[facing=north]
setblock ~6 ~-66 ~31 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~31 minecraft:redstone_lamp[lit=true]
setblock ~8 ~-66 ~31 minecraft:blast_furnace[facing=north]
setblock ~9 ~-66 ~31 minecraft:waxed_cut_copper
fill ~10 ~-66 ~31 ~12 ~-66 ~31 minecraft:air
setblock ~13 ~-66 ~31 minecraft:redstone_lamp[lit=true]
setblock ~14 ~-66 ~31 minecraft:blast_furnace[facing=north]
setblock ~15 ~-66 ~31 minecraft:waxed_cut_copper
setblock ~16 ~-66 ~31 minecraft:redstone_lamp[lit=true]
setblock ~17 ~-66 ~31 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~31 minecraft:deepslate_tiles
setblock ~19 ~-66 ~31 minecraft:air
setblock ~20 ~-66 ~31 minecraft:deepslate_tiles
fill ~21 ~-66 ~31 ~47 ~-66 ~31 minecraft:air
setblock ~48 ~-66 ~31 minecraft:deepslate_tiles
setblock ~49 ~-66 ~31 minecraft:air
setblock ~50 ~-66 ~31 minecraft:deepslate_tiles
fill ~51 ~-66 ~31 ~63 ~-66 ~31 minecraft:air
setblock ~64 ~-66 ~31 minecraft:deepslate_tiles
setblock ~4 ~-66 ~32 minecraft:deepslate_tiles
fill ~5 ~-66 ~32 ~10 ~-66 ~32 minecraft:yellow_concrete
setblock ~11 ~-66 ~32 minecraft:air
fill ~12 ~-66 ~32 ~18 ~-66 ~32 minecraft:yellow_concrete
setblock ~19 ~-66 ~32 minecraft:air
setblock ~20 ~-66 ~32 minecraft:deepslate_tiles
fill ~21 ~-66 ~32 ~32 ~-66 ~32 minecraft:air
fill ~33 ~-66 ~32 ~35 ~-66 ~32 minecraft:glass
fill ~36 ~-66 ~32 ~47 ~-66 ~32 minecraft:air
setblock ~48 ~-66 ~32 minecraft:deepslate_tiles
setblock ~49 ~-66 ~32 minecraft:air
fill ~50 ~-66 ~32 ~56 ~-66 ~32 minecraft:yellow_concrete
setblock ~57 ~-66 ~32 minecraft:air
fill ~58 ~-66 ~32 ~63 ~-66 ~32 minecraft:yellow_concrete
setblock ~64 ~-66 ~32 minecraft:deepslate_tiles
setblock ~4 ~-66 ~33 minecraft:deepslate_tiles
fill ~5 ~-66 ~33 ~23 ~-66 ~33 minecraft:air
setblock ~24 ~-66 ~33 minecraft:black_concrete
fill ~25 ~-66 ~33 ~31 ~-66 ~33 minecraft:air
setblock ~32 ~-66 ~33 minecraft:glass
fill ~33 ~-66 ~33 ~35 ~-66 ~33 minecraft:sea_lantern
setblock ~36 ~-66 ~33 minecraft:glass
fill ~37 ~-66 ~33 ~43 ~-66 ~33 minecraft:air
setblock ~44 ~-66 ~33 minecraft:black_concrete
fill ~45 ~-66 ~33 ~63 ~-66 ~33 minecraft:air
fill ~64 ~-66 ~33 ~68 ~-66 ~33 minecraft:deepslate_bricks
setblock ~4 ~-66 ~34 minecraft:deepslate_tiles
fill ~5 ~-66 ~34 ~23 ~-66 ~34 minecraft:air
setblock ~24 ~-66 ~34 minecraft:black_concrete
fill ~25 ~-66 ~34 ~31 ~-66 ~34 minecraft:air
setblock ~32 ~-66 ~34 minecraft:glass
fill ~33 ~-66 ~34 ~35 ~-66 ~34 minecraft:sea_lantern
setblock ~36 ~-66 ~34 minecraft:glass
fill ~37 ~-66 ~34 ~43 ~-66 ~34 minecraft:air
setblock ~44 ~-66 ~34 minecraft:black_concrete
fill ~45 ~-66 ~34 ~68 ~-66 ~34 minecraft:air
setblock ~4 ~-66 ~35 minecraft:deepslate_tiles
fill ~5 ~-66 ~35 ~23 ~-66 ~35 minecraft:air
setblock ~24 ~-66 ~35 minecraft:black_concrete
fill ~25 ~-66 ~35 ~31 ~-66 ~35 minecraft:air
setblock ~32 ~-66 ~35 minecraft:glass
fill ~33 ~-66 ~35 ~35 ~-66 ~35 minecraft:sea_lantern
setblock ~36 ~-66 ~35 minecraft:glass
fill ~37 ~-66 ~35 ~43 ~-66 ~35 minecraft:air
setblock ~44 ~-66 ~35 minecraft:black_concrete
fill ~45 ~-66 ~35 ~63 ~-66 ~35 minecraft:air
fill ~64 ~-66 ~35 ~68 ~-66 ~35 minecraft:deepslate_bricks
setblock ~4 ~-66 ~36 minecraft:deepslate_tiles
fill ~5 ~-66 ~36 ~10 ~-66 ~36 minecraft:yellow_concrete
setblock ~11 ~-66 ~36 minecraft:air
fill ~12 ~-66 ~36 ~18 ~-66 ~36 minecraft:yellow_concrete
setblock ~19 ~-66 ~36 minecraft:air
setblock ~20 ~-66 ~36 minecraft:deepslate_tiles
fill ~21 ~-66 ~36 ~32 ~-66 ~36 minecraft:air
fill ~33 ~-66 ~36 ~35 ~-66 ~36 minecraft:glass
fill ~36 ~-66 ~36 ~47 ~-66 ~36 minecraft:air
setblock ~48 ~-66 ~36 minecraft:deepslate_tiles
setblock ~49 ~-66 ~36 minecraft:air
fill ~50 ~-66 ~36 ~56 ~-66 ~36 minecraft:yellow_concrete
setblock ~57 ~-66 ~36 minecraft:air
fill ~58 ~-66 ~36 ~63 ~-66 ~36 minecraft:yellow_concrete
setblock ~64 ~-66 ~36 minecraft:deepslate_tiles
setblock ~4 ~-66 ~37 minecraft:deepslate_tiles
setblock ~5 ~-66 ~37 minecraft:blast_furnace[facing=south]
setblock ~6 ~-66 ~37 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~37 minecraft:redstone_lamp[lit=true]
setblock ~8 ~-66 ~37 minecraft:blast_furnace[facing=south]
setblock ~9 ~-66 ~37 minecraft:waxed_cut_copper
fill ~10 ~-66 ~37 ~12 ~-66 ~37 minecraft:air
setblock ~13 ~-66 ~37 minecraft:redstone_lamp[lit=true]
setblock ~14 ~-66 ~37 minecraft:blast_furnace[facing=south]
setblock ~15 ~-66 ~37 minecraft:waxed_cut_copper
setblock ~16 ~-66 ~37 minecraft:redstone_lamp[lit=true]
setblock ~17 ~-66 ~37 minecraft:blast_furnace[facing=south]
setblock ~18 ~-66 ~37 minecraft:deepslate_tiles
setblock ~19 ~-66 ~37 minecraft:air
setblock ~20 ~-66 ~37 minecraft:deepslate_tiles
fill ~21 ~-66 ~37 ~47 ~-66 ~37 minecraft:air
setblock ~48 ~-66 ~37 minecraft:deepslate_tiles
setblock ~49 ~-66 ~37 minecraft:air
setblock ~50 ~-66 ~37 minecraft:deepslate_tiles
fill ~51 ~-66 ~37 ~63 ~-66 ~37 minecraft:air
setblock ~64 ~-66 ~37 minecraft:deepslate_tiles
setblock ~4 ~-66 ~38 minecraft:deepslate_tiles
setblock ~5 ~-66 ~38 minecraft:waxed_cut_copper
fill ~6 ~-66 ~38 ~16 ~-66 ~38 minecraft:air
setblock ~17 ~-66 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~38 minecraft:deepslate_tiles
setblock ~19 ~-66 ~38 minecraft:air
setblock ~20 ~-66 ~38 minecraft:deepslate_tiles
fill ~21 ~-66 ~38 ~47 ~-66 ~38 minecraft:air
setblock ~48 ~-66 ~38 minecraft:deepslate_tiles
setblock ~49 ~-66 ~38 minecraft:air
setblock ~50 ~-66 ~38 minecraft:deepslate_tiles
setblock ~51 ~-66 ~38 minecraft:air
setblock ~52 ~-66 ~38 minecraft:barrel
fill ~53 ~-66 ~38 ~54 ~-66 ~38 minecraft:air
setblock ~55 ~-66 ~38 minecraft:barrel
fill ~56 ~-66 ~38 ~57 ~-66 ~38 minecraft:air
setblock ~58 ~-66 ~38 minecraft:barrel
fill ~59 ~-66 ~38 ~60 ~-66 ~38 minecraft:air
setblock ~61 ~-66 ~38 minecraft:barrel
fill ~62 ~-66 ~38 ~63 ~-66 ~38 minecraft:air
setblock ~64 ~-66 ~38 minecraft:deepslate_tiles
setblock ~4 ~-66 ~39 minecraft:deepslate_tiles
setblock ~5 ~-66 ~39 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~39 ~16 ~-66 ~39 minecraft:air
setblock ~17 ~-66 ~39 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~39 minecraft:deepslate_tiles
setblock ~19 ~-66 ~39 minecraft:air
setblock ~20 ~-66 ~39 minecraft:deepslate_tiles
fill ~21 ~-66 ~39 ~47 ~-66 ~39 minecraft:air
setblock ~48 ~-66 ~39 minecraft:deepslate_tiles
setblock ~49 ~-66 ~39 minecraft:air
setblock ~50 ~-66 ~39 minecraft:deepslate_tiles
setblock ~51 ~-66 ~39 minecraft:air
setblock ~52 ~-66 ~39 minecraft:barrel
fill ~53 ~-66 ~39 ~54 ~-66 ~39 minecraft:air
setblock ~55 ~-66 ~39 minecraft:barrel
fill ~56 ~-66 ~39 ~57 ~-66 ~39 minecraft:air
setblock ~58 ~-66 ~39 minecraft:barrel
fill ~59 ~-66 ~39 ~60 ~-66 ~39 minecraft:air
setblock ~61 ~-66 ~39 minecraft:barrel
fill ~62 ~-66 ~39 ~63 ~-66 ~39 minecraft:air
setblock ~64 ~-66 ~39 minecraft:deepslate_tiles
setblock ~4 ~-66 ~40 minecraft:deepslate_tiles
setblock ~5 ~-66 ~40 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~40 ~16 ~-66 ~40 minecraft:air
setblock ~17 ~-66 ~40 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~40 minecraft:deepslate_tiles
fill ~19 ~-66 ~40 ~20 ~-66 ~40 minecraft:air
setblock ~21 ~-66 ~40 minecraft:deepslate_tiles
fill ~22 ~-66 ~40 ~46 ~-66 ~40 minecraft:air
setblock ~47 ~-66 ~40 minecraft:deepslate_tiles
fill ~48 ~-66 ~40 ~49 ~-66 ~40 minecraft:air
setblock ~50 ~-66 ~40 minecraft:deepslate_tiles
setblock ~51 ~-66 ~40 minecraft:air
setblock ~52 ~-66 ~40 minecraft:barrel
fill ~53 ~-66 ~40 ~54 ~-66 ~40 minecraft:air
setblock ~55 ~-66 ~40 minecraft:barrel
fill ~56 ~-66 ~40 ~57 ~-66 ~40 minecraft:air
setblock ~58 ~-66 ~40 minecraft:barrel
fill ~59 ~-66 ~40 ~60 ~-66 ~40 minecraft:air
setblock ~61 ~-66 ~40 minecraft:barrel
fill ~62 ~-66 ~40 ~63 ~-66 ~40 minecraft:air
setblock ~64 ~-66 ~40 minecraft:deepslate_tiles
setblock ~4 ~-66 ~41 minecraft:deepslate_tiles
setblock ~5 ~-66 ~41 minecraft:waxed_cut_copper
fill ~6 ~-66 ~41 ~16 ~-66 ~41 minecraft:air
setblock ~17 ~-66 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~41 minecraft:deepslate_tiles
setblock ~19 ~-66 ~41 minecraft:air
setblock ~20 ~-66 ~41 minecraft:barrel
setblock ~21 ~-66 ~41 minecraft:deepslate_tiles
fill ~22 ~-66 ~41 ~46 ~-66 ~41 minecraft:air
setblock ~47 ~-66 ~41 minecraft:deepslate_tiles
setblock ~48 ~-66 ~41 minecraft:barrel
setblock ~49 ~-66 ~41 minecraft:air
setblock ~50 ~-66 ~41 minecraft:deepslate_tiles
setblock ~51 ~-66 ~41 minecraft:air
setblock ~52 ~-66 ~41 minecraft:barrel
fill ~53 ~-66 ~41 ~54 ~-66 ~41 minecraft:air
setblock ~55 ~-66 ~41 minecraft:barrel
fill ~56 ~-66 ~41 ~57 ~-66 ~41 minecraft:air
setblock ~58 ~-66 ~41 minecraft:barrel
fill ~59 ~-66 ~41 ~60 ~-66 ~41 minecraft:air
setblock ~61 ~-66 ~41 minecraft:barrel
fill ~62 ~-66 ~41 ~63 ~-66 ~41 minecraft:air
setblock ~64 ~-66 ~41 minecraft:deepslate_tiles
setblock ~4 ~-66 ~42 minecraft:deepslate_tiles
setblock ~5 ~-66 ~42 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~42 ~9 ~-66 ~42 minecraft:air
setblock ~10 ~-66 ~42 minecraft:waxed_cut_copper
fill ~11 ~-66 ~42 ~13 ~-66 ~42 minecraft:air
setblock ~14 ~-66 ~42 minecraft:waxed_cut_copper
fill ~15 ~-66 ~42 ~16 ~-66 ~42 minecraft:air
setblock ~17 ~-66 ~42 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~42 minecraft:deepslate_tiles
fill ~19 ~-66 ~42 ~21 ~-66 ~42 minecraft:air
setblock ~22 ~-66 ~42 minecraft:deepslate_tiles
fill ~23 ~-66 ~42 ~25 ~-66 ~42 minecraft:air
setblock ~26 ~-66 ~42 minecraft:waxed_cut_copper
fill ~27 ~-66 ~42 ~41 ~-66 ~42 minecraft:air
setblock ~42 ~-66 ~42 minecraft:waxed_cut_copper
fill ~43 ~-66 ~42 ~45 ~-66 ~42 minecraft:air
setblock ~46 ~-66 ~42 minecraft:deepslate_tiles
fill ~47 ~-66 ~42 ~49 ~-66 ~42 minecraft:air
setblock ~50 ~-66 ~42 minecraft:deepslate_tiles
fill ~51 ~-66 ~42 ~63 ~-66 ~42 minecraft:air
setblock ~64 ~-66 ~42 minecraft:deepslate_tiles
setblock ~4 ~-66 ~43 minecraft:deepslate_tiles
setblock ~5 ~-66 ~43 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~43 ~16 ~-66 ~43 minecraft:air
setblock ~17 ~-66 ~43 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~43 minecraft:deepslate_tiles
fill ~19 ~-66 ~43 ~21 ~-66 ~43 minecraft:air
fill ~22 ~-66 ~43 ~23 ~-66 ~43 minecraft:deepslate_tiles
fill ~24 ~-66 ~43 ~44 ~-66 ~43 minecraft:air
fill ~45 ~-66 ~43 ~46 ~-66 ~43 minecraft:deepslate_tiles
fill ~47 ~-66 ~43 ~49 ~-66 ~43 minecraft:air
setblock ~50 ~-66 ~43 minecraft:deepslate_tiles
setblock ~51 ~-66 ~43 minecraft:air
setblock ~52 ~-66 ~43 minecraft:barrel
fill ~53 ~-66 ~43 ~54 ~-66 ~43 minecraft:air
setblock ~55 ~-66 ~43 minecraft:barrel
fill ~56 ~-66 ~43 ~57 ~-66 ~43 minecraft:air
setblock ~58 ~-66 ~43 minecraft:barrel
fill ~59 ~-66 ~43 ~60 ~-66 ~43 minecraft:air
setblock ~61 ~-66 ~43 minecraft:barrel
fill ~62 ~-66 ~43 ~63 ~-66 ~43 minecraft:air
setblock ~64 ~-66 ~43 minecraft:deepslate_tiles
setblock ~4 ~-66 ~44 minecraft:deepslate_tiles
setblock ~5 ~-66 ~44 minecraft:waxed_cut_copper
fill ~6 ~-66 ~44 ~16 ~-66 ~44 minecraft:air
setblock ~17 ~-66 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~44 minecraft:deepslate_tiles
setblock ~19 ~-66 ~44 minecraft:air
fill ~20 ~-66 ~44 ~22 ~-66 ~44 minecraft:barrel
fill ~23 ~-66 ~44 ~24 ~-66 ~44 minecraft:deepslate_tiles
fill ~25 ~-66 ~44 ~32 ~-66 ~44 minecraft:air
fill ~33 ~-66 ~44 ~35 ~-66 ~44 minecraft:black_concrete
fill ~36 ~-66 ~44 ~43 ~-66 ~44 minecraft:air
fill ~44 ~-66 ~44 ~45 ~-66 ~44 minecraft:deepslate_tiles
setblock ~46 ~-66 ~44 minecraft:barrel
setblock ~47 ~-66 ~44 minecraft:air
setblock ~48 ~-66 ~44 minecraft:barrel
setblock ~49 ~-66 ~44 minecraft:air
setblock ~50 ~-66 ~44 minecraft:deepslate_tiles
setblock ~51 ~-66 ~44 minecraft:air
setblock ~52 ~-66 ~44 minecraft:barrel
fill ~53 ~-66 ~44 ~54 ~-66 ~44 minecraft:air
setblock ~55 ~-66 ~44 minecraft:barrel
fill ~56 ~-66 ~44 ~57 ~-66 ~44 minecraft:air
setblock ~58 ~-66 ~44 minecraft:barrel
fill ~59 ~-66 ~44 ~60 ~-66 ~44 minecraft:air
setblock ~61 ~-66 ~44 minecraft:barrel
fill ~62 ~-66 ~44 ~63 ~-66 ~44 minecraft:air
setblock ~64 ~-66 ~44 minecraft:deepslate_tiles
setblock ~4 ~-66 ~45 minecraft:deepslate_tiles
setblock ~5 ~-66 ~45 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~45 ~16 ~-66 ~45 minecraft:air
setblock ~17 ~-66 ~45 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~45 minecraft:deepslate_tiles
fill ~19 ~-66 ~45 ~23 ~-66 ~45 minecraft:air
fill ~24 ~-66 ~45 ~25 ~-66 ~45 minecraft:deepslate_tiles
fill ~26 ~-66 ~45 ~42 ~-66 ~45 minecraft:air
fill ~43 ~-66 ~45 ~44 ~-66 ~45 minecraft:deepslate_tiles
fill ~45 ~-66 ~45 ~49 ~-66 ~45 minecraft:air
setblock ~50 ~-66 ~45 minecraft:deepslate_tiles
setblock ~51 ~-66 ~45 minecraft:air
setblock ~52 ~-66 ~45 minecraft:barrel
fill ~53 ~-66 ~45 ~54 ~-66 ~45 minecraft:air
setblock ~55 ~-66 ~45 minecraft:barrel
fill ~56 ~-66 ~45 ~57 ~-66 ~45 minecraft:air
setblock ~58 ~-66 ~45 minecraft:barrel
fill ~59 ~-66 ~45 ~60 ~-66 ~45 minecraft:air
setblock ~61 ~-66 ~45 minecraft:barrel
fill ~62 ~-66 ~45 ~63 ~-66 ~45 minecraft:air
setblock ~64 ~-66 ~45 minecraft:deepslate_tiles
setblock ~4 ~-66 ~46 minecraft:deepslate_tiles
setblock ~5 ~-66 ~46 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~46 ~9 ~-66 ~46 minecraft:air
setblock ~10 ~-66 ~46 minecraft:waxed_cut_copper
fill ~11 ~-66 ~46 ~13 ~-66 ~46 minecraft:air
setblock ~14 ~-66 ~46 minecraft:waxed_cut_copper
fill ~15 ~-66 ~46 ~16 ~-66 ~46 minecraft:air
setblock ~17 ~-66 ~46 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~46 minecraft:deepslate_tiles
fill ~19 ~-66 ~46 ~24 ~-66 ~46 minecraft:air
fill ~25 ~-66 ~46 ~26 ~-66 ~46 minecraft:deepslate_tiles
fill ~27 ~-66 ~46 ~41 ~-66 ~46 minecraft:air
fill ~42 ~-66 ~46 ~43 ~-66 ~46 minecraft:deepslate_tiles
fill ~44 ~-66 ~46 ~49 ~-66 ~46 minecraft:air
setblock ~50 ~-66 ~46 minecraft:deepslate_tiles
setblock ~51 ~-66 ~46 minecraft:air
setblock ~52 ~-66 ~46 minecraft:barrel
fill ~53 ~-66 ~46 ~54 ~-66 ~46 minecraft:air
setblock ~55 ~-66 ~46 minecraft:barrel
fill ~56 ~-66 ~46 ~57 ~-66 ~46 minecraft:air
setblock ~58 ~-66 ~46 minecraft:barrel
fill ~59 ~-66 ~46 ~60 ~-66 ~46 minecraft:air
setblock ~61 ~-66 ~46 minecraft:barrel
fill ~62 ~-66 ~46 ~63 ~-66 ~46 minecraft:air
setblock ~64 ~-66 ~46 minecraft:deepslate_tiles
setblock ~4 ~-66 ~47 minecraft:deepslate_tiles
setblock ~5 ~-66 ~47 minecraft:waxed_cut_copper
fill ~6 ~-66 ~47 ~16 ~-66 ~47 minecraft:air
setblock ~17 ~-66 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~47 minecraft:deepslate_tiles
setblock ~19 ~-66 ~47 minecraft:air
fill ~20 ~-66 ~47 ~23 ~-66 ~47 minecraft:barrel
setblock ~24 ~-66 ~47 minecraft:air
fill ~25 ~-66 ~47 ~26 ~-66 ~47 minecraft:barrel
fill ~27 ~-66 ~47 ~28 ~-66 ~47 minecraft:deepslate_tiles
fill ~29 ~-66 ~47 ~39 ~-66 ~47 minecraft:air
fill ~40 ~-66 ~47 ~41 ~-66 ~47 minecraft:deepslate_tiles
setblock ~42 ~-66 ~47 minecraft:air
fill ~43 ~-66 ~47 ~46 ~-66 ~47 minecraft:barrel
setblock ~47 ~-66 ~47 minecraft:air
setblock ~48 ~-66 ~47 minecraft:barrel
setblock ~49 ~-66 ~47 minecraft:air
setblock ~50 ~-66 ~47 minecraft:deepslate_tiles
fill ~51 ~-66 ~47 ~63 ~-66 ~47 minecraft:air
setblock ~64 ~-66 ~47 minecraft:deepslate_tiles
setblock ~4 ~-66 ~48 minecraft:deepslate_tiles
setblock ~5 ~-66 ~48 minecraft:redstone_lamp[lit=true]
fill ~6 ~-66 ~48 ~16 ~-66 ~48 minecraft:air
setblock ~17 ~-66 ~48 minecraft:redstone_lamp[lit=true]
setblock ~18 ~-66 ~48 minecraft:deepslate_tiles
fill ~19 ~-66 ~48 ~28 ~-66 ~48 minecraft:air
fill ~29 ~-66 ~48 ~32 ~-66 ~48 minecraft:deepslate_tiles
fill ~33 ~-66 ~48 ~35 ~-66 ~48 minecraft:air
fill ~36 ~-66 ~48 ~39 ~-66 ~48 minecraft:deepslate_tiles
fill ~40 ~-66 ~48 ~49 ~-66 ~48 minecraft:air
setblock ~50 ~-66 ~48 minecraft:deepslate_tiles
setblock ~51 ~-66 ~48 minecraft:air
setblock ~52 ~-66 ~48 minecraft:barrel
fill ~53 ~-66 ~48 ~54 ~-66 ~48 minecraft:air
setblock ~55 ~-66 ~48 minecraft:barrel
fill ~56 ~-66 ~48 ~57 ~-66 ~48 minecraft:air
setblock ~58 ~-66 ~48 minecraft:barrel
fill ~59 ~-66 ~48 ~60 ~-66 ~48 minecraft:air
setblock ~61 ~-66 ~48 minecraft:barrel
fill ~62 ~-66 ~48 ~63 ~-66 ~48 minecraft:air
setblock ~64 ~-66 ~48 minecraft:deepslate_tiles
setblock ~4 ~-66 ~49 minecraft:deepslate_tiles
setblock ~5 ~-66 ~49 minecraft:blast_furnace[facing=north]
setblock ~6 ~-66 ~49 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~49 minecraft:redstone_lamp[lit=true]
setblock ~8 ~-66 ~49 minecraft:blast_furnace[facing=north]
setblock ~9 ~-66 ~49 minecraft:waxed_cut_copper
fill ~10 ~-66 ~49 ~12 ~-66 ~49 minecraft:air
setblock ~13 ~-66 ~49 minecraft:redstone_lamp[lit=true]
setblock ~14 ~-66 ~49 minecraft:blast_furnace[facing=north]
setblock ~15 ~-66 ~49 minecraft:waxed_cut_copper
setblock ~16 ~-66 ~49 minecraft:redstone_lamp[lit=true]
setblock ~17 ~-66 ~49 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~49 minecraft:deepslate_tiles
fill ~19 ~-66 ~49 ~49 ~-66 ~49 minecraft:air
setblock ~50 ~-66 ~49 minecraft:deepslate_tiles
fill ~51 ~-66 ~49 ~63 ~-66 ~49 minecraft:air
setblock ~64 ~-66 ~49 minecraft:deepslate_tiles
fill ~4 ~-66 ~50 ~10 ~-66 ~50 minecraft:deepslate_tiles
setblock ~11 ~-66 ~50 minecraft:air
fill ~12 ~-66 ~50 ~31 ~-66 ~50 minecraft:deepslate_tiles
setblock ~32 ~-66 ~50 minecraft:yellow_concrete
fill ~33 ~-66 ~50 ~35 ~-66 ~50 minecraft:air
setblock ~36 ~-66 ~50 minecraft:yellow_concrete
fill ~37 ~-66 ~50 ~56 ~-66 ~50 minecraft:deepslate_tiles
setblock ~57 ~-66 ~50 minecraft:air
fill ~58 ~-66 ~50 ~64 ~-66 ~50 minecraft:deepslate_tiles
setblock ~4 ~-66 ~51 minecraft:deepslate_tiles
setblock ~5 ~-66 ~51 minecraft:blast_furnace[facing=south]
setblock ~6 ~-66 ~51 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~51 minecraft:blast_furnace[facing=south]
setblock ~8 ~-66 ~51 minecraft:waxed_cut_copper
setblock ~9 ~-66 ~51 minecraft:blast_furnace[facing=south]
fill ~10 ~-66 ~51 ~12 ~-66 ~51 minecraft:air
setblock ~13 ~-66 ~51 minecraft:blast_furnace[facing=south]
setblock ~14 ~-66 ~51 minecraft:waxed_cut_copper
setblock ~15 ~-66 ~51 minecraft:blast_furnace[facing=south]
setblock ~16 ~-66 ~51 minecraft:waxed_cut_copper
setblock ~17 ~-66 ~51 minecraft:blast_furnace[facing=south]
setblock ~18 ~-66 ~51 minecraft:deepslate_tiles
fill ~19 ~-66 ~51 ~31 ~-66 ~51 minecraft:air
setblock ~32 ~-66 ~51 minecraft:yellow_concrete
fill ~33 ~-66 ~51 ~35 ~-66 ~51 minecraft:air
setblock ~36 ~-66 ~51 minecraft:yellow_concrete
fill ~37 ~-66 ~51 ~49 ~-66 ~51 minecraft:air
setblock ~50 ~-66 ~51 minecraft:deepslate_tiles
setblock ~51 ~-66 ~51 minecraft:waxed_cut_copper
fill ~52 ~-66 ~51 ~53 ~-66 ~51 minecraft:air
setblock ~54 ~-66 ~51 minecraft:waxed_cut_copper
fill ~55 ~-66 ~51 ~59 ~-66 ~51 minecraft:air
setblock ~60 ~-66 ~51 minecraft:waxed_cut_copper
fill ~61 ~-66 ~51 ~62 ~-66 ~51 minecraft:air
setblock ~63 ~-66 ~51 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~51 minecraft:deepslate_tiles
setblock ~4 ~-66 ~52 minecraft:deepslate_tiles
setblock ~5 ~-66 ~52 minecraft:waxed_cut_copper
fill ~6 ~-66 ~52 ~16 ~-66 ~52 minecraft:air
setblock ~17 ~-66 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~52 minecraft:deepslate_tiles
setblock ~19 ~-66 ~52 minecraft:air
fill ~20 ~-66 ~52 ~23 ~-66 ~52 minecraft:barrel
setblock ~24 ~-66 ~52 minecraft:air
fill ~25 ~-66 ~52 ~28 ~-66 ~52 minecraft:barrel
setblock ~29 ~-66 ~52 minecraft:air
setblock ~30 ~-66 ~52 minecraft:barrel
setblock ~31 ~-66 ~52 minecraft:air
setblock ~32 ~-66 ~52 minecraft:yellow_concrete
fill ~33 ~-66 ~52 ~35 ~-66 ~52 minecraft:air
setblock ~36 ~-66 ~52 minecraft:yellow_concrete
fill ~37 ~-66 ~52 ~49 ~-66 ~52 minecraft:air
setblock ~50 ~-66 ~52 minecraft:deepslate_tiles
fill ~51 ~-66 ~52 ~63 ~-66 ~52 minecraft:air
setblock ~64 ~-66 ~52 minecraft:deepslate_tiles
setblock ~4 ~-66 ~53 minecraft:deepslate_tiles
setblock ~5 ~-66 ~53 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~53 ~16 ~-66 ~53 minecraft:air
setblock ~17 ~-66 ~53 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~53 minecraft:deepslate_tiles
fill ~19 ~-66 ~53 ~31 ~-66 ~53 minecraft:air
setblock ~32 ~-66 ~53 minecraft:yellow_concrete
fill ~33 ~-66 ~53 ~35 ~-66 ~53 minecraft:air
setblock ~36 ~-66 ~53 minecraft:yellow_concrete
fill ~37 ~-66 ~53 ~49 ~-66 ~53 minecraft:air
setblock ~50 ~-66 ~53 minecraft:deepslate_tiles
fill ~51 ~-66 ~53 ~63 ~-66 ~53 minecraft:air
setblock ~64 ~-66 ~53 minecraft:deepslate_tiles
setblock ~4 ~-66 ~54 minecraft:deepslate_tiles
setblock ~5 ~-66 ~54 minecraft:waxed_cut_copper
fill ~6 ~-66 ~54 ~16 ~-66 ~54 minecraft:air
setblock ~17 ~-66 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~54 minecraft:deepslate_tiles
fill ~19 ~-66 ~54 ~31 ~-66 ~54 minecraft:air
setblock ~32 ~-66 ~54 minecraft:yellow_concrete
fill ~33 ~-66 ~54 ~35 ~-66 ~54 minecraft:air
setblock ~36 ~-66 ~54 minecraft:yellow_concrete
fill ~37 ~-66 ~54 ~49 ~-66 ~54 minecraft:air
setblock ~50 ~-66 ~54 minecraft:deepslate_tiles
setblock ~51 ~-66 ~54 minecraft:waxed_cut_copper
fill ~52 ~-66 ~54 ~62 ~-66 ~54 minecraft:air
setblock ~63 ~-66 ~54 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~54 minecraft:deepslate_tiles
setblock ~4 ~-66 ~55 minecraft:deepslate_tiles
setblock ~5 ~-66 ~55 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~55 ~16 ~-66 ~55 minecraft:air
setblock ~17 ~-66 ~55 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~55 minecraft:deepslate_tiles
setblock ~19 ~-66 ~55 minecraft:air
fill ~20 ~-66 ~55 ~23 ~-66 ~55 minecraft:barrel
setblock ~24 ~-66 ~55 minecraft:air
fill ~25 ~-66 ~55 ~28 ~-66 ~55 minecraft:barrel
setblock ~29 ~-66 ~55 minecraft:air
setblock ~30 ~-66 ~55 minecraft:barrel
setblock ~31 ~-66 ~55 minecraft:air
setblock ~32 ~-66 ~55 minecraft:yellow_concrete
fill ~33 ~-66 ~55 ~35 ~-66 ~55 minecraft:air
setblock ~36 ~-66 ~55 minecraft:yellow_concrete
fill ~37 ~-66 ~55 ~49 ~-66 ~55 minecraft:air
setblock ~50 ~-66 ~55 minecraft:deepslate_tiles
fill ~51 ~-66 ~55 ~63 ~-66 ~55 minecraft:air
setblock ~64 ~-66 ~55 minecraft:deepslate_tiles
setblock ~4 ~-66 ~56 minecraft:deepslate_tiles
setblock ~5 ~-66 ~56 minecraft:waxed_cut_copper
fill ~6 ~-66 ~56 ~17 ~-66 ~56 minecraft:air
setblock ~18 ~-66 ~56 minecraft:deepslate_tiles
fill ~19 ~-66 ~56 ~31 ~-66 ~56 minecraft:air
setblock ~32 ~-66 ~56 minecraft:yellow_concrete
fill ~33 ~-66 ~56 ~35 ~-66 ~56 minecraft:air
setblock ~36 ~-66 ~56 minecraft:yellow_concrete
fill ~37 ~-66 ~56 ~49 ~-66 ~56 minecraft:air
setblock ~50 ~-66 ~56 minecraft:deepslate_tiles
fill ~51 ~-66 ~56 ~63 ~-66 ~56 minecraft:air
setblock ~64 ~-66 ~56 minecraft:deepslate_tiles
setblock ~4 ~-66 ~57 minecraft:deepslate_tiles
setblock ~5 ~-66 ~57 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~57 ~11 ~-66 ~57 minecraft:air
setblock ~12 ~-66 ~57 minecraft:waxed_cut_copper
fill ~13 ~-66 ~57 ~62 ~-66 ~57 minecraft:air
setblock ~63 ~-66 ~57 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~57 minecraft:deepslate_tiles
setblock ~4 ~-66 ~58 minecraft:deepslate_tiles
setblock ~5 ~-66 ~58 minecraft:waxed_cut_copper
fill ~6 ~-66 ~58 ~17 ~-66 ~58 minecraft:air
setblock ~18 ~-66 ~58 minecraft:deepslate_tiles
setblock ~19 ~-66 ~58 minecraft:air
fill ~20 ~-66 ~58 ~23 ~-66 ~58 minecraft:barrel
setblock ~24 ~-66 ~58 minecraft:air
fill ~25 ~-66 ~58 ~28 ~-66 ~58 minecraft:barrel
setblock ~29 ~-66 ~58 minecraft:air
setblock ~30 ~-66 ~58 minecraft:barrel
setblock ~31 ~-66 ~58 minecraft:air
setblock ~32 ~-66 ~58 minecraft:yellow_concrete
fill ~33 ~-66 ~58 ~35 ~-66 ~58 minecraft:air
setblock ~36 ~-66 ~58 minecraft:yellow_concrete
fill ~37 ~-66 ~58 ~49 ~-66 ~58 minecraft:air
setblock ~50 ~-66 ~58 minecraft:deepslate_tiles
fill ~51 ~-66 ~58 ~63 ~-66 ~58 minecraft:air
setblock ~64 ~-66 ~58 minecraft:deepslate_tiles
setblock ~4 ~-66 ~59 minecraft:deepslate_tiles
setblock ~5 ~-66 ~59 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~59 ~16 ~-66 ~59 minecraft:air
setblock ~17 ~-66 ~59 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~59 minecraft:deepslate_tiles
fill ~19 ~-66 ~59 ~31 ~-66 ~59 minecraft:air
setblock ~32 ~-66 ~59 minecraft:yellow_concrete
fill ~33 ~-66 ~59 ~35 ~-66 ~59 minecraft:air
setblock ~36 ~-66 ~59 minecraft:yellow_concrete
fill ~37 ~-66 ~59 ~49 ~-66 ~59 minecraft:air
setblock ~50 ~-66 ~59 minecraft:deepslate_tiles
fill ~51 ~-66 ~59 ~63 ~-66 ~59 minecraft:air
setblock ~64 ~-66 ~59 minecraft:deepslate_tiles
setblock ~4 ~-66 ~60 minecraft:deepslate_tiles
setblock ~5 ~-66 ~60 minecraft:waxed_cut_copper
fill ~6 ~-66 ~60 ~16 ~-66 ~60 minecraft:air
setblock ~17 ~-66 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~60 minecraft:deepslate_tiles
fill ~19 ~-66 ~60 ~31 ~-66 ~60 minecraft:air
setblock ~32 ~-66 ~60 minecraft:yellow_concrete
fill ~33 ~-66 ~60 ~35 ~-66 ~60 minecraft:air
setblock ~36 ~-66 ~60 minecraft:yellow_concrete
fill ~37 ~-66 ~60 ~49 ~-66 ~60 minecraft:air
setblock ~50 ~-66 ~60 minecraft:deepslate_tiles
setblock ~51 ~-66 ~60 minecraft:waxed_cut_copper
fill ~52 ~-66 ~60 ~62 ~-66 ~60 minecraft:air
setblock ~63 ~-66 ~60 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~60 minecraft:deepslate_tiles
setblock ~4 ~-66 ~61 minecraft:deepslate_tiles
setblock ~5 ~-66 ~61 minecraft:blast_furnace[facing=east]
fill ~6 ~-66 ~61 ~16 ~-66 ~61 minecraft:air
setblock ~17 ~-66 ~61 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~61 minecraft:deepslate_tiles
setblock ~19 ~-66 ~61 minecraft:air
fill ~20 ~-66 ~61 ~23 ~-66 ~61 minecraft:barrel
setblock ~24 ~-66 ~61 minecraft:air
fill ~25 ~-66 ~61 ~28 ~-66 ~61 minecraft:barrel
setblock ~29 ~-66 ~61 minecraft:air
setblock ~30 ~-66 ~61 minecraft:barrel
setblock ~31 ~-66 ~61 minecraft:air
setblock ~32 ~-66 ~61 minecraft:yellow_concrete
fill ~33 ~-66 ~61 ~35 ~-66 ~61 minecraft:air
setblock ~36 ~-66 ~61 minecraft:yellow_concrete
fill ~37 ~-66 ~61 ~49 ~-66 ~61 minecraft:air
setblock ~50 ~-66 ~61 minecraft:deepslate_tiles
fill ~51 ~-66 ~61 ~63 ~-66 ~61 minecraft:air
setblock ~64 ~-66 ~61 minecraft:deepslate_tiles
setblock ~4 ~-66 ~62 minecraft:deepslate_tiles
setblock ~5 ~-66 ~62 minecraft:waxed_cut_copper
fill ~6 ~-66 ~62 ~16 ~-66 ~62 minecraft:air
setblock ~17 ~-66 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-66 ~62 minecraft:deepslate_tiles
fill ~19 ~-66 ~62 ~31 ~-66 ~62 minecraft:air
setblock ~32 ~-66 ~62 minecraft:yellow_concrete
fill ~33 ~-66 ~62 ~35 ~-66 ~62 minecraft:air
setblock ~36 ~-66 ~62 minecraft:yellow_concrete
fill ~37 ~-66 ~62 ~49 ~-66 ~62 minecraft:air
setblock ~50 ~-66 ~62 minecraft:deepslate_tiles
fill ~51 ~-66 ~62 ~63 ~-66 ~62 minecraft:air
setblock ~64 ~-66 ~62 minecraft:deepslate_tiles
setblock ~4 ~-66 ~63 minecraft:deepslate_tiles
setblock ~5 ~-66 ~63 minecraft:blast_furnace[facing=north]
setblock ~6 ~-66 ~63 minecraft:waxed_cut_copper
setblock ~7 ~-66 ~63 minecraft:blast_furnace[facing=north]
setblock ~8 ~-66 ~63 minecraft:waxed_cut_copper
setblock ~9 ~-66 ~63 minecraft:blast_furnace[facing=north]
setblock ~10 ~-66 ~63 minecraft:waxed_cut_copper
setblock ~11 ~-66 ~63 minecraft:blast_furnace[facing=north]
setblock ~12 ~-66 ~63 minecraft:waxed_cut_copper
setblock ~13 ~-66 ~63 minecraft:blast_furnace[facing=north]
setblock ~14 ~-66 ~63 minecraft:waxed_cut_copper
setblock ~15 ~-66 ~63 minecraft:blast_furnace[facing=north]
setblock ~16 ~-66 ~63 minecraft:waxed_cut_copper
setblock ~17 ~-66 ~63 minecraft:blast_furnace[facing=west]
setblock ~18 ~-66 ~63 minecraft:deepslate_tiles
fill ~19 ~-66 ~63 ~31 ~-66 ~63 minecraft:air
setblock ~32 ~-66 ~63 minecraft:yellow_concrete
fill ~33 ~-66 ~63 ~35 ~-66 ~63 minecraft:air
setblock ~36 ~-66 ~63 minecraft:yellow_concrete
fill ~37 ~-66 ~63 ~49 ~-66 ~63 minecraft:air
setblock ~50 ~-66 ~63 minecraft:deepslate_tiles
setblock ~51 ~-66 ~63 minecraft:waxed_cut_copper
fill ~52 ~-66 ~63 ~53 ~-66 ~63 minecraft:air
setblock ~54 ~-66 ~63 minecraft:waxed_cut_copper
fill ~55 ~-66 ~63 ~56 ~-66 ~63 minecraft:air
setblock ~57 ~-66 ~63 minecraft:waxed_cut_copper
fill ~58 ~-66 ~63 ~59 ~-66 ~63 minecraft:air
setblock ~60 ~-66 ~63 minecraft:waxed_cut_copper
fill ~61 ~-66 ~63 ~62 ~-66 ~63 minecraft:air
setblock ~63 ~-66 ~63 minecraft:waxed_cut_copper
setblock ~64 ~-66 ~63 minecraft:deepslate_tiles
fill ~4 ~-66 ~64 ~33 ~-66 ~64 minecraft:deepslate_tiles
setblock ~34 ~-66 ~64 minecraft:air
fill ~35 ~-66 ~64 ~64 ~-66 ~64 minecraft:deepslate_tiles
setblock ~33 ~-66 ~65 minecraft:deepslate_tiles
setblock ~34 ~-66 ~65 minecraft:air
setblock ~35 ~-66 ~65 minecraft:deepslate_tiles
fill ~32 ~-66 ~66 ~33 ~-66 ~66 minecraft:polished_andesite
setblock ~34 ~-66 ~66 minecraft:air
fill ~35 ~-66 ~66 ~36 ~-66 ~66 minecraft:polished_andesite
setblock ~32 ~-66 ~67 minecraft:polished_andesite
fill ~33 ~-66 ~67 ~35 ~-66 ~67 minecraft:air
setblock ~36 ~-66 ~67 minecraft:polished_andesite
setblock ~32 ~-66 ~68 minecraft:polished_andesite
setblock ~33 ~-66 ~68 minecraft:air
setblock ~34 ~-66 ~68 minecraft:quartz_pillar
setblock ~35 ~-66 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-66 ~68 minecraft:polished_andesite
setblock ~32 ~-66 ~69 minecraft:polished_andesite
fill ~33 ~-66 ~69 ~35 ~-66 ~69 minecraft:air
setblock ~36 ~-66 ~69 minecraft:polished_andesite
fill ~32 ~-66 ~70 ~36 ~-66 ~70 minecraft:polished_andesite
fill ~4 ~-65 ~4 ~64 ~-65 ~4 minecraft:deepslate_tiles
setblock ~4 ~-65 ~5 minecraft:deepslate_tiles
fill ~5 ~-65 ~5 ~17 ~-65 ~5 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~5 minecraft:deepslate_tiles
fill ~19 ~-65 ~5 ~31 ~-65 ~5 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~5 minecraft:deepslate_tiles
fill ~33 ~-65 ~5 ~35 ~-65 ~5 minecraft:air
setblock ~36 ~-65 ~5 minecraft:deepslate_tiles
setblock ~37 ~-65 ~5 minecraft:waxed_cut_copper
fill ~38 ~-65 ~5 ~39 ~-65 ~5 minecraft:air
setblock ~40 ~-65 ~5 minecraft:waxed_cut_copper
fill ~41 ~-65 ~5 ~42 ~-65 ~5 minecraft:air
setblock ~43 ~-65 ~5 minecraft:waxed_cut_copper
fill ~44 ~-65 ~5 ~45 ~-65 ~5 minecraft:air
setblock ~46 ~-65 ~5 minecraft:waxed_cut_copper
fill ~47 ~-65 ~5 ~48 ~-65 ~5 minecraft:air
setblock ~49 ~-65 ~5 minecraft:waxed_cut_copper
setblock ~50 ~-65 ~5 minecraft:deepslate_tiles
setblock ~51 ~-65 ~5 minecraft:air
setblock ~52 ~-65 ~5 minecraft:waxed_cut_copper
fill ~53 ~-65 ~5 ~54 ~-65 ~5 minecraft:air
setblock ~55 ~-65 ~5 minecraft:waxed_cut_copper
fill ~56 ~-65 ~5 ~57 ~-65 ~5 minecraft:air
setblock ~58 ~-65 ~5 minecraft:waxed_cut_copper
fill ~59 ~-65 ~5 ~60 ~-65 ~5 minecraft:air
setblock ~61 ~-65 ~5 minecraft:waxed_cut_copper
fill ~62 ~-65 ~5 ~63 ~-65 ~5 minecraft:air
setblock ~64 ~-65 ~5 minecraft:deepslate_tiles
setblock ~4 ~-65 ~6 minecraft:deepslate_tiles
setblock ~5 ~-65 ~6 minecraft:waxed_cut_copper
fill ~6 ~-65 ~6 ~16 ~-65 ~6 minecraft:air
setblock ~17 ~-65 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~6 minecraft:deepslate_tiles
setblock ~19 ~-65 ~6 minecraft:waxed_cut_copper
fill ~20 ~-65 ~6 ~30 ~-65 ~6 minecraft:air
setblock ~31 ~-65 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~6 minecraft:deepslate_tiles
fill ~33 ~-65 ~6 ~35 ~-65 ~6 minecraft:air
setblock ~36 ~-65 ~6 minecraft:deepslate_tiles
fill ~37 ~-65 ~6 ~49 ~-65 ~6 minecraft:air
setblock ~50 ~-65 ~6 minecraft:deepslate_tiles
setblock ~51 ~-65 ~6 minecraft:waxed_cut_copper
fill ~52 ~-65 ~6 ~62 ~-65 ~6 minecraft:air
setblock ~63 ~-65 ~6 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~6 minecraft:deepslate_tiles
setblock ~4 ~-65 ~7 minecraft:deepslate_tiles
setblock ~5 ~-65 ~7 minecraft:waxed_cut_copper
fill ~6 ~-65 ~7 ~16 ~-65 ~7 minecraft:air
setblock ~17 ~-65 ~7 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~7 minecraft:deepslate_tiles
setblock ~19 ~-65 ~7 minecraft:waxed_cut_copper
fill ~20 ~-65 ~7 ~30 ~-65 ~7 minecraft:air
setblock ~31 ~-65 ~7 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~7 minecraft:deepslate_tiles
fill ~33 ~-65 ~7 ~35 ~-65 ~7 minecraft:air
setblock ~36 ~-65 ~7 minecraft:deepslate_tiles
fill ~37 ~-65 ~7 ~49 ~-65 ~7 minecraft:air
setblock ~50 ~-65 ~7 minecraft:deepslate_tiles
fill ~51 ~-65 ~7 ~63 ~-65 ~7 minecraft:air
setblock ~64 ~-65 ~7 minecraft:deepslate_tiles
setblock ~4 ~-65 ~8 minecraft:deepslate_tiles
setblock ~5 ~-65 ~8 minecraft:waxed_cut_copper
fill ~6 ~-65 ~8 ~16 ~-65 ~8 minecraft:air
setblock ~17 ~-65 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~8 minecraft:deepslate_tiles
setblock ~19 ~-65 ~8 minecraft:waxed_cut_copper
fill ~20 ~-65 ~8 ~30 ~-65 ~8 minecraft:air
setblock ~31 ~-65 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~8 minecraft:deepslate_tiles
fill ~33 ~-65 ~8 ~35 ~-65 ~8 minecraft:air
setblock ~36 ~-65 ~8 minecraft:deepslate_tiles
setblock ~37 ~-65 ~8 minecraft:waxed_cut_copper
fill ~38 ~-65 ~8 ~48 ~-65 ~8 minecraft:air
setblock ~49 ~-65 ~8 minecraft:waxed_cut_copper
setblock ~50 ~-65 ~8 minecraft:deepslate_tiles
fill ~51 ~-65 ~8 ~63 ~-65 ~8 minecraft:air
setblock ~64 ~-65 ~8 minecraft:deepslate_tiles
setblock ~4 ~-65 ~9 minecraft:deepslate_tiles
setblock ~5 ~-65 ~9 minecraft:waxed_cut_copper
fill ~6 ~-65 ~9 ~16 ~-65 ~9 minecraft:air
setblock ~17 ~-65 ~9 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~9 minecraft:deepslate_tiles
setblock ~19 ~-65 ~9 minecraft:waxed_cut_copper
fill ~20 ~-65 ~9 ~30 ~-65 ~9 minecraft:air
setblock ~31 ~-65 ~9 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~9 minecraft:deepslate_tiles
fill ~33 ~-65 ~9 ~35 ~-65 ~9 minecraft:air
setblock ~36 ~-65 ~9 minecraft:deepslate_tiles
fill ~37 ~-65 ~9 ~49 ~-65 ~9 minecraft:air
setblock ~50 ~-65 ~9 minecraft:deepslate_tiles
setblock ~51 ~-65 ~9 minecraft:waxed_cut_copper
fill ~52 ~-65 ~9 ~62 ~-65 ~9 minecraft:air
setblock ~63 ~-65 ~9 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~9 minecraft:deepslate_tiles
setblock ~4 ~-65 ~10 minecraft:deepslate_tiles
setblock ~5 ~-65 ~10 minecraft:waxed_cut_copper
fill ~6 ~-65 ~10 ~17 ~-65 ~10 minecraft:air
setblock ~18 ~-65 ~10 minecraft:deepslate_tiles
fill ~19 ~-65 ~10 ~31 ~-65 ~10 minecraft:air
setblock ~32 ~-65 ~10 minecraft:deepslate_tiles
fill ~33 ~-65 ~10 ~35 ~-65 ~10 minecraft:air
setblock ~36 ~-65 ~10 minecraft:deepslate_tiles
fill ~37 ~-65 ~10 ~49 ~-65 ~10 minecraft:air
setblock ~50 ~-65 ~10 minecraft:deepslate_tiles
fill ~51 ~-65 ~10 ~63 ~-65 ~10 minecraft:air
setblock ~64 ~-65 ~10 minecraft:deepslate_tiles
setblock ~4 ~-65 ~11 minecraft:deepslate_tiles
setblock ~5 ~-65 ~11 minecraft:waxed_cut_copper
fill ~6 ~-65 ~11 ~17 ~-65 ~11 minecraft:air
setblock ~18 ~-65 ~11 minecraft:deepslate_tiles
fill ~19 ~-65 ~11 ~31 ~-65 ~11 minecraft:air
setblock ~32 ~-65 ~11 minecraft:deepslate_tiles
fill ~33 ~-65 ~11 ~35 ~-65 ~11 minecraft:air
setblock ~36 ~-65 ~11 minecraft:deepslate_tiles
fill ~37 ~-65 ~11 ~49 ~-65 ~11 minecraft:air
setblock ~50 ~-65 ~11 minecraft:deepslate_tiles
fill ~51 ~-65 ~11 ~63 ~-65 ~11 minecraft:air
setblock ~64 ~-65 ~11 minecraft:deepslate_tiles
setblock ~4 ~-65 ~12 minecraft:deepslate_tiles
setblock ~5 ~-65 ~12 minecraft:waxed_cut_copper
fill ~6 ~-65 ~12 ~11 ~-65 ~12 minecraft:air
setblock ~12 ~-65 ~12 minecraft:waxed_cut_copper
fill ~13 ~-65 ~12 ~17 ~-65 ~12 minecraft:air
setblock ~18 ~-65 ~12 minecraft:deepslate_tiles
fill ~19 ~-65 ~12 ~21 ~-65 ~12 minecraft:air
setblock ~22 ~-65 ~12 minecraft:waxed_cut_copper
fill ~23 ~-65 ~12 ~26 ~-65 ~12 minecraft:air
setblock ~27 ~-65 ~12 minecraft:waxed_cut_copper
fill ~28 ~-65 ~12 ~31 ~-65 ~12 minecraft:air
setblock ~32 ~-65 ~12 minecraft:deepslate_tiles
fill ~33 ~-65 ~12 ~35 ~-65 ~12 minecraft:air
setblock ~36 ~-65 ~12 minecraft:deepslate_tiles
fill ~37 ~-65 ~12 ~49 ~-65 ~12 minecraft:air
setblock ~50 ~-65 ~12 minecraft:deepslate_tiles
fill ~51 ~-65 ~12 ~62 ~-65 ~12 minecraft:air
setblock ~63 ~-65 ~12 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~12 minecraft:deepslate_tiles
setblock ~4 ~-65 ~13 minecraft:deepslate_tiles
setblock ~5 ~-65 ~13 minecraft:waxed_cut_copper
fill ~6 ~-65 ~13 ~16 ~-65 ~13 minecraft:air
setblock ~17 ~-65 ~13 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~13 minecraft:deepslate_tiles
setblock ~19 ~-65 ~13 minecraft:waxed_cut_copper
fill ~20 ~-65 ~13 ~30 ~-65 ~13 minecraft:air
setblock ~31 ~-65 ~13 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~13 minecraft:deepslate_tiles
fill ~33 ~-65 ~13 ~35 ~-65 ~13 minecraft:air
setblock ~36 ~-65 ~13 minecraft:deepslate_tiles
fill ~37 ~-65 ~13 ~49 ~-65 ~13 minecraft:air
setblock ~50 ~-65 ~13 minecraft:deepslate_tiles
fill ~51 ~-65 ~13 ~63 ~-65 ~13 minecraft:air
setblock ~64 ~-65 ~13 minecraft:deepslate_tiles
setblock ~4 ~-65 ~14 minecraft:deepslate_tiles
setblock ~5 ~-65 ~14 minecraft:waxed_cut_copper
fill ~6 ~-65 ~14 ~16 ~-65 ~14 minecraft:air
setblock ~17 ~-65 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~14 minecraft:deepslate_tiles
setblock ~19 ~-65 ~14 minecraft:waxed_cut_copper
fill ~20 ~-65 ~14 ~30 ~-65 ~14 minecraft:air
setblock ~31 ~-65 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~14 minecraft:deepslate_tiles
fill ~33 ~-65 ~14 ~35 ~-65 ~14 minecraft:air
setblock ~36 ~-65 ~14 minecraft:deepslate_tiles
setblock ~37 ~-65 ~14 minecraft:waxed_cut_copper
fill ~38 ~-65 ~14 ~48 ~-65 ~14 minecraft:air
setblock ~49 ~-65 ~14 minecraft:waxed_cut_copper
setblock ~50 ~-65 ~14 minecraft:deepslate_tiles
fill ~51 ~-65 ~14 ~63 ~-65 ~14 minecraft:air
setblock ~64 ~-65 ~14 minecraft:deepslate_tiles
setblock ~4 ~-65 ~15 minecraft:deepslate_tiles
setblock ~5 ~-65 ~15 minecraft:waxed_cut_copper
fill ~6 ~-65 ~15 ~16 ~-65 ~15 minecraft:air
setblock ~17 ~-65 ~15 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~15 minecraft:deepslate_tiles
setblock ~19 ~-65 ~15 minecraft:waxed_cut_copper
fill ~20 ~-65 ~15 ~30 ~-65 ~15 minecraft:air
setblock ~31 ~-65 ~15 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~15 minecraft:deepslate_tiles
fill ~33 ~-65 ~15 ~35 ~-65 ~15 minecraft:air
setblock ~36 ~-65 ~15 minecraft:deepslate_tiles
fill ~37 ~-65 ~15 ~49 ~-65 ~15 minecraft:air
setblock ~50 ~-65 ~15 minecraft:deepslate_tiles
setblock ~51 ~-65 ~15 minecraft:waxed_cut_copper
fill ~52 ~-65 ~15 ~62 ~-65 ~15 minecraft:air
setblock ~63 ~-65 ~15 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~15 minecraft:deepslate_tiles
setblock ~4 ~-65 ~16 minecraft:deepslate_tiles
setblock ~5 ~-65 ~16 minecraft:waxed_cut_copper
fill ~6 ~-65 ~16 ~16 ~-65 ~16 minecraft:air
setblock ~17 ~-65 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~16 minecraft:deepslate_tiles
setblock ~19 ~-65 ~16 minecraft:waxed_cut_copper
fill ~20 ~-65 ~16 ~30 ~-65 ~16 minecraft:air
setblock ~31 ~-65 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~16 minecraft:deepslate_tiles
fill ~33 ~-65 ~16 ~35 ~-65 ~16 minecraft:air
setblock ~36 ~-65 ~16 minecraft:deepslate_tiles
fill ~37 ~-65 ~16 ~49 ~-65 ~16 minecraft:air
setblock ~50 ~-65 ~16 minecraft:deepslate_tiles
fill ~51 ~-65 ~16 ~63 ~-65 ~16 minecraft:air
setblock ~64 ~-65 ~16 minecraft:deepslate_tiles
setblock ~4 ~-65 ~17 minecraft:deepslate_tiles
fill ~5 ~-65 ~17 ~9 ~-65 ~17 minecraft:waxed_cut_copper
fill ~10 ~-65 ~17 ~12 ~-65 ~17 minecraft:air
fill ~13 ~-65 ~17 ~17 ~-65 ~17 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~17 minecraft:deepslate_tiles
fill ~19 ~-65 ~17 ~31 ~-65 ~17 minecraft:waxed_cut_copper
setblock ~32 ~-65 ~17 minecraft:deepslate_tiles
fill ~33 ~-65 ~17 ~35 ~-65 ~17 minecraft:air
setblock ~36 ~-65 ~17 minecraft:deepslate_tiles
setblock ~37 ~-65 ~17 minecraft:waxed_cut_copper
fill ~38 ~-65 ~17 ~39 ~-65 ~17 minecraft:air
setblock ~40 ~-65 ~17 minecraft:waxed_cut_copper
fill ~41 ~-65 ~17 ~42 ~-65 ~17 minecraft:air
setblock ~43 ~-65 ~17 minecraft:waxed_cut_copper
fill ~44 ~-65 ~17 ~45 ~-65 ~17 minecraft:air
setblock ~46 ~-65 ~17 minecraft:waxed_cut_copper
fill ~47 ~-65 ~17 ~48 ~-65 ~17 minecraft:air
setblock ~49 ~-65 ~17 minecraft:waxed_cut_copper
setblock ~50 ~-65 ~17 minecraft:deepslate_tiles
setblock ~51 ~-65 ~17 minecraft:air
setblock ~52 ~-65 ~17 minecraft:waxed_cut_copper
fill ~53 ~-65 ~17 ~54 ~-65 ~17 minecraft:air
setblock ~55 ~-65 ~17 minecraft:waxed_cut_copper
fill ~56 ~-65 ~17 ~60 ~-65 ~17 minecraft:air
setblock ~61 ~-65 ~17 minecraft:waxed_cut_copper
fill ~62 ~-65 ~17 ~63 ~-65 ~17 minecraft:air
setblock ~64 ~-65 ~17 minecraft:deepslate_tiles
fill ~4 ~-65 ~18 ~32 ~-65 ~18 minecraft:deepslate_tiles
fill ~33 ~-65 ~18 ~35 ~-65 ~18 minecraft:air
fill ~36 ~-65 ~18 ~64 ~-65 ~18 minecraft:deepslate_tiles
setblock ~4 ~-65 ~19 minecraft:deepslate_tiles
setblock ~5 ~-65 ~19 minecraft:air
setblock ~6 ~-65 ~19 minecraft:waxed_cut_copper
fill ~7 ~-65 ~19 ~8 ~-65 ~19 minecraft:air
setblock ~9 ~-65 ~19 minecraft:waxed_cut_copper
fill ~10 ~-65 ~19 ~14 ~-65 ~19 minecraft:air
setblock ~15 ~-65 ~19 minecraft:waxed_cut_copper
fill ~16 ~-65 ~19 ~17 ~-65 ~19 minecraft:air
setblock ~18 ~-65 ~19 minecraft:deepslate_tiles
fill ~19 ~-65 ~19 ~31 ~-65 ~19 minecraft:air
setblock ~32 ~-65 ~19 minecraft:deepslate_tiles
fill ~33 ~-65 ~19 ~35 ~-65 ~19 minecraft:air
setblock ~36 ~-65 ~19 minecraft:deepslate_tiles
fill ~37 ~-65 ~19 ~49 ~-65 ~19 minecraft:air
setblock ~50 ~-65 ~19 minecraft:deepslate_tiles
fill ~51 ~-65 ~19 ~63 ~-65 ~19 minecraft:air
setblock ~64 ~-65 ~19 minecraft:deepslate_tiles
setblock ~4 ~-65 ~20 minecraft:deepslate_tiles
setblock ~5 ~-65 ~20 minecraft:waxed_cut_copper
fill ~6 ~-65 ~20 ~16 ~-65 ~20 minecraft:air
setblock ~17 ~-65 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~20 minecraft:deepslate_tiles
fill ~19 ~-65 ~20 ~28 ~-65 ~20 minecraft:air
fill ~29 ~-65 ~20 ~32 ~-65 ~20 minecraft:deepslate_tiles
fill ~33 ~-65 ~20 ~35 ~-65 ~20 minecraft:air
fill ~36 ~-65 ~20 ~39 ~-65 ~20 minecraft:deepslate_tiles
fill ~40 ~-65 ~20 ~49 ~-65 ~20 minecraft:air
setblock ~50 ~-65 ~20 minecraft:deepslate_tiles
fill ~51 ~-65 ~20 ~63 ~-65 ~20 minecraft:air
setblock ~64 ~-65 ~20 minecraft:deepslate_tiles
setblock ~4 ~-65 ~21 minecraft:deepslate_tiles
fill ~5 ~-65 ~21 ~17 ~-65 ~21 minecraft:air
setblock ~18 ~-65 ~21 minecraft:deepslate_tiles
setblock ~19 ~-65 ~21 minecraft:air
fill ~20 ~-65 ~21 ~23 ~-65 ~21 minecraft:barrel
setblock ~24 ~-65 ~21 minecraft:air
fill ~25 ~-65 ~21 ~26 ~-65 ~21 minecraft:barrel
fill ~27 ~-65 ~21 ~28 ~-65 ~21 minecraft:deepslate_tiles
fill ~29 ~-65 ~21 ~39 ~-65 ~21 minecraft:air
fill ~40 ~-65 ~21 ~41 ~-65 ~21 minecraft:deepslate_tiles
setblock ~42 ~-65 ~21 minecraft:air
fill ~43 ~-65 ~21 ~46 ~-65 ~21 minecraft:barrel
setblock ~47 ~-65 ~21 minecraft:air
setblock ~48 ~-65 ~21 minecraft:barrel
setblock ~49 ~-65 ~21 minecraft:air
setblock ~50 ~-65 ~21 minecraft:deepslate_tiles
fill ~51 ~-65 ~21 ~63 ~-65 ~21 minecraft:air
setblock ~64 ~-65 ~21 minecraft:deepslate_tiles
setblock ~4 ~-65 ~22 minecraft:deepslate_tiles
fill ~5 ~-65 ~22 ~9 ~-65 ~22 minecraft:air
setblock ~10 ~-65 ~22 minecraft:lightning_rod[facing=up]
fill ~11 ~-65 ~22 ~13 ~-65 ~22 minecraft:air
setblock ~14 ~-65 ~22 minecraft:lightning_rod[facing=up]
fill ~15 ~-65 ~22 ~17 ~-65 ~22 minecraft:air
setblock ~18 ~-65 ~22 minecraft:deepslate_tiles
fill ~19 ~-65 ~22 ~24 ~-65 ~22 minecraft:air
fill ~25 ~-65 ~22 ~26 ~-65 ~22 minecraft:deepslate_tiles
fill ~27 ~-65 ~22 ~41 ~-65 ~22 minecraft:air
fill ~42 ~-65 ~22 ~43 ~-65 ~22 minecraft:deepslate_tiles
fill ~44 ~-65 ~22 ~49 ~-65 ~22 minecraft:air
setblock ~50 ~-65 ~22 minecraft:deepslate_tiles
fill ~51 ~-65 ~22 ~63 ~-65 ~22 minecraft:air
setblock ~64 ~-65 ~22 minecraft:deepslate_tiles
setblock ~4 ~-65 ~23 minecraft:deepslate_tiles
setblock ~5 ~-65 ~23 minecraft:waxed_cut_copper
fill ~6 ~-65 ~23 ~16 ~-65 ~23 minecraft:air
setblock ~17 ~-65 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~23 minecraft:deepslate_tiles
fill ~19 ~-65 ~23 ~23 ~-65 ~23 minecraft:air
fill ~24 ~-65 ~23 ~25 ~-65 ~23 minecraft:deepslate_tiles
fill ~26 ~-65 ~23 ~42 ~-65 ~23 minecraft:air
fill ~43 ~-65 ~23 ~44 ~-65 ~23 minecraft:deepslate_tiles
fill ~45 ~-65 ~23 ~49 ~-65 ~23 minecraft:air
setblock ~50 ~-65 ~23 minecraft:deepslate_tiles
fill ~51 ~-65 ~23 ~63 ~-65 ~23 minecraft:air
setblock ~64 ~-65 ~23 minecraft:deepslate_tiles
setblock ~4 ~-65 ~24 minecraft:deepslate_tiles
fill ~5 ~-65 ~24 ~17 ~-65 ~24 minecraft:air
setblock ~18 ~-65 ~24 minecraft:deepslate_tiles
setblock ~19 ~-65 ~24 minecraft:air
fill ~20 ~-65 ~24 ~22 ~-65 ~24 minecraft:barrel
fill ~23 ~-65 ~24 ~24 ~-65 ~24 minecraft:deepslate_tiles
fill ~25 ~-65 ~24 ~43 ~-65 ~24 minecraft:air
fill ~44 ~-65 ~24 ~45 ~-65 ~24 minecraft:deepslate_tiles
setblock ~46 ~-65 ~24 minecraft:barrel
setblock ~47 ~-65 ~24 minecraft:air
setblock ~48 ~-65 ~24 minecraft:barrel
setblock ~49 ~-65 ~24 minecraft:air
setblock ~50 ~-65 ~24 minecraft:deepslate_tiles
fill ~51 ~-65 ~24 ~63 ~-65 ~24 minecraft:air
setblock ~64 ~-65 ~24 minecraft:deepslate_tiles
setblock ~4 ~-65 ~25 minecraft:deepslate_tiles
fill ~5 ~-65 ~25 ~17 ~-65 ~25 minecraft:air
setblock ~18 ~-65 ~25 minecraft:deepslate_tiles
fill ~19 ~-65 ~25 ~21 ~-65 ~25 minecraft:air
fill ~22 ~-65 ~25 ~23 ~-65 ~25 minecraft:deepslate_tiles
fill ~24 ~-65 ~25 ~44 ~-65 ~25 minecraft:air
fill ~45 ~-65 ~25 ~46 ~-65 ~25 minecraft:deepslate_tiles
fill ~47 ~-65 ~25 ~49 ~-65 ~25 minecraft:air
setblock ~50 ~-65 ~25 minecraft:deepslate_tiles
fill ~51 ~-65 ~25 ~63 ~-65 ~25 minecraft:air
setblock ~64 ~-65 ~25 minecraft:deepslate_tiles
setblock ~4 ~-65 ~26 minecraft:deepslate_tiles
setblock ~5 ~-65 ~26 minecraft:waxed_cut_copper
fill ~6 ~-65 ~26 ~9 ~-65 ~26 minecraft:air
setblock ~10 ~-65 ~26 minecraft:lightning_rod[facing=up]
fill ~11 ~-65 ~26 ~13 ~-65 ~26 minecraft:air
setblock ~14 ~-65 ~26 minecraft:lightning_rod[facing=up]
fill ~15 ~-65 ~26 ~16 ~-65 ~26 minecraft:air
setblock ~17 ~-65 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~26 minecraft:deepslate_tiles
fill ~19 ~-65 ~26 ~21 ~-65 ~26 minecraft:air
setblock ~22 ~-65 ~26 minecraft:deepslate_tiles
fill ~23 ~-65 ~26 ~25 ~-65 ~26 minecraft:air
setblock ~26 ~-65 ~26 minecraft:waxed_cut_copper
fill ~27 ~-65 ~26 ~41 ~-65 ~26 minecraft:air
setblock ~42 ~-65 ~26 minecraft:waxed_cut_copper
fill ~43 ~-65 ~26 ~45 ~-65 ~26 minecraft:air
setblock ~46 ~-65 ~26 minecraft:deepslate_tiles
fill ~47 ~-65 ~26 ~49 ~-65 ~26 minecraft:air
setblock ~50 ~-65 ~26 minecraft:deepslate_tiles
fill ~51 ~-65 ~26 ~63 ~-65 ~26 minecraft:air
setblock ~64 ~-65 ~26 minecraft:deepslate_tiles
setblock ~4 ~-65 ~27 minecraft:deepslate_tiles
fill ~5 ~-65 ~27 ~17 ~-65 ~27 minecraft:air
setblock ~18 ~-65 ~27 minecraft:deepslate_tiles
setblock ~19 ~-65 ~27 minecraft:air
setblock ~20 ~-65 ~27 minecraft:barrel
setblock ~21 ~-65 ~27 minecraft:deepslate_tiles
fill ~22 ~-65 ~27 ~46 ~-65 ~27 minecraft:air
setblock ~47 ~-65 ~27 minecraft:deepslate_tiles
setblock ~48 ~-65 ~27 minecraft:barrel
setblock ~49 ~-65 ~27 minecraft:air
setblock ~50 ~-65 ~27 minecraft:deepslate_tiles
fill ~51 ~-65 ~27 ~63 ~-65 ~27 minecraft:air
setblock ~64 ~-65 ~27 minecraft:deepslate_tiles
setblock ~4 ~-65 ~28 minecraft:deepslate_tiles
fill ~5 ~-65 ~28 ~17 ~-65 ~28 minecraft:air
setblock ~18 ~-65 ~28 minecraft:deepslate_tiles
fill ~19 ~-65 ~28 ~20 ~-65 ~28 minecraft:air
setblock ~21 ~-65 ~28 minecraft:deepslate_tiles
fill ~22 ~-65 ~28 ~46 ~-65 ~28 minecraft:air
setblock ~47 ~-65 ~28 minecraft:deepslate_tiles
fill ~48 ~-65 ~28 ~49 ~-65 ~28 minecraft:air
setblock ~50 ~-65 ~28 minecraft:deepslate_tiles
fill ~51 ~-65 ~28 ~63 ~-65 ~28 minecraft:air
setblock ~64 ~-65 ~28 minecraft:deepslate_tiles
setblock ~4 ~-65 ~29 minecraft:deepslate_tiles
setblock ~5 ~-65 ~29 minecraft:waxed_cut_copper
fill ~6 ~-65 ~29 ~16 ~-65 ~29 minecraft:air
setblock ~17 ~-65 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~29 minecraft:deepslate_tiles
setblock ~19 ~-65 ~29 minecraft:air
setblock ~20 ~-65 ~29 minecraft:deepslate_tiles
fill ~21 ~-65 ~29 ~47 ~-65 ~29 minecraft:air
setblock ~48 ~-65 ~29 minecraft:deepslate_tiles
setblock ~49 ~-65 ~29 minecraft:air
setblock ~50 ~-65 ~29 minecraft:deepslate_tiles
fill ~51 ~-65 ~29 ~63 ~-65 ~29 minecraft:air
setblock ~64 ~-65 ~29 minecraft:deepslate_tiles
setblock ~4 ~-65 ~30 minecraft:deepslate_tiles
fill ~5 ~-65 ~30 ~17 ~-65 ~30 minecraft:air
setblock ~18 ~-65 ~30 minecraft:deepslate_tiles
setblock ~19 ~-65 ~30 minecraft:air
setblock ~20 ~-65 ~30 minecraft:deepslate_tiles
fill ~21 ~-65 ~30 ~47 ~-65 ~30 minecraft:air
setblock ~48 ~-65 ~30 minecraft:deepslate_tiles
setblock ~49 ~-65 ~30 minecraft:air
setblock ~50 ~-65 ~30 minecraft:deepslate_tiles
fill ~51 ~-65 ~30 ~63 ~-65 ~30 minecraft:air
setblock ~64 ~-65 ~30 minecraft:deepslate_tiles
setblock ~4 ~-65 ~31 minecraft:deepslate_tiles
setblock ~5 ~-65 ~31 minecraft:air
setblock ~6 ~-65 ~31 minecraft:waxed_cut_copper
fill ~7 ~-65 ~31 ~8 ~-65 ~31 minecraft:air
setblock ~9 ~-65 ~31 minecraft:waxed_cut_copper
fill ~10 ~-65 ~31 ~14 ~-65 ~31 minecraft:air
setblock ~15 ~-65 ~31 minecraft:waxed_cut_copper
fill ~16 ~-65 ~31 ~17 ~-65 ~31 minecraft:air
setblock ~18 ~-65 ~31 minecraft:deepslate_tiles
setblock ~19 ~-65 ~31 minecraft:air
setblock ~20 ~-65 ~31 minecraft:deepslate_tiles
fill ~21 ~-65 ~31 ~47 ~-65 ~31 minecraft:air
setblock ~48 ~-65 ~31 minecraft:deepslate_tiles
setblock ~49 ~-65 ~31 minecraft:air
setblock ~50 ~-65 ~31 minecraft:deepslate_tiles
fill ~51 ~-65 ~31 ~63 ~-65 ~31 minecraft:air
setblock ~64 ~-65 ~31 minecraft:deepslate_tiles
fill ~4 ~-65 ~32 ~20 ~-65 ~32 minecraft:deepslate_tiles
fill ~21 ~-65 ~32 ~32 ~-65 ~32 minecraft:air
fill ~33 ~-65 ~32 ~35 ~-65 ~32 minecraft:glass
fill ~36 ~-65 ~32 ~47 ~-65 ~32 minecraft:air
fill ~48 ~-65 ~32 ~64 ~-65 ~32 minecraft:deepslate_tiles
setblock ~4 ~-65 ~33 minecraft:deepslate_tiles
fill ~5 ~-65 ~33 ~31 ~-65 ~33 minecraft:air
setblock ~32 ~-65 ~33 minecraft:glass
fill ~33 ~-65 ~33 ~35 ~-65 ~33 minecraft:sea_lantern
setblock ~36 ~-65 ~33 minecraft:glass
fill ~37 ~-65 ~33 ~63 ~-65 ~33 minecraft:air
fill ~64 ~-65 ~33 ~68 ~-65 ~33 minecraft:deepslate_bricks
setblock ~4 ~-65 ~34 minecraft:deepslate_tiles
fill ~5 ~-65 ~34 ~31 ~-65 ~34 minecraft:air
setblock ~32 ~-65 ~34 minecraft:glass
fill ~33 ~-65 ~34 ~35 ~-65 ~34 minecraft:sea_lantern
setblock ~36 ~-65 ~34 minecraft:glass
fill ~37 ~-65 ~34 ~63 ~-65 ~34 minecraft:air
setblock ~64 ~-65 ~34 minecraft:deepslate_bricks
setblock ~65 ~-65 ~34 minecraft:sea_lantern
fill ~66 ~-65 ~34 ~68 ~-65 ~34 minecraft:deepslate_bricks
setblock ~4 ~-65 ~35 minecraft:deepslate_tiles
fill ~5 ~-65 ~35 ~31 ~-65 ~35 minecraft:air
setblock ~32 ~-65 ~35 minecraft:glass
fill ~33 ~-65 ~35 ~35 ~-65 ~35 minecraft:sea_lantern
setblock ~36 ~-65 ~35 minecraft:glass
fill ~37 ~-65 ~35 ~63 ~-65 ~35 minecraft:air
fill ~64 ~-65 ~35 ~68 ~-65 ~35 minecraft:deepslate_bricks
fill ~4 ~-65 ~36 ~20 ~-65 ~36 minecraft:deepslate_tiles
fill ~21 ~-65 ~36 ~32 ~-65 ~36 minecraft:air
fill ~33 ~-65 ~36 ~35 ~-65 ~36 minecraft:glass
fill ~36 ~-65 ~36 ~47 ~-65 ~36 minecraft:air
fill ~48 ~-65 ~36 ~64 ~-65 ~36 minecraft:deepslate_tiles
setblock ~4 ~-65 ~37 minecraft:deepslate_tiles
setblock ~5 ~-65 ~37 minecraft:air
setblock ~6 ~-65 ~37 minecraft:waxed_cut_copper
fill ~7 ~-65 ~37 ~8 ~-65 ~37 minecraft:air
setblock ~9 ~-65 ~37 minecraft:waxed_cut_copper
fill ~10 ~-65 ~37 ~14 ~-65 ~37 minecraft:air
setblock ~15 ~-65 ~37 minecraft:waxed_cut_copper
fill ~16 ~-65 ~37 ~17 ~-65 ~37 minecraft:air
setblock ~18 ~-65 ~37 minecraft:deepslate_tiles
setblock ~19 ~-65 ~37 minecraft:air
setblock ~20 ~-65 ~37 minecraft:deepslate_tiles
fill ~21 ~-65 ~37 ~47 ~-65 ~37 minecraft:air
setblock ~48 ~-65 ~37 minecraft:deepslate_tiles
setblock ~49 ~-65 ~37 minecraft:air
setblock ~50 ~-65 ~37 minecraft:deepslate_tiles
fill ~51 ~-65 ~37 ~63 ~-65 ~37 minecraft:air
setblock ~64 ~-65 ~37 minecraft:deepslate_tiles
setblock ~4 ~-65 ~38 minecraft:deepslate_tiles
setblock ~5 ~-65 ~38 minecraft:waxed_cut_copper
fill ~6 ~-65 ~38 ~16 ~-65 ~38 minecraft:air
setblock ~17 ~-65 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~38 minecraft:deepslate_tiles
setblock ~19 ~-65 ~38 minecraft:air
setblock ~20 ~-65 ~38 minecraft:deepslate_tiles
fill ~21 ~-65 ~38 ~47 ~-65 ~38 minecraft:air
setblock ~48 ~-65 ~38 minecraft:deepslate_tiles
setblock ~49 ~-65 ~38 minecraft:air
setblock ~50 ~-65 ~38 minecraft:deepslate_tiles
setblock ~51 ~-65 ~38 minecraft:air
setblock ~52 ~-65 ~38 minecraft:barrel
fill ~53 ~-65 ~38 ~54 ~-65 ~38 minecraft:air
setblock ~55 ~-65 ~38 minecraft:barrel
fill ~56 ~-65 ~38 ~57 ~-65 ~38 minecraft:air
setblock ~58 ~-65 ~38 minecraft:barrel
fill ~59 ~-65 ~38 ~60 ~-65 ~38 minecraft:air
setblock ~61 ~-65 ~38 minecraft:barrel
fill ~62 ~-65 ~38 ~63 ~-65 ~38 minecraft:air
setblock ~64 ~-65 ~38 minecraft:deepslate_tiles
setblock ~4 ~-65 ~39 minecraft:deepslate_tiles
fill ~5 ~-65 ~39 ~17 ~-65 ~39 minecraft:air
setblock ~18 ~-65 ~39 minecraft:deepslate_tiles
setblock ~19 ~-65 ~39 minecraft:air
setblock ~20 ~-65 ~39 minecraft:deepslate_tiles
fill ~21 ~-65 ~39 ~47 ~-65 ~39 minecraft:air
setblock ~48 ~-65 ~39 minecraft:deepslate_tiles
setblock ~49 ~-65 ~39 minecraft:air
setblock ~50 ~-65 ~39 minecraft:deepslate_tiles
setblock ~51 ~-65 ~39 minecraft:air
setblock ~52 ~-65 ~39 minecraft:barrel
fill ~53 ~-65 ~39 ~54 ~-65 ~39 minecraft:air
setblock ~55 ~-65 ~39 minecraft:barrel
fill ~56 ~-65 ~39 ~57 ~-65 ~39 minecraft:air
setblock ~58 ~-65 ~39 minecraft:barrel
fill ~59 ~-65 ~39 ~60 ~-65 ~39 minecraft:air
setblock ~61 ~-65 ~39 minecraft:barrel
fill ~62 ~-65 ~39 ~63 ~-65 ~39 minecraft:air
setblock ~64 ~-65 ~39 minecraft:deepslate_tiles
setblock ~4 ~-65 ~40 minecraft:deepslate_tiles
fill ~5 ~-65 ~40 ~17 ~-65 ~40 minecraft:air
setblock ~18 ~-65 ~40 minecraft:deepslate_tiles
fill ~19 ~-65 ~40 ~20 ~-65 ~40 minecraft:air
setblock ~21 ~-65 ~40 minecraft:deepslate_tiles
fill ~22 ~-65 ~40 ~46 ~-65 ~40 minecraft:air
setblock ~47 ~-65 ~40 minecraft:deepslate_tiles
fill ~48 ~-65 ~40 ~49 ~-65 ~40 minecraft:air
setblock ~50 ~-65 ~40 minecraft:deepslate_tiles
setblock ~51 ~-65 ~40 minecraft:air
setblock ~52 ~-65 ~40 minecraft:barrel
fill ~53 ~-65 ~40 ~54 ~-65 ~40 minecraft:air
setblock ~55 ~-65 ~40 minecraft:barrel
fill ~56 ~-65 ~40 ~57 ~-65 ~40 minecraft:air
setblock ~58 ~-65 ~40 minecraft:barrel
fill ~59 ~-65 ~40 ~60 ~-65 ~40 minecraft:air
setblock ~61 ~-65 ~40 minecraft:barrel
fill ~62 ~-65 ~40 ~63 ~-65 ~40 minecraft:air
setblock ~64 ~-65 ~40 minecraft:deepslate_tiles
setblock ~4 ~-65 ~41 minecraft:deepslate_tiles
setblock ~5 ~-65 ~41 minecraft:waxed_cut_copper
fill ~6 ~-65 ~41 ~16 ~-65 ~41 minecraft:air
setblock ~17 ~-65 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~41 minecraft:deepslate_tiles
setblock ~19 ~-65 ~41 minecraft:air
setblock ~20 ~-65 ~41 minecraft:barrel
setblock ~21 ~-65 ~41 minecraft:deepslate_tiles
fill ~22 ~-65 ~41 ~46 ~-65 ~41 minecraft:air
setblock ~47 ~-65 ~41 minecraft:deepslate_tiles
setblock ~48 ~-65 ~41 minecraft:barrel
setblock ~49 ~-65 ~41 minecraft:air
setblock ~50 ~-65 ~41 minecraft:deepslate_tiles
setblock ~51 ~-65 ~41 minecraft:air
setblock ~52 ~-65 ~41 minecraft:barrel
fill ~53 ~-65 ~41 ~54 ~-65 ~41 minecraft:air
setblock ~55 ~-65 ~41 minecraft:barrel
fill ~56 ~-65 ~41 ~57 ~-65 ~41 minecraft:air
setblock ~58 ~-65 ~41 minecraft:barrel
fill ~59 ~-65 ~41 ~60 ~-65 ~41 minecraft:air
setblock ~61 ~-65 ~41 minecraft:barrel
fill ~62 ~-65 ~41 ~63 ~-65 ~41 minecraft:air
setblock ~64 ~-65 ~41 minecraft:deepslate_tiles
setblock ~4 ~-65 ~42 minecraft:deepslate_tiles
fill ~5 ~-65 ~42 ~9 ~-65 ~42 minecraft:air
setblock ~10 ~-65 ~42 minecraft:lightning_rod[facing=up]
fill ~11 ~-65 ~42 ~13 ~-65 ~42 minecraft:air
setblock ~14 ~-65 ~42 minecraft:lightning_rod[facing=up]
fill ~15 ~-65 ~42 ~17 ~-65 ~42 minecraft:air
setblock ~18 ~-65 ~42 minecraft:deepslate_tiles
fill ~19 ~-65 ~42 ~21 ~-65 ~42 minecraft:air
setblock ~22 ~-65 ~42 minecraft:deepslate_tiles
fill ~23 ~-65 ~42 ~25 ~-65 ~42 minecraft:air
setblock ~26 ~-65 ~42 minecraft:waxed_cut_copper
fill ~27 ~-65 ~42 ~41 ~-65 ~42 minecraft:air
setblock ~42 ~-65 ~42 minecraft:waxed_cut_copper
fill ~43 ~-65 ~42 ~45 ~-65 ~42 minecraft:air
setblock ~46 ~-65 ~42 minecraft:deepslate_tiles
fill ~47 ~-65 ~42 ~49 ~-65 ~42 minecraft:air
setblock ~50 ~-65 ~42 minecraft:deepslate_tiles
fill ~51 ~-65 ~42 ~63 ~-65 ~42 minecraft:air
setblock ~64 ~-65 ~42 minecraft:deepslate_tiles
setblock ~4 ~-65 ~43 minecraft:deepslate_tiles
fill ~5 ~-65 ~43 ~17 ~-65 ~43 minecraft:air
setblock ~18 ~-65 ~43 minecraft:deepslate_tiles
fill ~19 ~-65 ~43 ~21 ~-65 ~43 minecraft:air
fill ~22 ~-65 ~43 ~23 ~-65 ~43 minecraft:deepslate_tiles
fill ~24 ~-65 ~43 ~44 ~-65 ~43 minecraft:air
fill ~45 ~-65 ~43 ~46 ~-65 ~43 minecraft:deepslate_tiles
fill ~47 ~-65 ~43 ~49 ~-65 ~43 minecraft:air
setblock ~50 ~-65 ~43 minecraft:deepslate_tiles
setblock ~51 ~-65 ~43 minecraft:air
setblock ~52 ~-65 ~43 minecraft:barrel
fill ~53 ~-65 ~43 ~54 ~-65 ~43 minecraft:air
setblock ~55 ~-65 ~43 minecraft:barrel
fill ~56 ~-65 ~43 ~57 ~-65 ~43 minecraft:air
setblock ~58 ~-65 ~43 minecraft:barrel
fill ~59 ~-65 ~43 ~60 ~-65 ~43 minecraft:air
setblock ~61 ~-65 ~43 minecraft:barrel
fill ~62 ~-65 ~43 ~63 ~-65 ~43 minecraft:air
setblock ~64 ~-65 ~43 minecraft:deepslate_tiles
setblock ~4 ~-65 ~44 minecraft:deepslate_tiles
setblock ~5 ~-65 ~44 minecraft:waxed_cut_copper
fill ~6 ~-65 ~44 ~16 ~-65 ~44 minecraft:air
setblock ~17 ~-65 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~44 minecraft:deepslate_tiles
setblock ~19 ~-65 ~44 minecraft:air
fill ~20 ~-65 ~44 ~22 ~-65 ~44 minecraft:barrel
fill ~23 ~-65 ~44 ~24 ~-65 ~44 minecraft:deepslate_tiles
fill ~25 ~-65 ~44 ~43 ~-65 ~44 minecraft:air
fill ~44 ~-65 ~44 ~45 ~-65 ~44 minecraft:deepslate_tiles
setblock ~46 ~-65 ~44 minecraft:barrel
setblock ~47 ~-65 ~44 minecraft:air
setblock ~48 ~-65 ~44 minecraft:barrel
setblock ~49 ~-65 ~44 minecraft:air
setblock ~50 ~-65 ~44 minecraft:deepslate_tiles
setblock ~51 ~-65 ~44 minecraft:air
setblock ~52 ~-65 ~44 minecraft:barrel
fill ~53 ~-65 ~44 ~54 ~-65 ~44 minecraft:air
setblock ~55 ~-65 ~44 minecraft:barrel
fill ~56 ~-65 ~44 ~57 ~-65 ~44 minecraft:air
setblock ~58 ~-65 ~44 minecraft:barrel
fill ~59 ~-65 ~44 ~60 ~-65 ~44 minecraft:air
setblock ~61 ~-65 ~44 minecraft:barrel
fill ~62 ~-65 ~44 ~63 ~-65 ~44 minecraft:air
setblock ~64 ~-65 ~44 minecraft:deepslate_tiles
setblock ~4 ~-65 ~45 minecraft:deepslate_tiles
fill ~5 ~-65 ~45 ~17 ~-65 ~45 minecraft:air
setblock ~18 ~-65 ~45 minecraft:deepslate_tiles
fill ~19 ~-65 ~45 ~23 ~-65 ~45 minecraft:air
fill ~24 ~-65 ~45 ~25 ~-65 ~45 minecraft:deepslate_tiles
fill ~26 ~-65 ~45 ~42 ~-65 ~45 minecraft:air
fill ~43 ~-65 ~45 ~44 ~-65 ~45 minecraft:deepslate_tiles
fill ~45 ~-65 ~45 ~49 ~-65 ~45 minecraft:air
setblock ~50 ~-65 ~45 minecraft:deepslate_tiles
setblock ~51 ~-65 ~45 minecraft:air
setblock ~52 ~-65 ~45 minecraft:barrel
fill ~53 ~-65 ~45 ~54 ~-65 ~45 minecraft:air
setblock ~55 ~-65 ~45 minecraft:barrel
fill ~56 ~-65 ~45 ~57 ~-65 ~45 minecraft:air
setblock ~58 ~-65 ~45 minecraft:barrel
fill ~59 ~-65 ~45 ~60 ~-65 ~45 minecraft:air
setblock ~61 ~-65 ~45 minecraft:barrel
fill ~62 ~-65 ~45 ~63 ~-65 ~45 minecraft:air
setblock ~64 ~-65 ~45 minecraft:deepslate_tiles
setblock ~4 ~-65 ~46 minecraft:deepslate_tiles
fill ~5 ~-65 ~46 ~9 ~-65 ~46 minecraft:air
setblock ~10 ~-65 ~46 minecraft:lightning_rod[facing=up]
fill ~11 ~-65 ~46 ~13 ~-65 ~46 minecraft:air
setblock ~14 ~-65 ~46 minecraft:lightning_rod[facing=up]
fill ~15 ~-65 ~46 ~17 ~-65 ~46 minecraft:air
setblock ~18 ~-65 ~46 minecraft:deepslate_tiles
fill ~19 ~-65 ~46 ~24 ~-65 ~46 minecraft:air
fill ~25 ~-65 ~46 ~26 ~-65 ~46 minecraft:deepslate_tiles
fill ~27 ~-65 ~46 ~41 ~-65 ~46 minecraft:air
fill ~42 ~-65 ~46 ~43 ~-65 ~46 minecraft:deepslate_tiles
fill ~44 ~-65 ~46 ~49 ~-65 ~46 minecraft:air
setblock ~50 ~-65 ~46 minecraft:deepslate_tiles
setblock ~51 ~-65 ~46 minecraft:air
setblock ~52 ~-65 ~46 minecraft:barrel
fill ~53 ~-65 ~46 ~54 ~-65 ~46 minecraft:air
setblock ~55 ~-65 ~46 minecraft:barrel
fill ~56 ~-65 ~46 ~57 ~-65 ~46 minecraft:air
setblock ~58 ~-65 ~46 minecraft:barrel
fill ~59 ~-65 ~46 ~60 ~-65 ~46 minecraft:air
setblock ~61 ~-65 ~46 minecraft:barrel
fill ~62 ~-65 ~46 ~63 ~-65 ~46 minecraft:air
setblock ~64 ~-65 ~46 minecraft:deepslate_tiles
setblock ~4 ~-65 ~47 minecraft:deepslate_tiles
setblock ~5 ~-65 ~47 minecraft:waxed_cut_copper
fill ~6 ~-65 ~47 ~16 ~-65 ~47 minecraft:air
setblock ~17 ~-65 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~47 minecraft:deepslate_tiles
setblock ~19 ~-65 ~47 minecraft:air
fill ~20 ~-65 ~47 ~23 ~-65 ~47 minecraft:barrel
setblock ~24 ~-65 ~47 minecraft:air
fill ~25 ~-65 ~47 ~26 ~-65 ~47 minecraft:barrel
fill ~27 ~-65 ~47 ~28 ~-65 ~47 minecraft:deepslate_tiles
fill ~29 ~-65 ~47 ~39 ~-65 ~47 minecraft:air
fill ~40 ~-65 ~47 ~41 ~-65 ~47 minecraft:deepslate_tiles
setblock ~42 ~-65 ~47 minecraft:air
fill ~43 ~-65 ~47 ~46 ~-65 ~47 minecraft:barrel
setblock ~47 ~-65 ~47 minecraft:air
setblock ~48 ~-65 ~47 minecraft:barrel
setblock ~49 ~-65 ~47 minecraft:air
setblock ~50 ~-65 ~47 minecraft:deepslate_tiles
fill ~51 ~-65 ~47 ~63 ~-65 ~47 minecraft:air
setblock ~64 ~-65 ~47 minecraft:deepslate_tiles
setblock ~4 ~-65 ~48 minecraft:deepslate_tiles
fill ~5 ~-65 ~48 ~17 ~-65 ~48 minecraft:air
setblock ~18 ~-65 ~48 minecraft:deepslate_tiles
fill ~19 ~-65 ~48 ~28 ~-65 ~48 minecraft:air
fill ~29 ~-65 ~48 ~32 ~-65 ~48 minecraft:deepslate_tiles
fill ~33 ~-65 ~48 ~35 ~-65 ~48 minecraft:air
fill ~36 ~-65 ~48 ~39 ~-65 ~48 minecraft:deepslate_tiles
fill ~40 ~-65 ~48 ~49 ~-65 ~48 minecraft:air
setblock ~50 ~-65 ~48 minecraft:deepslate_tiles
setblock ~51 ~-65 ~48 minecraft:air
setblock ~52 ~-65 ~48 minecraft:barrel
fill ~53 ~-65 ~48 ~54 ~-65 ~48 minecraft:air
setblock ~55 ~-65 ~48 minecraft:barrel
fill ~56 ~-65 ~48 ~57 ~-65 ~48 minecraft:air
setblock ~58 ~-65 ~48 minecraft:barrel
fill ~59 ~-65 ~48 ~60 ~-65 ~48 minecraft:air
setblock ~61 ~-65 ~48 minecraft:barrel
fill ~62 ~-65 ~48 ~63 ~-65 ~48 minecraft:air
setblock ~64 ~-65 ~48 minecraft:deepslate_tiles
setblock ~4 ~-65 ~49 minecraft:deepslate_tiles
setblock ~5 ~-65 ~49 minecraft:air
setblock ~6 ~-65 ~49 minecraft:waxed_cut_copper
fill ~7 ~-65 ~49 ~8 ~-65 ~49 minecraft:air
setblock ~9 ~-65 ~49 minecraft:waxed_cut_copper
fill ~10 ~-65 ~49 ~14 ~-65 ~49 minecraft:air
setblock ~15 ~-65 ~49 minecraft:waxed_cut_copper
fill ~16 ~-65 ~49 ~17 ~-65 ~49 minecraft:air
setblock ~18 ~-65 ~49 minecraft:deepslate_tiles
fill ~19 ~-65 ~49 ~31 ~-65 ~49 minecraft:air
setblock ~32 ~-65 ~49 minecraft:deepslate_tiles
fill ~33 ~-65 ~49 ~35 ~-65 ~49 minecraft:air
setblock ~36 ~-65 ~49 minecraft:deepslate_tiles
fill ~37 ~-65 ~49 ~49 ~-65 ~49 minecraft:air
setblock ~50 ~-65 ~49 minecraft:deepslate_tiles
fill ~51 ~-65 ~49 ~63 ~-65 ~49 minecraft:air
setblock ~64 ~-65 ~49 minecraft:deepslate_tiles
fill ~4 ~-65 ~50 ~32 ~-65 ~50 minecraft:deepslate_tiles
fill ~33 ~-65 ~50 ~35 ~-65 ~50 minecraft:air
fill ~36 ~-65 ~50 ~64 ~-65 ~50 minecraft:deepslate_tiles
setblock ~4 ~-65 ~51 minecraft:deepslate_tiles
fill ~5 ~-65 ~51 ~9 ~-65 ~51 minecraft:waxed_cut_copper
fill ~10 ~-65 ~51 ~12 ~-65 ~51 minecraft:air
fill ~13 ~-65 ~51 ~17 ~-65 ~51 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~51 minecraft:deepslate_tiles
fill ~19 ~-65 ~51 ~31 ~-65 ~51 minecraft:air
setblock ~32 ~-65 ~51 minecraft:deepslate_tiles
fill ~33 ~-65 ~51 ~35 ~-65 ~51 minecraft:air
setblock ~36 ~-65 ~51 minecraft:deepslate_tiles
fill ~37 ~-65 ~51 ~49 ~-65 ~51 minecraft:air
setblock ~50 ~-65 ~51 minecraft:deepslate_tiles
setblock ~51 ~-65 ~51 minecraft:waxed_cut_copper
fill ~52 ~-65 ~51 ~53 ~-65 ~51 minecraft:air
setblock ~54 ~-65 ~51 minecraft:waxed_cut_copper
fill ~55 ~-65 ~51 ~59 ~-65 ~51 minecraft:air
setblock ~60 ~-65 ~51 minecraft:waxed_cut_copper
fill ~61 ~-65 ~51 ~62 ~-65 ~51 minecraft:air
setblock ~63 ~-65 ~51 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~51 minecraft:deepslate_tiles
setblock ~4 ~-65 ~52 minecraft:deepslate_tiles
setblock ~5 ~-65 ~52 minecraft:waxed_cut_copper
fill ~6 ~-65 ~52 ~16 ~-65 ~52 minecraft:air
setblock ~17 ~-65 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~52 minecraft:deepslate_tiles
setblock ~19 ~-65 ~52 minecraft:air
fill ~20 ~-65 ~52 ~23 ~-65 ~52 minecraft:barrel
setblock ~24 ~-65 ~52 minecraft:air
fill ~25 ~-65 ~52 ~28 ~-65 ~52 minecraft:barrel
setblock ~29 ~-65 ~52 minecraft:air
setblock ~30 ~-65 ~52 minecraft:barrel
setblock ~31 ~-65 ~52 minecraft:air
setblock ~32 ~-65 ~52 minecraft:deepslate_tiles
fill ~33 ~-65 ~52 ~35 ~-65 ~52 minecraft:air
setblock ~36 ~-65 ~52 minecraft:deepslate_tiles
fill ~37 ~-65 ~52 ~49 ~-65 ~52 minecraft:air
setblock ~50 ~-65 ~52 minecraft:deepslate_tiles
fill ~51 ~-65 ~52 ~63 ~-65 ~52 minecraft:air
setblock ~64 ~-65 ~52 minecraft:deepslate_tiles
setblock ~4 ~-65 ~53 minecraft:deepslate_tiles
setblock ~5 ~-65 ~53 minecraft:waxed_cut_copper
fill ~6 ~-65 ~53 ~16 ~-65 ~53 minecraft:air
setblock ~17 ~-65 ~53 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~53 minecraft:deepslate_tiles
fill ~19 ~-65 ~53 ~31 ~-65 ~53 minecraft:air
setblock ~32 ~-65 ~53 minecraft:deepslate_tiles
fill ~33 ~-65 ~53 ~35 ~-65 ~53 minecraft:air
setblock ~36 ~-65 ~53 minecraft:deepslate_tiles
fill ~37 ~-65 ~53 ~49 ~-65 ~53 minecraft:air
setblock ~50 ~-65 ~53 minecraft:deepslate_tiles
fill ~51 ~-65 ~53 ~63 ~-65 ~53 minecraft:air
setblock ~64 ~-65 ~53 minecraft:deepslate_tiles
setblock ~4 ~-65 ~54 minecraft:deepslate_tiles
setblock ~5 ~-65 ~54 minecraft:waxed_cut_copper
fill ~6 ~-65 ~54 ~16 ~-65 ~54 minecraft:air
setblock ~17 ~-65 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~54 minecraft:deepslate_tiles
fill ~19 ~-65 ~54 ~31 ~-65 ~54 minecraft:air
setblock ~32 ~-65 ~54 minecraft:deepslate_tiles
fill ~33 ~-65 ~54 ~35 ~-65 ~54 minecraft:air
setblock ~36 ~-65 ~54 minecraft:deepslate_tiles
fill ~37 ~-65 ~54 ~49 ~-65 ~54 minecraft:air
setblock ~50 ~-65 ~54 minecraft:deepslate_tiles
setblock ~51 ~-65 ~54 minecraft:waxed_cut_copper
fill ~52 ~-65 ~54 ~62 ~-65 ~54 minecraft:air
setblock ~63 ~-65 ~54 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~54 minecraft:deepslate_tiles
setblock ~4 ~-65 ~55 minecraft:deepslate_tiles
setblock ~5 ~-65 ~55 minecraft:waxed_cut_copper
fill ~6 ~-65 ~55 ~16 ~-65 ~55 minecraft:air
setblock ~17 ~-65 ~55 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~55 minecraft:deepslate_tiles
setblock ~19 ~-65 ~55 minecraft:air
fill ~20 ~-65 ~55 ~23 ~-65 ~55 minecraft:barrel
setblock ~24 ~-65 ~55 minecraft:air
fill ~25 ~-65 ~55 ~28 ~-65 ~55 minecraft:barrel
setblock ~29 ~-65 ~55 minecraft:air
setblock ~30 ~-65 ~55 minecraft:barrel
setblock ~31 ~-65 ~55 minecraft:air
setblock ~32 ~-65 ~55 minecraft:deepslate_tiles
fill ~33 ~-65 ~55 ~35 ~-65 ~55 minecraft:air
setblock ~36 ~-65 ~55 minecraft:deepslate_tiles
fill ~37 ~-65 ~55 ~49 ~-65 ~55 minecraft:air
setblock ~50 ~-65 ~55 minecraft:deepslate_tiles
fill ~51 ~-65 ~55 ~63 ~-65 ~55 minecraft:air
setblock ~64 ~-65 ~55 minecraft:deepslate_tiles
setblock ~4 ~-65 ~56 minecraft:deepslate_tiles
setblock ~5 ~-65 ~56 minecraft:waxed_cut_copper
fill ~6 ~-65 ~56 ~17 ~-65 ~56 minecraft:air
setblock ~18 ~-65 ~56 minecraft:deepslate_tiles
fill ~19 ~-65 ~56 ~31 ~-65 ~56 minecraft:air
setblock ~32 ~-65 ~56 minecraft:deepslate_tiles
fill ~33 ~-65 ~56 ~35 ~-65 ~56 minecraft:air
setblock ~36 ~-65 ~56 minecraft:deepslate_tiles
fill ~37 ~-65 ~56 ~49 ~-65 ~56 minecraft:air
setblock ~50 ~-65 ~56 minecraft:deepslate_tiles
fill ~51 ~-65 ~56 ~63 ~-65 ~56 minecraft:air
setblock ~64 ~-65 ~56 minecraft:deepslate_tiles
setblock ~4 ~-65 ~57 minecraft:deepslate_tiles
setblock ~5 ~-65 ~57 minecraft:waxed_cut_copper
fill ~6 ~-65 ~57 ~11 ~-65 ~57 minecraft:air
setblock ~12 ~-65 ~57 minecraft:waxed_cut_copper
fill ~13 ~-65 ~57 ~17 ~-65 ~57 minecraft:air
setblock ~18 ~-65 ~57 minecraft:deepslate_tiles
fill ~19 ~-65 ~57 ~31 ~-65 ~57 minecraft:air
setblock ~32 ~-65 ~57 minecraft:deepslate_tiles
fill ~33 ~-65 ~57 ~35 ~-65 ~57 minecraft:air
setblock ~36 ~-65 ~57 minecraft:deepslate_tiles
fill ~37 ~-65 ~57 ~49 ~-65 ~57 minecraft:air
setblock ~50 ~-65 ~57 minecraft:deepslate_tiles
fill ~51 ~-65 ~57 ~62 ~-65 ~57 minecraft:air
setblock ~63 ~-65 ~57 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~57 minecraft:deepslate_tiles
setblock ~4 ~-65 ~58 minecraft:deepslate_tiles
setblock ~5 ~-65 ~58 minecraft:waxed_cut_copper
fill ~6 ~-65 ~58 ~17 ~-65 ~58 minecraft:air
setblock ~18 ~-65 ~58 minecraft:deepslate_tiles
setblock ~19 ~-65 ~58 minecraft:air
fill ~20 ~-65 ~58 ~23 ~-65 ~58 minecraft:barrel
setblock ~24 ~-65 ~58 minecraft:air
fill ~25 ~-65 ~58 ~28 ~-65 ~58 minecraft:barrel
setblock ~29 ~-65 ~58 minecraft:air
setblock ~30 ~-65 ~58 minecraft:barrel
setblock ~31 ~-65 ~58 minecraft:air
setblock ~32 ~-65 ~58 minecraft:deepslate_tiles
fill ~33 ~-65 ~58 ~35 ~-65 ~58 minecraft:air
setblock ~36 ~-65 ~58 minecraft:deepslate_tiles
fill ~37 ~-65 ~58 ~49 ~-65 ~58 minecraft:air
setblock ~50 ~-65 ~58 minecraft:deepslate_tiles
fill ~51 ~-65 ~58 ~63 ~-65 ~58 minecraft:air
setblock ~64 ~-65 ~58 minecraft:deepslate_tiles
setblock ~4 ~-65 ~59 minecraft:deepslate_tiles
setblock ~5 ~-65 ~59 minecraft:waxed_cut_copper
fill ~6 ~-65 ~59 ~16 ~-65 ~59 minecraft:air
setblock ~17 ~-65 ~59 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~59 minecraft:deepslate_tiles
fill ~19 ~-65 ~59 ~31 ~-65 ~59 minecraft:air
setblock ~32 ~-65 ~59 minecraft:deepslate_tiles
fill ~33 ~-65 ~59 ~35 ~-65 ~59 minecraft:air
setblock ~36 ~-65 ~59 minecraft:deepslate_tiles
fill ~37 ~-65 ~59 ~49 ~-65 ~59 minecraft:air
setblock ~50 ~-65 ~59 minecraft:deepslate_tiles
fill ~51 ~-65 ~59 ~63 ~-65 ~59 minecraft:air
setblock ~64 ~-65 ~59 minecraft:deepslate_tiles
setblock ~4 ~-65 ~60 minecraft:deepslate_tiles
setblock ~5 ~-65 ~60 minecraft:waxed_cut_copper
fill ~6 ~-65 ~60 ~16 ~-65 ~60 minecraft:air
setblock ~17 ~-65 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~60 minecraft:deepslate_tiles
fill ~19 ~-65 ~60 ~31 ~-65 ~60 minecraft:air
setblock ~32 ~-65 ~60 minecraft:deepslate_tiles
fill ~33 ~-65 ~60 ~35 ~-65 ~60 minecraft:air
setblock ~36 ~-65 ~60 minecraft:deepslate_tiles
fill ~37 ~-65 ~60 ~49 ~-65 ~60 minecraft:air
setblock ~50 ~-65 ~60 minecraft:deepslate_tiles
setblock ~51 ~-65 ~60 minecraft:waxed_cut_copper
fill ~52 ~-65 ~60 ~62 ~-65 ~60 minecraft:air
setblock ~63 ~-65 ~60 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~60 minecraft:deepslate_tiles
setblock ~4 ~-65 ~61 minecraft:deepslate_tiles
setblock ~5 ~-65 ~61 minecraft:waxed_cut_copper
fill ~6 ~-65 ~61 ~16 ~-65 ~61 minecraft:air
setblock ~17 ~-65 ~61 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~61 minecraft:deepslate_tiles
setblock ~19 ~-65 ~61 minecraft:air
fill ~20 ~-65 ~61 ~23 ~-65 ~61 minecraft:barrel
setblock ~24 ~-65 ~61 minecraft:air
fill ~25 ~-65 ~61 ~28 ~-65 ~61 minecraft:barrel
setblock ~29 ~-65 ~61 minecraft:air
setblock ~30 ~-65 ~61 minecraft:barrel
setblock ~31 ~-65 ~61 minecraft:air
setblock ~32 ~-65 ~61 minecraft:deepslate_tiles
fill ~33 ~-65 ~61 ~35 ~-65 ~61 minecraft:air
setblock ~36 ~-65 ~61 minecraft:deepslate_tiles
fill ~37 ~-65 ~61 ~49 ~-65 ~61 minecraft:air
setblock ~50 ~-65 ~61 minecraft:deepslate_tiles
fill ~51 ~-65 ~61 ~63 ~-65 ~61 minecraft:air
setblock ~64 ~-65 ~61 minecraft:deepslate_tiles
setblock ~4 ~-65 ~62 minecraft:deepslate_tiles
setblock ~5 ~-65 ~62 minecraft:waxed_cut_copper
fill ~6 ~-65 ~62 ~16 ~-65 ~62 minecraft:air
setblock ~17 ~-65 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~62 minecraft:deepslate_tiles
fill ~19 ~-65 ~62 ~31 ~-65 ~62 minecraft:air
setblock ~32 ~-65 ~62 minecraft:deepslate_tiles
fill ~33 ~-65 ~62 ~35 ~-65 ~62 minecraft:air
setblock ~36 ~-65 ~62 minecraft:deepslate_tiles
fill ~37 ~-65 ~62 ~49 ~-65 ~62 minecraft:air
setblock ~50 ~-65 ~62 minecraft:deepslate_tiles
fill ~51 ~-65 ~62 ~63 ~-65 ~62 minecraft:air
setblock ~64 ~-65 ~62 minecraft:deepslate_tiles
setblock ~4 ~-65 ~63 minecraft:deepslate_tiles
fill ~5 ~-65 ~63 ~17 ~-65 ~63 minecraft:waxed_cut_copper
setblock ~18 ~-65 ~63 minecraft:deepslate_tiles
fill ~19 ~-65 ~63 ~31 ~-65 ~63 minecraft:air
setblock ~32 ~-65 ~63 minecraft:deepslate_tiles
fill ~33 ~-65 ~63 ~35 ~-65 ~63 minecraft:air
setblock ~36 ~-65 ~63 minecraft:deepslate_tiles
fill ~37 ~-65 ~63 ~49 ~-65 ~63 minecraft:air
setblock ~50 ~-65 ~63 minecraft:deepslate_tiles
setblock ~51 ~-65 ~63 minecraft:waxed_cut_copper
fill ~52 ~-65 ~63 ~53 ~-65 ~63 minecraft:air
setblock ~54 ~-65 ~63 minecraft:waxed_cut_copper
fill ~55 ~-65 ~63 ~56 ~-65 ~63 minecraft:air
setblock ~57 ~-65 ~63 minecraft:waxed_cut_copper
fill ~58 ~-65 ~63 ~59 ~-65 ~63 minecraft:air
setblock ~60 ~-65 ~63 minecraft:waxed_cut_copper
fill ~61 ~-65 ~63 ~62 ~-65 ~63 minecraft:air
setblock ~63 ~-65 ~63 minecraft:waxed_cut_copper
setblock ~64 ~-65 ~63 minecraft:deepslate_tiles
fill ~4 ~-65 ~64 ~64 ~-65 ~64 minecraft:deepslate_tiles
setblock ~34 ~-65 ~65 minecraft:deepslate_tiles
fill ~32 ~-65 ~66 ~36 ~-65 ~66 minecraft:polished_andesite
setblock ~32 ~-65 ~67 minecraft:polished_andesite
fill ~33 ~-65 ~67 ~35 ~-65 ~67 minecraft:air
setblock ~36 ~-65 ~67 minecraft:polished_andesite
setblock ~32 ~-65 ~68 minecraft:polished_andesite
setblock ~33 ~-65 ~68 minecraft:air
setblock ~34 ~-65 ~68 minecraft:quartz_pillar
setblock ~35 ~-65 ~68 minecraft:air
setblock ~36 ~-65 ~68 minecraft:polished_andesite
setblock ~32 ~-65 ~69 minecraft:polished_andesite
fill ~33 ~-65 ~69 ~34 ~-65 ~69 minecraft:air
setblock ~35 ~-65 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-65 ~69 minecraft:polished_andesite
fill ~32 ~-65 ~70 ~36 ~-65 ~70 minecraft:polished_andesite
fill ~4 ~-64 ~4 ~64 ~-64 ~4 minecraft:deepslate_tiles
setblock ~4 ~-64 ~5 minecraft:deepslate_tiles
fill ~5 ~-64 ~5 ~17 ~-64 ~5 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~5 minecraft:deepslate_tiles
fill ~19 ~-64 ~5 ~31 ~-64 ~5 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~5 minecraft:deepslate_tiles
fill ~33 ~-64 ~5 ~35 ~-64 ~5 minecraft:air
setblock ~36 ~-64 ~5 minecraft:deepslate_tiles
setblock ~37 ~-64 ~5 minecraft:waxed_cut_copper
fill ~38 ~-64 ~5 ~39 ~-64 ~5 minecraft:air
setblock ~40 ~-64 ~5 minecraft:waxed_cut_copper
fill ~41 ~-64 ~5 ~42 ~-64 ~5 minecraft:air
setblock ~43 ~-64 ~5 minecraft:waxed_cut_copper
fill ~44 ~-64 ~5 ~45 ~-64 ~5 minecraft:air
setblock ~46 ~-64 ~5 minecraft:waxed_cut_copper
fill ~47 ~-64 ~5 ~48 ~-64 ~5 minecraft:air
setblock ~49 ~-64 ~5 minecraft:waxed_cut_copper
setblock ~50 ~-64 ~5 minecraft:deepslate_tiles
setblock ~51 ~-64 ~5 minecraft:air
setblock ~52 ~-64 ~5 minecraft:waxed_cut_copper
fill ~53 ~-64 ~5 ~54 ~-64 ~5 minecraft:air
setblock ~55 ~-64 ~5 minecraft:waxed_cut_copper
fill ~56 ~-64 ~5 ~57 ~-64 ~5 minecraft:air
setblock ~58 ~-64 ~5 minecraft:waxed_cut_copper
fill ~59 ~-64 ~5 ~60 ~-64 ~5 minecraft:air
setblock ~61 ~-64 ~5 minecraft:waxed_cut_copper
fill ~62 ~-64 ~5 ~63 ~-64 ~5 minecraft:air
setblock ~64 ~-64 ~5 minecraft:deepslate_tiles
setblock ~4 ~-64 ~6 minecraft:deepslate_tiles
setblock ~5 ~-64 ~6 minecraft:waxed_cut_copper
fill ~6 ~-64 ~6 ~16 ~-64 ~6 minecraft:air
setblock ~17 ~-64 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~6 minecraft:deepslate_tiles
setblock ~19 ~-64 ~6 minecraft:waxed_cut_copper
fill ~20 ~-64 ~6 ~30 ~-64 ~6 minecraft:air
setblock ~31 ~-64 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~6 minecraft:deepslate_tiles
fill ~33 ~-64 ~6 ~35 ~-64 ~6 minecraft:air
setblock ~36 ~-64 ~6 minecraft:deepslate_tiles
fill ~37 ~-64 ~6 ~49 ~-64 ~6 minecraft:air
setblock ~50 ~-64 ~6 minecraft:deepslate_tiles
setblock ~51 ~-64 ~6 minecraft:waxed_cut_copper
fill ~52 ~-64 ~6 ~62 ~-64 ~6 minecraft:air
setblock ~63 ~-64 ~6 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~6 minecraft:deepslate_tiles
setblock ~4 ~-64 ~7 minecraft:deepslate_tiles
setblock ~5 ~-64 ~7 minecraft:waxed_cut_copper
fill ~6 ~-64 ~7 ~16 ~-64 ~7 minecraft:air
setblock ~17 ~-64 ~7 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~7 minecraft:deepslate_tiles
setblock ~19 ~-64 ~7 minecraft:waxed_cut_copper
fill ~20 ~-64 ~7 ~30 ~-64 ~7 minecraft:air
setblock ~31 ~-64 ~7 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~7 minecraft:deepslate_tiles
fill ~33 ~-64 ~7 ~35 ~-64 ~7 minecraft:air
setblock ~36 ~-64 ~7 minecraft:deepslate_tiles
fill ~37 ~-64 ~7 ~49 ~-64 ~7 minecraft:air
setblock ~50 ~-64 ~7 minecraft:deepslate_tiles
fill ~51 ~-64 ~7 ~63 ~-64 ~7 minecraft:air
setblock ~64 ~-64 ~7 minecraft:deepslate_tiles
setblock ~4 ~-64 ~8 minecraft:deepslate_tiles
setblock ~5 ~-64 ~8 minecraft:waxed_cut_copper
fill ~6 ~-64 ~8 ~16 ~-64 ~8 minecraft:air
setblock ~17 ~-64 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~8 minecraft:deepslate_tiles
setblock ~19 ~-64 ~8 minecraft:waxed_cut_copper
fill ~20 ~-64 ~8 ~30 ~-64 ~8 minecraft:air
setblock ~31 ~-64 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~8 minecraft:deepslate_tiles
fill ~33 ~-64 ~8 ~35 ~-64 ~8 minecraft:air
setblock ~36 ~-64 ~8 minecraft:deepslate_tiles
setblock ~37 ~-64 ~8 minecraft:waxed_cut_copper
fill ~38 ~-64 ~8 ~48 ~-64 ~8 minecraft:air
setblock ~49 ~-64 ~8 minecraft:waxed_cut_copper
setblock ~50 ~-64 ~8 minecraft:deepslate_tiles
fill ~51 ~-64 ~8 ~63 ~-64 ~8 minecraft:air
setblock ~64 ~-64 ~8 minecraft:deepslate_tiles
setblock ~4 ~-64 ~9 minecraft:deepslate_tiles
setblock ~5 ~-64 ~9 minecraft:waxed_cut_copper
fill ~6 ~-64 ~9 ~16 ~-64 ~9 minecraft:air
setblock ~17 ~-64 ~9 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~9 minecraft:deepslate_tiles
setblock ~19 ~-64 ~9 minecraft:waxed_cut_copper
fill ~20 ~-64 ~9 ~30 ~-64 ~9 minecraft:air
setblock ~31 ~-64 ~9 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~9 minecraft:deepslate_tiles
fill ~33 ~-64 ~9 ~35 ~-64 ~9 minecraft:air
setblock ~36 ~-64 ~9 minecraft:deepslate_tiles
fill ~37 ~-64 ~9 ~49 ~-64 ~9 minecraft:air
setblock ~50 ~-64 ~9 minecraft:deepslate_tiles
setblock ~51 ~-64 ~9 minecraft:waxed_cut_copper
fill ~52 ~-64 ~9 ~62 ~-64 ~9 minecraft:air
setblock ~63 ~-64 ~9 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~9 minecraft:deepslate_tiles
setblock ~4 ~-64 ~10 minecraft:deepslate_tiles
setblock ~5 ~-64 ~10 minecraft:waxed_cut_copper
fill ~6 ~-64 ~10 ~17 ~-64 ~10 minecraft:air
setblock ~18 ~-64 ~10 minecraft:deepslate_tiles
fill ~19 ~-64 ~10 ~31 ~-64 ~10 minecraft:air
setblock ~32 ~-64 ~10 minecraft:deepslate_tiles
fill ~33 ~-64 ~10 ~35 ~-64 ~10 minecraft:air
setblock ~36 ~-64 ~10 minecraft:deepslate_tiles
fill ~37 ~-64 ~10 ~49 ~-64 ~10 minecraft:air
setblock ~50 ~-64 ~10 minecraft:deepslate_tiles
fill ~51 ~-64 ~10 ~63 ~-64 ~10 minecraft:air
setblock ~64 ~-64 ~10 minecraft:deepslate_tiles
setblock ~4 ~-64 ~11 minecraft:deepslate_tiles
setblock ~5 ~-64 ~11 minecraft:waxed_cut_copper
fill ~6 ~-64 ~11 ~17 ~-64 ~11 minecraft:air
setblock ~18 ~-64 ~11 minecraft:deepslate_tiles
fill ~19 ~-64 ~11 ~31 ~-64 ~11 minecraft:air
setblock ~32 ~-64 ~11 minecraft:deepslate_tiles
fill ~33 ~-64 ~11 ~35 ~-64 ~11 minecraft:air
setblock ~36 ~-64 ~11 minecraft:deepslate_tiles
fill ~37 ~-64 ~11 ~49 ~-64 ~11 minecraft:air
setblock ~50 ~-64 ~11 minecraft:deepslate_tiles
fill ~51 ~-64 ~11 ~63 ~-64 ~11 minecraft:air
setblock ~64 ~-64 ~11 minecraft:deepslate_tiles
setblock ~4 ~-64 ~12 minecraft:deepslate_tiles
setblock ~5 ~-64 ~12 minecraft:waxed_cut_copper
fill ~6 ~-64 ~12 ~11 ~-64 ~12 minecraft:air
setblock ~12 ~-64 ~12 minecraft:redstone_lamp[lit=true]
fill ~13 ~-64 ~12 ~17 ~-64 ~12 minecraft:air
setblock ~18 ~-64 ~12 minecraft:deepslate_tiles
fill ~19 ~-64 ~12 ~21 ~-64 ~12 minecraft:air
setblock ~22 ~-64 ~12 minecraft:redstone_lamp[lit=true]
fill ~23 ~-64 ~12 ~26 ~-64 ~12 minecraft:air
setblock ~27 ~-64 ~12 minecraft:redstone_lamp[lit=true]
fill ~28 ~-64 ~12 ~31 ~-64 ~12 minecraft:air
setblock ~32 ~-64 ~12 minecraft:deepslate_tiles
fill ~33 ~-64 ~12 ~35 ~-64 ~12 minecraft:air
setblock ~36 ~-64 ~12 minecraft:deepslate_tiles
fill ~37 ~-64 ~12 ~49 ~-64 ~12 minecraft:air
setblock ~50 ~-64 ~12 minecraft:deepslate_tiles
fill ~51 ~-64 ~12 ~62 ~-64 ~12 minecraft:air
setblock ~63 ~-64 ~12 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~12 minecraft:deepslate_tiles
setblock ~4 ~-64 ~13 minecraft:deepslate_tiles
setblock ~5 ~-64 ~13 minecraft:waxed_cut_copper
fill ~6 ~-64 ~13 ~16 ~-64 ~13 minecraft:air
setblock ~17 ~-64 ~13 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~13 minecraft:deepslate_tiles
setblock ~19 ~-64 ~13 minecraft:waxed_cut_copper
fill ~20 ~-64 ~13 ~30 ~-64 ~13 minecraft:air
setblock ~31 ~-64 ~13 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~13 minecraft:deepslate_tiles
fill ~33 ~-64 ~13 ~35 ~-64 ~13 minecraft:air
setblock ~36 ~-64 ~13 minecraft:deepslate_tiles
fill ~37 ~-64 ~13 ~49 ~-64 ~13 minecraft:air
setblock ~50 ~-64 ~13 minecraft:deepslate_tiles
fill ~51 ~-64 ~13 ~63 ~-64 ~13 minecraft:air
setblock ~64 ~-64 ~13 minecraft:deepslate_tiles
setblock ~4 ~-64 ~14 minecraft:deepslate_tiles
setblock ~5 ~-64 ~14 minecraft:waxed_cut_copper
fill ~6 ~-64 ~14 ~16 ~-64 ~14 minecraft:air
setblock ~17 ~-64 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~14 minecraft:deepslate_tiles
setblock ~19 ~-64 ~14 minecraft:waxed_cut_copper
fill ~20 ~-64 ~14 ~30 ~-64 ~14 minecraft:air
setblock ~31 ~-64 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~14 minecraft:deepslate_tiles
fill ~33 ~-64 ~14 ~35 ~-64 ~14 minecraft:air
setblock ~36 ~-64 ~14 minecraft:deepslate_tiles
setblock ~37 ~-64 ~14 minecraft:waxed_cut_copper
fill ~38 ~-64 ~14 ~48 ~-64 ~14 minecraft:air
setblock ~49 ~-64 ~14 minecraft:waxed_cut_copper
setblock ~50 ~-64 ~14 minecraft:deepslate_tiles
fill ~51 ~-64 ~14 ~63 ~-64 ~14 minecraft:air
setblock ~64 ~-64 ~14 minecraft:deepslate_tiles
setblock ~4 ~-64 ~15 minecraft:deepslate_tiles
setblock ~5 ~-64 ~15 minecraft:waxed_cut_copper
fill ~6 ~-64 ~15 ~16 ~-64 ~15 minecraft:air
setblock ~17 ~-64 ~15 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~15 minecraft:deepslate_tiles
setblock ~19 ~-64 ~15 minecraft:waxed_cut_copper
fill ~20 ~-64 ~15 ~30 ~-64 ~15 minecraft:air
setblock ~31 ~-64 ~15 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~15 minecraft:deepslate_tiles
fill ~33 ~-64 ~15 ~35 ~-64 ~15 minecraft:air
setblock ~36 ~-64 ~15 minecraft:deepslate_tiles
fill ~37 ~-64 ~15 ~49 ~-64 ~15 minecraft:air
setblock ~50 ~-64 ~15 minecraft:deepslate_tiles
setblock ~51 ~-64 ~15 minecraft:waxed_cut_copper
fill ~52 ~-64 ~15 ~62 ~-64 ~15 minecraft:air
setblock ~63 ~-64 ~15 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~15 minecraft:deepslate_tiles
setblock ~4 ~-64 ~16 minecraft:deepslate_tiles
setblock ~5 ~-64 ~16 minecraft:waxed_cut_copper
fill ~6 ~-64 ~16 ~16 ~-64 ~16 minecraft:air
setblock ~17 ~-64 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~16 minecraft:deepslate_tiles
setblock ~19 ~-64 ~16 minecraft:waxed_cut_copper
fill ~20 ~-64 ~16 ~30 ~-64 ~16 minecraft:air
setblock ~31 ~-64 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~16 minecraft:deepslate_tiles
fill ~33 ~-64 ~16 ~35 ~-64 ~16 minecraft:air
setblock ~36 ~-64 ~16 minecraft:deepslate_tiles
fill ~37 ~-64 ~16 ~49 ~-64 ~16 minecraft:air
setblock ~50 ~-64 ~16 minecraft:deepslate_tiles
fill ~51 ~-64 ~16 ~63 ~-64 ~16 minecraft:air
setblock ~64 ~-64 ~16 minecraft:deepslate_tiles
setblock ~4 ~-64 ~17 minecraft:deepslate_tiles
fill ~5 ~-64 ~17 ~9 ~-64 ~17 minecraft:waxed_cut_copper
fill ~10 ~-64 ~17 ~12 ~-64 ~17 minecraft:air
fill ~13 ~-64 ~17 ~17 ~-64 ~17 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~17 minecraft:deepslate_tiles
fill ~19 ~-64 ~17 ~31 ~-64 ~17 minecraft:waxed_cut_copper
setblock ~32 ~-64 ~17 minecraft:deepslate_tiles
fill ~33 ~-64 ~17 ~35 ~-64 ~17 minecraft:air
setblock ~36 ~-64 ~17 minecraft:deepslate_tiles
setblock ~37 ~-64 ~17 minecraft:waxed_cut_copper
fill ~38 ~-64 ~17 ~39 ~-64 ~17 minecraft:air
setblock ~40 ~-64 ~17 minecraft:waxed_cut_copper
fill ~41 ~-64 ~17 ~42 ~-64 ~17 minecraft:air
setblock ~43 ~-64 ~17 minecraft:waxed_cut_copper
fill ~44 ~-64 ~17 ~45 ~-64 ~17 minecraft:air
setblock ~46 ~-64 ~17 minecraft:waxed_cut_copper
fill ~47 ~-64 ~17 ~48 ~-64 ~17 minecraft:air
setblock ~49 ~-64 ~17 minecraft:waxed_cut_copper
setblock ~50 ~-64 ~17 minecraft:deepslate_tiles
setblock ~51 ~-64 ~17 minecraft:air
setblock ~52 ~-64 ~17 minecraft:waxed_cut_copper
fill ~53 ~-64 ~17 ~54 ~-64 ~17 minecraft:air
setblock ~55 ~-64 ~17 minecraft:waxed_cut_copper
fill ~56 ~-64 ~17 ~60 ~-64 ~17 minecraft:air
setblock ~61 ~-64 ~17 minecraft:waxed_cut_copper
fill ~62 ~-64 ~17 ~63 ~-64 ~17 minecraft:air
setblock ~64 ~-64 ~17 minecraft:deepslate_tiles
fill ~4 ~-64 ~18 ~32 ~-64 ~18 minecraft:deepslate_tiles
fill ~33 ~-64 ~18 ~35 ~-64 ~18 minecraft:air
fill ~36 ~-64 ~18 ~64 ~-64 ~18 minecraft:deepslate_tiles
setblock ~4 ~-64 ~19 minecraft:deepslate_tiles
setblock ~5 ~-64 ~19 minecraft:air
setblock ~6 ~-64 ~19 minecraft:waxed_cut_copper
fill ~7 ~-64 ~19 ~8 ~-64 ~19 minecraft:air
setblock ~9 ~-64 ~19 minecraft:waxed_cut_copper
fill ~10 ~-64 ~19 ~14 ~-64 ~19 minecraft:air
setblock ~15 ~-64 ~19 minecraft:waxed_cut_copper
fill ~16 ~-64 ~19 ~17 ~-64 ~19 minecraft:air
setblock ~18 ~-64 ~19 minecraft:deepslate_tiles
fill ~19 ~-64 ~19 ~31 ~-64 ~19 minecraft:air
setblock ~32 ~-64 ~19 minecraft:deepslate_tiles
fill ~33 ~-64 ~19 ~35 ~-64 ~19 minecraft:air
setblock ~36 ~-64 ~19 minecraft:deepslate_tiles
fill ~37 ~-64 ~19 ~49 ~-64 ~19 minecraft:air
setblock ~50 ~-64 ~19 minecraft:deepslate_tiles
fill ~51 ~-64 ~19 ~63 ~-64 ~19 minecraft:air
setblock ~64 ~-64 ~19 minecraft:deepslate_tiles
setblock ~4 ~-64 ~20 minecraft:deepslate_tiles
setblock ~5 ~-64 ~20 minecraft:waxed_cut_copper
fill ~6 ~-64 ~20 ~16 ~-64 ~20 minecraft:air
setblock ~17 ~-64 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~20 minecraft:deepslate_tiles
fill ~19 ~-64 ~20 ~28 ~-64 ~20 minecraft:air
fill ~29 ~-64 ~20 ~32 ~-64 ~20 minecraft:deepslate_tiles
fill ~33 ~-64 ~20 ~35 ~-64 ~20 minecraft:air
fill ~36 ~-64 ~20 ~39 ~-64 ~20 minecraft:deepslate_tiles
fill ~40 ~-64 ~20 ~49 ~-64 ~20 minecraft:air
setblock ~50 ~-64 ~20 minecraft:deepslate_tiles
fill ~51 ~-64 ~20 ~63 ~-64 ~20 minecraft:air
setblock ~64 ~-64 ~20 minecraft:deepslate_tiles
setblock ~4 ~-64 ~21 minecraft:deepslate_tiles
fill ~5 ~-64 ~21 ~17 ~-64 ~21 minecraft:air
setblock ~18 ~-64 ~21 minecraft:deepslate_tiles
fill ~19 ~-64 ~21 ~26 ~-64 ~21 minecraft:air
fill ~27 ~-64 ~21 ~28 ~-64 ~21 minecraft:deepslate_tiles
fill ~29 ~-64 ~21 ~39 ~-64 ~21 minecraft:air
fill ~40 ~-64 ~21 ~41 ~-64 ~21 minecraft:deepslate_tiles
fill ~42 ~-64 ~21 ~49 ~-64 ~21 minecraft:air
setblock ~50 ~-64 ~21 minecraft:deepslate_tiles
fill ~51 ~-64 ~21 ~63 ~-64 ~21 minecraft:air
setblock ~64 ~-64 ~21 minecraft:deepslate_tiles
setblock ~4 ~-64 ~22 minecraft:deepslate_tiles
fill ~5 ~-64 ~22 ~17 ~-64 ~22 minecraft:air
setblock ~18 ~-64 ~22 minecraft:deepslate_tiles
fill ~19 ~-64 ~22 ~24 ~-64 ~22 minecraft:air
fill ~25 ~-64 ~22 ~26 ~-64 ~22 minecraft:deepslate_tiles
fill ~27 ~-64 ~22 ~41 ~-64 ~22 minecraft:air
fill ~42 ~-64 ~22 ~43 ~-64 ~22 minecraft:deepslate_tiles
fill ~44 ~-64 ~22 ~49 ~-64 ~22 minecraft:air
setblock ~50 ~-64 ~22 minecraft:deepslate_tiles
fill ~51 ~-64 ~22 ~63 ~-64 ~22 minecraft:air
setblock ~64 ~-64 ~22 minecraft:deepslate_tiles
setblock ~4 ~-64 ~23 minecraft:deepslate_tiles
setblock ~5 ~-64 ~23 minecraft:waxed_cut_copper
fill ~6 ~-64 ~23 ~16 ~-64 ~23 minecraft:air
setblock ~17 ~-64 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~23 minecraft:deepslate_tiles
fill ~19 ~-64 ~23 ~23 ~-64 ~23 minecraft:air
fill ~24 ~-64 ~23 ~25 ~-64 ~23 minecraft:deepslate_tiles
fill ~26 ~-64 ~23 ~42 ~-64 ~23 minecraft:air
fill ~43 ~-64 ~23 ~44 ~-64 ~23 minecraft:deepslate_tiles
fill ~45 ~-64 ~23 ~49 ~-64 ~23 minecraft:air
setblock ~50 ~-64 ~23 minecraft:deepslate_tiles
fill ~51 ~-64 ~23 ~63 ~-64 ~23 minecraft:air
setblock ~64 ~-64 ~23 minecraft:deepslate_tiles
setblock ~4 ~-64 ~24 minecraft:deepslate_tiles
fill ~5 ~-64 ~24 ~17 ~-64 ~24 minecraft:air
setblock ~18 ~-64 ~24 minecraft:deepslate_tiles
fill ~19 ~-64 ~24 ~22 ~-64 ~24 minecraft:air
fill ~23 ~-64 ~24 ~24 ~-64 ~24 minecraft:deepslate_tiles
fill ~25 ~-64 ~24 ~43 ~-64 ~24 minecraft:air
fill ~44 ~-64 ~24 ~45 ~-64 ~24 minecraft:deepslate_tiles
fill ~46 ~-64 ~24 ~49 ~-64 ~24 minecraft:air
setblock ~50 ~-64 ~24 minecraft:deepslate_tiles
fill ~51 ~-64 ~24 ~63 ~-64 ~24 minecraft:air
setblock ~64 ~-64 ~24 minecraft:deepslate_tiles
setblock ~4 ~-64 ~25 minecraft:deepslate_tiles
fill ~5 ~-64 ~25 ~17 ~-64 ~25 minecraft:air
setblock ~18 ~-64 ~25 minecraft:deepslate_tiles
fill ~19 ~-64 ~25 ~21 ~-64 ~25 minecraft:air
fill ~22 ~-64 ~25 ~23 ~-64 ~25 minecraft:deepslate_tiles
fill ~24 ~-64 ~25 ~44 ~-64 ~25 minecraft:air
fill ~45 ~-64 ~25 ~46 ~-64 ~25 minecraft:deepslate_tiles
fill ~47 ~-64 ~25 ~49 ~-64 ~25 minecraft:air
setblock ~50 ~-64 ~25 minecraft:deepslate_tiles
fill ~51 ~-64 ~25 ~63 ~-64 ~25 minecraft:air
setblock ~64 ~-64 ~25 minecraft:deepslate_tiles
setblock ~4 ~-64 ~26 minecraft:deepslate_tiles
setblock ~5 ~-64 ~26 minecraft:waxed_cut_copper
fill ~6 ~-64 ~26 ~16 ~-64 ~26 minecraft:air
setblock ~17 ~-64 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~26 minecraft:deepslate_tiles
fill ~19 ~-64 ~26 ~21 ~-64 ~26 minecraft:air
setblock ~22 ~-64 ~26 minecraft:deepslate_tiles
fill ~23 ~-64 ~26 ~25 ~-64 ~26 minecraft:air
setblock ~26 ~-64 ~26 minecraft:redstone_lamp[lit=true]
fill ~27 ~-64 ~26 ~41 ~-64 ~26 minecraft:air
setblock ~42 ~-64 ~26 minecraft:redstone_lamp[lit=true]
fill ~43 ~-64 ~26 ~45 ~-64 ~26 minecraft:air
setblock ~46 ~-64 ~26 minecraft:deepslate_tiles
fill ~47 ~-64 ~26 ~49 ~-64 ~26 minecraft:air
setblock ~50 ~-64 ~26 minecraft:deepslate_tiles
fill ~51 ~-64 ~26 ~63 ~-64 ~26 minecraft:air
setblock ~64 ~-64 ~26 minecraft:deepslate_tiles
setblock ~4 ~-64 ~27 minecraft:deepslate_tiles
fill ~5 ~-64 ~27 ~17 ~-64 ~27 minecraft:air
setblock ~18 ~-64 ~27 minecraft:deepslate_tiles
fill ~19 ~-64 ~27 ~20 ~-64 ~27 minecraft:air
setblock ~21 ~-64 ~27 minecraft:deepslate_tiles
fill ~22 ~-64 ~27 ~46 ~-64 ~27 minecraft:air
setblock ~47 ~-64 ~27 minecraft:deepslate_tiles
fill ~48 ~-64 ~27 ~49 ~-64 ~27 minecraft:air
setblock ~50 ~-64 ~27 minecraft:deepslate_tiles
fill ~51 ~-64 ~27 ~63 ~-64 ~27 minecraft:air
setblock ~64 ~-64 ~27 minecraft:deepslate_tiles
setblock ~4 ~-64 ~28 minecraft:deepslate_tiles
fill ~5 ~-64 ~28 ~17 ~-64 ~28 minecraft:air
setblock ~18 ~-64 ~28 minecraft:deepslate_tiles
fill ~19 ~-64 ~28 ~20 ~-64 ~28 minecraft:air
setblock ~21 ~-64 ~28 minecraft:deepslate_tiles
fill ~22 ~-64 ~28 ~46 ~-64 ~28 minecraft:air
setblock ~47 ~-64 ~28 minecraft:deepslate_tiles
fill ~48 ~-64 ~28 ~49 ~-64 ~28 minecraft:air
setblock ~50 ~-64 ~28 minecraft:deepslate_tiles
fill ~51 ~-64 ~28 ~63 ~-64 ~28 minecraft:air
setblock ~64 ~-64 ~28 minecraft:deepslate_tiles
setblock ~4 ~-64 ~29 minecraft:deepslate_tiles
setblock ~5 ~-64 ~29 minecraft:waxed_cut_copper
fill ~6 ~-64 ~29 ~16 ~-64 ~29 minecraft:air
setblock ~17 ~-64 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~29 minecraft:deepslate_tiles
setblock ~19 ~-64 ~29 minecraft:air
setblock ~20 ~-64 ~29 minecraft:deepslate_tiles
fill ~21 ~-64 ~29 ~47 ~-64 ~29 minecraft:air
setblock ~48 ~-64 ~29 minecraft:deepslate_tiles
setblock ~49 ~-64 ~29 minecraft:air
setblock ~50 ~-64 ~29 minecraft:deepslate_tiles
fill ~51 ~-64 ~29 ~63 ~-64 ~29 minecraft:air
setblock ~64 ~-64 ~29 minecraft:deepslate_tiles
setblock ~4 ~-64 ~30 minecraft:deepslate_tiles
fill ~5 ~-64 ~30 ~17 ~-64 ~30 minecraft:air
setblock ~18 ~-64 ~30 minecraft:deepslate_tiles
setblock ~19 ~-64 ~30 minecraft:air
setblock ~20 ~-64 ~30 minecraft:deepslate_tiles
fill ~21 ~-64 ~30 ~47 ~-64 ~30 minecraft:air
setblock ~48 ~-64 ~30 minecraft:deepslate_tiles
setblock ~49 ~-64 ~30 minecraft:air
setblock ~50 ~-64 ~30 minecraft:deepslate_tiles
fill ~51 ~-64 ~30 ~63 ~-64 ~30 minecraft:air
setblock ~64 ~-64 ~30 minecraft:deepslate_tiles
setblock ~4 ~-64 ~31 minecraft:deepslate_tiles
setblock ~5 ~-64 ~31 minecraft:air
setblock ~6 ~-64 ~31 minecraft:waxed_cut_copper
fill ~7 ~-64 ~31 ~8 ~-64 ~31 minecraft:air
setblock ~9 ~-64 ~31 minecraft:waxed_cut_copper
fill ~10 ~-64 ~31 ~14 ~-64 ~31 minecraft:air
setblock ~15 ~-64 ~31 minecraft:waxed_cut_copper
fill ~16 ~-64 ~31 ~17 ~-64 ~31 minecraft:air
setblock ~18 ~-64 ~31 minecraft:deepslate_tiles
setblock ~19 ~-64 ~31 minecraft:air
setblock ~20 ~-64 ~31 minecraft:deepslate_tiles
fill ~21 ~-64 ~31 ~47 ~-64 ~31 minecraft:air
setblock ~48 ~-64 ~31 minecraft:deepslate_tiles
setblock ~49 ~-64 ~31 minecraft:air
setblock ~50 ~-64 ~31 minecraft:deepslate_tiles
fill ~51 ~-64 ~31 ~63 ~-64 ~31 minecraft:air
setblock ~64 ~-64 ~31 minecraft:deepslate_tiles
fill ~4 ~-64 ~32 ~20 ~-64 ~32 minecraft:deepslate_tiles
fill ~21 ~-64 ~32 ~32 ~-64 ~32 minecraft:air
fill ~33 ~-64 ~32 ~35 ~-64 ~32 minecraft:waxed_cut_copper
fill ~36 ~-64 ~32 ~47 ~-64 ~32 minecraft:air
fill ~48 ~-64 ~32 ~64 ~-64 ~32 minecraft:deepslate_tiles
setblock ~4 ~-64 ~33 minecraft:deepslate_tiles
fill ~5 ~-64 ~33 ~31 ~-64 ~33 minecraft:air
setblock ~32 ~-64 ~33 minecraft:waxed_cut_copper
fill ~33 ~-64 ~33 ~35 ~-64 ~33 minecraft:sea_lantern
setblock ~36 ~-64 ~33 minecraft:waxed_cut_copper
fill ~37 ~-64 ~33 ~63 ~-64 ~33 minecraft:air
setblock ~64 ~-64 ~33 minecraft:deepslate_tiles
setblock ~4 ~-64 ~34 minecraft:deepslate_tiles
fill ~5 ~-64 ~34 ~31 ~-64 ~34 minecraft:air
setblock ~32 ~-64 ~34 minecraft:waxed_cut_copper
fill ~33 ~-64 ~34 ~35 ~-64 ~34 minecraft:sea_lantern
setblock ~36 ~-64 ~34 minecraft:waxed_cut_copper
fill ~37 ~-64 ~34 ~63 ~-64 ~34 minecraft:air
setblock ~64 ~-64 ~34 minecraft:deepslate_tiles
setblock ~4 ~-64 ~35 minecraft:deepslate_tiles
fill ~5 ~-64 ~35 ~31 ~-64 ~35 minecraft:air
setblock ~32 ~-64 ~35 minecraft:waxed_cut_copper
fill ~33 ~-64 ~35 ~35 ~-64 ~35 minecraft:sea_lantern
setblock ~36 ~-64 ~35 minecraft:waxed_cut_copper
fill ~37 ~-64 ~35 ~63 ~-64 ~35 minecraft:air
setblock ~64 ~-64 ~35 minecraft:deepslate_tiles
fill ~4 ~-64 ~36 ~20 ~-64 ~36 minecraft:deepslate_tiles
fill ~21 ~-64 ~36 ~32 ~-64 ~36 minecraft:air
fill ~33 ~-64 ~36 ~35 ~-64 ~36 minecraft:waxed_cut_copper
fill ~36 ~-64 ~36 ~47 ~-64 ~36 minecraft:air
fill ~48 ~-64 ~36 ~64 ~-64 ~36 minecraft:deepslate_tiles
setblock ~4 ~-64 ~37 minecraft:deepslate_tiles
setblock ~5 ~-64 ~37 minecraft:air
setblock ~6 ~-64 ~37 minecraft:waxed_cut_copper
fill ~7 ~-64 ~37 ~8 ~-64 ~37 minecraft:air
setblock ~9 ~-64 ~37 minecraft:waxed_cut_copper
fill ~10 ~-64 ~37 ~14 ~-64 ~37 minecraft:air
setblock ~15 ~-64 ~37 minecraft:waxed_cut_copper
fill ~16 ~-64 ~37 ~17 ~-64 ~37 minecraft:air
setblock ~18 ~-64 ~37 minecraft:deepslate_tiles
setblock ~19 ~-64 ~37 minecraft:air
setblock ~20 ~-64 ~37 minecraft:deepslate_tiles
fill ~21 ~-64 ~37 ~47 ~-64 ~37 minecraft:air
setblock ~48 ~-64 ~37 minecraft:deepslate_tiles
setblock ~49 ~-64 ~37 minecraft:air
setblock ~50 ~-64 ~37 minecraft:deepslate_tiles
fill ~51 ~-64 ~37 ~63 ~-64 ~37 minecraft:air
setblock ~64 ~-64 ~37 minecraft:deepslate_tiles
setblock ~4 ~-64 ~38 minecraft:deepslate_tiles
setblock ~5 ~-64 ~38 minecraft:waxed_cut_copper
fill ~6 ~-64 ~38 ~16 ~-64 ~38 minecraft:air
setblock ~17 ~-64 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~38 minecraft:deepslate_tiles
setblock ~19 ~-64 ~38 minecraft:air
setblock ~20 ~-64 ~38 minecraft:deepslate_tiles
fill ~21 ~-64 ~38 ~47 ~-64 ~38 minecraft:air
setblock ~48 ~-64 ~38 minecraft:deepslate_tiles
setblock ~49 ~-64 ~38 minecraft:air
setblock ~50 ~-64 ~38 minecraft:deepslate_tiles
fill ~51 ~-64 ~38 ~63 ~-64 ~38 minecraft:air
setblock ~64 ~-64 ~38 minecraft:deepslate_tiles
setblock ~4 ~-64 ~39 minecraft:deepslate_tiles
fill ~5 ~-64 ~39 ~17 ~-64 ~39 minecraft:air
setblock ~18 ~-64 ~39 minecraft:deepslate_tiles
setblock ~19 ~-64 ~39 minecraft:air
setblock ~20 ~-64 ~39 minecraft:deepslate_tiles
fill ~21 ~-64 ~39 ~47 ~-64 ~39 minecraft:air
setblock ~48 ~-64 ~39 minecraft:deepslate_tiles
setblock ~49 ~-64 ~39 minecraft:air
setblock ~50 ~-64 ~39 minecraft:deepslate_tiles
fill ~51 ~-64 ~39 ~63 ~-64 ~39 minecraft:air
setblock ~64 ~-64 ~39 minecraft:deepslate_tiles
setblock ~4 ~-64 ~40 minecraft:deepslate_tiles
fill ~5 ~-64 ~40 ~17 ~-64 ~40 minecraft:air
setblock ~18 ~-64 ~40 minecraft:deepslate_tiles
fill ~19 ~-64 ~40 ~20 ~-64 ~40 minecraft:air
setblock ~21 ~-64 ~40 minecraft:deepslate_tiles
fill ~22 ~-64 ~40 ~46 ~-64 ~40 minecraft:air
setblock ~47 ~-64 ~40 minecraft:deepslate_tiles
fill ~48 ~-64 ~40 ~49 ~-64 ~40 minecraft:air
setblock ~50 ~-64 ~40 minecraft:deepslate_tiles
fill ~51 ~-64 ~40 ~63 ~-64 ~40 minecraft:air
setblock ~64 ~-64 ~40 minecraft:deepslate_tiles
setblock ~4 ~-64 ~41 minecraft:deepslate_tiles
setblock ~5 ~-64 ~41 minecraft:waxed_cut_copper
fill ~6 ~-64 ~41 ~16 ~-64 ~41 minecraft:air
setblock ~17 ~-64 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~41 minecraft:deepslate_tiles
fill ~19 ~-64 ~41 ~20 ~-64 ~41 minecraft:air
setblock ~21 ~-64 ~41 minecraft:deepslate_tiles
fill ~22 ~-64 ~41 ~46 ~-64 ~41 minecraft:air
setblock ~47 ~-64 ~41 minecraft:deepslate_tiles
fill ~48 ~-64 ~41 ~49 ~-64 ~41 minecraft:air
setblock ~50 ~-64 ~41 minecraft:deepslate_tiles
fill ~51 ~-64 ~41 ~63 ~-64 ~41 minecraft:air
setblock ~64 ~-64 ~41 minecraft:deepslate_tiles
setblock ~4 ~-64 ~42 minecraft:deepslate_tiles
fill ~5 ~-64 ~42 ~17 ~-64 ~42 minecraft:air
setblock ~18 ~-64 ~42 minecraft:deepslate_tiles
fill ~19 ~-64 ~42 ~21 ~-64 ~42 minecraft:air
setblock ~22 ~-64 ~42 minecraft:deepslate_tiles
fill ~23 ~-64 ~42 ~25 ~-64 ~42 minecraft:air
setblock ~26 ~-64 ~42 minecraft:redstone_lamp[lit=true]
fill ~27 ~-64 ~42 ~41 ~-64 ~42 minecraft:air
setblock ~42 ~-64 ~42 minecraft:redstone_lamp[lit=true]
fill ~43 ~-64 ~42 ~45 ~-64 ~42 minecraft:air
setblock ~46 ~-64 ~42 minecraft:deepslate_tiles
fill ~47 ~-64 ~42 ~49 ~-64 ~42 minecraft:air
setblock ~50 ~-64 ~42 minecraft:deepslate_tiles
fill ~51 ~-64 ~42 ~63 ~-64 ~42 minecraft:air
setblock ~64 ~-64 ~42 minecraft:deepslate_tiles
setblock ~4 ~-64 ~43 minecraft:deepslate_tiles
fill ~5 ~-64 ~43 ~17 ~-64 ~43 minecraft:air
setblock ~18 ~-64 ~43 minecraft:deepslate_tiles
fill ~19 ~-64 ~43 ~21 ~-64 ~43 minecraft:air
fill ~22 ~-64 ~43 ~23 ~-64 ~43 minecraft:deepslate_tiles
fill ~24 ~-64 ~43 ~44 ~-64 ~43 minecraft:air
fill ~45 ~-64 ~43 ~46 ~-64 ~43 minecraft:deepslate_tiles
fill ~47 ~-64 ~43 ~49 ~-64 ~43 minecraft:air
setblock ~50 ~-64 ~43 minecraft:deepslate_tiles
fill ~51 ~-64 ~43 ~63 ~-64 ~43 minecraft:air
setblock ~64 ~-64 ~43 minecraft:deepslate_tiles
setblock ~4 ~-64 ~44 minecraft:deepslate_tiles
setblock ~5 ~-64 ~44 minecraft:waxed_cut_copper
fill ~6 ~-64 ~44 ~16 ~-64 ~44 minecraft:air
setblock ~17 ~-64 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~44 minecraft:deepslate_tiles
fill ~19 ~-64 ~44 ~22 ~-64 ~44 minecraft:air
fill ~23 ~-64 ~44 ~24 ~-64 ~44 minecraft:deepslate_tiles
fill ~25 ~-64 ~44 ~43 ~-64 ~44 minecraft:air
fill ~44 ~-64 ~44 ~45 ~-64 ~44 minecraft:deepslate_tiles
fill ~46 ~-64 ~44 ~49 ~-64 ~44 minecraft:air
setblock ~50 ~-64 ~44 minecraft:deepslate_tiles
fill ~51 ~-64 ~44 ~63 ~-64 ~44 minecraft:air
setblock ~64 ~-64 ~44 minecraft:deepslate_tiles
setblock ~4 ~-64 ~45 minecraft:deepslate_tiles
fill ~5 ~-64 ~45 ~17 ~-64 ~45 minecraft:air
setblock ~18 ~-64 ~45 minecraft:deepslate_tiles
fill ~19 ~-64 ~45 ~23 ~-64 ~45 minecraft:air
fill ~24 ~-64 ~45 ~25 ~-64 ~45 minecraft:deepslate_tiles
fill ~26 ~-64 ~45 ~42 ~-64 ~45 minecraft:air
fill ~43 ~-64 ~45 ~44 ~-64 ~45 minecraft:deepslate_tiles
fill ~45 ~-64 ~45 ~49 ~-64 ~45 minecraft:air
setblock ~50 ~-64 ~45 minecraft:deepslate_tiles
fill ~51 ~-64 ~45 ~63 ~-64 ~45 minecraft:air
setblock ~64 ~-64 ~45 minecraft:deepslate_tiles
setblock ~4 ~-64 ~46 minecraft:deepslate_tiles
fill ~5 ~-64 ~46 ~17 ~-64 ~46 minecraft:air
setblock ~18 ~-64 ~46 minecraft:deepslate_tiles
fill ~19 ~-64 ~46 ~24 ~-64 ~46 minecraft:air
fill ~25 ~-64 ~46 ~26 ~-64 ~46 minecraft:deepslate_tiles
fill ~27 ~-64 ~46 ~41 ~-64 ~46 minecraft:air
fill ~42 ~-64 ~46 ~43 ~-64 ~46 minecraft:deepslate_tiles
fill ~44 ~-64 ~46 ~49 ~-64 ~46 minecraft:air
setblock ~50 ~-64 ~46 minecraft:deepslate_tiles
fill ~51 ~-64 ~46 ~63 ~-64 ~46 minecraft:air
setblock ~64 ~-64 ~46 minecraft:deepslate_tiles
setblock ~4 ~-64 ~47 minecraft:deepslate_tiles
setblock ~5 ~-64 ~47 minecraft:waxed_cut_copper
fill ~6 ~-64 ~47 ~16 ~-64 ~47 minecraft:air
setblock ~17 ~-64 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~47 minecraft:deepslate_tiles
fill ~19 ~-64 ~47 ~26 ~-64 ~47 minecraft:air
fill ~27 ~-64 ~47 ~28 ~-64 ~47 minecraft:deepslate_tiles
fill ~29 ~-64 ~47 ~39 ~-64 ~47 minecraft:air
fill ~40 ~-64 ~47 ~41 ~-64 ~47 minecraft:deepslate_tiles
fill ~42 ~-64 ~47 ~49 ~-64 ~47 minecraft:air
setblock ~50 ~-64 ~47 minecraft:deepslate_tiles
fill ~51 ~-64 ~47 ~63 ~-64 ~47 minecraft:air
setblock ~64 ~-64 ~47 minecraft:deepslate_tiles
setblock ~4 ~-64 ~48 minecraft:deepslate_tiles
fill ~5 ~-64 ~48 ~17 ~-64 ~48 minecraft:air
setblock ~18 ~-64 ~48 minecraft:deepslate_tiles
fill ~19 ~-64 ~48 ~28 ~-64 ~48 minecraft:air
fill ~29 ~-64 ~48 ~32 ~-64 ~48 minecraft:deepslate_tiles
fill ~33 ~-64 ~48 ~35 ~-64 ~48 minecraft:air
fill ~36 ~-64 ~48 ~39 ~-64 ~48 minecraft:deepslate_tiles
fill ~40 ~-64 ~48 ~49 ~-64 ~48 minecraft:air
setblock ~50 ~-64 ~48 minecraft:deepslate_tiles
fill ~51 ~-64 ~48 ~63 ~-64 ~48 minecraft:air
setblock ~64 ~-64 ~48 minecraft:deepslate_tiles
setblock ~4 ~-64 ~49 minecraft:deepslate_tiles
setblock ~5 ~-64 ~49 minecraft:air
setblock ~6 ~-64 ~49 minecraft:waxed_cut_copper
fill ~7 ~-64 ~49 ~8 ~-64 ~49 minecraft:air
setblock ~9 ~-64 ~49 minecraft:waxed_cut_copper
fill ~10 ~-64 ~49 ~14 ~-64 ~49 minecraft:air
setblock ~15 ~-64 ~49 minecraft:waxed_cut_copper
fill ~16 ~-64 ~49 ~17 ~-64 ~49 minecraft:air
setblock ~18 ~-64 ~49 minecraft:deepslate_tiles
fill ~19 ~-64 ~49 ~31 ~-64 ~49 minecraft:air
setblock ~32 ~-64 ~49 minecraft:deepslate_tiles
fill ~33 ~-64 ~49 ~35 ~-64 ~49 minecraft:air
setblock ~36 ~-64 ~49 minecraft:deepslate_tiles
fill ~37 ~-64 ~49 ~49 ~-64 ~49 minecraft:air
setblock ~50 ~-64 ~49 minecraft:deepslate_tiles
fill ~51 ~-64 ~49 ~63 ~-64 ~49 minecraft:air
setblock ~64 ~-64 ~49 minecraft:deepslate_tiles
fill ~4 ~-64 ~50 ~32 ~-64 ~50 minecraft:deepslate_tiles
fill ~33 ~-64 ~50 ~35 ~-64 ~50 minecraft:air
fill ~36 ~-64 ~50 ~64 ~-64 ~50 minecraft:deepslate_tiles
setblock ~4 ~-64 ~51 minecraft:deepslate_tiles
fill ~5 ~-64 ~51 ~9 ~-64 ~51 minecraft:waxed_cut_copper
fill ~10 ~-64 ~51 ~12 ~-64 ~51 minecraft:air
fill ~13 ~-64 ~51 ~17 ~-64 ~51 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~51 minecraft:deepslate_tiles
fill ~19 ~-64 ~51 ~31 ~-64 ~51 minecraft:air
setblock ~32 ~-64 ~51 minecraft:deepslate_tiles
fill ~33 ~-64 ~51 ~35 ~-64 ~51 minecraft:air
setblock ~36 ~-64 ~51 minecraft:deepslate_tiles
fill ~37 ~-64 ~51 ~49 ~-64 ~51 minecraft:air
setblock ~50 ~-64 ~51 minecraft:deepslate_tiles
setblock ~51 ~-64 ~51 minecraft:waxed_cut_copper
fill ~52 ~-64 ~51 ~53 ~-64 ~51 minecraft:air
setblock ~54 ~-64 ~51 minecraft:waxed_cut_copper
fill ~55 ~-64 ~51 ~59 ~-64 ~51 minecraft:air
setblock ~60 ~-64 ~51 minecraft:waxed_cut_copper
fill ~61 ~-64 ~51 ~62 ~-64 ~51 minecraft:air
setblock ~63 ~-64 ~51 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~51 minecraft:deepslate_tiles
setblock ~4 ~-64 ~52 minecraft:deepslate_tiles
setblock ~5 ~-64 ~52 minecraft:waxed_cut_copper
fill ~6 ~-64 ~52 ~16 ~-64 ~52 minecraft:air
setblock ~17 ~-64 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~52 minecraft:deepslate_tiles
fill ~19 ~-64 ~52 ~31 ~-64 ~52 minecraft:air
setblock ~32 ~-64 ~52 minecraft:deepslate_tiles
fill ~33 ~-64 ~52 ~35 ~-64 ~52 minecraft:air
setblock ~36 ~-64 ~52 minecraft:deepslate_tiles
fill ~37 ~-64 ~52 ~49 ~-64 ~52 minecraft:air
setblock ~50 ~-64 ~52 minecraft:deepslate_tiles
fill ~51 ~-64 ~52 ~63 ~-64 ~52 minecraft:air
setblock ~64 ~-64 ~52 minecraft:deepslate_tiles
setblock ~4 ~-64 ~53 minecraft:deepslate_tiles
setblock ~5 ~-64 ~53 minecraft:waxed_cut_copper
fill ~6 ~-64 ~53 ~16 ~-64 ~53 minecraft:air
setblock ~17 ~-64 ~53 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~53 minecraft:deepslate_tiles
fill ~19 ~-64 ~53 ~31 ~-64 ~53 minecraft:air
setblock ~32 ~-64 ~53 minecraft:deepslate_tiles
fill ~33 ~-64 ~53 ~35 ~-64 ~53 minecraft:air
setblock ~36 ~-64 ~53 minecraft:deepslate_tiles
fill ~37 ~-64 ~53 ~49 ~-64 ~53 minecraft:air
setblock ~50 ~-64 ~53 minecraft:deepslate_tiles
fill ~51 ~-64 ~53 ~63 ~-64 ~53 minecraft:air
setblock ~64 ~-64 ~53 minecraft:deepslate_tiles
setblock ~4 ~-64 ~54 minecraft:deepslate_tiles
setblock ~5 ~-64 ~54 minecraft:waxed_cut_copper
fill ~6 ~-64 ~54 ~16 ~-64 ~54 minecraft:air
setblock ~17 ~-64 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~54 minecraft:deepslate_tiles
fill ~19 ~-64 ~54 ~31 ~-64 ~54 minecraft:air
setblock ~32 ~-64 ~54 minecraft:deepslate_tiles
fill ~33 ~-64 ~54 ~35 ~-64 ~54 minecraft:air
setblock ~36 ~-64 ~54 minecraft:deepslate_tiles
fill ~37 ~-64 ~54 ~49 ~-64 ~54 minecraft:air
setblock ~50 ~-64 ~54 minecraft:deepslate_tiles
setblock ~51 ~-64 ~54 minecraft:waxed_cut_copper
fill ~52 ~-64 ~54 ~62 ~-64 ~54 minecraft:air
setblock ~63 ~-64 ~54 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~54 minecraft:deepslate_tiles
setblock ~4 ~-64 ~55 minecraft:deepslate_tiles
setblock ~5 ~-64 ~55 minecraft:waxed_cut_copper
fill ~6 ~-64 ~55 ~16 ~-64 ~55 minecraft:air
setblock ~17 ~-64 ~55 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~55 minecraft:deepslate_tiles
fill ~19 ~-64 ~55 ~31 ~-64 ~55 minecraft:air
setblock ~32 ~-64 ~55 minecraft:deepslate_tiles
fill ~33 ~-64 ~55 ~35 ~-64 ~55 minecraft:air
setblock ~36 ~-64 ~55 minecraft:deepslate_tiles
fill ~37 ~-64 ~55 ~49 ~-64 ~55 minecraft:air
setblock ~50 ~-64 ~55 minecraft:deepslate_tiles
fill ~51 ~-64 ~55 ~63 ~-64 ~55 minecraft:air
setblock ~64 ~-64 ~55 minecraft:deepslate_tiles
setblock ~4 ~-64 ~56 minecraft:deepslate_tiles
setblock ~5 ~-64 ~56 minecraft:waxed_cut_copper
fill ~6 ~-64 ~56 ~17 ~-64 ~56 minecraft:air
setblock ~18 ~-64 ~56 minecraft:deepslate_tiles
fill ~19 ~-64 ~56 ~31 ~-64 ~56 minecraft:air
setblock ~32 ~-64 ~56 minecraft:deepslate_tiles
fill ~33 ~-64 ~56 ~35 ~-64 ~56 minecraft:air
setblock ~36 ~-64 ~56 minecraft:deepslate_tiles
fill ~37 ~-64 ~56 ~49 ~-64 ~56 minecraft:air
setblock ~50 ~-64 ~56 minecraft:deepslate_tiles
fill ~51 ~-64 ~56 ~63 ~-64 ~56 minecraft:air
setblock ~64 ~-64 ~56 minecraft:deepslate_tiles
setblock ~4 ~-64 ~57 minecraft:deepslate_tiles
setblock ~5 ~-64 ~57 minecraft:waxed_cut_copper
fill ~6 ~-64 ~57 ~11 ~-64 ~57 minecraft:air
setblock ~12 ~-64 ~57 minecraft:redstone_lamp[lit=true]
fill ~13 ~-64 ~57 ~17 ~-64 ~57 minecraft:air
setblock ~18 ~-64 ~57 minecraft:deepslate_tiles
fill ~19 ~-64 ~57 ~31 ~-64 ~57 minecraft:air
setblock ~32 ~-64 ~57 minecraft:deepslate_tiles
fill ~33 ~-64 ~57 ~35 ~-64 ~57 minecraft:air
setblock ~36 ~-64 ~57 minecraft:deepslate_tiles
fill ~37 ~-64 ~57 ~49 ~-64 ~57 minecraft:air
setblock ~50 ~-64 ~57 minecraft:deepslate_tiles
fill ~51 ~-64 ~57 ~62 ~-64 ~57 minecraft:air
setblock ~63 ~-64 ~57 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~57 minecraft:deepslate_tiles
setblock ~4 ~-64 ~58 minecraft:deepslate_tiles
setblock ~5 ~-64 ~58 minecraft:waxed_cut_copper
fill ~6 ~-64 ~58 ~17 ~-64 ~58 minecraft:air
setblock ~18 ~-64 ~58 minecraft:deepslate_tiles
fill ~19 ~-64 ~58 ~31 ~-64 ~58 minecraft:air
setblock ~32 ~-64 ~58 minecraft:deepslate_tiles
fill ~33 ~-64 ~58 ~35 ~-64 ~58 minecraft:air
setblock ~36 ~-64 ~58 minecraft:deepslate_tiles
fill ~37 ~-64 ~58 ~49 ~-64 ~58 minecraft:air
setblock ~50 ~-64 ~58 minecraft:deepslate_tiles
fill ~51 ~-64 ~58 ~63 ~-64 ~58 minecraft:air
setblock ~64 ~-64 ~58 minecraft:deepslate_tiles
setblock ~4 ~-64 ~59 minecraft:deepslate_tiles
setblock ~5 ~-64 ~59 minecraft:waxed_cut_copper
fill ~6 ~-64 ~59 ~16 ~-64 ~59 minecraft:air
setblock ~17 ~-64 ~59 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~59 minecraft:deepslate_tiles
fill ~19 ~-64 ~59 ~31 ~-64 ~59 minecraft:air
setblock ~32 ~-64 ~59 minecraft:deepslate_tiles
fill ~33 ~-64 ~59 ~35 ~-64 ~59 minecraft:air
setblock ~36 ~-64 ~59 minecraft:deepslate_tiles
fill ~37 ~-64 ~59 ~49 ~-64 ~59 minecraft:air
setblock ~50 ~-64 ~59 minecraft:deepslate_tiles
fill ~51 ~-64 ~59 ~63 ~-64 ~59 minecraft:air
setblock ~64 ~-64 ~59 minecraft:deepslate_tiles
setblock ~4 ~-64 ~60 minecraft:deepslate_tiles
setblock ~5 ~-64 ~60 minecraft:waxed_cut_copper
fill ~6 ~-64 ~60 ~16 ~-64 ~60 minecraft:air
setblock ~17 ~-64 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~60 minecraft:deepslate_tiles
fill ~19 ~-64 ~60 ~31 ~-64 ~60 minecraft:air
setblock ~32 ~-64 ~60 minecraft:deepslate_tiles
fill ~33 ~-64 ~60 ~35 ~-64 ~60 minecraft:air
setblock ~36 ~-64 ~60 minecraft:deepslate_tiles
fill ~37 ~-64 ~60 ~49 ~-64 ~60 minecraft:air
setblock ~50 ~-64 ~60 minecraft:deepslate_tiles
setblock ~51 ~-64 ~60 minecraft:waxed_cut_copper
fill ~52 ~-64 ~60 ~62 ~-64 ~60 minecraft:air
setblock ~63 ~-64 ~60 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~60 minecraft:deepslate_tiles
setblock ~4 ~-64 ~61 minecraft:deepslate_tiles
setblock ~5 ~-64 ~61 minecraft:waxed_cut_copper
fill ~6 ~-64 ~61 ~16 ~-64 ~61 minecraft:air
setblock ~17 ~-64 ~61 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~61 minecraft:deepslate_tiles
fill ~19 ~-64 ~61 ~31 ~-64 ~61 minecraft:air
setblock ~32 ~-64 ~61 minecraft:deepslate_tiles
fill ~33 ~-64 ~61 ~35 ~-64 ~61 minecraft:air
setblock ~36 ~-64 ~61 minecraft:deepslate_tiles
fill ~37 ~-64 ~61 ~49 ~-64 ~61 minecraft:air
setblock ~50 ~-64 ~61 minecraft:deepslate_tiles
fill ~51 ~-64 ~61 ~63 ~-64 ~61 minecraft:air
setblock ~64 ~-64 ~61 minecraft:deepslate_tiles
setblock ~4 ~-64 ~62 minecraft:deepslate_tiles
setblock ~5 ~-64 ~62 minecraft:waxed_cut_copper
fill ~6 ~-64 ~62 ~16 ~-64 ~62 minecraft:air
setblock ~17 ~-64 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~62 minecraft:deepslate_tiles
fill ~19 ~-64 ~62 ~31 ~-64 ~62 minecraft:air
setblock ~32 ~-64 ~62 minecraft:deepslate_tiles
fill ~33 ~-64 ~62 ~35 ~-64 ~62 minecraft:air
setblock ~36 ~-64 ~62 minecraft:deepslate_tiles
fill ~37 ~-64 ~62 ~49 ~-64 ~62 minecraft:air
setblock ~50 ~-64 ~62 minecraft:deepslate_tiles
fill ~51 ~-64 ~62 ~63 ~-64 ~62 minecraft:air
setblock ~64 ~-64 ~62 minecraft:deepslate_tiles
setblock ~4 ~-64 ~63 minecraft:deepslate_tiles
fill ~5 ~-64 ~63 ~17 ~-64 ~63 minecraft:waxed_cut_copper
setblock ~18 ~-64 ~63 minecraft:deepslate_tiles
fill ~19 ~-64 ~63 ~31 ~-64 ~63 minecraft:air
setblock ~32 ~-64 ~63 minecraft:deepslate_tiles
fill ~33 ~-64 ~63 ~35 ~-64 ~63 minecraft:air
setblock ~36 ~-64 ~63 minecraft:deepslate_tiles
fill ~37 ~-64 ~63 ~49 ~-64 ~63 minecraft:air
setblock ~50 ~-64 ~63 minecraft:deepslate_tiles
setblock ~51 ~-64 ~63 minecraft:waxed_cut_copper
fill ~52 ~-64 ~63 ~53 ~-64 ~63 minecraft:air
setblock ~54 ~-64 ~63 minecraft:waxed_cut_copper
fill ~55 ~-64 ~63 ~56 ~-64 ~63 minecraft:air
setblock ~57 ~-64 ~63 minecraft:waxed_cut_copper
fill ~58 ~-64 ~63 ~59 ~-64 ~63 minecraft:air
setblock ~60 ~-64 ~63 minecraft:waxed_cut_copper
fill ~61 ~-64 ~63 ~62 ~-64 ~63 minecraft:air
setblock ~63 ~-64 ~63 minecraft:waxed_cut_copper
setblock ~64 ~-64 ~63 minecraft:deepslate_tiles
fill ~4 ~-64 ~64 ~64 ~-64 ~64 minecraft:deepslate_tiles
fill ~32 ~-64 ~66 ~36 ~-64 ~66 minecraft:polished_andesite
setblock ~32 ~-64 ~67 minecraft:polished_andesite
fill ~33 ~-64 ~67 ~35 ~-64 ~67 minecraft:air
setblock ~36 ~-64 ~67 minecraft:polished_andesite
setblock ~32 ~-64 ~68 minecraft:sea_lantern
setblock ~33 ~-64 ~68 minecraft:air
setblock ~34 ~-64 ~68 minecraft:quartz_pillar
setblock ~35 ~-64 ~68 minecraft:air
setblock ~36 ~-64 ~68 minecraft:sea_lantern
setblock ~32 ~-64 ~69 minecraft:polished_andesite
setblock ~33 ~-64 ~69 minecraft:air
setblock ~34 ~-64 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-64 ~69 minecraft:air
setblock ~36 ~-64 ~69 minecraft:polished_andesite
fill ~32 ~-64 ~70 ~36 ~-64 ~70 minecraft:polished_andesite
fill ~4 ~-63 ~4 ~64 ~-63 ~4 minecraft:deepslate_tiles
setblock ~4 ~-63 ~5 minecraft:deepslate_tiles
fill ~5 ~-63 ~5 ~17 ~-63 ~5 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~5 minecraft:deepslate_tiles
fill ~19 ~-63 ~5 ~31 ~-63 ~5 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~5 minecraft:deepslate_tiles
fill ~33 ~-63 ~5 ~35 ~-63 ~5 minecraft:air
setblock ~36 ~-63 ~5 minecraft:deepslate_tiles
setblock ~37 ~-63 ~5 minecraft:waxed_cut_copper
fill ~38 ~-63 ~5 ~39 ~-63 ~5 minecraft:air
setblock ~40 ~-63 ~5 minecraft:waxed_cut_copper
fill ~41 ~-63 ~5 ~42 ~-63 ~5 minecraft:air
setblock ~43 ~-63 ~5 minecraft:waxed_cut_copper
fill ~44 ~-63 ~5 ~45 ~-63 ~5 minecraft:air
setblock ~46 ~-63 ~5 minecraft:waxed_cut_copper
fill ~47 ~-63 ~5 ~48 ~-63 ~5 minecraft:air
setblock ~49 ~-63 ~5 minecraft:waxed_cut_copper
setblock ~50 ~-63 ~5 minecraft:deepslate_tiles
setblock ~51 ~-63 ~5 minecraft:air
setblock ~52 ~-63 ~5 minecraft:waxed_cut_copper
fill ~53 ~-63 ~5 ~54 ~-63 ~5 minecraft:air
setblock ~55 ~-63 ~5 minecraft:waxed_cut_copper
fill ~56 ~-63 ~5 ~57 ~-63 ~5 minecraft:air
setblock ~58 ~-63 ~5 minecraft:waxed_cut_copper
fill ~59 ~-63 ~5 ~60 ~-63 ~5 minecraft:air
setblock ~61 ~-63 ~5 minecraft:waxed_cut_copper
fill ~62 ~-63 ~5 ~63 ~-63 ~5 minecraft:air
schedule function hive:weiter/3 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 2 von 18 fertig","color":"gray"}]