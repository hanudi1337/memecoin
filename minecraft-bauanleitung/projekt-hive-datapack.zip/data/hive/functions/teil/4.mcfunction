setblock ~50 ~-60 ~9 minecraft:deepslate_tiles
setblock ~51 ~-60 ~9 minecraft:waxed_cut_copper
fill ~52 ~-60 ~9 ~62 ~-60 ~9 minecraft:air
setblock ~63 ~-60 ~9 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~9 minecraft:deepslate_tiles
setblock ~4 ~-60 ~10 minecraft:deepslate_tiles
setblock ~5 ~-60 ~10 minecraft:waxed_cut_copper
fill ~6 ~-60 ~10 ~17 ~-60 ~10 minecraft:air
setblock ~18 ~-60 ~10 minecraft:deepslate_tiles
fill ~19 ~-60 ~10 ~31 ~-60 ~10 minecraft:air
setblock ~32 ~-60 ~10 minecraft:deepslate_tiles
setblock ~33 ~-60 ~10 minecraft:air
setblock ~34 ~-60 ~10 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~10 minecraft:air
setblock ~36 ~-60 ~10 minecraft:deepslate_tiles
fill ~37 ~-60 ~10 ~49 ~-60 ~10 minecraft:air
setblock ~50 ~-60 ~10 minecraft:deepslate_tiles
fill ~51 ~-60 ~10 ~63 ~-60 ~10 minecraft:air
setblock ~64 ~-60 ~10 minecraft:deepslate_tiles
setblock ~4 ~-60 ~11 minecraft:deepslate_tiles
setblock ~5 ~-60 ~11 minecraft:waxed_cut_copper
fill ~6 ~-60 ~11 ~17 ~-60 ~11 minecraft:air
setblock ~18 ~-60 ~11 minecraft:deepslate_tiles
fill ~19 ~-60 ~11 ~31 ~-60 ~11 minecraft:air
setblock ~32 ~-60 ~11 minecraft:deepslate_tiles
setblock ~33 ~-60 ~11 minecraft:air
setblock ~34 ~-60 ~11 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~11 minecraft:air
setblock ~36 ~-60 ~11 minecraft:deepslate_tiles
fill ~37 ~-60 ~11 ~49 ~-60 ~11 minecraft:air
setblock ~50 ~-60 ~11 minecraft:deepslate_tiles
fill ~51 ~-60 ~11 ~63 ~-60 ~11 minecraft:air
setblock ~64 ~-60 ~11 minecraft:deepslate_tiles
setblock ~4 ~-60 ~12 minecraft:deepslate_tiles
setblock ~5 ~-60 ~12 minecraft:waxed_cut_copper
fill ~6 ~-60 ~12 ~17 ~-60 ~12 minecraft:air
setblock ~18 ~-60 ~12 minecraft:deepslate_tiles
fill ~19 ~-60 ~12 ~31 ~-60 ~12 minecraft:air
setblock ~32 ~-60 ~12 minecraft:deepslate_tiles
setblock ~33 ~-60 ~12 minecraft:air
setblock ~34 ~-60 ~12 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~12 minecraft:air
setblock ~36 ~-60 ~12 minecraft:deepslate_tiles
fill ~37 ~-60 ~12 ~49 ~-60 ~12 minecraft:air
setblock ~50 ~-60 ~12 minecraft:deepslate_tiles
fill ~51 ~-60 ~12 ~62 ~-60 ~12 minecraft:air
setblock ~63 ~-60 ~12 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~12 minecraft:deepslate_tiles
setblock ~4 ~-60 ~13 minecraft:deepslate_tiles
setblock ~5 ~-60 ~13 minecraft:waxed_cut_copper
fill ~6 ~-60 ~13 ~16 ~-60 ~13 minecraft:air
setblock ~17 ~-60 ~13 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~13 minecraft:deepslate_tiles
setblock ~19 ~-60 ~13 minecraft:waxed_cut_copper
fill ~20 ~-60 ~13 ~30 ~-60 ~13 minecraft:air
setblock ~31 ~-60 ~13 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~13 minecraft:deepslate_tiles
setblock ~33 ~-60 ~13 minecraft:air
setblock ~34 ~-60 ~13 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~13 minecraft:air
setblock ~36 ~-60 ~13 minecraft:deepslate_tiles
fill ~37 ~-60 ~13 ~49 ~-60 ~13 minecraft:air
setblock ~50 ~-60 ~13 minecraft:deepslate_tiles
fill ~51 ~-60 ~13 ~63 ~-60 ~13 minecraft:air
setblock ~64 ~-60 ~13 minecraft:deepslate_tiles
setblock ~4 ~-60 ~14 minecraft:deepslate_tiles
setblock ~5 ~-60 ~14 minecraft:waxed_cut_copper
fill ~6 ~-60 ~14 ~16 ~-60 ~14 minecraft:air
setblock ~17 ~-60 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~14 minecraft:deepslate_tiles
setblock ~19 ~-60 ~14 minecraft:waxed_cut_copper
fill ~20 ~-60 ~14 ~30 ~-60 ~14 minecraft:air
setblock ~31 ~-60 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~14 minecraft:deepslate_tiles
setblock ~33 ~-60 ~14 minecraft:air
setblock ~34 ~-60 ~14 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~14 minecraft:air
setblock ~36 ~-60 ~14 minecraft:deepslate_tiles
setblock ~37 ~-60 ~14 minecraft:waxed_cut_copper
fill ~38 ~-60 ~14 ~48 ~-60 ~14 minecraft:air
setblock ~49 ~-60 ~14 minecraft:waxed_cut_copper
setblock ~50 ~-60 ~14 minecraft:deepslate_tiles
fill ~51 ~-60 ~14 ~63 ~-60 ~14 minecraft:air
setblock ~64 ~-60 ~14 minecraft:deepslate_tiles
setblock ~4 ~-60 ~15 minecraft:deepslate_tiles
setblock ~5 ~-60 ~15 minecraft:waxed_cut_copper
fill ~6 ~-60 ~15 ~16 ~-60 ~15 minecraft:air
setblock ~17 ~-60 ~15 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~15 minecraft:deepslate_tiles
setblock ~19 ~-60 ~15 minecraft:waxed_cut_copper
fill ~20 ~-60 ~15 ~30 ~-60 ~15 minecraft:air
setblock ~31 ~-60 ~15 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~15 minecraft:deepslate_tiles
setblock ~33 ~-60 ~15 minecraft:air
setblock ~34 ~-60 ~15 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~15 minecraft:air
setblock ~36 ~-60 ~15 minecraft:deepslate_tiles
fill ~37 ~-60 ~15 ~49 ~-60 ~15 minecraft:air
setblock ~50 ~-60 ~15 minecraft:deepslate_tiles
setblock ~51 ~-60 ~15 minecraft:waxed_cut_copper
fill ~52 ~-60 ~15 ~62 ~-60 ~15 minecraft:air
setblock ~63 ~-60 ~15 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~15 minecraft:deepslate_tiles
setblock ~4 ~-60 ~16 minecraft:deepslate_tiles
setblock ~5 ~-60 ~16 minecraft:waxed_cut_copper
fill ~6 ~-60 ~16 ~16 ~-60 ~16 minecraft:air
setblock ~17 ~-60 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~16 minecraft:deepslate_tiles
setblock ~19 ~-60 ~16 minecraft:waxed_cut_copper
fill ~20 ~-60 ~16 ~30 ~-60 ~16 minecraft:air
setblock ~31 ~-60 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~16 minecraft:deepslate_tiles
setblock ~33 ~-60 ~16 minecraft:air
setblock ~34 ~-60 ~16 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~16 minecraft:air
setblock ~36 ~-60 ~16 minecraft:deepslate_tiles
fill ~37 ~-60 ~16 ~49 ~-60 ~16 minecraft:air
setblock ~50 ~-60 ~16 minecraft:deepslate_tiles
fill ~51 ~-60 ~16 ~63 ~-60 ~16 minecraft:air
setblock ~64 ~-60 ~16 minecraft:deepslate_tiles
setblock ~4 ~-60 ~17 minecraft:deepslate_tiles
fill ~5 ~-60 ~17 ~9 ~-60 ~17 minecraft:waxed_cut_copper
fill ~10 ~-60 ~17 ~12 ~-60 ~17 minecraft:air
fill ~13 ~-60 ~17 ~17 ~-60 ~17 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~17 minecraft:deepslate_tiles
fill ~19 ~-60 ~17 ~31 ~-60 ~17 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~17 minecraft:deepslate_tiles
setblock ~33 ~-60 ~17 minecraft:air
setblock ~34 ~-60 ~17 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~17 minecraft:air
setblock ~36 ~-60 ~17 minecraft:deepslate_tiles
setblock ~37 ~-60 ~17 minecraft:waxed_cut_copper
fill ~38 ~-60 ~17 ~39 ~-60 ~17 minecraft:air
setblock ~40 ~-60 ~17 minecraft:waxed_cut_copper
fill ~41 ~-60 ~17 ~42 ~-60 ~17 minecraft:air
setblock ~43 ~-60 ~17 minecraft:waxed_cut_copper
fill ~44 ~-60 ~17 ~45 ~-60 ~17 minecraft:air
setblock ~46 ~-60 ~17 minecraft:waxed_cut_copper
fill ~47 ~-60 ~17 ~48 ~-60 ~17 minecraft:air
setblock ~49 ~-60 ~17 minecraft:waxed_cut_copper
setblock ~50 ~-60 ~17 minecraft:deepslate_tiles
setblock ~51 ~-60 ~17 minecraft:air
setblock ~52 ~-60 ~17 minecraft:waxed_cut_copper
fill ~53 ~-60 ~17 ~54 ~-60 ~17 minecraft:air
setblock ~55 ~-60 ~17 minecraft:waxed_cut_copper
fill ~56 ~-60 ~17 ~60 ~-60 ~17 minecraft:air
setblock ~61 ~-60 ~17 minecraft:waxed_cut_copper
fill ~62 ~-60 ~17 ~63 ~-60 ~17 minecraft:air
setblock ~64 ~-60 ~17 minecraft:deepslate_tiles
fill ~4 ~-60 ~18 ~32 ~-60 ~18 minecraft:deepslate_tiles
setblock ~33 ~-60 ~18 minecraft:air
setblock ~34 ~-60 ~18 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~18 minecraft:air
fill ~36 ~-60 ~18 ~64 ~-60 ~18 minecraft:deepslate_tiles
setblock ~4 ~-60 ~19 minecraft:deepslate_tiles
setblock ~5 ~-60 ~19 minecraft:air
setblock ~6 ~-60 ~19 minecraft:waxed_cut_copper
fill ~7 ~-60 ~19 ~8 ~-60 ~19 minecraft:air
setblock ~9 ~-60 ~19 minecraft:waxed_cut_copper
fill ~10 ~-60 ~19 ~14 ~-60 ~19 minecraft:air
setblock ~15 ~-60 ~19 minecraft:waxed_cut_copper
fill ~16 ~-60 ~19 ~17 ~-60 ~19 minecraft:air
setblock ~18 ~-60 ~19 minecraft:deepslate_tiles
fill ~19 ~-60 ~19 ~31 ~-60 ~19 minecraft:air
setblock ~32 ~-60 ~19 minecraft:deepslate_tiles
setblock ~33 ~-60 ~19 minecraft:air
setblock ~34 ~-60 ~19 minecraft:deepslate_tiles
setblock ~35 ~-60 ~19 minecraft:air
setblock ~36 ~-60 ~19 minecraft:deepslate_tiles
fill ~37 ~-60 ~19 ~49 ~-60 ~19 minecraft:air
setblock ~50 ~-60 ~19 minecraft:deepslate_tiles
fill ~51 ~-60 ~19 ~63 ~-60 ~19 minecraft:air
setblock ~64 ~-60 ~19 minecraft:deepslate_tiles
setblock ~4 ~-60 ~20 minecraft:deepslate_tiles
setblock ~5 ~-60 ~20 minecraft:waxed_cut_copper
fill ~6 ~-60 ~20 ~16 ~-60 ~20 minecraft:air
setblock ~17 ~-60 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~20 minecraft:deepslate_tiles
fill ~19 ~-60 ~20 ~28 ~-60 ~20 minecraft:air
fill ~29 ~-60 ~20 ~33 ~-60 ~20 minecraft:deepslate_tiles
setblock ~34 ~-60 ~20 minecraft:air
fill ~35 ~-60 ~20 ~39 ~-60 ~20 minecraft:deepslate_tiles
fill ~40 ~-60 ~20 ~49 ~-60 ~20 minecraft:air
setblock ~50 ~-60 ~20 minecraft:deepslate_tiles
fill ~51 ~-60 ~20 ~63 ~-60 ~20 minecraft:air
setblock ~64 ~-60 ~20 minecraft:deepslate_tiles
setblock ~4 ~-60 ~21 minecraft:deepslate_tiles
fill ~5 ~-60 ~21 ~17 ~-60 ~21 minecraft:air
setblock ~18 ~-60 ~21 minecraft:deepslate_tiles
fill ~19 ~-60 ~21 ~26 ~-60 ~21 minecraft:air
fill ~27 ~-60 ~21 ~28 ~-60 ~21 minecraft:deepslate_tiles
fill ~29 ~-60 ~21 ~39 ~-60 ~21 minecraft:air
fill ~40 ~-60 ~21 ~41 ~-60 ~21 minecraft:deepslate_tiles
fill ~42 ~-60 ~21 ~49 ~-60 ~21 minecraft:air
setblock ~50 ~-60 ~21 minecraft:deepslate_tiles
fill ~51 ~-60 ~21 ~63 ~-60 ~21 minecraft:air
setblock ~64 ~-60 ~21 minecraft:deepslate_tiles
setblock ~4 ~-60 ~22 minecraft:deepslate_tiles
fill ~5 ~-60 ~22 ~17 ~-60 ~22 minecraft:air
setblock ~18 ~-60 ~22 minecraft:deepslate_tiles
fill ~19 ~-60 ~22 ~24 ~-60 ~22 minecraft:air
fill ~25 ~-60 ~22 ~26 ~-60 ~22 minecraft:deepslate_tiles
fill ~27 ~-60 ~22 ~41 ~-60 ~22 minecraft:air
fill ~42 ~-60 ~22 ~43 ~-60 ~22 minecraft:deepslate_tiles
fill ~44 ~-60 ~22 ~49 ~-60 ~22 minecraft:air
setblock ~50 ~-60 ~22 minecraft:deepslate_tiles
fill ~51 ~-60 ~22 ~63 ~-60 ~22 minecraft:air
setblock ~64 ~-60 ~22 minecraft:deepslate_tiles
setblock ~4 ~-60 ~23 minecraft:deepslate_tiles
setblock ~5 ~-60 ~23 minecraft:waxed_cut_copper
fill ~6 ~-60 ~23 ~16 ~-60 ~23 minecraft:air
setblock ~17 ~-60 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~23 minecraft:deepslate_tiles
fill ~19 ~-60 ~23 ~23 ~-60 ~23 minecraft:air
fill ~24 ~-60 ~23 ~25 ~-60 ~23 minecraft:deepslate_tiles
fill ~26 ~-60 ~23 ~42 ~-60 ~23 minecraft:air
fill ~43 ~-60 ~23 ~44 ~-60 ~23 minecraft:deepslate_tiles
fill ~45 ~-60 ~23 ~49 ~-60 ~23 minecraft:air
setblock ~50 ~-60 ~23 minecraft:deepslate_tiles
fill ~51 ~-60 ~23 ~63 ~-60 ~23 minecraft:air
setblock ~64 ~-60 ~23 minecraft:deepslate_tiles
setblock ~4 ~-60 ~24 minecraft:deepslate_tiles
fill ~5 ~-60 ~24 ~17 ~-60 ~24 minecraft:air
setblock ~18 ~-60 ~24 minecraft:deepslate_tiles
fill ~19 ~-60 ~24 ~22 ~-60 ~24 minecraft:air
fill ~23 ~-60 ~24 ~24 ~-60 ~24 minecraft:deepslate_tiles
fill ~25 ~-60 ~24 ~43 ~-60 ~24 minecraft:air
fill ~44 ~-60 ~24 ~45 ~-60 ~24 minecraft:deepslate_tiles
fill ~46 ~-60 ~24 ~49 ~-60 ~24 minecraft:air
setblock ~50 ~-60 ~24 minecraft:deepslate_tiles
fill ~51 ~-60 ~24 ~63 ~-60 ~24 minecraft:air
setblock ~64 ~-60 ~24 minecraft:deepslate_tiles
setblock ~4 ~-60 ~25 minecraft:deepslate_tiles
fill ~5 ~-60 ~25 ~17 ~-60 ~25 minecraft:air
setblock ~18 ~-60 ~25 minecraft:deepslate_tiles
fill ~19 ~-60 ~25 ~21 ~-60 ~25 minecraft:air
fill ~22 ~-60 ~25 ~23 ~-60 ~25 minecraft:deepslate_tiles
fill ~24 ~-60 ~25 ~44 ~-60 ~25 minecraft:air
fill ~45 ~-60 ~25 ~46 ~-60 ~25 minecraft:deepslate_tiles
fill ~47 ~-60 ~25 ~49 ~-60 ~25 minecraft:air
setblock ~50 ~-60 ~25 minecraft:deepslate_tiles
fill ~51 ~-60 ~25 ~63 ~-60 ~25 minecraft:air
setblock ~64 ~-60 ~25 minecraft:deepslate_tiles
setblock ~4 ~-60 ~26 minecraft:deepslate_tiles
setblock ~5 ~-60 ~26 minecraft:waxed_cut_copper
fill ~6 ~-60 ~26 ~16 ~-60 ~26 minecraft:air
setblock ~17 ~-60 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~26 minecraft:deepslate_tiles
fill ~19 ~-60 ~26 ~21 ~-60 ~26 minecraft:air
setblock ~22 ~-60 ~26 minecraft:deepslate_tiles
fill ~23 ~-60 ~26 ~25 ~-60 ~26 minecraft:air
setblock ~26 ~-60 ~26 minecraft:waxed_cut_copper
fill ~27 ~-60 ~26 ~41 ~-60 ~26 minecraft:air
setblock ~42 ~-60 ~26 minecraft:waxed_cut_copper
fill ~43 ~-60 ~26 ~45 ~-60 ~26 minecraft:air
setblock ~46 ~-60 ~26 minecraft:deepslate_tiles
fill ~47 ~-60 ~26 ~49 ~-60 ~26 minecraft:air
setblock ~50 ~-60 ~26 minecraft:deepslate_tiles
fill ~51 ~-60 ~26 ~63 ~-60 ~26 minecraft:air
setblock ~64 ~-60 ~26 minecraft:deepslate_tiles
setblock ~4 ~-60 ~27 minecraft:deepslate_tiles
fill ~5 ~-60 ~27 ~17 ~-60 ~27 minecraft:air
setblock ~18 ~-60 ~27 minecraft:deepslate_tiles
fill ~19 ~-60 ~27 ~20 ~-60 ~27 minecraft:air
setblock ~21 ~-60 ~27 minecraft:deepslate_tiles
fill ~22 ~-60 ~27 ~46 ~-60 ~27 minecraft:air
setblock ~47 ~-60 ~27 minecraft:deepslate_tiles
fill ~48 ~-60 ~27 ~49 ~-60 ~27 minecraft:air
setblock ~50 ~-60 ~27 minecraft:deepslate_tiles
fill ~51 ~-60 ~27 ~63 ~-60 ~27 minecraft:air
setblock ~64 ~-60 ~27 minecraft:deepslate_tiles
setblock ~4 ~-60 ~28 minecraft:deepslate_tiles
fill ~5 ~-60 ~28 ~17 ~-60 ~28 minecraft:air
setblock ~18 ~-60 ~28 minecraft:deepslate_tiles
fill ~19 ~-60 ~28 ~20 ~-60 ~28 minecraft:air
setblock ~21 ~-60 ~28 minecraft:deepslate_tiles
fill ~22 ~-60 ~28 ~46 ~-60 ~28 minecraft:air
setblock ~47 ~-60 ~28 minecraft:deepslate_tiles
fill ~48 ~-60 ~28 ~49 ~-60 ~28 minecraft:air
setblock ~50 ~-60 ~28 minecraft:deepslate_tiles
fill ~51 ~-60 ~28 ~63 ~-60 ~28 minecraft:air
setblock ~64 ~-60 ~28 minecraft:deepslate_tiles
setblock ~4 ~-60 ~29 minecraft:deepslate_tiles
setblock ~5 ~-60 ~29 minecraft:waxed_cut_copper
fill ~6 ~-60 ~29 ~16 ~-60 ~29 minecraft:air
setblock ~17 ~-60 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~29 minecraft:deepslate_tiles
setblock ~19 ~-60 ~29 minecraft:air
setblock ~20 ~-60 ~29 minecraft:deepslate_tiles
fill ~21 ~-60 ~29 ~47 ~-60 ~29 minecraft:air
setblock ~48 ~-60 ~29 minecraft:deepslate_tiles
setblock ~49 ~-60 ~29 minecraft:air
setblock ~50 ~-60 ~29 minecraft:deepslate_tiles
fill ~51 ~-60 ~29 ~63 ~-60 ~29 minecraft:air
setblock ~64 ~-60 ~29 minecraft:deepslate_tiles
setblock ~4 ~-60 ~30 minecraft:deepslate_tiles
fill ~5 ~-60 ~30 ~17 ~-60 ~30 minecraft:air
setblock ~18 ~-60 ~30 minecraft:deepslate_tiles
setblock ~19 ~-60 ~30 minecraft:air
setblock ~20 ~-60 ~30 minecraft:deepslate_tiles
fill ~21 ~-60 ~30 ~47 ~-60 ~30 minecraft:air
setblock ~48 ~-60 ~30 minecraft:deepslate_tiles
setblock ~49 ~-60 ~30 minecraft:air
setblock ~50 ~-60 ~30 minecraft:deepslate_tiles
fill ~51 ~-60 ~30 ~63 ~-60 ~30 minecraft:air
setblock ~64 ~-60 ~30 minecraft:deepslate_tiles
setblock ~4 ~-60 ~31 minecraft:deepslate_tiles
setblock ~5 ~-60 ~31 minecraft:air
setblock ~6 ~-60 ~31 minecraft:waxed_cut_copper
fill ~7 ~-60 ~31 ~8 ~-60 ~31 minecraft:air
setblock ~9 ~-60 ~31 minecraft:waxed_cut_copper
fill ~10 ~-60 ~31 ~14 ~-60 ~31 minecraft:air
setblock ~15 ~-60 ~31 minecraft:waxed_cut_copper
fill ~16 ~-60 ~31 ~17 ~-60 ~31 minecraft:air
setblock ~18 ~-60 ~31 minecraft:deepslate_tiles
setblock ~19 ~-60 ~31 minecraft:air
setblock ~20 ~-60 ~31 minecraft:deepslate_tiles
fill ~21 ~-60 ~31 ~47 ~-60 ~31 minecraft:air
setblock ~48 ~-60 ~31 minecraft:deepslate_tiles
setblock ~49 ~-60 ~31 minecraft:air
setblock ~50 ~-60 ~31 minecraft:deepslate_tiles
fill ~51 ~-60 ~31 ~63 ~-60 ~31 minecraft:air
setblock ~64 ~-60 ~31 minecraft:deepslate_tiles
fill ~4 ~-60 ~32 ~20 ~-60 ~32 minecraft:deepslate_tiles
fill ~21 ~-60 ~32 ~32 ~-60 ~32 minecraft:air
fill ~33 ~-60 ~32 ~35 ~-60 ~32 minecraft:waxed_cut_copper
fill ~36 ~-60 ~32 ~47 ~-60 ~32 minecraft:air
fill ~48 ~-60 ~32 ~64 ~-60 ~32 minecraft:deepslate_tiles
setblock ~4 ~-60 ~33 minecraft:deepslate_tiles
fill ~5 ~-60 ~33 ~19 ~-60 ~33 minecraft:air
setblock ~20 ~-60 ~33 minecraft:deepslate_tiles
fill ~21 ~-60 ~33 ~31 ~-60 ~33 minecraft:air
setblock ~32 ~-60 ~33 minecraft:waxed_cut_copper
fill ~33 ~-60 ~33 ~35 ~-60 ~33 minecraft:sea_lantern
setblock ~36 ~-60 ~33 minecraft:waxed_cut_copper
fill ~37 ~-60 ~33 ~47 ~-60 ~33 minecraft:air
setblock ~48 ~-60 ~33 minecraft:deepslate_tiles
fill ~49 ~-60 ~33 ~63 ~-60 ~33 minecraft:air
setblock ~64 ~-60 ~33 minecraft:deepslate_tiles
setblock ~4 ~-60 ~34 minecraft:deepslate_tiles
fill ~5 ~-60 ~34 ~18 ~-60 ~34 minecraft:waxed_cut_copper
setblock ~19 ~-60 ~34 minecraft:deepslate_tiles
fill ~20 ~-60 ~34 ~31 ~-60 ~34 minecraft:air
setblock ~32 ~-60 ~34 minecraft:waxed_cut_copper
fill ~33 ~-60 ~34 ~35 ~-60 ~34 minecraft:sea_lantern
setblock ~36 ~-60 ~34 minecraft:waxed_cut_copper
fill ~37 ~-60 ~34 ~48 ~-60 ~34 minecraft:air
setblock ~49 ~-60 ~34 minecraft:deepslate_tiles
fill ~50 ~-60 ~34 ~63 ~-60 ~34 minecraft:air
setblock ~64 ~-60 ~34 minecraft:deepslate_tiles
setblock ~4 ~-60 ~35 minecraft:deepslate_tiles
fill ~5 ~-60 ~35 ~19 ~-60 ~35 minecraft:air
setblock ~20 ~-60 ~35 minecraft:deepslate_tiles
fill ~21 ~-60 ~35 ~31 ~-60 ~35 minecraft:air
setblock ~32 ~-60 ~35 minecraft:waxed_cut_copper
fill ~33 ~-60 ~35 ~35 ~-60 ~35 minecraft:sea_lantern
setblock ~36 ~-60 ~35 minecraft:waxed_cut_copper
fill ~37 ~-60 ~35 ~47 ~-60 ~35 minecraft:air
setblock ~48 ~-60 ~35 minecraft:deepslate_tiles
fill ~49 ~-60 ~35 ~63 ~-60 ~35 minecraft:air
setblock ~64 ~-60 ~35 minecraft:deepslate_tiles
fill ~4 ~-60 ~36 ~20 ~-60 ~36 minecraft:deepslate_tiles
fill ~21 ~-60 ~36 ~32 ~-60 ~36 minecraft:air
fill ~33 ~-60 ~36 ~35 ~-60 ~36 minecraft:waxed_cut_copper
fill ~36 ~-60 ~36 ~47 ~-60 ~36 minecraft:air
fill ~48 ~-60 ~36 ~64 ~-60 ~36 minecraft:deepslate_tiles
setblock ~4 ~-60 ~37 minecraft:deepslate_tiles
setblock ~5 ~-60 ~37 minecraft:air
setblock ~6 ~-60 ~37 minecraft:waxed_cut_copper
fill ~7 ~-60 ~37 ~8 ~-60 ~37 minecraft:air
setblock ~9 ~-60 ~37 minecraft:waxed_cut_copper
fill ~10 ~-60 ~37 ~14 ~-60 ~37 minecraft:air
setblock ~15 ~-60 ~37 minecraft:waxed_cut_copper
fill ~16 ~-60 ~37 ~17 ~-60 ~37 minecraft:air
setblock ~18 ~-60 ~37 minecraft:deepslate_tiles
setblock ~19 ~-60 ~37 minecraft:air
setblock ~20 ~-60 ~37 minecraft:deepslate_tiles
fill ~21 ~-60 ~37 ~47 ~-60 ~37 minecraft:air
setblock ~48 ~-60 ~37 minecraft:deepslate_tiles
setblock ~49 ~-60 ~37 minecraft:air
setblock ~50 ~-60 ~37 minecraft:deepslate_tiles
fill ~51 ~-60 ~37 ~63 ~-60 ~37 minecraft:air
setblock ~64 ~-60 ~37 minecraft:deepslate_tiles
setblock ~4 ~-60 ~38 minecraft:deepslate_tiles
setblock ~5 ~-60 ~38 minecraft:waxed_cut_copper
fill ~6 ~-60 ~38 ~16 ~-60 ~38 minecraft:air
setblock ~17 ~-60 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~38 minecraft:deepslate_tiles
setblock ~19 ~-60 ~38 minecraft:air
setblock ~20 ~-60 ~38 minecraft:deepslate_tiles
fill ~21 ~-60 ~38 ~47 ~-60 ~38 minecraft:air
setblock ~48 ~-60 ~38 minecraft:deepslate_tiles
setblock ~49 ~-60 ~38 minecraft:air
setblock ~50 ~-60 ~38 minecraft:deepslate_tiles
fill ~51 ~-60 ~38 ~63 ~-60 ~38 minecraft:air
setblock ~64 ~-60 ~38 minecraft:deepslate_tiles
setblock ~4 ~-60 ~39 minecraft:deepslate_tiles
fill ~5 ~-60 ~39 ~17 ~-60 ~39 minecraft:air
setblock ~18 ~-60 ~39 minecraft:deepslate_tiles
setblock ~19 ~-60 ~39 minecraft:air
setblock ~20 ~-60 ~39 minecraft:deepslate_tiles
fill ~21 ~-60 ~39 ~47 ~-60 ~39 minecraft:air
setblock ~48 ~-60 ~39 minecraft:deepslate_tiles
setblock ~49 ~-60 ~39 minecraft:air
setblock ~50 ~-60 ~39 minecraft:deepslate_tiles
fill ~51 ~-60 ~39 ~63 ~-60 ~39 minecraft:air
setblock ~64 ~-60 ~39 minecraft:deepslate_tiles
setblock ~4 ~-60 ~40 minecraft:deepslate_tiles
fill ~5 ~-60 ~40 ~17 ~-60 ~40 minecraft:air
setblock ~18 ~-60 ~40 minecraft:deepslate_tiles
fill ~19 ~-60 ~40 ~20 ~-60 ~40 minecraft:air
setblock ~21 ~-60 ~40 minecraft:deepslate_tiles
fill ~22 ~-60 ~40 ~46 ~-60 ~40 minecraft:air
setblock ~47 ~-60 ~40 minecraft:deepslate_tiles
fill ~48 ~-60 ~40 ~49 ~-60 ~40 minecraft:air
setblock ~50 ~-60 ~40 minecraft:deepslate_tiles
fill ~51 ~-60 ~40 ~63 ~-60 ~40 minecraft:air
setblock ~64 ~-60 ~40 minecraft:deepslate_tiles
setblock ~4 ~-60 ~41 minecraft:deepslate_tiles
setblock ~5 ~-60 ~41 minecraft:waxed_cut_copper
fill ~6 ~-60 ~41 ~16 ~-60 ~41 minecraft:air
setblock ~17 ~-60 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~41 minecraft:deepslate_tiles
fill ~19 ~-60 ~41 ~20 ~-60 ~41 minecraft:air
setblock ~21 ~-60 ~41 minecraft:deepslate_tiles
fill ~22 ~-60 ~41 ~46 ~-60 ~41 minecraft:air
setblock ~47 ~-60 ~41 minecraft:deepslate_tiles
fill ~48 ~-60 ~41 ~49 ~-60 ~41 minecraft:air
setblock ~50 ~-60 ~41 minecraft:deepslate_tiles
fill ~51 ~-60 ~41 ~63 ~-60 ~41 minecraft:air
setblock ~64 ~-60 ~41 minecraft:deepslate_tiles
setblock ~4 ~-60 ~42 minecraft:deepslate_tiles
fill ~5 ~-60 ~42 ~17 ~-60 ~42 minecraft:air
setblock ~18 ~-60 ~42 minecraft:deepslate_tiles
fill ~19 ~-60 ~42 ~21 ~-60 ~42 minecraft:air
setblock ~22 ~-60 ~42 minecraft:deepslate_tiles
fill ~23 ~-60 ~42 ~25 ~-60 ~42 minecraft:air
setblock ~26 ~-60 ~42 minecraft:waxed_cut_copper
fill ~27 ~-60 ~42 ~41 ~-60 ~42 minecraft:air
setblock ~42 ~-60 ~42 minecraft:waxed_cut_copper
fill ~43 ~-60 ~42 ~45 ~-60 ~42 minecraft:air
setblock ~46 ~-60 ~42 minecraft:deepslate_tiles
fill ~47 ~-60 ~42 ~49 ~-60 ~42 minecraft:air
setblock ~50 ~-60 ~42 minecraft:deepslate_tiles
fill ~51 ~-60 ~42 ~63 ~-60 ~42 minecraft:air
setblock ~64 ~-60 ~42 minecraft:deepslate_tiles
setblock ~4 ~-60 ~43 minecraft:deepslate_tiles
fill ~5 ~-60 ~43 ~17 ~-60 ~43 minecraft:air
setblock ~18 ~-60 ~43 minecraft:deepslate_tiles
fill ~19 ~-60 ~43 ~21 ~-60 ~43 minecraft:air
fill ~22 ~-60 ~43 ~23 ~-60 ~43 minecraft:deepslate_tiles
fill ~24 ~-60 ~43 ~44 ~-60 ~43 minecraft:air
fill ~45 ~-60 ~43 ~46 ~-60 ~43 minecraft:deepslate_tiles
fill ~47 ~-60 ~43 ~49 ~-60 ~43 minecraft:air
setblock ~50 ~-60 ~43 minecraft:deepslate_tiles
fill ~51 ~-60 ~43 ~63 ~-60 ~43 minecraft:air
setblock ~64 ~-60 ~43 minecraft:deepslate_tiles
setblock ~4 ~-60 ~44 minecraft:deepslate_tiles
setblock ~5 ~-60 ~44 minecraft:waxed_cut_copper
fill ~6 ~-60 ~44 ~16 ~-60 ~44 minecraft:air
setblock ~17 ~-60 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~44 minecraft:deepslate_tiles
fill ~19 ~-60 ~44 ~22 ~-60 ~44 minecraft:air
fill ~23 ~-60 ~44 ~24 ~-60 ~44 minecraft:deepslate_tiles
fill ~25 ~-60 ~44 ~43 ~-60 ~44 minecraft:air
fill ~44 ~-60 ~44 ~45 ~-60 ~44 minecraft:deepslate_tiles
fill ~46 ~-60 ~44 ~49 ~-60 ~44 minecraft:air
setblock ~50 ~-60 ~44 minecraft:deepslate_tiles
fill ~51 ~-60 ~44 ~63 ~-60 ~44 minecraft:air
setblock ~64 ~-60 ~44 minecraft:deepslate_tiles
setblock ~4 ~-60 ~45 minecraft:deepslate_tiles
fill ~5 ~-60 ~45 ~17 ~-60 ~45 minecraft:air
setblock ~18 ~-60 ~45 minecraft:deepslate_tiles
fill ~19 ~-60 ~45 ~23 ~-60 ~45 minecraft:air
fill ~24 ~-60 ~45 ~25 ~-60 ~45 minecraft:deepslate_tiles
fill ~26 ~-60 ~45 ~42 ~-60 ~45 minecraft:air
fill ~43 ~-60 ~45 ~44 ~-60 ~45 minecraft:deepslate_tiles
fill ~45 ~-60 ~45 ~49 ~-60 ~45 minecraft:air
setblock ~50 ~-60 ~45 minecraft:deepslate_tiles
fill ~51 ~-60 ~45 ~63 ~-60 ~45 minecraft:air
setblock ~64 ~-60 ~45 minecraft:deepslate_tiles
setblock ~4 ~-60 ~46 minecraft:deepslate_tiles
fill ~5 ~-60 ~46 ~17 ~-60 ~46 minecraft:air
setblock ~18 ~-60 ~46 minecraft:deepslate_tiles
fill ~19 ~-60 ~46 ~24 ~-60 ~46 minecraft:air
fill ~25 ~-60 ~46 ~26 ~-60 ~46 minecraft:deepslate_tiles
fill ~27 ~-60 ~46 ~41 ~-60 ~46 minecraft:air
fill ~42 ~-60 ~46 ~43 ~-60 ~46 minecraft:deepslate_tiles
fill ~44 ~-60 ~46 ~49 ~-60 ~46 minecraft:air
setblock ~50 ~-60 ~46 minecraft:deepslate_tiles
fill ~51 ~-60 ~46 ~63 ~-60 ~46 minecraft:air
setblock ~64 ~-60 ~46 minecraft:deepslate_tiles
setblock ~4 ~-60 ~47 minecraft:deepslate_tiles
setblock ~5 ~-60 ~47 minecraft:waxed_cut_copper
fill ~6 ~-60 ~47 ~16 ~-60 ~47 minecraft:air
setblock ~17 ~-60 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~47 minecraft:deepslate_tiles
fill ~19 ~-60 ~47 ~26 ~-60 ~47 minecraft:air
fill ~27 ~-60 ~47 ~28 ~-60 ~47 minecraft:deepslate_tiles
fill ~29 ~-60 ~47 ~39 ~-60 ~47 minecraft:air
fill ~40 ~-60 ~47 ~41 ~-60 ~47 minecraft:deepslate_tiles
fill ~42 ~-60 ~47 ~49 ~-60 ~47 minecraft:air
setblock ~50 ~-60 ~47 minecraft:deepslate_tiles
fill ~51 ~-60 ~47 ~63 ~-60 ~47 minecraft:air
setblock ~64 ~-60 ~47 minecraft:deepslate_tiles
setblock ~4 ~-60 ~48 minecraft:deepslate_tiles
fill ~5 ~-60 ~48 ~17 ~-60 ~48 minecraft:air
setblock ~18 ~-60 ~48 minecraft:deepslate_tiles
fill ~19 ~-60 ~48 ~28 ~-60 ~48 minecraft:air
fill ~29 ~-60 ~48 ~33 ~-60 ~48 minecraft:deepslate_tiles
setblock ~34 ~-60 ~48 minecraft:air
fill ~35 ~-60 ~48 ~39 ~-60 ~48 minecraft:deepslate_tiles
fill ~40 ~-60 ~48 ~49 ~-60 ~48 minecraft:air
setblock ~50 ~-60 ~48 minecraft:deepslate_tiles
fill ~51 ~-60 ~48 ~63 ~-60 ~48 minecraft:air
setblock ~64 ~-60 ~48 minecraft:deepslate_tiles
setblock ~4 ~-60 ~49 minecraft:deepslate_tiles
setblock ~5 ~-60 ~49 minecraft:air
setblock ~6 ~-60 ~49 minecraft:waxed_cut_copper
fill ~7 ~-60 ~49 ~8 ~-60 ~49 minecraft:air
setblock ~9 ~-60 ~49 minecraft:waxed_cut_copper
fill ~10 ~-60 ~49 ~14 ~-60 ~49 minecraft:air
setblock ~15 ~-60 ~49 minecraft:waxed_cut_copper
fill ~16 ~-60 ~49 ~17 ~-60 ~49 minecraft:air
setblock ~18 ~-60 ~49 minecraft:deepslate_tiles
fill ~19 ~-60 ~49 ~31 ~-60 ~49 minecraft:air
setblock ~32 ~-60 ~49 minecraft:deepslate_tiles
setblock ~33 ~-60 ~49 minecraft:air
setblock ~34 ~-60 ~49 minecraft:deepslate_tiles
setblock ~35 ~-60 ~49 minecraft:air
setblock ~36 ~-60 ~49 minecraft:deepslate_tiles
fill ~37 ~-60 ~49 ~49 ~-60 ~49 minecraft:air
setblock ~50 ~-60 ~49 minecraft:deepslate_tiles
fill ~51 ~-60 ~49 ~63 ~-60 ~49 minecraft:air
setblock ~64 ~-60 ~49 minecraft:deepslate_tiles
fill ~4 ~-60 ~50 ~32 ~-60 ~50 minecraft:deepslate_tiles
fill ~33 ~-60 ~50 ~35 ~-60 ~50 minecraft:air
fill ~36 ~-60 ~50 ~64 ~-60 ~50 minecraft:deepslate_tiles
setblock ~4 ~-60 ~51 minecraft:deepslate_tiles
fill ~5 ~-60 ~51 ~9 ~-60 ~51 minecraft:waxed_cut_copper
fill ~10 ~-60 ~51 ~12 ~-60 ~51 minecraft:air
fill ~13 ~-60 ~51 ~17 ~-60 ~51 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~51 minecraft:deepslate_tiles
fill ~19 ~-60 ~51 ~31 ~-60 ~51 minecraft:air
setblock ~32 ~-60 ~51 minecraft:deepslate_tiles
fill ~33 ~-60 ~51 ~35 ~-60 ~51 minecraft:air
setblock ~36 ~-60 ~51 minecraft:deepslate_tiles
fill ~37 ~-60 ~51 ~49 ~-60 ~51 minecraft:air
setblock ~50 ~-60 ~51 minecraft:deepslate_tiles
setblock ~51 ~-60 ~51 minecraft:waxed_cut_copper
fill ~52 ~-60 ~51 ~53 ~-60 ~51 minecraft:air
setblock ~54 ~-60 ~51 minecraft:waxed_cut_copper
fill ~55 ~-60 ~51 ~59 ~-60 ~51 minecraft:air
setblock ~60 ~-60 ~51 minecraft:waxed_cut_copper
fill ~61 ~-60 ~51 ~62 ~-60 ~51 minecraft:air
setblock ~63 ~-60 ~51 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~51 minecraft:deepslate_tiles
setblock ~4 ~-60 ~52 minecraft:deepslate_tiles
setblock ~5 ~-60 ~52 minecraft:waxed_cut_copper
fill ~6 ~-60 ~52 ~16 ~-60 ~52 minecraft:air
setblock ~17 ~-60 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~52 minecraft:deepslate_tiles
fill ~19 ~-60 ~52 ~31 ~-60 ~52 minecraft:air
setblock ~32 ~-60 ~52 minecraft:deepslate_tiles
fill ~33 ~-60 ~52 ~35 ~-60 ~52 minecraft:air
setblock ~36 ~-60 ~52 minecraft:deepslate_tiles
fill ~37 ~-60 ~52 ~49 ~-60 ~52 minecraft:air
setblock ~50 ~-60 ~52 minecraft:deepslate_tiles
fill ~51 ~-60 ~52 ~63 ~-60 ~52 minecraft:air
setblock ~64 ~-60 ~52 minecraft:deepslate_tiles
setblock ~4 ~-60 ~53 minecraft:deepslate_tiles
setblock ~5 ~-60 ~53 minecraft:waxed_cut_copper
fill ~6 ~-60 ~53 ~16 ~-60 ~53 minecraft:air
setblock ~17 ~-60 ~53 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~53 minecraft:deepslate_tiles
fill ~19 ~-60 ~53 ~31 ~-60 ~53 minecraft:air
setblock ~32 ~-60 ~53 minecraft:deepslate_tiles
fill ~33 ~-60 ~53 ~35 ~-60 ~53 minecraft:air
setblock ~36 ~-60 ~53 minecraft:deepslate_tiles
fill ~37 ~-60 ~53 ~49 ~-60 ~53 minecraft:air
setblock ~50 ~-60 ~53 minecraft:deepslate_tiles
fill ~51 ~-60 ~53 ~63 ~-60 ~53 minecraft:air
setblock ~64 ~-60 ~53 minecraft:deepslate_tiles
setblock ~4 ~-60 ~54 minecraft:deepslate_tiles
setblock ~5 ~-60 ~54 minecraft:waxed_cut_copper
fill ~6 ~-60 ~54 ~16 ~-60 ~54 minecraft:air
setblock ~17 ~-60 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~54 minecraft:deepslate_tiles
fill ~19 ~-60 ~54 ~31 ~-60 ~54 minecraft:air
setblock ~32 ~-60 ~54 minecraft:deepslate_tiles
fill ~33 ~-60 ~54 ~35 ~-60 ~54 minecraft:air
setblock ~36 ~-60 ~54 minecraft:deepslate_tiles
fill ~37 ~-60 ~54 ~49 ~-60 ~54 minecraft:air
setblock ~50 ~-60 ~54 minecraft:deepslate_tiles
setblock ~51 ~-60 ~54 minecraft:waxed_cut_copper
fill ~52 ~-60 ~54 ~62 ~-60 ~54 minecraft:air
setblock ~63 ~-60 ~54 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~54 minecraft:deepslate_tiles
setblock ~4 ~-60 ~55 minecraft:deepslate_tiles
setblock ~5 ~-60 ~55 minecraft:waxed_cut_copper
fill ~6 ~-60 ~55 ~16 ~-60 ~55 minecraft:air
setblock ~17 ~-60 ~55 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~55 minecraft:deepslate_tiles
fill ~19 ~-60 ~55 ~31 ~-60 ~55 minecraft:air
setblock ~32 ~-60 ~55 minecraft:deepslate_tiles
fill ~33 ~-60 ~55 ~35 ~-60 ~55 minecraft:air
setblock ~36 ~-60 ~55 minecraft:deepslate_tiles
fill ~37 ~-60 ~55 ~49 ~-60 ~55 minecraft:air
setblock ~50 ~-60 ~55 minecraft:deepslate_tiles
fill ~51 ~-60 ~55 ~63 ~-60 ~55 minecraft:air
setblock ~64 ~-60 ~55 minecraft:deepslate_tiles
setblock ~4 ~-60 ~56 minecraft:deepslate_tiles
setblock ~5 ~-60 ~56 minecraft:waxed_cut_copper
fill ~6 ~-60 ~56 ~17 ~-60 ~56 minecraft:air
setblock ~18 ~-60 ~56 minecraft:deepslate_tiles
fill ~19 ~-60 ~56 ~31 ~-60 ~56 minecraft:air
setblock ~32 ~-60 ~56 minecraft:deepslate_tiles
fill ~33 ~-60 ~56 ~35 ~-60 ~56 minecraft:air
setblock ~36 ~-60 ~56 minecraft:deepslate_tiles
fill ~37 ~-60 ~56 ~49 ~-60 ~56 minecraft:air
setblock ~50 ~-60 ~56 minecraft:deepslate_tiles
fill ~51 ~-60 ~56 ~63 ~-60 ~56 minecraft:air
setblock ~64 ~-60 ~56 minecraft:deepslate_tiles
setblock ~4 ~-60 ~57 minecraft:deepslate_tiles
setblock ~5 ~-60 ~57 minecraft:waxed_cut_copper
fill ~6 ~-60 ~57 ~17 ~-60 ~57 minecraft:air
setblock ~18 ~-60 ~57 minecraft:deepslate_tiles
fill ~19 ~-60 ~57 ~31 ~-60 ~57 minecraft:air
setblock ~32 ~-60 ~57 minecraft:deepslate_tiles
fill ~33 ~-60 ~57 ~35 ~-60 ~57 minecraft:air
setblock ~36 ~-60 ~57 minecraft:deepslate_tiles
fill ~37 ~-60 ~57 ~49 ~-60 ~57 minecraft:air
setblock ~50 ~-60 ~57 minecraft:deepslate_tiles
fill ~51 ~-60 ~57 ~62 ~-60 ~57 minecraft:air
setblock ~63 ~-60 ~57 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~57 minecraft:deepslate_tiles
setblock ~4 ~-60 ~58 minecraft:deepslate_tiles
setblock ~5 ~-60 ~58 minecraft:waxed_cut_copper
fill ~6 ~-60 ~58 ~17 ~-60 ~58 minecraft:air
setblock ~18 ~-60 ~58 minecraft:deepslate_tiles
fill ~19 ~-60 ~58 ~31 ~-60 ~58 minecraft:air
setblock ~32 ~-60 ~58 minecraft:deepslate_tiles
fill ~33 ~-60 ~58 ~35 ~-60 ~58 minecraft:air
setblock ~36 ~-60 ~58 minecraft:deepslate_tiles
fill ~37 ~-60 ~58 ~49 ~-60 ~58 minecraft:air
setblock ~50 ~-60 ~58 minecraft:deepslate_tiles
fill ~51 ~-60 ~58 ~63 ~-60 ~58 minecraft:air
setblock ~64 ~-60 ~58 minecraft:deepslate_tiles
setblock ~4 ~-60 ~59 minecraft:deepslate_tiles
setblock ~5 ~-60 ~59 minecraft:waxed_cut_copper
fill ~6 ~-60 ~59 ~16 ~-60 ~59 minecraft:air
setblock ~17 ~-60 ~59 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~59 minecraft:deepslate_tiles
fill ~19 ~-60 ~59 ~31 ~-60 ~59 minecraft:air
setblock ~32 ~-60 ~59 minecraft:deepslate_tiles
fill ~33 ~-60 ~59 ~35 ~-60 ~59 minecraft:air
setblock ~36 ~-60 ~59 minecraft:deepslate_tiles
fill ~37 ~-60 ~59 ~49 ~-60 ~59 minecraft:air
setblock ~50 ~-60 ~59 minecraft:deepslate_tiles
fill ~51 ~-60 ~59 ~63 ~-60 ~59 minecraft:air
setblock ~64 ~-60 ~59 minecraft:deepslate_tiles
setblock ~4 ~-60 ~60 minecraft:deepslate_tiles
setblock ~5 ~-60 ~60 minecraft:waxed_cut_copper
fill ~6 ~-60 ~60 ~16 ~-60 ~60 minecraft:air
setblock ~17 ~-60 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~60 minecraft:deepslate_tiles
fill ~19 ~-60 ~60 ~31 ~-60 ~60 minecraft:air
setblock ~32 ~-60 ~60 minecraft:deepslate_tiles
fill ~33 ~-60 ~60 ~35 ~-60 ~60 minecraft:air
setblock ~36 ~-60 ~60 minecraft:deepslate_tiles
fill ~37 ~-60 ~60 ~49 ~-60 ~60 minecraft:air
setblock ~50 ~-60 ~60 minecraft:deepslate_tiles
setblock ~51 ~-60 ~60 minecraft:waxed_cut_copper
fill ~52 ~-60 ~60 ~62 ~-60 ~60 minecraft:air
setblock ~63 ~-60 ~60 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~60 minecraft:deepslate_tiles
setblock ~4 ~-60 ~61 minecraft:deepslate_tiles
setblock ~5 ~-60 ~61 minecraft:waxed_cut_copper
fill ~6 ~-60 ~61 ~16 ~-60 ~61 minecraft:air
setblock ~17 ~-60 ~61 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~61 minecraft:deepslate_tiles
fill ~19 ~-60 ~61 ~31 ~-60 ~61 minecraft:air
setblock ~32 ~-60 ~61 minecraft:deepslate_tiles
fill ~33 ~-60 ~61 ~35 ~-60 ~61 minecraft:air
setblock ~36 ~-60 ~61 minecraft:deepslate_tiles
fill ~37 ~-60 ~61 ~49 ~-60 ~61 minecraft:air
setblock ~50 ~-60 ~61 minecraft:deepslate_tiles
fill ~51 ~-60 ~61 ~63 ~-60 ~61 minecraft:air
setblock ~64 ~-60 ~61 minecraft:deepslate_tiles
setblock ~4 ~-60 ~62 minecraft:deepslate_tiles
setblock ~5 ~-60 ~62 minecraft:waxed_cut_copper
fill ~6 ~-60 ~62 ~16 ~-60 ~62 minecraft:air
setblock ~17 ~-60 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~62 minecraft:deepslate_tiles
fill ~19 ~-60 ~62 ~31 ~-60 ~62 minecraft:air
setblock ~32 ~-60 ~62 minecraft:deepslate_tiles
fill ~33 ~-60 ~62 ~35 ~-60 ~62 minecraft:air
setblock ~36 ~-60 ~62 minecraft:deepslate_tiles
fill ~37 ~-60 ~62 ~49 ~-60 ~62 minecraft:air
setblock ~50 ~-60 ~62 minecraft:deepslate_tiles
fill ~51 ~-60 ~62 ~63 ~-60 ~62 minecraft:air
setblock ~64 ~-60 ~62 minecraft:deepslate_tiles
setblock ~4 ~-60 ~63 minecraft:deepslate_tiles
fill ~5 ~-60 ~63 ~17 ~-60 ~63 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~63 minecraft:deepslate_tiles
fill ~19 ~-60 ~63 ~31 ~-60 ~63 minecraft:air
setblock ~32 ~-60 ~63 minecraft:deepslate_tiles
fill ~33 ~-60 ~63 ~35 ~-60 ~63 minecraft:air
setblock ~36 ~-60 ~63 minecraft:deepslate_tiles
fill ~37 ~-60 ~63 ~49 ~-60 ~63 minecraft:air
setblock ~50 ~-60 ~63 minecraft:deepslate_tiles
setblock ~51 ~-60 ~63 minecraft:waxed_cut_copper
fill ~52 ~-60 ~63 ~53 ~-60 ~63 minecraft:air
setblock ~54 ~-60 ~63 minecraft:waxed_cut_copper
fill ~55 ~-60 ~63 ~56 ~-60 ~63 minecraft:air
setblock ~57 ~-60 ~63 minecraft:waxed_cut_copper
fill ~58 ~-60 ~63 ~59 ~-60 ~63 minecraft:air
setblock ~60 ~-60 ~63 minecraft:waxed_cut_copper
fill ~61 ~-60 ~63 ~62 ~-60 ~63 minecraft:air
setblock ~63 ~-60 ~63 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~63 minecraft:deepslate_tiles
fill ~4 ~-60 ~64 ~64 ~-60 ~64 minecraft:deepslate_tiles
fill ~32 ~-60 ~66 ~36 ~-60 ~66 minecraft:polished_andesite
setblock ~32 ~-60 ~67 minecraft:polished_andesite
setblock ~33 ~-60 ~67 minecraft:air
setblock ~34 ~-60 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-60 ~67 minecraft:air
setblock ~36 ~-60 ~67 minecraft:polished_andesite
setblock ~32 ~-60 ~68 minecraft:polished_andesite
setblock ~33 ~-60 ~68 minecraft:air
setblock ~34 ~-60 ~68 minecraft:quartz_pillar
setblock ~35 ~-60 ~68 minecraft:air
setblock ~36 ~-60 ~68 minecraft:polished_andesite
setblock ~32 ~-60 ~69 minecraft:polished_andesite
fill ~33 ~-60 ~69 ~35 ~-60 ~69 minecraft:air
setblock ~36 ~-60 ~69 minecraft:polished_andesite
fill ~32 ~-60 ~70 ~36 ~-60 ~70 minecraft:polished_andesite
fill ~4 ~-59 ~4 ~64 ~-59 ~4 minecraft:polished_deepslate
fill ~4 ~-59 ~5 ~64 ~-59 ~5 minecraft:polished_deepslate
fill ~4 ~-59 ~6 ~5 ~-59 ~6 minecraft:polished_deepslate
setblock ~6 ~-59 ~6 minecraft:sea_lantern
fill ~7 ~-59 ~6 ~9 ~-59 ~6 minecraft:polished_deepslate
setblock ~10 ~-59 ~6 minecraft:sea_lantern
fill ~11 ~-59 ~6 ~13 ~-59 ~6 minecraft:polished_deepslate
setblock ~14 ~-59 ~6 minecraft:sea_lantern
fill ~15 ~-59 ~6 ~21 ~-59 ~6 minecraft:polished_deepslate
setblock ~22 ~-59 ~6 minecraft:sea_lantern
fill ~23 ~-59 ~6 ~25 ~-59 ~6 minecraft:polished_deepslate
setblock ~26 ~-59 ~6 minecraft:sea_lantern
fill ~27 ~-59 ~6 ~29 ~-59 ~6 minecraft:polished_deepslate
setblock ~30 ~-59 ~6 minecraft:sea_lantern
fill ~31 ~-59 ~6 ~33 ~-59 ~6 minecraft:polished_deepslate
setblock ~34 ~-59 ~6 minecraft:sea_lantern
fill ~35 ~-59 ~6 ~37 ~-59 ~6 minecraft:polished_deepslate
setblock ~38 ~-59 ~6 minecraft:sea_lantern
fill ~39 ~-59 ~6 ~41 ~-59 ~6 minecraft:polished_deepslate
setblock ~42 ~-59 ~6 minecraft:sea_lantern
fill ~43 ~-59 ~6 ~45 ~-59 ~6 minecraft:polished_deepslate
setblock ~46 ~-59 ~6 minecraft:sea_lantern
fill ~47 ~-59 ~6 ~53 ~-59 ~6 minecraft:polished_deepslate
setblock ~54 ~-59 ~6 minecraft:sea_lantern
fill ~55 ~-59 ~6 ~57 ~-59 ~6 minecraft:polished_deepslate
setblock ~58 ~-59 ~6 minecraft:sea_lantern
fill ~59 ~-59 ~6 ~61 ~-59 ~6 minecraft:polished_deepslate
setblock ~62 ~-59 ~6 minecraft:sea_lantern
fill ~63 ~-59 ~6 ~64 ~-59 ~6 minecraft:polished_deepslate
fill ~4 ~-59 ~7 ~64 ~-59 ~7 minecraft:polished_deepslate
fill ~4 ~-59 ~8 ~64 ~-59 ~8 minecraft:polished_deepslate
fill ~4 ~-59 ~9 ~64 ~-59 ~9 minecraft:polished_deepslate
fill ~4 ~-59 ~10 ~5 ~-59 ~10 minecraft:polished_deepslate
setblock ~6 ~-59 ~10 minecraft:sea_lantern
fill ~7 ~-59 ~10 ~9 ~-59 ~10 minecraft:polished_deepslate
setblock ~10 ~-59 ~10 minecraft:sea_lantern
fill ~11 ~-59 ~10 ~13 ~-59 ~10 minecraft:polished_deepslate
setblock ~14 ~-59 ~10 minecraft:sea_lantern
fill ~15 ~-59 ~10 ~21 ~-59 ~10 minecraft:polished_deepslate
setblock ~22 ~-59 ~10 minecraft:sea_lantern
fill ~23 ~-59 ~10 ~25 ~-59 ~10 minecraft:polished_deepslate
setblock ~26 ~-59 ~10 minecraft:sea_lantern
fill ~27 ~-59 ~10 ~29 ~-59 ~10 minecraft:polished_deepslate
setblock ~30 ~-59 ~10 minecraft:sea_lantern
fill ~31 ~-59 ~10 ~33 ~-59 ~10 minecraft:polished_deepslate
setblock ~34 ~-59 ~10 minecraft:sea_lantern
fill ~35 ~-59 ~10 ~37 ~-59 ~10 minecraft:polished_deepslate
setblock ~38 ~-59 ~10 minecraft:sea_lantern
fill ~39 ~-59 ~10 ~41 ~-59 ~10 minecraft:polished_deepslate
setblock ~42 ~-59 ~10 minecraft:sea_lantern
fill ~43 ~-59 ~10 ~45 ~-59 ~10 minecraft:polished_deepslate
setblock ~46 ~-59 ~10 minecraft:sea_lantern
fill ~47 ~-59 ~10 ~53 ~-59 ~10 minecraft:polished_deepslate
setblock ~54 ~-59 ~10 minecraft:sea_lantern
fill ~55 ~-59 ~10 ~57 ~-59 ~10 minecraft:polished_deepslate
setblock ~58 ~-59 ~10 minecraft:sea_lantern
fill ~59 ~-59 ~10 ~61 ~-59 ~10 minecraft:polished_deepslate
setblock ~62 ~-59 ~10 minecraft:sea_lantern
fill ~63 ~-59 ~10 ~64 ~-59 ~10 minecraft:polished_deepslate
fill ~4 ~-59 ~11 ~64 ~-59 ~11 minecraft:polished_deepslate
fill ~4 ~-59 ~12 ~64 ~-59 ~12 minecraft:polished_deepslate
fill ~4 ~-59 ~13 ~64 ~-59 ~13 minecraft:polished_deepslate
fill ~4 ~-59 ~14 ~5 ~-59 ~14 minecraft:polished_deepslate
setblock ~6 ~-59 ~14 minecraft:sea_lantern
fill ~7 ~-59 ~14 ~9 ~-59 ~14 minecraft:polished_deepslate
setblock ~10 ~-59 ~14 minecraft:sea_lantern
fill ~11 ~-59 ~14 ~13 ~-59 ~14 minecraft:polished_deepslate
setblock ~14 ~-59 ~14 minecraft:sea_lantern
fill ~15 ~-59 ~14 ~21 ~-59 ~14 minecraft:polished_deepslate
setblock ~22 ~-59 ~14 minecraft:sea_lantern
fill ~23 ~-59 ~14 ~25 ~-59 ~14 minecraft:polished_deepslate
setblock ~26 ~-59 ~14 minecraft:sea_lantern
fill ~27 ~-59 ~14 ~29 ~-59 ~14 minecraft:polished_deepslate
setblock ~30 ~-59 ~14 minecraft:sea_lantern
fill ~31 ~-59 ~14 ~33 ~-59 ~14 minecraft:polished_deepslate
setblock ~34 ~-59 ~14 minecraft:sea_lantern
fill ~35 ~-59 ~14 ~37 ~-59 ~14 minecraft:polished_deepslate
setblock ~38 ~-59 ~14 minecraft:sea_lantern
fill ~39 ~-59 ~14 ~41 ~-59 ~14 minecraft:polished_deepslate
setblock ~42 ~-59 ~14 minecraft:sea_lantern
fill ~43 ~-59 ~14 ~45 ~-59 ~14 minecraft:polished_deepslate
setblock ~46 ~-59 ~14 minecraft:sea_lantern
fill ~47 ~-59 ~14 ~53 ~-59 ~14 minecraft:polished_deepslate
setblock ~54 ~-59 ~14 minecraft:sea_lantern
fill ~55 ~-59 ~14 ~57 ~-59 ~14 minecraft:polished_deepslate
setblock ~58 ~-59 ~14 minecraft:sea_lantern
fill ~59 ~-59 ~14 ~61 ~-59 ~14 minecraft:polished_deepslate
setblock ~62 ~-59 ~14 minecraft:sea_lantern
fill ~63 ~-59 ~14 ~64 ~-59 ~14 minecraft:polished_deepslate
fill ~4 ~-59 ~15 ~64 ~-59 ~15 minecraft:polished_deepslate
fill ~4 ~-59 ~16 ~64 ~-59 ~16 minecraft:polished_deepslate
fill ~4 ~-59 ~17 ~64 ~-59 ~17 minecraft:polished_deepslate
fill ~4 ~-59 ~18 ~33 ~-59 ~18 minecraft:polished_deepslate
setblock ~34 ~-59 ~18 minecraft:sea_lantern
fill ~35 ~-59 ~18 ~64 ~-59 ~18 minecraft:polished_deepslate
fill ~4 ~-59 ~19 ~64 ~-59 ~19 minecraft:polished_deepslate
fill ~4 ~-59 ~20 ~64 ~-59 ~20 minecraft:polished_deepslate
fill ~4 ~-59 ~21 ~64 ~-59 ~21 minecraft:polished_deepslate
fill ~4 ~-59 ~22 ~5 ~-59 ~22 minecraft:polished_deepslate
setblock ~6 ~-59 ~22 minecraft:sea_lantern
fill ~7 ~-59 ~22 ~9 ~-59 ~22 minecraft:polished_deepslate
setblock ~10 ~-59 ~22 minecraft:sea_lantern
fill ~11 ~-59 ~22 ~13 ~-59 ~22 minecraft:polished_deepslate
setblock ~14 ~-59 ~22 minecraft:sea_lantern
fill ~15 ~-59 ~22 ~21 ~-59 ~22 minecraft:polished_deepslate
setblock ~22 ~-59 ~22 minecraft:sea_lantern
fill ~23 ~-59 ~22 ~29 ~-59 ~22 minecraft:polished_deepslate
setblock ~30 ~-59 ~22 minecraft:sea_lantern
fill ~31 ~-59 ~22 ~33 ~-59 ~22 minecraft:polished_deepslate
setblock ~34 ~-59 ~22 minecraft:sea_lantern
fill ~35 ~-59 ~22 ~37 ~-59 ~22 minecraft:polished_deepslate
setblock ~38 ~-59 ~22 minecraft:sea_lantern
fill ~39 ~-59 ~22 ~45 ~-59 ~22 minecraft:polished_deepslate
setblock ~46 ~-59 ~22 minecraft:sea_lantern
fill ~47 ~-59 ~22 ~53 ~-59 ~22 minecraft:polished_deepslate
setblock ~54 ~-59 ~22 minecraft:sea_lantern
fill ~55 ~-59 ~22 ~57 ~-59 ~22 minecraft:polished_deepslate
setblock ~58 ~-59 ~22 minecraft:sea_lantern
fill ~59 ~-59 ~22 ~61 ~-59 ~22 minecraft:polished_deepslate
setblock ~62 ~-59 ~22 minecraft:sea_lantern
fill ~63 ~-59 ~22 ~64 ~-59 ~22 minecraft:polished_deepslate
fill ~4 ~-59 ~23 ~64 ~-59 ~23 minecraft:polished_deepslate
fill ~4 ~-59 ~24 ~64 ~-59 ~24 minecraft:polished_deepslate
fill ~4 ~-59 ~25 ~64 ~-59 ~25 minecraft:polished_deepslate
fill ~4 ~-59 ~26 ~5 ~-59 ~26 minecraft:polished_deepslate
setblock ~6 ~-59 ~26 minecraft:sea_lantern
fill ~7 ~-59 ~26 ~9 ~-59 ~26 minecraft:polished_deepslate
setblock ~10 ~-59 ~26 minecraft:sea_lantern
fill ~11 ~-59 ~26 ~13 ~-59 ~26 minecraft:polished_deepslate
setblock ~14 ~-59 ~26 minecraft:sea_lantern
fill ~15 ~-59 ~26 ~25 ~-59 ~26 minecraft:polished_deepslate
setblock ~26 ~-59 ~26 minecraft:sea_lantern
fill ~27 ~-59 ~26 ~29 ~-59 ~26 minecraft:polished_deepslate
setblock ~30 ~-59 ~26 minecraft:sea_lantern
setblock ~31 ~-59 ~26 minecraft:polished_deepslate
fill ~32 ~-59 ~26 ~36 ~-59 ~26 minecraft:air
setblock ~37 ~-59 ~26 minecraft:polished_deepslate
setblock ~38 ~-59 ~26 minecraft:sea_lantern
fill ~39 ~-59 ~26 ~41 ~-59 ~26 minecraft:polished_deepslate
setblock ~42 ~-59 ~26 minecraft:sea_lantern
fill ~43 ~-59 ~26 ~53 ~-59 ~26 minecraft:polished_deepslate
setblock ~54 ~-59 ~26 minecraft:sea_lantern
fill ~55 ~-59 ~26 ~57 ~-59 ~26 minecraft:polished_deepslate
setblock ~58 ~-59 ~26 minecraft:sea_lantern
fill ~59 ~-59 ~26 ~61 ~-59 ~26 minecraft:polished_deepslate
setblock ~62 ~-59 ~26 minecraft:sea_lantern
fill ~63 ~-59 ~26 ~64 ~-59 ~26 minecraft:polished_deepslate
fill ~4 ~-59 ~27 ~29 ~-59 ~27 minecraft:polished_deepslate
fill ~30 ~-59 ~27 ~38 ~-59 ~27 minecraft:air
fill ~39 ~-59 ~27 ~64 ~-59 ~27 minecraft:polished_deepslate
fill ~4 ~-59 ~28 ~27 ~-59 ~28 minecraft:polished_deepslate
fill ~28 ~-59 ~28 ~40 ~-59 ~28 minecraft:air
fill ~41 ~-59 ~28 ~64 ~-59 ~28 minecraft:polished_deepslate
fill ~4 ~-59 ~29 ~27 ~-59 ~29 minecraft:polished_deepslate
fill ~28 ~-59 ~29 ~40 ~-59 ~29 minecraft:air
fill ~41 ~-59 ~29 ~64 ~-59 ~29 minecraft:polished_deepslate
fill ~4 ~-59 ~30 ~5 ~-59 ~30 minecraft:polished_deepslate
setblock ~6 ~-59 ~30 minecraft:sea_lantern
fill ~7 ~-59 ~30 ~9 ~-59 ~30 minecraft:polished_deepslate
setblock ~10 ~-59 ~30 minecraft:sea_lantern
fill ~11 ~-59 ~30 ~13 ~-59 ~30 minecraft:polished_deepslate
setblock ~14 ~-59 ~30 minecraft:sea_lantern
fill ~15 ~-59 ~30 ~21 ~-59 ~30 minecraft:polished_deepslate
setblock ~22 ~-59 ~30 minecraft:sea_lantern
fill ~23 ~-59 ~30 ~25 ~-59 ~30 minecraft:polished_deepslate
setblock ~26 ~-59 ~30 minecraft:sea_lantern
fill ~27 ~-59 ~30 ~41 ~-59 ~30 minecraft:air
setblock ~42 ~-59 ~30 minecraft:sea_lantern
fill ~43 ~-59 ~30 ~45 ~-59 ~30 minecraft:polished_deepslate
setblock ~46 ~-59 ~30 minecraft:sea_lantern
fill ~47 ~-59 ~30 ~53 ~-59 ~30 minecraft:polished_deepslate
setblock ~54 ~-59 ~30 minecraft:sea_lantern
fill ~55 ~-59 ~30 ~57 ~-59 ~30 minecraft:polished_deepslate
setblock ~58 ~-59 ~30 minecraft:sea_lantern
fill ~59 ~-59 ~30 ~61 ~-59 ~30 minecraft:polished_deepslate
setblock ~62 ~-59 ~30 minecraft:sea_lantern
fill ~63 ~-59 ~30 ~64 ~-59 ~30 minecraft:polished_deepslate
fill ~4 ~-59 ~31 ~26 ~-59 ~31 minecraft:polished_deepslate
fill ~27 ~-59 ~31 ~41 ~-59 ~31 minecraft:air
fill ~42 ~-59 ~31 ~64 ~-59 ~31 minecraft:polished_deepslate
fill ~4 ~-59 ~32 ~25 ~-59 ~32 minecraft:polished_deepslate
fill ~26 ~-59 ~32 ~32 ~-59 ~32 minecraft:air
fill ~33 ~-59 ~32 ~35 ~-59 ~32 minecraft:glass
fill ~36 ~-59 ~32 ~42 ~-59 ~32 minecraft:air
fill ~43 ~-59 ~32 ~64 ~-59 ~32 minecraft:polished_deepslate
fill ~4 ~-59 ~33 ~25 ~-59 ~33 minecraft:polished_deepslate
fill ~26 ~-59 ~33 ~31 ~-59 ~33 minecraft:air
setblock ~32 ~-59 ~33 minecraft:glass
fill ~33 ~-59 ~33 ~35 ~-59 ~33 minecraft:sea_lantern
setblock ~36 ~-59 ~33 minecraft:glass
fill ~37 ~-59 ~33 ~42 ~-59 ~33 minecraft:air
fill ~43 ~-59 ~33 ~64 ~-59 ~33 minecraft:polished_deepslate
fill ~4 ~-59 ~34 ~5 ~-59 ~34 minecraft:polished_deepslate
setblock ~6 ~-59 ~34 minecraft:sea_lantern
fill ~7 ~-59 ~34 ~9 ~-59 ~34 minecraft:polished_deepslate
setblock ~10 ~-59 ~34 minecraft:sea_lantern
fill ~11 ~-59 ~34 ~13 ~-59 ~34 minecraft:polished_deepslate
setblock ~14 ~-59 ~34 minecraft:sea_lantern
fill ~15 ~-59 ~34 ~17 ~-59 ~34 minecraft:polished_deepslate
setblock ~18 ~-59 ~34 minecraft:sea_lantern
fill ~19 ~-59 ~34 ~21 ~-59 ~34 minecraft:polished_deepslate
setblock ~22 ~-59 ~34 minecraft:sea_lantern
fill ~23 ~-59 ~34 ~25 ~-59 ~34 minecraft:polished_deepslate
fill ~26 ~-59 ~34 ~31 ~-59 ~34 minecraft:air
setblock ~32 ~-59 ~34 minecraft:glass
fill ~33 ~-59 ~34 ~35 ~-59 ~34 minecraft:sea_lantern
setblock ~36 ~-59 ~34 minecraft:glass
fill ~37 ~-59 ~34 ~42 ~-59 ~34 minecraft:air
fill ~43 ~-59 ~34 ~45 ~-59 ~34 minecraft:polished_deepslate
setblock ~46 ~-59 ~34 minecraft:sea_lantern
fill ~47 ~-59 ~34 ~49 ~-59 ~34 minecraft:polished_deepslate
setblock ~50 ~-59 ~34 minecraft:sea_lantern
fill ~51 ~-59 ~34 ~53 ~-59 ~34 minecraft:polished_deepslate
setblock ~54 ~-59 ~34 minecraft:sea_lantern
fill ~55 ~-59 ~34 ~57 ~-59 ~34 minecraft:polished_deepslate
setblock ~58 ~-59 ~34 minecraft:sea_lantern
fill ~59 ~-59 ~34 ~61 ~-59 ~34 minecraft:polished_deepslate
setblock ~62 ~-59 ~34 minecraft:sea_lantern
fill ~63 ~-59 ~34 ~64 ~-59 ~34 minecraft:polished_deepslate
fill ~4 ~-59 ~35 ~25 ~-59 ~35 minecraft:polished_deepslate
fill ~26 ~-59 ~35 ~31 ~-59 ~35 minecraft:air
setblock ~32 ~-59 ~35 minecraft:glass
fill ~33 ~-59 ~35 ~35 ~-59 ~35 minecraft:sea_lantern
setblock ~36 ~-59 ~35 minecraft:glass
fill ~37 ~-59 ~35 ~42 ~-59 ~35 minecraft:air
fill ~43 ~-59 ~35 ~64 ~-59 ~35 minecraft:polished_deepslate
fill ~4 ~-59 ~36 ~25 ~-59 ~36 minecraft:polished_deepslate
fill ~26 ~-59 ~36 ~32 ~-59 ~36 minecraft:air
fill ~33 ~-59 ~36 ~35 ~-59 ~36 minecraft:glass
fill ~36 ~-59 ~36 ~42 ~-59 ~36 minecraft:air
fill ~43 ~-59 ~36 ~64 ~-59 ~36 minecraft:polished_deepslate
fill ~4 ~-59 ~37 ~26 ~-59 ~37 minecraft:polished_deepslate
fill ~27 ~-59 ~37 ~41 ~-59 ~37 minecraft:air
fill ~42 ~-59 ~37 ~64 ~-59 ~37 minecraft:polished_deepslate
fill ~4 ~-59 ~38 ~5 ~-59 ~38 minecraft:polished_deepslate
setblock ~6 ~-59 ~38 minecraft:sea_lantern
fill ~7 ~-59 ~38 ~9 ~-59 ~38 minecraft:polished_deepslate
setblock ~10 ~-59 ~38 minecraft:sea_lantern
fill ~11 ~-59 ~38 ~13 ~-59 ~38 minecraft:polished_deepslate
setblock ~14 ~-59 ~38 minecraft:sea_lantern
fill ~15 ~-59 ~38 ~21 ~-59 ~38 minecraft:polished_deepslate
setblock ~22 ~-59 ~38 minecraft:sea_lantern
fill ~23 ~-59 ~38 ~25 ~-59 ~38 minecraft:polished_deepslate
setblock ~26 ~-59 ~38 minecraft:sea_lantern
fill ~27 ~-59 ~38 ~41 ~-59 ~38 minecraft:air
setblock ~42 ~-59 ~38 minecraft:sea_lantern
fill ~43 ~-59 ~38 ~45 ~-59 ~38 minecraft:polished_deepslate
setblock ~46 ~-59 ~38 minecraft:sea_lantern
fill ~47 ~-59 ~38 ~53 ~-59 ~38 minecraft:polished_deepslate
setblock ~54 ~-59 ~38 minecraft:sea_lantern
fill ~55 ~-59 ~38 ~57 ~-59 ~38 minecraft:polished_deepslate
setblock ~58 ~-59 ~38 minecraft:sea_lantern
fill ~59 ~-59 ~38 ~61 ~-59 ~38 minecraft:polished_deepslate
setblock ~62 ~-59 ~38 minecraft:sea_lantern
fill ~63 ~-59 ~38 ~64 ~-59 ~38 minecraft:polished_deepslate
fill ~4 ~-59 ~39 ~27 ~-59 ~39 minecraft:polished_deepslate
fill ~28 ~-59 ~39 ~40 ~-59 ~39 minecraft:air
fill ~41 ~-59 ~39 ~64 ~-59 ~39 minecraft:polished_deepslate
fill ~4 ~-59 ~40 ~27 ~-59 ~40 minecraft:polished_deepslate
fill ~28 ~-59 ~40 ~40 ~-59 ~40 minecraft:air
fill ~41 ~-59 ~40 ~64 ~-59 ~40 minecraft:polished_deepslate
fill ~4 ~-59 ~41 ~29 ~-59 ~41 minecraft:polished_deepslate
fill ~30 ~-59 ~41 ~38 ~-59 ~41 minecraft:air
fill ~39 ~-59 ~41 ~64 ~-59 ~41 minecraft:polished_deepslate
fill ~4 ~-59 ~42 ~5 ~-59 ~42 minecraft:polished_deepslate
setblock ~6 ~-59 ~42 minecraft:sea_lantern
fill ~7 ~-59 ~42 ~9 ~-59 ~42 minecraft:polished_deepslate
setblock ~10 ~-59 ~42 minecraft:sea_lantern
fill ~11 ~-59 ~42 ~13 ~-59 ~42 minecraft:polished_deepslate
setblock ~14 ~-59 ~42 minecraft:sea_lantern
fill ~15 ~-59 ~42 ~25 ~-59 ~42 minecraft:polished_deepslate
setblock ~26 ~-59 ~42 minecraft:sea_lantern
fill ~27 ~-59 ~42 ~29 ~-59 ~42 minecraft:polished_deepslate
setblock ~30 ~-59 ~42 minecraft:sea_lantern
setblock ~31 ~-59 ~42 minecraft:polished_deepslate
fill ~32 ~-59 ~42 ~36 ~-59 ~42 minecraft:air
setblock ~37 ~-59 ~42 minecraft:polished_deepslate
setblock ~38 ~-59 ~42 minecraft:sea_lantern
fill ~39 ~-59 ~42 ~41 ~-59 ~42 minecraft:polished_deepslate
setblock ~42 ~-59 ~42 minecraft:sea_lantern
fill ~43 ~-59 ~42 ~53 ~-59 ~42 minecraft:polished_deepslate
setblock ~54 ~-59 ~42 minecraft:sea_lantern
fill ~55 ~-59 ~42 ~57 ~-59 ~42 minecraft:polished_deepslate
setblock ~58 ~-59 ~42 minecraft:sea_lantern
fill ~59 ~-59 ~42 ~61 ~-59 ~42 minecraft:polished_deepslate
setblock ~62 ~-59 ~42 minecraft:sea_lantern
fill ~63 ~-59 ~42 ~64 ~-59 ~42 minecraft:polished_deepslate
fill ~4 ~-59 ~43 ~64 ~-59 ~43 minecraft:polished_deepslate
fill ~4 ~-59 ~44 ~64 ~-59 ~44 minecraft:polished_deepslate
fill ~4 ~-59 ~45 ~64 ~-59 ~45 minecraft:polished_deepslate
fill ~4 ~-59 ~46 ~5 ~-59 ~46 minecraft:polished_deepslate
setblock ~6 ~-59 ~46 minecraft:sea_lantern
fill ~7 ~-59 ~46 ~9 ~-59 ~46 minecraft:polished_deepslate
setblock ~10 ~-59 ~46 minecraft:sea_lantern
fill ~11 ~-59 ~46 ~13 ~-59 ~46 minecraft:polished_deepslate
setblock ~14 ~-59 ~46 minecraft:sea_lantern
fill ~15 ~-59 ~46 ~21 ~-59 ~46 minecraft:polished_deepslate
setblock ~22 ~-59 ~46 minecraft:sea_lantern
fill ~23 ~-59 ~46 ~29 ~-59 ~46 minecraft:polished_deepslate
setblock ~30 ~-59 ~46 minecraft:sea_lantern
fill ~31 ~-59 ~46 ~33 ~-59 ~46 minecraft:polished_deepslate
setblock ~34 ~-59 ~46 minecraft:sea_lantern
fill ~35 ~-59 ~46 ~37 ~-59 ~46 minecraft:polished_deepslate
setblock ~38 ~-59 ~46 minecraft:sea_lantern
fill ~39 ~-59 ~46 ~45 ~-59 ~46 minecraft:polished_deepslate
setblock ~46 ~-59 ~46 minecraft:sea_lantern
fill ~47 ~-59 ~46 ~53 ~-59 ~46 minecraft:polished_deepslate
setblock ~54 ~-59 ~46 minecraft:sea_lantern
fill ~55 ~-59 ~46 ~57 ~-59 ~46 minecraft:polished_deepslate
setblock ~58 ~-59 ~46 minecraft:sea_lantern
fill ~59 ~-59 ~46 ~61 ~-59 ~46 minecraft:polished_deepslate
setblock ~62 ~-59 ~46 minecraft:sea_lantern
fill ~63 ~-59 ~46 ~64 ~-59 ~46 minecraft:polished_deepslate
fill ~4 ~-59 ~47 ~64 ~-59 ~47 minecraft:polished_deepslate
fill ~4 ~-59 ~48 ~64 ~-59 ~48 minecraft:polished_deepslate
fill ~4 ~-59 ~49 ~64 ~-59 ~49 minecraft:polished_deepslate
fill ~4 ~-59 ~50 ~33 ~-59 ~50 minecraft:polished_deepslate
setblock ~34 ~-59 ~50 minecraft:sea_lantern
fill ~35 ~-59 ~50 ~64 ~-59 ~50 minecraft:polished_deepslate
fill ~4 ~-59 ~51 ~64 ~-59 ~51 minecraft:polished_deepslate
fill ~4 ~-59 ~52 ~64 ~-59 ~52 minecraft:polished_deepslate
fill ~4 ~-59 ~53 ~64 ~-59 ~53 minecraft:polished_deepslate
fill ~4 ~-59 ~54 ~5 ~-59 ~54 minecraft:polished_deepslate
setblock ~6 ~-59 ~54 minecraft:sea_lantern
fill ~7 ~-59 ~54 ~9 ~-59 ~54 minecraft:polished_deepslate
setblock ~10 ~-59 ~54 minecraft:sea_lantern
fill ~11 ~-59 ~54 ~13 ~-59 ~54 minecraft:polished_deepslate
setblock ~14 ~-59 ~54 minecraft:sea_lantern
fill ~15 ~-59 ~54 ~21 ~-59 ~54 minecraft:polished_deepslate
setblock ~22 ~-59 ~54 minecraft:sea_lantern
fill ~23 ~-59 ~54 ~25 ~-59 ~54 minecraft:polished_deepslate
setblock ~26 ~-59 ~54 minecraft:sea_lantern
fill ~27 ~-59 ~54 ~29 ~-59 ~54 minecraft:polished_deepslate
setblock ~30 ~-59 ~54 minecraft:sea_lantern
fill ~31 ~-59 ~54 ~33 ~-59 ~54 minecraft:polished_deepslate
setblock ~34 ~-59 ~54 minecraft:sea_lantern
fill ~35 ~-59 ~54 ~37 ~-59 ~54 minecraft:polished_deepslate
setblock ~38 ~-59 ~54 minecraft:sea_lantern
fill ~39 ~-59 ~54 ~41 ~-59 ~54 minecraft:polished_deepslate
setblock ~42 ~-59 ~54 minecraft:sea_lantern
fill ~43 ~-59 ~54 ~45 ~-59 ~54 minecraft:polished_deepslate
setblock ~46 ~-59 ~54 minecraft:sea_lantern
fill ~47 ~-59 ~54 ~53 ~-59 ~54 minecraft:polished_deepslate
setblock ~54 ~-59 ~54 minecraft:sea_lantern
fill ~55 ~-59 ~54 ~57 ~-59 ~54 minecraft:polished_deepslate
setblock ~58 ~-59 ~54 minecraft:sea_lantern
fill ~59 ~-59 ~54 ~61 ~-59 ~54 minecraft:polished_deepslate
setblock ~62 ~-59 ~54 minecraft:sea_lantern
fill ~63 ~-59 ~54 ~64 ~-59 ~54 minecraft:polished_deepslate
fill ~4 ~-59 ~55 ~64 ~-59 ~55 minecraft:polished_deepslate
fill ~4 ~-59 ~56 ~64 ~-59 ~56 minecraft:polished_deepslate
fill ~4 ~-59 ~57 ~64 ~-59 ~57 minecraft:polished_deepslate
fill ~4 ~-59 ~58 ~5 ~-59 ~58 minecraft:polished_deepslate
setblock ~6 ~-59 ~58 minecraft:sea_lantern
fill ~7 ~-59 ~58 ~9 ~-59 ~58 minecraft:polished_deepslate
setblock ~10 ~-59 ~58 minecraft:sea_lantern
fill ~11 ~-59 ~58 ~13 ~-59 ~58 minecraft:polished_deepslate
setblock ~14 ~-59 ~58 minecraft:sea_lantern
fill ~15 ~-59 ~58 ~21 ~-59 ~58 minecraft:polished_deepslate
setblock ~22 ~-59 ~58 minecraft:sea_lantern
fill ~23 ~-59 ~58 ~25 ~-59 ~58 minecraft:polished_deepslate
setblock ~26 ~-59 ~58 minecraft:sea_lantern
fill ~27 ~-59 ~58 ~29 ~-59 ~58 minecraft:polished_deepslate
setblock ~30 ~-59 ~58 minecraft:sea_lantern
fill ~31 ~-59 ~58 ~33 ~-59 ~58 minecraft:polished_deepslate
setblock ~34 ~-59 ~58 minecraft:sea_lantern
fill ~35 ~-59 ~58 ~37 ~-59 ~58 minecraft:polished_deepslate
setblock ~38 ~-59 ~58 minecraft:sea_lantern
fill ~39 ~-59 ~58 ~41 ~-59 ~58 minecraft:polished_deepslate
setblock ~42 ~-59 ~58 minecraft:sea_lantern
fill ~43 ~-59 ~58 ~45 ~-59 ~58 minecraft:polished_deepslate
setblock ~46 ~-59 ~58 minecraft:sea_lantern
fill ~47 ~-59 ~58 ~53 ~-59 ~58 minecraft:polished_deepslate
setblock ~54 ~-59 ~58 minecraft:sea_lantern
fill ~55 ~-59 ~58 ~57 ~-59 ~58 minecraft:polished_deepslate
setblock ~58 ~-59 ~58 minecraft:sea_lantern
fill ~59 ~-59 ~58 ~61 ~-59 ~58 minecraft:polished_deepslate
setblock ~62 ~-59 ~58 minecraft:sea_lantern
fill ~63 ~-59 ~58 ~64 ~-59 ~58 minecraft:polished_deepslate
fill ~4 ~-59 ~59 ~64 ~-59 ~59 minecraft:polished_deepslate
fill ~4 ~-59 ~60 ~64 ~-59 ~60 minecraft:polished_deepslate
fill ~4 ~-59 ~61 ~64 ~-59 ~61 minecraft:polished_deepslate
fill ~4 ~-59 ~62 ~5 ~-59 ~62 minecraft:polished_deepslate
setblock ~6 ~-59 ~62 minecraft:sea_lantern
fill ~7 ~-59 ~62 ~9 ~-59 ~62 minecraft:polished_deepslate
setblock ~10 ~-59 ~62 minecraft:sea_lantern
fill ~11 ~-59 ~62 ~13 ~-59 ~62 minecraft:polished_deepslate
setblock ~14 ~-59 ~62 minecraft:sea_lantern
fill ~15 ~-59 ~62 ~21 ~-59 ~62 minecraft:polished_deepslate
setblock ~22 ~-59 ~62 minecraft:sea_lantern
fill ~23 ~-59 ~62 ~25 ~-59 ~62 minecraft:polished_deepslate
setblock ~26 ~-59 ~62 minecraft:sea_lantern
fill ~27 ~-59 ~62 ~29 ~-59 ~62 minecraft:polished_deepslate
setblock ~30 ~-59 ~62 minecraft:sea_lantern
fill ~31 ~-59 ~62 ~33 ~-59 ~62 minecraft:polished_deepslate
setblock ~34 ~-59 ~62 minecraft:sea_lantern
fill ~35 ~-59 ~62 ~37 ~-59 ~62 minecraft:polished_deepslate
setblock ~38 ~-59 ~62 minecraft:sea_lantern
fill ~39 ~-59 ~62 ~41 ~-59 ~62 minecraft:polished_deepslate
setblock ~42 ~-59 ~62 minecraft:sea_lantern
fill ~43 ~-59 ~62 ~45 ~-59 ~62 minecraft:polished_deepslate
setblock ~46 ~-59 ~62 minecraft:sea_lantern
fill ~47 ~-59 ~62 ~53 ~-59 ~62 minecraft:polished_deepslate
setblock ~54 ~-59 ~62 minecraft:sea_lantern
fill ~55 ~-59 ~62 ~57 ~-59 ~62 minecraft:polished_deepslate
setblock ~58 ~-59 ~62 minecraft:sea_lantern
fill ~59 ~-59 ~62 ~61 ~-59 ~62 minecraft:polished_deepslate
setblock ~62 ~-59 ~62 minecraft:sea_lantern
fill ~63 ~-59 ~62 ~64 ~-59 ~62 minecraft:polished_deepslate
fill ~4 ~-59 ~63 ~64 ~-59 ~63 minecraft:polished_deepslate
fill ~4 ~-59 ~64 ~64 ~-59 ~64 minecraft:polished_deepslate
fill ~32 ~-59 ~66 ~36 ~-59 ~66 minecraft:polished_andesite
setblock ~32 ~-59 ~67 minecraft:polished_andesite
fill ~33 ~-59 ~67 ~34 ~-59 ~67 minecraft:air
setblock ~35 ~-59 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-59 ~67 minecraft:polished_andesite
setblock ~32 ~-59 ~68 minecraft:polished_andesite
setblock ~33 ~-59 ~68 minecraft:air
setblock ~34 ~-59 ~68 minecraft:quartz_pillar
setblock ~35 ~-59 ~68 minecraft:air
setblock ~36 ~-59 ~68 minecraft:polished_andesite
setblock ~32 ~-59 ~69 minecraft:polished_andesite
fill ~33 ~-59 ~69 ~35 ~-59 ~69 minecraft:air
setblock ~36 ~-59 ~69 minecraft:polished_andesite
fill ~32 ~-59 ~70 ~36 ~-59 ~70 minecraft:polished_andesite
setblock ~34 ~-58 ~24 minecraft:deepslate_tiles
fill ~30 ~-58 ~25 ~38 ~-58 ~25 minecraft:deepslate_tiles
fill ~28 ~-58 ~26 ~31 ~-58 ~26 minecraft:deepslate_tiles
fill ~32 ~-58 ~26 ~36 ~-58 ~26 minecraft:air
fill ~37 ~-58 ~26 ~40 ~-58 ~26 minecraft:deepslate_tiles
fill ~27 ~-58 ~27 ~29 ~-58 ~27 minecraft:deepslate_tiles
fill ~30 ~-58 ~27 ~38 ~-58 ~27 minecraft:air
fill ~39 ~-58 ~27 ~41 ~-58 ~27 minecraft:deepslate_tiles
fill ~26 ~-58 ~28 ~27 ~-58 ~28 minecraft:deepslate_tiles
fill ~28 ~-58 ~28 ~40 ~-58 ~28 minecraft:air
fill ~41 ~-58 ~28 ~42 ~-58 ~28 minecraft:deepslate_tiles
fill ~26 ~-58 ~29 ~27 ~-58 ~29 minecraft:deepslate_tiles
fill ~28 ~-58 ~29 ~40 ~-58 ~29 minecraft:air
fill ~41 ~-58 ~29 ~42 ~-58 ~29 minecraft:deepslate_tiles
fill ~25 ~-58 ~30 ~26 ~-58 ~30 minecraft:deepslate_tiles
fill ~27 ~-58 ~30 ~41 ~-58 ~30 minecraft:air
fill ~42 ~-58 ~30 ~43 ~-58 ~30 minecraft:deepslate_tiles
fill ~25 ~-58 ~31 ~26 ~-58 ~31 minecraft:deepslate_tiles
fill ~27 ~-58 ~31 ~41 ~-58 ~31 minecraft:air
fill ~42 ~-58 ~31 ~43 ~-58 ~31 minecraft:deepslate_tiles
setblock ~25 ~-58 ~32 minecraft:deepslate_tiles
fill ~26 ~-58 ~32 ~32 ~-58 ~32 minecraft:air
fill ~33 ~-58 ~32 ~35 ~-58 ~32 minecraft:glass
fill ~36 ~-58 ~32 ~42 ~-58 ~32 minecraft:air
setblock ~43 ~-58 ~32 minecraft:deepslate_tiles
setblock ~25 ~-58 ~33 minecraft:deepslate_tiles
fill ~26 ~-58 ~33 ~31 ~-58 ~33 minecraft:air
setblock ~32 ~-58 ~33 minecraft:glass
fill ~33 ~-58 ~33 ~35 ~-58 ~33 minecraft:sea_lantern
setblock ~36 ~-58 ~33 minecraft:glass
fill ~37 ~-58 ~33 ~42 ~-58 ~33 minecraft:air
setblock ~43 ~-58 ~33 minecraft:deepslate_tiles
fill ~24 ~-58 ~34 ~25 ~-58 ~34 minecraft:deepslate_tiles
fill ~26 ~-58 ~34 ~31 ~-58 ~34 minecraft:air
setblock ~32 ~-58 ~34 minecraft:glass
fill ~33 ~-58 ~34 ~35 ~-58 ~34 minecraft:sea_lantern
setblock ~36 ~-58 ~34 minecraft:glass
fill ~37 ~-58 ~34 ~42 ~-58 ~34 minecraft:air
fill ~43 ~-58 ~34 ~44 ~-58 ~34 minecraft:deepslate_tiles
setblock ~25 ~-58 ~35 minecraft:deepslate_tiles
fill ~26 ~-58 ~35 ~31 ~-58 ~35 minecraft:air
setblock ~32 ~-58 ~35 minecraft:glass
fill ~33 ~-58 ~35 ~35 ~-58 ~35 minecraft:sea_lantern
setblock ~36 ~-58 ~35 minecraft:glass
fill ~37 ~-58 ~35 ~42 ~-58 ~35 minecraft:air
setblock ~43 ~-58 ~35 minecraft:deepslate_tiles
setblock ~25 ~-58 ~36 minecraft:deepslate_tiles
fill ~26 ~-58 ~36 ~32 ~-58 ~36 minecraft:air
fill ~33 ~-58 ~36 ~35 ~-58 ~36 minecraft:glass
fill ~36 ~-58 ~36 ~42 ~-58 ~36 minecraft:air
setblock ~43 ~-58 ~36 minecraft:deepslate_tiles
fill ~25 ~-58 ~37 ~26 ~-58 ~37 minecraft:deepslate_tiles
fill ~27 ~-58 ~37 ~41 ~-58 ~37 minecraft:air
fill ~42 ~-58 ~37 ~43 ~-58 ~37 minecraft:deepslate_tiles
fill ~25 ~-58 ~38 ~26 ~-58 ~38 minecraft:deepslate_tiles
fill ~27 ~-58 ~38 ~41 ~-58 ~38 minecraft:air
fill ~42 ~-58 ~38 ~43 ~-58 ~38 minecraft:deepslate_tiles
fill ~26 ~-58 ~39 ~27 ~-58 ~39 minecraft:deepslate_tiles
fill ~28 ~-58 ~39 ~40 ~-58 ~39 minecraft:air
fill ~41 ~-58 ~39 ~42 ~-58 ~39 minecraft:deepslate_tiles
fill ~26 ~-58 ~40 ~27 ~-58 ~40 minecraft:deepslate_tiles
fill ~28 ~-58 ~40 ~40 ~-58 ~40 minecraft:air
fill ~41 ~-58 ~40 ~42 ~-58 ~40 minecraft:deepslate_tiles
fill ~27 ~-58 ~41 ~29 ~-58 ~41 minecraft:deepslate_tiles
fill ~30 ~-58 ~41 ~38 ~-58 ~41 minecraft:air
fill ~39 ~-58 ~41 ~41 ~-58 ~41 minecraft:deepslate_tiles
fill ~28 ~-58 ~42 ~31 ~-58 ~42 minecraft:deepslate_tiles
fill ~32 ~-58 ~42 ~36 ~-58 ~42 minecraft:air
fill ~37 ~-58 ~42 ~40 ~-58 ~42 minecraft:deepslate_tiles
fill ~30 ~-58 ~43 ~38 ~-58 ~43 minecraft:deepslate_tiles
setblock ~34 ~-58 ~44 minecraft:deepslate_tiles
fill ~32 ~-58 ~66 ~36 ~-58 ~66 minecraft:polished_andesite
setblock ~32 ~-58 ~67 minecraft:polished_andesite
fill ~33 ~-58 ~67 ~35 ~-58 ~67 minecraft:air
setblock ~36 ~-58 ~67 minecraft:polished_andesite
setblock ~32 ~-58 ~68 minecraft:polished_andesite
setblock ~33 ~-58 ~68 minecraft:air
setblock ~34 ~-58 ~68 minecraft:quartz_pillar
setblock ~35 ~-58 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-58 ~68 minecraft:polished_andesite
setblock ~32 ~-58 ~69 minecraft:polished_andesite
fill ~33 ~-58 ~69 ~35 ~-58 ~69 minecraft:air
setblock ~36 ~-58 ~69 minecraft:polished_andesite
fill ~32 ~-58 ~70 ~36 ~-58 ~70 minecraft:polished_andesite
setblock ~34 ~-57 ~24 minecraft:deepslate_tiles
fill ~30 ~-57 ~25 ~38 ~-57 ~25 minecraft:deepslate_tiles
fill ~28 ~-57 ~26 ~31 ~-57 ~26 minecraft:deepslate_tiles
fill ~32 ~-57 ~26 ~36 ~-57 ~26 minecraft:air
fill ~37 ~-57 ~26 ~40 ~-57 ~26 minecraft:deepslate_tiles
fill ~27 ~-57 ~27 ~29 ~-57 ~27 minecraft:deepslate_tiles
fill ~30 ~-57 ~27 ~38 ~-57 ~27 minecraft:air
fill ~39 ~-57 ~27 ~41 ~-57 ~27 minecraft:deepslate_tiles
fill ~26 ~-57 ~28 ~27 ~-57 ~28 minecraft:deepslate_tiles
fill ~28 ~-57 ~28 ~40 ~-57 ~28 minecraft:air
fill ~41 ~-57 ~28 ~42 ~-57 ~28 minecraft:deepslate_tiles
fill ~26 ~-57 ~29 ~27 ~-57 ~29 minecraft:deepslate_tiles
fill ~28 ~-57 ~29 ~40 ~-57 ~29 minecraft:air
fill ~41 ~-57 ~29 ~42 ~-57 ~29 minecraft:deepslate_tiles
fill ~25 ~-57 ~30 ~26 ~-57 ~30 minecraft:deepslate_tiles
fill ~27 ~-57 ~30 ~41 ~-57 ~30 minecraft:air
fill ~42 ~-57 ~30 ~43 ~-57 ~30 minecraft:deepslate_tiles
fill ~25 ~-57 ~31 ~26 ~-57 ~31 minecraft:deepslate_tiles
fill ~27 ~-57 ~31 ~41 ~-57 ~31 minecraft:air
fill ~42 ~-57 ~31 ~43 ~-57 ~31 minecraft:deepslate_tiles
setblock ~25 ~-57 ~32 minecraft:deepslate_tiles
fill ~26 ~-57 ~32 ~32 ~-57 ~32 minecraft:air
fill ~33 ~-57 ~32 ~35 ~-57 ~32 minecraft:glass
fill ~36 ~-57 ~32 ~42 ~-57 ~32 minecraft:air
setblock ~43 ~-57 ~32 minecraft:deepslate_tiles
setblock ~25 ~-57 ~33 minecraft:deepslate_tiles
fill ~26 ~-57 ~33 ~31 ~-57 ~33 minecraft:air
setblock ~32 ~-57 ~33 minecraft:glass
fill ~33 ~-57 ~33 ~35 ~-57 ~33 minecraft:sea_lantern
setblock ~36 ~-57 ~33 minecraft:glass
fill ~37 ~-57 ~33 ~42 ~-57 ~33 minecraft:air
setblock ~43 ~-57 ~33 minecraft:deepslate_tiles
fill ~24 ~-57 ~34 ~25 ~-57 ~34 minecraft:deepslate_tiles
fill ~26 ~-57 ~34 ~31 ~-57 ~34 minecraft:air
setblock ~32 ~-57 ~34 minecraft:glass
fill ~33 ~-57 ~34 ~35 ~-57 ~34 minecraft:sea_lantern
setblock ~36 ~-57 ~34 minecraft:glass
fill ~37 ~-57 ~34 ~42 ~-57 ~34 minecraft:air
fill ~43 ~-57 ~34 ~44 ~-57 ~34 minecraft:deepslate_tiles
setblock ~25 ~-57 ~35 minecraft:deepslate_tiles
fill ~26 ~-57 ~35 ~31 ~-57 ~35 minecraft:air
setblock ~32 ~-57 ~35 minecraft:glass
fill ~33 ~-57 ~35 ~35 ~-57 ~35 minecraft:sea_lantern
setblock ~36 ~-57 ~35 minecraft:glass
fill ~37 ~-57 ~35 ~42 ~-57 ~35 minecraft:air
setblock ~43 ~-57 ~35 minecraft:deepslate_tiles
setblock ~25 ~-57 ~36 minecraft:deepslate_tiles
fill ~26 ~-57 ~36 ~32 ~-57 ~36 minecraft:air
fill ~33 ~-57 ~36 ~35 ~-57 ~36 minecraft:glass
fill ~36 ~-57 ~36 ~42 ~-57 ~36 minecraft:air
setblock ~43 ~-57 ~36 minecraft:deepslate_tiles
fill ~25 ~-57 ~37 ~26 ~-57 ~37 minecraft:deepslate_tiles
fill ~27 ~-57 ~37 ~41 ~-57 ~37 minecraft:air
fill ~42 ~-57 ~37 ~43 ~-57 ~37 minecraft:deepslate_tiles
fill ~25 ~-57 ~38 ~26 ~-57 ~38 minecraft:deepslate_tiles
fill ~27 ~-57 ~38 ~41 ~-57 ~38 minecraft:air
fill ~42 ~-57 ~38 ~43 ~-57 ~38 minecraft:deepslate_tiles
fill ~26 ~-57 ~39 ~27 ~-57 ~39 minecraft:deepslate_tiles
fill ~28 ~-57 ~39 ~40 ~-57 ~39 minecraft:air
fill ~41 ~-57 ~39 ~42 ~-57 ~39 minecraft:deepslate_tiles
fill ~26 ~-57 ~40 ~27 ~-57 ~40 minecraft:deepslate_tiles
fill ~28 ~-57 ~40 ~40 ~-57 ~40 minecraft:air
fill ~41 ~-57 ~40 ~42 ~-57 ~40 minecraft:deepslate_tiles
fill ~27 ~-57 ~41 ~29 ~-57 ~41 minecraft:deepslate_tiles
fill ~30 ~-57 ~41 ~38 ~-57 ~41 minecraft:air
fill ~39 ~-57 ~41 ~41 ~-57 ~41 minecraft:deepslate_tiles
fill ~28 ~-57 ~42 ~31 ~-57 ~42 minecraft:deepslate_tiles
fill ~32 ~-57 ~42 ~36 ~-57 ~42 minecraft:air
fill ~37 ~-57 ~42 ~40 ~-57 ~42 minecraft:deepslate_tiles
fill ~30 ~-57 ~43 ~38 ~-57 ~43 minecraft:deepslate_tiles
setblock ~34 ~-57 ~44 minecraft:deepslate_tiles
fill ~32 ~-57 ~66 ~36 ~-57 ~66 minecraft:polished_andesite
setblock ~32 ~-57 ~67 minecraft:polished_andesite
fill ~33 ~-57 ~67 ~35 ~-57 ~67 minecraft:air
setblock ~36 ~-57 ~67 minecraft:polished_andesite
setblock ~32 ~-57 ~68 minecraft:polished_andesite
setblock ~33 ~-57 ~68 minecraft:air
setblock ~34 ~-57 ~68 minecraft:quartz_pillar
setblock ~35 ~-57 ~68 minecraft:air
setblock ~36 ~-57 ~68 minecraft:polished_andesite
setblock ~32 ~-57 ~69 minecraft:polished_andesite
fill ~33 ~-57 ~69 ~34 ~-57 ~69 minecraft:air
setblock ~35 ~-57 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-57 ~69 minecraft:polished_andesite
fill ~32 ~-57 ~70 ~36 ~-57 ~70 minecraft:polished_andesite
setblock ~34 ~-56 ~24 minecraft:deepslate_tiles
fill ~30 ~-56 ~25 ~38 ~-56 ~25 minecraft:deepslate_tiles
fill ~28 ~-56 ~26 ~31 ~-56 ~26 minecraft:deepslate_tiles
fill ~32 ~-56 ~26 ~36 ~-56 ~26 minecraft:air
fill ~37 ~-56 ~26 ~40 ~-56 ~26 minecraft:deepslate_tiles
fill ~27 ~-56 ~27 ~29 ~-56 ~27 minecraft:deepslate_tiles
fill ~30 ~-56 ~27 ~38 ~-56 ~27 minecraft:air
fill ~39 ~-56 ~27 ~41 ~-56 ~27 minecraft:deepslate_tiles
fill ~26 ~-56 ~28 ~27 ~-56 ~28 minecraft:deepslate_tiles
fill ~28 ~-56 ~28 ~40 ~-56 ~28 minecraft:air
fill ~41 ~-56 ~28 ~42 ~-56 ~28 minecraft:deepslate_tiles
fill ~26 ~-56 ~29 ~27 ~-56 ~29 minecraft:deepslate_tiles
fill ~28 ~-56 ~29 ~40 ~-56 ~29 minecraft:air
fill ~41 ~-56 ~29 ~42 ~-56 ~29 minecraft:deepslate_tiles
fill ~25 ~-56 ~30 ~26 ~-56 ~30 minecraft:deepslate_tiles
fill ~27 ~-56 ~30 ~41 ~-56 ~30 minecraft:air
fill ~42 ~-56 ~30 ~43 ~-56 ~30 minecraft:deepslate_tiles
fill ~25 ~-56 ~31 ~26 ~-56 ~31 minecraft:deepslate_tiles
fill ~27 ~-56 ~31 ~41 ~-56 ~31 minecraft:air
fill ~42 ~-56 ~31 ~43 ~-56 ~31 minecraft:deepslate_tiles
setblock ~25 ~-56 ~32 minecraft:deepslate_tiles
fill ~26 ~-56 ~32 ~32 ~-56 ~32 minecraft:air
fill ~33 ~-56 ~32 ~35 ~-56 ~32 minecraft:waxed_cut_copper
fill ~36 ~-56 ~32 ~42 ~-56 ~32 minecraft:air
setblock ~43 ~-56 ~32 minecraft:deepslate_tiles
setblock ~25 ~-56 ~33 minecraft:deepslate_tiles
fill ~26 ~-56 ~33 ~31 ~-56 ~33 minecraft:air
setblock ~32 ~-56 ~33 minecraft:waxed_cut_copper
fill ~33 ~-56 ~33 ~35 ~-56 ~33 minecraft:sea_lantern
setblock ~36 ~-56 ~33 minecraft:waxed_cut_copper
fill ~37 ~-56 ~33 ~42 ~-56 ~33 minecraft:air
setblock ~43 ~-56 ~33 minecraft:deepslate_tiles
fill ~24 ~-56 ~34 ~25 ~-56 ~34 minecraft:deepslate_tiles
fill ~26 ~-56 ~34 ~31 ~-56 ~34 minecraft:air
setblock ~32 ~-56 ~34 minecraft:waxed_cut_copper
fill ~33 ~-56 ~34 ~35 ~-56 ~34 minecraft:sea_lantern
setblock ~36 ~-56 ~34 minecraft:waxed_cut_copper
fill ~37 ~-56 ~34 ~42 ~-56 ~34 minecraft:air
fill ~43 ~-56 ~34 ~44 ~-56 ~34 minecraft:deepslate_tiles
setblock ~25 ~-56 ~35 minecraft:deepslate_tiles
fill ~26 ~-56 ~35 ~31 ~-56 ~35 minecraft:air
setblock ~32 ~-56 ~35 minecraft:waxed_cut_copper
fill ~33 ~-56 ~35 ~35 ~-56 ~35 minecraft:sea_lantern
setblock ~36 ~-56 ~35 minecraft:waxed_cut_copper
fill ~37 ~-56 ~35 ~42 ~-56 ~35 minecraft:air
setblock ~43 ~-56 ~35 minecraft:deepslate_tiles
setblock ~25 ~-56 ~36 minecraft:deepslate_tiles
fill ~26 ~-56 ~36 ~32 ~-56 ~36 minecraft:air
fill ~33 ~-56 ~36 ~35 ~-56 ~36 minecraft:waxed_cut_copper
fill ~36 ~-56 ~36 ~42 ~-56 ~36 minecraft:air
setblock ~43 ~-56 ~36 minecraft:deepslate_tiles
fill ~25 ~-56 ~37 ~26 ~-56 ~37 minecraft:deepslate_tiles
fill ~27 ~-56 ~37 ~41 ~-56 ~37 minecraft:air
fill ~42 ~-56 ~37 ~43 ~-56 ~37 minecraft:deepslate_tiles
fill ~25 ~-56 ~38 ~26 ~-56 ~38 minecraft:deepslate_tiles
fill ~27 ~-56 ~38 ~41 ~-56 ~38 minecraft:air
fill ~42 ~-56 ~38 ~43 ~-56 ~38 minecraft:deepslate_tiles
fill ~26 ~-56 ~39 ~27 ~-56 ~39 minecraft:deepslate_tiles
fill ~28 ~-56 ~39 ~40 ~-56 ~39 minecraft:air
fill ~41 ~-56 ~39 ~42 ~-56 ~39 minecraft:deepslate_tiles
fill ~26 ~-56 ~40 ~27 ~-56 ~40 minecraft:deepslate_tiles
fill ~28 ~-56 ~40 ~40 ~-56 ~40 minecraft:air
fill ~41 ~-56 ~40 ~42 ~-56 ~40 minecraft:deepslate_tiles
fill ~27 ~-56 ~41 ~29 ~-56 ~41 minecraft:deepslate_tiles
fill ~30 ~-56 ~41 ~38 ~-56 ~41 minecraft:air
fill ~39 ~-56 ~41 ~41 ~-56 ~41 minecraft:deepslate_tiles
fill ~28 ~-56 ~42 ~31 ~-56 ~42 minecraft:deepslate_tiles
fill ~32 ~-56 ~42 ~36 ~-56 ~42 minecraft:air
fill ~37 ~-56 ~42 ~40 ~-56 ~42 minecraft:deepslate_tiles
fill ~30 ~-56 ~43 ~38 ~-56 ~43 minecraft:deepslate_tiles
setblock ~34 ~-56 ~44 minecraft:deepslate_tiles
fill ~32 ~-56 ~66 ~36 ~-56 ~66 minecraft:polished_andesite
setblock ~32 ~-56 ~67 minecraft:polished_andesite
fill ~33 ~-56 ~67 ~35 ~-56 ~67 minecraft:air
setblock ~36 ~-56 ~67 minecraft:polished_andesite
setblock ~32 ~-56 ~68 minecraft:sea_lantern
setblock ~33 ~-56 ~68 minecraft:air
setblock ~34 ~-56 ~68 minecraft:quartz_pillar
setblock ~35 ~-56 ~68 minecraft:air
setblock ~36 ~-56 ~68 minecraft:sea_lantern
setblock ~32 ~-56 ~69 minecraft:polished_andesite
setblock ~33 ~-56 ~69 minecraft:air
setblock ~34 ~-56 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-56 ~69 minecraft:air
setblock ~36 ~-56 ~69 minecraft:polished_andesite
fill ~32 ~-56 ~70 ~36 ~-56 ~70 minecraft:polished_andesite
setblock ~34 ~-55 ~24 minecraft:sea_lantern
setblock ~30 ~-55 ~25 minecraft:deepslate_tiles
setblock ~31 ~-55 ~25 minecraft:sea_lantern
setblock ~32 ~-55 ~25 minecraft:deepslate_tiles
setblock ~33 ~-55 ~25 minecraft:sea_lantern
setblock ~34 ~-55 ~25 minecraft:deepslate_tiles
setblock ~35 ~-55 ~25 minecraft:sea_lantern
setblock ~36 ~-55 ~25 minecraft:deepslate_tiles
setblock ~37 ~-55 ~25 minecraft:sea_lantern
setblock ~38 ~-55 ~25 minecraft:deepslate_tiles
setblock ~28 ~-55 ~26 minecraft:sea_lantern
setblock ~29 ~-55 ~26 minecraft:deepslate_tiles
setblock ~30 ~-55 ~26 minecraft:sea_lantern
setblock ~31 ~-55 ~26 minecraft:deepslate_tiles
fill ~32 ~-55 ~26 ~36 ~-55 ~26 minecraft:air
setblock ~37 ~-55 ~26 minecraft:deepslate_tiles
setblock ~38 ~-55 ~26 minecraft:sea_lantern
setblock ~39 ~-55 ~26 minecraft:deepslate_tiles
setblock ~40 ~-55 ~26 minecraft:sea_lantern
setblock ~27 ~-55 ~27 minecraft:sea_lantern
setblock ~28 ~-55 ~27 minecraft:deepslate_tiles
setblock ~29 ~-55 ~27 minecraft:sea_lantern
fill ~30 ~-55 ~27 ~38 ~-55 ~27 minecraft:air
setblock ~39 ~-55 ~27 minecraft:sea_lantern
setblock ~40 ~-55 ~27 minecraft:deepslate_tiles
setblock ~41 ~-55 ~27 minecraft:sea_lantern
setblock ~26 ~-55 ~28 minecraft:sea_lantern
setblock ~27 ~-55 ~28 minecraft:deepslate_tiles
fill ~28 ~-55 ~28 ~40 ~-55 ~28 minecraft:air
setblock ~41 ~-55 ~28 minecraft:deepslate_tiles
setblock ~42 ~-55 ~28 minecraft:sea_lantern
setblock ~26 ~-55 ~29 minecraft:deepslate_tiles
setblock ~27 ~-55 ~29 minecraft:sea_lantern
fill ~28 ~-55 ~29 ~40 ~-55 ~29 minecraft:air
setblock ~41 ~-55 ~29 minecraft:sea_lantern
setblock ~42 ~-55 ~29 minecraft:deepslate_tiles
setblock ~25 ~-55 ~30 minecraft:deepslate_tiles
setblock ~26 ~-55 ~30 minecraft:sea_lantern
fill ~27 ~-55 ~30 ~41 ~-55 ~30 minecraft:air
setblock ~42 ~-55 ~30 minecraft:sea_lantern
setblock ~43 ~-55 ~30 minecraft:deepslate_tiles
setblock ~25 ~-55 ~31 minecraft:sea_lantern
setblock ~26 ~-55 ~31 minecraft:deepslate_tiles
fill ~27 ~-55 ~31 ~41 ~-55 ~31 minecraft:air
setblock ~42 ~-55 ~31 minecraft:deepslate_tiles
setblock ~43 ~-55 ~31 minecraft:sea_lantern
setblock ~25 ~-55 ~32 minecraft:deepslate_tiles
fill ~26 ~-55 ~32 ~32 ~-55 ~32 minecraft:air
fill ~33 ~-55 ~32 ~35 ~-55 ~32 minecraft:glass
fill ~36 ~-55 ~32 ~42 ~-55 ~32 minecraft:air
setblock ~43 ~-55 ~32 minecraft:deepslate_tiles
setblock ~25 ~-55 ~33 minecraft:sea_lantern
fill ~26 ~-55 ~33 ~31 ~-55 ~33 minecraft:air
setblock ~32 ~-55 ~33 minecraft:glass
fill ~33 ~-55 ~33 ~35 ~-55 ~33 minecraft:sea_lantern
setblock ~36 ~-55 ~33 minecraft:glass
fill ~37 ~-55 ~33 ~42 ~-55 ~33 minecraft:air
setblock ~43 ~-55 ~33 minecraft:sea_lantern
setblock ~24 ~-55 ~34 minecraft:sea_lantern
setblock ~25 ~-55 ~34 minecraft:deepslate_tiles
fill ~26 ~-55 ~34 ~31 ~-55 ~34 minecraft:air
setblock ~32 ~-55 ~34 minecraft:glass
fill ~33 ~-55 ~34 ~35 ~-55 ~34 minecraft:sea_lantern
setblock ~36 ~-55 ~34 minecraft:glass
fill ~37 ~-55 ~34 ~42 ~-55 ~34 minecraft:air
setblock ~43 ~-55 ~34 minecraft:deepslate_tiles
setblock ~44 ~-55 ~34 minecraft:sea_lantern
setblock ~25 ~-55 ~35 minecraft:sea_lantern
fill ~26 ~-55 ~35 ~31 ~-55 ~35 minecraft:air
setblock ~32 ~-55 ~35 minecraft:glass
fill ~33 ~-55 ~35 ~35 ~-55 ~35 minecraft:sea_lantern
setblock ~36 ~-55 ~35 minecraft:glass
fill ~37 ~-55 ~35 ~42 ~-55 ~35 minecraft:air
setblock ~43 ~-55 ~35 minecraft:sea_lantern
setblock ~25 ~-55 ~36 minecraft:deepslate_tiles
fill ~26 ~-55 ~36 ~32 ~-55 ~36 minecraft:air
fill ~33 ~-55 ~36 ~35 ~-55 ~36 minecraft:glass
fill ~36 ~-55 ~36 ~42 ~-55 ~36 minecraft:air
setblock ~43 ~-55 ~36 minecraft:deepslate_tiles
setblock ~25 ~-55 ~37 minecraft:sea_lantern
setblock ~26 ~-55 ~37 minecraft:deepslate_tiles
fill ~27 ~-55 ~37 ~41 ~-55 ~37 minecraft:air
setblock ~42 ~-55 ~37 minecraft:deepslate_tiles
setblock ~43 ~-55 ~37 minecraft:sea_lantern
setblock ~25 ~-55 ~38 minecraft:deepslate_tiles
setblock ~26 ~-55 ~38 minecraft:sea_lantern
fill ~27 ~-55 ~38 ~41 ~-55 ~38 minecraft:air
setblock ~42 ~-55 ~38 minecraft:sea_lantern
setblock ~43 ~-55 ~38 minecraft:deepslate_tiles
setblock ~26 ~-55 ~39 minecraft:deepslate_tiles
setblock ~27 ~-55 ~39 minecraft:sea_lantern
fill ~28 ~-55 ~39 ~40 ~-55 ~39 minecraft:air
setblock ~41 ~-55 ~39 minecraft:sea_lantern
setblock ~42 ~-55 ~39 minecraft:deepslate_tiles
setblock ~26 ~-55 ~40 minecraft:sea_lantern
setblock ~27 ~-55 ~40 minecraft:deepslate_tiles
fill ~28 ~-55 ~40 ~40 ~-55 ~40 minecraft:air
setblock ~41 ~-55 ~40 minecraft:deepslate_tiles
setblock ~42 ~-55 ~40 minecraft:sea_lantern
setblock ~27 ~-55 ~41 minecraft:sea_lantern
setblock ~28 ~-55 ~41 minecraft:deepslate_tiles
setblock ~29 ~-55 ~41 minecraft:sea_lantern
fill ~30 ~-55 ~41 ~38 ~-55 ~41 minecraft:air
setblock ~39 ~-55 ~41 minecraft:sea_lantern
setblock ~40 ~-55 ~41 minecraft:deepslate_tiles
setblock ~41 ~-55 ~41 minecraft:sea_lantern
setblock ~28 ~-55 ~42 minecraft:sea_lantern
setblock ~29 ~-55 ~42 minecraft:deepslate_tiles
setblock ~30 ~-55 ~42 minecraft:sea_lantern
setblock ~31 ~-55 ~42 minecraft:deepslate_tiles
fill ~32 ~-55 ~42 ~36 ~-55 ~42 minecraft:air
setblock ~37 ~-55 ~42 minecraft:deepslate_tiles
setblock ~38 ~-55 ~42 minecraft:sea_lantern
setblock ~39 ~-55 ~42 minecraft:deepslate_tiles
setblock ~40 ~-55 ~42 minecraft:sea_lantern
setblock ~30 ~-55 ~43 minecraft:deepslate_tiles
setblock ~31 ~-55 ~43 minecraft:sea_lantern
setblock ~32 ~-55 ~43 minecraft:deepslate_tiles
setblock ~33 ~-55 ~43 minecraft:sea_lantern
setblock ~34 ~-55 ~43 minecraft:deepslate_tiles
setblock ~35 ~-55 ~43 minecraft:sea_lantern
setblock ~36 ~-55 ~43 minecraft:deepslate_tiles
setblock ~37 ~-55 ~43 minecraft:sea_lantern
setblock ~38 ~-55 ~43 minecraft:deepslate_tiles
setblock ~34 ~-55 ~44 minecraft:sea_lantern
fill ~32 ~-55 ~66 ~36 ~-55 ~66 minecraft:polished_andesite
setblock ~32 ~-55 ~67 minecraft:polished_andesite
fill ~33 ~-55 ~67 ~35 ~-55 ~67 minecraft:air
setblock ~36 ~-55 ~67 minecraft:polished_andesite
setblock ~32 ~-55 ~68 minecraft:polished_andesite
setblock ~33 ~-55 ~68 minecraft:air
setblock ~34 ~-55 ~68 minecraft:quartz_pillar
setblock ~35 ~-55 ~68 minecraft:air
setblock ~36 ~-55 ~68 minecraft:polished_andesite
setblock ~32 ~-55 ~69 minecraft:polished_andesite
setblock ~33 ~-55 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-55 ~69 ~35 ~-55 ~69 minecraft:air
setblock ~36 ~-55 ~69 minecraft:polished_andesite
fill ~32 ~-55 ~70 ~36 ~-55 ~70 minecraft:polished_andesite
setblock ~34 ~-54 ~24 minecraft:deepslate_tiles
fill ~30 ~-54 ~25 ~38 ~-54 ~25 minecraft:deepslate_tiles
fill ~28 ~-54 ~26 ~31 ~-54 ~26 minecraft:deepslate_tiles
fill ~32 ~-54 ~26 ~36 ~-54 ~26 minecraft:air
fill ~37 ~-54 ~26 ~40 ~-54 ~26 minecraft:deepslate_tiles
fill ~27 ~-54 ~27 ~29 ~-54 ~27 minecraft:deepslate_tiles
fill ~30 ~-54 ~27 ~38 ~-54 ~27 minecraft:air
fill ~39 ~-54 ~27 ~41 ~-54 ~27 minecraft:deepslate_tiles
fill ~26 ~-54 ~28 ~27 ~-54 ~28 minecraft:deepslate_tiles
fill ~28 ~-54 ~28 ~40 ~-54 ~28 minecraft:air
fill ~41 ~-54 ~28 ~42 ~-54 ~28 minecraft:deepslate_tiles
fill ~26 ~-54 ~29 ~27 ~-54 ~29 minecraft:deepslate_tiles
fill ~28 ~-54 ~29 ~40 ~-54 ~29 minecraft:air
fill ~41 ~-54 ~29 ~42 ~-54 ~29 minecraft:deepslate_tiles
fill ~25 ~-54 ~30 ~26 ~-54 ~30 minecraft:deepslate_tiles
fill ~27 ~-54 ~30 ~41 ~-54 ~30 minecraft:air
fill ~42 ~-54 ~30 ~43 ~-54 ~30 minecraft:deepslate_tiles
fill ~25 ~-54 ~31 ~26 ~-54 ~31 minecraft:deepslate_tiles
fill ~27 ~-54 ~31 ~41 ~-54 ~31 minecraft:air
fill ~42 ~-54 ~31 ~43 ~-54 ~31 minecraft:deepslate_tiles
setblock ~25 ~-54 ~32 minecraft:deepslate_tiles
fill ~26 ~-54 ~32 ~32 ~-54 ~32 minecraft:air
fill ~33 ~-54 ~32 ~35 ~-54 ~32 minecraft:glass
fill ~36 ~-54 ~32 ~42 ~-54 ~32 minecraft:air
setblock ~43 ~-54 ~32 minecraft:deepslate_tiles
setblock ~25 ~-54 ~33 minecraft:deepslate_tiles
fill ~26 ~-54 ~33 ~31 ~-54 ~33 minecraft:air
setblock ~32 ~-54 ~33 minecraft:glass
fill ~33 ~-54 ~33 ~35 ~-54 ~33 minecraft:sea_lantern
setblock ~36 ~-54 ~33 minecraft:glass
fill ~37 ~-54 ~33 ~42 ~-54 ~33 minecraft:air
setblock ~43 ~-54 ~33 minecraft:deepslate_tiles
fill ~24 ~-54 ~34 ~25 ~-54 ~34 minecraft:deepslate_tiles
fill ~26 ~-54 ~34 ~31 ~-54 ~34 minecraft:air
setblock ~32 ~-54 ~34 minecraft:glass
fill ~33 ~-54 ~34 ~35 ~-54 ~34 minecraft:sea_lantern
setblock ~36 ~-54 ~34 minecraft:glass
fill ~37 ~-54 ~34 ~42 ~-54 ~34 minecraft:air
fill ~43 ~-54 ~34 ~44 ~-54 ~34 minecraft:deepslate_tiles
setblock ~25 ~-54 ~35 minecraft:deepslate_tiles
fill ~26 ~-54 ~35 ~31 ~-54 ~35 minecraft:air
setblock ~32 ~-54 ~35 minecraft:glass
fill ~33 ~-54 ~35 ~35 ~-54 ~35 minecraft:sea_lantern
setblock ~36 ~-54 ~35 minecraft:glass
fill ~37 ~-54 ~35 ~42 ~-54 ~35 minecraft:air
setblock ~43 ~-54 ~35 minecraft:deepslate_tiles
setblock ~25 ~-54 ~36 minecraft:deepslate_tiles
fill ~26 ~-54 ~36 ~32 ~-54 ~36 minecraft:air
fill ~33 ~-54 ~36 ~35 ~-54 ~36 minecraft:glass
fill ~36 ~-54 ~36 ~42 ~-54 ~36 minecraft:air
setblock ~43 ~-54 ~36 minecraft:deepslate_tiles
fill ~25 ~-54 ~37 ~26 ~-54 ~37 minecraft:deepslate_tiles
fill ~27 ~-54 ~37 ~41 ~-54 ~37 minecraft:air
fill ~42 ~-54 ~37 ~43 ~-54 ~37 minecraft:deepslate_tiles
fill ~25 ~-54 ~38 ~26 ~-54 ~38 minecraft:deepslate_tiles
fill ~27 ~-54 ~38 ~41 ~-54 ~38 minecraft:air
fill ~42 ~-54 ~38 ~43 ~-54 ~38 minecraft:deepslate_tiles
fill ~26 ~-54 ~39 ~27 ~-54 ~39 minecraft:deepslate_tiles
fill ~28 ~-54 ~39 ~40 ~-54 ~39 minecraft:air
fill ~41 ~-54 ~39 ~42 ~-54 ~39 minecraft:deepslate_tiles
fill ~26 ~-54 ~40 ~27 ~-54 ~40 minecraft:deepslate_tiles
fill ~28 ~-54 ~40 ~40 ~-54 ~40 minecraft:air
fill ~41 ~-54 ~40 ~42 ~-54 ~40 minecraft:deepslate_tiles
fill ~27 ~-54 ~41 ~29 ~-54 ~41 minecraft:deepslate_tiles
fill ~30 ~-54 ~41 ~38 ~-54 ~41 minecraft:air
fill ~39 ~-54 ~41 ~41 ~-54 ~41 minecraft:deepslate_tiles
fill ~28 ~-54 ~42 ~31 ~-54 ~42 minecraft:deepslate_tiles
fill ~32 ~-54 ~42 ~36 ~-54 ~42 minecraft:air
fill ~37 ~-54 ~42 ~40 ~-54 ~42 minecraft:deepslate_tiles
fill ~30 ~-54 ~43 ~38 ~-54 ~43 minecraft:deepslate_tiles
setblock ~34 ~-54 ~44 minecraft:deepslate_tiles
fill ~32 ~-54 ~66 ~36 ~-54 ~66 minecraft:polished_andesite
setblock ~32 ~-54 ~67 minecraft:polished_andesite
fill ~33 ~-54 ~67 ~35 ~-54 ~67 minecraft:air
setblock ~36 ~-54 ~67 minecraft:polished_andesite
setblock ~32 ~-54 ~68 minecraft:polished_andesite
setblock ~33 ~-54 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-54 ~68 minecraft:quartz_pillar
setblock ~35 ~-54 ~68 minecraft:air
setblock ~36 ~-54 ~68 minecraft:polished_andesite
setblock ~32 ~-54 ~69 minecraft:polished_andesite
fill ~33 ~-54 ~69 ~35 ~-54 ~69 minecraft:air
setblock ~36 ~-54 ~69 minecraft:polished_andesite
fill ~32 ~-54 ~70 ~36 ~-54 ~70 minecraft:polished_andesite
setblock ~34 ~-53 ~24 minecraft:deepslate_tiles
fill ~30 ~-53 ~25 ~38 ~-53 ~25 minecraft:deepslate_tiles
fill ~28 ~-53 ~26 ~31 ~-53 ~26 minecraft:deepslate_tiles
fill ~32 ~-53 ~26 ~36 ~-53 ~26 minecraft:air
fill ~37 ~-53 ~26 ~40 ~-53 ~26 minecraft:deepslate_tiles
fill ~27 ~-53 ~27 ~29 ~-53 ~27 minecraft:deepslate_tiles
fill ~30 ~-53 ~27 ~38 ~-53 ~27 minecraft:air
fill ~39 ~-53 ~27 ~41 ~-53 ~27 minecraft:deepslate_tiles
fill ~26 ~-53 ~28 ~27 ~-53 ~28 minecraft:deepslate_tiles
fill ~28 ~-53 ~28 ~40 ~-53 ~28 minecraft:air
fill ~41 ~-53 ~28 ~42 ~-53 ~28 minecraft:deepslate_tiles
fill ~26 ~-53 ~29 ~27 ~-53 ~29 minecraft:deepslate_tiles
fill ~28 ~-53 ~29 ~40 ~-53 ~29 minecraft:air
fill ~41 ~-53 ~29 ~42 ~-53 ~29 minecraft:deepslate_tiles
fill ~25 ~-53 ~30 ~26 ~-53 ~30 minecraft:deepslate_tiles
fill ~27 ~-53 ~30 ~41 ~-53 ~30 minecraft:air
fill ~42 ~-53 ~30 ~43 ~-53 ~30 minecraft:deepslate_tiles
fill ~25 ~-53 ~31 ~26 ~-53 ~31 minecraft:deepslate_tiles
fill ~27 ~-53 ~31 ~41 ~-53 ~31 minecraft:air
fill ~42 ~-53 ~31 ~43 ~-53 ~31 minecraft:deepslate_tiles
setblock ~25 ~-53 ~32 minecraft:deepslate_tiles
fill ~26 ~-53 ~32 ~32 ~-53 ~32 minecraft:air
fill ~33 ~-53 ~32 ~35 ~-53 ~32 minecraft:glass
fill ~36 ~-53 ~32 ~42 ~-53 ~32 minecraft:air
setblock ~43 ~-53 ~32 minecraft:deepslate_tiles
setblock ~25 ~-53 ~33 minecraft:deepslate_tiles
fill ~26 ~-53 ~33 ~31 ~-53 ~33 minecraft:air
setblock ~32 ~-53 ~33 minecraft:glass
fill ~33 ~-53 ~33 ~35 ~-53 ~33 minecraft:sea_lantern
setblock ~36 ~-53 ~33 minecraft:glass
fill ~37 ~-53 ~33 ~42 ~-53 ~33 minecraft:air
setblock ~43 ~-53 ~33 minecraft:deepslate_tiles
fill ~24 ~-53 ~34 ~25 ~-53 ~34 minecraft:deepslate_tiles
fill ~26 ~-53 ~34 ~31 ~-53 ~34 minecraft:air
setblock ~32 ~-53 ~34 minecraft:glass
fill ~33 ~-53 ~34 ~35 ~-53 ~34 minecraft:sea_lantern
setblock ~36 ~-53 ~34 minecraft:glass
fill ~37 ~-53 ~34 ~42 ~-53 ~34 minecraft:air
fill ~43 ~-53 ~34 ~44 ~-53 ~34 minecraft:deepslate_tiles
setblock ~25 ~-53 ~35 minecraft:deepslate_tiles
fill ~26 ~-53 ~35 ~31 ~-53 ~35 minecraft:air
setblock ~32 ~-53 ~35 minecraft:glass
fill ~33 ~-53 ~35 ~35 ~-53 ~35 minecraft:sea_lantern
setblock ~36 ~-53 ~35 minecraft:glass
fill ~37 ~-53 ~35 ~42 ~-53 ~35 minecraft:air
setblock ~43 ~-53 ~35 minecraft:deepslate_tiles
setblock ~25 ~-53 ~36 minecraft:deepslate_tiles
fill ~26 ~-53 ~36 ~32 ~-53 ~36 minecraft:air
fill ~33 ~-53 ~36 ~35 ~-53 ~36 minecraft:glass
fill ~36 ~-53 ~36 ~42 ~-53 ~36 minecraft:air
setblock ~43 ~-53 ~36 minecraft:deepslate_tiles
fill ~25 ~-53 ~37 ~26 ~-53 ~37 minecraft:deepslate_tiles
fill ~27 ~-53 ~37 ~41 ~-53 ~37 minecraft:air
fill ~42 ~-53 ~37 ~43 ~-53 ~37 minecraft:deepslate_tiles
fill ~25 ~-53 ~38 ~26 ~-53 ~38 minecraft:deepslate_tiles
fill ~27 ~-53 ~38 ~41 ~-53 ~38 minecraft:air
fill ~42 ~-53 ~38 ~43 ~-53 ~38 minecraft:deepslate_tiles
fill ~26 ~-53 ~39 ~27 ~-53 ~39 minecraft:deepslate_tiles
fill ~28 ~-53 ~39 ~40 ~-53 ~39 minecraft:air
fill ~41 ~-53 ~39 ~42 ~-53 ~39 minecraft:deepslate_tiles
fill ~26 ~-53 ~40 ~27 ~-53 ~40 minecraft:deepslate_tiles
fill ~28 ~-53 ~40 ~40 ~-53 ~40 minecraft:air
fill ~41 ~-53 ~40 ~42 ~-53 ~40 minecraft:deepslate_tiles
fill ~27 ~-53 ~41 ~29 ~-53 ~41 minecraft:deepslate_tiles
fill ~30 ~-53 ~41 ~38 ~-53 ~41 minecraft:air
fill ~39 ~-53 ~41 ~41 ~-53 ~41 minecraft:deepslate_tiles
fill ~28 ~-53 ~42 ~31 ~-53 ~42 minecraft:deepslate_tiles
fill ~32 ~-53 ~42 ~36 ~-53 ~42 minecraft:air
fill ~37 ~-53 ~42 ~40 ~-53 ~42 minecraft:deepslate_tiles
fill ~30 ~-53 ~43 ~38 ~-53 ~43 minecraft:deepslate_tiles
setblock ~34 ~-53 ~44 minecraft:deepslate_tiles
fill ~32 ~-53 ~66 ~36 ~-53 ~66 minecraft:polished_andesite
setblock ~32 ~-53 ~67 minecraft:polished_andesite
setblock ~33 ~-53 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-53 ~67 ~35 ~-53 ~67 minecraft:air
setblock ~36 ~-53 ~67 minecraft:polished_andesite
setblock ~32 ~-53 ~68 minecraft:polished_andesite
setblock ~33 ~-53 ~68 minecraft:air
setblock ~34 ~-53 ~68 minecraft:quartz_pillar
setblock ~35 ~-53 ~68 minecraft:air
setblock ~36 ~-53 ~68 minecraft:polished_andesite
setblock ~32 ~-53 ~69 minecraft:polished_andesite
fill ~33 ~-53 ~69 ~35 ~-53 ~69 minecraft:air
setblock ~36 ~-53 ~69 minecraft:polished_andesite
fill ~32 ~-53 ~70 ~36 ~-53 ~70 minecraft:polished_andesite
setblock ~34 ~-52 ~24 minecraft:deepslate_tiles
fill ~30 ~-52 ~25 ~38 ~-52 ~25 minecraft:deepslate_tiles
fill ~28 ~-52 ~26 ~31 ~-52 ~26 minecraft:deepslate_tiles
fill ~32 ~-52 ~26 ~36 ~-52 ~26 minecraft:air
fill ~37 ~-52 ~26 ~40 ~-52 ~26 minecraft:deepslate_tiles
fill ~27 ~-52 ~27 ~29 ~-52 ~27 minecraft:deepslate_tiles
fill ~30 ~-52 ~27 ~38 ~-52 ~27 minecraft:air
fill ~39 ~-52 ~27 ~41 ~-52 ~27 minecraft:deepslate_tiles
fill ~26 ~-52 ~28 ~27 ~-52 ~28 minecraft:deepslate_tiles
fill ~28 ~-52 ~28 ~40 ~-52 ~28 minecraft:air
fill ~41 ~-52 ~28 ~42 ~-52 ~28 minecraft:deepslate_tiles
fill ~26 ~-52 ~29 ~27 ~-52 ~29 minecraft:deepslate_tiles
fill ~28 ~-52 ~29 ~40 ~-52 ~29 minecraft:air
fill ~41 ~-52 ~29 ~42 ~-52 ~29 minecraft:deepslate_tiles
fill ~25 ~-52 ~30 ~26 ~-52 ~30 minecraft:deepslate_tiles
fill ~27 ~-52 ~30 ~41 ~-52 ~30 minecraft:air
fill ~42 ~-52 ~30 ~43 ~-52 ~30 minecraft:deepslate_tiles
fill ~25 ~-52 ~31 ~26 ~-52 ~31 minecraft:deepslate_tiles
fill ~27 ~-52 ~31 ~41 ~-52 ~31 minecraft:air
fill ~42 ~-52 ~31 ~43 ~-52 ~31 minecraft:deepslate_tiles
setblock ~25 ~-52 ~32 minecraft:deepslate_tiles
fill ~26 ~-52 ~32 ~32 ~-52 ~32 minecraft:air
fill ~33 ~-52 ~32 ~35 ~-52 ~32 minecraft:waxed_cut_copper
fill ~36 ~-52 ~32 ~42 ~-52 ~32 minecraft:air
setblock ~43 ~-52 ~32 minecraft:deepslate_tiles
setblock ~25 ~-52 ~33 minecraft:deepslate_tiles
fill ~26 ~-52 ~33 ~31 ~-52 ~33 minecraft:air
setblock ~32 ~-52 ~33 minecraft:waxed_cut_copper
fill ~33 ~-52 ~33 ~35 ~-52 ~33 minecraft:sea_lantern
setblock ~36 ~-52 ~33 minecraft:waxed_cut_copper
fill ~37 ~-52 ~33 ~42 ~-52 ~33 minecraft:air
setblock ~43 ~-52 ~33 minecraft:deepslate_tiles
fill ~24 ~-52 ~34 ~25 ~-52 ~34 minecraft:deepslate_tiles
fill ~26 ~-52 ~34 ~31 ~-52 ~34 minecraft:air
setblock ~32 ~-52 ~34 minecraft:waxed_cut_copper
fill ~33 ~-52 ~34 ~35 ~-52 ~34 minecraft:sea_lantern
setblock ~36 ~-52 ~34 minecraft:waxed_cut_copper
fill ~37 ~-52 ~34 ~42 ~-52 ~34 minecraft:air
fill ~43 ~-52 ~34 ~44 ~-52 ~34 minecraft:deepslate_tiles
setblock ~25 ~-52 ~35 minecraft:deepslate_tiles
fill ~26 ~-52 ~35 ~31 ~-52 ~35 minecraft:air
setblock ~32 ~-52 ~35 minecraft:waxed_cut_copper
fill ~33 ~-52 ~35 ~35 ~-52 ~35 minecraft:sea_lantern
setblock ~36 ~-52 ~35 minecraft:waxed_cut_copper
fill ~37 ~-52 ~35 ~42 ~-52 ~35 minecraft:air
setblock ~43 ~-52 ~35 minecraft:deepslate_tiles
setblock ~25 ~-52 ~36 minecraft:deepslate_tiles
fill ~26 ~-52 ~36 ~32 ~-52 ~36 minecraft:air
fill ~33 ~-52 ~36 ~35 ~-52 ~36 minecraft:waxed_cut_copper
fill ~36 ~-52 ~36 ~42 ~-52 ~36 minecraft:air
setblock ~43 ~-52 ~36 minecraft:deepslate_tiles
fill ~25 ~-52 ~37 ~26 ~-52 ~37 minecraft:deepslate_tiles
fill ~27 ~-52 ~37 ~41 ~-52 ~37 minecraft:air
fill ~42 ~-52 ~37 ~43 ~-52 ~37 minecraft:deepslate_tiles
fill ~25 ~-52 ~38 ~26 ~-52 ~38 minecraft:deepslate_tiles
fill ~27 ~-52 ~38 ~41 ~-52 ~38 minecraft:air
fill ~42 ~-52 ~38 ~43 ~-52 ~38 minecraft:deepslate_tiles
fill ~26 ~-52 ~39 ~27 ~-52 ~39 minecraft:deepslate_tiles
fill ~28 ~-52 ~39 ~40 ~-52 ~39 minecraft:air
fill ~41 ~-52 ~39 ~42 ~-52 ~39 minecraft:deepslate_tiles
fill ~26 ~-52 ~40 ~27 ~-52 ~40 minecraft:deepslate_tiles
fill ~28 ~-52 ~40 ~40 ~-52 ~40 minecraft:air
fill ~41 ~-52 ~40 ~42 ~-52 ~40 minecraft:deepslate_tiles
fill ~27 ~-52 ~41 ~29 ~-52 ~41 minecraft:deepslate_tiles
fill ~30 ~-52 ~41 ~38 ~-52 ~41 minecraft:air
fill ~39 ~-52 ~41 ~41 ~-52 ~41 minecraft:deepslate_tiles
fill ~28 ~-52 ~42 ~31 ~-52 ~42 minecraft:deepslate_tiles
fill ~32 ~-52 ~42 ~36 ~-52 ~42 minecraft:air
fill ~37 ~-52 ~42 ~40 ~-52 ~42 minecraft:deepslate_tiles
fill ~30 ~-52 ~43 ~38 ~-52 ~43 minecraft:deepslate_tiles
setblock ~34 ~-52 ~44 minecraft:deepslate_tiles
fill ~32 ~-52 ~66 ~36 ~-52 ~66 minecraft:polished_andesite
setblock ~32 ~-52 ~67 minecraft:polished_andesite
setblock ~33 ~-52 ~67 minecraft:air
setblock ~34 ~-52 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-52 ~67 minecraft:air
setblock ~36 ~-52 ~67 minecraft:polished_andesite
setblock ~32 ~-52 ~68 minecraft:polished_andesite
setblock ~33 ~-52 ~68 minecraft:air
setblock ~34 ~-52 ~68 minecraft:quartz_pillar
setblock ~35 ~-52 ~68 minecraft:air
setblock ~36 ~-52 ~68 minecraft:polished_andesite
setblock ~32 ~-52 ~69 minecraft:polished_andesite
fill ~33 ~-52 ~69 ~35 ~-52 ~69 minecraft:air
setblock ~36 ~-52 ~69 minecraft:polished_andesite
fill ~32 ~-52 ~70 ~36 ~-52 ~70 minecraft:polished_andesite
setblock ~34 ~-51 ~24 minecraft:sea_lantern
setblock ~30 ~-51 ~25 minecraft:deepslate_tiles
setblock ~31 ~-51 ~25 minecraft:sea_lantern
setblock ~32 ~-51 ~25 minecraft:deepslate_tiles
setblock ~33 ~-51 ~25 minecraft:sea_lantern
setblock ~34 ~-51 ~25 minecraft:deepslate_tiles
setblock ~35 ~-51 ~25 minecraft:sea_lantern
setblock ~36 ~-51 ~25 minecraft:deepslate_tiles
setblock ~37 ~-51 ~25 minecraft:sea_lantern
setblock ~38 ~-51 ~25 minecraft:deepslate_tiles
setblock ~28 ~-51 ~26 minecraft:sea_lantern
setblock ~29 ~-51 ~26 minecraft:deepslate_tiles
setblock ~30 ~-51 ~26 minecraft:sea_lantern
setblock ~31 ~-51 ~26 minecraft:deepslate_tiles
fill ~32 ~-51 ~26 ~36 ~-51 ~26 minecraft:air
setblock ~37 ~-51 ~26 minecraft:deepslate_tiles
setblock ~38 ~-51 ~26 minecraft:sea_lantern
setblock ~39 ~-51 ~26 minecraft:deepslate_tiles
setblock ~40 ~-51 ~26 minecraft:sea_lantern
setblock ~27 ~-51 ~27 minecraft:sea_lantern
setblock ~28 ~-51 ~27 minecraft:deepslate_tiles
setblock ~29 ~-51 ~27 minecraft:sea_lantern
fill ~30 ~-51 ~27 ~38 ~-51 ~27 minecraft:air
setblock ~39 ~-51 ~27 minecraft:sea_lantern
setblock ~40 ~-51 ~27 minecraft:deepslate_tiles
setblock ~41 ~-51 ~27 minecraft:sea_lantern
setblock ~26 ~-51 ~28 minecraft:sea_lantern
setblock ~27 ~-51 ~28 minecraft:deepslate_tiles
fill ~28 ~-51 ~28 ~40 ~-51 ~28 minecraft:air
setblock ~41 ~-51 ~28 minecraft:deepslate_tiles
setblock ~42 ~-51 ~28 minecraft:sea_lantern
setblock ~26 ~-51 ~29 minecraft:deepslate_tiles
setblock ~27 ~-51 ~29 minecraft:sea_lantern
fill ~28 ~-51 ~29 ~40 ~-51 ~29 minecraft:air
setblock ~41 ~-51 ~29 minecraft:sea_lantern
setblock ~42 ~-51 ~29 minecraft:deepslate_tiles
setblock ~25 ~-51 ~30 minecraft:deepslate_tiles
setblock ~26 ~-51 ~30 minecraft:sea_lantern
fill ~27 ~-51 ~30 ~41 ~-51 ~30 minecraft:air
setblock ~42 ~-51 ~30 minecraft:sea_lantern
setblock ~43 ~-51 ~30 minecraft:deepslate_tiles
setblock ~25 ~-51 ~31 minecraft:sea_lantern
setblock ~26 ~-51 ~31 minecraft:deepslate_tiles
fill ~27 ~-51 ~31 ~41 ~-51 ~31 minecraft:air
setblock ~42 ~-51 ~31 minecraft:deepslate_tiles
setblock ~43 ~-51 ~31 minecraft:sea_lantern
setblock ~25 ~-51 ~32 minecraft:deepslate_tiles
fill ~26 ~-51 ~32 ~32 ~-51 ~32 minecraft:air
fill ~33 ~-51 ~32 ~35 ~-51 ~32 minecraft:glass
fill ~36 ~-51 ~32 ~42 ~-51 ~32 minecraft:air
setblock ~43 ~-51 ~32 minecraft:deepslate_tiles
setblock ~25 ~-51 ~33 minecraft:sea_lantern
fill ~26 ~-51 ~33 ~31 ~-51 ~33 minecraft:air
setblock ~32 ~-51 ~33 minecraft:glass
fill ~33 ~-51 ~33 ~35 ~-51 ~33 minecraft:sea_lantern
setblock ~36 ~-51 ~33 minecraft:glass
fill ~37 ~-51 ~33 ~42 ~-51 ~33 minecraft:air
setblock ~43 ~-51 ~33 minecraft:sea_lantern
setblock ~24 ~-51 ~34 minecraft:sea_lantern
setblock ~25 ~-51 ~34 minecraft:deepslate_tiles
fill ~26 ~-51 ~34 ~31 ~-51 ~34 minecraft:air
setblock ~32 ~-51 ~34 minecraft:glass
fill ~33 ~-51 ~34 ~35 ~-51 ~34 minecraft:sea_lantern
setblock ~36 ~-51 ~34 minecraft:glass
fill ~37 ~-51 ~34 ~42 ~-51 ~34 minecraft:air
setblock ~43 ~-51 ~34 minecraft:deepslate_tiles
setblock ~44 ~-51 ~34 minecraft:sea_lantern
setblock ~25 ~-51 ~35 minecraft:sea_lantern
fill ~26 ~-51 ~35 ~31 ~-51 ~35 minecraft:air
setblock ~32 ~-51 ~35 minecraft:glass
fill ~33 ~-51 ~35 ~35 ~-51 ~35 minecraft:sea_lantern
setblock ~36 ~-51 ~35 minecraft:glass
fill ~37 ~-51 ~35 ~42 ~-51 ~35 minecraft:air
setblock ~43 ~-51 ~35 minecraft:sea_lantern
setblock ~25 ~-51 ~36 minecraft:deepslate_tiles
fill ~26 ~-51 ~36 ~32 ~-51 ~36 minecraft:air
fill ~33 ~-51 ~36 ~35 ~-51 ~36 minecraft:glass
fill ~36 ~-51 ~36 ~42 ~-51 ~36 minecraft:air
setblock ~43 ~-51 ~36 minecraft:deepslate_tiles
setblock ~25 ~-51 ~37 minecraft:sea_lantern
setblock ~26 ~-51 ~37 minecraft:deepslate_tiles
fill ~27 ~-51 ~37 ~41 ~-51 ~37 minecraft:air
setblock ~42 ~-51 ~37 minecraft:deepslate_tiles
setblock ~43 ~-51 ~37 minecraft:sea_lantern
setblock ~25 ~-51 ~38 minecraft:deepslate_tiles
setblock ~26 ~-51 ~38 minecraft:sea_lantern
fill ~27 ~-51 ~38 ~41 ~-51 ~38 minecraft:air
setblock ~42 ~-51 ~38 minecraft:sea_lantern
setblock ~43 ~-51 ~38 minecraft:deepslate_tiles
setblock ~26 ~-51 ~39 minecraft:deepslate_tiles
setblock ~27 ~-51 ~39 minecraft:sea_lantern
fill ~28 ~-51 ~39 ~40 ~-51 ~39 minecraft:air
setblock ~41 ~-51 ~39 minecraft:sea_lantern
setblock ~42 ~-51 ~39 minecraft:deepslate_tiles
setblock ~26 ~-51 ~40 minecraft:sea_lantern
setblock ~27 ~-51 ~40 minecraft:deepslate_tiles
fill ~28 ~-51 ~40 ~40 ~-51 ~40 minecraft:air
setblock ~41 ~-51 ~40 minecraft:deepslate_tiles
setblock ~42 ~-51 ~40 minecraft:sea_lantern
setblock ~27 ~-51 ~41 minecraft:sea_lantern
setblock ~28 ~-51 ~41 minecraft:deepslate_tiles
setblock ~29 ~-51 ~41 minecraft:sea_lantern
fill ~30 ~-51 ~41 ~38 ~-51 ~41 minecraft:air
setblock ~39 ~-51 ~41 minecraft:sea_lantern
setblock ~40 ~-51 ~41 minecraft:deepslate_tiles
setblock ~41 ~-51 ~41 minecraft:sea_lantern
setblock ~28 ~-51 ~42 minecraft:sea_lantern
setblock ~29 ~-51 ~42 minecraft:deepslate_tiles
setblock ~30 ~-51 ~42 minecraft:sea_lantern
setblock ~31 ~-51 ~42 minecraft:deepslate_tiles
fill ~32 ~-51 ~42 ~36 ~-51 ~42 minecraft:air
setblock ~37 ~-51 ~42 minecraft:deepslate_tiles
setblock ~38 ~-51 ~42 minecraft:sea_lantern
setblock ~39 ~-51 ~42 minecraft:deepslate_tiles
setblock ~40 ~-51 ~42 minecraft:sea_lantern
setblock ~30 ~-51 ~43 minecraft:deepslate_tiles
setblock ~31 ~-51 ~43 minecraft:sea_lantern
setblock ~32 ~-51 ~43 minecraft:deepslate_tiles
setblock ~33 ~-51 ~43 minecraft:sea_lantern
setblock ~34 ~-51 ~43 minecraft:deepslate_tiles
setblock ~35 ~-51 ~43 minecraft:sea_lantern
setblock ~36 ~-51 ~43 minecraft:deepslate_tiles
setblock ~37 ~-51 ~43 minecraft:sea_lantern
setblock ~38 ~-51 ~43 minecraft:deepslate_tiles
setblock ~34 ~-51 ~44 minecraft:sea_lantern
fill ~32 ~-51 ~66 ~36 ~-51 ~66 minecraft:polished_andesite
setblock ~32 ~-51 ~67 minecraft:polished_andesite
fill ~33 ~-51 ~67 ~34 ~-51 ~67 minecraft:air
setblock ~35 ~-51 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-51 ~67 minecraft:polished_andesite
setblock ~32 ~-51 ~68 minecraft:polished_andesite
setblock ~33 ~-51 ~68 minecraft:air
setblock ~34 ~-51 ~68 minecraft:quartz_pillar
setblock ~35 ~-51 ~68 minecraft:air
setblock ~36 ~-51 ~68 minecraft:polished_andesite
setblock ~32 ~-51 ~69 minecraft:polished_andesite
fill ~33 ~-51 ~69 ~35 ~-51 ~69 minecraft:air
setblock ~36 ~-51 ~69 minecraft:polished_andesite
fill ~32 ~-51 ~70 ~36 ~-51 ~70 minecraft:polished_andesite
setblock ~34 ~-50 ~24 minecraft:deepslate_tiles
fill ~30 ~-50 ~25 ~38 ~-50 ~25 minecraft:deepslate_tiles
fill ~28 ~-50 ~26 ~31 ~-50 ~26 minecraft:deepslate_tiles
fill ~32 ~-50 ~26 ~36 ~-50 ~26 minecraft:air
fill ~37 ~-50 ~26 ~40 ~-50 ~26 minecraft:deepslate_tiles
fill ~27 ~-50 ~27 ~29 ~-50 ~27 minecraft:deepslate_tiles
fill ~30 ~-50 ~27 ~38 ~-50 ~27 minecraft:air
fill ~39 ~-50 ~27 ~41 ~-50 ~27 minecraft:deepslate_tiles
fill ~26 ~-50 ~28 ~27 ~-50 ~28 minecraft:deepslate_tiles
fill ~28 ~-50 ~28 ~40 ~-50 ~28 minecraft:air
fill ~41 ~-50 ~28 ~42 ~-50 ~28 minecraft:deepslate_tiles
fill ~26 ~-50 ~29 ~27 ~-50 ~29 minecraft:deepslate_tiles
fill ~28 ~-50 ~29 ~40 ~-50 ~29 minecraft:air
fill ~41 ~-50 ~29 ~42 ~-50 ~29 minecraft:deepslate_tiles
fill ~25 ~-50 ~30 ~26 ~-50 ~30 minecraft:deepslate_tiles
fill ~27 ~-50 ~30 ~41 ~-50 ~30 minecraft:air
fill ~42 ~-50 ~30 ~43 ~-50 ~30 minecraft:deepslate_tiles
fill ~25 ~-50 ~31 ~26 ~-50 ~31 minecraft:deepslate_tiles
fill ~27 ~-50 ~31 ~41 ~-50 ~31 minecraft:air
fill ~42 ~-50 ~31 ~43 ~-50 ~31 minecraft:deepslate_tiles
setblock ~25 ~-50 ~32 minecraft:deepslate_tiles
fill ~26 ~-50 ~32 ~32 ~-50 ~32 minecraft:air
fill ~33 ~-50 ~32 ~35 ~-50 ~32 minecraft:glass
fill ~36 ~-50 ~32 ~42 ~-50 ~32 minecraft:air
setblock ~43 ~-50 ~32 minecraft:deepslate_tiles
setblock ~25 ~-50 ~33 minecraft:deepslate_tiles
fill ~26 ~-50 ~33 ~31 ~-50 ~33 minecraft:air
setblock ~32 ~-50 ~33 minecraft:glass
fill ~33 ~-50 ~33 ~35 ~-50 ~33 minecraft:sea_lantern
setblock ~36 ~-50 ~33 minecraft:glass
fill ~37 ~-50 ~33 ~42 ~-50 ~33 minecraft:air
setblock ~43 ~-50 ~33 minecraft:deepslate_tiles
fill ~24 ~-50 ~34 ~25 ~-50 ~34 minecraft:deepslate_tiles
fill ~26 ~-50 ~34 ~31 ~-50 ~34 minecraft:air
setblock ~32 ~-50 ~34 minecraft:glass
fill ~33 ~-50 ~34 ~35 ~-50 ~34 minecraft:sea_lantern
setblock ~36 ~-50 ~34 minecraft:glass
fill ~37 ~-50 ~34 ~42 ~-50 ~34 minecraft:air
fill ~43 ~-50 ~34 ~44 ~-50 ~34 minecraft:deepslate_tiles
setblock ~25 ~-50 ~35 minecraft:deepslate_tiles
fill ~26 ~-50 ~35 ~31 ~-50 ~35 minecraft:air
setblock ~32 ~-50 ~35 minecraft:glass
fill ~33 ~-50 ~35 ~35 ~-50 ~35 minecraft:sea_lantern
setblock ~36 ~-50 ~35 minecraft:glass
fill ~37 ~-50 ~35 ~42 ~-50 ~35 minecraft:air
setblock ~43 ~-50 ~35 minecraft:deepslate_tiles
setblock ~25 ~-50 ~36 minecraft:deepslate_tiles
fill ~26 ~-50 ~36 ~32 ~-50 ~36 minecraft:air
fill ~33 ~-50 ~36 ~35 ~-50 ~36 minecraft:glass
fill ~36 ~-50 ~36 ~42 ~-50 ~36 minecraft:air
setblock ~43 ~-50 ~36 minecraft:deepslate_tiles
fill ~25 ~-50 ~37 ~26 ~-50 ~37 minecraft:deepslate_tiles
fill ~27 ~-50 ~37 ~41 ~-50 ~37 minecraft:air
fill ~42 ~-50 ~37 ~43 ~-50 ~37 minecraft:deepslate_tiles
fill ~25 ~-50 ~38 ~26 ~-50 ~38 minecraft:deepslate_tiles
fill ~27 ~-50 ~38 ~41 ~-50 ~38 minecraft:air
fill ~42 ~-50 ~38 ~43 ~-50 ~38 minecraft:deepslate_tiles
fill ~26 ~-50 ~39 ~27 ~-50 ~39 minecraft:deepslate_tiles
fill ~28 ~-50 ~39 ~40 ~-50 ~39 minecraft:air
fill ~41 ~-50 ~39 ~42 ~-50 ~39 minecraft:deepslate_tiles
fill ~26 ~-50 ~40 ~27 ~-50 ~40 minecraft:deepslate_tiles
fill ~28 ~-50 ~40 ~40 ~-50 ~40 minecraft:air
fill ~41 ~-50 ~40 ~42 ~-50 ~40 minecraft:deepslate_tiles
fill ~27 ~-50 ~41 ~29 ~-50 ~41 minecraft:deepslate_tiles
fill ~30 ~-50 ~41 ~38 ~-50 ~41 minecraft:air
fill ~39 ~-50 ~41 ~41 ~-50 ~41 minecraft:deepslate_tiles
fill ~28 ~-50 ~42 ~31 ~-50 ~42 minecraft:deepslate_tiles
fill ~32 ~-50 ~42 ~36 ~-50 ~42 minecraft:air
fill ~37 ~-50 ~42 ~40 ~-50 ~42 minecraft:deepslate_tiles
fill ~30 ~-50 ~43 ~38 ~-50 ~43 minecraft:deepslate_tiles
setblock ~34 ~-50 ~44 minecraft:deepslate_tiles
fill ~32 ~-50 ~66 ~36 ~-50 ~66 minecraft:polished_andesite
setblock ~32 ~-50 ~67 minecraft:polished_andesite
fill ~33 ~-50 ~67 ~35 ~-50 ~67 minecraft:air
setblock ~36 ~-50 ~67 minecraft:polished_andesite
setblock ~32 ~-50 ~68 minecraft:polished_andesite
setblock ~33 ~-50 ~68 minecraft:air
setblock ~34 ~-50 ~68 minecraft:quartz_pillar
setblock ~35 ~-50 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-50 ~68 minecraft:polished_andesite
setblock ~32 ~-50 ~69 minecraft:polished_andesite
fill ~33 ~-50 ~69 ~35 ~-50 ~69 minecraft:air
setblock ~36 ~-50 ~69 minecraft:polished_andesite
fill ~32 ~-50 ~70 ~36 ~-50 ~70 minecraft:polished_andesite
setblock ~34 ~-49 ~24 minecraft:deepslate_tiles
fill ~30 ~-49 ~25 ~38 ~-49 ~25 minecraft:deepslate_tiles
fill ~28 ~-49 ~26 ~31 ~-49 ~26 minecraft:deepslate_tiles
fill ~32 ~-49 ~26 ~36 ~-49 ~26 minecraft:air
fill ~37 ~-49 ~26 ~40 ~-49 ~26 minecraft:deepslate_tiles
fill ~27 ~-49 ~27 ~29 ~-49 ~27 minecraft:deepslate_tiles
fill ~30 ~-49 ~27 ~38 ~-49 ~27 minecraft:air
fill ~39 ~-49 ~27 ~41 ~-49 ~27 minecraft:deepslate_tiles
fill ~26 ~-49 ~28 ~27 ~-49 ~28 minecraft:deepslate_tiles
fill ~28 ~-49 ~28 ~40 ~-49 ~28 minecraft:air
fill ~41 ~-49 ~28 ~42 ~-49 ~28 minecraft:deepslate_tiles
fill ~26 ~-49 ~29 ~27 ~-49 ~29 minecraft:deepslate_tiles
fill ~28 ~-49 ~29 ~40 ~-49 ~29 minecraft:air
fill ~41 ~-49 ~29 ~42 ~-49 ~29 minecraft:deepslate_tiles
fill ~25 ~-49 ~30 ~26 ~-49 ~30 minecraft:deepslate_tiles
fill ~27 ~-49 ~30 ~41 ~-49 ~30 minecraft:air
fill ~42 ~-49 ~30 ~43 ~-49 ~30 minecraft:deepslate_tiles
fill ~25 ~-49 ~31 ~26 ~-49 ~31 minecraft:deepslate_tiles
fill ~27 ~-49 ~31 ~41 ~-49 ~31 minecraft:air
fill ~42 ~-49 ~31 ~43 ~-49 ~31 minecraft:deepslate_tiles
setblock ~25 ~-49 ~32 minecraft:deepslate_tiles
fill ~26 ~-49 ~32 ~32 ~-49 ~32 minecraft:air
fill ~33 ~-49 ~32 ~35 ~-49 ~32 minecraft:waxed_cut_copper
fill ~36 ~-49 ~32 ~42 ~-49 ~32 minecraft:air
setblock ~43 ~-49 ~32 minecraft:deepslate_tiles
setblock ~25 ~-49 ~33 minecraft:deepslate_tiles
fill ~26 ~-49 ~33 ~31 ~-49 ~33 minecraft:air
fill ~32 ~-49 ~33 ~36 ~-49 ~33 minecraft:waxed_cut_copper
fill ~37 ~-49 ~33 ~42 ~-49 ~33 minecraft:air
setblock ~43 ~-49 ~33 minecraft:deepslate_tiles
fill ~24 ~-49 ~34 ~25 ~-49 ~34 minecraft:deepslate_tiles
fill ~26 ~-49 ~34 ~31 ~-49 ~34 minecraft:air
fill ~32 ~-49 ~34 ~36 ~-49 ~34 minecraft:waxed_cut_copper
fill ~37 ~-49 ~34 ~42 ~-49 ~34 minecraft:air
fill ~43 ~-49 ~34 ~44 ~-49 ~34 minecraft:deepslate_tiles
setblock ~25 ~-49 ~35 minecraft:deepslate_tiles
fill ~26 ~-49 ~35 ~31 ~-49 ~35 minecraft:air
fill ~32 ~-49 ~35 ~36 ~-49 ~35 minecraft:waxed_cut_copper
fill ~37 ~-49 ~35 ~42 ~-49 ~35 minecraft:air
setblock ~43 ~-49 ~35 minecraft:deepslate_tiles
setblock ~25 ~-49 ~36 minecraft:deepslate_tiles
fill ~26 ~-49 ~36 ~32 ~-49 ~36 minecraft:air
fill ~33 ~-49 ~36 ~35 ~-49 ~36 minecraft:waxed_cut_copper
fill ~36 ~-49 ~36 ~42 ~-49 ~36 minecraft:air
setblock ~43 ~-49 ~36 minecraft:deepslate_tiles
fill ~25 ~-49 ~37 ~26 ~-49 ~37 minecraft:deepslate_tiles
fill ~27 ~-49 ~37 ~41 ~-49 ~37 minecraft:air
fill ~42 ~-49 ~37 ~43 ~-49 ~37 minecraft:deepslate_tiles
fill ~25 ~-49 ~38 ~26 ~-49 ~38 minecraft:deepslate_tiles
fill ~27 ~-49 ~38 ~41 ~-49 ~38 minecraft:air
fill ~42 ~-49 ~38 ~43 ~-49 ~38 minecraft:deepslate_tiles
fill ~26 ~-49 ~39 ~27 ~-49 ~39 minecraft:deepslate_tiles
fill ~28 ~-49 ~39 ~40 ~-49 ~39 minecraft:air
fill ~41 ~-49 ~39 ~42 ~-49 ~39 minecraft:deepslate_tiles
fill ~26 ~-49 ~40 ~27 ~-49 ~40 minecraft:deepslate_tiles
fill ~28 ~-49 ~40 ~40 ~-49 ~40 minecraft:air
fill ~41 ~-49 ~40 ~42 ~-49 ~40 minecraft:deepslate_tiles
fill ~27 ~-49 ~41 ~29 ~-49 ~41 minecraft:deepslate_tiles
fill ~30 ~-49 ~41 ~38 ~-49 ~41 minecraft:air
fill ~39 ~-49 ~41 ~41 ~-49 ~41 minecraft:deepslate_tiles
fill ~28 ~-49 ~42 ~31 ~-49 ~42 minecraft:deepslate_tiles
fill ~32 ~-49 ~42 ~36 ~-49 ~42 minecraft:air
fill ~37 ~-49 ~42 ~40 ~-49 ~42 minecraft:deepslate_tiles
fill ~30 ~-49 ~43 ~38 ~-49 ~43 minecraft:deepslate_tiles
setblock ~34 ~-49 ~44 minecraft:deepslate_tiles
fill ~32 ~-49 ~66 ~36 ~-49 ~66 minecraft:polished_andesite
setblock ~32 ~-49 ~67 minecraft:polished_andesite
fill ~33 ~-49 ~67 ~35 ~-49 ~67 minecraft:air
setblock ~36 ~-49 ~67 minecraft:polished_andesite
setblock ~32 ~-49 ~68 minecraft:polished_andesite
setblock ~33 ~-49 ~68 minecraft:air
setblock ~34 ~-49 ~68 minecraft:quartz_pillar
setblock ~35 ~-49 ~68 minecraft:air
setblock ~36 ~-49 ~68 minecraft:polished_andesite
setblock ~32 ~-49 ~69 minecraft:polished_andesite
fill ~33 ~-49 ~69 ~34 ~-49 ~69 minecraft:air
setblock ~35 ~-49 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-49 ~69 minecraft:polished_andesite
fill ~32 ~-49 ~70 ~36 ~-49 ~70 minecraft:polished_andesite
setblock ~34 ~-48 ~24 minecraft:deepslate_tiles
fill ~30 ~-48 ~25 ~38 ~-48 ~25 minecraft:deepslate_tiles
fill ~28 ~-48 ~26 ~31 ~-48 ~26 minecraft:deepslate_tiles
fill ~32 ~-48 ~26 ~36 ~-48 ~26 minecraft:air
fill ~37 ~-48 ~26 ~40 ~-48 ~26 minecraft:deepslate_tiles
fill ~27 ~-48 ~27 ~29 ~-48 ~27 minecraft:deepslate_tiles
fill ~30 ~-48 ~27 ~38 ~-48 ~27 minecraft:air
fill ~39 ~-48 ~27 ~41 ~-48 ~27 minecraft:deepslate_tiles
fill ~26 ~-48 ~28 ~27 ~-48 ~28 minecraft:deepslate_tiles
fill ~28 ~-48 ~28 ~40 ~-48 ~28 minecraft:air
fill ~41 ~-48 ~28 ~42 ~-48 ~28 minecraft:deepslate_tiles
fill ~26 ~-48 ~29 ~27 ~-48 ~29 minecraft:deepslate_tiles
fill ~28 ~-48 ~29 ~40 ~-48 ~29 minecraft:air
fill ~41 ~-48 ~29 ~42 ~-48 ~29 minecraft:deepslate_tiles
fill ~25 ~-48 ~30 ~26 ~-48 ~30 minecraft:deepslate_tiles
fill ~27 ~-48 ~30 ~41 ~-48 ~30 minecraft:air
fill ~42 ~-48 ~30 ~43 ~-48 ~30 minecraft:deepslate_tiles
fill ~25 ~-48 ~31 ~26 ~-48 ~31 minecraft:deepslate_tiles
fill ~27 ~-48 ~31 ~41 ~-48 ~31 minecraft:air
fill ~42 ~-48 ~31 ~43 ~-48 ~31 minecraft:deepslate_tiles
setblock ~25 ~-48 ~32 minecraft:deepslate_tiles
fill ~26 ~-48 ~32 ~42 ~-48 ~32 minecraft:air
setblock ~43 ~-48 ~32 minecraft:deepslate_tiles
setblock ~25 ~-48 ~33 minecraft:deepslate_tiles
fill ~26 ~-48 ~33 ~42 ~-48 ~33 minecraft:air
setblock ~43 ~-48 ~33 minecraft:deepslate_tiles
fill ~24 ~-48 ~34 ~25 ~-48 ~34 minecraft:deepslate_tiles
fill ~26 ~-48 ~34 ~33 ~-48 ~34 minecraft:air
setblock ~34 ~-48 ~34 minecraft:lightning_rod[facing=up]
fill ~35 ~-48 ~34 ~42 ~-48 ~34 minecraft:air
fill ~43 ~-48 ~34 ~44 ~-48 ~34 minecraft:deepslate_tiles
setblock ~25 ~-48 ~35 minecraft:deepslate_tiles
fill ~26 ~-48 ~35 ~42 ~-48 ~35 minecraft:air
setblock ~43 ~-48 ~35 minecraft:deepslate_tiles
setblock ~25 ~-48 ~36 minecraft:deepslate_tiles
fill ~26 ~-48 ~36 ~42 ~-48 ~36 minecraft:air
setblock ~43 ~-48 ~36 minecraft:deepslate_tiles
fill ~25 ~-48 ~37 ~26 ~-48 ~37 minecraft:deepslate_tiles
fill ~27 ~-48 ~37 ~41 ~-48 ~37 minecraft:air
fill ~42 ~-48 ~37 ~43 ~-48 ~37 minecraft:deepslate_tiles
fill ~25 ~-48 ~38 ~26 ~-48 ~38 minecraft:deepslate_tiles
fill ~27 ~-48 ~38 ~41 ~-48 ~38 minecraft:air
fill ~42 ~-48 ~38 ~43 ~-48 ~38 minecraft:deepslate_tiles
fill ~26 ~-48 ~39 ~27 ~-48 ~39 minecraft:deepslate_tiles
fill ~28 ~-48 ~39 ~40 ~-48 ~39 minecraft:air
fill ~41 ~-48 ~39 ~42 ~-48 ~39 minecraft:deepslate_tiles
fill ~26 ~-48 ~40 ~27 ~-48 ~40 minecraft:deepslate_tiles
fill ~28 ~-48 ~40 ~40 ~-48 ~40 minecraft:air
fill ~41 ~-48 ~40 ~42 ~-48 ~40 minecraft:deepslate_tiles
fill ~27 ~-48 ~41 ~29 ~-48 ~41 minecraft:deepslate_tiles
fill ~30 ~-48 ~41 ~38 ~-48 ~41 minecraft:air
fill ~39 ~-48 ~41 ~41 ~-48 ~41 minecraft:deepslate_tiles
fill ~28 ~-48 ~42 ~31 ~-48 ~42 minecraft:deepslate_tiles
fill ~32 ~-48 ~42 ~36 ~-48 ~42 minecraft:air
fill ~37 ~-48 ~42 ~40 ~-48 ~42 minecraft:deepslate_tiles
fill ~30 ~-48 ~43 ~38 ~-48 ~43 minecraft:deepslate_tiles
setblock ~34 ~-48 ~44 minecraft:deepslate_tiles
fill ~32 ~-48 ~66 ~36 ~-48 ~66 minecraft:polished_andesite
setblock ~32 ~-48 ~67 minecraft:polished_andesite
fill ~33 ~-48 ~67 ~35 ~-48 ~67 minecraft:air
setblock ~36 ~-48 ~67 minecraft:polished_andesite
setblock ~32 ~-48 ~68 minecraft:sea_lantern
setblock ~33 ~-48 ~68 minecraft:air
setblock ~34 ~-48 ~68 minecraft:quartz_pillar
setblock ~35 ~-48 ~68 minecraft:air
setblock ~36 ~-48 ~68 minecraft:sea_lantern
setblock ~32 ~-48 ~69 minecraft:polished_andesite
setblock ~33 ~-48 ~69 minecraft:air
setblock ~34 ~-48 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-48 ~69 minecraft:air
setblock ~36 ~-48 ~69 minecraft:polished_andesite
fill ~32 ~-48 ~70 ~36 ~-48 ~70 minecraft:polished_andesite
setblock ~34 ~-47 ~24 minecraft:sea_lantern
setblock ~30 ~-47 ~25 minecraft:deepslate_tiles
setblock ~31 ~-47 ~25 minecraft:sea_lantern
setblock ~32 ~-47 ~25 minecraft:deepslate_tiles
setblock ~33 ~-47 ~25 minecraft:sea_lantern
setblock ~34 ~-47 ~25 minecraft:deepslate_tiles
setblock ~35 ~-47 ~25 minecraft:sea_lantern
setblock ~36 ~-47 ~25 minecraft:deepslate_tiles
setblock ~37 ~-47 ~25 minecraft:sea_lantern
setblock ~38 ~-47 ~25 minecraft:deepslate_tiles
setblock ~28 ~-47 ~26 minecraft:sea_lantern
setblock ~29 ~-47 ~26 minecraft:deepslate_tiles
setblock ~30 ~-47 ~26 minecraft:sea_lantern
setblock ~31 ~-47 ~26 minecraft:deepslate_tiles
fill ~32 ~-47 ~26 ~36 ~-47 ~26 minecraft:air
setblock ~37 ~-47 ~26 minecraft:deepslate_tiles
setblock ~38 ~-47 ~26 minecraft:sea_lantern
setblock ~39 ~-47 ~26 minecraft:deepslate_tiles
setblock ~40 ~-47 ~26 minecraft:sea_lantern
setblock ~27 ~-47 ~27 minecraft:sea_lantern
setblock ~28 ~-47 ~27 minecraft:deepslate_tiles
setblock ~29 ~-47 ~27 minecraft:sea_lantern
fill ~30 ~-47 ~27 ~38 ~-47 ~27 minecraft:air
setblock ~39 ~-47 ~27 minecraft:sea_lantern
setblock ~40 ~-47 ~27 minecraft:deepslate_tiles
setblock ~41 ~-47 ~27 minecraft:sea_lantern
setblock ~26 ~-47 ~28 minecraft:sea_lantern
setblock ~27 ~-47 ~28 minecraft:deepslate_tiles
fill ~28 ~-47 ~28 ~40 ~-47 ~28 minecraft:air
setblock ~41 ~-47 ~28 minecraft:deepslate_tiles
setblock ~42 ~-47 ~28 minecraft:sea_lantern
setblock ~26 ~-47 ~29 minecraft:deepslate_tiles
setblock ~27 ~-47 ~29 minecraft:sea_lantern
fill ~28 ~-47 ~29 ~40 ~-47 ~29 minecraft:air
setblock ~41 ~-47 ~29 minecraft:sea_lantern
setblock ~42 ~-47 ~29 minecraft:deepslate_tiles
setblock ~25 ~-47 ~30 minecraft:deepslate_tiles
setblock ~26 ~-47 ~30 minecraft:sea_lantern
fill ~27 ~-47 ~30 ~41 ~-47 ~30 minecraft:air
setblock ~42 ~-47 ~30 minecraft:sea_lantern
setblock ~43 ~-47 ~30 minecraft:deepslate_tiles
setblock ~25 ~-47 ~31 minecraft:sea_lantern
setblock ~26 ~-47 ~31 minecraft:deepslate_tiles
fill ~27 ~-47 ~31 ~41 ~-47 ~31 minecraft:air
setblock ~42 ~-47 ~31 minecraft:deepslate_tiles
setblock ~43 ~-47 ~31 minecraft:sea_lantern
setblock ~25 ~-47 ~32 minecraft:deepslate_tiles
fill ~26 ~-47 ~32 ~42 ~-47 ~32 minecraft:air
setblock ~43 ~-47 ~32 minecraft:deepslate_tiles
setblock ~25 ~-47 ~33 minecraft:sea_lantern
fill ~26 ~-47 ~33 ~42 ~-47 ~33 minecraft:air
setblock ~43 ~-47 ~33 minecraft:sea_lantern
setblock ~24 ~-47 ~34 minecraft:sea_lantern
setblock ~25 ~-47 ~34 minecraft:deepslate_tiles
fill ~26 ~-47 ~34 ~42 ~-47 ~34 minecraft:air
setblock ~43 ~-47 ~34 minecraft:deepslate_tiles
setblock ~44 ~-47 ~34 minecraft:sea_lantern
setblock ~25 ~-47 ~35 minecraft:sea_lantern
fill ~26 ~-47 ~35 ~42 ~-47 ~35 minecraft:air
setblock ~43 ~-47 ~35 minecraft:sea_lantern
setblock ~25 ~-47 ~36 minecraft:deepslate_tiles
fill ~26 ~-47 ~36 ~42 ~-47 ~36 minecraft:air
setblock ~43 ~-47 ~36 minecraft:deepslate_tiles
setblock ~25 ~-47 ~37 minecraft:sea_lantern
setblock ~26 ~-47 ~37 minecraft:deepslate_tiles
fill ~27 ~-47 ~37 ~41 ~-47 ~37 minecraft:air
setblock ~42 ~-47 ~37 minecraft:deepslate_tiles
setblock ~43 ~-47 ~37 minecraft:sea_lantern
setblock ~25 ~-47 ~38 minecraft:deepslate_tiles
setblock ~26 ~-47 ~38 minecraft:sea_lantern
fill ~27 ~-47 ~38 ~41 ~-47 ~38 minecraft:air
setblock ~42 ~-47 ~38 minecraft:sea_lantern
setblock ~43 ~-47 ~38 minecraft:deepslate_tiles
setblock ~26 ~-47 ~39 minecraft:deepslate_tiles
setblock ~27 ~-47 ~39 minecraft:sea_lantern
fill ~28 ~-47 ~39 ~40 ~-47 ~39 minecraft:air
setblock ~41 ~-47 ~39 minecraft:sea_lantern
setblock ~42 ~-47 ~39 minecraft:deepslate_tiles
setblock ~26 ~-47 ~40 minecraft:sea_lantern
setblock ~27 ~-47 ~40 minecraft:deepslate_tiles
fill ~28 ~-47 ~40 ~40 ~-47 ~40 minecraft:air
setblock ~41 ~-47 ~40 minecraft:deepslate_tiles
setblock ~42 ~-47 ~40 minecraft:sea_lantern
setblock ~27 ~-47 ~41 minecraft:sea_lantern
setblock ~28 ~-47 ~41 minecraft:deepslate_tiles
setblock ~29 ~-47 ~41 minecraft:sea_lantern
fill ~30 ~-47 ~41 ~38 ~-47 ~41 minecraft:air
setblock ~39 ~-47 ~41 minecraft:sea_lantern
setblock ~40 ~-47 ~41 minecraft:deepslate_tiles
setblock ~41 ~-47 ~41 minecraft:sea_lantern
setblock ~28 ~-47 ~42 minecraft:sea_lantern
setblock ~29 ~-47 ~42 minecraft:deepslate_tiles
setblock ~30 ~-47 ~42 minecraft:sea_lantern
setblock ~31 ~-47 ~42 minecraft:deepslate_tiles
fill ~32 ~-47 ~42 ~36 ~-47 ~42 minecraft:air
setblock ~37 ~-47 ~42 minecraft:deepslate_tiles
setblock ~38 ~-47 ~42 minecraft:sea_lantern
setblock ~39 ~-47 ~42 minecraft:deepslate_tiles
setblock ~40 ~-47 ~42 minecraft:sea_lantern
setblock ~30 ~-47 ~43 minecraft:deepslate_tiles
setblock ~31 ~-47 ~43 minecraft:sea_lantern
setblock ~32 ~-47 ~43 minecraft:deepslate_tiles
setblock ~33 ~-47 ~43 minecraft:sea_lantern
setblock ~34 ~-47 ~43 minecraft:deepslate_tiles
setblock ~35 ~-47 ~43 minecraft:sea_lantern
setblock ~36 ~-47 ~43 minecraft:deepslate_tiles
setblock ~37 ~-47 ~43 minecraft:sea_lantern
setblock ~38 ~-47 ~43 minecraft:deepslate_tiles
setblock ~34 ~-47 ~44 minecraft:sea_lantern
fill ~32 ~-47 ~66 ~36 ~-47 ~66 minecraft:polished_andesite
setblock ~32 ~-47 ~67 minecraft:polished_andesite
fill ~33 ~-47 ~67 ~35 ~-47 ~67 minecraft:air
setblock ~36 ~-47 ~67 minecraft:polished_andesite
setblock ~32 ~-47 ~68 minecraft:polished_andesite
setblock ~33 ~-47 ~68 minecraft:air
setblock ~34 ~-47 ~68 minecraft:quartz_pillar
setblock ~35 ~-47 ~68 minecraft:air
setblock ~36 ~-47 ~68 minecraft:polished_andesite
setblock ~32 ~-47 ~69 minecraft:polished_andesite
setblock ~33 ~-47 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-47 ~69 ~35 ~-47 ~69 minecraft:air
setblock ~36 ~-47 ~69 minecraft:polished_andesite
fill ~32 ~-47 ~70 ~36 ~-47 ~70 minecraft:polished_andesite
setblock ~34 ~-46 ~24 minecraft:deepslate_tiles
fill ~30 ~-46 ~25 ~38 ~-46 ~25 minecraft:deepslate_tiles
fill ~28 ~-46 ~26 ~31 ~-46 ~26 minecraft:deepslate_tiles
fill ~32 ~-46 ~26 ~36 ~-46 ~26 minecraft:air
fill ~37 ~-46 ~26 ~40 ~-46 ~26 minecraft:deepslate_tiles
fill ~27 ~-46 ~27 ~29 ~-46 ~27 minecraft:deepslate_tiles
fill ~30 ~-46 ~27 ~38 ~-46 ~27 minecraft:air
fill ~39 ~-46 ~27 ~41 ~-46 ~27 minecraft:deepslate_tiles
fill ~26 ~-46 ~28 ~27 ~-46 ~28 minecraft:deepslate_tiles
fill ~28 ~-46 ~28 ~40 ~-46 ~28 minecraft:air
fill ~41 ~-46 ~28 ~42 ~-46 ~28 minecraft:deepslate_tiles
fill ~26 ~-46 ~29 ~27 ~-46 ~29 minecraft:deepslate_tiles
fill ~28 ~-46 ~29 ~40 ~-46 ~29 minecraft:air
fill ~41 ~-46 ~29 ~42 ~-46 ~29 minecraft:deepslate_tiles
fill ~25 ~-46 ~30 ~26 ~-46 ~30 minecraft:deepslate_tiles
fill ~27 ~-46 ~30 ~41 ~-46 ~30 minecraft:air
fill ~42 ~-46 ~30 ~43 ~-46 ~30 minecraft:deepslate_tiles
fill ~25 ~-46 ~31 ~26 ~-46 ~31 minecraft:deepslate_tiles
fill ~27 ~-46 ~31 ~41 ~-46 ~31 minecraft:air
fill ~42 ~-46 ~31 ~43 ~-46 ~31 minecraft:deepslate_tiles
setblock ~25 ~-46 ~32 minecraft:deepslate_tiles
fill ~26 ~-46 ~32 ~42 ~-46 ~32 minecraft:air
setblock ~43 ~-46 ~32 minecraft:deepslate_tiles
setblock ~25 ~-46 ~33 minecraft:deepslate_tiles
fill ~26 ~-46 ~33 ~42 ~-46 ~33 minecraft:air
setblock ~43 ~-46 ~33 minecraft:deepslate_tiles
fill ~24 ~-46 ~34 ~25 ~-46 ~34 minecraft:deepslate_tiles
fill ~26 ~-46 ~34 ~42 ~-46 ~34 minecraft:air
fill ~43 ~-46 ~34 ~44 ~-46 ~34 minecraft:deepslate_tiles
setblock ~25 ~-46 ~35 minecraft:deepslate_tiles
fill ~26 ~-46 ~35 ~42 ~-46 ~35 minecraft:air
setblock ~43 ~-46 ~35 minecraft:deepslate_tiles
setblock ~25 ~-46 ~36 minecraft:deepslate_tiles
fill ~26 ~-46 ~36 ~42 ~-46 ~36 minecraft:air
setblock ~43 ~-46 ~36 minecraft:deepslate_tiles
fill ~25 ~-46 ~37 ~26 ~-46 ~37 minecraft:deepslate_tiles
fill ~27 ~-46 ~37 ~41 ~-46 ~37 minecraft:air
fill ~42 ~-46 ~37 ~43 ~-46 ~37 minecraft:deepslate_tiles
fill ~25 ~-46 ~38 ~26 ~-46 ~38 minecraft:deepslate_tiles
fill ~27 ~-46 ~38 ~41 ~-46 ~38 minecraft:air
fill ~42 ~-46 ~38 ~43 ~-46 ~38 minecraft:deepslate_tiles
fill ~26 ~-46 ~39 ~27 ~-46 ~39 minecraft:deepslate_tiles
fill ~28 ~-46 ~39 ~40 ~-46 ~39 minecraft:air
fill ~41 ~-46 ~39 ~42 ~-46 ~39 minecraft:deepslate_tiles
fill ~26 ~-46 ~40 ~27 ~-46 ~40 minecraft:deepslate_tiles
fill ~28 ~-46 ~40 ~40 ~-46 ~40 minecraft:air
fill ~41 ~-46 ~40 ~42 ~-46 ~40 minecraft:deepslate_tiles
fill ~27 ~-46 ~41 ~29 ~-46 ~41 minecraft:deepslate_tiles
fill ~30 ~-46 ~41 ~38 ~-46 ~41 minecraft:air
fill ~39 ~-46 ~41 ~41 ~-46 ~41 minecraft:deepslate_tiles
fill ~28 ~-46 ~42 ~31 ~-46 ~42 minecraft:deepslate_tiles
fill ~32 ~-46 ~42 ~36 ~-46 ~42 minecraft:air
fill ~37 ~-46 ~42 ~40 ~-46 ~42 minecraft:deepslate_tiles
fill ~30 ~-46 ~43 ~38 ~-46 ~43 minecraft:deepslate_tiles
setblock ~34 ~-46 ~44 minecraft:deepslate_tiles
fill ~32 ~-46 ~66 ~36 ~-46 ~66 minecraft:polished_andesite
setblock ~32 ~-46 ~67 minecraft:polished_andesite
fill ~33 ~-46 ~67 ~35 ~-46 ~67 minecraft:air
setblock ~36 ~-46 ~67 minecraft:polished_andesite
setblock ~32 ~-46 ~68 minecraft:polished_andesite
setblock ~33 ~-46 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-46 ~68 minecraft:quartz_pillar
setblock ~35 ~-46 ~68 minecraft:air
setblock ~36 ~-46 ~68 minecraft:polished_andesite
setblock ~32 ~-46 ~69 minecraft:polished_andesite
fill ~33 ~-46 ~69 ~35 ~-46 ~69 minecraft:air
setblock ~36 ~-46 ~69 minecraft:polished_andesite
fill ~32 ~-46 ~70 ~36 ~-46 ~70 minecraft:polished_andesite
setblock ~34 ~-45 ~24 minecraft:deepslate_tiles
fill ~30 ~-45 ~25 ~38 ~-45 ~25 minecraft:deepslate_tiles
fill ~28 ~-45 ~26 ~31 ~-45 ~26 minecraft:deepslate_tiles
fill ~32 ~-45 ~26 ~36 ~-45 ~26 minecraft:air
fill ~37 ~-45 ~26 ~40 ~-45 ~26 minecraft:deepslate_tiles
fill ~27 ~-45 ~27 ~29 ~-45 ~27 minecraft:deepslate_tiles
fill ~30 ~-45 ~27 ~38 ~-45 ~27 minecraft:air
fill ~39 ~-45 ~27 ~41 ~-45 ~27 minecraft:deepslate_tiles
fill ~26 ~-45 ~28 ~27 ~-45 ~28 minecraft:deepslate_tiles
fill ~28 ~-45 ~28 ~40 ~-45 ~28 minecraft:air
fill ~41 ~-45 ~28 ~42 ~-45 ~28 minecraft:deepslate_tiles
fill ~26 ~-45 ~29 ~27 ~-45 ~29 minecraft:deepslate_tiles
fill ~28 ~-45 ~29 ~40 ~-45 ~29 minecraft:air
fill ~41 ~-45 ~29 ~42 ~-45 ~29 minecraft:deepslate_tiles
fill ~25 ~-45 ~30 ~26 ~-45 ~30 minecraft:deepslate_tiles
fill ~27 ~-45 ~30 ~41 ~-45 ~30 minecraft:air
fill ~42 ~-45 ~30 ~43 ~-45 ~30 minecraft:deepslate_tiles
fill ~25 ~-45 ~31 ~26 ~-45 ~31 minecraft:deepslate_tiles
fill ~27 ~-45 ~31 ~41 ~-45 ~31 minecraft:air
fill ~42 ~-45 ~31 ~43 ~-45 ~31 minecraft:deepslate_tiles
setblock ~25 ~-45 ~32 minecraft:deepslate_tiles
fill ~26 ~-45 ~32 ~42 ~-45 ~32 minecraft:air
setblock ~43 ~-45 ~32 minecraft:deepslate_tiles
setblock ~25 ~-45 ~33 minecraft:deepslate_tiles
fill ~26 ~-45 ~33 ~42 ~-45 ~33 minecraft:air
setblock ~43 ~-45 ~33 minecraft:deepslate_tiles
fill ~24 ~-45 ~34 ~25 ~-45 ~34 minecraft:deepslate_tiles
fill ~26 ~-45 ~34 ~42 ~-45 ~34 minecraft:air
fill ~43 ~-45 ~34 ~44 ~-45 ~34 minecraft:deepslate_tiles
setblock ~25 ~-45 ~35 minecraft:deepslate_tiles
fill ~26 ~-45 ~35 ~42 ~-45 ~35 minecraft:air
setblock ~43 ~-45 ~35 minecraft:deepslate_tiles
setblock ~25 ~-45 ~36 minecraft:deepslate_tiles
fill ~26 ~-45 ~36 ~42 ~-45 ~36 minecraft:air
setblock ~43 ~-45 ~36 minecraft:deepslate_tiles
fill ~25 ~-45 ~37 ~26 ~-45 ~37 minecraft:deepslate_tiles
fill ~27 ~-45 ~37 ~41 ~-45 ~37 minecraft:air
fill ~42 ~-45 ~37 ~43 ~-45 ~37 minecraft:deepslate_tiles
fill ~25 ~-45 ~38 ~26 ~-45 ~38 minecraft:deepslate_tiles
fill ~27 ~-45 ~38 ~41 ~-45 ~38 minecraft:air
fill ~42 ~-45 ~38 ~43 ~-45 ~38 minecraft:deepslate_tiles
fill ~26 ~-45 ~39 ~27 ~-45 ~39 minecraft:deepslate_tiles
fill ~28 ~-45 ~39 ~40 ~-45 ~39 minecraft:air
fill ~41 ~-45 ~39 ~42 ~-45 ~39 minecraft:deepslate_tiles
fill ~26 ~-45 ~40 ~27 ~-45 ~40 minecraft:deepslate_tiles
fill ~28 ~-45 ~40 ~40 ~-45 ~40 minecraft:air
fill ~41 ~-45 ~40 ~42 ~-45 ~40 minecraft:deepslate_tiles
fill ~27 ~-45 ~41 ~29 ~-45 ~41 minecraft:deepslate_tiles
fill ~30 ~-45 ~41 ~38 ~-45 ~41 minecraft:air
fill ~39 ~-45 ~41 ~41 ~-45 ~41 minecraft:deepslate_tiles
fill ~28 ~-45 ~42 ~31 ~-45 ~42 minecraft:deepslate_tiles
fill ~32 ~-45 ~42 ~36 ~-45 ~42 minecraft:air
fill ~37 ~-45 ~42 ~40 ~-45 ~42 minecraft:deepslate_tiles
fill ~30 ~-45 ~43 ~38 ~-45 ~43 minecraft:deepslate_tiles
setblock ~34 ~-45 ~44 minecraft:deepslate_tiles
fill ~32 ~-45 ~66 ~36 ~-45 ~66 minecraft:polished_andesite
setblock ~32 ~-45 ~67 minecraft:polished_andesite
setblock ~33 ~-45 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-45 ~67 ~35 ~-45 ~67 minecraft:air
setblock ~36 ~-45 ~67 minecraft:polished_andesite
setblock ~32 ~-45 ~68 minecraft:polished_andesite
setblock ~33 ~-45 ~68 minecraft:air
setblock ~34 ~-45 ~68 minecraft:quartz_pillar
setblock ~35 ~-45 ~68 minecraft:air
setblock ~36 ~-45 ~68 minecraft:polished_andesite
setblock ~32 ~-45 ~69 minecraft:polished_andesite
fill ~33 ~-45 ~69 ~35 ~-45 ~69 minecraft:air
setblock ~36 ~-45 ~69 minecraft:polished_andesite
fill ~32 ~-45 ~70 ~36 ~-45 ~70 minecraft:polished_andesite
fill ~4 ~-44 ~4 ~64 ~-44 ~4 minecraft:light_gray_concrete
setblock ~4 ~-44 ~5 minecraft:light_gray_concrete
fill ~5 ~-44 ~5 ~17 ~-44 ~5 minecraft:polished_andesite
setblock ~18 ~-44 ~5 minecraft:light_gray_concrete
fill ~19 ~-44 ~5 ~31 ~-44 ~5 minecraft:polished_andesite
setblock ~32 ~-44 ~5 minecraft:light_gray_concrete
setblock ~33 ~-44 ~5 minecraft:white_concrete
setblock ~34 ~-44 ~5 minecraft:red_concrete
setblock ~35 ~-44 ~5 minecraft:white_concrete
setblock ~36 ~-44 ~5 minecraft:light_gray_concrete
fill ~37 ~-44 ~5 ~49 ~-44 ~5 minecraft:black_concrete
setblock ~50 ~-44 ~5 minecraft:light_gray_concrete
fill ~51 ~-44 ~5 ~63 ~-44 ~5 minecraft:polished_andesite
setblock ~64 ~-44 ~5 minecraft:light_gray_concrete
setblock ~4 ~-44 ~6 minecraft:light_gray_concrete
fill ~5 ~-44 ~6 ~17 ~-44 ~6 minecraft:polished_andesite
setblock ~18 ~-44 ~6 minecraft:light_gray_concrete
fill ~19 ~-44 ~6 ~31 ~-44 ~6 minecraft:polished_andesite
setblock ~32 ~-44 ~6 minecraft:light_gray_concrete
setblock ~33 ~-44 ~6 minecraft:white_concrete
setblock ~34 ~-44 ~6 minecraft:red_concrete
setblock ~35 ~-44 ~6 minecraft:white_concrete
setblock ~36 ~-44 ~6 minecraft:light_gray_concrete
fill ~37 ~-44 ~6 ~49 ~-44 ~6 minecraft:black_concrete
setblock ~50 ~-44 ~6 minecraft:light_gray_concrete
fill ~51 ~-44 ~6 ~63 ~-44 ~6 minecraft:polished_andesite
setblock ~64 ~-44 ~6 minecraft:light_gray_concrete
setblock ~4 ~-44 ~7 minecraft:light_gray_concrete
fill ~5 ~-44 ~7 ~17 ~-44 ~7 minecraft:polished_andesite
setblock ~18 ~-44 ~7 minecraft:light_gray_concrete
fill ~19 ~-44 ~7 ~31 ~-44 ~7 minecraft:polished_andesite
setblock ~32 ~-44 ~7 minecraft:light_gray_concrete
setblock ~33 ~-44 ~7 minecraft:white_concrete
setblock ~34 ~-44 ~7 minecraft:red_concrete
setblock ~35 ~-44 ~7 minecraft:white_concrete
setblock ~36 ~-44 ~7 minecraft:light_gray_concrete
fill ~37 ~-44 ~7 ~49 ~-44 ~7 minecraft:black_concrete
setblock ~50 ~-44 ~7 minecraft:light_gray_concrete
fill ~51 ~-44 ~7 ~63 ~-44 ~7 minecraft:polished_andesite
setblock ~64 ~-44 ~7 minecraft:light_gray_concrete
setblock ~4 ~-44 ~8 minecraft:light_gray_concrete
fill ~5 ~-44 ~8 ~17 ~-44 ~8 minecraft:polished_andesite
setblock ~18 ~-44 ~8 minecraft:light_gray_concrete
fill ~19 ~-44 ~8 ~31 ~-44 ~8 minecraft:polished_andesite
setblock ~32 ~-44 ~8 minecraft:light_gray_concrete
setblock ~33 ~-44 ~8 minecraft:white_concrete
setblock ~34 ~-44 ~8 minecraft:red_concrete
setblock ~35 ~-44 ~8 minecraft:white_concrete
setblock ~36 ~-44 ~8 minecraft:light_gray_concrete
fill ~37 ~-44 ~8 ~49 ~-44 ~8 minecraft:black_concrete
setblock ~50 ~-44 ~8 minecraft:light_gray_concrete
fill ~51 ~-44 ~8 ~63 ~-44 ~8 minecraft:polished_andesite
setblock ~64 ~-44 ~8 minecraft:light_gray_concrete
setblock ~4 ~-44 ~9 minecraft:light_gray_concrete
fill ~5 ~-44 ~9 ~17 ~-44 ~9 minecraft:polished_andesite
schedule function hive:weiter/5 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 4 von 18 fertig","color":"gray"}]