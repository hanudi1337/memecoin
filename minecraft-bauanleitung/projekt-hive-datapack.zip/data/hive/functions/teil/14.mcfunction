fill ~33 ~-19 ~19 ~35 ~-19 ~19 minecraft:air
setblock ~36 ~-19 ~19 minecraft:light_gray_concrete
setblock ~37 ~-19 ~19 minecraft:air
fill ~38 ~-19 ~19 ~49 ~-19 ~19 minecraft:chiseled_bookshelf[facing=south]
setblock ~50 ~-19 ~19 minecraft:light_gray_concrete
fill ~51 ~-19 ~19 ~63 ~-19 ~19 minecraft:air
setblock ~64 ~-19 ~19 minecraft:light_gray_concrete
setblock ~4 ~-19 ~20 minecraft:light_gray_concrete
fill ~5 ~-19 ~20 ~17 ~-19 ~20 minecraft:air
setblock ~18 ~-19 ~20 minecraft:light_gray_concrete
fill ~19 ~-19 ~20 ~49 ~-19 ~20 minecraft:air
setblock ~50 ~-19 ~20 minecraft:light_gray_concrete
fill ~51 ~-19 ~20 ~63 ~-19 ~20 minecraft:air
setblock ~64 ~-19 ~20 minecraft:light_gray_concrete
setblock ~4 ~-19 ~21 minecraft:light_gray_concrete
setblock ~5 ~-19 ~21 minecraft:air
setblock ~6 ~-19 ~21 minecraft:iron_trapdoor[half=bottom]
setblock ~7 ~-19 ~21 minecraft:white_stained_glass_pane
setblock ~8 ~-19 ~21 minecraft:air
setblock ~9 ~-19 ~21 minecraft:iron_trapdoor[half=bottom]
setblock ~10 ~-19 ~21 minecraft:white_stained_glass_pane
setblock ~11 ~-19 ~21 minecraft:air
setblock ~12 ~-19 ~21 minecraft:iron_trapdoor[half=bottom]
setblock ~13 ~-19 ~21 minecraft:white_stained_glass_pane
setblock ~14 ~-19 ~21 minecraft:air
setblock ~15 ~-19 ~21 minecraft:iron_trapdoor[half=bottom]
setblock ~16 ~-19 ~21 minecraft:white_stained_glass_pane
setblock ~17 ~-19 ~21 minecraft:air
setblock ~18 ~-19 ~21 minecraft:light_gray_concrete
fill ~19 ~-19 ~21 ~31 ~-19 ~21 minecraft:air
setblock ~32 ~-19 ~21 minecraft:light_gray_concrete
fill ~33 ~-19 ~21 ~35 ~-19 ~21 minecraft:air
setblock ~36 ~-19 ~21 minecraft:light_gray_concrete
fill ~37 ~-19 ~21 ~42 ~-19 ~21 minecraft:air
fill ~43 ~-19 ~21 ~47 ~-19 ~21 minecraft:red_carpet
fill ~48 ~-19 ~21 ~49 ~-19 ~21 minecraft:air
setblock ~50 ~-19 ~21 minecraft:light_gray_concrete
fill ~51 ~-19 ~21 ~63 ~-19 ~21 minecraft:air
setblock ~64 ~-19 ~21 minecraft:light_gray_concrete
setblock ~4 ~-19 ~22 minecraft:light_gray_concrete
setblock ~5 ~-19 ~22 minecraft:air
setblock ~6 ~-19 ~22 minecraft:white_stained_glass_pane
fill ~7 ~-19 ~22 ~8 ~-19 ~22 minecraft:air
setblock ~9 ~-19 ~22 minecraft:white_stained_glass_pane
fill ~10 ~-19 ~22 ~11 ~-19 ~22 minecraft:air
setblock ~12 ~-19 ~22 minecraft:white_stained_glass_pane
fill ~13 ~-19 ~22 ~14 ~-19 ~22 minecraft:air
setblock ~15 ~-19 ~22 minecraft:white_stained_glass_pane
fill ~16 ~-19 ~22 ~17 ~-19 ~22 minecraft:air
setblock ~18 ~-19 ~22 minecraft:light_gray_concrete
setblock ~19 ~-19 ~22 minecraft:smooth_stone_slab[type=top]
setblock ~20 ~-19 ~22 minecraft:air
fill ~21 ~-19 ~22 ~22 ~-19 ~22 minecraft:smooth_stone_slab[type=top]
setblock ~23 ~-19 ~22 minecraft:air
fill ~24 ~-19 ~22 ~25 ~-19 ~22 minecraft:smooth_stone_slab[type=top]
fill ~26 ~-19 ~22 ~28 ~-19 ~22 minecraft:air
fill ~29 ~-19 ~22 ~32 ~-19 ~22 minecraft:polished_andesite
fill ~33 ~-19 ~22 ~35 ~-19 ~22 minecraft:air
fill ~36 ~-19 ~22 ~39 ~-19 ~22 minecraft:polished_andesite
fill ~40 ~-19 ~22 ~44 ~-19 ~22 minecraft:air
fill ~45 ~-19 ~22 ~47 ~-19 ~22 minecraft:red_carpet
fill ~48 ~-19 ~22 ~49 ~-19 ~22 minecraft:air
setblock ~50 ~-19 ~22 minecraft:light_gray_concrete
fill ~51 ~-19 ~22 ~55 ~-19 ~22 minecraft:air
setblock ~56 ~-19 ~22 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-19 ~22 ~58 ~-19 ~22 minecraft:spruce_slab[type=top]
setblock ~59 ~-19 ~22 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-19 ~22 ~63 ~-19 ~22 minecraft:air
setblock ~64 ~-19 ~22 minecraft:light_gray_concrete
setblock ~4 ~-19 ~23 minecraft:light_gray_concrete
setblock ~5 ~-19 ~23 minecraft:cauldron
fill ~6 ~-19 ~23 ~16 ~-19 ~23 minecraft:air
setblock ~17 ~-19 ~23 minecraft:cauldron
setblock ~18 ~-19 ~23 minecraft:light_gray_concrete
setblock ~19 ~-19 ~23 minecraft:spruce_stairs[facing=south,half=bottom]
setblock ~20 ~-19 ~23 minecraft:air
fill ~21 ~-19 ~23 ~22 ~-19 ~23 minecraft:spruce_stairs[facing=south,half=bottom]
setblock ~23 ~-19 ~23 minecraft:air
fill ~24 ~-19 ~23 ~25 ~-19 ~23 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~26 ~-19 ~23 ~28 ~-19 ~23 minecraft:air
setblock ~29 ~-19 ~23 minecraft:polished_andesite
fill ~30 ~-19 ~23 ~38 ~-19 ~23 minecraft:air
setblock ~39 ~-19 ~23 minecraft:polished_andesite
fill ~40 ~-19 ~23 ~42 ~-19 ~23 minecraft:air
fill ~43 ~-19 ~23 ~45 ~-19 ~23 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~46 ~-19 ~23 ~47 ~-19 ~23 minecraft:red_carpet
fill ~48 ~-19 ~23 ~49 ~-19 ~23 minecraft:air
setblock ~50 ~-19 ~23 minecraft:light_gray_concrete
fill ~51 ~-19 ~23 ~55 ~-19 ~23 minecraft:air
setblock ~56 ~-19 ~23 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-19 ~23 ~58 ~-19 ~23 minecraft:spruce_slab[type=top]
setblock ~59 ~-19 ~23 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-19 ~23 ~63 ~-19 ~23 minecraft:air
setblock ~64 ~-19 ~23 minecraft:light_gray_concrete
setblock ~4 ~-19 ~24 minecraft:light_gray_concrete
setblock ~5 ~-19 ~24 minecraft:air
setblock ~6 ~-19 ~24 minecraft:iron_trapdoor[half=bottom]
setblock ~7 ~-19 ~24 minecraft:white_stained_glass_pane
setblock ~8 ~-19 ~24 minecraft:air
setblock ~9 ~-19 ~24 minecraft:iron_trapdoor[half=bottom]
setblock ~10 ~-19 ~24 minecraft:white_stained_glass_pane
setblock ~11 ~-19 ~24 minecraft:air
setblock ~12 ~-19 ~24 minecraft:iron_trapdoor[half=bottom]
setblock ~13 ~-19 ~24 minecraft:white_stained_glass_pane
setblock ~14 ~-19 ~24 minecraft:air
setblock ~15 ~-19 ~24 minecraft:iron_trapdoor[half=bottom]
setblock ~16 ~-19 ~24 minecraft:white_stained_glass_pane
setblock ~17 ~-19 ~24 minecraft:air
setblock ~18 ~-19 ~24 minecraft:light_gray_concrete
fill ~19 ~-19 ~24 ~25 ~-19 ~24 minecraft:air
fill ~26 ~-19 ~24 ~27 ~-19 ~24 minecraft:polished_andesite
fill ~28 ~-19 ~24 ~29 ~-19 ~24 minecraft:air
setblock ~30 ~-19 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-19 ~24 ~37 ~-19 ~24 minecraft:air
setblock ~38 ~-19 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-19 ~24 ~40 ~-19 ~24 minecraft:air
fill ~41 ~-19 ~24 ~42 ~-19 ~24 minecraft:polished_andesite
fill ~43 ~-19 ~24 ~44 ~-19 ~24 minecraft:spruce_slab[type=top]
fill ~45 ~-19 ~24 ~46 ~-19 ~24 minecraft:air
setblock ~47 ~-19 ~24 minecraft:red_carpet
fill ~48 ~-19 ~24 ~49 ~-19 ~24 minecraft:air
setblock ~50 ~-19 ~24 minecraft:light_gray_concrete
fill ~51 ~-19 ~24 ~55 ~-19 ~24 minecraft:air
setblock ~56 ~-19 ~24 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-19 ~24 ~58 ~-19 ~24 minecraft:spruce_slab[type=top]
setblock ~59 ~-19 ~24 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-19 ~24 ~62 ~-19 ~24 minecraft:air
setblock ~63 ~-19 ~24 minecraft:black_concrete
setblock ~64 ~-19 ~24 minecraft:light_gray_concrete
setblock ~4 ~-19 ~25 minecraft:light_gray_concrete
setblock ~5 ~-19 ~25 minecraft:air
setblock ~6 ~-19 ~25 minecraft:white_stained_glass_pane
fill ~7 ~-19 ~25 ~8 ~-19 ~25 minecraft:air
setblock ~9 ~-19 ~25 minecraft:white_stained_glass_pane
fill ~10 ~-19 ~25 ~11 ~-19 ~25 minecraft:air
setblock ~12 ~-19 ~25 minecraft:white_stained_glass_pane
fill ~13 ~-19 ~25 ~14 ~-19 ~25 minecraft:air
setblock ~15 ~-19 ~25 minecraft:white_stained_glass_pane
fill ~16 ~-19 ~25 ~17 ~-19 ~25 minecraft:air
setblock ~18 ~-19 ~25 minecraft:light_gray_concrete
fill ~19 ~-19 ~25 ~24 ~-19 ~25 minecraft:air
fill ~25 ~-19 ~25 ~26 ~-19 ~25 minecraft:polished_andesite
fill ~27 ~-19 ~25 ~31 ~-19 ~25 minecraft:air
setblock ~32 ~-19 ~25 minecraft:glass_pane[east=true]
fill ~33 ~-19 ~25 ~35 ~-19 ~25 minecraft:glass_pane[east=true,west=true]
setblock ~36 ~-19 ~25 minecraft:glass_pane[west=true]
fill ~37 ~-19 ~25 ~41 ~-19 ~25 minecraft:air
fill ~42 ~-19 ~25 ~43 ~-19 ~25 minecraft:polished_andesite
fill ~44 ~-19 ~25 ~46 ~-19 ~25 minecraft:air
setblock ~47 ~-19 ~25 minecraft:red_carpet
fill ~48 ~-19 ~25 ~49 ~-19 ~25 minecraft:air
setblock ~50 ~-19 ~25 minecraft:light_gray_concrete
fill ~51 ~-19 ~25 ~55 ~-19 ~25 minecraft:air
setblock ~56 ~-19 ~25 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-19 ~25 ~58 ~-19 ~25 minecraft:spruce_slab[type=top]
setblock ~59 ~-19 ~25 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-19 ~25 ~62 ~-19 ~25 minecraft:air
setblock ~63 ~-19 ~25 minecraft:black_concrete
setblock ~64 ~-19 ~25 minecraft:light_gray_concrete
setblock ~4 ~-19 ~26 minecraft:light_gray_concrete
fill ~5 ~-19 ~26 ~17 ~-19 ~26 minecraft:air
setblock ~18 ~-19 ~26 minecraft:light_gray_concrete
fill ~19 ~-19 ~26 ~23 ~-19 ~26 minecraft:air
fill ~24 ~-19 ~26 ~25 ~-19 ~26 minecraft:polished_andesite
fill ~26 ~-19 ~26 ~29 ~-19 ~26 minecraft:air
setblock ~30 ~-19 ~26 minecraft:glass_pane[east=true]
setblock ~31 ~-19 ~26 minecraft:glass_pane[west=true]
fill ~32 ~-19 ~26 ~36 ~-19 ~26 minecraft:air
setblock ~37 ~-19 ~26 minecraft:glass_pane[east=true]
setblock ~38 ~-19 ~26 minecraft:glass_pane[west=true]
fill ~39 ~-19 ~26 ~42 ~-19 ~26 minecraft:air
fill ~43 ~-19 ~26 ~44 ~-19 ~26 minecraft:polished_andesite
fill ~45 ~-19 ~26 ~49 ~-19 ~26 minecraft:air
setblock ~50 ~-19 ~26 minecraft:light_gray_concrete
fill ~51 ~-19 ~26 ~55 ~-19 ~26 minecraft:air
setblock ~56 ~-19 ~26 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-19 ~26 ~58 ~-19 ~26 minecraft:spruce_slab[type=top]
setblock ~59 ~-19 ~26 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-19 ~26 ~62 ~-19 ~26 minecraft:air
setblock ~63 ~-19 ~26 minecraft:black_concrete
setblock ~64 ~-19 ~26 minecraft:light_gray_concrete
setblock ~4 ~-19 ~27 minecraft:light_gray_concrete
setblock ~5 ~-19 ~27 minecraft:cauldron
setblock ~6 ~-19 ~27 minecraft:iron_trapdoor[half=bottom]
setblock ~7 ~-19 ~27 minecraft:white_stained_glass_pane
setblock ~8 ~-19 ~27 minecraft:air
setblock ~9 ~-19 ~27 minecraft:iron_trapdoor[half=bottom]
setblock ~10 ~-19 ~27 minecraft:white_stained_glass_pane
setblock ~11 ~-19 ~27 minecraft:air
setblock ~12 ~-19 ~27 minecraft:iron_trapdoor[half=bottom]
setblock ~13 ~-19 ~27 minecraft:white_stained_glass_pane
setblock ~14 ~-19 ~27 minecraft:air
setblock ~15 ~-19 ~27 minecraft:iron_trapdoor[half=bottom]
setblock ~16 ~-19 ~27 minecraft:white_stained_glass_pane[east=true]
setblock ~17 ~-19 ~27 minecraft:cauldron
setblock ~18 ~-19 ~27 minecraft:light_gray_concrete
fill ~19 ~-19 ~27 ~23 ~-19 ~27 minecraft:air
setblock ~24 ~-19 ~27 minecraft:polished_andesite
fill ~25 ~-19 ~27 ~27 ~-19 ~27 minecraft:air
setblock ~28 ~-19 ~27 minecraft:glass_pane[east=true]
setblock ~29 ~-19 ~27 minecraft:glass_pane[west=true]
fill ~30 ~-19 ~27 ~38 ~-19 ~27 minecraft:air
setblock ~39 ~-19 ~27 minecraft:glass_pane[east=true]
setblock ~40 ~-19 ~27 minecraft:glass_pane[west=true]
fill ~41 ~-19 ~27 ~43 ~-19 ~27 minecraft:air
setblock ~44 ~-19 ~27 minecraft:polished_andesite
setblock ~45 ~-19 ~27 minecraft:quartz_stairs[facing=south,half=bottom]
fill ~46 ~-19 ~27 ~49 ~-19 ~27 minecraft:air
setblock ~50 ~-19 ~27 minecraft:light_gray_concrete
fill ~51 ~-19 ~27 ~55 ~-19 ~27 minecraft:air
setblock ~56 ~-19 ~27 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-19 ~27 ~58 ~-19 ~27 minecraft:spruce_slab[type=top]
setblock ~59 ~-19 ~27 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-19 ~27 ~63 ~-19 ~27 minecraft:air
setblock ~64 ~-19 ~27 minecraft:light_gray_concrete
setblock ~4 ~-19 ~28 minecraft:light_gray_concrete
setblock ~5 ~-19 ~28 minecraft:air
setblock ~6 ~-19 ~28 minecraft:white_stained_glass_pane
fill ~7 ~-19 ~28 ~8 ~-19 ~28 minecraft:air
setblock ~9 ~-19 ~28 minecraft:white_stained_glass_pane
fill ~10 ~-19 ~28 ~11 ~-19 ~28 minecraft:air
setblock ~12 ~-19 ~28 minecraft:white_stained_glass_pane
fill ~13 ~-19 ~28 ~14 ~-19 ~28 minecraft:air
setblock ~15 ~-19 ~28 minecraft:white_stained_glass_pane
fill ~16 ~-19 ~28 ~17 ~-19 ~28 minecraft:air
setblock ~18 ~-19 ~28 minecraft:light_gray_concrete
fill ~19 ~-19 ~28 ~22 ~-19 ~28 minecraft:air
setblock ~23 ~-19 ~28 minecraft:polished_andesite
fill ~24 ~-19 ~28 ~26 ~-19 ~28 minecraft:air
setblock ~27 ~-19 ~28 minecraft:glass_pane[south=true]
fill ~28 ~-19 ~28 ~40 ~-19 ~28 minecraft:air
setblock ~41 ~-19 ~28 minecraft:glass_pane[south=true]
fill ~42 ~-19 ~28 ~44 ~-19 ~28 minecraft:air
setblock ~45 ~-19 ~28 minecraft:polished_andesite
fill ~46 ~-19 ~28 ~49 ~-19 ~28 minecraft:air
setblock ~50 ~-19 ~28 minecraft:light_gray_concrete
fill ~51 ~-19 ~28 ~55 ~-19 ~28 minecraft:air
setblock ~56 ~-19 ~28 minecraft:spruce_stairs[facing=west,half=bottom]
fill ~57 ~-19 ~28 ~58 ~-19 ~28 minecraft:spruce_slab[type=top]
setblock ~59 ~-19 ~28 minecraft:spruce_stairs[facing=east,half=bottom]
fill ~60 ~-19 ~28 ~63 ~-19 ~28 minecraft:air
setblock ~64 ~-19 ~28 minecraft:light_gray_concrete
setblock ~4 ~-19 ~29 minecraft:light_gray_concrete
fill ~5 ~-19 ~29 ~17 ~-19 ~29 minecraft:air
setblock ~18 ~-19 ~29 minecraft:light_gray_concrete
fill ~19 ~-19 ~29 ~21 ~-19 ~29 minecraft:air
fill ~22 ~-19 ~29 ~23 ~-19 ~29 minecraft:polished_andesite
fill ~24 ~-19 ~29 ~26 ~-19 ~29 minecraft:air
setblock ~27 ~-19 ~29 minecraft:glass_pane[north=true]
fill ~28 ~-19 ~29 ~40 ~-19 ~29 minecraft:air
setblock ~41 ~-19 ~29 minecraft:glass_pane[north=true]
fill ~42 ~-19 ~29 ~44 ~-19 ~29 minecraft:air
fill ~45 ~-19 ~29 ~46 ~-19 ~29 minecraft:polished_andesite
fill ~47 ~-19 ~29 ~49 ~-19 ~29 minecraft:air
setblock ~50 ~-19 ~29 minecraft:light_gray_concrete
fill ~51 ~-19 ~29 ~63 ~-19 ~29 minecraft:air
setblock ~64 ~-19 ~29 minecraft:light_gray_concrete
setblock ~4 ~-19 ~30 minecraft:light_gray_concrete
setblock ~5 ~-19 ~30 minecraft:air
setblock ~6 ~-19 ~30 minecraft:iron_trapdoor[half=bottom]
setblock ~7 ~-19 ~30 minecraft:white_stained_glass_pane
setblock ~8 ~-19 ~30 minecraft:air
setblock ~9 ~-19 ~30 minecraft:iron_trapdoor[half=bottom]
setblock ~10 ~-19 ~30 minecraft:white_stained_glass_pane
setblock ~11 ~-19 ~30 minecraft:air
setblock ~12 ~-19 ~30 minecraft:iron_trapdoor[half=bottom]
setblock ~13 ~-19 ~30 minecraft:white_stained_glass_pane[south=true]
setblock ~14 ~-19 ~30 minecraft:air
setblock ~15 ~-19 ~30 minecraft:iron_trapdoor[half=bottom]
setblock ~16 ~-19 ~30 minecraft:white_stained_glass_pane
setblock ~17 ~-19 ~30 minecraft:air
setblock ~18 ~-19 ~30 minecraft:light_gray_concrete
fill ~19 ~-19 ~30 ~21 ~-19 ~30 minecraft:air
setblock ~22 ~-19 ~30 minecraft:polished_andesite
setblock ~23 ~-19 ~30 minecraft:air
setblock ~24 ~-19 ~30 minecraft:chiseled_quartz_block
setblock ~25 ~-19 ~30 minecraft:air
setblock ~26 ~-19 ~30 minecraft:glass_pane[south=true]
fill ~27 ~-19 ~30 ~41 ~-19 ~30 minecraft:air
setblock ~42 ~-19 ~30 minecraft:glass_pane[south=true]
setblock ~43 ~-19 ~30 minecraft:air
setblock ~44 ~-19 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-19 ~30 minecraft:air
setblock ~46 ~-19 ~30 minecraft:polished_andesite
fill ~47 ~-19 ~30 ~49 ~-19 ~30 minecraft:air
setblock ~50 ~-19 ~30 minecraft:light_gray_concrete
fill ~51 ~-19 ~30 ~63 ~-19 ~30 minecraft:air
setblock ~64 ~-19 ~30 minecraft:light_gray_concrete
setblock ~4 ~-19 ~31 minecraft:light_gray_concrete
setblock ~5 ~-19 ~31 minecraft:cauldron
setblock ~6 ~-19 ~31 minecraft:white_stained_glass_pane[south=true,west=true]
fill ~7 ~-19 ~31 ~8 ~-19 ~31 minecraft:air
setblock ~9 ~-19 ~31 minecraft:cauldron
fill ~10 ~-19 ~31 ~12 ~-19 ~31 minecraft:air
setblock ~13 ~-19 ~31 minecraft:cauldron
setblock ~14 ~-19 ~31 minecraft:air
setblock ~15 ~-19 ~31 minecraft:white_stained_glass_pane[south=true]
setblock ~16 ~-19 ~31 minecraft:air
setblock ~17 ~-19 ~31 minecraft:cauldron
setblock ~18 ~-19 ~31 minecraft:light_gray_concrete
fill ~19 ~-19 ~31 ~21 ~-19 ~31 minecraft:air
setblock ~22 ~-19 ~31 minecraft:polished_andesite
fill ~23 ~-19 ~31 ~25 ~-19 ~31 minecraft:air
setblock ~26 ~-19 ~31 minecraft:glass_pane[north=true]
fill ~27 ~-19 ~31 ~41 ~-19 ~31 minecraft:air
setblock ~42 ~-19 ~31 minecraft:glass_pane[north=true,south=true]
fill ~43 ~-19 ~31 ~45 ~-19 ~31 minecraft:air
setblock ~46 ~-19 ~31 minecraft:polished_andesite
fill ~47 ~-19 ~31 ~49 ~-19 ~31 minecraft:air
setblock ~50 ~-19 ~31 minecraft:light_gray_concrete
fill ~51 ~-19 ~31 ~63 ~-19 ~31 minecraft:air
setblock ~64 ~-19 ~31 minecraft:light_gray_concrete
fill ~4 ~-19 ~32 ~10 ~-19 ~32 minecraft:light_gray_concrete
setblock ~11 ~-19 ~32 minecraft:air
fill ~12 ~-19 ~32 ~19 ~-19 ~32 minecraft:light_gray_concrete
setblock ~20 ~-19 ~32 minecraft:air
setblock ~21 ~-19 ~32 minecraft:light_gray_concrete
setblock ~22 ~-19 ~32 minecraft:polished_andesite
fill ~23 ~-19 ~32 ~24 ~-19 ~32 minecraft:air
setblock ~25 ~-19 ~32 minecraft:glass_pane[south=true]
fill ~26 ~-19 ~32 ~32 ~-19 ~32 minecraft:air
fill ~33 ~-19 ~32 ~35 ~-19 ~32 minecraft:glass
setblock ~36 ~-19 ~32 minecraft:air
setblock ~37 ~-19 ~32 minecraft:iron_bars[east=true]
fill ~38 ~-19 ~32 ~41 ~-19 ~32 minecraft:iron_bars[east=true,west=true]
setblock ~42 ~-19 ~32 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~43 ~-19 ~32 minecraft:glass_pane[west=true]
fill ~44 ~-19 ~32 ~45 ~-19 ~32 minecraft:air
setblock ~46 ~-19 ~32 minecraft:polished_andesite
setblock ~47 ~-19 ~32 minecraft:light_gray_concrete
setblock ~48 ~-19 ~32 minecraft:air
fill ~49 ~-19 ~32 ~56 ~-19 ~32 minecraft:light_gray_concrete
setblock ~57 ~-19 ~32 minecraft:air
fill ~58 ~-19 ~32 ~64 ~-19 ~32 minecraft:light_gray_concrete
setblock ~4 ~-19 ~33 minecraft:light_gray_concrete
fill ~5 ~-19 ~33 ~24 ~-19 ~33 minecraft:air
setblock ~25 ~-19 ~33 minecraft:glass_pane[north=true,south=true]
fill ~26 ~-19 ~33 ~32 ~-19 ~33 minecraft:air
setblock ~33 ~-19 ~33 minecraft:glass
fill ~34 ~-19 ~33 ~63 ~-19 ~33 minecraft:air
setblock ~64 ~-19 ~33 minecraft:light_gray_concrete
setblock ~4 ~-19 ~34 minecraft:light_gray_concrete
fill ~5 ~-19 ~34 ~24 ~-19 ~34 minecraft:air
setblock ~25 ~-19 ~34 minecraft:glass_pane[north=true,south=true]
fill ~26 ~-19 ~34 ~32 ~-19 ~34 minecraft:air
fill ~33 ~-19 ~34 ~35 ~-19 ~34 minecraft:glass
fill ~36 ~-19 ~34 ~63 ~-19 ~34 minecraft:air
setblock ~64 ~-19 ~34 minecraft:light_gray_concrete
setblock ~4 ~-19 ~35 minecraft:light_gray_concrete
fill ~5 ~-19 ~35 ~24 ~-19 ~35 minecraft:air
setblock ~25 ~-19 ~35 minecraft:glass_pane[north=true,south=true]
fill ~26 ~-19 ~35 ~32 ~-19 ~35 minecraft:air
setblock ~33 ~-19 ~35 minecraft:glass
fill ~34 ~-19 ~35 ~63 ~-19 ~35 minecraft:air
setblock ~64 ~-19 ~35 minecraft:light_gray_concrete
fill ~4 ~-19 ~36 ~10 ~-19 ~36 minecraft:light_gray_concrete
setblock ~11 ~-19 ~36 minecraft:air
fill ~12 ~-19 ~36 ~19 ~-19 ~36 minecraft:light_gray_concrete
setblock ~20 ~-19 ~36 minecraft:air
setblock ~21 ~-19 ~36 minecraft:light_gray_concrete
setblock ~22 ~-19 ~36 minecraft:polished_andesite
fill ~23 ~-19 ~36 ~24 ~-19 ~36 minecraft:air
setblock ~25 ~-19 ~36 minecraft:glass_pane[north=true]
fill ~26 ~-19 ~36 ~32 ~-19 ~36 minecraft:air
fill ~33 ~-19 ~36 ~35 ~-19 ~36 minecraft:glass
setblock ~36 ~-19 ~36 minecraft:air
setblock ~37 ~-19 ~36 minecraft:iron_bars[east=true]
fill ~38 ~-19 ~36 ~41 ~-19 ~36 minecraft:iron_bars[east=true,west=true]
setblock ~42 ~-19 ~36 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~43 ~-19 ~36 minecraft:glass_pane[west=true]
fill ~44 ~-19 ~36 ~45 ~-19 ~36 minecraft:air
setblock ~46 ~-19 ~36 minecraft:polished_andesite
setblock ~47 ~-19 ~36 minecraft:light_gray_concrete
setblock ~48 ~-19 ~36 minecraft:air
fill ~49 ~-19 ~36 ~56 ~-19 ~36 minecraft:light_gray_concrete
setblock ~57 ~-19 ~36 minecraft:air
fill ~58 ~-19 ~36 ~64 ~-19 ~36 minecraft:light_gray_concrete
setblock ~4 ~-19 ~37 minecraft:light_gray_concrete
fill ~5 ~-19 ~37 ~7 ~-19 ~37 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~8 ~-19 ~37 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-19 ~37 ~17 ~-19 ~37 minecraft:air
setblock ~18 ~-19 ~37 minecraft:light_gray_concrete
fill ~19 ~-19 ~37 ~21 ~-19 ~37 minecraft:air
setblock ~22 ~-19 ~37 minecraft:polished_andesite
fill ~23 ~-19 ~37 ~25 ~-19 ~37 minecraft:air
setblock ~26 ~-19 ~37 minecraft:glass_pane[south=true]
fill ~27 ~-19 ~37 ~41 ~-19 ~37 minecraft:air
setblock ~42 ~-19 ~37 minecraft:glass_pane[north=true,south=true]
fill ~43 ~-19 ~37 ~45 ~-19 ~37 minecraft:air
setblock ~46 ~-19 ~37 minecraft:polished_andesite
fill ~47 ~-19 ~37 ~49 ~-19 ~37 minecraft:air
setblock ~50 ~-19 ~37 minecraft:light_gray_concrete
setblock ~51 ~-19 ~37 minecraft:air
setblock ~52 ~-19 ~37 minecraft:cauldron
fill ~53 ~-19 ~37 ~59 ~-19 ~37 minecraft:air
setblock ~60 ~-19 ~37 minecraft:cauldron
fill ~61 ~-19 ~37 ~63 ~-19 ~37 minecraft:air
setblock ~64 ~-19 ~37 minecraft:light_gray_concrete
setblock ~4 ~-19 ~38 minecraft:light_gray_concrete
fill ~5 ~-19 ~38 ~7 ~-19 ~38 minecraft:air
setblock ~8 ~-19 ~38 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-19 ~38 ~17 ~-19 ~38 minecraft:air
setblock ~18 ~-19 ~38 minecraft:light_gray_concrete
fill ~19 ~-19 ~38 ~21 ~-19 ~38 minecraft:air
setblock ~22 ~-19 ~38 minecraft:polished_andesite
setblock ~23 ~-19 ~38 minecraft:air
setblock ~24 ~-19 ~38 minecraft:chiseled_quartz_block
setblock ~25 ~-19 ~38 minecraft:air
setblock ~26 ~-19 ~38 minecraft:glass_pane[north=true]
fill ~27 ~-19 ~38 ~41 ~-19 ~38 minecraft:air
setblock ~42 ~-19 ~38 minecraft:glass_pane[north=true]
setblock ~43 ~-19 ~38 minecraft:air
setblock ~44 ~-19 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-19 ~38 minecraft:air
setblock ~46 ~-19 ~38 minecraft:polished_andesite
fill ~47 ~-19 ~38 ~49 ~-19 ~38 minecraft:air
setblock ~50 ~-19 ~38 minecraft:light_gray_concrete
fill ~51 ~-19 ~38 ~63 ~-19 ~38 minecraft:air
setblock ~64 ~-19 ~38 minecraft:light_gray_concrete
setblock ~4 ~-19 ~39 minecraft:light_gray_concrete
fill ~5 ~-19 ~39 ~17 ~-19 ~39 minecraft:air
setblock ~18 ~-19 ~39 minecraft:light_gray_concrete
setblock ~19 ~-19 ~39 minecraft:barrel
fill ~20 ~-19 ~39 ~21 ~-19 ~39 minecraft:air
fill ~22 ~-19 ~39 ~23 ~-19 ~39 minecraft:polished_andesite
fill ~24 ~-19 ~39 ~26 ~-19 ~39 minecraft:air
setblock ~27 ~-19 ~39 minecraft:glass_pane[south=true]
fill ~28 ~-19 ~39 ~40 ~-19 ~39 minecraft:air
setblock ~41 ~-19 ~39 minecraft:glass_pane[south=true]
fill ~42 ~-19 ~39 ~44 ~-19 ~39 minecraft:air
fill ~45 ~-19 ~39 ~46 ~-19 ~39 minecraft:polished_andesite
fill ~47 ~-19 ~39 ~49 ~-19 ~39 minecraft:air
setblock ~50 ~-19 ~39 minecraft:light_gray_concrete
fill ~51 ~-19 ~39 ~63 ~-19 ~39 minecraft:air
setblock ~64 ~-19 ~39 minecraft:light_gray_concrete
setblock ~4 ~-19 ~40 minecraft:light_gray_concrete
fill ~5 ~-19 ~40 ~7 ~-19 ~40 minecraft:air
setblock ~8 ~-19 ~40 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-19 ~40 ~17 ~-19 ~40 minecraft:air
setblock ~18 ~-19 ~40 minecraft:light_gray_concrete
fill ~19 ~-19 ~40 ~22 ~-19 ~40 minecraft:air
setblock ~23 ~-19 ~40 minecraft:polished_andesite
fill ~24 ~-19 ~40 ~26 ~-19 ~40 minecraft:air
setblock ~27 ~-19 ~40 minecraft:glass_pane[north=true]
fill ~28 ~-19 ~40 ~40 ~-19 ~40 minecraft:air
setblock ~41 ~-19 ~40 minecraft:glass_pane[north=true]
fill ~42 ~-19 ~40 ~44 ~-19 ~40 minecraft:air
setblock ~45 ~-19 ~40 minecraft:polished_andesite
fill ~46 ~-19 ~40 ~49 ~-19 ~40 minecraft:air
setblock ~50 ~-19 ~40 minecraft:light_gray_concrete
fill ~51 ~-19 ~40 ~63 ~-19 ~40 minecraft:air
setblock ~64 ~-19 ~40 minecraft:light_gray_concrete
setblock ~4 ~-19 ~41 minecraft:light_gray_concrete
fill ~5 ~-19 ~41 ~7 ~-19 ~41 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-19 ~41 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-19 ~41 ~17 ~-19 ~41 minecraft:air
setblock ~18 ~-19 ~41 minecraft:light_gray_concrete
fill ~19 ~-19 ~41 ~22 ~-19 ~41 minecraft:air
setblock ~23 ~-19 ~41 minecraft:barrel
setblock ~24 ~-19 ~41 minecraft:polished_andesite
fill ~25 ~-19 ~41 ~27 ~-19 ~41 minecraft:air
setblock ~28 ~-19 ~41 minecraft:glass_pane[east=true]
setblock ~29 ~-19 ~41 minecraft:glass_pane[west=true]
fill ~30 ~-19 ~41 ~38 ~-19 ~41 minecraft:air
setblock ~39 ~-19 ~41 minecraft:glass_pane[east=true]
setblock ~40 ~-19 ~41 minecraft:glass_pane[west=true]
fill ~41 ~-19 ~41 ~43 ~-19 ~41 minecraft:air
setblock ~44 ~-19 ~41 minecraft:polished_andesite
fill ~45 ~-19 ~41 ~49 ~-19 ~41 minecraft:air
setblock ~50 ~-19 ~41 minecraft:light_gray_concrete
fill ~51 ~-19 ~41 ~56 ~-19 ~41 minecraft:air
setblock ~57 ~-19 ~41 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-19 ~41 ~63 ~-19 ~41 minecraft:air
setblock ~64 ~-19 ~41 minecraft:light_gray_concrete
setblock ~4 ~-19 ~42 minecraft:light_gray_concrete
fill ~5 ~-19 ~42 ~7 ~-19 ~42 minecraft:air
setblock ~8 ~-19 ~42 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-19 ~42 ~17 ~-19 ~42 minecraft:air
setblock ~18 ~-19 ~42 minecraft:light_gray_concrete
setblock ~19 ~-19 ~42 minecraft:barrel
fill ~20 ~-19 ~42 ~23 ~-19 ~42 minecraft:air
fill ~24 ~-19 ~42 ~25 ~-19 ~42 minecraft:polished_andesite
fill ~26 ~-19 ~42 ~29 ~-19 ~42 minecraft:air
setblock ~30 ~-19 ~42 minecraft:glass_pane[east=true]
setblock ~31 ~-19 ~42 minecraft:glass_pane[west=true]
fill ~32 ~-19 ~42 ~36 ~-19 ~42 minecraft:air
setblock ~37 ~-19 ~42 minecraft:glass_pane[east=true]
setblock ~38 ~-19 ~42 minecraft:glass_pane[west=true]
fill ~39 ~-19 ~42 ~42 ~-19 ~42 minecraft:air
fill ~43 ~-19 ~42 ~44 ~-19 ~42 minecraft:polished_andesite
fill ~45 ~-19 ~42 ~49 ~-19 ~42 minecraft:air
setblock ~50 ~-19 ~42 minecraft:light_gray_concrete
setblock ~51 ~-19 ~42 minecraft:cauldron
fill ~52 ~-19 ~42 ~56 ~-19 ~42 minecraft:air
setblock ~57 ~-19 ~42 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-19 ~42 ~62 ~-19 ~42 minecraft:air
setblock ~63 ~-19 ~42 minecraft:cauldron
setblock ~64 ~-19 ~42 minecraft:light_gray_concrete
setblock ~4 ~-19 ~43 minecraft:light_gray_concrete
fill ~5 ~-19 ~43 ~11 ~-19 ~43 minecraft:air
setblock ~12 ~-19 ~43 minecraft:smooth_stone_slab[type=top]
fill ~13 ~-19 ~43 ~17 ~-19 ~43 minecraft:air
setblock ~18 ~-19 ~43 minecraft:light_gray_concrete
fill ~19 ~-19 ~43 ~23 ~-19 ~43 minecraft:air
setblock ~24 ~-19 ~43 minecraft:spruce_slab[type=top]
fill ~25 ~-19 ~43 ~26 ~-19 ~43 minecraft:polished_andesite
fill ~27 ~-19 ~43 ~31 ~-19 ~43 minecraft:air
setblock ~32 ~-19 ~43 minecraft:glass_pane[east=true]
fill ~33 ~-19 ~43 ~35 ~-19 ~43 minecraft:glass_pane[east=true,west=true]
setblock ~36 ~-19 ~43 minecraft:glass_pane[west=true]
fill ~37 ~-19 ~43 ~41 ~-19 ~43 minecraft:air
fill ~42 ~-19 ~43 ~43 ~-19 ~43 minecraft:polished_andesite
fill ~44 ~-19 ~43 ~46 ~-19 ~43 minecraft:air
setblock ~47 ~-19 ~43 minecraft:red_carpet
fill ~48 ~-19 ~43 ~49 ~-19 ~43 minecraft:air
setblock ~50 ~-19 ~43 minecraft:light_gray_concrete
fill ~51 ~-19 ~43 ~56 ~-19 ~43 minecraft:air
setblock ~57 ~-19 ~43 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-19 ~43 ~63 ~-19 ~43 minecraft:air
setblock ~64 ~-19 ~43 minecraft:light_gray_concrete
setblock ~4 ~-19 ~44 minecraft:light_gray_concrete
fill ~5 ~-19 ~44 ~7 ~-19 ~44 minecraft:air
setblock ~8 ~-19 ~44 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-19 ~44 ~17 ~-19 ~44 minecraft:air
setblock ~18 ~-19 ~44 minecraft:light_gray_concrete
fill ~19 ~-19 ~44 ~23 ~-19 ~44 minecraft:air
fill ~24 ~-19 ~44 ~25 ~-19 ~44 minecraft:spruce_slab[type=top]
fill ~26 ~-19 ~44 ~27 ~-19 ~44 minecraft:polished_andesite
fill ~28 ~-19 ~44 ~29 ~-19 ~44 minecraft:air
setblock ~30 ~-19 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-19 ~44 ~37 ~-19 ~44 minecraft:air
setblock ~38 ~-19 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-19 ~44 ~40 ~-19 ~44 minecraft:air
fill ~41 ~-19 ~44 ~42 ~-19 ~44 minecraft:polished_andesite
fill ~43 ~-19 ~44 ~46 ~-19 ~44 minecraft:air
setblock ~47 ~-19 ~44 minecraft:red_carpet
fill ~48 ~-19 ~44 ~49 ~-19 ~44 minecraft:air
setblock ~50 ~-19 ~44 minecraft:light_gray_concrete
fill ~51 ~-19 ~44 ~56 ~-19 ~44 minecraft:air
setblock ~57 ~-19 ~44 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-19 ~44 ~63 ~-19 ~44 minecraft:air
setblock ~64 ~-19 ~44 minecraft:light_gray_concrete
setblock ~4 ~-19 ~45 minecraft:light_gray_concrete
fill ~5 ~-19 ~45 ~7 ~-19 ~45 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-19 ~45 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-19 ~45 ~17 ~-19 ~45 minecraft:air
setblock ~18 ~-19 ~45 minecraft:light_gray_concrete
setblock ~19 ~-19 ~45 minecraft:barrel
fill ~20 ~-19 ~45 ~23 ~-19 ~45 minecraft:air
fill ~24 ~-19 ~45 ~25 ~-19 ~45 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~26 ~-19 ~45 ~28 ~-19 ~45 minecraft:air
setblock ~29 ~-19 ~45 minecraft:polished_andesite
fill ~30 ~-19 ~45 ~38 ~-19 ~45 minecraft:air
setblock ~39 ~-19 ~45 minecraft:polished_andesite
fill ~40 ~-19 ~45 ~42 ~-19 ~45 minecraft:air
setblock ~43 ~-19 ~45 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~44 ~-19 ~45 ~45 ~-19 ~45 minecraft:air
fill ~46 ~-19 ~45 ~47 ~-19 ~45 minecraft:red_carpet
fill ~48 ~-19 ~45 ~49 ~-19 ~45 minecraft:air
setblock ~50 ~-19 ~45 minecraft:light_gray_concrete
fill ~51 ~-19 ~45 ~56 ~-19 ~45 minecraft:air
setblock ~57 ~-19 ~45 minecraft:smooth_stone_slab[type=top]
fill ~58 ~-19 ~45 ~63 ~-19 ~45 minecraft:air
setblock ~64 ~-19 ~45 minecraft:light_gray_concrete
setblock ~4 ~-19 ~46 minecraft:light_gray_concrete
fill ~5 ~-19 ~46 ~7 ~-19 ~46 minecraft:air
setblock ~8 ~-19 ~46 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-19 ~46 ~17 ~-19 ~46 minecraft:air
setblock ~18 ~-19 ~46 minecraft:light_gray_concrete
fill ~19 ~-19 ~46 ~28 ~-19 ~46 minecraft:air
fill ~29 ~-19 ~46 ~32 ~-19 ~46 minecraft:polished_andesite
fill ~33 ~-19 ~46 ~35 ~-19 ~46 minecraft:air
fill ~36 ~-19 ~46 ~39 ~-19 ~46 minecraft:polished_andesite
fill ~40 ~-19 ~46 ~41 ~-19 ~46 minecraft:air
fill ~42 ~-19 ~46 ~44 ~-19 ~46 minecraft:smooth_stone_slab[type=top]
setblock ~45 ~-19 ~46 minecraft:lectern
fill ~46 ~-19 ~46 ~47 ~-19 ~46 minecraft:red_carpet
fill ~48 ~-19 ~46 ~49 ~-19 ~46 minecraft:air
setblock ~50 ~-19 ~46 minecraft:light_gray_concrete
setblock ~51 ~-19 ~46 minecraft:cauldron
fill ~52 ~-19 ~46 ~62 ~-19 ~46 minecraft:air
setblock ~63 ~-19 ~46 minecraft:cauldron
setblock ~64 ~-19 ~46 minecraft:light_gray_concrete
setblock ~4 ~-19 ~47 minecraft:light_gray_concrete
fill ~5 ~-19 ~47 ~17 ~-19 ~47 minecraft:air
setblock ~18 ~-19 ~47 minecraft:light_gray_concrete
fill ~19 ~-19 ~47 ~28 ~-19 ~47 minecraft:air
setblock ~29 ~-19 ~47 minecraft:barrel
fill ~30 ~-19 ~47 ~31 ~-19 ~47 minecraft:air
setblock ~32 ~-19 ~47 minecraft:light_gray_concrete
fill ~33 ~-19 ~47 ~35 ~-19 ~47 minecraft:air
setblock ~36 ~-19 ~47 minecraft:light_gray_concrete
fill ~37 ~-19 ~47 ~42 ~-19 ~47 minecraft:air
fill ~43 ~-19 ~47 ~47 ~-19 ~47 minecraft:red_carpet
fill ~48 ~-19 ~47 ~49 ~-19 ~47 minecraft:air
setblock ~50 ~-19 ~47 minecraft:light_gray_concrete
fill ~51 ~-19 ~47 ~63 ~-19 ~47 minecraft:air
setblock ~64 ~-19 ~47 minecraft:light_gray_concrete
setblock ~4 ~-19 ~48 minecraft:light_gray_concrete
fill ~5 ~-19 ~48 ~7 ~-19 ~48 minecraft:air
setblock ~8 ~-19 ~48 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-19 ~48 ~17 ~-19 ~48 minecraft:air
setblock ~18 ~-19 ~48 minecraft:light_gray_concrete
setblock ~19 ~-19 ~48 minecraft:barrel
fill ~20 ~-19 ~48 ~49 ~-19 ~48 minecraft:air
setblock ~50 ~-19 ~48 minecraft:light_gray_concrete
fill ~51 ~-19 ~48 ~63 ~-19 ~48 minecraft:air
setblock ~64 ~-19 ~48 minecraft:light_gray_concrete
setblock ~4 ~-19 ~49 minecraft:light_gray_concrete
fill ~5 ~-19 ~49 ~7 ~-19 ~49 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~8 ~-19 ~49 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-19 ~49 ~17 ~-19 ~49 minecraft:air
setblock ~18 ~-19 ~49 minecraft:light_gray_concrete
setblock ~19 ~-19 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~20 ~-19 ~49 minecraft:air
setblock ~21 ~-19 ~49 minecraft:barrel
setblock ~22 ~-19 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~23 ~-19 ~49 minecraft:air
setblock ~24 ~-19 ~49 minecraft:barrel
setblock ~25 ~-19 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~26 ~-19 ~49 minecraft:air
setblock ~27 ~-19 ~49 minecraft:barrel
setblock ~28 ~-19 ~49 minecraft:smooth_stone_slab[type=top]
setblock ~29 ~-19 ~49 minecraft:air
setblock ~30 ~-19 ~49 minecraft:barrel
setblock ~31 ~-19 ~49 minecraft:air
setblock ~32 ~-19 ~49 minecraft:light_gray_concrete
fill ~33 ~-19 ~49 ~35 ~-19 ~49 minecraft:air
setblock ~36 ~-19 ~49 minecraft:light_gray_concrete
setblock ~37 ~-19 ~49 minecraft:air
fill ~38 ~-19 ~49 ~48 ~-19 ~49 minecraft:chiseled_bookshelf[facing=north]
setblock ~49 ~-19 ~49 minecraft:air
setblock ~50 ~-19 ~49 minecraft:light_gray_concrete
setblock ~51 ~-19 ~49 minecraft:air
setblock ~52 ~-19 ~49 minecraft:cauldron
fill ~53 ~-19 ~49 ~59 ~-19 ~49 minecraft:air
setblock ~60 ~-19 ~49 minecraft:cauldron
fill ~61 ~-19 ~49 ~63 ~-19 ~49 minecraft:air
setblock ~64 ~-19 ~49 minecraft:light_gray_concrete
fill ~4 ~-19 ~50 ~10 ~-19 ~50 minecraft:light_gray_concrete
setblock ~11 ~-19 ~50 minecraft:air
fill ~12 ~-19 ~50 ~32 ~-19 ~50 minecraft:light_gray_concrete
fill ~33 ~-19 ~50 ~35 ~-19 ~50 minecraft:air
fill ~36 ~-19 ~50 ~56 ~-19 ~50 minecraft:light_gray_concrete
setblock ~57 ~-19 ~50 minecraft:air
fill ~58 ~-19 ~50 ~64 ~-19 ~50 minecraft:light_gray_concrete
setblock ~4 ~-19 ~51 minecraft:light_gray_concrete
setblock ~5 ~-19 ~51 minecraft:air
setblock ~6 ~-19 ~51 minecraft:barrel
setblock ~7 ~-19 ~51 minecraft:air
setblock ~8 ~-19 ~51 minecraft:barrel
fill ~9 ~-19 ~51 ~13 ~-19 ~51 minecraft:air
setblock ~14 ~-19 ~51 minecraft:barrel
setblock ~15 ~-19 ~51 minecraft:air
setblock ~16 ~-19 ~51 minecraft:barrel
setblock ~17 ~-19 ~51 minecraft:air
setblock ~18 ~-19 ~51 minecraft:light_gray_concrete
fill ~19 ~-19 ~51 ~31 ~-19 ~51 minecraft:air
setblock ~32 ~-19 ~51 minecraft:light_gray_concrete
fill ~33 ~-19 ~51 ~35 ~-19 ~51 minecraft:air
setblock ~36 ~-19 ~51 minecraft:light_gray_concrete
setblock ~37 ~-19 ~51 minecraft:chest[facing=south]
setblock ~38 ~-19 ~51 minecraft:air
setblock ~39 ~-19 ~51 minecraft:chest[facing=south]
setblock ~40 ~-19 ~51 minecraft:air
setblock ~41 ~-19 ~51 minecraft:chest[facing=south]
setblock ~42 ~-19 ~51 minecraft:air
setblock ~43 ~-19 ~51 minecraft:chest[facing=south]
setblock ~44 ~-19 ~51 minecraft:air
setblock ~45 ~-19 ~51 minecraft:chest[facing=south]
setblock ~46 ~-19 ~51 minecraft:air
setblock ~47 ~-19 ~51 minecraft:chest[facing=south]
setblock ~48 ~-19 ~51 minecraft:air
setblock ~49 ~-19 ~51 minecraft:chest[facing=south]
setblock ~50 ~-19 ~51 minecraft:light_gray_concrete
setblock ~51 ~-19 ~51 minecraft:air
setblock ~52 ~-19 ~51 minecraft:barrel
fill ~53 ~-19 ~51 ~54 ~-19 ~51 minecraft:air
setblock ~55 ~-19 ~51 minecraft:barrel
fill ~56 ~-19 ~51 ~60 ~-19 ~51 minecraft:air
setblock ~61 ~-19 ~51 minecraft:barrel
fill ~62 ~-19 ~51 ~63 ~-19 ~51 minecraft:air
setblock ~64 ~-19 ~51 minecraft:light_gray_concrete
setblock ~4 ~-19 ~52 minecraft:light_gray_concrete
setblock ~5 ~-19 ~52 minecraft:barrel
fill ~6 ~-19 ~52 ~16 ~-19 ~52 minecraft:air
setblock ~17 ~-19 ~52 minecraft:barrel
setblock ~18 ~-19 ~52 minecraft:light_gray_concrete
fill ~19 ~-19 ~52 ~31 ~-19 ~52 minecraft:air
setblock ~32 ~-19 ~52 minecraft:light_gray_concrete
fill ~33 ~-19 ~52 ~35 ~-19 ~52 minecraft:air
setblock ~36 ~-19 ~52 minecraft:light_gray_concrete
setblock ~37 ~-19 ~52 minecraft:air
fill ~38 ~-19 ~52 ~41 ~-19 ~52 minecraft:barrel
setblock ~42 ~-19 ~52 minecraft:air
fill ~43 ~-19 ~52 ~46 ~-19 ~52 minecraft:barrel
setblock ~47 ~-19 ~52 minecraft:air
setblock ~48 ~-19 ~52 minecraft:barrel
setblock ~49 ~-19 ~52 minecraft:air
setblock ~50 ~-19 ~52 minecraft:light_gray_concrete
fill ~51 ~-19 ~52 ~63 ~-19 ~52 minecraft:air
setblock ~64 ~-19 ~52 minecraft:light_gray_concrete
setblock ~4 ~-19 ~53 minecraft:light_gray_concrete
fill ~5 ~-19 ~53 ~17 ~-19 ~53 minecraft:air
setblock ~18 ~-19 ~53 minecraft:light_gray_concrete
fill ~19 ~-19 ~53 ~31 ~-19 ~53 minecraft:air
setblock ~32 ~-19 ~53 minecraft:light_gray_concrete
fill ~33 ~-19 ~53 ~35 ~-19 ~53 minecraft:air
setblock ~36 ~-19 ~53 minecraft:light_gray_concrete
setblock ~37 ~-19 ~53 minecraft:chest[facing=east]
fill ~38 ~-19 ~53 ~48 ~-19 ~53 minecraft:air
setblock ~49 ~-19 ~53 minecraft:chest[facing=west]
setblock ~50 ~-19 ~53 minecraft:light_gray_concrete
fill ~51 ~-19 ~53 ~63 ~-19 ~53 minecraft:air
setblock ~64 ~-19 ~53 minecraft:light_gray_concrete
setblock ~4 ~-19 ~54 minecraft:light_gray_concrete
setblock ~5 ~-19 ~54 minecraft:barrel
fill ~6 ~-19 ~54 ~16 ~-19 ~54 minecraft:air
setblock ~17 ~-19 ~54 minecraft:barrel
setblock ~18 ~-19 ~54 minecraft:light_gray_concrete
fill ~19 ~-19 ~54 ~31 ~-19 ~54 minecraft:air
setblock ~32 ~-19 ~54 minecraft:light_gray_concrete
fill ~33 ~-19 ~54 ~35 ~-19 ~54 minecraft:air
setblock ~36 ~-19 ~54 minecraft:light_gray_concrete
fill ~37 ~-19 ~54 ~49 ~-19 ~54 minecraft:air
setblock ~50 ~-19 ~54 minecraft:light_gray_concrete
fill ~51 ~-19 ~54 ~53 ~-19 ~54 minecraft:air
fill ~54 ~-19 ~54 ~60 ~-19 ~54 minecraft:light_gray_carpet
fill ~61 ~-19 ~54 ~63 ~-19 ~54 minecraft:air
setblock ~64 ~-19 ~54 minecraft:light_gray_concrete
setblock ~4 ~-19 ~55 minecraft:light_gray_concrete
fill ~5 ~-19 ~55 ~7 ~-19 ~55 minecraft:air
setblock ~8 ~-19 ~55 minecraft:iron_block
fill ~9 ~-19 ~55 ~13 ~-19 ~55 minecraft:smooth_stone_slab[type=top]
setblock ~14 ~-19 ~55 minecraft:iron_block
fill ~15 ~-19 ~55 ~17 ~-19 ~55 minecraft:air
setblock ~18 ~-19 ~55 minecraft:light_gray_concrete
setblock ~19 ~-19 ~55 minecraft:air
fill ~20 ~-19 ~55 ~24 ~-19 ~55 minecraft:smooth_stone_slab[type=top]
setblock ~25 ~-19 ~55 minecraft:air
fill ~26 ~-19 ~55 ~30 ~-19 ~55 minecraft:smooth_stone_slab[type=top]
setblock ~31 ~-19 ~55 minecraft:air
setblock ~32 ~-19 ~55 minecraft:light_gray_concrete
fill ~33 ~-19 ~55 ~35 ~-19 ~55 minecraft:air
setblock ~36 ~-19 ~55 minecraft:light_gray_concrete
setblock ~37 ~-19 ~55 minecraft:chest[facing=east]
fill ~38 ~-19 ~55 ~41 ~-19 ~55 minecraft:barrel
setblock ~42 ~-19 ~55 minecraft:air
fill ~43 ~-19 ~55 ~46 ~-19 ~55 minecraft:barrel
setblock ~47 ~-19 ~55 minecraft:air
setblock ~48 ~-19 ~55 minecraft:barrel
setblock ~49 ~-19 ~55 minecraft:chest[facing=west]
setblock ~50 ~-19 ~55 minecraft:light_gray_concrete
setblock ~51 ~-19 ~55 minecraft:barrel
fill ~52 ~-19 ~55 ~53 ~-19 ~55 minecraft:air
fill ~54 ~-19 ~55 ~60 ~-19 ~55 minecraft:light_gray_carpet
fill ~61 ~-19 ~55 ~62 ~-19 ~55 minecraft:air
setblock ~63 ~-19 ~55 minecraft:barrel
setblock ~64 ~-19 ~55 minecraft:light_gray_concrete
setblock ~4 ~-19 ~56 minecraft:light_gray_concrete
setblock ~5 ~-19 ~56 minecraft:barrel
fill ~6 ~-19 ~56 ~17 ~-19 ~56 minecraft:air
setblock ~18 ~-19 ~56 minecraft:light_gray_concrete
fill ~19 ~-19 ~56 ~31 ~-19 ~56 minecraft:air
setblock ~32 ~-19 ~56 minecraft:light_gray_concrete
fill ~33 ~-19 ~56 ~35 ~-19 ~56 minecraft:air
setblock ~36 ~-19 ~56 minecraft:light_gray_concrete
fill ~37 ~-19 ~56 ~49 ~-19 ~56 minecraft:air
setblock ~50 ~-19 ~56 minecraft:light_gray_concrete
fill ~51 ~-19 ~56 ~53 ~-19 ~56 minecraft:air
fill ~54 ~-19 ~56 ~60 ~-19 ~56 minecraft:light_gray_carpet
fill ~61 ~-19 ~56 ~63 ~-19 ~56 minecraft:air
setblock ~64 ~-19 ~56 minecraft:light_gray_concrete
setblock ~4 ~-19 ~57 minecraft:light_gray_concrete
fill ~5 ~-19 ~57 ~53 ~-19 ~57 minecraft:air
fill ~54 ~-19 ~57 ~56 ~-19 ~57 minecraft:light_gray_carpet
setblock ~57 ~-19 ~57 minecraft:spruce_slab[type=top]
fill ~58 ~-19 ~57 ~60 ~-19 ~57 minecraft:light_gray_carpet
fill ~61 ~-19 ~57 ~63 ~-19 ~57 minecraft:air
setblock ~64 ~-19 ~57 minecraft:light_gray_concrete
setblock ~4 ~-19 ~58 minecraft:light_gray_concrete
setblock ~5 ~-19 ~58 minecraft:barrel
fill ~6 ~-19 ~58 ~7 ~-19 ~58 minecraft:air
setblock ~8 ~-19 ~58 minecraft:iron_block
fill ~9 ~-19 ~58 ~13 ~-19 ~58 minecraft:smooth_stone_slab[type=top]
setblock ~14 ~-19 ~58 minecraft:iron_block
fill ~15 ~-19 ~58 ~17 ~-19 ~58 minecraft:air
setblock ~18 ~-19 ~58 minecraft:light_gray_concrete
fill ~19 ~-19 ~58 ~20 ~-19 ~58 minecraft:air
setblock ~21 ~-19 ~58 minecraft:iron_bars[south=true]
fill ~22 ~-19 ~58 ~23 ~-19 ~58 minecraft:air
setblock ~24 ~-19 ~58 minecraft:iron_bars[south=true]
fill ~25 ~-19 ~58 ~26 ~-19 ~58 minecraft:air
setblock ~27 ~-19 ~58 minecraft:iron_bars[south=true]
fill ~28 ~-19 ~58 ~29 ~-19 ~58 minecraft:air
setblock ~30 ~-19 ~58 minecraft:iron_bars[south=true]
setblock ~31 ~-19 ~58 minecraft:air
setblock ~32 ~-19 ~58 minecraft:light_gray_concrete
fill ~33 ~-19 ~58 ~35 ~-19 ~58 minecraft:air
setblock ~36 ~-19 ~58 minecraft:light_gray_concrete
setblock ~37 ~-19 ~58 minecraft:air
fill ~38 ~-19 ~58 ~41 ~-19 ~58 minecraft:barrel
setblock ~42 ~-19 ~58 minecraft:air
fill ~43 ~-19 ~58 ~46 ~-19 ~58 minecraft:barrel
setblock ~47 ~-19 ~58 minecraft:air
setblock ~48 ~-19 ~58 minecraft:barrel
setblock ~49 ~-19 ~58 minecraft:air
setblock ~50 ~-19 ~58 minecraft:light_gray_concrete
fill ~51 ~-19 ~58 ~53 ~-19 ~58 minecraft:air
fill ~54 ~-19 ~58 ~60 ~-19 ~58 minecraft:light_gray_carpet
fill ~61 ~-19 ~58 ~62 ~-19 ~58 minecraft:air
setblock ~63 ~-19 ~58 minecraft:barrel
setblock ~64 ~-19 ~58 minecraft:light_gray_concrete
setblock ~4 ~-19 ~59 minecraft:light_gray_concrete
fill ~5 ~-19 ~59 ~17 ~-19 ~59 minecraft:air
setblock ~18 ~-19 ~59 minecraft:light_gray_concrete
fill ~19 ~-19 ~59 ~20 ~-19 ~59 minecraft:air
setblock ~21 ~-19 ~59 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-19 ~59 ~23 ~-19 ~59 minecraft:air
setblock ~24 ~-19 ~59 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-19 ~59 ~26 ~-19 ~59 minecraft:air
setblock ~27 ~-19 ~59 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-19 ~59 ~29 ~-19 ~59 minecraft:air
setblock ~30 ~-19 ~59 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-19 ~59 minecraft:air
setblock ~32 ~-19 ~59 minecraft:light_gray_concrete
fill ~33 ~-19 ~59 ~35 ~-19 ~59 minecraft:air
setblock ~36 ~-19 ~59 minecraft:light_gray_concrete
setblock ~37 ~-19 ~59 minecraft:chest[facing=east]
fill ~38 ~-19 ~59 ~48 ~-19 ~59 minecraft:air
setblock ~49 ~-19 ~59 minecraft:chest[facing=west]
setblock ~50 ~-19 ~59 minecraft:light_gray_concrete
fill ~51 ~-19 ~59 ~53 ~-19 ~59 minecraft:air
fill ~54 ~-19 ~59 ~60 ~-19 ~59 minecraft:light_gray_carpet
fill ~61 ~-19 ~59 ~63 ~-19 ~59 minecraft:air
setblock ~64 ~-19 ~59 minecraft:light_gray_concrete
setblock ~4 ~-19 ~60 minecraft:light_gray_concrete
setblock ~5 ~-19 ~60 minecraft:barrel
fill ~6 ~-19 ~60 ~16 ~-19 ~60 minecraft:air
setblock ~17 ~-19 ~60 minecraft:barrel
setblock ~18 ~-19 ~60 minecraft:light_gray_concrete
fill ~19 ~-19 ~60 ~20 ~-19 ~60 minecraft:air
setblock ~21 ~-19 ~60 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-19 ~60 ~23 ~-19 ~60 minecraft:air
setblock ~24 ~-19 ~60 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-19 ~60 ~26 ~-19 ~60 minecraft:air
setblock ~27 ~-19 ~60 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-19 ~60 ~29 ~-19 ~60 minecraft:air
setblock ~30 ~-19 ~60 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-19 ~60 minecraft:air
setblock ~32 ~-19 ~60 minecraft:light_gray_concrete
fill ~33 ~-19 ~60 ~35 ~-19 ~60 minecraft:air
setblock ~36 ~-19 ~60 minecraft:light_gray_concrete
fill ~37 ~-19 ~60 ~49 ~-19 ~60 minecraft:air
setblock ~50 ~-19 ~60 minecraft:light_gray_concrete
fill ~51 ~-19 ~60 ~53 ~-19 ~60 minecraft:air
fill ~54 ~-19 ~60 ~60 ~-19 ~60 minecraft:light_gray_carpet
fill ~61 ~-19 ~60 ~63 ~-19 ~60 minecraft:air
setblock ~64 ~-19 ~60 minecraft:light_gray_concrete
setblock ~4 ~-19 ~61 minecraft:light_gray_concrete
fill ~5 ~-19 ~61 ~17 ~-19 ~61 minecraft:air
setblock ~18 ~-19 ~61 minecraft:light_gray_concrete
fill ~19 ~-19 ~61 ~20 ~-19 ~61 minecraft:air
setblock ~21 ~-19 ~61 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-19 ~61 ~23 ~-19 ~61 minecraft:air
setblock ~24 ~-19 ~61 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-19 ~61 ~26 ~-19 ~61 minecraft:air
setblock ~27 ~-19 ~61 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-19 ~61 ~29 ~-19 ~61 minecraft:air
setblock ~30 ~-19 ~61 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-19 ~61 minecraft:air
setblock ~32 ~-19 ~61 minecraft:light_gray_concrete
fill ~33 ~-19 ~61 ~35 ~-19 ~61 minecraft:air
setblock ~36 ~-19 ~61 minecraft:light_gray_concrete
setblock ~37 ~-19 ~61 minecraft:chest[facing=east]
fill ~38 ~-19 ~61 ~41 ~-19 ~61 minecraft:barrel
setblock ~42 ~-19 ~61 minecraft:air
fill ~43 ~-19 ~61 ~46 ~-19 ~61 minecraft:barrel
setblock ~47 ~-19 ~61 minecraft:air
setblock ~48 ~-19 ~61 minecraft:barrel
setblock ~49 ~-19 ~61 minecraft:chest[facing=west]
setblock ~50 ~-19 ~61 minecraft:light_gray_concrete
setblock ~51 ~-19 ~61 minecraft:barrel
fill ~52 ~-19 ~61 ~62 ~-19 ~61 minecraft:air
setblock ~63 ~-19 ~61 minecraft:barrel
setblock ~64 ~-19 ~61 minecraft:light_gray_concrete
setblock ~4 ~-19 ~62 minecraft:light_gray_concrete
setblock ~5 ~-19 ~62 minecraft:barrel
fill ~6 ~-19 ~62 ~16 ~-19 ~62 minecraft:air
setblock ~17 ~-19 ~62 minecraft:barrel
setblock ~18 ~-19 ~62 minecraft:light_gray_concrete
fill ~19 ~-19 ~62 ~20 ~-19 ~62 minecraft:air
setblock ~21 ~-19 ~62 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-19 ~62 ~23 ~-19 ~62 minecraft:air
setblock ~24 ~-19 ~62 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-19 ~62 ~26 ~-19 ~62 minecraft:air
setblock ~27 ~-19 ~62 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-19 ~62 ~29 ~-19 ~62 minecraft:air
setblock ~30 ~-19 ~62 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-19 ~62 minecraft:air
setblock ~32 ~-19 ~62 minecraft:light_gray_concrete
fill ~33 ~-19 ~62 ~35 ~-19 ~62 minecraft:air
setblock ~36 ~-19 ~62 minecraft:light_gray_concrete
fill ~37 ~-19 ~62 ~49 ~-19 ~62 minecraft:air
setblock ~50 ~-19 ~62 minecraft:light_gray_concrete
fill ~51 ~-19 ~62 ~63 ~-19 ~62 minecraft:air
setblock ~64 ~-19 ~62 minecraft:light_gray_concrete
setblock ~4 ~-19 ~63 minecraft:light_gray_concrete
setblock ~5 ~-19 ~63 minecraft:air
setblock ~6 ~-19 ~63 minecraft:barrel
setblock ~7 ~-19 ~63 minecraft:air
setblock ~8 ~-19 ~63 minecraft:barrel
setblock ~9 ~-19 ~63 minecraft:air
setblock ~10 ~-19 ~63 minecraft:barrel
setblock ~11 ~-19 ~63 minecraft:air
setblock ~12 ~-19 ~63 minecraft:barrel
setblock ~13 ~-19 ~63 minecraft:air
setblock ~14 ~-19 ~63 minecraft:barrel
setblock ~15 ~-19 ~63 minecraft:air
setblock ~16 ~-19 ~63 minecraft:barrel
setblock ~17 ~-19 ~63 minecraft:air
setblock ~18 ~-19 ~63 minecraft:light_gray_concrete
fill ~19 ~-19 ~63 ~30 ~-19 ~63 minecraft:hay_block
setblock ~31 ~-19 ~63 minecraft:air
setblock ~32 ~-19 ~63 minecraft:light_gray_concrete
fill ~33 ~-19 ~63 ~35 ~-19 ~63 minecraft:air
setblock ~36 ~-19 ~63 minecraft:light_gray_concrete
setblock ~37 ~-19 ~63 minecraft:chest[facing=north]
setblock ~38 ~-19 ~63 minecraft:air
setblock ~39 ~-19 ~63 minecraft:chest[facing=north]
setblock ~40 ~-19 ~63 minecraft:air
setblock ~41 ~-19 ~63 minecraft:chest[facing=north]
setblock ~42 ~-19 ~63 minecraft:air
setblock ~43 ~-19 ~63 minecraft:chest[facing=north]
setblock ~44 ~-19 ~63 minecraft:air
setblock ~45 ~-19 ~63 minecraft:chest[facing=north]
setblock ~46 ~-19 ~63 minecraft:air
setblock ~47 ~-19 ~63 minecraft:chest[facing=north]
setblock ~48 ~-19 ~63 minecraft:air
setblock ~49 ~-19 ~63 minecraft:chest[facing=west]
setblock ~50 ~-19 ~63 minecraft:light_gray_concrete
setblock ~51 ~-19 ~63 minecraft:air
setblock ~52 ~-19 ~63 minecraft:barrel
fill ~53 ~-19 ~63 ~54 ~-19 ~63 minecraft:air
setblock ~55 ~-19 ~63 minecraft:barrel
fill ~56 ~-19 ~63 ~57 ~-19 ~63 minecraft:air
setblock ~58 ~-19 ~63 minecraft:barrel
fill ~59 ~-19 ~63 ~60 ~-19 ~63 minecraft:air
setblock ~61 ~-19 ~63 minecraft:barrel
fill ~62 ~-19 ~63 ~63 ~-19 ~63 minecraft:air
setblock ~64 ~-19 ~63 minecraft:light_gray_concrete
fill ~4 ~-19 ~64 ~33 ~-19 ~64 minecraft:light_gray_concrete
setblock ~34 ~-19 ~64 minecraft:air
fill ~35 ~-19 ~64 ~64 ~-19 ~64 minecraft:light_gray_concrete
setblock ~33 ~-19 ~65 minecraft:light_gray_concrete
setblock ~34 ~-19 ~65 minecraft:air
setblock ~35 ~-19 ~65 minecraft:light_gray_concrete
fill ~32 ~-19 ~66 ~33 ~-19 ~66 minecraft:polished_andesite
setblock ~34 ~-19 ~66 minecraft:air
fill ~35 ~-19 ~66 ~36 ~-19 ~66 minecraft:polished_andesite
setblock ~32 ~-19 ~67 minecraft:polished_andesite
fill ~33 ~-19 ~67 ~34 ~-19 ~67 minecraft:air
setblock ~35 ~-19 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-19 ~67 minecraft:polished_andesite
setblock ~32 ~-19 ~68 minecraft:polished_andesite
setblock ~33 ~-19 ~68 minecraft:air
setblock ~34 ~-19 ~68 minecraft:quartz_pillar
setblock ~35 ~-19 ~68 minecraft:air
setblock ~36 ~-19 ~68 minecraft:polished_andesite
setblock ~32 ~-19 ~69 minecraft:polished_andesite
fill ~33 ~-19 ~69 ~35 ~-19 ~69 minecraft:air
setblock ~36 ~-19 ~69 minecraft:polished_andesite
fill ~32 ~-19 ~70 ~36 ~-19 ~70 minecraft:polished_andesite
fill ~4 ~-18 ~4 ~64 ~-18 ~4 minecraft:light_gray_concrete
setblock ~4 ~-18 ~5 minecraft:light_gray_concrete
fill ~5 ~-18 ~5 ~17 ~-18 ~5 minecraft:air
setblock ~18 ~-18 ~5 minecraft:light_gray_concrete
setblock ~19 ~-18 ~5 minecraft:air
fill ~20 ~-18 ~5 ~23 ~-18 ~5 minecraft:barrel
setblock ~24 ~-18 ~5 minecraft:air
fill ~25 ~-18 ~5 ~28 ~-18 ~5 minecraft:barrel
setblock ~29 ~-18 ~5 minecraft:air
fill ~30 ~-18 ~5 ~31 ~-18 ~5 minecraft:barrel
setblock ~32 ~-18 ~5 minecraft:red_concrete
fill ~33 ~-18 ~5 ~35 ~-18 ~5 minecraft:air
setblock ~36 ~-18 ~5 minecraft:red_concrete
fill ~37 ~-18 ~5 ~49 ~-18 ~5 minecraft:air
setblock ~50 ~-18 ~5 minecraft:light_gray_concrete
fill ~51 ~-18 ~5 ~63 ~-18 ~5 minecraft:air
setblock ~64 ~-18 ~5 minecraft:light_gray_concrete
setblock ~4 ~-18 ~6 minecraft:light_gray_concrete
fill ~5 ~-18 ~6 ~17 ~-18 ~6 minecraft:air
setblock ~18 ~-18 ~6 minecraft:light_gray_concrete
setblock ~19 ~-18 ~6 minecraft:barrel
fill ~20 ~-18 ~6 ~30 ~-18 ~6 minecraft:air
setblock ~31 ~-18 ~6 minecraft:barrel
setblock ~32 ~-18 ~6 minecraft:red_concrete
fill ~33 ~-18 ~6 ~35 ~-18 ~6 minecraft:air
setblock ~36 ~-18 ~6 minecraft:red_concrete
fill ~37 ~-18 ~6 ~49 ~-18 ~6 minecraft:air
setblock ~50 ~-18 ~6 minecraft:light_gray_concrete
fill ~51 ~-18 ~6 ~63 ~-18 ~6 minecraft:air
setblock ~64 ~-18 ~6 minecraft:light_gray_concrete
setblock ~4 ~-18 ~7 minecraft:light_gray_concrete
fill ~5 ~-18 ~7 ~17 ~-18 ~7 minecraft:air
setblock ~18 ~-18 ~7 minecraft:light_gray_concrete
setblock ~19 ~-18 ~7 minecraft:barrel
fill ~20 ~-18 ~7 ~30 ~-18 ~7 minecraft:air
setblock ~31 ~-18 ~7 minecraft:barrel
setblock ~32 ~-18 ~7 minecraft:red_concrete
fill ~33 ~-18 ~7 ~35 ~-18 ~7 minecraft:air
setblock ~36 ~-18 ~7 minecraft:red_concrete
fill ~37 ~-18 ~7 ~49 ~-18 ~7 minecraft:air
setblock ~50 ~-18 ~7 minecraft:light_gray_concrete
fill ~51 ~-18 ~7 ~63 ~-18 ~7 minecraft:air
setblock ~64 ~-18 ~7 minecraft:light_gray_concrete
setblock ~4 ~-18 ~8 minecraft:light_gray_concrete
fill ~5 ~-18 ~8 ~17 ~-18 ~8 minecraft:air
setblock ~18 ~-18 ~8 minecraft:light_gray_concrete
setblock ~19 ~-18 ~8 minecraft:barrel
fill ~20 ~-18 ~8 ~31 ~-18 ~8 minecraft:air
setblock ~32 ~-18 ~8 minecraft:red_concrete
fill ~33 ~-18 ~8 ~35 ~-18 ~8 minecraft:air
setblock ~36 ~-18 ~8 minecraft:red_concrete
fill ~37 ~-18 ~8 ~49 ~-18 ~8 minecraft:air
setblock ~50 ~-18 ~8 minecraft:light_gray_concrete
fill ~51 ~-18 ~8 ~63 ~-18 ~8 minecraft:air
setblock ~64 ~-18 ~8 minecraft:light_gray_concrete
setblock ~4 ~-18 ~9 minecraft:light_gray_concrete
fill ~5 ~-18 ~9 ~17 ~-18 ~9 minecraft:air
setblock ~18 ~-18 ~9 minecraft:light_gray_concrete
setblock ~19 ~-18 ~9 minecraft:barrel
fill ~20 ~-18 ~9 ~30 ~-18 ~9 minecraft:air
setblock ~31 ~-18 ~9 minecraft:barrel
setblock ~32 ~-18 ~9 minecraft:red_concrete
fill ~33 ~-18 ~9 ~35 ~-18 ~9 minecraft:air
setblock ~36 ~-18 ~9 minecraft:red_concrete
fill ~37 ~-18 ~9 ~49 ~-18 ~9 minecraft:air
setblock ~50 ~-18 ~9 minecraft:light_gray_concrete
fill ~51 ~-18 ~9 ~63 ~-18 ~9 minecraft:air
setblock ~64 ~-18 ~9 minecraft:light_gray_concrete
setblock ~4 ~-18 ~10 minecraft:light_gray_concrete
fill ~5 ~-18 ~10 ~17 ~-18 ~10 minecraft:air
setblock ~18 ~-18 ~10 minecraft:light_gray_concrete
fill ~19 ~-18 ~10 ~31 ~-18 ~10 minecraft:air
setblock ~32 ~-18 ~10 minecraft:red_concrete
fill ~33 ~-18 ~10 ~35 ~-18 ~10 minecraft:air
setblock ~36 ~-18 ~10 minecraft:red_concrete
fill ~37 ~-18 ~10 ~49 ~-18 ~10 minecraft:air
setblock ~50 ~-18 ~10 minecraft:light_gray_concrete
fill ~51 ~-18 ~10 ~63 ~-18 ~10 minecraft:air
setblock ~64 ~-18 ~10 minecraft:light_gray_concrete
setblock ~4 ~-18 ~11 minecraft:light_gray_concrete
fill ~5 ~-18 ~11 ~63 ~-18 ~11 minecraft:air
setblock ~64 ~-18 ~11 minecraft:light_gray_concrete
setblock ~4 ~-18 ~12 minecraft:light_gray_concrete
fill ~5 ~-18 ~12 ~17 ~-18 ~12 minecraft:air
setblock ~18 ~-18 ~12 minecraft:light_gray_concrete
fill ~19 ~-18 ~12 ~31 ~-18 ~12 minecraft:air
setblock ~32 ~-18 ~12 minecraft:red_concrete
fill ~33 ~-18 ~12 ~35 ~-18 ~12 minecraft:air
setblock ~36 ~-18 ~12 minecraft:red_concrete
fill ~37 ~-18 ~12 ~49 ~-18 ~12 minecraft:air
setblock ~50 ~-18 ~12 minecraft:light_gray_concrete
fill ~51 ~-18 ~12 ~63 ~-18 ~12 minecraft:air
setblock ~64 ~-18 ~12 minecraft:light_gray_concrete
setblock ~4 ~-18 ~13 minecraft:light_gray_concrete
fill ~5 ~-18 ~13 ~17 ~-18 ~13 minecraft:air
setblock ~18 ~-18 ~13 minecraft:light_gray_concrete
setblock ~19 ~-18 ~13 minecraft:barrel
fill ~20 ~-18 ~13 ~31 ~-18 ~13 minecraft:air
setblock ~32 ~-18 ~13 minecraft:red_concrete
fill ~33 ~-18 ~13 ~35 ~-18 ~13 minecraft:air
setblock ~36 ~-18 ~13 minecraft:red_concrete
fill ~37 ~-18 ~13 ~49 ~-18 ~13 minecraft:air
setblock ~50 ~-18 ~13 minecraft:light_gray_concrete
fill ~51 ~-18 ~13 ~63 ~-18 ~13 minecraft:air
setblock ~64 ~-18 ~13 minecraft:light_gray_concrete
setblock ~4 ~-18 ~14 minecraft:light_gray_concrete
fill ~5 ~-18 ~14 ~17 ~-18 ~14 minecraft:air
setblock ~18 ~-18 ~14 minecraft:light_gray_concrete
setblock ~19 ~-18 ~14 minecraft:barrel
fill ~20 ~-18 ~14 ~30 ~-18 ~14 minecraft:air
setblock ~31 ~-18 ~14 minecraft:barrel
setblock ~32 ~-18 ~14 minecraft:red_concrete
fill ~33 ~-18 ~14 ~35 ~-18 ~14 minecraft:air
setblock ~36 ~-18 ~14 minecraft:red_concrete
fill ~37 ~-18 ~14 ~49 ~-18 ~14 minecraft:air
setblock ~50 ~-18 ~14 minecraft:light_gray_concrete
fill ~51 ~-18 ~14 ~63 ~-18 ~14 minecraft:air
setblock ~64 ~-18 ~14 minecraft:light_gray_concrete
setblock ~4 ~-18 ~15 minecraft:light_gray_concrete
fill ~5 ~-18 ~15 ~17 ~-18 ~15 minecraft:air
setblock ~18 ~-18 ~15 minecraft:light_gray_concrete
fill ~19 ~-18 ~15 ~30 ~-18 ~15 minecraft:air
setblock ~31 ~-18 ~15 minecraft:barrel
setblock ~32 ~-18 ~15 minecraft:red_concrete
fill ~33 ~-18 ~15 ~35 ~-18 ~15 minecraft:air
setblock ~36 ~-18 ~15 minecraft:red_concrete
fill ~37 ~-18 ~15 ~49 ~-18 ~15 minecraft:air
setblock ~50 ~-18 ~15 minecraft:light_gray_concrete
fill ~51 ~-18 ~15 ~63 ~-18 ~15 minecraft:air
setblock ~64 ~-18 ~15 minecraft:light_gray_concrete
setblock ~4 ~-18 ~16 minecraft:light_gray_concrete
fill ~5 ~-18 ~16 ~17 ~-18 ~16 minecraft:air
setblock ~18 ~-18 ~16 minecraft:light_gray_concrete
setblock ~19 ~-18 ~16 minecraft:barrel
fill ~20 ~-18 ~16 ~30 ~-18 ~16 minecraft:air
setblock ~31 ~-18 ~16 minecraft:barrel
setblock ~32 ~-18 ~16 minecraft:red_concrete
fill ~33 ~-18 ~16 ~35 ~-18 ~16 minecraft:air
setblock ~36 ~-18 ~16 minecraft:red_concrete
fill ~37 ~-18 ~16 ~49 ~-18 ~16 minecraft:air
setblock ~50 ~-18 ~16 minecraft:light_gray_concrete
fill ~51 ~-18 ~16 ~63 ~-18 ~16 minecraft:air
setblock ~64 ~-18 ~16 minecraft:light_gray_concrete
setblock ~4 ~-18 ~17 minecraft:light_gray_concrete
fill ~5 ~-18 ~17 ~17 ~-18 ~17 minecraft:air
setblock ~18 ~-18 ~17 minecraft:light_gray_concrete
fill ~19 ~-18 ~17 ~21 ~-18 ~17 minecraft:barrel
setblock ~22 ~-18 ~17 minecraft:air
fill ~23 ~-18 ~17 ~26 ~-18 ~17 minecraft:barrel
setblock ~27 ~-18 ~17 minecraft:air
fill ~28 ~-18 ~17 ~31 ~-18 ~17 minecraft:barrel
setblock ~32 ~-18 ~17 minecraft:red_concrete
fill ~33 ~-18 ~17 ~35 ~-18 ~17 minecraft:air
setblock ~36 ~-18 ~17 minecraft:red_concrete
fill ~37 ~-18 ~17 ~49 ~-18 ~17 minecraft:air
setblock ~50 ~-18 ~17 minecraft:light_gray_concrete
fill ~51 ~-18 ~17 ~63 ~-18 ~17 minecraft:air
setblock ~64 ~-18 ~17 minecraft:light_gray_concrete
fill ~4 ~-18 ~18 ~10 ~-18 ~18 minecraft:light_gray_concrete
setblock ~11 ~-18 ~18 minecraft:air
fill ~12 ~-18 ~18 ~31 ~-18 ~18 minecraft:light_gray_concrete
setblock ~32 ~-18 ~18 minecraft:red_concrete
fill ~33 ~-18 ~18 ~35 ~-18 ~18 minecraft:air
setblock ~36 ~-18 ~18 minecraft:red_concrete
fill ~37 ~-18 ~18 ~56 ~-18 ~18 minecraft:light_gray_concrete
setblock ~57 ~-18 ~18 minecraft:air
fill ~58 ~-18 ~18 ~64 ~-18 ~18 minecraft:light_gray_concrete
setblock ~4 ~-18 ~19 minecraft:light_gray_concrete
fill ~5 ~-18 ~19 ~17 ~-18 ~19 minecraft:air
setblock ~18 ~-18 ~19 minecraft:light_gray_concrete
fill ~19 ~-18 ~19 ~30 ~-18 ~19 minecraft:black_concrete
setblock ~31 ~-18 ~19 minecraft:air
setblock ~32 ~-18 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-18 ~19 ~35 ~-18 ~19 minecraft:air
setblock ~36 ~-18 ~19 minecraft:glass_pane[north=true,south=true]
setblock ~37 ~-18 ~19 minecraft:air
fill ~38 ~-18 ~19 ~49 ~-18 ~19 minecraft:chiseled_bookshelf[facing=south]
setblock ~50 ~-18 ~19 minecraft:light_gray_concrete
fill ~51 ~-18 ~19 ~63 ~-18 ~19 minecraft:air
setblock ~64 ~-18 ~19 minecraft:light_gray_concrete
setblock ~4 ~-18 ~20 minecraft:light_gray_concrete
fill ~5 ~-18 ~20 ~17 ~-18 ~20 minecraft:air
setblock ~18 ~-18 ~20 minecraft:light_gray_concrete
fill ~19 ~-18 ~20 ~49 ~-18 ~20 minecraft:air
setblock ~50 ~-18 ~20 minecraft:light_gray_concrete
fill ~51 ~-18 ~20 ~63 ~-18 ~20 minecraft:air
setblock ~64 ~-18 ~20 minecraft:light_gray_concrete
setblock ~4 ~-18 ~21 minecraft:light_gray_concrete
fill ~5 ~-18 ~21 ~6 ~-18 ~21 minecraft:air
setblock ~7 ~-18 ~21 minecraft:white_stained_glass_pane
fill ~8 ~-18 ~21 ~9 ~-18 ~21 minecraft:air
setblock ~10 ~-18 ~21 minecraft:white_stained_glass_pane
fill ~11 ~-18 ~21 ~12 ~-18 ~21 minecraft:air
setblock ~13 ~-18 ~21 minecraft:white_stained_glass_pane
fill ~14 ~-18 ~21 ~15 ~-18 ~21 minecraft:air
setblock ~16 ~-18 ~21 minecraft:white_stained_glass_pane
setblock ~17 ~-18 ~21 minecraft:air
setblock ~18 ~-18 ~21 minecraft:light_gray_concrete
fill ~19 ~-18 ~21 ~31 ~-18 ~21 minecraft:air
setblock ~32 ~-18 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-18 ~21 ~35 ~-18 ~21 minecraft:air
setblock ~36 ~-18 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-18 ~21 ~49 ~-18 ~21 minecraft:air
setblock ~50 ~-18 ~21 minecraft:light_gray_concrete
fill ~51 ~-18 ~21 ~63 ~-18 ~21 minecraft:air
setblock ~64 ~-18 ~21 minecraft:light_gray_concrete
setblock ~4 ~-18 ~22 minecraft:light_gray_concrete
setblock ~5 ~-18 ~22 minecraft:air
setblock ~6 ~-18 ~22 minecraft:white_stained_glass_pane
fill ~7 ~-18 ~22 ~8 ~-18 ~22 minecraft:air
setblock ~9 ~-18 ~22 minecraft:white_stained_glass_pane
fill ~10 ~-18 ~22 ~11 ~-18 ~22 minecraft:air
setblock ~12 ~-18 ~22 minecraft:white_stained_glass_pane
fill ~13 ~-18 ~22 ~14 ~-18 ~22 minecraft:air
setblock ~15 ~-18 ~22 minecraft:white_stained_glass_pane
fill ~16 ~-18 ~22 ~17 ~-18 ~22 minecraft:air
setblock ~18 ~-18 ~22 minecraft:light_gray_concrete
setblock ~19 ~-18 ~22 minecraft:black_concrete
setblock ~20 ~-18 ~22 minecraft:air
fill ~21 ~-18 ~22 ~22 ~-18 ~22 minecraft:black_concrete
setblock ~23 ~-18 ~22 minecraft:air
fill ~24 ~-18 ~22 ~25 ~-18 ~22 minecraft:black_concrete
fill ~26 ~-18 ~22 ~28 ~-18 ~22 minecraft:air
setblock ~29 ~-18 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-18 ~22 minecraft:quartz_pillar
setblock ~31 ~-18 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-18 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-18 ~22 ~35 ~-18 ~22 minecraft:air
setblock ~36 ~-18 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-18 ~22 ~38 ~-18 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-18 ~22 minecraft:quartz_pillar
fill ~40 ~-18 ~22 ~49 ~-18 ~22 minecraft:air
setblock ~50 ~-18 ~22 minecraft:light_gray_concrete
fill ~51 ~-18 ~22 ~63 ~-18 ~22 minecraft:air
setblock ~64 ~-18 ~22 minecraft:light_gray_concrete
setblock ~4 ~-18 ~23 minecraft:light_gray_concrete
fill ~5 ~-18 ~23 ~17 ~-18 ~23 minecraft:air
setblock ~18 ~-18 ~23 minecraft:light_gray_concrete
fill ~19 ~-18 ~23 ~28 ~-18 ~23 minecraft:air
setblock ~29 ~-18 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-18 ~23 ~38 ~-18 ~23 minecraft:air
setblock ~39 ~-18 ~23 minecraft:quartz_pillar
fill ~40 ~-18 ~23 ~49 ~-18 ~23 minecraft:air
setblock ~50 ~-18 ~23 minecraft:light_gray_concrete
fill ~51 ~-18 ~23 ~63 ~-18 ~23 minecraft:air
setblock ~64 ~-18 ~23 minecraft:light_gray_concrete
setblock ~4 ~-18 ~24 minecraft:light_gray_concrete
fill ~5 ~-18 ~24 ~6 ~-18 ~24 minecraft:air
setblock ~7 ~-18 ~24 minecraft:white_stained_glass_pane
fill ~8 ~-18 ~24 ~9 ~-18 ~24 minecraft:air
setblock ~10 ~-18 ~24 minecraft:white_stained_glass_pane
fill ~11 ~-18 ~24 ~12 ~-18 ~24 minecraft:air
setblock ~13 ~-18 ~24 minecraft:white_stained_glass_pane
fill ~14 ~-18 ~24 ~15 ~-18 ~24 minecraft:air
setblock ~16 ~-18 ~24 minecraft:white_stained_glass_pane
setblock ~17 ~-18 ~24 minecraft:air
setblock ~18 ~-18 ~24 minecraft:light_gray_concrete
fill ~19 ~-18 ~24 ~25 ~-18 ~24 minecraft:air
setblock ~26 ~-18 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-18 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-18 ~24 ~29 ~-18 ~24 minecraft:air
setblock ~30 ~-18 ~24 minecraft:quartz_pillar
fill ~31 ~-18 ~24 ~37 ~-18 ~24 minecraft:air
setblock ~38 ~-18 ~24 minecraft:quartz_pillar
fill ~39 ~-18 ~24 ~40 ~-18 ~24 minecraft:air
setblock ~41 ~-18 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-18 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-18 ~24 ~49 ~-18 ~24 minecraft:air
setblock ~50 ~-18 ~24 minecraft:light_gray_concrete
fill ~51 ~-18 ~24 ~62 ~-18 ~24 minecraft:air
setblock ~63 ~-18 ~24 minecraft:black_concrete
setblock ~64 ~-18 ~24 minecraft:light_gray_concrete
setblock ~4 ~-18 ~25 minecraft:light_gray_concrete
setblock ~5 ~-18 ~25 minecraft:air
setblock ~6 ~-18 ~25 minecraft:white_stained_glass_pane
fill ~7 ~-18 ~25 ~8 ~-18 ~25 minecraft:air
setblock ~9 ~-18 ~25 minecraft:white_stained_glass_pane
fill ~10 ~-18 ~25 ~11 ~-18 ~25 minecraft:air
setblock ~12 ~-18 ~25 minecraft:white_stained_glass_pane
fill ~13 ~-18 ~25 ~14 ~-18 ~25 minecraft:air
setblock ~15 ~-18 ~25 minecraft:white_stained_glass_pane
fill ~16 ~-18 ~25 ~17 ~-18 ~25 minecraft:air
setblock ~18 ~-18 ~25 minecraft:light_gray_concrete
fill ~19 ~-18 ~25 ~24 ~-18 ~25 minecraft:air
fill ~25 ~-18 ~25 ~26 ~-18 ~25 minecraft:quartz_pillar
fill ~27 ~-18 ~25 ~41 ~-18 ~25 minecraft:air
setblock ~42 ~-18 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-18 ~25 minecraft:quartz_pillar
fill ~44 ~-18 ~25 ~49 ~-18 ~25 minecraft:air
setblock ~50 ~-18 ~25 minecraft:light_gray_concrete
fill ~51 ~-18 ~25 ~62 ~-18 ~25 minecraft:air
setblock ~63 ~-18 ~25 minecraft:black_concrete
setblock ~64 ~-18 ~25 minecraft:light_gray_concrete
setblock ~4 ~-18 ~26 minecraft:light_gray_concrete
fill ~5 ~-18 ~26 ~17 ~-18 ~26 minecraft:air
setblock ~18 ~-18 ~26 minecraft:light_gray_concrete
fill ~19 ~-18 ~26 ~23 ~-18 ~26 minecraft:air
setblock ~24 ~-18 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-18 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-18 ~26 ~42 ~-18 ~26 minecraft:air
setblock ~43 ~-18 ~26 minecraft:quartz_pillar
setblock ~44 ~-18 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-18 ~26 ~49 ~-18 ~26 minecraft:air
setblock ~50 ~-18 ~26 minecraft:light_gray_concrete
fill ~51 ~-18 ~26 ~62 ~-18 ~26 minecraft:air
setblock ~63 ~-18 ~26 minecraft:black_concrete
setblock ~64 ~-18 ~26 minecraft:light_gray_concrete
setblock ~4 ~-18 ~27 minecraft:light_gray_concrete
fill ~5 ~-18 ~27 ~6 ~-18 ~27 minecraft:air
setblock ~7 ~-18 ~27 minecraft:white_stained_glass_pane
fill ~8 ~-18 ~27 ~9 ~-18 ~27 minecraft:air
setblock ~10 ~-18 ~27 minecraft:white_stained_glass_pane
fill ~11 ~-18 ~27 ~12 ~-18 ~27 minecraft:air
setblock ~13 ~-18 ~27 minecraft:white_stained_glass_pane
fill ~14 ~-18 ~27 ~15 ~-18 ~27 minecraft:air
setblock ~16 ~-18 ~27 minecraft:white_stained_glass_pane
setblock ~17 ~-18 ~27 minecraft:air
setblock ~18 ~-18 ~27 minecraft:light_gray_concrete
fill ~19 ~-18 ~27 ~23 ~-18 ~27 minecraft:air
setblock ~24 ~-18 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-18 ~27 ~43 ~-18 ~27 minecraft:air
setblock ~44 ~-18 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-18 ~27 ~49 ~-18 ~27 minecraft:air
setblock ~50 ~-18 ~27 minecraft:light_gray_concrete
fill ~51 ~-18 ~27 ~63 ~-18 ~27 minecraft:air
setblock ~64 ~-18 ~27 minecraft:light_gray_concrete
setblock ~4 ~-18 ~28 minecraft:light_gray_concrete
setblock ~5 ~-18 ~28 minecraft:air
setblock ~6 ~-18 ~28 minecraft:white_stained_glass_pane
fill ~7 ~-18 ~28 ~8 ~-18 ~28 minecraft:air
setblock ~9 ~-18 ~28 minecraft:white_stained_glass_pane
fill ~10 ~-18 ~28 ~11 ~-18 ~28 minecraft:air
setblock ~12 ~-18 ~28 minecraft:white_stained_glass_pane
fill ~13 ~-18 ~28 ~14 ~-18 ~28 minecraft:air
setblock ~15 ~-18 ~28 minecraft:white_stained_glass_pane
fill ~16 ~-18 ~28 ~17 ~-18 ~28 minecraft:air
setblock ~18 ~-18 ~28 minecraft:light_gray_concrete
fill ~19 ~-18 ~28 ~22 ~-18 ~28 minecraft:air
setblock ~23 ~-18 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-18 ~28 ~44 ~-18 ~28 minecraft:air
setblock ~45 ~-18 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-18 ~28 ~49 ~-18 ~28 minecraft:air
setblock ~50 ~-18 ~28 minecraft:light_gray_concrete
fill ~51 ~-18 ~28 ~63 ~-18 ~28 minecraft:air
setblock ~64 ~-18 ~28 minecraft:light_gray_concrete
setblock ~4 ~-18 ~29 minecraft:light_gray_concrete
fill ~5 ~-18 ~29 ~17 ~-18 ~29 minecraft:air
setblock ~18 ~-18 ~29 minecraft:light_gray_concrete
fill ~19 ~-18 ~29 ~21 ~-18 ~29 minecraft:air
fill ~22 ~-18 ~29 ~23 ~-18 ~29 minecraft:quartz_pillar
fill ~24 ~-18 ~29 ~44 ~-18 ~29 minecraft:air
setblock ~45 ~-18 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-18 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-18 ~29 ~49 ~-18 ~29 minecraft:air
setblock ~50 ~-18 ~29 minecraft:light_gray_concrete
fill ~51 ~-18 ~29 ~63 ~-18 ~29 minecraft:air
setblock ~64 ~-18 ~29 minecraft:light_gray_concrete
setblock ~4 ~-18 ~30 minecraft:light_gray_concrete
fill ~5 ~-18 ~30 ~6 ~-18 ~30 minecraft:air
setblock ~7 ~-18 ~30 minecraft:white_stained_glass_pane
fill ~8 ~-18 ~30 ~9 ~-18 ~30 minecraft:air
setblock ~10 ~-18 ~30 minecraft:white_stained_glass_pane
fill ~11 ~-18 ~30 ~12 ~-18 ~30 minecraft:air
setblock ~13 ~-18 ~30 minecraft:white_stained_glass_pane
fill ~14 ~-18 ~30 ~15 ~-18 ~30 minecraft:air
setblock ~16 ~-18 ~30 minecraft:white_stained_glass_pane
setblock ~17 ~-18 ~30 minecraft:air
setblock ~18 ~-18 ~30 minecraft:light_gray_concrete
fill ~19 ~-18 ~30 ~21 ~-18 ~30 minecraft:air
setblock ~22 ~-18 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-18 ~30 minecraft:air
setblock ~24 ~-18 ~30 minecraft:quartz_pillar
fill ~25 ~-18 ~30 ~43 ~-18 ~30 minecraft:air
setblock ~44 ~-18 ~30 minecraft:quartz_pillar
setblock ~45 ~-18 ~30 minecraft:air
setblock ~46 ~-18 ~30 minecraft:quartz_pillar
fill ~47 ~-18 ~30 ~49 ~-18 ~30 minecraft:air
setblock ~50 ~-18 ~30 minecraft:light_gray_concrete
fill ~51 ~-18 ~30 ~63 ~-18 ~30 minecraft:air
setblock ~64 ~-18 ~30 minecraft:light_gray_concrete
setblock ~4 ~-18 ~31 minecraft:light_gray_concrete
setblock ~5 ~-18 ~31 minecraft:air
setblock ~6 ~-18 ~31 minecraft:white_stained_glass_pane[south=true]
fill ~7 ~-18 ~31 ~8 ~-18 ~31 minecraft:air
setblock ~9 ~-18 ~31 minecraft:white_stained_glass_pane[south=true]
fill ~10 ~-18 ~31 ~14 ~-18 ~31 minecraft:air
setblock ~15 ~-18 ~31 minecraft:white_stained_glass_pane[south=true]
fill ~16 ~-18 ~31 ~17 ~-18 ~31 minecraft:air
setblock ~18 ~-18 ~31 minecraft:light_gray_concrete
fill ~19 ~-18 ~31 ~21 ~-18 ~31 minecraft:air
setblock ~22 ~-18 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-18 ~31 ~45 ~-18 ~31 minecraft:air
setblock ~46 ~-18 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-18 ~31 ~49 ~-18 ~31 minecraft:air
setblock ~50 ~-18 ~31 minecraft:light_gray_concrete
fill ~51 ~-18 ~31 ~63 ~-18 ~31 minecraft:air
setblock ~64 ~-18 ~31 minecraft:light_gray_concrete
setblock ~4 ~-18 ~32 minecraft:light_gray_concrete
setblock ~5 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~6 ~-18 ~32 minecraft:red_concrete
fill ~7 ~-18 ~32 ~8 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~9 ~-18 ~32 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~10 ~-18 ~32 minecraft:red_concrete
setblock ~11 ~-18 ~32 minecraft:air
fill ~12 ~-18 ~32 ~13 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~14 ~-18 ~32 minecraft:red_concrete
setblock ~15 ~-18 ~32 minecraft:glass_pane[north=true,east=true,west=true]
fill ~16 ~-18 ~32 ~17 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~18 ~-18 ~32 minecraft:red_concrete
setblock ~19 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-18 ~32 minecraft:air
setblock ~21 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-18 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-18 ~32 ~32 ~-18 ~32 minecraft:air
fill ~33 ~-18 ~32 ~35 ~-18 ~32 minecraft:glass
fill ~36 ~-18 ~32 ~45 ~-18 ~32 minecraft:air
setblock ~46 ~-18 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-18 ~32 minecraft:air
setblock ~49 ~-18 ~32 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-18 ~32 ~56 ~-18 ~32 minecraft:red_concrete
setblock ~57 ~-18 ~32 minecraft:air
fill ~58 ~-18 ~32 ~63 ~-18 ~32 minecraft:red_concrete
setblock ~64 ~-18 ~32 minecraft:light_gray_concrete
setblock ~4 ~-18 ~33 minecraft:light_gray_concrete
fill ~5 ~-18 ~33 ~32 ~-18 ~33 minecraft:air
setblock ~33 ~-18 ~33 minecraft:glass
fill ~34 ~-18 ~33 ~63 ~-18 ~33 minecraft:air
setblock ~64 ~-18 ~33 minecraft:light_gray_concrete
setblock ~4 ~-18 ~34 minecraft:light_gray_concrete
fill ~5 ~-18 ~34 ~32 ~-18 ~34 minecraft:air
fill ~33 ~-18 ~34 ~35 ~-18 ~34 minecraft:glass
fill ~36 ~-18 ~34 ~63 ~-18 ~34 minecraft:air
setblock ~64 ~-18 ~34 minecraft:light_gray_concrete
setblock ~4 ~-18 ~35 minecraft:light_gray_concrete
fill ~5 ~-18 ~35 ~32 ~-18 ~35 minecraft:air
setblock ~33 ~-18 ~35 minecraft:glass
fill ~34 ~-18 ~35 ~63 ~-18 ~35 minecraft:air
setblock ~64 ~-18 ~35 minecraft:light_gray_concrete
setblock ~4 ~-18 ~36 minecraft:light_gray_concrete
setblock ~5 ~-18 ~36 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~6 ~-18 ~36 minecraft:red_concrete
fill ~7 ~-18 ~36 ~8 ~-18 ~36 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~9 ~-18 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~10 ~-18 ~36 minecraft:red_concrete
setblock ~11 ~-18 ~36 minecraft:air
fill ~12 ~-18 ~36 ~13 ~-18 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~14 ~-18 ~36 minecraft:red_concrete
fill ~15 ~-18 ~36 ~17 ~-18 ~36 minecraft:glass_pane[east=true,west=true]
fill ~18 ~-18 ~36 ~19 ~-18 ~36 minecraft:red_concrete
setblock ~20 ~-18 ~36 minecraft:air
setblock ~21 ~-18 ~36 minecraft:red_concrete
setblock ~22 ~-18 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-18 ~36 ~32 ~-18 ~36 minecraft:air
fill ~33 ~-18 ~36 ~35 ~-18 ~36 minecraft:glass
fill ~36 ~-18 ~36 ~45 ~-18 ~36 minecraft:air
setblock ~46 ~-18 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-18 ~36 minecraft:red_concrete
setblock ~48 ~-18 ~36 minecraft:air
fill ~49 ~-18 ~36 ~56 ~-18 ~36 minecraft:red_concrete
setblock ~57 ~-18 ~36 minecraft:air
fill ~58 ~-18 ~36 ~63 ~-18 ~36 minecraft:red_concrete
setblock ~64 ~-18 ~36 minecraft:light_gray_concrete
setblock ~4 ~-18 ~37 minecraft:light_gray_concrete
fill ~5 ~-18 ~37 ~7 ~-18 ~37 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~8 ~-18 ~37 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-18 ~37 ~17 ~-18 ~37 minecraft:air
setblock ~18 ~-18 ~37 minecraft:light_gray_concrete
fill ~19 ~-18 ~37 ~21 ~-18 ~37 minecraft:air
setblock ~22 ~-18 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-18 ~37 ~45 ~-18 ~37 minecraft:air
setblock ~46 ~-18 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-18 ~37 ~49 ~-18 ~37 minecraft:air
setblock ~50 ~-18 ~37 minecraft:light_gray_concrete
fill ~51 ~-18 ~37 ~63 ~-18 ~37 minecraft:air
setblock ~64 ~-18 ~37 minecraft:light_gray_concrete
setblock ~4 ~-18 ~38 minecraft:light_gray_concrete
fill ~5 ~-18 ~38 ~7 ~-18 ~38 minecraft:air
setblock ~8 ~-18 ~38 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-18 ~38 ~17 ~-18 ~38 minecraft:air
setblock ~18 ~-18 ~38 minecraft:light_gray_concrete
fill ~19 ~-18 ~38 ~21 ~-18 ~38 minecraft:air
setblock ~22 ~-18 ~38 minecraft:quartz_pillar
setblock ~23 ~-18 ~38 minecraft:air
setblock ~24 ~-18 ~38 minecraft:quartz_pillar
fill ~25 ~-18 ~38 ~43 ~-18 ~38 minecraft:air
setblock ~44 ~-18 ~38 minecraft:quartz_pillar
setblock ~45 ~-18 ~38 minecraft:air
setblock ~46 ~-18 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-18 ~38 ~49 ~-18 ~38 minecraft:air
setblock ~50 ~-18 ~38 minecraft:light_gray_concrete
fill ~51 ~-18 ~38 ~63 ~-18 ~38 minecraft:air
setblock ~64 ~-18 ~38 minecraft:light_gray_concrete
setblock ~4 ~-18 ~39 minecraft:light_gray_concrete
fill ~5 ~-18 ~39 ~17 ~-18 ~39 minecraft:air
setblock ~18 ~-18 ~39 minecraft:light_gray_concrete
fill ~19 ~-18 ~39 ~21 ~-18 ~39 minecraft:air
setblock ~22 ~-18 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-18 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-18 ~39 ~44 ~-18 ~39 minecraft:air
fill ~45 ~-18 ~39 ~46 ~-18 ~39 minecraft:quartz_pillar
fill ~47 ~-18 ~39 ~49 ~-18 ~39 minecraft:air
setblock ~50 ~-18 ~39 minecraft:light_gray_concrete
fill ~51 ~-18 ~39 ~63 ~-18 ~39 minecraft:air
setblock ~64 ~-18 ~39 minecraft:light_gray_concrete
setblock ~4 ~-18 ~40 minecraft:light_gray_concrete
fill ~5 ~-18 ~40 ~7 ~-18 ~40 minecraft:air
setblock ~8 ~-18 ~40 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-18 ~40 ~17 ~-18 ~40 minecraft:air
setblock ~18 ~-18 ~40 minecraft:light_gray_concrete
fill ~19 ~-18 ~40 ~22 ~-18 ~40 minecraft:air
setblock ~23 ~-18 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-18 ~40 ~44 ~-18 ~40 minecraft:air
setblock ~45 ~-18 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-18 ~40 ~49 ~-18 ~40 minecraft:air
setblock ~50 ~-18 ~40 minecraft:light_gray_concrete
fill ~51 ~-18 ~40 ~63 ~-18 ~40 minecraft:air
setblock ~64 ~-18 ~40 minecraft:light_gray_concrete
setblock ~4 ~-18 ~41 minecraft:light_gray_concrete
fill ~5 ~-18 ~41 ~7 ~-18 ~41 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-18 ~41 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-18 ~41 ~17 ~-18 ~41 minecraft:air
setblock ~18 ~-18 ~41 minecraft:light_gray_concrete
fill ~19 ~-18 ~41 ~23 ~-18 ~41 minecraft:air
setblock ~24 ~-18 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-18 ~41 ~43 ~-18 ~41 minecraft:air
setblock ~44 ~-18 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-18 ~41 ~49 ~-18 ~41 minecraft:air
setblock ~50 ~-18 ~41 minecraft:light_gray_concrete
fill ~51 ~-18 ~41 ~63 ~-18 ~41 minecraft:air
setblock ~64 ~-18 ~41 minecraft:light_gray_concrete
setblock ~4 ~-18 ~42 minecraft:light_gray_concrete
fill ~5 ~-18 ~42 ~7 ~-18 ~42 minecraft:air
setblock ~8 ~-18 ~42 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-18 ~42 ~17 ~-18 ~42 minecraft:air
setblock ~18 ~-18 ~42 minecraft:light_gray_concrete
fill ~19 ~-18 ~42 ~23 ~-18 ~42 minecraft:air
setblock ~24 ~-18 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-18 ~42 minecraft:quartz_pillar
fill ~26 ~-18 ~42 ~42 ~-18 ~42 minecraft:air
setblock ~43 ~-18 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-18 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-18 ~42 ~49 ~-18 ~42 minecraft:air
setblock ~50 ~-18 ~42 minecraft:light_gray_concrete
fill ~51 ~-18 ~42 ~63 ~-18 ~42 minecraft:air
setblock ~64 ~-18 ~42 minecraft:light_gray_concrete
setblock ~4 ~-18 ~43 minecraft:light_gray_concrete
fill ~5 ~-18 ~43 ~11 ~-18 ~43 minecraft:air
setblock ~12 ~-18 ~43 minecraft:black_concrete
fill ~13 ~-18 ~43 ~17 ~-18 ~43 minecraft:air
setblock ~18 ~-18 ~43 minecraft:light_gray_concrete
fill ~19 ~-18 ~43 ~25 ~-18 ~43 minecraft:air
setblock ~26 ~-18 ~43 minecraft:glass_pane[south=true]
fill ~27 ~-18 ~43 ~41 ~-18 ~43 minecraft:air
fill ~42 ~-18 ~43 ~43 ~-18 ~43 minecraft:quartz_pillar
fill ~44 ~-18 ~43 ~49 ~-18 ~43 minecraft:air
setblock ~50 ~-18 ~43 minecraft:light_gray_concrete
fill ~51 ~-18 ~43 ~63 ~-18 ~43 minecraft:air
setblock ~64 ~-18 ~43 minecraft:light_gray_concrete
setblock ~4 ~-18 ~44 minecraft:light_gray_concrete
fill ~5 ~-18 ~44 ~7 ~-18 ~44 minecraft:air
setblock ~8 ~-18 ~44 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-18 ~44 ~17 ~-18 ~44 minecraft:air
setblock ~18 ~-18 ~44 minecraft:light_gray_concrete
fill ~19 ~-18 ~44 ~25 ~-18 ~44 minecraft:air
setblock ~26 ~-18 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-18 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-18 ~44 ~29 ~-18 ~44 minecraft:air
setblock ~30 ~-18 ~44 minecraft:quartz_pillar
fill ~31 ~-18 ~44 ~37 ~-18 ~44 minecraft:air
setblock ~38 ~-18 ~44 minecraft:quartz_pillar
fill ~39 ~-18 ~44 ~40 ~-18 ~44 minecraft:air
setblock ~41 ~-18 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-18 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-18 ~44 ~49 ~-18 ~44 minecraft:air
setblock ~50 ~-18 ~44 minecraft:light_gray_concrete
fill ~51 ~-18 ~44 ~63 ~-18 ~44 minecraft:air
setblock ~64 ~-18 ~44 minecraft:light_gray_concrete
setblock ~4 ~-18 ~45 minecraft:light_gray_concrete
fill ~5 ~-18 ~45 ~7 ~-18 ~45 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-18 ~45 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-18 ~45 ~17 ~-18 ~45 minecraft:air
setblock ~18 ~-18 ~45 minecraft:light_gray_concrete
fill ~19 ~-18 ~45 ~28 ~-18 ~45 minecraft:air
setblock ~29 ~-18 ~45 minecraft:quartz_pillar
fill ~30 ~-18 ~45 ~38 ~-18 ~45 minecraft:air
setblock ~39 ~-18 ~45 minecraft:glass_pane[east=true,south=true]
fill ~40 ~-18 ~45 ~49 ~-18 ~45 minecraft:air
setblock ~50 ~-18 ~45 minecraft:light_gray_concrete
fill ~51 ~-18 ~45 ~63 ~-18 ~45 minecraft:air
setblock ~64 ~-18 ~45 minecraft:light_gray_concrete
setblock ~4 ~-18 ~46 minecraft:light_gray_concrete
fill ~5 ~-18 ~46 ~7 ~-18 ~46 minecraft:air
setblock ~8 ~-18 ~46 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-18 ~46 ~17 ~-18 ~46 minecraft:air
setblock ~18 ~-18 ~46 minecraft:light_gray_concrete
fill ~19 ~-18 ~46 ~28 ~-18 ~46 minecraft:air
setblock ~29 ~-18 ~46 minecraft:quartz_pillar
fill ~30 ~-18 ~46 ~31 ~-18 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-18 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-18 ~46 ~35 ~-18 ~46 minecraft:air
setblock ~36 ~-18 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-18 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-18 ~46 minecraft:quartz_pillar
setblock ~39 ~-18 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-18 ~46 ~42 ~-18 ~46 minecraft:air
setblock ~43 ~-18 ~46 minecraft:black_concrete
fill ~44 ~-18 ~46 ~49 ~-18 ~46 minecraft:air
setblock ~50 ~-18 ~46 minecraft:light_gray_concrete
fill ~51 ~-18 ~46 ~63 ~-18 ~46 minecraft:air
setblock ~64 ~-18 ~46 minecraft:light_gray_concrete
setblock ~4 ~-18 ~47 minecraft:light_gray_concrete
fill ~5 ~-18 ~47 ~17 ~-18 ~47 minecraft:air
setblock ~18 ~-18 ~47 minecraft:light_gray_concrete
fill ~19 ~-18 ~47 ~31 ~-18 ~47 minecraft:air
setblock ~32 ~-18 ~47 minecraft:red_concrete
fill ~33 ~-18 ~47 ~35 ~-18 ~47 minecraft:air
setblock ~36 ~-18 ~47 minecraft:red_concrete
fill ~37 ~-18 ~47 ~49 ~-18 ~47 minecraft:air
setblock ~50 ~-18 ~47 minecraft:light_gray_concrete
fill ~51 ~-18 ~47 ~63 ~-18 ~47 minecraft:air
setblock ~64 ~-18 ~47 minecraft:light_gray_concrete
setblock ~4 ~-18 ~48 minecraft:light_gray_concrete
fill ~5 ~-18 ~48 ~7 ~-18 ~48 minecraft:air
setblock ~8 ~-18 ~48 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-18 ~48 ~17 ~-18 ~48 minecraft:air
setblock ~18 ~-18 ~48 minecraft:light_gray_concrete
fill ~19 ~-18 ~48 ~49 ~-18 ~48 minecraft:air
setblock ~50 ~-18 ~48 minecraft:light_gray_concrete
fill ~51 ~-18 ~48 ~63 ~-18 ~48 minecraft:air
setblock ~64 ~-18 ~48 minecraft:light_gray_concrete
setblock ~4 ~-18 ~49 minecraft:light_gray_concrete
fill ~5 ~-18 ~49 ~7 ~-18 ~49 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~8 ~-18 ~49 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-18 ~49 ~17 ~-18 ~49 minecraft:air
setblock ~18 ~-18 ~49 minecraft:light_gray_concrete
setblock ~19 ~-18 ~49 minecraft:black_concrete
fill ~20 ~-18 ~49 ~21 ~-18 ~49 minecraft:air
setblock ~22 ~-18 ~49 minecraft:black_concrete
fill ~23 ~-18 ~49 ~24 ~-18 ~49 minecraft:air
setblock ~25 ~-18 ~49 minecraft:black_concrete
fill ~26 ~-18 ~49 ~27 ~-18 ~49 minecraft:air
setblock ~28 ~-18 ~49 minecraft:black_concrete
fill ~29 ~-18 ~49 ~31 ~-18 ~49 minecraft:air
setblock ~32 ~-18 ~49 minecraft:red_concrete
fill ~33 ~-18 ~49 ~35 ~-18 ~49 minecraft:air
setblock ~36 ~-18 ~49 minecraft:red_concrete
setblock ~37 ~-18 ~49 minecraft:air
fill ~38 ~-18 ~49 ~48 ~-18 ~49 minecraft:chiseled_bookshelf[facing=north]
setblock ~49 ~-18 ~49 minecraft:air
setblock ~50 ~-18 ~49 minecraft:light_gray_concrete
fill ~51 ~-18 ~49 ~63 ~-18 ~49 minecraft:air
setblock ~64 ~-18 ~49 minecraft:light_gray_concrete
fill ~4 ~-18 ~50 ~10 ~-18 ~50 minecraft:light_gray_concrete
setblock ~11 ~-18 ~50 minecraft:air
fill ~12 ~-18 ~50 ~31 ~-18 ~50 minecraft:light_gray_concrete
setblock ~32 ~-18 ~50 minecraft:red_concrete
fill ~33 ~-18 ~50 ~35 ~-18 ~50 minecraft:air
setblock ~36 ~-18 ~50 minecraft:red_concrete
fill ~37 ~-18 ~50 ~56 ~-18 ~50 minecraft:light_gray_concrete
setblock ~57 ~-18 ~50 minecraft:air
fill ~58 ~-18 ~50 ~64 ~-18 ~50 minecraft:light_gray_concrete
setblock ~4 ~-18 ~51 minecraft:light_gray_concrete
setblock ~5 ~-18 ~51 minecraft:air
setblock ~6 ~-18 ~51 minecraft:barrel
setblock ~7 ~-18 ~51 minecraft:air
setblock ~8 ~-18 ~51 minecraft:barrel
fill ~9 ~-18 ~51 ~13 ~-18 ~51 minecraft:air
setblock ~14 ~-18 ~51 minecraft:barrel
setblock ~15 ~-18 ~51 minecraft:air
setblock ~16 ~-18 ~51 minecraft:barrel
setblock ~17 ~-18 ~51 minecraft:air
setblock ~18 ~-18 ~51 minecraft:light_gray_concrete
fill ~19 ~-18 ~51 ~31 ~-18 ~51 minecraft:air
setblock ~32 ~-18 ~51 minecraft:red_concrete
fill ~33 ~-18 ~51 ~35 ~-18 ~51 minecraft:air
setblock ~36 ~-18 ~51 minecraft:red_concrete
fill ~37 ~-18 ~51 ~49 ~-18 ~51 minecraft:air
setblock ~50 ~-18 ~51 minecraft:light_gray_concrete
fill ~51 ~-18 ~51 ~63 ~-18 ~51 minecraft:air
setblock ~64 ~-18 ~51 minecraft:light_gray_concrete
setblock ~4 ~-18 ~52 minecraft:light_gray_concrete
setblock ~5 ~-18 ~52 minecraft:barrel
fill ~6 ~-18 ~52 ~16 ~-18 ~52 minecraft:air
setblock ~17 ~-18 ~52 minecraft:barrel
setblock ~18 ~-18 ~52 minecraft:light_gray_concrete
fill ~19 ~-18 ~52 ~31 ~-18 ~52 minecraft:air
setblock ~32 ~-18 ~52 minecraft:red_concrete
fill ~33 ~-18 ~52 ~35 ~-18 ~52 minecraft:air
setblock ~36 ~-18 ~52 minecraft:red_concrete
setblock ~37 ~-18 ~52 minecraft:air
fill ~38 ~-18 ~52 ~41 ~-18 ~52 minecraft:barrel
setblock ~42 ~-18 ~52 minecraft:air
fill ~43 ~-18 ~52 ~46 ~-18 ~52 minecraft:barrel
setblock ~47 ~-18 ~52 minecraft:air
setblock ~48 ~-18 ~52 minecraft:barrel
setblock ~49 ~-18 ~52 minecraft:air
setblock ~50 ~-18 ~52 minecraft:light_gray_concrete
fill ~51 ~-18 ~52 ~63 ~-18 ~52 minecraft:air
setblock ~64 ~-18 ~52 minecraft:light_gray_concrete
setblock ~4 ~-18 ~53 minecraft:light_gray_concrete
fill ~5 ~-18 ~53 ~17 ~-18 ~53 minecraft:air
setblock ~18 ~-18 ~53 minecraft:light_gray_concrete
fill ~19 ~-18 ~53 ~31 ~-18 ~53 minecraft:air
setblock ~32 ~-18 ~53 minecraft:red_concrete
fill ~33 ~-18 ~53 ~35 ~-18 ~53 minecraft:air
setblock ~36 ~-18 ~53 minecraft:red_concrete
fill ~37 ~-18 ~53 ~49 ~-18 ~53 minecraft:air
setblock ~50 ~-18 ~53 minecraft:light_gray_concrete
fill ~51 ~-18 ~53 ~63 ~-18 ~53 minecraft:air
setblock ~64 ~-18 ~53 minecraft:light_gray_concrete
setblock ~4 ~-18 ~54 minecraft:light_gray_concrete
setblock ~5 ~-18 ~54 minecraft:barrel
fill ~6 ~-18 ~54 ~16 ~-18 ~54 minecraft:air
setblock ~17 ~-18 ~54 minecraft:barrel
setblock ~18 ~-18 ~54 minecraft:light_gray_concrete
fill ~19 ~-18 ~54 ~31 ~-18 ~54 minecraft:air
setblock ~32 ~-18 ~54 minecraft:red_concrete
fill ~33 ~-18 ~54 ~35 ~-18 ~54 minecraft:air
setblock ~36 ~-18 ~54 minecraft:red_concrete
fill ~37 ~-18 ~54 ~49 ~-18 ~54 minecraft:air
setblock ~50 ~-18 ~54 minecraft:light_gray_concrete
fill ~51 ~-18 ~54 ~63 ~-18 ~54 minecraft:air
setblock ~64 ~-18 ~54 minecraft:light_gray_concrete
setblock ~4 ~-18 ~55 minecraft:light_gray_concrete
fill ~5 ~-18 ~55 ~17 ~-18 ~55 minecraft:air
setblock ~18 ~-18 ~55 minecraft:light_gray_concrete
fill ~19 ~-18 ~55 ~31 ~-18 ~55 minecraft:air
setblock ~32 ~-18 ~55 minecraft:red_concrete
fill ~33 ~-18 ~55 ~35 ~-18 ~55 minecraft:air
setblock ~36 ~-18 ~55 minecraft:red_concrete
setblock ~37 ~-18 ~55 minecraft:air
fill ~38 ~-18 ~55 ~41 ~-18 ~55 minecraft:barrel
setblock ~42 ~-18 ~55 minecraft:air
fill ~43 ~-18 ~55 ~46 ~-18 ~55 minecraft:barrel
setblock ~47 ~-18 ~55 minecraft:air
setblock ~48 ~-18 ~55 minecraft:barrel
setblock ~49 ~-18 ~55 minecraft:air
setblock ~50 ~-18 ~55 minecraft:light_gray_concrete
fill ~51 ~-18 ~55 ~63 ~-18 ~55 minecraft:air
setblock ~64 ~-18 ~55 minecraft:light_gray_concrete
setblock ~4 ~-18 ~56 minecraft:light_gray_concrete
setblock ~5 ~-18 ~56 minecraft:barrel
fill ~6 ~-18 ~56 ~17 ~-18 ~56 minecraft:air
setblock ~18 ~-18 ~56 minecraft:light_gray_concrete
fill ~19 ~-18 ~56 ~31 ~-18 ~56 minecraft:air
setblock ~32 ~-18 ~56 minecraft:red_concrete
fill ~33 ~-18 ~56 ~35 ~-18 ~56 minecraft:air
setblock ~36 ~-18 ~56 minecraft:red_concrete
fill ~37 ~-18 ~56 ~49 ~-18 ~56 minecraft:air
setblock ~50 ~-18 ~56 minecraft:light_gray_concrete
fill ~51 ~-18 ~56 ~63 ~-18 ~56 minecraft:air
setblock ~64 ~-18 ~56 minecraft:light_gray_concrete
setblock ~4 ~-18 ~57 minecraft:light_gray_concrete
fill ~5 ~-18 ~57 ~63 ~-18 ~57 minecraft:air
setblock ~64 ~-18 ~57 minecraft:light_gray_concrete
setblock ~4 ~-18 ~58 minecraft:light_gray_concrete
setblock ~5 ~-18 ~58 minecraft:barrel
fill ~6 ~-18 ~58 ~17 ~-18 ~58 minecraft:air
setblock ~18 ~-18 ~58 minecraft:light_gray_concrete
fill ~19 ~-18 ~58 ~20 ~-18 ~58 minecraft:air
setblock ~21 ~-18 ~58 minecraft:iron_bars[south=true]
fill ~22 ~-18 ~58 ~23 ~-18 ~58 minecraft:air
setblock ~24 ~-18 ~58 minecraft:iron_bars[south=true]
fill ~25 ~-18 ~58 ~26 ~-18 ~58 minecraft:air
setblock ~27 ~-18 ~58 minecraft:iron_bars[south=true]
fill ~28 ~-18 ~58 ~29 ~-18 ~58 minecraft:air
setblock ~30 ~-18 ~58 minecraft:iron_bars[south=true]
setblock ~31 ~-18 ~58 minecraft:air
setblock ~32 ~-18 ~58 minecraft:red_concrete
fill ~33 ~-18 ~58 ~35 ~-18 ~58 minecraft:air
setblock ~36 ~-18 ~58 minecraft:red_concrete
setblock ~37 ~-18 ~58 minecraft:air
fill ~38 ~-18 ~58 ~41 ~-18 ~58 minecraft:barrel
setblock ~42 ~-18 ~58 minecraft:air
fill ~43 ~-18 ~58 ~46 ~-18 ~58 minecraft:barrel
setblock ~47 ~-18 ~58 minecraft:air
setblock ~48 ~-18 ~58 minecraft:barrel
setblock ~49 ~-18 ~58 minecraft:air
setblock ~50 ~-18 ~58 minecraft:light_gray_concrete
fill ~51 ~-18 ~58 ~63 ~-18 ~58 minecraft:air
setblock ~64 ~-18 ~58 minecraft:light_gray_concrete
setblock ~4 ~-18 ~59 minecraft:light_gray_concrete
fill ~5 ~-18 ~59 ~17 ~-18 ~59 minecraft:air
setblock ~18 ~-18 ~59 minecraft:light_gray_concrete
fill ~19 ~-18 ~59 ~20 ~-18 ~59 minecraft:air
setblock ~21 ~-18 ~59 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-18 ~59 ~23 ~-18 ~59 minecraft:air
setblock ~24 ~-18 ~59 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-18 ~59 ~26 ~-18 ~59 minecraft:air
setblock ~27 ~-18 ~59 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-18 ~59 ~29 ~-18 ~59 minecraft:air
setblock ~30 ~-18 ~59 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-18 ~59 minecraft:air
setblock ~32 ~-18 ~59 minecraft:red_concrete
fill ~33 ~-18 ~59 ~35 ~-18 ~59 minecraft:air
setblock ~36 ~-18 ~59 minecraft:red_concrete
fill ~37 ~-18 ~59 ~49 ~-18 ~59 minecraft:air
setblock ~50 ~-18 ~59 minecraft:light_gray_concrete
fill ~51 ~-18 ~59 ~63 ~-18 ~59 minecraft:air
setblock ~64 ~-18 ~59 minecraft:light_gray_concrete
setblock ~4 ~-18 ~60 minecraft:light_gray_concrete
setblock ~5 ~-18 ~60 minecraft:barrel
fill ~6 ~-18 ~60 ~16 ~-18 ~60 minecraft:air
setblock ~17 ~-18 ~60 minecraft:barrel
setblock ~18 ~-18 ~60 minecraft:light_gray_concrete
fill ~19 ~-18 ~60 ~20 ~-18 ~60 minecraft:air
setblock ~21 ~-18 ~60 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-18 ~60 ~23 ~-18 ~60 minecraft:air
setblock ~24 ~-18 ~60 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-18 ~60 ~26 ~-18 ~60 minecraft:air
setblock ~27 ~-18 ~60 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-18 ~60 ~29 ~-18 ~60 minecraft:air
setblock ~30 ~-18 ~60 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-18 ~60 minecraft:air
setblock ~32 ~-18 ~60 minecraft:red_concrete
fill ~33 ~-18 ~60 ~35 ~-18 ~60 minecraft:air
setblock ~36 ~-18 ~60 minecraft:red_concrete
fill ~37 ~-18 ~60 ~49 ~-18 ~60 minecraft:air
setblock ~50 ~-18 ~60 minecraft:light_gray_concrete
fill ~51 ~-18 ~60 ~63 ~-18 ~60 minecraft:air
setblock ~64 ~-18 ~60 minecraft:light_gray_concrete
setblock ~4 ~-18 ~61 minecraft:light_gray_concrete
fill ~5 ~-18 ~61 ~17 ~-18 ~61 minecraft:air
setblock ~18 ~-18 ~61 minecraft:light_gray_concrete
fill ~19 ~-18 ~61 ~20 ~-18 ~61 minecraft:air
setblock ~21 ~-18 ~61 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-18 ~61 ~23 ~-18 ~61 minecraft:air
setblock ~24 ~-18 ~61 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-18 ~61 ~26 ~-18 ~61 minecraft:air
setblock ~27 ~-18 ~61 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-18 ~61 ~29 ~-18 ~61 minecraft:air
setblock ~30 ~-18 ~61 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-18 ~61 minecraft:air
setblock ~32 ~-18 ~61 minecraft:red_concrete
fill ~33 ~-18 ~61 ~35 ~-18 ~61 minecraft:air
setblock ~36 ~-18 ~61 minecraft:red_concrete
setblock ~37 ~-18 ~61 minecraft:air
fill ~38 ~-18 ~61 ~41 ~-18 ~61 minecraft:barrel
setblock ~42 ~-18 ~61 minecraft:air
fill ~43 ~-18 ~61 ~46 ~-18 ~61 minecraft:barrel
setblock ~47 ~-18 ~61 minecraft:air
setblock ~48 ~-18 ~61 minecraft:barrel
setblock ~49 ~-18 ~61 minecraft:air
setblock ~50 ~-18 ~61 minecraft:light_gray_concrete
fill ~51 ~-18 ~61 ~63 ~-18 ~61 minecraft:air
setblock ~64 ~-18 ~61 minecraft:light_gray_concrete
setblock ~4 ~-18 ~62 minecraft:light_gray_concrete
setblock ~5 ~-18 ~62 minecraft:barrel
fill ~6 ~-18 ~62 ~16 ~-18 ~62 minecraft:air
setblock ~17 ~-18 ~62 minecraft:barrel
setblock ~18 ~-18 ~62 minecraft:light_gray_concrete
fill ~19 ~-18 ~62 ~20 ~-18 ~62 minecraft:air
setblock ~21 ~-18 ~62 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-18 ~62 ~23 ~-18 ~62 minecraft:air
setblock ~24 ~-18 ~62 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-18 ~62 ~26 ~-18 ~62 minecraft:air
setblock ~27 ~-18 ~62 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-18 ~62 ~29 ~-18 ~62 minecraft:air
setblock ~30 ~-18 ~62 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-18 ~62 minecraft:air
setblock ~32 ~-18 ~62 minecraft:red_concrete
fill ~33 ~-18 ~62 ~35 ~-18 ~62 minecraft:air
setblock ~36 ~-18 ~62 minecraft:red_concrete
fill ~37 ~-18 ~62 ~49 ~-18 ~62 minecraft:air
setblock ~50 ~-18 ~62 minecraft:light_gray_concrete
fill ~51 ~-18 ~62 ~63 ~-18 ~62 minecraft:air
setblock ~64 ~-18 ~62 minecraft:light_gray_concrete
setblock ~4 ~-18 ~63 minecraft:light_gray_concrete
setblock ~5 ~-18 ~63 minecraft:air
setblock ~6 ~-18 ~63 minecraft:barrel
setblock ~7 ~-18 ~63 minecraft:air
setblock ~8 ~-18 ~63 minecraft:barrel
setblock ~9 ~-18 ~63 minecraft:air
setblock ~10 ~-18 ~63 minecraft:barrel
setblock ~11 ~-18 ~63 minecraft:air
setblock ~12 ~-18 ~63 minecraft:barrel
setblock ~13 ~-18 ~63 minecraft:air
setblock ~14 ~-18 ~63 minecraft:barrel
setblock ~15 ~-18 ~63 minecraft:air
setblock ~16 ~-18 ~63 minecraft:barrel
setblock ~17 ~-18 ~63 minecraft:air
setblock ~18 ~-18 ~63 minecraft:light_gray_concrete
fill ~19 ~-18 ~63 ~30 ~-18 ~63 minecraft:target
setblock ~31 ~-18 ~63 minecraft:air
setblock ~32 ~-18 ~63 minecraft:red_concrete
fill ~33 ~-18 ~63 ~35 ~-18 ~63 minecraft:air
setblock ~36 ~-18 ~63 minecraft:red_concrete
fill ~37 ~-18 ~63 ~49 ~-18 ~63 minecraft:air
setblock ~50 ~-18 ~63 minecraft:light_gray_concrete
fill ~51 ~-18 ~63 ~63 ~-18 ~63 minecraft:air
setblock ~64 ~-18 ~63 minecraft:light_gray_concrete
fill ~4 ~-18 ~64 ~33 ~-18 ~64 minecraft:light_gray_concrete
setblock ~34 ~-18 ~64 minecraft:air
fill ~35 ~-18 ~64 ~64 ~-18 ~64 minecraft:light_gray_concrete
setblock ~33 ~-18 ~65 minecraft:light_gray_concrete
setblock ~34 ~-18 ~65 minecraft:air
setblock ~35 ~-18 ~65 minecraft:light_gray_concrete
fill ~32 ~-18 ~66 ~33 ~-18 ~66 minecraft:polished_andesite
setblock ~34 ~-18 ~66 minecraft:air
fill ~35 ~-18 ~66 ~36 ~-18 ~66 minecraft:polished_andesite
setblock ~32 ~-18 ~67 minecraft:polished_andesite
fill ~33 ~-18 ~67 ~35 ~-18 ~67 minecraft:air
setblock ~36 ~-18 ~67 minecraft:polished_andesite
setblock ~32 ~-18 ~68 minecraft:polished_andesite
setblock ~33 ~-18 ~68 minecraft:air
setblock ~34 ~-18 ~68 minecraft:quartz_pillar
setblock ~35 ~-18 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-18 ~68 minecraft:polished_andesite
setblock ~32 ~-18 ~69 minecraft:polished_andesite
fill ~33 ~-18 ~69 ~35 ~-18 ~69 minecraft:air
setblock ~36 ~-18 ~69 minecraft:polished_andesite
fill ~32 ~-18 ~70 ~36 ~-18 ~70 minecraft:polished_andesite
fill ~4 ~-17 ~4 ~64 ~-17 ~4 minecraft:light_gray_concrete
setblock ~4 ~-17 ~5 minecraft:light_gray_concrete
fill ~5 ~-17 ~5 ~17 ~-17 ~5 minecraft:air
setblock ~18 ~-17 ~5 minecraft:light_gray_concrete
fill ~19 ~-17 ~5 ~31 ~-17 ~5 minecraft:air
setblock ~32 ~-17 ~5 minecraft:light_gray_concrete
fill ~33 ~-17 ~5 ~35 ~-17 ~5 minecraft:air
setblock ~36 ~-17 ~5 minecraft:light_gray_concrete
fill ~37 ~-17 ~5 ~49 ~-17 ~5 minecraft:air
setblock ~50 ~-17 ~5 minecraft:light_gray_concrete
fill ~51 ~-17 ~5 ~63 ~-17 ~5 minecraft:air
setblock ~64 ~-17 ~5 minecraft:light_gray_concrete
setblock ~4 ~-17 ~6 minecraft:light_gray_concrete
fill ~5 ~-17 ~6 ~17 ~-17 ~6 minecraft:air
setblock ~18 ~-17 ~6 minecraft:light_gray_concrete
fill ~19 ~-17 ~6 ~31 ~-17 ~6 minecraft:air
setblock ~32 ~-17 ~6 minecraft:light_gray_concrete
fill ~33 ~-17 ~6 ~35 ~-17 ~6 minecraft:air
setblock ~36 ~-17 ~6 minecraft:light_gray_concrete
fill ~37 ~-17 ~6 ~49 ~-17 ~6 minecraft:air
setblock ~50 ~-17 ~6 minecraft:light_gray_concrete
fill ~51 ~-17 ~6 ~63 ~-17 ~6 minecraft:air
setblock ~64 ~-17 ~6 minecraft:light_gray_concrete
setblock ~4 ~-17 ~7 minecraft:light_gray_concrete
fill ~5 ~-17 ~7 ~17 ~-17 ~7 minecraft:air
setblock ~18 ~-17 ~7 minecraft:light_gray_concrete
fill ~19 ~-17 ~7 ~31 ~-17 ~7 minecraft:air
setblock ~32 ~-17 ~7 minecraft:light_gray_concrete
fill ~33 ~-17 ~7 ~35 ~-17 ~7 minecraft:air
setblock ~36 ~-17 ~7 minecraft:light_gray_concrete
fill ~37 ~-17 ~7 ~49 ~-17 ~7 minecraft:air
setblock ~50 ~-17 ~7 minecraft:light_gray_concrete
fill ~51 ~-17 ~7 ~63 ~-17 ~7 minecraft:air
setblock ~64 ~-17 ~7 minecraft:light_gray_concrete
setblock ~4 ~-17 ~8 minecraft:light_gray_concrete
fill ~5 ~-17 ~8 ~17 ~-17 ~8 minecraft:air
setblock ~18 ~-17 ~8 minecraft:light_gray_concrete
fill ~19 ~-17 ~8 ~31 ~-17 ~8 minecraft:air
setblock ~32 ~-17 ~8 minecraft:light_gray_concrete
fill ~33 ~-17 ~8 ~35 ~-17 ~8 minecraft:air
setblock ~36 ~-17 ~8 minecraft:light_gray_concrete
fill ~37 ~-17 ~8 ~49 ~-17 ~8 minecraft:air
setblock ~50 ~-17 ~8 minecraft:light_gray_concrete
fill ~51 ~-17 ~8 ~63 ~-17 ~8 minecraft:air
setblock ~64 ~-17 ~8 minecraft:light_gray_concrete
setblock ~4 ~-17 ~9 minecraft:light_gray_concrete
fill ~5 ~-17 ~9 ~17 ~-17 ~9 minecraft:air
setblock ~18 ~-17 ~9 minecraft:light_gray_concrete
fill ~19 ~-17 ~9 ~31 ~-17 ~9 minecraft:air
setblock ~32 ~-17 ~9 minecraft:light_gray_concrete
fill ~33 ~-17 ~9 ~35 ~-17 ~9 minecraft:air
setblock ~36 ~-17 ~9 minecraft:light_gray_concrete
fill ~37 ~-17 ~9 ~49 ~-17 ~9 minecraft:air
setblock ~50 ~-17 ~9 minecraft:light_gray_concrete
fill ~51 ~-17 ~9 ~63 ~-17 ~9 minecraft:air
setblock ~64 ~-17 ~9 minecraft:light_gray_concrete
setblock ~4 ~-17 ~10 minecraft:light_gray_concrete
fill ~5 ~-17 ~10 ~17 ~-17 ~10 minecraft:air
setblock ~18 ~-17 ~10 minecraft:light_gray_concrete
fill ~19 ~-17 ~10 ~31 ~-17 ~10 minecraft:air
setblock ~32 ~-17 ~10 minecraft:light_gray_concrete
fill ~33 ~-17 ~10 ~35 ~-17 ~10 minecraft:air
setblock ~36 ~-17 ~10 minecraft:light_gray_concrete
fill ~37 ~-17 ~10 ~49 ~-17 ~10 minecraft:air
setblock ~50 ~-17 ~10 minecraft:light_gray_concrete
fill ~51 ~-17 ~10 ~63 ~-17 ~10 minecraft:air
setblock ~64 ~-17 ~10 minecraft:light_gray_concrete
setblock ~4 ~-17 ~11 minecraft:light_gray_concrete
fill ~5 ~-17 ~11 ~17 ~-17 ~11 minecraft:air
setblock ~18 ~-17 ~11 minecraft:light_gray_concrete
fill ~19 ~-17 ~11 ~31 ~-17 ~11 minecraft:air
setblock ~32 ~-17 ~11 minecraft:light_gray_concrete
fill ~33 ~-17 ~11 ~35 ~-17 ~11 minecraft:air
setblock ~36 ~-17 ~11 minecraft:light_gray_concrete
fill ~37 ~-17 ~11 ~49 ~-17 ~11 minecraft:air
setblock ~50 ~-17 ~11 minecraft:light_gray_concrete
fill ~51 ~-17 ~11 ~63 ~-17 ~11 minecraft:air
setblock ~64 ~-17 ~11 minecraft:light_gray_concrete
setblock ~4 ~-17 ~12 minecraft:light_gray_concrete
fill ~5 ~-17 ~12 ~17 ~-17 ~12 minecraft:air
setblock ~18 ~-17 ~12 minecraft:light_gray_concrete
fill ~19 ~-17 ~12 ~31 ~-17 ~12 minecraft:air
setblock ~32 ~-17 ~12 minecraft:light_gray_concrete
fill ~33 ~-17 ~12 ~35 ~-17 ~12 minecraft:air
setblock ~36 ~-17 ~12 minecraft:light_gray_concrete
fill ~37 ~-17 ~12 ~49 ~-17 ~12 minecraft:air
setblock ~50 ~-17 ~12 minecraft:light_gray_concrete
fill ~51 ~-17 ~12 ~63 ~-17 ~12 minecraft:air
setblock ~64 ~-17 ~12 minecraft:light_gray_concrete
setblock ~4 ~-17 ~13 minecraft:light_gray_concrete
fill ~5 ~-17 ~13 ~17 ~-17 ~13 minecraft:air
setblock ~18 ~-17 ~13 minecraft:light_gray_concrete
fill ~19 ~-17 ~13 ~31 ~-17 ~13 minecraft:air
setblock ~32 ~-17 ~13 minecraft:light_gray_concrete
fill ~33 ~-17 ~13 ~35 ~-17 ~13 minecraft:air
setblock ~36 ~-17 ~13 minecraft:light_gray_concrete
fill ~37 ~-17 ~13 ~49 ~-17 ~13 minecraft:air
setblock ~50 ~-17 ~13 minecraft:light_gray_concrete
fill ~51 ~-17 ~13 ~63 ~-17 ~13 minecraft:air
setblock ~64 ~-17 ~13 minecraft:light_gray_concrete
setblock ~4 ~-17 ~14 minecraft:light_gray_concrete
fill ~5 ~-17 ~14 ~17 ~-17 ~14 minecraft:air
setblock ~18 ~-17 ~14 minecraft:light_gray_concrete
fill ~19 ~-17 ~14 ~31 ~-17 ~14 minecraft:air
setblock ~32 ~-17 ~14 minecraft:light_gray_concrete
fill ~33 ~-17 ~14 ~35 ~-17 ~14 minecraft:air
setblock ~36 ~-17 ~14 minecraft:light_gray_concrete
fill ~37 ~-17 ~14 ~49 ~-17 ~14 minecraft:air
setblock ~50 ~-17 ~14 minecraft:light_gray_concrete
fill ~51 ~-17 ~14 ~63 ~-17 ~14 minecraft:air
setblock ~64 ~-17 ~14 minecraft:light_gray_concrete
setblock ~4 ~-17 ~15 minecraft:light_gray_concrete
fill ~5 ~-17 ~15 ~17 ~-17 ~15 minecraft:air
setblock ~18 ~-17 ~15 minecraft:light_gray_concrete
fill ~19 ~-17 ~15 ~31 ~-17 ~15 minecraft:air
setblock ~32 ~-17 ~15 minecraft:light_gray_concrete
fill ~33 ~-17 ~15 ~35 ~-17 ~15 minecraft:air
setblock ~36 ~-17 ~15 minecraft:light_gray_concrete
fill ~37 ~-17 ~15 ~49 ~-17 ~15 minecraft:air
setblock ~50 ~-17 ~15 minecraft:light_gray_concrete
fill ~51 ~-17 ~15 ~63 ~-17 ~15 minecraft:air
setblock ~64 ~-17 ~15 minecraft:light_gray_concrete
setblock ~4 ~-17 ~16 minecraft:light_gray_concrete
fill ~5 ~-17 ~16 ~17 ~-17 ~16 minecraft:air
setblock ~18 ~-17 ~16 minecraft:light_gray_concrete
fill ~19 ~-17 ~16 ~31 ~-17 ~16 minecraft:air
setblock ~32 ~-17 ~16 minecraft:light_gray_concrete
fill ~33 ~-17 ~16 ~35 ~-17 ~16 minecraft:air
setblock ~36 ~-17 ~16 minecraft:light_gray_concrete
fill ~37 ~-17 ~16 ~49 ~-17 ~16 minecraft:air
setblock ~50 ~-17 ~16 minecraft:light_gray_concrete
fill ~51 ~-17 ~16 ~63 ~-17 ~16 minecraft:air
setblock ~64 ~-17 ~16 minecraft:light_gray_concrete
setblock ~4 ~-17 ~17 minecraft:light_gray_concrete
fill ~5 ~-17 ~17 ~17 ~-17 ~17 minecraft:air
setblock ~18 ~-17 ~17 minecraft:light_gray_concrete
fill ~19 ~-17 ~17 ~31 ~-17 ~17 minecraft:air
setblock ~32 ~-17 ~17 minecraft:light_gray_concrete
fill ~33 ~-17 ~17 ~35 ~-17 ~17 minecraft:air
setblock ~36 ~-17 ~17 minecraft:light_gray_concrete
fill ~37 ~-17 ~17 ~49 ~-17 ~17 minecraft:air
setblock ~50 ~-17 ~17 minecraft:light_gray_concrete
fill ~51 ~-17 ~17 ~63 ~-17 ~17 minecraft:air
setblock ~64 ~-17 ~17 minecraft:light_gray_concrete
fill ~4 ~-17 ~18 ~32 ~-17 ~18 minecraft:light_gray_concrete
fill ~33 ~-17 ~18 ~35 ~-17 ~18 minecraft:air
fill ~36 ~-17 ~18 ~64 ~-17 ~18 minecraft:light_gray_concrete
setblock ~4 ~-17 ~19 minecraft:light_gray_concrete
fill ~5 ~-17 ~19 ~17 ~-17 ~19 minecraft:air
setblock ~18 ~-17 ~19 minecraft:light_gray_concrete
fill ~19 ~-17 ~19 ~30 ~-17 ~19 minecraft:black_concrete
setblock ~31 ~-17 ~19 minecraft:air
setblock ~32 ~-17 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-17 ~19 ~35 ~-17 ~19 minecraft:air
setblock ~36 ~-17 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-17 ~19 ~49 ~-17 ~19 minecraft:air
setblock ~50 ~-17 ~19 minecraft:light_gray_concrete
fill ~51 ~-17 ~19 ~63 ~-17 ~19 minecraft:air
setblock ~64 ~-17 ~19 minecraft:light_gray_concrete
setblock ~4 ~-17 ~20 minecraft:light_gray_concrete
fill ~5 ~-17 ~20 ~17 ~-17 ~20 minecraft:air
setblock ~18 ~-17 ~20 minecraft:light_gray_concrete
fill ~19 ~-17 ~20 ~31 ~-17 ~20 minecraft:air
setblock ~32 ~-17 ~20 minecraft:light_gray_concrete
fill ~33 ~-17 ~20 ~35 ~-17 ~20 minecraft:air
setblock ~36 ~-17 ~20 minecraft:light_gray_concrete
fill ~37 ~-17 ~20 ~49 ~-17 ~20 minecraft:air
setblock ~50 ~-17 ~20 minecraft:light_gray_concrete
fill ~51 ~-17 ~20 ~63 ~-17 ~20 minecraft:air
setblock ~64 ~-17 ~20 minecraft:light_gray_concrete
setblock ~4 ~-17 ~21 minecraft:light_gray_concrete
fill ~5 ~-17 ~21 ~6 ~-17 ~21 minecraft:air
setblock ~7 ~-17 ~21 minecraft:white_stained_glass_pane
fill ~8 ~-17 ~21 ~9 ~-17 ~21 minecraft:air
setblock ~10 ~-17 ~21 minecraft:white_stained_glass_pane
fill ~11 ~-17 ~21 ~12 ~-17 ~21 minecraft:air
setblock ~13 ~-17 ~21 minecraft:white_stained_glass_pane
fill ~14 ~-17 ~21 ~15 ~-17 ~21 minecraft:air
setblock ~16 ~-17 ~21 minecraft:white_stained_glass_pane
setblock ~17 ~-17 ~21 minecraft:air
setblock ~18 ~-17 ~21 minecraft:light_gray_concrete
fill ~19 ~-17 ~21 ~31 ~-17 ~21 minecraft:air
setblock ~32 ~-17 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-17 ~21 ~35 ~-17 ~21 minecraft:air
setblock ~36 ~-17 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-17 ~21 ~49 ~-17 ~21 minecraft:air
setblock ~50 ~-17 ~21 minecraft:light_gray_concrete
fill ~51 ~-17 ~21 ~63 ~-17 ~21 minecraft:air
setblock ~64 ~-17 ~21 minecraft:light_gray_concrete
setblock ~4 ~-17 ~22 minecraft:light_gray_concrete
setblock ~5 ~-17 ~22 minecraft:air
setblock ~6 ~-17 ~22 minecraft:white_stained_glass_pane
fill ~7 ~-17 ~22 ~8 ~-17 ~22 minecraft:air
setblock ~9 ~-17 ~22 minecraft:white_stained_glass_pane
fill ~10 ~-17 ~22 ~11 ~-17 ~22 minecraft:air
setblock ~12 ~-17 ~22 minecraft:white_stained_glass_pane
fill ~13 ~-17 ~22 ~14 ~-17 ~22 minecraft:air
setblock ~15 ~-17 ~22 minecraft:white_stained_glass_pane
fill ~16 ~-17 ~22 ~17 ~-17 ~22 minecraft:air
setblock ~18 ~-17 ~22 minecraft:light_gray_concrete
fill ~19 ~-17 ~22 ~28 ~-17 ~22 minecraft:air
setblock ~29 ~-17 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-17 ~22 minecraft:quartz_pillar
setblock ~31 ~-17 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-17 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-17 ~22 ~35 ~-17 ~22 minecraft:air
setblock ~36 ~-17 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-17 ~22 ~38 ~-17 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-17 ~22 minecraft:quartz_pillar
fill ~40 ~-17 ~22 ~49 ~-17 ~22 minecraft:air
setblock ~50 ~-17 ~22 minecraft:light_gray_concrete
fill ~51 ~-17 ~22 ~63 ~-17 ~22 minecraft:air
setblock ~64 ~-17 ~22 minecraft:light_gray_concrete
setblock ~4 ~-17 ~23 minecraft:light_gray_concrete
fill ~5 ~-17 ~23 ~17 ~-17 ~23 minecraft:air
setblock ~18 ~-17 ~23 minecraft:light_gray_concrete
fill ~19 ~-17 ~23 ~27 ~-17 ~23 minecraft:air
setblock ~28 ~-17 ~23 minecraft:smooth_quartz
setblock ~29 ~-17 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-17 ~23 ~38 ~-17 ~23 minecraft:air
setblock ~39 ~-17 ~23 minecraft:quartz_pillar
setblock ~40 ~-17 ~23 minecraft:smooth_quartz
fill ~41 ~-17 ~23 ~49 ~-17 ~23 minecraft:air
setblock ~50 ~-17 ~23 minecraft:light_gray_concrete
fill ~51 ~-17 ~23 ~63 ~-17 ~23 minecraft:air
setblock ~64 ~-17 ~23 minecraft:light_gray_concrete
setblock ~4 ~-17 ~24 minecraft:light_gray_concrete
fill ~5 ~-17 ~24 ~6 ~-17 ~24 minecraft:air
setblock ~7 ~-17 ~24 minecraft:white_stained_glass_pane
fill ~8 ~-17 ~24 ~9 ~-17 ~24 minecraft:air
setblock ~10 ~-17 ~24 minecraft:white_stained_glass_pane
fill ~11 ~-17 ~24 ~12 ~-17 ~24 minecraft:air
setblock ~13 ~-17 ~24 minecraft:white_stained_glass_pane
fill ~14 ~-17 ~24 ~15 ~-17 ~24 minecraft:air
setblock ~16 ~-17 ~24 minecraft:white_stained_glass_pane
setblock ~17 ~-17 ~24 minecraft:air
setblock ~18 ~-17 ~24 minecraft:light_gray_concrete
fill ~19 ~-17 ~24 ~25 ~-17 ~24 minecraft:air
setblock ~26 ~-17 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-17 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-17 ~24 ~29 ~-17 ~24 minecraft:air
setblock ~30 ~-17 ~24 minecraft:quartz_pillar
fill ~31 ~-17 ~24 ~37 ~-17 ~24 minecraft:air
setblock ~38 ~-17 ~24 minecraft:quartz_pillar
fill ~39 ~-17 ~24 ~40 ~-17 ~24 minecraft:air
setblock ~41 ~-17 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-17 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-17 ~24 ~49 ~-17 ~24 minecraft:air
setblock ~50 ~-17 ~24 minecraft:light_gray_concrete
fill ~51 ~-17 ~24 ~62 ~-17 ~24 minecraft:air
setblock ~63 ~-17 ~24 minecraft:black_concrete
setblock ~64 ~-17 ~24 minecraft:light_gray_concrete
setblock ~4 ~-17 ~25 minecraft:light_gray_concrete
setblock ~5 ~-17 ~25 minecraft:air
setblock ~6 ~-17 ~25 minecraft:white_stained_glass_pane
fill ~7 ~-17 ~25 ~8 ~-17 ~25 minecraft:air
setblock ~9 ~-17 ~25 minecraft:white_stained_glass_pane
fill ~10 ~-17 ~25 ~11 ~-17 ~25 minecraft:air
setblock ~12 ~-17 ~25 minecraft:white_stained_glass_pane
fill ~13 ~-17 ~25 ~14 ~-17 ~25 minecraft:air
setblock ~15 ~-17 ~25 minecraft:white_stained_glass_pane
fill ~16 ~-17 ~25 ~17 ~-17 ~25 minecraft:air
setblock ~18 ~-17 ~25 minecraft:light_gray_concrete
fill ~19 ~-17 ~25 ~24 ~-17 ~25 minecraft:air
fill ~25 ~-17 ~25 ~26 ~-17 ~25 minecraft:quartz_pillar
fill ~27 ~-17 ~25 ~41 ~-17 ~25 minecraft:air
setblock ~42 ~-17 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-17 ~25 minecraft:quartz_pillar
fill ~44 ~-17 ~25 ~49 ~-17 ~25 minecraft:air
setblock ~50 ~-17 ~25 minecraft:light_gray_concrete
fill ~51 ~-17 ~25 ~62 ~-17 ~25 minecraft:air
setblock ~63 ~-17 ~25 minecraft:black_concrete
setblock ~64 ~-17 ~25 minecraft:light_gray_concrete
setblock ~4 ~-17 ~26 minecraft:light_gray_concrete
fill ~5 ~-17 ~26 ~17 ~-17 ~26 minecraft:air
setblock ~18 ~-17 ~26 minecraft:light_gray_concrete
fill ~19 ~-17 ~26 ~23 ~-17 ~26 minecraft:air
setblock ~24 ~-17 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-17 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-17 ~26 ~42 ~-17 ~26 minecraft:air
setblock ~43 ~-17 ~26 minecraft:quartz_pillar
setblock ~44 ~-17 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-17 ~26 ~49 ~-17 ~26 minecraft:air
setblock ~50 ~-17 ~26 minecraft:light_gray_concrete
fill ~51 ~-17 ~26 ~62 ~-17 ~26 minecraft:air
setblock ~63 ~-17 ~26 minecraft:black_concrete
setblock ~64 ~-17 ~26 minecraft:light_gray_concrete
setblock ~4 ~-17 ~27 minecraft:light_gray_concrete
fill ~5 ~-17 ~27 ~6 ~-17 ~27 minecraft:air
setblock ~7 ~-17 ~27 minecraft:white_stained_glass_pane
fill ~8 ~-17 ~27 ~9 ~-17 ~27 minecraft:air
setblock ~10 ~-17 ~27 minecraft:white_stained_glass_pane
fill ~11 ~-17 ~27 ~12 ~-17 ~27 minecraft:air
setblock ~13 ~-17 ~27 minecraft:white_stained_glass_pane
fill ~14 ~-17 ~27 ~15 ~-17 ~27 minecraft:air
setblock ~16 ~-17 ~27 minecraft:white_stained_glass_pane
setblock ~17 ~-17 ~27 minecraft:air
setblock ~18 ~-17 ~27 minecraft:light_gray_concrete
fill ~19 ~-17 ~27 ~23 ~-17 ~27 minecraft:air
setblock ~24 ~-17 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-17 ~27 ~43 ~-17 ~27 minecraft:air
setblock ~44 ~-17 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-17 ~27 ~49 ~-17 ~27 minecraft:air
setblock ~50 ~-17 ~27 minecraft:light_gray_concrete
fill ~51 ~-17 ~27 ~63 ~-17 ~27 minecraft:air
setblock ~64 ~-17 ~27 minecraft:light_gray_concrete
setblock ~4 ~-17 ~28 minecraft:light_gray_concrete
setblock ~5 ~-17 ~28 minecraft:air
setblock ~6 ~-17 ~28 minecraft:white_stained_glass_pane
fill ~7 ~-17 ~28 ~8 ~-17 ~28 minecraft:air
setblock ~9 ~-17 ~28 minecraft:white_stained_glass_pane
fill ~10 ~-17 ~28 ~11 ~-17 ~28 minecraft:air
setblock ~12 ~-17 ~28 minecraft:white_stained_glass_pane
fill ~13 ~-17 ~28 ~14 ~-17 ~28 minecraft:air
setblock ~15 ~-17 ~28 minecraft:white_stained_glass_pane
fill ~16 ~-17 ~28 ~17 ~-17 ~28 minecraft:air
setblock ~18 ~-17 ~28 minecraft:light_gray_concrete
fill ~19 ~-17 ~28 ~22 ~-17 ~28 minecraft:air
setblock ~23 ~-17 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-17 ~28 ~44 ~-17 ~28 minecraft:air
setblock ~45 ~-17 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-17 ~28 ~49 ~-17 ~28 minecraft:air
setblock ~50 ~-17 ~28 minecraft:light_gray_concrete
fill ~51 ~-17 ~28 ~63 ~-17 ~28 minecraft:air
setblock ~64 ~-17 ~28 minecraft:light_gray_concrete
setblock ~4 ~-17 ~29 minecraft:light_gray_concrete
fill ~5 ~-17 ~29 ~17 ~-17 ~29 minecraft:air
setblock ~18 ~-17 ~29 minecraft:light_gray_concrete
fill ~19 ~-17 ~29 ~21 ~-17 ~29 minecraft:air
fill ~22 ~-17 ~29 ~23 ~-17 ~29 minecraft:quartz_pillar
fill ~24 ~-17 ~29 ~44 ~-17 ~29 minecraft:air
setblock ~45 ~-17 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-17 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-17 ~29 ~49 ~-17 ~29 minecraft:air
setblock ~50 ~-17 ~29 minecraft:light_gray_concrete
fill ~51 ~-17 ~29 ~63 ~-17 ~29 minecraft:air
setblock ~64 ~-17 ~29 minecraft:light_gray_concrete
setblock ~4 ~-17 ~30 minecraft:light_gray_concrete
fill ~5 ~-17 ~30 ~6 ~-17 ~30 minecraft:air
setblock ~7 ~-17 ~30 minecraft:white_stained_glass_pane
fill ~8 ~-17 ~30 ~9 ~-17 ~30 minecraft:air
setblock ~10 ~-17 ~30 minecraft:white_stained_glass_pane
fill ~11 ~-17 ~30 ~12 ~-17 ~30 minecraft:air
setblock ~13 ~-17 ~30 minecraft:white_stained_glass_pane
fill ~14 ~-17 ~30 ~15 ~-17 ~30 minecraft:air
setblock ~16 ~-17 ~30 minecraft:white_stained_glass_pane
setblock ~17 ~-17 ~30 minecraft:air
setblock ~18 ~-17 ~30 minecraft:light_gray_concrete
fill ~19 ~-17 ~30 ~21 ~-17 ~30 minecraft:air
setblock ~22 ~-17 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-17 ~30 minecraft:air
setblock ~24 ~-17 ~30 minecraft:quartz_pillar
fill ~25 ~-17 ~30 ~43 ~-17 ~30 minecraft:air
setblock ~44 ~-17 ~30 minecraft:quartz_pillar
setblock ~45 ~-17 ~30 minecraft:air
setblock ~46 ~-17 ~30 minecraft:quartz_pillar
fill ~47 ~-17 ~30 ~49 ~-17 ~30 minecraft:air
setblock ~50 ~-17 ~30 minecraft:light_gray_concrete
fill ~51 ~-17 ~30 ~63 ~-17 ~30 minecraft:air
setblock ~64 ~-17 ~30 minecraft:light_gray_concrete
setblock ~4 ~-17 ~31 minecraft:light_gray_concrete
setblock ~5 ~-17 ~31 minecraft:air
setblock ~6 ~-17 ~31 minecraft:white_stained_glass_pane[south=true]
fill ~7 ~-17 ~31 ~8 ~-17 ~31 minecraft:air
setblock ~9 ~-17 ~31 minecraft:white_stained_glass_pane[south=true]
fill ~10 ~-17 ~31 ~14 ~-17 ~31 minecraft:air
setblock ~15 ~-17 ~31 minecraft:white_stained_glass_pane[south=true]
fill ~16 ~-17 ~31 ~17 ~-17 ~31 minecraft:air
setblock ~18 ~-17 ~31 minecraft:light_gray_concrete
fill ~19 ~-17 ~31 ~21 ~-17 ~31 minecraft:air
setblock ~22 ~-17 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-17 ~31 ~45 ~-17 ~31 minecraft:air
setblock ~46 ~-17 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-17 ~31 ~49 ~-17 ~31 minecraft:air
setblock ~50 ~-17 ~31 minecraft:light_gray_concrete
fill ~51 ~-17 ~31 ~63 ~-17 ~31 minecraft:air
setblock ~64 ~-17 ~31 minecraft:light_gray_concrete
setblock ~4 ~-17 ~32 minecraft:light_gray_concrete
setblock ~5 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~6 ~-17 ~32 minecraft:light_gray_concrete
fill ~7 ~-17 ~32 ~8 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~9 ~-17 ~32 minecraft:glass_pane[north=true,east=true,west=true]
fill ~10 ~-17 ~32 ~11 ~-17 ~32 minecraft:light_gray_concrete
fill ~12 ~-17 ~32 ~13 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~14 ~-17 ~32 minecraft:light_gray_concrete
setblock ~15 ~-17 ~32 minecraft:glass_pane[north=true,east=true,west=true]
fill ~16 ~-17 ~32 ~17 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~18 ~-17 ~32 minecraft:light_gray_concrete
setblock ~19 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-17 ~32 minecraft:light_gray_concrete
setblock ~21 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-17 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-17 ~32 ~32 ~-17 ~32 minecraft:air
fill ~33 ~-17 ~32 ~35 ~-17 ~32 minecraft:glass
fill ~36 ~-17 ~32 ~45 ~-17 ~32 minecraft:air
setblock ~46 ~-17 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-17 ~32 minecraft:light_gray_concrete
setblock ~49 ~-17 ~32 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-17 ~32 ~64 ~-17 ~32 minecraft:light_gray_concrete
setblock ~4 ~-17 ~33 minecraft:light_gray_concrete
fill ~5 ~-17 ~33 ~32 ~-17 ~33 minecraft:air
setblock ~33 ~-17 ~33 minecraft:glass
setblock ~34 ~-17 ~33 minecraft:air
setblock ~35 ~-17 ~33 minecraft:glass
fill ~36 ~-17 ~33 ~63 ~-17 ~33 minecraft:air
setblock ~64 ~-17 ~33 minecraft:light_gray_concrete
setblock ~4 ~-17 ~34 minecraft:light_gray_concrete
fill ~5 ~-17 ~34 ~32 ~-17 ~34 minecraft:air
fill ~33 ~-17 ~34 ~35 ~-17 ~34 minecraft:glass
fill ~36 ~-17 ~34 ~63 ~-17 ~34 minecraft:air
setblock ~64 ~-17 ~34 minecraft:light_gray_concrete
setblock ~4 ~-17 ~35 minecraft:light_gray_concrete
fill ~5 ~-17 ~35 ~32 ~-17 ~35 minecraft:air
setblock ~33 ~-17 ~35 minecraft:glass
setblock ~34 ~-17 ~35 minecraft:air
setblock ~35 ~-17 ~35 minecraft:glass
fill ~36 ~-17 ~35 ~63 ~-17 ~35 minecraft:air
setblock ~64 ~-17 ~35 minecraft:light_gray_concrete
setblock ~4 ~-17 ~36 minecraft:light_gray_concrete
setblock ~5 ~-17 ~36 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~6 ~-17 ~36 minecraft:light_gray_concrete
fill ~7 ~-17 ~36 ~8 ~-17 ~36 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~9 ~-17 ~36 minecraft:glass_pane[east=true,west=true]
fill ~10 ~-17 ~36 ~11 ~-17 ~36 minecraft:light_gray_concrete
fill ~12 ~-17 ~36 ~13 ~-17 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~14 ~-17 ~36 minecraft:light_gray_concrete
fill ~15 ~-17 ~36 ~17 ~-17 ~36 minecraft:glass_pane[east=true,west=true]
fill ~18 ~-17 ~36 ~21 ~-17 ~36 minecraft:light_gray_concrete
setblock ~22 ~-17 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-17 ~36 ~32 ~-17 ~36 minecraft:air
fill ~33 ~-17 ~36 ~35 ~-17 ~36 minecraft:glass
fill ~36 ~-17 ~36 ~45 ~-17 ~36 minecraft:air
setblock ~46 ~-17 ~36 minecraft:glass_pane[east=true,south=true]
fill ~47 ~-17 ~36 ~64 ~-17 ~36 minecraft:light_gray_concrete
setblock ~4 ~-17 ~37 minecraft:light_gray_concrete
fill ~5 ~-17 ~37 ~7 ~-17 ~37 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~8 ~-17 ~37 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-17 ~37 ~17 ~-17 ~37 minecraft:air
setblock ~18 ~-17 ~37 minecraft:light_gray_concrete
fill ~19 ~-17 ~37 ~21 ~-17 ~37 minecraft:air
setblock ~22 ~-17 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-17 ~37 ~45 ~-17 ~37 minecraft:air
setblock ~46 ~-17 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-17 ~37 ~49 ~-17 ~37 minecraft:air
setblock ~50 ~-17 ~37 minecraft:light_gray_concrete
fill ~51 ~-17 ~37 ~63 ~-17 ~37 minecraft:air
setblock ~64 ~-17 ~37 minecraft:light_gray_concrete
setblock ~4 ~-17 ~38 minecraft:light_gray_concrete
fill ~5 ~-17 ~38 ~7 ~-17 ~38 minecraft:air
setblock ~8 ~-17 ~38 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~38 ~17 ~-17 ~38 minecraft:air
setblock ~18 ~-17 ~38 minecraft:light_gray_concrete
fill ~19 ~-17 ~38 ~21 ~-17 ~38 minecraft:air
setblock ~22 ~-17 ~38 minecraft:quartz_pillar
setblock ~23 ~-17 ~38 minecraft:air
setblock ~24 ~-17 ~38 minecraft:quartz_pillar
fill ~25 ~-17 ~38 ~43 ~-17 ~38 minecraft:air
setblock ~44 ~-17 ~38 minecraft:quartz_pillar
setblock ~45 ~-17 ~38 minecraft:air
setblock ~46 ~-17 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-17 ~38 ~49 ~-17 ~38 minecraft:air
setblock ~50 ~-17 ~38 minecraft:light_gray_concrete
fill ~51 ~-17 ~38 ~63 ~-17 ~38 minecraft:air
setblock ~64 ~-17 ~38 minecraft:light_gray_concrete
setblock ~4 ~-17 ~39 minecraft:light_gray_concrete
fill ~5 ~-17 ~39 ~7 ~-17 ~39 minecraft:air
setblock ~8 ~-17 ~39 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~39 ~17 ~-17 ~39 minecraft:air
setblock ~18 ~-17 ~39 minecraft:light_gray_concrete
fill ~19 ~-17 ~39 ~21 ~-17 ~39 minecraft:air
setblock ~22 ~-17 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-17 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-17 ~39 ~44 ~-17 ~39 minecraft:air
fill ~45 ~-17 ~39 ~46 ~-17 ~39 minecraft:quartz_pillar
fill ~47 ~-17 ~39 ~49 ~-17 ~39 minecraft:air
setblock ~50 ~-17 ~39 minecraft:light_gray_concrete
fill ~51 ~-17 ~39 ~63 ~-17 ~39 minecraft:air
setblock ~64 ~-17 ~39 minecraft:light_gray_concrete
setblock ~4 ~-17 ~40 minecraft:light_gray_concrete
fill ~5 ~-17 ~40 ~7 ~-17 ~40 minecraft:air
setblock ~8 ~-17 ~40 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~40 ~17 ~-17 ~40 minecraft:air
setblock ~18 ~-17 ~40 minecraft:light_gray_concrete
fill ~19 ~-17 ~40 ~22 ~-17 ~40 minecraft:air
setblock ~23 ~-17 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-17 ~40 ~44 ~-17 ~40 minecraft:air
setblock ~45 ~-17 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-17 ~40 ~49 ~-17 ~40 minecraft:air
setblock ~50 ~-17 ~40 minecraft:light_gray_concrete
fill ~51 ~-17 ~40 ~63 ~-17 ~40 minecraft:air
setblock ~64 ~-17 ~40 minecraft:light_gray_concrete
setblock ~4 ~-17 ~41 minecraft:light_gray_concrete
fill ~5 ~-17 ~41 ~7 ~-17 ~41 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-17 ~41 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-17 ~41 ~17 ~-17 ~41 minecraft:air
setblock ~18 ~-17 ~41 minecraft:light_gray_concrete
fill ~19 ~-17 ~41 ~23 ~-17 ~41 minecraft:air
setblock ~24 ~-17 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-17 ~41 ~43 ~-17 ~41 minecraft:air
setblock ~44 ~-17 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-17 ~41 ~49 ~-17 ~41 minecraft:air
setblock ~50 ~-17 ~41 minecraft:light_gray_concrete
fill ~51 ~-17 ~41 ~63 ~-17 ~41 minecraft:air
setblock ~64 ~-17 ~41 minecraft:light_gray_concrete
setblock ~4 ~-17 ~42 minecraft:light_gray_concrete
fill ~5 ~-17 ~42 ~7 ~-17 ~42 minecraft:air
setblock ~8 ~-17 ~42 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~42 ~17 ~-17 ~42 minecraft:air
setblock ~18 ~-17 ~42 minecraft:light_gray_concrete
fill ~19 ~-17 ~42 ~23 ~-17 ~42 minecraft:air
setblock ~24 ~-17 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-17 ~42 minecraft:quartz_pillar
fill ~26 ~-17 ~42 ~42 ~-17 ~42 minecraft:air
setblock ~43 ~-17 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-17 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-17 ~42 ~49 ~-17 ~42 minecraft:air
setblock ~50 ~-17 ~42 minecraft:light_gray_concrete
fill ~51 ~-17 ~42 ~63 ~-17 ~42 minecraft:air
setblock ~64 ~-17 ~42 minecraft:light_gray_concrete
setblock ~4 ~-17 ~43 minecraft:light_gray_concrete
fill ~5 ~-17 ~43 ~7 ~-17 ~43 minecraft:air
setblock ~8 ~-17 ~43 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~43 ~17 ~-17 ~43 minecraft:air
setblock ~18 ~-17 ~43 minecraft:light_gray_concrete
fill ~19 ~-17 ~43 ~24 ~-17 ~43 minecraft:air
setblock ~25 ~-17 ~43 minecraft:quartz_pillar
setblock ~26 ~-17 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-17 ~43 ~41 ~-17 ~43 minecraft:air
fill ~42 ~-17 ~43 ~43 ~-17 ~43 minecraft:quartz_pillar
fill ~44 ~-17 ~43 ~49 ~-17 ~43 minecraft:air
setblock ~50 ~-17 ~43 minecraft:light_gray_concrete
fill ~51 ~-17 ~43 ~63 ~-17 ~43 minecraft:air
setblock ~64 ~-17 ~43 minecraft:light_gray_concrete
setblock ~4 ~-17 ~44 minecraft:light_gray_concrete
fill ~5 ~-17 ~44 ~7 ~-17 ~44 minecraft:air
setblock ~8 ~-17 ~44 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~44 ~17 ~-17 ~44 minecraft:air
setblock ~18 ~-17 ~44 minecraft:light_gray_concrete
fill ~19 ~-17 ~44 ~25 ~-17 ~44 minecraft:air
setblock ~26 ~-17 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-17 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-17 ~44 ~29 ~-17 ~44 minecraft:air
setblock ~30 ~-17 ~44 minecraft:quartz_pillar
fill ~31 ~-17 ~44 ~37 ~-17 ~44 minecraft:air
setblock ~38 ~-17 ~44 minecraft:quartz_pillar
fill ~39 ~-17 ~44 ~40 ~-17 ~44 minecraft:air
setblock ~41 ~-17 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-17 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-17 ~44 ~49 ~-17 ~44 minecraft:air
setblock ~50 ~-17 ~44 minecraft:light_gray_concrete
fill ~51 ~-17 ~44 ~63 ~-17 ~44 minecraft:air
setblock ~64 ~-17 ~44 minecraft:light_gray_concrete
setblock ~4 ~-17 ~45 minecraft:light_gray_concrete
fill ~5 ~-17 ~45 ~7 ~-17 ~45 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-17 ~45 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-17 ~45 ~17 ~-17 ~45 minecraft:air
setblock ~18 ~-17 ~45 minecraft:light_gray_concrete
fill ~19 ~-17 ~45 ~27 ~-17 ~45 minecraft:air
setblock ~28 ~-17 ~45 minecraft:smooth_quartz
setblock ~29 ~-17 ~45 minecraft:quartz_pillar
fill ~30 ~-17 ~45 ~38 ~-17 ~45 minecraft:air
setblock ~39 ~-17 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-17 ~45 minecraft:smooth_quartz
fill ~41 ~-17 ~45 ~49 ~-17 ~45 minecraft:air
setblock ~50 ~-17 ~45 minecraft:light_gray_concrete
fill ~51 ~-17 ~45 ~63 ~-17 ~45 minecraft:air
setblock ~64 ~-17 ~45 minecraft:light_gray_concrete
setblock ~4 ~-17 ~46 minecraft:light_gray_concrete
fill ~5 ~-17 ~46 ~7 ~-17 ~46 minecraft:air
setblock ~8 ~-17 ~46 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~46 ~17 ~-17 ~46 minecraft:air
setblock ~18 ~-17 ~46 minecraft:light_gray_concrete
fill ~19 ~-17 ~46 ~28 ~-17 ~46 minecraft:air
setblock ~29 ~-17 ~46 minecraft:quartz_pillar
fill ~30 ~-17 ~46 ~31 ~-17 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-17 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-17 ~46 ~35 ~-17 ~46 minecraft:air
setblock ~36 ~-17 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-17 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-17 ~46 minecraft:quartz_pillar
setblock ~39 ~-17 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-17 ~46 ~49 ~-17 ~46 minecraft:air
setblock ~50 ~-17 ~46 minecraft:light_gray_concrete
fill ~51 ~-17 ~46 ~63 ~-17 ~46 minecraft:air
setblock ~64 ~-17 ~46 minecraft:light_gray_concrete
setblock ~4 ~-17 ~47 minecraft:light_gray_concrete
fill ~5 ~-17 ~47 ~7 ~-17 ~47 minecraft:air
setblock ~8 ~-17 ~47 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~47 ~17 ~-17 ~47 minecraft:air
setblock ~18 ~-17 ~47 minecraft:light_gray_concrete
fill ~19 ~-17 ~47 ~31 ~-17 ~47 minecraft:air
setblock ~32 ~-17 ~47 minecraft:light_gray_concrete
fill ~33 ~-17 ~47 ~35 ~-17 ~47 minecraft:air
setblock ~36 ~-17 ~47 minecraft:light_gray_concrete
fill ~37 ~-17 ~47 ~49 ~-17 ~47 minecraft:air
setblock ~50 ~-17 ~47 minecraft:light_gray_concrete
fill ~51 ~-17 ~47 ~63 ~-17 ~47 minecraft:air
setblock ~64 ~-17 ~47 minecraft:light_gray_concrete
setblock ~4 ~-17 ~48 minecraft:light_gray_concrete
fill ~5 ~-17 ~48 ~7 ~-17 ~48 minecraft:air
setblock ~8 ~-17 ~48 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-17 ~48 ~17 ~-17 ~48 minecraft:air
setblock ~18 ~-17 ~48 minecraft:light_gray_concrete
fill ~19 ~-17 ~48 ~31 ~-17 ~48 minecraft:air
setblock ~32 ~-17 ~48 minecraft:light_gray_concrete
fill ~33 ~-17 ~48 ~35 ~-17 ~48 minecraft:air
setblock ~36 ~-17 ~48 minecraft:light_gray_concrete
fill ~37 ~-17 ~48 ~49 ~-17 ~48 minecraft:air
setblock ~50 ~-17 ~48 minecraft:light_gray_concrete
fill ~51 ~-17 ~48 ~63 ~-17 ~48 minecraft:air
setblock ~64 ~-17 ~48 minecraft:light_gray_concrete
setblock ~4 ~-17 ~49 minecraft:light_gray_concrete
fill ~5 ~-17 ~49 ~7 ~-17 ~49 minecraft:iron_bars[east=true,south=true,west=true]
schedule function hive:weiter/15 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 14 von 18 fertig","color":"gray"}]