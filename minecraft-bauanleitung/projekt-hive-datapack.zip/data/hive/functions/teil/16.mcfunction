setblock ~10 ~-13 ~14 minecraft:sea_lantern
fill ~11 ~-13 ~14 ~13 ~-13 ~14 minecraft:smooth_stone
setblock ~14 ~-13 ~14 minecraft:sea_lantern
fill ~15 ~-13 ~14 ~21 ~-13 ~14 minecraft:smooth_stone
setblock ~22 ~-13 ~14 minecraft:sea_lantern
fill ~23 ~-13 ~14 ~25 ~-13 ~14 minecraft:smooth_stone
setblock ~26 ~-13 ~14 minecraft:sea_lantern
fill ~27 ~-13 ~14 ~29 ~-13 ~14 minecraft:smooth_stone
setblock ~30 ~-13 ~14 minecraft:sea_lantern
fill ~31 ~-13 ~14 ~33 ~-13 ~14 minecraft:smooth_stone
setblock ~34 ~-13 ~14 minecraft:sea_lantern
fill ~35 ~-13 ~14 ~37 ~-13 ~14 minecraft:smooth_stone
setblock ~38 ~-13 ~14 minecraft:sea_lantern
fill ~39 ~-13 ~14 ~41 ~-13 ~14 minecraft:smooth_stone
setblock ~42 ~-13 ~14 minecraft:sea_lantern
fill ~43 ~-13 ~14 ~45 ~-13 ~14 minecraft:smooth_stone
setblock ~46 ~-13 ~14 minecraft:sea_lantern
fill ~47 ~-13 ~14 ~53 ~-13 ~14 minecraft:smooth_stone
setblock ~54 ~-13 ~14 minecraft:sea_lantern
fill ~55 ~-13 ~14 ~57 ~-13 ~14 minecraft:smooth_stone
setblock ~58 ~-13 ~14 minecraft:sea_lantern
fill ~59 ~-13 ~14 ~61 ~-13 ~14 minecraft:smooth_stone
setblock ~62 ~-13 ~14 minecraft:sea_lantern
fill ~63 ~-13 ~14 ~64 ~-13 ~14 minecraft:smooth_stone
fill ~4 ~-13 ~15 ~64 ~-13 ~15 minecraft:smooth_stone
fill ~4 ~-13 ~16 ~64 ~-13 ~16 minecraft:smooth_stone
fill ~4 ~-13 ~17 ~64 ~-13 ~17 minecraft:smooth_stone
fill ~4 ~-13 ~18 ~33 ~-13 ~18 minecraft:smooth_stone
setblock ~34 ~-13 ~18 minecraft:sea_lantern
fill ~35 ~-13 ~18 ~64 ~-13 ~18 minecraft:smooth_stone
fill ~4 ~-13 ~19 ~64 ~-13 ~19 minecraft:smooth_stone
fill ~4 ~-13 ~20 ~64 ~-13 ~20 minecraft:smooth_stone
fill ~4 ~-13 ~21 ~33 ~-13 ~21 minecraft:smooth_stone
setblock ~34 ~-13 ~21 minecraft:smooth_quartz
fill ~35 ~-13 ~21 ~64 ~-13 ~21 minecraft:smooth_stone
fill ~4 ~-13 ~22 ~5 ~-13 ~22 minecraft:smooth_stone
setblock ~6 ~-13 ~22 minecraft:sea_lantern
fill ~7 ~-13 ~22 ~9 ~-13 ~22 minecraft:smooth_stone
setblock ~10 ~-13 ~22 minecraft:sea_lantern
fill ~11 ~-13 ~22 ~13 ~-13 ~22 minecraft:smooth_stone
setblock ~14 ~-13 ~22 minecraft:sea_lantern
fill ~15 ~-13 ~22 ~21 ~-13 ~22 minecraft:smooth_stone
setblock ~22 ~-13 ~22 minecraft:sea_lantern
fill ~23 ~-13 ~22 ~25 ~-13 ~22 minecraft:smooth_stone
setblock ~26 ~-13 ~22 minecraft:sea_lantern
fill ~27 ~-13 ~22 ~28 ~-13 ~22 minecraft:smooth_stone
fill ~29 ~-13 ~22 ~39 ~-13 ~22 minecraft:smooth_quartz
fill ~40 ~-13 ~22 ~41 ~-13 ~22 minecraft:smooth_stone
setblock ~42 ~-13 ~22 minecraft:sea_lantern
fill ~43 ~-13 ~22 ~45 ~-13 ~22 minecraft:smooth_stone
setblock ~46 ~-13 ~22 minecraft:sea_lantern
fill ~47 ~-13 ~22 ~53 ~-13 ~22 minecraft:smooth_stone
setblock ~54 ~-13 ~22 minecraft:sea_lantern
fill ~55 ~-13 ~22 ~57 ~-13 ~22 minecraft:smooth_stone
setblock ~58 ~-13 ~22 minecraft:sea_lantern
fill ~59 ~-13 ~22 ~61 ~-13 ~22 minecraft:smooth_stone
setblock ~62 ~-13 ~22 minecraft:sea_lantern
fill ~63 ~-13 ~22 ~64 ~-13 ~22 minecraft:smooth_stone
fill ~4 ~-13 ~23 ~27 ~-13 ~23 minecraft:smooth_stone
fill ~28 ~-13 ~23 ~40 ~-13 ~23 minecraft:smooth_quartz
fill ~41 ~-13 ~23 ~64 ~-13 ~23 minecraft:smooth_stone
fill ~4 ~-13 ~24 ~25 ~-13 ~24 minecraft:smooth_stone
fill ~26 ~-13 ~24 ~42 ~-13 ~24 minecraft:smooth_quartz
fill ~43 ~-13 ~24 ~64 ~-13 ~24 minecraft:smooth_stone
fill ~4 ~-13 ~25 ~24 ~-13 ~25 minecraft:smooth_stone
fill ~25 ~-13 ~25 ~31 ~-13 ~25 minecraft:smooth_quartz
fill ~32 ~-13 ~25 ~36 ~-13 ~25 minecraft:sea_lantern
fill ~37 ~-13 ~25 ~43 ~-13 ~25 minecraft:smooth_quartz
fill ~44 ~-13 ~25 ~64 ~-13 ~25 minecraft:smooth_stone
fill ~4 ~-13 ~26 ~5 ~-13 ~26 minecraft:smooth_stone
setblock ~6 ~-13 ~26 minecraft:sea_lantern
fill ~7 ~-13 ~26 ~9 ~-13 ~26 minecraft:smooth_stone
setblock ~10 ~-13 ~26 minecraft:sea_lantern
fill ~11 ~-13 ~26 ~13 ~-13 ~26 minecraft:smooth_stone
setblock ~14 ~-13 ~26 minecraft:sea_lantern
fill ~15 ~-13 ~26 ~21 ~-13 ~26 minecraft:smooth_stone
setblock ~22 ~-13 ~26 minecraft:sea_lantern
setblock ~23 ~-13 ~26 minecraft:smooth_stone
fill ~24 ~-13 ~26 ~29 ~-13 ~26 minecraft:smooth_quartz
fill ~30 ~-13 ~26 ~38 ~-13 ~26 minecraft:sea_lantern
fill ~39 ~-13 ~26 ~44 ~-13 ~26 minecraft:smooth_quartz
setblock ~45 ~-13 ~26 minecraft:smooth_stone
setblock ~46 ~-13 ~26 minecraft:sea_lantern
fill ~47 ~-13 ~26 ~53 ~-13 ~26 minecraft:smooth_stone
setblock ~54 ~-13 ~26 minecraft:sea_lantern
fill ~55 ~-13 ~26 ~57 ~-13 ~26 minecraft:smooth_stone
setblock ~58 ~-13 ~26 minecraft:sea_lantern
fill ~59 ~-13 ~26 ~61 ~-13 ~26 minecraft:smooth_stone
setblock ~62 ~-13 ~26 minecraft:sea_lantern
fill ~63 ~-13 ~26 ~64 ~-13 ~26 minecraft:smooth_stone
fill ~4 ~-13 ~27 ~23 ~-13 ~27 minecraft:smooth_stone
fill ~24 ~-13 ~27 ~27 ~-13 ~27 minecraft:smooth_quartz
fill ~28 ~-13 ~27 ~31 ~-13 ~27 minecraft:sea_lantern
fill ~32 ~-13 ~27 ~33 ~-13 ~27 minecraft:white_concrete
fill ~34 ~-13 ~27 ~36 ~-13 ~27 minecraft:red_concrete
fill ~37 ~-13 ~27 ~40 ~-13 ~27 minecraft:sea_lantern
fill ~41 ~-13 ~27 ~44 ~-13 ~27 minecraft:smooth_quartz
fill ~45 ~-13 ~27 ~64 ~-13 ~27 minecraft:smooth_stone
fill ~4 ~-13 ~28 ~22 ~-13 ~28 minecraft:smooth_stone
fill ~23 ~-13 ~28 ~26 ~-13 ~28 minecraft:smooth_quartz
fill ~27 ~-13 ~28 ~29 ~-13 ~28 minecraft:sea_lantern
fill ~30 ~-13 ~28 ~33 ~-13 ~28 minecraft:white_concrete
fill ~34 ~-13 ~28 ~38 ~-13 ~28 minecraft:red_concrete
fill ~39 ~-13 ~28 ~41 ~-13 ~28 minecraft:sea_lantern
fill ~42 ~-13 ~28 ~45 ~-13 ~28 minecraft:smooth_quartz
fill ~46 ~-13 ~28 ~64 ~-13 ~28 minecraft:smooth_stone
fill ~4 ~-13 ~29 ~21 ~-13 ~29 minecraft:smooth_stone
fill ~22 ~-13 ~29 ~26 ~-13 ~29 minecraft:smooth_quartz
fill ~27 ~-13 ~29 ~28 ~-13 ~29 minecraft:sea_lantern
fill ~29 ~-13 ~29 ~33 ~-13 ~29 minecraft:white_concrete
fill ~34 ~-13 ~29 ~38 ~-13 ~29 minecraft:red_concrete
setblock ~39 ~-13 ~29 minecraft:white_concrete
fill ~40 ~-13 ~29 ~41 ~-13 ~29 minecraft:sea_lantern
fill ~42 ~-13 ~29 ~46 ~-13 ~29 minecraft:smooth_quartz
fill ~47 ~-13 ~29 ~64 ~-13 ~29 minecraft:smooth_stone
fill ~4 ~-13 ~30 ~5 ~-13 ~30 minecraft:smooth_stone
setblock ~6 ~-13 ~30 minecraft:sea_lantern
fill ~7 ~-13 ~30 ~9 ~-13 ~30 minecraft:smooth_stone
setblock ~10 ~-13 ~30 minecraft:sea_lantern
fill ~11 ~-13 ~30 ~13 ~-13 ~30 minecraft:smooth_stone
setblock ~14 ~-13 ~30 minecraft:sea_lantern
fill ~15 ~-13 ~30 ~21 ~-13 ~30 minecraft:smooth_stone
fill ~22 ~-13 ~30 ~25 ~-13 ~30 minecraft:smooth_quartz
fill ~26 ~-13 ~30 ~27 ~-13 ~30 minecraft:sea_lantern
fill ~28 ~-13 ~30 ~29 ~-13 ~30 minecraft:red_concrete
fill ~30 ~-13 ~30 ~33 ~-13 ~30 minecraft:white_concrete
fill ~34 ~-13 ~30 ~37 ~-13 ~30 minecraft:red_concrete
fill ~38 ~-13 ~30 ~40 ~-13 ~30 minecraft:white_concrete
fill ~41 ~-13 ~30 ~42 ~-13 ~30 minecraft:sea_lantern
fill ~43 ~-13 ~30 ~46 ~-13 ~30 minecraft:smooth_quartz
fill ~47 ~-13 ~30 ~53 ~-13 ~30 minecraft:smooth_stone
setblock ~54 ~-13 ~30 minecraft:sea_lantern
fill ~55 ~-13 ~30 ~57 ~-13 ~30 minecraft:smooth_stone
setblock ~58 ~-13 ~30 minecraft:sea_lantern
fill ~59 ~-13 ~30 ~61 ~-13 ~30 minecraft:smooth_stone
setblock ~62 ~-13 ~30 minecraft:sea_lantern
fill ~63 ~-13 ~30 ~64 ~-13 ~30 minecraft:smooth_stone
fill ~4 ~-13 ~31 ~21 ~-13 ~31 minecraft:smooth_stone
fill ~22 ~-13 ~31 ~25 ~-13 ~31 minecraft:smooth_quartz
fill ~26 ~-13 ~31 ~27 ~-13 ~31 minecraft:sea_lantern
fill ~28 ~-13 ~31 ~30 ~-13 ~31 minecraft:red_concrete
fill ~31 ~-13 ~31 ~33 ~-13 ~31 minecraft:white_concrete
fill ~34 ~-13 ~31 ~36 ~-13 ~31 minecraft:red_concrete
fill ~37 ~-13 ~31 ~40 ~-13 ~31 minecraft:white_concrete
fill ~41 ~-13 ~31 ~42 ~-13 ~31 minecraft:sea_lantern
fill ~43 ~-13 ~31 ~46 ~-13 ~31 minecraft:smooth_quartz
fill ~47 ~-13 ~31 ~64 ~-13 ~31 minecraft:smooth_stone
fill ~4 ~-13 ~32 ~21 ~-13 ~32 minecraft:smooth_stone
fill ~22 ~-13 ~32 ~24 ~-13 ~32 minecraft:smooth_quartz
fill ~25 ~-13 ~32 ~26 ~-13 ~32 minecraft:sea_lantern
fill ~27 ~-13 ~32 ~31 ~-13 ~32 minecraft:red_concrete
setblock ~32 ~-13 ~32 minecraft:white_concrete
fill ~33 ~-13 ~32 ~35 ~-13 ~32 minecraft:glass
fill ~36 ~-13 ~32 ~41 ~-13 ~32 minecraft:white_concrete
fill ~42 ~-13 ~32 ~43 ~-13 ~32 minecraft:sea_lantern
fill ~44 ~-13 ~32 ~46 ~-13 ~32 minecraft:smooth_quartz
fill ~47 ~-13 ~32 ~64 ~-13 ~32 minecraft:smooth_stone
fill ~4 ~-13 ~33 ~21 ~-13 ~33 minecraft:smooth_stone
fill ~22 ~-13 ~33 ~24 ~-13 ~33 minecraft:smooth_quartz
fill ~25 ~-13 ~33 ~26 ~-13 ~33 minecraft:sea_lantern
fill ~27 ~-13 ~33 ~32 ~-13 ~33 minecraft:red_concrete
setblock ~33 ~-13 ~33 minecraft:glass
setblock ~34 ~-13 ~33 minecraft:air
setblock ~35 ~-13 ~33 minecraft:glass
fill ~36 ~-13 ~33 ~41 ~-13 ~33 minecraft:white_concrete
fill ~42 ~-13 ~33 ~43 ~-13 ~33 minecraft:sea_lantern
fill ~44 ~-13 ~33 ~46 ~-13 ~33 minecraft:smooth_quartz
fill ~47 ~-13 ~33 ~64 ~-13 ~33 minecraft:smooth_stone
fill ~4 ~-13 ~34 ~5 ~-13 ~34 minecraft:smooth_stone
setblock ~6 ~-13 ~34 minecraft:sea_lantern
fill ~7 ~-13 ~34 ~9 ~-13 ~34 minecraft:smooth_stone
setblock ~10 ~-13 ~34 minecraft:sea_lantern
fill ~11 ~-13 ~34 ~13 ~-13 ~34 minecraft:smooth_stone
setblock ~14 ~-13 ~34 minecraft:sea_lantern
fill ~15 ~-13 ~34 ~17 ~-13 ~34 minecraft:smooth_stone
setblock ~18 ~-13 ~34 minecraft:sea_lantern
fill ~19 ~-13 ~34 ~20 ~-13 ~34 minecraft:smooth_stone
fill ~21 ~-13 ~34 ~24 ~-13 ~34 minecraft:smooth_quartz
fill ~25 ~-13 ~34 ~26 ~-13 ~34 minecraft:sea_lantern
fill ~27 ~-13 ~34 ~32 ~-13 ~34 minecraft:red_concrete
fill ~33 ~-13 ~34 ~35 ~-13 ~34 minecraft:glass
fill ~36 ~-13 ~34 ~41 ~-13 ~34 minecraft:red_concrete
fill ~42 ~-13 ~34 ~43 ~-13 ~34 minecraft:sea_lantern
fill ~44 ~-13 ~34 ~47 ~-13 ~34 minecraft:smooth_quartz
fill ~48 ~-13 ~34 ~49 ~-13 ~34 minecraft:smooth_stone
setblock ~50 ~-13 ~34 minecraft:sea_lantern
fill ~51 ~-13 ~34 ~53 ~-13 ~34 minecraft:smooth_stone
setblock ~54 ~-13 ~34 minecraft:sea_lantern
fill ~55 ~-13 ~34 ~57 ~-13 ~34 minecraft:smooth_stone
setblock ~58 ~-13 ~34 minecraft:sea_lantern
fill ~59 ~-13 ~34 ~61 ~-13 ~34 minecraft:smooth_stone
setblock ~62 ~-13 ~34 minecraft:sea_lantern
fill ~63 ~-13 ~34 ~64 ~-13 ~34 minecraft:smooth_stone
fill ~4 ~-13 ~35 ~21 ~-13 ~35 minecraft:smooth_stone
fill ~22 ~-13 ~35 ~24 ~-13 ~35 minecraft:smooth_quartz
fill ~25 ~-13 ~35 ~26 ~-13 ~35 minecraft:sea_lantern
fill ~27 ~-13 ~35 ~32 ~-13 ~35 minecraft:white_concrete
setblock ~33 ~-13 ~35 minecraft:glass
setblock ~34 ~-13 ~35 minecraft:air
setblock ~35 ~-13 ~35 minecraft:glass
fill ~36 ~-13 ~35 ~41 ~-13 ~35 minecraft:red_concrete
fill ~42 ~-13 ~35 ~43 ~-13 ~35 minecraft:sea_lantern
fill ~44 ~-13 ~35 ~46 ~-13 ~35 minecraft:smooth_quartz
fill ~47 ~-13 ~35 ~64 ~-13 ~35 minecraft:smooth_stone
fill ~4 ~-13 ~36 ~21 ~-13 ~36 minecraft:smooth_stone
fill ~22 ~-13 ~36 ~24 ~-13 ~36 minecraft:smooth_quartz
fill ~25 ~-13 ~36 ~26 ~-13 ~36 minecraft:sea_lantern
fill ~27 ~-13 ~36 ~32 ~-13 ~36 minecraft:white_concrete
fill ~33 ~-13 ~36 ~35 ~-13 ~36 minecraft:glass
setblock ~36 ~-13 ~36 minecraft:white_concrete
fill ~37 ~-13 ~36 ~41 ~-13 ~36 minecraft:red_concrete
fill ~42 ~-13 ~36 ~43 ~-13 ~36 minecraft:sea_lantern
fill ~44 ~-13 ~36 ~46 ~-13 ~36 minecraft:smooth_quartz
fill ~47 ~-13 ~36 ~64 ~-13 ~36 minecraft:smooth_stone
fill ~4 ~-13 ~37 ~21 ~-13 ~37 minecraft:smooth_stone
fill ~22 ~-13 ~37 ~25 ~-13 ~37 minecraft:smooth_quartz
fill ~26 ~-13 ~37 ~27 ~-13 ~37 minecraft:sea_lantern
fill ~28 ~-13 ~37 ~31 ~-13 ~37 minecraft:white_concrete
fill ~32 ~-13 ~37 ~34 ~-13 ~37 minecraft:red_concrete
fill ~35 ~-13 ~37 ~37 ~-13 ~37 minecraft:white_concrete
fill ~38 ~-13 ~37 ~40 ~-13 ~37 minecraft:red_concrete
fill ~41 ~-13 ~37 ~42 ~-13 ~37 minecraft:sea_lantern
fill ~43 ~-13 ~37 ~46 ~-13 ~37 minecraft:smooth_quartz
fill ~47 ~-13 ~37 ~64 ~-13 ~37 minecraft:smooth_stone
fill ~4 ~-13 ~38 ~5 ~-13 ~38 minecraft:smooth_stone
setblock ~6 ~-13 ~38 minecraft:sea_lantern
fill ~7 ~-13 ~38 ~9 ~-13 ~38 minecraft:smooth_stone
setblock ~10 ~-13 ~38 minecraft:sea_lantern
fill ~11 ~-13 ~38 ~13 ~-13 ~38 minecraft:smooth_stone
setblock ~14 ~-13 ~38 minecraft:sea_lantern
fill ~15 ~-13 ~38 ~21 ~-13 ~38 minecraft:smooth_stone
fill ~22 ~-13 ~38 ~25 ~-13 ~38 minecraft:smooth_quartz
fill ~26 ~-13 ~38 ~27 ~-13 ~38 minecraft:sea_lantern
fill ~28 ~-13 ~38 ~30 ~-13 ~38 minecraft:white_concrete
fill ~31 ~-13 ~38 ~34 ~-13 ~38 minecraft:red_concrete
fill ~35 ~-13 ~38 ~38 ~-13 ~38 minecraft:white_concrete
fill ~39 ~-13 ~38 ~40 ~-13 ~38 minecraft:red_concrete
fill ~41 ~-13 ~38 ~42 ~-13 ~38 minecraft:sea_lantern
fill ~43 ~-13 ~38 ~46 ~-13 ~38 minecraft:smooth_quartz
fill ~47 ~-13 ~38 ~53 ~-13 ~38 minecraft:smooth_stone
setblock ~54 ~-13 ~38 minecraft:sea_lantern
fill ~55 ~-13 ~38 ~57 ~-13 ~38 minecraft:smooth_stone
setblock ~58 ~-13 ~38 minecraft:sea_lantern
fill ~59 ~-13 ~38 ~61 ~-13 ~38 minecraft:smooth_stone
setblock ~62 ~-13 ~38 minecraft:sea_lantern
fill ~63 ~-13 ~38 ~64 ~-13 ~38 minecraft:smooth_stone
fill ~4 ~-13 ~39 ~21 ~-13 ~39 minecraft:smooth_stone
fill ~22 ~-13 ~39 ~26 ~-13 ~39 minecraft:smooth_quartz
fill ~27 ~-13 ~39 ~28 ~-13 ~39 minecraft:sea_lantern
setblock ~29 ~-13 ~39 minecraft:white_concrete
fill ~30 ~-13 ~39 ~34 ~-13 ~39 minecraft:red_concrete
fill ~35 ~-13 ~39 ~39 ~-13 ~39 minecraft:white_concrete
fill ~40 ~-13 ~39 ~41 ~-13 ~39 minecraft:sea_lantern
fill ~42 ~-13 ~39 ~46 ~-13 ~39 minecraft:smooth_quartz
fill ~47 ~-13 ~39 ~64 ~-13 ~39 minecraft:smooth_stone
fill ~4 ~-13 ~40 ~22 ~-13 ~40 minecraft:smooth_stone
fill ~23 ~-13 ~40 ~26 ~-13 ~40 minecraft:smooth_quartz
fill ~27 ~-13 ~40 ~29 ~-13 ~40 minecraft:sea_lantern
fill ~30 ~-13 ~40 ~34 ~-13 ~40 minecraft:red_concrete
fill ~35 ~-13 ~40 ~38 ~-13 ~40 minecraft:white_concrete
fill ~39 ~-13 ~40 ~41 ~-13 ~40 minecraft:sea_lantern
fill ~42 ~-13 ~40 ~45 ~-13 ~40 minecraft:smooth_quartz
fill ~46 ~-13 ~40 ~64 ~-13 ~40 minecraft:smooth_stone
fill ~4 ~-13 ~41 ~23 ~-13 ~41 minecraft:smooth_stone
fill ~24 ~-13 ~41 ~27 ~-13 ~41 minecraft:smooth_quartz
fill ~28 ~-13 ~41 ~31 ~-13 ~41 minecraft:sea_lantern
fill ~32 ~-13 ~41 ~34 ~-13 ~41 minecraft:red_concrete
fill ~35 ~-13 ~41 ~36 ~-13 ~41 minecraft:white_concrete
fill ~37 ~-13 ~41 ~40 ~-13 ~41 minecraft:sea_lantern
fill ~41 ~-13 ~41 ~44 ~-13 ~41 minecraft:smooth_quartz
fill ~45 ~-13 ~41 ~64 ~-13 ~41 minecraft:smooth_stone
fill ~4 ~-13 ~42 ~5 ~-13 ~42 minecraft:smooth_stone
setblock ~6 ~-13 ~42 minecraft:sea_lantern
fill ~7 ~-13 ~42 ~9 ~-13 ~42 minecraft:smooth_stone
setblock ~10 ~-13 ~42 minecraft:sea_lantern
fill ~11 ~-13 ~42 ~13 ~-13 ~42 minecraft:smooth_stone
setblock ~14 ~-13 ~42 minecraft:sea_lantern
fill ~15 ~-13 ~42 ~21 ~-13 ~42 minecraft:smooth_stone
setblock ~22 ~-13 ~42 minecraft:sea_lantern
setblock ~23 ~-13 ~42 minecraft:smooth_stone
fill ~24 ~-13 ~42 ~29 ~-13 ~42 minecraft:smooth_quartz
fill ~30 ~-13 ~42 ~38 ~-13 ~42 minecraft:sea_lantern
fill ~39 ~-13 ~42 ~44 ~-13 ~42 minecraft:smooth_quartz
setblock ~45 ~-13 ~42 minecraft:smooth_stone
setblock ~46 ~-13 ~42 minecraft:sea_lantern
fill ~47 ~-13 ~42 ~53 ~-13 ~42 minecraft:smooth_stone
setblock ~54 ~-13 ~42 minecraft:sea_lantern
fill ~55 ~-13 ~42 ~57 ~-13 ~42 minecraft:smooth_stone
setblock ~58 ~-13 ~42 minecraft:sea_lantern
fill ~59 ~-13 ~42 ~61 ~-13 ~42 minecraft:smooth_stone
setblock ~62 ~-13 ~42 minecraft:sea_lantern
fill ~63 ~-13 ~42 ~64 ~-13 ~42 minecraft:smooth_stone
fill ~4 ~-13 ~43 ~24 ~-13 ~43 minecraft:smooth_stone
fill ~25 ~-13 ~43 ~31 ~-13 ~43 minecraft:smooth_quartz
fill ~32 ~-13 ~43 ~36 ~-13 ~43 minecraft:sea_lantern
fill ~37 ~-13 ~43 ~43 ~-13 ~43 minecraft:smooth_quartz
fill ~44 ~-13 ~43 ~64 ~-13 ~43 minecraft:smooth_stone
fill ~4 ~-13 ~44 ~25 ~-13 ~44 minecraft:smooth_stone
fill ~26 ~-13 ~44 ~42 ~-13 ~44 minecraft:smooth_quartz
fill ~43 ~-13 ~44 ~64 ~-13 ~44 minecraft:smooth_stone
fill ~4 ~-13 ~45 ~27 ~-13 ~45 minecraft:smooth_stone
fill ~28 ~-13 ~45 ~40 ~-13 ~45 minecraft:smooth_quartz
fill ~41 ~-13 ~45 ~64 ~-13 ~45 minecraft:smooth_stone
fill ~4 ~-13 ~46 ~5 ~-13 ~46 minecraft:smooth_stone
setblock ~6 ~-13 ~46 minecraft:sea_lantern
fill ~7 ~-13 ~46 ~9 ~-13 ~46 minecraft:smooth_stone
setblock ~10 ~-13 ~46 minecraft:sea_lantern
fill ~11 ~-13 ~46 ~13 ~-13 ~46 minecraft:smooth_stone
setblock ~14 ~-13 ~46 minecraft:sea_lantern
fill ~15 ~-13 ~46 ~21 ~-13 ~46 minecraft:smooth_stone
setblock ~22 ~-13 ~46 minecraft:sea_lantern
fill ~23 ~-13 ~46 ~25 ~-13 ~46 minecraft:smooth_stone
setblock ~26 ~-13 ~46 minecraft:sea_lantern
fill ~27 ~-13 ~46 ~28 ~-13 ~46 minecraft:smooth_stone
fill ~29 ~-13 ~46 ~39 ~-13 ~46 minecraft:smooth_quartz
fill ~40 ~-13 ~46 ~41 ~-13 ~46 minecraft:smooth_stone
setblock ~42 ~-13 ~46 minecraft:sea_lantern
fill ~43 ~-13 ~46 ~45 ~-13 ~46 minecraft:smooth_stone
setblock ~46 ~-13 ~46 minecraft:sea_lantern
fill ~47 ~-13 ~46 ~53 ~-13 ~46 minecraft:smooth_stone
setblock ~54 ~-13 ~46 minecraft:sea_lantern
fill ~55 ~-13 ~46 ~57 ~-13 ~46 minecraft:smooth_stone
setblock ~58 ~-13 ~46 minecraft:sea_lantern
fill ~59 ~-13 ~46 ~61 ~-13 ~46 minecraft:smooth_stone
setblock ~62 ~-13 ~46 minecraft:sea_lantern
fill ~63 ~-13 ~46 ~64 ~-13 ~46 minecraft:smooth_stone
fill ~4 ~-13 ~47 ~33 ~-13 ~47 minecraft:smooth_stone
setblock ~34 ~-13 ~47 minecraft:smooth_quartz
fill ~35 ~-13 ~47 ~64 ~-13 ~47 minecraft:smooth_stone
fill ~4 ~-13 ~48 ~64 ~-13 ~48 minecraft:smooth_stone
fill ~4 ~-13 ~49 ~64 ~-13 ~49 minecraft:smooth_stone
fill ~4 ~-13 ~50 ~33 ~-13 ~50 minecraft:smooth_stone
setblock ~34 ~-13 ~50 minecraft:sea_lantern
fill ~35 ~-13 ~50 ~64 ~-13 ~50 minecraft:smooth_stone
fill ~4 ~-13 ~51 ~64 ~-13 ~51 minecraft:smooth_stone
fill ~4 ~-13 ~52 ~64 ~-13 ~52 minecraft:smooth_stone
fill ~4 ~-13 ~53 ~64 ~-13 ~53 minecraft:smooth_stone
fill ~4 ~-13 ~54 ~5 ~-13 ~54 minecraft:smooth_stone
setblock ~6 ~-13 ~54 minecraft:sea_lantern
fill ~7 ~-13 ~54 ~9 ~-13 ~54 minecraft:smooth_stone
setblock ~10 ~-13 ~54 minecraft:sea_lantern
fill ~11 ~-13 ~54 ~13 ~-13 ~54 minecraft:smooth_stone
setblock ~14 ~-13 ~54 minecraft:sea_lantern
fill ~15 ~-13 ~54 ~21 ~-13 ~54 minecraft:smooth_stone
setblock ~22 ~-13 ~54 minecraft:sea_lantern
fill ~23 ~-13 ~54 ~25 ~-13 ~54 minecraft:smooth_stone
setblock ~26 ~-13 ~54 minecraft:sea_lantern
fill ~27 ~-13 ~54 ~29 ~-13 ~54 minecraft:smooth_stone
setblock ~30 ~-13 ~54 minecraft:sea_lantern
fill ~31 ~-13 ~54 ~33 ~-13 ~54 minecraft:smooth_stone
setblock ~34 ~-13 ~54 minecraft:sea_lantern
fill ~35 ~-13 ~54 ~37 ~-13 ~54 minecraft:smooth_stone
setblock ~38 ~-13 ~54 minecraft:sea_lantern
fill ~39 ~-13 ~54 ~41 ~-13 ~54 minecraft:smooth_stone
setblock ~42 ~-13 ~54 minecraft:sea_lantern
fill ~43 ~-13 ~54 ~45 ~-13 ~54 minecraft:smooth_stone
setblock ~46 ~-13 ~54 minecraft:sea_lantern
fill ~47 ~-13 ~54 ~53 ~-13 ~54 minecraft:smooth_stone
setblock ~54 ~-13 ~54 minecraft:sea_lantern
fill ~55 ~-13 ~54 ~57 ~-13 ~54 minecraft:smooth_stone
setblock ~58 ~-13 ~54 minecraft:sea_lantern
fill ~59 ~-13 ~54 ~61 ~-13 ~54 minecraft:smooth_stone
setblock ~62 ~-13 ~54 minecraft:sea_lantern
fill ~63 ~-13 ~54 ~64 ~-13 ~54 minecraft:smooth_stone
fill ~4 ~-13 ~55 ~64 ~-13 ~55 minecraft:smooth_stone
fill ~4 ~-13 ~56 ~64 ~-13 ~56 minecraft:smooth_stone
fill ~4 ~-13 ~57 ~64 ~-13 ~57 minecraft:smooth_stone
fill ~4 ~-13 ~58 ~5 ~-13 ~58 minecraft:smooth_stone
setblock ~6 ~-13 ~58 minecraft:sea_lantern
fill ~7 ~-13 ~58 ~9 ~-13 ~58 minecraft:smooth_stone
setblock ~10 ~-13 ~58 minecraft:sea_lantern
fill ~11 ~-13 ~58 ~13 ~-13 ~58 minecraft:smooth_stone
setblock ~14 ~-13 ~58 minecraft:sea_lantern
fill ~15 ~-13 ~58 ~21 ~-13 ~58 minecraft:smooth_stone
setblock ~22 ~-13 ~58 minecraft:sea_lantern
fill ~23 ~-13 ~58 ~25 ~-13 ~58 minecraft:smooth_stone
setblock ~26 ~-13 ~58 minecraft:sea_lantern
fill ~27 ~-13 ~58 ~29 ~-13 ~58 minecraft:smooth_stone
setblock ~30 ~-13 ~58 minecraft:sea_lantern
fill ~31 ~-13 ~58 ~33 ~-13 ~58 minecraft:smooth_stone
setblock ~34 ~-13 ~58 minecraft:sea_lantern
fill ~35 ~-13 ~58 ~37 ~-13 ~58 minecraft:smooth_stone
setblock ~38 ~-13 ~58 minecraft:sea_lantern
fill ~39 ~-13 ~58 ~41 ~-13 ~58 minecraft:smooth_stone
setblock ~42 ~-13 ~58 minecraft:sea_lantern
fill ~43 ~-13 ~58 ~45 ~-13 ~58 minecraft:smooth_stone
setblock ~46 ~-13 ~58 minecraft:sea_lantern
fill ~47 ~-13 ~58 ~53 ~-13 ~58 minecraft:smooth_stone
setblock ~54 ~-13 ~58 minecraft:sea_lantern
fill ~55 ~-13 ~58 ~57 ~-13 ~58 minecraft:smooth_stone
setblock ~58 ~-13 ~58 minecraft:sea_lantern
fill ~59 ~-13 ~58 ~61 ~-13 ~58 minecraft:smooth_stone
setblock ~62 ~-13 ~58 minecraft:sea_lantern
fill ~63 ~-13 ~58 ~64 ~-13 ~58 minecraft:smooth_stone
fill ~4 ~-13 ~59 ~64 ~-13 ~59 minecraft:smooth_stone
fill ~4 ~-13 ~60 ~64 ~-13 ~60 minecraft:smooth_stone
fill ~4 ~-13 ~61 ~64 ~-13 ~61 minecraft:smooth_stone
fill ~4 ~-13 ~62 ~5 ~-13 ~62 minecraft:smooth_stone
setblock ~6 ~-13 ~62 minecraft:sea_lantern
fill ~7 ~-13 ~62 ~9 ~-13 ~62 minecraft:smooth_stone
setblock ~10 ~-13 ~62 minecraft:sea_lantern
fill ~11 ~-13 ~62 ~13 ~-13 ~62 minecraft:smooth_stone
setblock ~14 ~-13 ~62 minecraft:sea_lantern
fill ~15 ~-13 ~62 ~21 ~-13 ~62 minecraft:smooth_stone
setblock ~22 ~-13 ~62 minecraft:sea_lantern
fill ~23 ~-13 ~62 ~25 ~-13 ~62 minecraft:smooth_stone
setblock ~26 ~-13 ~62 minecraft:sea_lantern
fill ~27 ~-13 ~62 ~29 ~-13 ~62 minecraft:smooth_stone
setblock ~30 ~-13 ~62 minecraft:sea_lantern
fill ~31 ~-13 ~62 ~33 ~-13 ~62 minecraft:smooth_stone
setblock ~34 ~-13 ~62 minecraft:sea_lantern
fill ~35 ~-13 ~62 ~37 ~-13 ~62 minecraft:smooth_stone
setblock ~38 ~-13 ~62 minecraft:sea_lantern
fill ~39 ~-13 ~62 ~41 ~-13 ~62 minecraft:smooth_stone
setblock ~42 ~-13 ~62 minecraft:sea_lantern
fill ~43 ~-13 ~62 ~45 ~-13 ~62 minecraft:smooth_stone
setblock ~46 ~-13 ~62 minecraft:sea_lantern
fill ~47 ~-13 ~62 ~53 ~-13 ~62 minecraft:smooth_stone
setblock ~54 ~-13 ~62 minecraft:sea_lantern
fill ~55 ~-13 ~62 ~57 ~-13 ~62 minecraft:smooth_stone
setblock ~58 ~-13 ~62 minecraft:sea_lantern
fill ~59 ~-13 ~62 ~61 ~-13 ~62 minecraft:smooth_stone
setblock ~62 ~-13 ~62 minecraft:sea_lantern
fill ~63 ~-13 ~62 ~64 ~-13 ~62 minecraft:smooth_stone
fill ~4 ~-13 ~63 ~64 ~-13 ~63 minecraft:smooth_stone
fill ~4 ~-13 ~64 ~64 ~-13 ~64 minecraft:smooth_stone
fill ~32 ~-13 ~66 ~36 ~-13 ~66 minecraft:polished_andesite
setblock ~32 ~-13 ~67 minecraft:polished_andesite
setblock ~33 ~-13 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-13 ~67 ~35 ~-13 ~67 minecraft:air
setblock ~36 ~-13 ~67 minecraft:polished_andesite
setblock ~32 ~-13 ~68 minecraft:polished_andesite
setblock ~33 ~-13 ~68 minecraft:air
setblock ~34 ~-13 ~68 minecraft:quartz_pillar
setblock ~35 ~-13 ~68 minecraft:air
setblock ~36 ~-13 ~68 minecraft:polished_andesite
setblock ~32 ~-13 ~69 minecraft:polished_andesite
fill ~33 ~-13 ~69 ~35 ~-13 ~69 minecraft:air
setblock ~36 ~-13 ~69 minecraft:polished_andesite
fill ~32 ~-13 ~70 ~36 ~-13 ~70 minecraft:polished_andesite
fill ~33 ~-12 ~32 ~35 ~-12 ~32 minecraft:polished_andesite
setblock ~33 ~-12 ~33 minecraft:polished_andesite
setblock ~34 ~-12 ~33 minecraft:air
setblock ~35 ~-12 ~33 minecraft:polished_andesite
fill ~33 ~-12 ~34 ~35 ~-12 ~34 minecraft:polished_andesite
setblock ~33 ~-12 ~35 minecraft:polished_andesite
setblock ~34 ~-12 ~35 minecraft:air
setblock ~35 ~-12 ~35 minecraft:polished_andesite
fill ~33 ~-12 ~36 ~35 ~-12 ~36 minecraft:polished_andesite
fill ~32 ~-12 ~66 ~36 ~-12 ~66 minecraft:polished_andesite
setblock ~32 ~-12 ~67 minecraft:polished_andesite
setblock ~33 ~-12 ~67 minecraft:air
setblock ~34 ~-12 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-12 ~67 minecraft:air
setblock ~36 ~-12 ~67 minecraft:polished_andesite
setblock ~32 ~-12 ~68 minecraft:polished_andesite
setblock ~33 ~-12 ~68 minecraft:air
setblock ~34 ~-12 ~68 minecraft:quartz_pillar
setblock ~35 ~-12 ~68 minecraft:air
setblock ~36 ~-12 ~68 minecraft:polished_andesite
setblock ~32 ~-12 ~69 minecraft:polished_andesite
fill ~33 ~-12 ~69 ~35 ~-12 ~69 minecraft:air
setblock ~36 ~-12 ~69 minecraft:polished_andesite
fill ~32 ~-12 ~70 ~36 ~-12 ~70 minecraft:polished_andesite
fill ~33 ~-11 ~32 ~35 ~-11 ~32 minecraft:polished_andesite
setblock ~33 ~-11 ~33 minecraft:polished_andesite
setblock ~34 ~-11 ~33 minecraft:air
setblock ~35 ~-11 ~33 minecraft:polished_andesite
fill ~33 ~-11 ~34 ~35 ~-11 ~34 minecraft:polished_andesite
setblock ~33 ~-11 ~35 minecraft:polished_andesite
setblock ~34 ~-11 ~35 minecraft:air
setblock ~35 ~-11 ~35 minecraft:polished_andesite
fill ~33 ~-11 ~36 ~35 ~-11 ~36 minecraft:polished_andesite
fill ~32 ~-11 ~66 ~36 ~-11 ~66 minecraft:polished_andesite
setblock ~32 ~-11 ~67 minecraft:polished_andesite
fill ~33 ~-11 ~67 ~34 ~-11 ~67 minecraft:air
setblock ~35 ~-11 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-11 ~67 minecraft:polished_andesite
setblock ~32 ~-11 ~68 minecraft:polished_andesite
setblock ~33 ~-11 ~68 minecraft:air
setblock ~34 ~-11 ~68 minecraft:quartz_pillar
setblock ~35 ~-11 ~68 minecraft:air
setblock ~36 ~-11 ~68 minecraft:polished_andesite
setblock ~32 ~-11 ~69 minecraft:polished_andesite
fill ~33 ~-11 ~69 ~35 ~-11 ~69 minecraft:air
setblock ~36 ~-11 ~69 minecraft:polished_andesite
fill ~32 ~-11 ~70 ~36 ~-11 ~70 minecraft:polished_andesite
fill ~33 ~-10 ~32 ~35 ~-10 ~32 minecraft:polished_andesite
setblock ~33 ~-10 ~33 minecraft:polished_andesite
setblock ~34 ~-10 ~33 minecraft:air
setblock ~35 ~-10 ~33 minecraft:polished_andesite
fill ~33 ~-10 ~34 ~35 ~-10 ~34 minecraft:polished_andesite
setblock ~33 ~-10 ~35 minecraft:polished_andesite
setblock ~34 ~-10 ~35 minecraft:air
setblock ~35 ~-10 ~35 minecraft:polished_andesite
fill ~33 ~-10 ~36 ~35 ~-10 ~36 minecraft:polished_andesite
fill ~32 ~-10 ~66 ~36 ~-10 ~66 minecraft:polished_andesite
setblock ~32 ~-10 ~67 minecraft:polished_andesite
fill ~33 ~-10 ~67 ~35 ~-10 ~67 minecraft:air
setblock ~36 ~-10 ~67 minecraft:polished_andesite
setblock ~32 ~-10 ~68 minecraft:polished_andesite
setblock ~33 ~-10 ~68 minecraft:air
setblock ~34 ~-10 ~68 minecraft:quartz_pillar
setblock ~35 ~-10 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-10 ~68 minecraft:polished_andesite
setblock ~32 ~-10 ~69 minecraft:polished_andesite
fill ~33 ~-10 ~69 ~35 ~-10 ~69 minecraft:air
setblock ~36 ~-10 ~69 minecraft:polished_andesite
fill ~32 ~-10 ~70 ~36 ~-10 ~70 minecraft:polished_andesite
fill ~33 ~-9 ~32 ~35 ~-9 ~32 minecraft:polished_andesite
setblock ~33 ~-9 ~33 minecraft:polished_andesite
setblock ~34 ~-9 ~33 minecraft:air
setblock ~35 ~-9 ~33 minecraft:polished_andesite
fill ~33 ~-9 ~34 ~35 ~-9 ~34 minecraft:polished_andesite
setblock ~33 ~-9 ~35 minecraft:polished_andesite
setblock ~34 ~-9 ~35 minecraft:air
setblock ~35 ~-9 ~35 minecraft:polished_andesite
fill ~33 ~-9 ~36 ~35 ~-9 ~36 minecraft:polished_andesite
fill ~32 ~-9 ~66 ~36 ~-9 ~66 minecraft:polished_andesite
setblock ~32 ~-9 ~67 minecraft:polished_andesite
fill ~33 ~-9 ~67 ~35 ~-9 ~67 minecraft:air
setblock ~36 ~-9 ~67 minecraft:polished_andesite
setblock ~32 ~-9 ~68 minecraft:polished_andesite
setblock ~33 ~-9 ~68 minecraft:air
setblock ~34 ~-9 ~68 minecraft:quartz_pillar
setblock ~35 ~-9 ~68 minecraft:air
setblock ~36 ~-9 ~68 minecraft:polished_andesite
setblock ~32 ~-9 ~69 minecraft:polished_andesite
fill ~33 ~-9 ~69 ~34 ~-9 ~69 minecraft:air
setblock ~35 ~-9 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-9 ~69 minecraft:polished_andesite
fill ~32 ~-9 ~70 ~36 ~-9 ~70 minecraft:polished_andesite
fill ~33 ~-8 ~32 ~35 ~-8 ~32 minecraft:polished_andesite
setblock ~33 ~-8 ~33 minecraft:polished_andesite
setblock ~34 ~-8 ~33 minecraft:air
setblock ~35 ~-8 ~33 minecraft:polished_andesite
fill ~33 ~-8 ~34 ~35 ~-8 ~34 minecraft:polished_andesite
setblock ~33 ~-8 ~35 minecraft:polished_andesite
setblock ~34 ~-8 ~35 minecraft:air
setblock ~35 ~-8 ~35 minecraft:polished_andesite
fill ~33 ~-8 ~36 ~35 ~-8 ~36 minecraft:polished_andesite
fill ~32 ~-8 ~66 ~36 ~-8 ~66 minecraft:polished_andesite
setblock ~32 ~-8 ~67 minecraft:polished_andesite
fill ~33 ~-8 ~67 ~35 ~-8 ~67 minecraft:air
setblock ~36 ~-8 ~67 minecraft:polished_andesite
setblock ~32 ~-8 ~68 minecraft:sea_lantern
setblock ~33 ~-8 ~68 minecraft:air
setblock ~34 ~-8 ~68 minecraft:quartz_pillar
setblock ~35 ~-8 ~68 minecraft:air
setblock ~36 ~-8 ~68 minecraft:sea_lantern
setblock ~32 ~-8 ~69 minecraft:polished_andesite
setblock ~33 ~-8 ~69 minecraft:air
setblock ~34 ~-8 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-8 ~69 minecraft:air
setblock ~36 ~-8 ~69 minecraft:polished_andesite
fill ~32 ~-8 ~70 ~36 ~-8 ~70 minecraft:polished_andesite
fill ~33 ~-7 ~32 ~35 ~-7 ~32 minecraft:polished_andesite
setblock ~33 ~-7 ~33 minecraft:polished_andesite
setblock ~34 ~-7 ~33 minecraft:air
setblock ~35 ~-7 ~33 minecraft:polished_andesite
fill ~33 ~-7 ~34 ~35 ~-7 ~34 minecraft:polished_andesite
setblock ~33 ~-7 ~35 minecraft:polished_andesite
setblock ~34 ~-7 ~35 minecraft:air
setblock ~35 ~-7 ~35 minecraft:polished_andesite
fill ~33 ~-7 ~36 ~35 ~-7 ~36 minecraft:polished_andesite
fill ~32 ~-7 ~66 ~36 ~-7 ~66 minecraft:polished_andesite
setblock ~32 ~-7 ~67 minecraft:polished_andesite
fill ~33 ~-7 ~67 ~35 ~-7 ~67 minecraft:air
setblock ~36 ~-7 ~67 minecraft:polished_andesite
setblock ~32 ~-7 ~68 minecraft:polished_andesite
setblock ~33 ~-7 ~68 minecraft:air
setblock ~34 ~-7 ~68 minecraft:quartz_pillar
setblock ~35 ~-7 ~68 minecraft:air
setblock ~36 ~-7 ~68 minecraft:polished_andesite
setblock ~32 ~-7 ~69 minecraft:polished_andesite
setblock ~33 ~-7 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-7 ~69 ~35 ~-7 ~69 minecraft:air
setblock ~36 ~-7 ~69 minecraft:polished_andesite
fill ~32 ~-7 ~70 ~36 ~-7 ~70 minecraft:polished_andesite
fill ~33 ~-6 ~32 ~35 ~-6 ~32 minecraft:polished_andesite
setblock ~33 ~-6 ~33 minecraft:polished_andesite
setblock ~34 ~-6 ~33 minecraft:air
setblock ~35 ~-6 ~33 minecraft:polished_andesite
fill ~33 ~-6 ~34 ~35 ~-6 ~34 minecraft:polished_andesite
setblock ~33 ~-6 ~35 minecraft:polished_andesite
setblock ~34 ~-6 ~35 minecraft:air
setblock ~35 ~-6 ~35 minecraft:polished_andesite
fill ~33 ~-6 ~36 ~35 ~-6 ~36 minecraft:polished_andesite
fill ~32 ~-6 ~66 ~36 ~-6 ~66 minecraft:polished_andesite
setblock ~32 ~-6 ~67 minecraft:polished_andesite
fill ~33 ~-6 ~67 ~35 ~-6 ~67 minecraft:air
setblock ~36 ~-6 ~67 minecraft:polished_andesite
setblock ~32 ~-6 ~68 minecraft:polished_andesite
setblock ~33 ~-6 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-6 ~68 minecraft:quartz_pillar
setblock ~35 ~-6 ~68 minecraft:air
setblock ~36 ~-6 ~68 minecraft:polished_andesite
setblock ~32 ~-6 ~69 minecraft:polished_andesite
fill ~33 ~-6 ~69 ~35 ~-6 ~69 minecraft:air
setblock ~36 ~-6 ~69 minecraft:polished_andesite
fill ~32 ~-6 ~70 ~36 ~-6 ~70 minecraft:polished_andesite
fill ~33 ~-5 ~32 ~35 ~-5 ~32 minecraft:polished_andesite
setblock ~33 ~-5 ~33 minecraft:polished_andesite
setblock ~34 ~-5 ~33 minecraft:air
setblock ~35 ~-5 ~33 minecraft:polished_andesite
fill ~33 ~-5 ~34 ~35 ~-5 ~34 minecraft:polished_andesite
setblock ~33 ~-5 ~35 minecraft:polished_andesite
setblock ~34 ~-5 ~35 minecraft:air
setblock ~35 ~-5 ~35 minecraft:polished_andesite
fill ~33 ~-5 ~36 ~35 ~-5 ~36 minecraft:polished_andesite
fill ~32 ~-5 ~66 ~36 ~-5 ~66 minecraft:polished_andesite
setblock ~32 ~-5 ~67 minecraft:polished_andesite
setblock ~33 ~-5 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-5 ~67 ~35 ~-5 ~67 minecraft:air
setblock ~36 ~-5 ~67 minecraft:polished_andesite
setblock ~32 ~-5 ~68 minecraft:polished_andesite
setblock ~33 ~-5 ~68 minecraft:air
setblock ~34 ~-5 ~68 minecraft:quartz_pillar
setblock ~35 ~-5 ~68 minecraft:air
setblock ~36 ~-5 ~68 minecraft:polished_andesite
setblock ~32 ~-5 ~69 minecraft:polished_andesite
fill ~33 ~-5 ~69 ~35 ~-5 ~69 minecraft:air
setblock ~36 ~-5 ~69 minecraft:polished_andesite
fill ~32 ~-5 ~70 ~36 ~-5 ~70 minecraft:polished_andesite
fill ~33 ~-4 ~32 ~35 ~-4 ~32 minecraft:polished_andesite
setblock ~33 ~-4 ~33 minecraft:polished_andesite
setblock ~34 ~-4 ~33 minecraft:air
setblock ~35 ~-4 ~33 minecraft:polished_andesite
fill ~33 ~-4 ~34 ~35 ~-4 ~34 minecraft:polished_andesite
setblock ~33 ~-4 ~35 minecraft:polished_andesite
setblock ~34 ~-4 ~35 minecraft:air
setblock ~35 ~-4 ~35 minecraft:polished_andesite
fill ~33 ~-4 ~36 ~35 ~-4 ~36 minecraft:polished_andesite
fill ~32 ~-4 ~66 ~36 ~-4 ~66 minecraft:polished_andesite
setblock ~32 ~-4 ~67 minecraft:polished_andesite
setblock ~33 ~-4 ~67 minecraft:air
setblock ~34 ~-4 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
setblock ~35 ~-4 ~67 minecraft:air
setblock ~36 ~-4 ~67 minecraft:polished_andesite
setblock ~32 ~-4 ~68 minecraft:polished_andesite
setblock ~33 ~-4 ~68 minecraft:air
setblock ~34 ~-4 ~68 minecraft:quartz_pillar
setblock ~35 ~-4 ~68 minecraft:air
setblock ~36 ~-4 ~68 minecraft:polished_andesite
setblock ~32 ~-4 ~69 minecraft:polished_andesite
fill ~33 ~-4 ~69 ~35 ~-4 ~69 minecraft:air
setblock ~36 ~-4 ~69 minecraft:polished_andesite
fill ~32 ~-4 ~70 ~36 ~-4 ~70 minecraft:polished_andesite
fill ~33 ~-3 ~32 ~35 ~-3 ~32 minecraft:polished_andesite
setblock ~33 ~-3 ~33 minecraft:polished_andesite
setblock ~34 ~-3 ~33 minecraft:air
setblock ~35 ~-3 ~33 minecraft:polished_andesite
fill ~33 ~-3 ~34 ~35 ~-3 ~34 minecraft:polished_andesite
setblock ~33 ~-3 ~35 minecraft:polished_andesite
setblock ~34 ~-3 ~35 minecraft:air
setblock ~35 ~-3 ~35 minecraft:polished_andesite
fill ~33 ~-3 ~36 ~35 ~-3 ~36 minecraft:polished_andesite
fill ~32 ~-3 ~66 ~36 ~-3 ~66 minecraft:polished_andesite
setblock ~32 ~-3 ~67 minecraft:polished_andesite
fill ~33 ~-3 ~67 ~34 ~-3 ~67 minecraft:air
setblock ~35 ~-3 ~67 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-3 ~67 minecraft:polished_andesite
setblock ~32 ~-3 ~68 minecraft:polished_andesite
setblock ~33 ~-3 ~68 minecraft:air
setblock ~34 ~-3 ~68 minecraft:quartz_pillar
setblock ~35 ~-3 ~68 minecraft:air
setblock ~36 ~-3 ~68 minecraft:polished_andesite
setblock ~32 ~-3 ~69 minecraft:polished_andesite
fill ~33 ~-3 ~69 ~35 ~-3 ~69 minecraft:air
setblock ~36 ~-3 ~69 minecraft:polished_andesite
fill ~32 ~-3 ~70 ~36 ~-3 ~70 minecraft:polished_andesite
fill ~33 ~-2 ~32 ~35 ~-2 ~32 minecraft:polished_andesite
setblock ~33 ~-2 ~33 minecraft:polished_andesite
setblock ~34 ~-2 ~33 minecraft:air
setblock ~35 ~-2 ~33 minecraft:polished_andesite
fill ~33 ~-2 ~34 ~35 ~-2 ~34 minecraft:polished_andesite
setblock ~33 ~-2 ~35 minecraft:polished_andesite
setblock ~34 ~-2 ~35 minecraft:air
setblock ~35 ~-2 ~35 minecraft:polished_andesite
fill ~33 ~-2 ~36 ~35 ~-2 ~36 minecraft:polished_andesite
fill ~32 ~-2 ~66 ~36 ~-2 ~66 minecraft:polished_andesite
setblock ~32 ~-2 ~67 minecraft:polished_andesite
fill ~33 ~-2 ~67 ~35 ~-2 ~67 minecraft:air
setblock ~36 ~-2 ~67 minecraft:polished_andesite
setblock ~32 ~-2 ~68 minecraft:polished_andesite
setblock ~33 ~-2 ~68 minecraft:air
setblock ~34 ~-2 ~68 minecraft:quartz_pillar
setblock ~35 ~-2 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-2 ~68 minecraft:polished_andesite
setblock ~32 ~-2 ~69 minecraft:polished_andesite
fill ~33 ~-2 ~69 ~35 ~-2 ~69 minecraft:air
setblock ~36 ~-2 ~69 minecraft:polished_andesite
fill ~32 ~-2 ~70 ~36 ~-2 ~70 minecraft:polished_andesite
fill ~18 ~-1 ~11 ~49 ~-1 ~11 minecraft:polished_diorite
fill ~18 ~-1 ~12 ~49 ~-1 ~12 minecraft:polished_diorite
fill ~18 ~-1 ~13 ~49 ~-1 ~13 minecraft:polished_diorite
fill ~18 ~-1 ~14 ~49 ~-1 ~14 minecraft:polished_diorite
fill ~18 ~-1 ~15 ~49 ~-1 ~15 minecraft:polished_diorite
fill ~18 ~-1 ~16 ~49 ~-1 ~16 minecraft:polished_diorite
fill ~18 ~-1 ~17 ~49 ~-1 ~17 minecraft:polished_diorite
fill ~18 ~-1 ~18 ~49 ~-1 ~18 minecraft:polished_diorite
fill ~18 ~-1 ~19 ~49 ~-1 ~19 minecraft:polished_diorite
fill ~18 ~-1 ~20 ~49 ~-1 ~20 minecraft:polished_diorite
fill ~18 ~-1 ~21 ~49 ~-1 ~21 minecraft:polished_diorite
fill ~18 ~-1 ~22 ~49 ~-1 ~22 minecraft:polished_diorite
fill ~18 ~-1 ~23 ~49 ~-1 ~23 minecraft:polished_diorite
fill ~18 ~-1 ~24 ~49 ~-1 ~24 minecraft:polished_diorite
fill ~18 ~-1 ~25 ~49 ~-1 ~25 minecraft:polished_diorite
fill ~18 ~-1 ~26 ~49 ~-1 ~26 minecraft:polished_diorite
fill ~18 ~-1 ~27 ~49 ~-1 ~27 minecraft:polished_diorite
fill ~18 ~-1 ~28 ~49 ~-1 ~28 minecraft:polished_diorite
fill ~18 ~-1 ~29 ~49 ~-1 ~29 minecraft:polished_diorite
fill ~18 ~-1 ~30 ~49 ~-1 ~30 minecraft:polished_diorite
fill ~18 ~-1 ~31 ~49 ~-1 ~31 minecraft:polished_diorite
fill ~18 ~-1 ~32 ~49 ~-1 ~32 minecraft:polished_diorite
fill ~18 ~-1 ~33 ~33 ~-1 ~33 minecraft:polished_diorite
setblock ~34 ~-1 ~33 minecraft:air
fill ~35 ~-1 ~33 ~49 ~-1 ~33 minecraft:polished_diorite
fill ~18 ~-1 ~34 ~49 ~-1 ~34 minecraft:polished_diorite
fill ~18 ~-1 ~35 ~33 ~-1 ~35 minecraft:polished_diorite
setblock ~34 ~-1 ~35 minecraft:air
fill ~35 ~-1 ~35 ~49 ~-1 ~35 minecraft:polished_diorite
fill ~18 ~-1 ~36 ~49 ~-1 ~36 minecraft:polished_diorite
fill ~18 ~-1 ~37 ~49 ~-1 ~37 minecraft:polished_diorite
fill ~18 ~-1 ~38 ~49 ~-1 ~38 minecraft:polished_diorite
fill ~18 ~-1 ~39 ~49 ~-1 ~39 minecraft:polished_diorite
fill ~18 ~-1 ~40 ~49 ~-1 ~40 minecraft:polished_diorite
fill ~18 ~-1 ~41 ~49 ~-1 ~41 minecraft:polished_diorite
fill ~18 ~-1 ~42 ~49 ~-1 ~42 minecraft:polished_diorite
fill ~18 ~-1 ~43 ~49 ~-1 ~43 minecraft:polished_diorite
fill ~18 ~-1 ~44 ~49 ~-1 ~44 minecraft:polished_diorite
fill ~18 ~-1 ~45 ~49 ~-1 ~45 minecraft:polished_diorite
fill ~18 ~-1 ~46 ~49 ~-1 ~46 minecraft:polished_diorite
fill ~18 ~-1 ~47 ~49 ~-1 ~47 minecraft:polished_diorite
fill ~18 ~-1 ~48 ~49 ~-1 ~48 minecraft:polished_diorite
fill ~18 ~-1 ~49 ~49 ~-1 ~49 minecraft:polished_diorite
fill ~18 ~-1 ~50 ~49 ~-1 ~50 minecraft:polished_diorite
fill ~18 ~-1 ~51 ~49 ~-1 ~51 minecraft:polished_diorite
fill ~18 ~-1 ~52 ~49 ~-1 ~52 minecraft:polished_diorite
fill ~18 ~-1 ~53 ~49 ~-1 ~53 minecraft:polished_diorite
fill ~18 ~-1 ~54 ~49 ~-1 ~54 minecraft:polished_diorite
fill ~18 ~-1 ~55 ~49 ~-1 ~55 minecraft:polished_diorite
fill ~18 ~-1 ~56 ~49 ~-1 ~56 minecraft:polished_diorite
fill ~18 ~-1 ~57 ~49 ~-1 ~57 minecraft:polished_diorite
fill ~21 ~-1 ~58 ~47 ~-1 ~58 minecraft:polished_diorite
fill ~21 ~-1 ~59 ~47 ~-1 ~59 minecraft:polished_diorite
fill ~21 ~-1 ~60 ~47 ~-1 ~60 minecraft:polished_diorite
fill ~21 ~-1 ~61 ~47 ~-1 ~61 minecraft:polished_diorite
fill ~21 ~-1 ~62 ~47 ~-1 ~62 minecraft:polished_diorite
fill ~21 ~-1 ~63 ~33 ~-1 ~63 minecraft:polished_diorite
setblock ~34 ~-1 ~63 minecraft:polished_andesite
fill ~35 ~-1 ~63 ~47 ~-1 ~63 minecraft:polished_diorite
fill ~21 ~-1 ~64 ~33 ~-1 ~64 minecraft:polished_diorite
setblock ~34 ~-1 ~64 minecraft:polished_andesite
fill ~35 ~-1 ~64 ~47 ~-1 ~64 minecraft:polished_diorite
fill ~21 ~-1 ~65 ~33 ~-1 ~65 minecraft:polished_diorite
setblock ~34 ~-1 ~65 minecraft:polished_andesite
fill ~35 ~-1 ~65 ~47 ~-1 ~65 minecraft:polished_diorite
fill ~21 ~-1 ~66 ~31 ~-1 ~66 minecraft:polished_diorite
fill ~32 ~-1 ~66 ~36 ~-1 ~66 minecraft:polished_andesite
fill ~37 ~-1 ~66 ~47 ~-1 ~66 minecraft:polished_diorite
fill ~21 ~-1 ~67 ~31 ~-1 ~67 minecraft:polished_diorite
fill ~32 ~-1 ~67 ~34 ~-1 ~67 minecraft:polished_andesite
setblock ~35 ~-1 ~67 minecraft:air
setblock ~36 ~-1 ~67 minecraft:polished_andesite
fill ~37 ~-1 ~67 ~47 ~-1 ~67 minecraft:polished_diorite
fill ~21 ~-1 ~68 ~31 ~-1 ~68 minecraft:polished_diorite
fill ~32 ~-1 ~68 ~33 ~-1 ~68 minecraft:polished_andesite
setblock ~34 ~-1 ~68 minecraft:quartz_pillar
setblock ~35 ~-1 ~68 minecraft:air
setblock ~36 ~-1 ~68 minecraft:polished_andesite
fill ~37 ~-1 ~68 ~47 ~-1 ~68 minecraft:polished_diorite
fill ~21 ~-1 ~69 ~31 ~-1 ~69 minecraft:polished_diorite
fill ~32 ~-1 ~69 ~34 ~-1 ~69 minecraft:polished_andesite
setblock ~35 ~-1 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-1 ~69 minecraft:polished_andesite
fill ~37 ~-1 ~69 ~47 ~-1 ~69 minecraft:polished_diorite
fill ~21 ~-1 ~70 ~31 ~-1 ~70 minecraft:polished_diorite
fill ~32 ~-1 ~70 ~36 ~-1 ~70 minecraft:polished_andesite
fill ~37 ~-1 ~70 ~47 ~-1 ~70 minecraft:polished_diorite
fill ~21 ~-1 ~71 ~47 ~-1 ~71 minecraft:polished_diorite
fill ~21 ~-1 ~72 ~47 ~-1 ~72 minecraft:polished_diorite
fill ~21 ~-1 ~73 ~47 ~-1 ~73 minecraft:polished_diorite
fill ~21 ~-1 ~74 ~47 ~-1 ~74 minecraft:polished_diorite
fill ~21 ~-1 ~75 ~47 ~-1 ~75 minecraft:polished_diorite
fill ~32 ~-1 ~76 ~36 ~-1 ~76 minecraft:dirt_path
fill ~32 ~-1 ~77 ~36 ~-1 ~77 minecraft:dirt_path
fill ~32 ~-1 ~78 ~36 ~-1 ~78 minecraft:dirt_path
fill ~32 ~-1 ~79 ~36 ~-1 ~79 minecraft:dirt_path
fill ~32 ~-1 ~80 ~36 ~-1 ~80 minecraft:dirt_path
fill ~32 ~-1 ~81 ~36 ~-1 ~81 minecraft:dirt_path
fill ~32 ~-1 ~82 ~36 ~-1 ~82 minecraft:dirt_path
fill ~32 ~-1 ~83 ~36 ~-1 ~83 minecraft:dirt_path
fill ~32 ~-1 ~84 ~36 ~-1 ~84 minecraft:dirt_path
fill ~32 ~-1 ~85 ~36 ~-1 ~85 minecraft:dirt_path
fill ~32 ~-1 ~86 ~36 ~-1 ~86 minecraft:dirt_path
fill ~32 ~-1 ~87 ~36 ~-1 ~87 minecraft:dirt_path
fill ~32 ~-1 ~88 ~36 ~-1 ~88 minecraft:dirt_path
fill ~32 ~-1 ~89 ~36 ~-1 ~89 minecraft:dirt_path
fill ~32 ~-1 ~90 ~36 ~-1 ~90 minecraft:dirt_path
setblock ~5 ~0 ~6 minecraft:oak_log
setblock ~13 ~0 ~8 minecraft:oak_log
setblock ~54 ~0 ~8 minecraft:oak_log
setblock ~63 ~0 ~10 minecraft:oak_log
setblock ~20 ~0 ~13 minecraft:smooth_quartz
fill ~21 ~0 ~13 ~46 ~0 ~13 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~47 ~0 ~13 minecraft:smooth_quartz
setblock ~20 ~0 ~14 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~14 ~46 ~0 ~14 minecraft:smooth_quartz
setblock ~47 ~0 ~14 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~15 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~15 ~46 ~0 ~15 minecraft:smooth_quartz
setblock ~47 ~0 ~15 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~16 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~16 ~46 ~0 ~16 minecraft:smooth_quartz
setblock ~47 ~0 ~16 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~17 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~17 ~46 ~0 ~17 minecraft:smooth_quartz
setblock ~47 ~0 ~17 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~6 ~0 ~18 minecraft:oak_log
setblock ~20 ~0 ~18 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~18 ~46 ~0 ~18 minecraft:smooth_quartz
setblock ~47 ~0 ~18 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~19 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~19 ~46 ~0 ~19 minecraft:smooth_quartz
setblock ~47 ~0 ~19 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~20 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~20 ~46 ~0 ~20 minecraft:smooth_quartz
setblock ~47 ~0 ~20 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~21 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~21 ~46 ~0 ~21 minecraft:smooth_quartz
setblock ~47 ~0 ~21 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~22 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~22 ~46 ~0 ~22 minecraft:smooth_quartz
setblock ~47 ~0 ~22 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~60 ~0 ~22 minecraft:oak_log
setblock ~20 ~0 ~23 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~23 ~46 ~0 ~23 minecraft:smooth_quartz
setblock ~47 ~0 ~23 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~24 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~24 ~46 ~0 ~24 minecraft:smooth_quartz
setblock ~47 ~0 ~24 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~25 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~25 ~46 ~0 ~25 minecraft:smooth_quartz
setblock ~47 ~0 ~25 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~26 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~26 ~46 ~0 ~26 minecraft:smooth_quartz
setblock ~47 ~0 ~26 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~27 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~27 ~46 ~0 ~27 minecraft:smooth_quartz
setblock ~47 ~0 ~27 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~28 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~28 ~46 ~0 ~28 minecraft:smooth_quartz
setblock ~47 ~0 ~28 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~29 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~29 ~46 ~0 ~29 minecraft:smooth_quartz
setblock ~47 ~0 ~29 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~30 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~30 ~46 ~0 ~30 minecraft:smooth_quartz
setblock ~47 ~0 ~30 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~31 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~31 ~46 ~0 ~31 minecraft:smooth_quartz
setblock ~47 ~0 ~31 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~32 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~32 ~46 ~0 ~32 minecraft:smooth_quartz
setblock ~47 ~0 ~32 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~4 ~0 ~33 minecraft:oak_log
setblock ~20 ~0 ~33 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~33 ~33 ~0 ~33 minecraft:smooth_quartz
fill ~35 ~0 ~33 ~46 ~0 ~33 minecraft:smooth_quartz
setblock ~47 ~0 ~33 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~34 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~34 ~46 ~0 ~34 minecraft:smooth_quartz
setblock ~47 ~0 ~34 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~35 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~35 ~33 ~0 ~35 minecraft:smooth_quartz
fill ~35 ~0 ~35 ~46 ~0 ~35 minecraft:smooth_quartz
setblock ~47 ~0 ~35 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~36 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~36 ~46 ~0 ~36 minecraft:smooth_quartz
setblock ~47 ~0 ~36 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~64 ~0 ~36 minecraft:oak_log
setblock ~20 ~0 ~37 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~37 ~46 ~0 ~37 minecraft:smooth_quartz
setblock ~47 ~0 ~37 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~38 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~38 ~46 ~0 ~38 minecraft:smooth_quartz
setblock ~47 ~0 ~38 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~39 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~39 ~46 ~0 ~39 minecraft:smooth_quartz
setblock ~47 ~0 ~39 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~40 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~40 ~46 ~0 ~40 minecraft:smooth_quartz
setblock ~47 ~0 ~40 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~41 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~41 ~46 ~0 ~41 minecraft:smooth_quartz
setblock ~47 ~0 ~41 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~42 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~42 ~46 ~0 ~42 minecraft:smooth_quartz
setblock ~47 ~0 ~42 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~43 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~43 ~46 ~0 ~43 minecraft:smooth_quartz
setblock ~47 ~0 ~43 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~44 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~44 ~46 ~0 ~44 minecraft:smooth_quartz
setblock ~47 ~0 ~44 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~45 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~45 ~46 ~0 ~45 minecraft:smooth_quartz
setblock ~47 ~0 ~45 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~46 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~46 ~46 ~0 ~46 minecraft:smooth_quartz
setblock ~47 ~0 ~46 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~47 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~47 ~46 ~0 ~47 minecraft:smooth_quartz
setblock ~47 ~0 ~47 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~6 ~0 ~48 minecraft:oak_log
setblock ~20 ~0 ~48 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~48 ~46 ~0 ~48 minecraft:smooth_quartz
setblock ~47 ~0 ~48 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~49 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~49 ~46 ~0 ~49 minecraft:smooth_quartz
setblock ~47 ~0 ~49 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~50 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~50 ~46 ~0 ~50 minecraft:smooth_quartz
setblock ~47 ~0 ~50 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~51 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~51 ~46 ~0 ~51 minecraft:smooth_quartz
setblock ~47 ~0 ~51 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~52 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~52 ~46 ~0 ~52 minecraft:smooth_quartz
setblock ~47 ~0 ~52 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~60 ~0 ~52 minecraft:oak_log
setblock ~20 ~0 ~53 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~53 ~46 ~0 ~53 minecraft:smooth_quartz
setblock ~47 ~0 ~53 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~54 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~21 ~0 ~54 ~46 ~0 ~54 minecraft:smooth_quartz
setblock ~47 ~0 ~54 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~20 ~0 ~55 minecraft:smooth_quartz
fill ~21 ~0 ~55 ~46 ~0 ~55 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~47 ~0 ~55 minecraft:smooth_quartz
setblock ~4 ~0 ~62 minecraft:oak_log
fill ~25 ~0 ~62 ~33 ~0 ~62 minecraft:polished_deepslate
fill ~35 ~0 ~62 ~43 ~0 ~62 minecraft:polished_deepslate
setblock ~62 ~0 ~62 minecraft:oak_log
fill ~25 ~0 ~63 ~33 ~0 ~63 minecraft:polished_deepslate
fill ~35 ~0 ~63 ~43 ~0 ~63 minecraft:polished_deepslate
fill ~25 ~0 ~64 ~33 ~0 ~64 minecraft:polished_deepslate
fill ~35 ~0 ~64 ~43 ~0 ~64 minecraft:polished_deepslate
fill ~25 ~0 ~65 ~33 ~0 ~65 minecraft:polished_deepslate
fill ~35 ~0 ~65 ~43 ~0 ~65 minecraft:polished_deepslate
fill ~25 ~0 ~66 ~33 ~0 ~66 minecraft:polished_deepslate
fill ~35 ~0 ~66 ~43 ~0 ~66 minecraft:polished_deepslate
fill ~25 ~0 ~67 ~32 ~0 ~67 minecraft:polished_deepslate
fill ~36 ~0 ~67 ~43 ~0 ~67 minecraft:polished_deepslate
fill ~25 ~0 ~68 ~32 ~0 ~68 minecraft:polished_deepslate
fill ~36 ~0 ~68 ~43 ~0 ~68 minecraft:polished_deepslate
fill ~25 ~0 ~69 ~32 ~0 ~69 minecraft:polished_deepslate
fill ~36 ~0 ~69 ~43 ~0 ~69 minecraft:polished_deepslate
fill ~25 ~0 ~70 ~43 ~0 ~70 minecraft:polished_deepslate
setblock ~9 ~0 ~72 minecraft:oak_log
setblock ~57 ~0 ~72 minecraft:oak_log
setblock ~6 ~0 ~84 minecraft:oak_log
setblock ~58 ~0 ~86 minecraft:oak_log
setblock ~5 ~1 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~1 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~1 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~1 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~21 ~1 ~14 minecraft:smooth_quartz
fill ~22 ~1 ~14 ~45 ~1 ~14 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~46 ~1 ~14 minecraft:smooth_quartz
setblock ~21 ~1 ~15 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~15 ~45 ~1 ~15 minecraft:smooth_quartz
setblock ~46 ~1 ~15 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~16 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~16 ~45 ~1 ~16 minecraft:smooth_quartz
setblock ~46 ~1 ~16 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~17 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~17 ~45 ~1 ~17 minecraft:smooth_quartz
setblock ~46 ~1 ~17 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~6 ~1 ~18 minecraft:oak_log
setblock ~21 ~1 ~18 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~18 ~45 ~1 ~18 minecraft:smooth_quartz
setblock ~46 ~1 ~18 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~19 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~19 ~45 ~1 ~19 minecraft:smooth_quartz
setblock ~46 ~1 ~19 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~20 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~20 ~45 ~1 ~20 minecraft:smooth_quartz
setblock ~46 ~1 ~20 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~21 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~21 ~45 ~1 ~21 minecraft:smooth_quartz
setblock ~46 ~1 ~21 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~22 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~22 ~45 ~1 ~22 minecraft:smooth_quartz
setblock ~46 ~1 ~22 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~60 ~1 ~22 minecraft:oak_log
setblock ~21 ~1 ~23 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~23 ~45 ~1 ~23 minecraft:smooth_quartz
setblock ~46 ~1 ~23 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~24 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~24 ~45 ~1 ~24 minecraft:smooth_quartz
setblock ~46 ~1 ~24 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~25 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~25 ~45 ~1 ~25 minecraft:smooth_quartz
setblock ~46 ~1 ~25 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~26 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~26 ~45 ~1 ~26 minecraft:smooth_quartz
setblock ~46 ~1 ~26 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~27 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~27 ~45 ~1 ~27 minecraft:smooth_quartz
setblock ~46 ~1 ~27 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~28 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~28 ~45 ~1 ~28 minecraft:smooth_quartz
setblock ~46 ~1 ~28 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~29 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~29 ~45 ~1 ~29 minecraft:smooth_quartz
setblock ~46 ~1 ~29 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~30 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~30 ~45 ~1 ~30 minecraft:smooth_quartz
setblock ~46 ~1 ~30 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~31 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~31 ~45 ~1 ~31 minecraft:smooth_quartz
setblock ~46 ~1 ~31 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~32 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~32 ~45 ~1 ~32 minecraft:smooth_quartz
setblock ~46 ~1 ~32 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~4 ~1 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~21 ~1 ~33 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~33 ~33 ~1 ~33 minecraft:smooth_quartz
fill ~35 ~1 ~33 ~45 ~1 ~33 minecraft:smooth_quartz
setblock ~46 ~1 ~33 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~34 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~34 ~45 ~1 ~34 minecraft:smooth_quartz
setblock ~46 ~1 ~34 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~35 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~35 ~33 ~1 ~35 minecraft:smooth_quartz
fill ~35 ~1 ~35 ~45 ~1 ~35 minecraft:smooth_quartz
setblock ~46 ~1 ~35 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~36 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~36 ~45 ~1 ~36 minecraft:smooth_quartz
setblock ~46 ~1 ~36 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~64 ~1 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~21 ~1 ~37 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~37 ~45 ~1 ~37 minecraft:smooth_quartz
setblock ~46 ~1 ~37 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~38 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~38 ~45 ~1 ~38 minecraft:smooth_quartz
setblock ~46 ~1 ~38 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~39 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~39 ~45 ~1 ~39 minecraft:smooth_quartz
setblock ~46 ~1 ~39 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~40 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~40 ~45 ~1 ~40 minecraft:smooth_quartz
setblock ~46 ~1 ~40 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~41 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~41 ~45 ~1 ~41 minecraft:smooth_quartz
setblock ~46 ~1 ~41 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~42 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~42 ~45 ~1 ~42 minecraft:smooth_quartz
setblock ~46 ~1 ~42 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~43 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~43 ~45 ~1 ~43 minecraft:smooth_quartz
setblock ~46 ~1 ~43 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~44 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~44 ~45 ~1 ~44 minecraft:smooth_quartz
setblock ~46 ~1 ~44 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~45 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~45 ~45 ~1 ~45 minecraft:smooth_quartz
setblock ~46 ~1 ~45 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~46 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~46 ~45 ~1 ~46 minecraft:smooth_quartz
setblock ~46 ~1 ~46 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~47 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~47 ~45 ~1 ~47 minecraft:smooth_quartz
setblock ~46 ~1 ~47 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~6 ~1 ~48 minecraft:oak_log
setblock ~21 ~1 ~48 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~48 ~45 ~1 ~48 minecraft:smooth_quartz
setblock ~46 ~1 ~48 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~49 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~49 ~45 ~1 ~49 minecraft:smooth_quartz
setblock ~46 ~1 ~49 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~50 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~50 ~45 ~1 ~50 minecraft:smooth_quartz
setblock ~46 ~1 ~50 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~51 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~51 ~45 ~1 ~51 minecraft:smooth_quartz
setblock ~46 ~1 ~51 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~52 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~52 ~45 ~1 ~52 minecraft:smooth_quartz
setblock ~46 ~1 ~52 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~60 ~1 ~52 minecraft:oak_log
setblock ~21 ~1 ~53 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~22 ~1 ~53 ~45 ~1 ~53 minecraft:smooth_quartz
setblock ~46 ~1 ~53 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~21 ~1 ~54 minecraft:smooth_quartz
fill ~22 ~1 ~54 ~45 ~1 ~54 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~46 ~1 ~54 minecraft:smooth_quartz
setblock ~4 ~1 ~62 minecraft:spruce_leaves[persistent=true]
fill ~25 ~1 ~62 ~33 ~1 ~62 minecraft:polished_deepslate
fill ~35 ~1 ~62 ~43 ~1 ~62 minecraft:polished_deepslate
setblock ~62 ~1 ~62 minecraft:spruce_leaves[persistent=true]
fill ~25 ~1 ~63 ~33 ~1 ~63 minecraft:polished_deepslate
fill ~35 ~1 ~63 ~43 ~1 ~63 minecraft:polished_deepslate
fill ~25 ~1 ~64 ~33 ~1 ~64 minecraft:polished_deepslate
fill ~35 ~1 ~64 ~43 ~1 ~64 minecraft:polished_deepslate
fill ~25 ~1 ~65 ~33 ~1 ~65 minecraft:polished_deepslate
fill ~35 ~1 ~65 ~43 ~1 ~65 minecraft:polished_deepslate
fill ~25 ~1 ~66 ~33 ~1 ~66 minecraft:polished_deepslate
fill ~35 ~1 ~66 ~43 ~1 ~66 minecraft:polished_deepslate
fill ~25 ~1 ~67 ~32 ~1 ~67 minecraft:polished_deepslate
fill ~36 ~1 ~67 ~43 ~1 ~67 minecraft:polished_deepslate
fill ~25 ~1 ~68 ~32 ~1 ~68 minecraft:polished_deepslate
fill ~36 ~1 ~68 ~43 ~1 ~68 minecraft:polished_deepslate
fill ~25 ~1 ~69 ~32 ~1 ~69 minecraft:polished_deepslate
fill ~36 ~1 ~69 ~43 ~1 ~69 minecraft:polished_deepslate
fill ~25 ~1 ~70 ~43 ~1 ~70 minecraft:polished_deepslate
setblock ~9 ~1 ~72 minecraft:oak_log
setblock ~57 ~1 ~72 minecraft:oak_log
setblock ~6 ~1 ~84 minecraft:oak_log
setblock ~58 ~1 ~86 minecraft:oak_log
setblock ~5 ~2 ~5 minecraft:spruce_leaves[persistent=true]
fill ~4 ~2 ~6 ~6 ~2 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~5 ~2 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~2 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~2 ~7 minecraft:spruce_leaves[persistent=true]
fill ~12 ~2 ~8 ~14 ~2 ~8 minecraft:spruce_leaves[persistent=true]
fill ~53 ~2 ~8 ~55 ~2 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~2 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~2 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~2 ~9 minecraft:spruce_leaves[persistent=true]
fill ~62 ~2 ~10 ~64 ~2 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~2 ~11 minecraft:spruce_leaves[persistent=true]
fill ~22 ~2 ~15 ~45 ~2 ~15 minecraft:smooth_quartz
fill ~22 ~2 ~16 ~45 ~2 ~16 minecraft:smooth_quartz
fill ~22 ~2 ~17 ~45 ~2 ~17 minecraft:smooth_quartz
setblock ~6 ~2 ~18 minecraft:oak_log
fill ~22 ~2 ~18 ~45 ~2 ~18 minecraft:smooth_quartz
fill ~22 ~2 ~19 ~45 ~2 ~19 minecraft:smooth_quartz
fill ~22 ~2 ~20 ~45 ~2 ~20 minecraft:smooth_quartz
fill ~22 ~2 ~21 ~45 ~2 ~21 minecraft:smooth_quartz
fill ~22 ~2 ~22 ~45 ~2 ~22 minecraft:smooth_quartz
setblock ~60 ~2 ~22 minecraft:oak_log
fill ~22 ~2 ~23 ~27 ~2 ~23 minecraft:smooth_quartz
fill ~28 ~2 ~23 ~39 ~2 ~23 minecraft:polished_diorite
fill ~40 ~2 ~23 ~45 ~2 ~23 minecraft:smooth_quartz
fill ~22 ~2 ~24 ~27 ~2 ~24 minecraft:smooth_quartz
fill ~28 ~2 ~24 ~39 ~2 ~24 minecraft:polished_diorite
fill ~40 ~2 ~24 ~45 ~2 ~24 minecraft:smooth_quartz
fill ~22 ~2 ~25 ~27 ~2 ~25 minecraft:smooth_quartz
fill ~28 ~2 ~25 ~39 ~2 ~25 minecraft:polished_diorite
fill ~40 ~2 ~25 ~45 ~2 ~25 minecraft:smooth_quartz
fill ~22 ~2 ~26 ~27 ~2 ~26 minecraft:smooth_quartz
fill ~28 ~2 ~26 ~39 ~2 ~26 minecraft:polished_diorite
fill ~40 ~2 ~26 ~45 ~2 ~26 minecraft:smooth_quartz
fill ~22 ~2 ~27 ~27 ~2 ~27 minecraft:smooth_quartz
fill ~28 ~2 ~27 ~39 ~2 ~27 minecraft:polished_diorite
fill ~40 ~2 ~27 ~45 ~2 ~27 minecraft:smooth_quartz
fill ~22 ~2 ~28 ~27 ~2 ~28 minecraft:smooth_quartz
fill ~28 ~2 ~28 ~39 ~2 ~28 minecraft:polished_diorite
fill ~40 ~2 ~28 ~45 ~2 ~28 minecraft:smooth_quartz
fill ~22 ~2 ~29 ~27 ~2 ~29 minecraft:smooth_quartz
fill ~28 ~2 ~29 ~39 ~2 ~29 minecraft:polished_diorite
fill ~40 ~2 ~29 ~45 ~2 ~29 minecraft:smooth_quartz
fill ~22 ~2 ~30 ~27 ~2 ~30 minecraft:smooth_quartz
fill ~28 ~2 ~30 ~39 ~2 ~30 minecraft:polished_diorite
fill ~40 ~2 ~30 ~45 ~2 ~30 minecraft:smooth_quartz
fill ~22 ~2 ~31 ~27 ~2 ~31 minecraft:smooth_quartz
fill ~28 ~2 ~31 ~39 ~2 ~31 minecraft:polished_diorite
fill ~40 ~2 ~31 ~45 ~2 ~31 minecraft:smooth_quartz
setblock ~4 ~2 ~32 minecraft:spruce_leaves[persistent=true]
fill ~22 ~2 ~32 ~27 ~2 ~32 minecraft:smooth_quartz
fill ~28 ~2 ~32 ~32 ~2 ~32 minecraft:polished_diorite
fill ~33 ~2 ~32 ~35 ~2 ~32 minecraft:chiseled_quartz_block
fill ~36 ~2 ~32 ~39 ~2 ~32 minecraft:polished_diorite
fill ~40 ~2 ~32 ~45 ~2 ~32 minecraft:smooth_quartz
fill ~3 ~2 ~33 ~5 ~2 ~33 minecraft:spruce_leaves[persistent=true]
fill ~22 ~2 ~33 ~27 ~2 ~33 minecraft:smooth_quartz
fill ~28 ~2 ~33 ~32 ~2 ~33 minecraft:polished_diorite
setblock ~33 ~2 ~33 minecraft:chiseled_quartz_block
setblock ~35 ~2 ~33 minecraft:chiseled_quartz_block
fill ~36 ~2 ~33 ~39 ~2 ~33 minecraft:polished_diorite
fill ~40 ~2 ~33 ~45 ~2 ~33 minecraft:smooth_quartz
setblock ~4 ~2 ~34 minecraft:spruce_leaves[persistent=true]
fill ~22 ~2 ~34 ~27 ~2 ~34 minecraft:smooth_quartz
fill ~28 ~2 ~34 ~32 ~2 ~34 minecraft:polished_diorite
fill ~33 ~2 ~34 ~35 ~2 ~34 minecraft:chiseled_quartz_block
fill ~36 ~2 ~34 ~39 ~2 ~34 minecraft:polished_diorite
fill ~40 ~2 ~34 ~45 ~2 ~34 minecraft:smooth_quartz
fill ~22 ~2 ~35 ~27 ~2 ~35 minecraft:smooth_quartz
fill ~28 ~2 ~35 ~32 ~2 ~35 minecraft:polished_diorite
setblock ~33 ~2 ~35 minecraft:chiseled_quartz_block
setblock ~35 ~2 ~35 minecraft:chiseled_quartz_block
fill ~36 ~2 ~35 ~39 ~2 ~35 minecraft:polished_diorite
fill ~40 ~2 ~35 ~45 ~2 ~35 minecraft:smooth_quartz
setblock ~64 ~2 ~35 minecraft:spruce_leaves[persistent=true]
fill ~22 ~2 ~36 ~27 ~2 ~36 minecraft:smooth_quartz
fill ~28 ~2 ~36 ~32 ~2 ~36 minecraft:polished_diorite
fill ~33 ~2 ~36 ~35 ~2 ~36 minecraft:chiseled_quartz_block
fill ~36 ~2 ~36 ~39 ~2 ~36 minecraft:polished_diorite
fill ~40 ~2 ~36 ~45 ~2 ~36 minecraft:smooth_quartz
fill ~63 ~2 ~36 ~65 ~2 ~36 minecraft:spruce_leaves[persistent=true]
fill ~22 ~2 ~37 ~27 ~2 ~37 minecraft:smooth_quartz
fill ~28 ~2 ~37 ~39 ~2 ~37 minecraft:polished_diorite
fill ~40 ~2 ~37 ~45 ~2 ~37 minecraft:smooth_quartz
setblock ~64 ~2 ~37 minecraft:spruce_leaves[persistent=true]
fill ~22 ~2 ~38 ~27 ~2 ~38 minecraft:smooth_quartz
fill ~28 ~2 ~38 ~39 ~2 ~38 minecraft:polished_diorite
fill ~40 ~2 ~38 ~45 ~2 ~38 minecraft:smooth_quartz
fill ~22 ~2 ~39 ~27 ~2 ~39 minecraft:smooth_quartz
fill ~28 ~2 ~39 ~39 ~2 ~39 minecraft:polished_diorite
fill ~40 ~2 ~39 ~45 ~2 ~39 minecraft:smooth_quartz
fill ~22 ~2 ~40 ~27 ~2 ~40 minecraft:smooth_quartz
fill ~28 ~2 ~40 ~39 ~2 ~40 minecraft:polished_diorite
fill ~40 ~2 ~40 ~45 ~2 ~40 minecraft:smooth_quartz
fill ~22 ~2 ~41 ~27 ~2 ~41 minecraft:smooth_quartz
fill ~28 ~2 ~41 ~39 ~2 ~41 minecraft:polished_diorite
fill ~40 ~2 ~41 ~45 ~2 ~41 minecraft:smooth_quartz
fill ~22 ~2 ~42 ~27 ~2 ~42 minecraft:smooth_quartz
fill ~28 ~2 ~42 ~39 ~2 ~42 minecraft:polished_diorite
fill ~40 ~2 ~42 ~45 ~2 ~42 minecraft:smooth_quartz
fill ~22 ~2 ~43 ~27 ~2 ~43 minecraft:smooth_quartz
fill ~28 ~2 ~43 ~39 ~2 ~43 minecraft:polished_diorite
fill ~40 ~2 ~43 ~45 ~2 ~43 minecraft:smooth_quartz
fill ~22 ~2 ~44 ~27 ~2 ~44 minecraft:smooth_quartz
fill ~28 ~2 ~44 ~39 ~2 ~44 minecraft:polished_diorite
fill ~40 ~2 ~44 ~45 ~2 ~44 minecraft:smooth_quartz
fill ~22 ~2 ~45 ~27 ~2 ~45 minecraft:smooth_quartz
fill ~28 ~2 ~45 ~39 ~2 ~45 minecraft:polished_diorite
fill ~40 ~2 ~45 ~45 ~2 ~45 minecraft:smooth_quartz
fill ~22 ~2 ~46 ~45 ~2 ~46 minecraft:smooth_quartz
fill ~22 ~2 ~47 ~45 ~2 ~47 minecraft:smooth_quartz
setblock ~6 ~2 ~48 minecraft:oak_log
fill ~22 ~2 ~48 ~45 ~2 ~48 minecraft:smooth_quartz
fill ~22 ~2 ~49 ~45 ~2 ~49 minecraft:smooth_quartz
fill ~22 ~2 ~50 ~45 ~2 ~50 minecraft:smooth_quartz
fill ~22 ~2 ~51 ~45 ~2 ~51 minecraft:smooth_quartz
fill ~22 ~2 ~52 ~45 ~2 ~52 minecraft:smooth_quartz
setblock ~60 ~2 ~52 minecraft:oak_log
fill ~22 ~2 ~53 ~45 ~2 ~53 minecraft:smooth_quartz
setblock ~4 ~2 ~61 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~2 ~61 minecraft:spruce_leaves[persistent=true]
fill ~3 ~2 ~62 ~5 ~2 ~62 minecraft:spruce_leaves[persistent=true]
fill ~61 ~2 ~62 ~63 ~2 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~4 ~2 ~63 minecraft:spruce_leaves[persistent=true]
fill ~27 ~2 ~63 ~41 ~2 ~63 minecraft:polished_deepslate
setblock ~62 ~2 ~63 minecraft:spruce_leaves[persistent=true]
fill ~27 ~2 ~64 ~41 ~2 ~64 minecraft:polished_deepslate
fill ~27 ~2 ~65 ~41 ~2 ~65 minecraft:polished_deepslate
fill ~27 ~2 ~66 ~41 ~2 ~66 minecraft:polished_deepslate
fill ~27 ~2 ~67 ~41 ~2 ~67 minecraft:polished_deepslate
setblock ~43 ~2 ~67 minecraft:oak_fence
fill ~27 ~2 ~68 ~33 ~2 ~68 minecraft:polished_deepslate
setblock ~34 ~2 ~68 minecraft:sea_lantern
fill ~35 ~2 ~68 ~41 ~2 ~68 minecraft:polished_deepslate
fill ~27 ~2 ~69 ~41 ~2 ~69 minecraft:polished_deepslate
setblock ~9 ~2 ~72 minecraft:oak_log
setblock ~57 ~2 ~72 minecraft:oak_log
setblock ~6 ~2 ~84 minecraft:oak_log
setblock ~58 ~2 ~86 minecraft:oak_log
setblock ~5 ~3 ~5 minecraft:spruce_leaves[persistent=true]
fill ~4 ~3 ~6 ~6 ~3 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~5 ~3 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~3 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~3 ~7 minecraft:spruce_leaves[persistent=true]
fill ~12 ~3 ~8 ~14 ~3 ~8 minecraft:spruce_leaves[persistent=true]
fill ~53 ~3 ~8 ~55 ~3 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~3 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~3 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~3 ~9 minecraft:spruce_leaves[persistent=true]
fill ~62 ~3 ~10 ~64 ~3 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~3 ~11 minecraft:spruce_leaves[persistent=true]
fill ~6 ~3 ~16 ~8 ~3 ~16 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~3 ~16 minecraft:chiseled_quartz_block
setblock ~26 ~3 ~16 minecraft:chiseled_quartz_block
setblock ~29 ~3 ~16 minecraft:chiseled_quartz_block
setblock ~32 ~3 ~16 minecraft:chiseled_quartz_block
setblock ~35 ~3 ~16 minecraft:chiseled_quartz_block
setblock ~38 ~3 ~16 minecraft:chiseled_quartz_block
setblock ~41 ~3 ~16 minecraft:chiseled_quartz_block
setblock ~44 ~3 ~16 minecraft:chiseled_quartz_block
fill ~5 ~3 ~17 ~9 ~3 ~17 minecraft:azalea_leaves[persistent=true]
fill ~5 ~3 ~18 ~6 ~3 ~18 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~3 ~18 minecraft:oak_log
fill ~8 ~3 ~18 ~9 ~3 ~18 minecraft:azalea_leaves[persistent=true]
fill ~5 ~3 ~19 ~9 ~3 ~19 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~3 ~19 minecraft:chiseled_quartz_block
setblock ~44 ~3 ~19 minecraft:chiseled_quartz_block
fill ~6 ~3 ~20 ~8 ~3 ~20 minecraft:azalea_leaves[persistent=true]
fill ~60 ~3 ~20 ~62 ~3 ~20 minecraft:azalea_leaves[persistent=true]
fill ~59 ~3 ~21 ~63 ~3 ~21 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~3 ~22 minecraft:chiseled_quartz_block
fill ~27 ~3 ~22 ~40 ~3 ~22 minecraft:quartz_bricks
setblock ~44 ~3 ~22 minecraft:chiseled_quartz_block
fill ~59 ~3 ~22 ~60 ~3 ~22 minecraft:azalea_leaves[persistent=true]
setblock ~61 ~3 ~22 minecraft:oak_log
fill ~62 ~3 ~22 ~63 ~3 ~22 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~3 ~23 minecraft:quartz_bricks
setblock ~40 ~3 ~23 minecraft:quartz_bricks
fill ~59 ~3 ~23 ~63 ~3 ~23 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~3 ~24 minecraft:quartz_bricks
setblock ~40 ~3 ~24 minecraft:quartz_bricks
fill ~60 ~3 ~24 ~62 ~3 ~24 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~3 ~25 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~25 minecraft:quartz_bricks
setblock ~30 ~3 ~25 minecraft:quartz_pillar
setblock ~37 ~3 ~25 minecraft:quartz_pillar
setblock ~40 ~3 ~25 minecraft:quartz_bricks
setblock ~44 ~3 ~25 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~26 minecraft:quartz_bricks
fill ~33 ~3 ~26 ~34 ~3 ~26 minecraft:gold_block
setblock ~40 ~3 ~26 minecraft:quartz_bricks
setblock ~27 ~3 ~27 minecraft:quartz_bricks
setblock ~40 ~3 ~27 minecraft:quartz_bricks
setblock ~23 ~3 ~28 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~28 minecraft:quartz_bricks
setblock ~30 ~3 ~28 minecraft:quartz_pillar
setblock ~37 ~3 ~28 minecraft:quartz_pillar
setblock ~40 ~3 ~28 minecraft:quartz_bricks
setblock ~44 ~3 ~28 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~29 minecraft:quartz_bricks
setblock ~40 ~3 ~29 minecraft:quartz_bricks
setblock ~27 ~3 ~30 minecraft:quartz_bricks
setblock ~40 ~3 ~30 minecraft:quartz_bricks
setblock ~23 ~3 ~31 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~31 minecraft:quartz_bricks
setblock ~30 ~3 ~31 minecraft:quartz_pillar
setblock ~37 ~3 ~31 minecraft:quartz_pillar
setblock ~40 ~3 ~31 minecraft:quartz_bricks
setblock ~44 ~3 ~31 minecraft:chiseled_quartz_block
setblock ~4 ~3 ~32 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~3 ~32 minecraft:quartz_bricks
setblock ~40 ~3 ~32 minecraft:quartz_bricks
fill ~3 ~3 ~33 ~5 ~3 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~3 ~33 minecraft:quartz_bricks
setblock ~40 ~3 ~33 minecraft:quartz_bricks
setblock ~4 ~3 ~34 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~3 ~34 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~34 minecraft:quartz_bricks
setblock ~30 ~3 ~34 minecraft:quartz_pillar
setblock ~37 ~3 ~34 minecraft:quartz_pillar
setblock ~40 ~3 ~34 minecraft:quartz_bricks
setblock ~44 ~3 ~34 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~35 minecraft:quartz_bricks
setblock ~40 ~3 ~35 minecraft:quartz_bricks
setblock ~64 ~3 ~35 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~3 ~36 minecraft:quartz_bricks
setblock ~40 ~3 ~36 minecraft:quartz_bricks
fill ~63 ~3 ~36 ~65 ~3 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~3 ~37 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~37 minecraft:quartz_bricks
setblock ~30 ~3 ~37 minecraft:quartz_pillar
setblock ~37 ~3 ~37 minecraft:quartz_pillar
setblock ~40 ~3 ~37 minecraft:quartz_bricks
setblock ~44 ~3 ~37 minecraft:chiseled_quartz_block
setblock ~64 ~3 ~37 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~3 ~38 minecraft:quartz_bricks
setblock ~40 ~3 ~38 minecraft:quartz_bricks
setblock ~27 ~3 ~39 minecraft:quartz_bricks
setblock ~40 ~3 ~39 minecraft:quartz_bricks
setblock ~23 ~3 ~40 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~40 minecraft:quartz_bricks
setblock ~30 ~3 ~40 minecraft:quartz_pillar
setblock ~37 ~3 ~40 minecraft:quartz_pillar
setblock ~40 ~3 ~40 minecraft:quartz_bricks
setblock ~44 ~3 ~40 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~41 minecraft:quartz_bricks
setblock ~40 ~3 ~41 minecraft:quartz_bricks
setblock ~27 ~3 ~42 minecraft:quartz_bricks
setblock ~40 ~3 ~42 minecraft:quartz_bricks
setblock ~23 ~3 ~43 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~43 minecraft:quartz_bricks
setblock ~30 ~3 ~43 minecraft:quartz_pillar
setblock ~37 ~3 ~43 minecraft:quartz_pillar
setblock ~40 ~3 ~43 minecraft:quartz_bricks
setblock ~44 ~3 ~43 minecraft:chiseled_quartz_block
setblock ~27 ~3 ~44 minecraft:quartz_bricks
setblock ~40 ~3 ~44 minecraft:quartz_bricks
setblock ~27 ~3 ~45 minecraft:quartz_bricks
setblock ~40 ~3 ~45 minecraft:quartz_bricks
fill ~6 ~3 ~46 ~8 ~3 ~46 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~3 ~46 minecraft:chiseled_quartz_block
fill ~27 ~3 ~46 ~31 ~3 ~46 minecraft:quartz_bricks
fill ~36 ~3 ~46 ~40 ~3 ~46 minecraft:quartz_bricks
setblock ~44 ~3 ~46 minecraft:chiseled_quartz_block
fill ~5 ~3 ~47 ~9 ~3 ~47 minecraft:azalea_leaves[persistent=true]
fill ~5 ~3 ~48 ~6 ~3 ~48 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~3 ~48 minecraft:oak_log
fill ~8 ~3 ~48 ~9 ~3 ~48 minecraft:azalea_leaves[persistent=true]
fill ~5 ~3 ~49 ~9 ~3 ~49 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~3 ~49 minecraft:chiseled_quartz_block
setblock ~44 ~3 ~49 minecraft:chiseled_quartz_block
fill ~6 ~3 ~50 ~8 ~3 ~50 minecraft:azalea_leaves[persistent=true]
fill ~60 ~3 ~50 ~62 ~3 ~50 minecraft:azalea_leaves[persistent=true]
fill ~59 ~3 ~51 ~63 ~3 ~51 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~3 ~52 minecraft:chiseled_quartz_block
setblock ~26 ~3 ~52 minecraft:chiseled_quartz_block
setblock ~29 ~3 ~52 minecraft:chiseled_quartz_block
setblock ~32 ~3 ~52 minecraft:chiseled_quartz_block
setblock ~35 ~3 ~52 minecraft:chiseled_quartz_block
setblock ~38 ~3 ~52 minecraft:chiseled_quartz_block
setblock ~41 ~3 ~52 minecraft:chiseled_quartz_block
setblock ~44 ~3 ~52 minecraft:chiseled_quartz_block
fill ~59 ~3 ~52 ~60 ~3 ~52 minecraft:azalea_leaves[persistent=true]
setblock ~61 ~3 ~52 minecraft:oak_log
fill ~62 ~3 ~52 ~63 ~3 ~52 minecraft:azalea_leaves[persistent=true]
fill ~59 ~3 ~53 ~63 ~3 ~53 minecraft:azalea_leaves[persistent=true]
fill ~60 ~3 ~54 ~62 ~3 ~54 minecraft:azalea_leaves[persistent=true]
setblock ~4 ~3 ~61 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~3 ~61 minecraft:spruce_leaves[persistent=true]
fill ~3 ~3 ~62 ~5 ~3 ~62 minecraft:spruce_leaves[persistent=true]
fill ~61 ~3 ~62 ~63 ~3 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~4 ~3 ~63 minecraft:spruce_leaves[persistent=true]
fill ~27 ~3 ~63 ~41 ~3 ~63 minecraft:polished_deepslate
setblock ~62 ~3 ~63 minecraft:spruce_leaves[persistent=true]
fill ~27 ~3 ~64 ~41 ~3 ~64 minecraft:polished_deepslate
fill ~27 ~3 ~65 ~41 ~3 ~65 minecraft:polished_deepslate
fill ~27 ~3 ~66 ~41 ~3 ~66 minecraft:polished_deepslate
fill ~27 ~3 ~67 ~41 ~3 ~67 minecraft:polished_deepslate
setblock ~43 ~3 ~67 minecraft:oak_fence
fill ~27 ~3 ~68 ~41 ~3 ~68 minecraft:polished_deepslate
fill ~27 ~3 ~69 ~41 ~3 ~69 minecraft:polished_deepslate
fill ~9 ~3 ~70 ~11 ~3 ~70 minecraft:azalea_leaves[persistent=true]
fill ~57 ~3 ~70 ~59 ~3 ~70 minecraft:azalea_leaves[persistent=true]
fill ~8 ~3 ~71 ~12 ~3 ~71 minecraft:azalea_leaves[persistent=true]
fill ~56 ~3 ~71 ~60 ~3 ~71 minecraft:azalea_leaves[persistent=true]
fill ~8 ~3 ~72 ~9 ~3 ~72 minecraft:azalea_leaves[persistent=true]
setblock ~10 ~3 ~72 minecraft:oak_log
fill ~11 ~3 ~72 ~12 ~3 ~72 minecraft:azalea_leaves[persistent=true]
fill ~56 ~3 ~72 ~57 ~3 ~72 minecraft:azalea_leaves[persistent=true]
setblock ~58 ~3 ~72 minecraft:oak_log
fill ~59 ~3 ~72 ~60 ~3 ~72 minecraft:azalea_leaves[persistent=true]
fill ~8 ~3 ~73 ~12 ~3 ~73 minecraft:azalea_leaves[persistent=true]
fill ~56 ~3 ~73 ~60 ~3 ~73 minecraft:azalea_leaves[persistent=true]
fill ~9 ~3 ~74 ~11 ~3 ~74 minecraft:azalea_leaves[persistent=true]
fill ~57 ~3 ~74 ~59 ~3 ~74 minecraft:azalea_leaves[persistent=true]
fill ~6 ~3 ~82 ~8 ~3 ~82 minecraft:azalea_leaves[persistent=true]
fill ~5 ~3 ~83 ~9 ~3 ~83 minecraft:azalea_leaves[persistent=true]
fill ~5 ~3 ~84 ~6 ~3 ~84 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~3 ~84 minecraft:oak_log
fill ~8 ~3 ~84 ~9 ~3 ~84 minecraft:azalea_leaves[persistent=true]
fill ~58 ~3 ~84 ~60 ~3 ~84 minecraft:azalea_leaves[persistent=true]
fill ~5 ~3 ~85 ~9 ~3 ~85 minecraft:azalea_leaves[persistent=true]
fill ~57 ~3 ~85 ~61 ~3 ~85 minecraft:azalea_leaves[persistent=true]
fill ~6 ~3 ~86 ~8 ~3 ~86 minecraft:azalea_leaves[persistent=true]
fill ~57 ~3 ~86 ~58 ~3 ~86 minecraft:azalea_leaves[persistent=true]
setblock ~59 ~3 ~86 minecraft:oak_log
fill ~60 ~3 ~86 ~61 ~3 ~86 minecraft:azalea_leaves[persistent=true]
fill ~57 ~3 ~87 ~61 ~3 ~87 minecraft:azalea_leaves[persistent=true]
fill ~58 ~3 ~88 ~60 ~3 ~88 minecraft:azalea_leaves[persistent=true]
setblock ~5 ~4 ~5 minecraft:spruce_leaves[persistent=true]
fill ~4 ~4 ~6 ~6 ~4 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~5 ~4 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~4 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~4 ~7 minecraft:spruce_leaves[persistent=true]
fill ~12 ~4 ~8 ~14 ~4 ~8 minecraft:spruce_leaves[persistent=true]
fill ~53 ~4 ~8 ~55 ~4 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~4 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~4 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~4 ~9 minecraft:spruce_leaves[persistent=true]
fill ~62 ~4 ~10 ~64 ~4 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~4 ~11 minecraft:spruce_leaves[persistent=true]
fill ~6 ~4 ~16 ~8 ~4 ~16 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~4 ~16 minecraft:quartz_pillar
setblock ~26 ~4 ~16 minecraft:quartz_pillar
setblock ~29 ~4 ~16 minecraft:quartz_pillar
setblock ~32 ~4 ~16 minecraft:quartz_pillar
setblock ~35 ~4 ~16 minecraft:quartz_pillar
setblock ~38 ~4 ~16 minecraft:quartz_pillar
setblock ~41 ~4 ~16 minecraft:quartz_pillar
setblock ~44 ~4 ~16 minecraft:quartz_pillar
fill ~5 ~4 ~17 ~9 ~4 ~17 minecraft:azalea_leaves[persistent=true]
fill ~5 ~4 ~18 ~6 ~4 ~18 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~4 ~18 minecraft:oak_log
fill ~8 ~4 ~18 ~9 ~4 ~18 minecraft:azalea_leaves[persistent=true]
fill ~5 ~4 ~19 ~9 ~4 ~19 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~4 ~19 minecraft:quartz_pillar
setblock ~44 ~4 ~19 minecraft:quartz_pillar
fill ~6 ~4 ~20 ~8 ~4 ~20 minecraft:azalea_leaves[persistent=true]
fill ~60 ~4 ~20 ~62 ~4 ~20 minecraft:azalea_leaves[persistent=true]
fill ~59 ~4 ~21 ~63 ~4 ~21 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~4 ~22 minecraft:quartz_pillar
fill ~27 ~4 ~22 ~40 ~4 ~22 minecraft:quartz_bricks
setblock ~44 ~4 ~22 minecraft:quartz_pillar
fill ~59 ~4 ~22 ~60 ~4 ~22 minecraft:azalea_leaves[persistent=true]
setblock ~61 ~4 ~22 minecraft:oak_log
fill ~62 ~4 ~22 ~63 ~4 ~22 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~4 ~23 minecraft:quartz_bricks
setblock ~40 ~4 ~23 minecraft:quartz_bricks
fill ~59 ~4 ~23 ~63 ~4 ~23 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~4 ~24 minecraft:quartz_bricks
setblock ~40 ~4 ~24 minecraft:quartz_bricks
fill ~60 ~4 ~24 ~62 ~4 ~24 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~4 ~25 minecraft:quartz_pillar
setblock ~27 ~4 ~25 minecraft:quartz_bricks
setblock ~30 ~4 ~25 minecraft:quartz_pillar
setblock ~37 ~4 ~25 minecraft:quartz_pillar
setblock ~40 ~4 ~25 minecraft:quartz_bricks
setblock ~44 ~4 ~25 minecraft:quartz_pillar
setblock ~27 ~4 ~26 minecraft:quartz_bricks
fill ~33 ~4 ~26 ~34 ~4 ~26 minecraft:campfire[lit=true]
setblock ~40 ~4 ~26 minecraft:quartz_bricks
setblock ~27 ~4 ~27 minecraft:quartz_bricks
setblock ~40 ~4 ~27 minecraft:quartz_bricks
setblock ~23 ~4 ~28 minecraft:quartz_pillar
setblock ~27 ~4 ~28 minecraft:quartz_bricks
setblock ~30 ~4 ~28 minecraft:quartz_pillar
setblock ~37 ~4 ~28 minecraft:quartz_pillar
setblock ~40 ~4 ~28 minecraft:quartz_bricks
setblock ~44 ~4 ~28 minecraft:quartz_pillar
setblock ~27 ~4 ~29 minecraft:quartz_bricks
setblock ~40 ~4 ~29 minecraft:quartz_bricks
setblock ~27 ~4 ~30 minecraft:quartz_bricks
setblock ~40 ~4 ~30 minecraft:quartz_bricks
setblock ~23 ~4 ~31 minecraft:quartz_pillar
setblock ~27 ~4 ~31 minecraft:quartz_bricks
setblock ~30 ~4 ~31 minecraft:quartz_pillar
setblock ~37 ~4 ~31 minecraft:quartz_pillar
setblock ~40 ~4 ~31 minecraft:quartz_bricks
setblock ~44 ~4 ~31 minecraft:quartz_pillar
setblock ~4 ~4 ~32 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~4 ~32 minecraft:quartz_bricks
setblock ~40 ~4 ~32 minecraft:quartz_bricks
fill ~3 ~4 ~33 ~5 ~4 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~4 ~33 minecraft:quartz_bricks
setblock ~40 ~4 ~33 minecraft:quartz_bricks
setblock ~4 ~4 ~34 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~4 ~34 minecraft:quartz_pillar
setblock ~27 ~4 ~34 minecraft:quartz_bricks
setblock ~30 ~4 ~34 minecraft:quartz_pillar
setblock ~37 ~4 ~34 minecraft:quartz_pillar
setblock ~40 ~4 ~34 minecraft:quartz_bricks
setblock ~44 ~4 ~34 minecraft:quartz_pillar
setblock ~27 ~4 ~35 minecraft:quartz_bricks
setblock ~40 ~4 ~35 minecraft:quartz_bricks
setblock ~64 ~4 ~35 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~4 ~36 minecraft:quartz_bricks
setblock ~40 ~4 ~36 minecraft:quartz_bricks
fill ~63 ~4 ~36 ~65 ~4 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~4 ~37 minecraft:quartz_pillar
setblock ~27 ~4 ~37 minecraft:quartz_bricks
setblock ~30 ~4 ~37 minecraft:quartz_pillar
setblock ~37 ~4 ~37 minecraft:quartz_pillar
setblock ~40 ~4 ~37 minecraft:quartz_bricks
setblock ~44 ~4 ~37 minecraft:quartz_pillar
setblock ~64 ~4 ~37 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~4 ~38 minecraft:quartz_bricks
setblock ~40 ~4 ~38 minecraft:quartz_bricks
setblock ~27 ~4 ~39 minecraft:quartz_bricks
setblock ~40 ~4 ~39 minecraft:quartz_bricks
setblock ~23 ~4 ~40 minecraft:quartz_pillar
setblock ~27 ~4 ~40 minecraft:quartz_bricks
setblock ~30 ~4 ~40 minecraft:quartz_pillar
setblock ~37 ~4 ~40 minecraft:quartz_pillar
setblock ~40 ~4 ~40 minecraft:quartz_bricks
setblock ~44 ~4 ~40 minecraft:quartz_pillar
setblock ~27 ~4 ~41 minecraft:quartz_bricks
setblock ~40 ~4 ~41 minecraft:quartz_bricks
setblock ~27 ~4 ~42 minecraft:quartz_bricks
setblock ~40 ~4 ~42 minecraft:quartz_bricks
setblock ~23 ~4 ~43 minecraft:quartz_pillar
setblock ~27 ~4 ~43 minecraft:quartz_bricks
setblock ~30 ~4 ~43 minecraft:quartz_pillar
setblock ~37 ~4 ~43 minecraft:quartz_pillar
setblock ~40 ~4 ~43 minecraft:quartz_bricks
setblock ~44 ~4 ~43 minecraft:quartz_pillar
setblock ~27 ~4 ~44 minecraft:quartz_bricks
setblock ~40 ~4 ~44 minecraft:quartz_bricks
setblock ~27 ~4 ~45 minecraft:quartz_bricks
setblock ~40 ~4 ~45 minecraft:quartz_bricks
fill ~6 ~4 ~46 ~8 ~4 ~46 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~4 ~46 minecraft:quartz_pillar
fill ~27 ~4 ~46 ~31 ~4 ~46 minecraft:quartz_bricks
fill ~36 ~4 ~46 ~40 ~4 ~46 minecraft:quartz_bricks
setblock ~44 ~4 ~46 minecraft:quartz_pillar
fill ~5 ~4 ~47 ~9 ~4 ~47 minecraft:azalea_leaves[persistent=true]
fill ~5 ~4 ~48 ~6 ~4 ~48 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~4 ~48 minecraft:oak_log
fill ~8 ~4 ~48 ~9 ~4 ~48 minecraft:azalea_leaves[persistent=true]
fill ~5 ~4 ~49 ~9 ~4 ~49 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~4 ~49 minecraft:quartz_pillar
setblock ~44 ~4 ~49 minecraft:quartz_pillar
fill ~6 ~4 ~50 ~8 ~4 ~50 minecraft:azalea_leaves[persistent=true]
fill ~60 ~4 ~50 ~62 ~4 ~50 minecraft:azalea_leaves[persistent=true]
fill ~59 ~4 ~51 ~63 ~4 ~51 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~4 ~52 minecraft:quartz_pillar
setblock ~26 ~4 ~52 minecraft:quartz_pillar
setblock ~29 ~4 ~52 minecraft:quartz_pillar
setblock ~32 ~4 ~52 minecraft:quartz_pillar
setblock ~35 ~4 ~52 minecraft:quartz_pillar
setblock ~38 ~4 ~52 minecraft:quartz_pillar
setblock ~41 ~4 ~52 minecraft:quartz_pillar
setblock ~44 ~4 ~52 minecraft:quartz_pillar
fill ~59 ~4 ~52 ~60 ~4 ~52 minecraft:azalea_leaves[persistent=true]
setblock ~61 ~4 ~52 minecraft:oak_log
fill ~62 ~4 ~52 ~63 ~4 ~52 minecraft:azalea_leaves[persistent=true]
fill ~59 ~4 ~53 ~63 ~4 ~53 minecraft:azalea_leaves[persistent=true]
fill ~60 ~4 ~54 ~62 ~4 ~54 minecraft:azalea_leaves[persistent=true]
setblock ~4 ~4 ~61 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~4 ~61 minecraft:spruce_leaves[persistent=true]
fill ~3 ~4 ~62 ~5 ~4 ~62 minecraft:spruce_leaves[persistent=true]
fill ~61 ~4 ~62 ~63 ~4 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~4 ~4 ~63 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~4 ~63 minecraft:spruce_leaves[persistent=true]
setblock ~43 ~4 ~67 minecraft:oak_fence
fill ~30 ~4 ~68 ~31 ~4 ~68 minecraft:calcite
fill ~36 ~4 ~68 ~37 ~4 ~68 minecraft:calcite
fill ~30 ~4 ~69 ~31 ~4 ~69 minecraft:calcite
fill ~36 ~4 ~69 ~37 ~4 ~69 minecraft:calcite
fill ~9 ~4 ~70 ~11 ~4 ~70 minecraft:azalea_leaves[persistent=true]
fill ~57 ~4 ~70 ~59 ~4 ~70 minecraft:azalea_leaves[persistent=true]
fill ~8 ~4 ~71 ~12 ~4 ~71 minecraft:azalea_leaves[persistent=true]
fill ~56 ~4 ~71 ~60 ~4 ~71 minecraft:azalea_leaves[persistent=true]
fill ~8 ~4 ~72 ~9 ~4 ~72 minecraft:azalea_leaves[persistent=true]
setblock ~10 ~4 ~72 minecraft:oak_log
fill ~11 ~4 ~72 ~12 ~4 ~72 minecraft:azalea_leaves[persistent=true]
fill ~56 ~4 ~72 ~57 ~4 ~72 minecraft:azalea_leaves[persistent=true]
setblock ~58 ~4 ~72 minecraft:oak_log
fill ~59 ~4 ~72 ~60 ~4 ~72 minecraft:azalea_leaves[persistent=true]
fill ~8 ~4 ~73 ~12 ~4 ~73 minecraft:azalea_leaves[persistent=true]
fill ~56 ~4 ~73 ~60 ~4 ~73 minecraft:azalea_leaves[persistent=true]
fill ~9 ~4 ~74 ~11 ~4 ~74 minecraft:azalea_leaves[persistent=true]
fill ~57 ~4 ~74 ~59 ~4 ~74 minecraft:azalea_leaves[persistent=true]
fill ~6 ~4 ~82 ~8 ~4 ~82 minecraft:azalea_leaves[persistent=true]
fill ~5 ~4 ~83 ~9 ~4 ~83 minecraft:azalea_leaves[persistent=true]
fill ~5 ~4 ~84 ~6 ~4 ~84 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~4 ~84 minecraft:oak_log
fill ~8 ~4 ~84 ~9 ~4 ~84 minecraft:azalea_leaves[persistent=true]
fill ~58 ~4 ~84 ~60 ~4 ~84 minecraft:azalea_leaves[persistent=true]
fill ~5 ~4 ~85 ~9 ~4 ~85 minecraft:azalea_leaves[persistent=true]
fill ~57 ~4 ~85 ~61 ~4 ~85 minecraft:azalea_leaves[persistent=true]
fill ~6 ~4 ~86 ~8 ~4 ~86 minecraft:azalea_leaves[persistent=true]
fill ~57 ~4 ~86 ~58 ~4 ~86 minecraft:azalea_leaves[persistent=true]
setblock ~59 ~4 ~86 minecraft:oak_log
fill ~60 ~4 ~86 ~61 ~4 ~86 minecraft:azalea_leaves[persistent=true]
fill ~57 ~4 ~87 ~61 ~4 ~87 minecraft:azalea_leaves[persistent=true]
fill ~58 ~4 ~88 ~60 ~4 ~88 minecraft:azalea_leaves[persistent=true]
setblock ~5 ~5 ~5 minecraft:spruce_leaves[persistent=true]
fill ~4 ~5 ~6 ~6 ~5 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~5 ~5 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~5 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~5 ~7 minecraft:spruce_leaves[persistent=true]
fill ~12 ~5 ~8 ~14 ~5 ~8 minecraft:spruce_leaves[persistent=true]
fill ~53 ~5 ~8 ~55 ~5 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~5 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~5 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~5 ~9 minecraft:spruce_leaves[persistent=true]
fill ~62 ~5 ~10 ~64 ~5 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~5 ~11 minecraft:spruce_leaves[persistent=true]
fill ~6 ~5 ~16 ~8 ~5 ~16 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~5 ~16 minecraft:quartz_pillar
setblock ~26 ~5 ~16 minecraft:quartz_pillar
setblock ~29 ~5 ~16 minecraft:quartz_pillar
setblock ~32 ~5 ~16 minecraft:quartz_pillar
setblock ~35 ~5 ~16 minecraft:quartz_pillar
setblock ~38 ~5 ~16 minecraft:quartz_pillar
setblock ~41 ~5 ~16 minecraft:quartz_pillar
setblock ~44 ~5 ~16 minecraft:quartz_pillar
fill ~5 ~5 ~17 ~9 ~5 ~17 minecraft:azalea_leaves[persistent=true]
fill ~5 ~5 ~18 ~9 ~5 ~18 minecraft:azalea_leaves[persistent=true]
fill ~5 ~5 ~19 ~9 ~5 ~19 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~5 ~19 minecraft:quartz_pillar
setblock ~44 ~5 ~19 minecraft:quartz_pillar
fill ~6 ~5 ~20 ~8 ~5 ~20 minecraft:azalea_leaves[persistent=true]
fill ~60 ~5 ~20 ~62 ~5 ~20 minecraft:azalea_leaves[persistent=true]
fill ~59 ~5 ~21 ~63 ~5 ~21 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~5 ~22 minecraft:quartz_pillar
fill ~27 ~5 ~22 ~40 ~5 ~22 minecraft:quartz_bricks
setblock ~44 ~5 ~22 minecraft:quartz_pillar
fill ~59 ~5 ~22 ~63 ~5 ~22 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~5 ~23 minecraft:quartz_bricks
setblock ~40 ~5 ~23 minecraft:quartz_bricks
fill ~59 ~5 ~23 ~63 ~5 ~23 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~5 ~24 minecraft:quartz_bricks
setblock ~40 ~5 ~24 minecraft:quartz_bricks
fill ~60 ~5 ~24 ~62 ~5 ~24 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~5 ~25 minecraft:quartz_pillar
setblock ~27 ~5 ~25 minecraft:quartz_bricks
setblock ~30 ~5 ~25 minecraft:quartz_pillar
setblock ~37 ~5 ~25 minecraft:quartz_pillar
setblock ~40 ~5 ~25 minecraft:quartz_bricks
setblock ~44 ~5 ~25 minecraft:quartz_pillar
setblock ~27 ~5 ~26 minecraft:quartz_bricks
setblock ~40 ~5 ~26 minecraft:quartz_bricks
setblock ~27 ~5 ~27 minecraft:quartz_bricks
setblock ~40 ~5 ~27 minecraft:quartz_bricks
setblock ~23 ~5 ~28 minecraft:quartz_pillar
setblock ~27 ~5 ~28 minecraft:quartz_bricks
setblock ~30 ~5 ~28 minecraft:quartz_pillar
setblock ~37 ~5 ~28 minecraft:quartz_pillar
setblock ~40 ~5 ~28 minecraft:quartz_bricks
setblock ~44 ~5 ~28 minecraft:quartz_pillar
setblock ~27 ~5 ~29 minecraft:quartz_bricks
setblock ~40 ~5 ~29 minecraft:quartz_bricks
setblock ~27 ~5 ~30 minecraft:quartz_bricks
setblock ~40 ~5 ~30 minecraft:quartz_bricks
setblock ~23 ~5 ~31 minecraft:quartz_pillar
setblock ~27 ~5 ~31 minecraft:quartz_bricks
setblock ~30 ~5 ~31 minecraft:quartz_pillar
setblock ~37 ~5 ~31 minecraft:quartz_pillar
setblock ~40 ~5 ~31 minecraft:quartz_bricks
setblock ~44 ~5 ~31 minecraft:quartz_pillar
setblock ~4 ~5 ~32 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~5 ~32 minecraft:quartz_bricks
setblock ~40 ~5 ~32 minecraft:quartz_bricks
fill ~3 ~5 ~33 ~5 ~5 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~5 ~33 minecraft:quartz_bricks
setblock ~40 ~5 ~33 minecraft:quartz_bricks
setblock ~4 ~5 ~34 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~5 ~34 minecraft:quartz_pillar
setblock ~27 ~5 ~34 minecraft:quartz_bricks
setblock ~30 ~5 ~34 minecraft:quartz_pillar
setblock ~37 ~5 ~34 minecraft:quartz_pillar
setblock ~40 ~5 ~34 minecraft:quartz_bricks
setblock ~44 ~5 ~34 minecraft:quartz_pillar
setblock ~27 ~5 ~35 minecraft:quartz_bricks
setblock ~40 ~5 ~35 minecraft:quartz_bricks
setblock ~64 ~5 ~35 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~5 ~36 minecraft:quartz_bricks
setblock ~40 ~5 ~36 minecraft:quartz_bricks
fill ~63 ~5 ~36 ~65 ~5 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~5 ~37 minecraft:quartz_pillar
setblock ~27 ~5 ~37 minecraft:quartz_bricks
setblock ~30 ~5 ~37 minecraft:quartz_pillar
setblock ~37 ~5 ~37 minecraft:quartz_pillar
setblock ~40 ~5 ~37 minecraft:quartz_bricks
setblock ~44 ~5 ~37 minecraft:quartz_pillar
setblock ~64 ~5 ~37 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~5 ~38 minecraft:quartz_bricks
setblock ~40 ~5 ~38 minecraft:quartz_bricks
setblock ~27 ~5 ~39 minecraft:quartz_bricks
setblock ~40 ~5 ~39 minecraft:quartz_bricks
setblock ~23 ~5 ~40 minecraft:quartz_pillar
setblock ~27 ~5 ~40 minecraft:quartz_bricks
setblock ~30 ~5 ~40 minecraft:quartz_pillar
setblock ~37 ~5 ~40 minecraft:quartz_pillar
setblock ~40 ~5 ~40 minecraft:quartz_bricks
setblock ~44 ~5 ~40 minecraft:quartz_pillar
setblock ~27 ~5 ~41 minecraft:quartz_bricks
setblock ~40 ~5 ~41 minecraft:quartz_bricks
setblock ~27 ~5 ~42 minecraft:quartz_bricks
setblock ~40 ~5 ~42 minecraft:quartz_bricks
setblock ~23 ~5 ~43 minecraft:quartz_pillar
setblock ~27 ~5 ~43 minecraft:quartz_bricks
setblock ~30 ~5 ~43 minecraft:quartz_pillar
setblock ~37 ~5 ~43 minecraft:quartz_pillar
setblock ~40 ~5 ~43 minecraft:quartz_bricks
setblock ~44 ~5 ~43 minecraft:quartz_pillar
setblock ~27 ~5 ~44 minecraft:quartz_bricks
setblock ~40 ~5 ~44 minecraft:quartz_bricks
setblock ~27 ~5 ~45 minecraft:quartz_bricks
setblock ~40 ~5 ~45 minecraft:quartz_bricks
fill ~6 ~5 ~46 ~8 ~5 ~46 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~5 ~46 minecraft:quartz_pillar
fill ~27 ~5 ~46 ~31 ~5 ~46 minecraft:quartz_bricks
fill ~36 ~5 ~46 ~40 ~5 ~46 minecraft:quartz_bricks
setblock ~44 ~5 ~46 minecraft:quartz_pillar
fill ~5 ~5 ~47 ~9 ~5 ~47 minecraft:azalea_leaves[persistent=true]
fill ~5 ~5 ~48 ~9 ~5 ~48 minecraft:azalea_leaves[persistent=true]
fill ~5 ~5 ~49 ~9 ~5 ~49 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~5 ~49 minecraft:quartz_pillar
setblock ~44 ~5 ~49 minecraft:quartz_pillar
fill ~6 ~5 ~50 ~8 ~5 ~50 minecraft:azalea_leaves[persistent=true]
fill ~60 ~5 ~50 ~62 ~5 ~50 minecraft:azalea_leaves[persistent=true]
fill ~59 ~5 ~51 ~63 ~5 ~51 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~5 ~52 minecraft:quartz_pillar
setblock ~26 ~5 ~52 minecraft:quartz_pillar
setblock ~29 ~5 ~52 minecraft:quartz_pillar
setblock ~32 ~5 ~52 minecraft:quartz_pillar
setblock ~35 ~5 ~52 minecraft:quartz_pillar
setblock ~38 ~5 ~52 minecraft:quartz_pillar
setblock ~41 ~5 ~52 minecraft:quartz_pillar
setblock ~44 ~5 ~52 minecraft:quartz_pillar
fill ~59 ~5 ~52 ~63 ~5 ~52 minecraft:azalea_leaves[persistent=true]
fill ~59 ~5 ~53 ~63 ~5 ~53 minecraft:azalea_leaves[persistent=true]
fill ~60 ~5 ~54 ~62 ~5 ~54 minecraft:azalea_leaves[persistent=true]
setblock ~4 ~5 ~61 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~5 ~61 minecraft:spruce_leaves[persistent=true]
fill ~3 ~5 ~62 ~5 ~5 ~62 minecraft:spruce_leaves[persistent=true]
fill ~61 ~5 ~62 ~63 ~5 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~4 ~5 ~63 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~5 ~63 minecraft:spruce_leaves[persistent=true]
setblock ~29 ~5 ~64 minecraft:smooth_quartz
setblock ~30 ~5 ~64 minecraft:quartz_pillar
fill ~31 ~5 ~64 ~32 ~5 ~64 minecraft:smooth_quartz
setblock ~33 ~5 ~64 minecraft:quartz_pillar
setblock ~34 ~5 ~64 minecraft:smooth_quartz
setblock ~35 ~5 ~64 minecraft:quartz_pillar
fill ~36 ~5 ~64 ~37 ~5 ~64 minecraft:smooth_quartz
setblock ~38 ~5 ~64 minecraft:quartz_pillar
setblock ~39 ~5 ~64 minecraft:smooth_quartz
setblock ~29 ~5 ~65 minecraft:smooth_quartz
setblock ~30 ~5 ~65 minecraft:quartz_pillar
fill ~31 ~5 ~65 ~32 ~5 ~65 minecraft:smooth_quartz
setblock ~33 ~5 ~65 minecraft:quartz_pillar
setblock ~34 ~5 ~65 minecraft:smooth_quartz
setblock ~35 ~5 ~65 minecraft:quartz_pillar
fill ~36 ~5 ~65 ~37 ~5 ~65 minecraft:smooth_quartz
setblock ~38 ~5 ~65 minecraft:quartz_pillar
setblock ~39 ~5 ~65 minecraft:smooth_quartz
setblock ~29 ~5 ~66 minecraft:smooth_quartz
setblock ~30 ~5 ~66 minecraft:quartz_pillar
fill ~31 ~5 ~66 ~32 ~5 ~66 minecraft:smooth_quartz
setblock ~33 ~5 ~66 minecraft:quartz_pillar
setblock ~34 ~5 ~66 minecraft:smooth_quartz
setblock ~35 ~5 ~66 minecraft:quartz_pillar
fill ~36 ~5 ~66 ~37 ~5 ~66 minecraft:smooth_quartz
setblock ~38 ~5 ~66 minecraft:quartz_pillar
setblock ~39 ~5 ~66 minecraft:smooth_quartz
setblock ~29 ~5 ~67 minecraft:smooth_quartz
setblock ~30 ~5 ~67 minecraft:quartz_pillar
fill ~31 ~5 ~67 ~32 ~5 ~67 minecraft:smooth_quartz
setblock ~33 ~5 ~67 minecraft:quartz_pillar
setblock ~34 ~5 ~67 minecraft:smooth_quartz
setblock ~35 ~5 ~67 minecraft:quartz_pillar
fill ~36 ~5 ~67 ~37 ~5 ~67 minecraft:smooth_quartz
setblock ~38 ~5 ~67 minecraft:quartz_pillar
setblock ~39 ~5 ~67 minecraft:smooth_quartz
setblock ~43 ~5 ~67 minecraft:oak_fence
setblock ~29 ~5 ~68 minecraft:smooth_quartz
setblock ~30 ~5 ~68 minecraft:quartz_pillar
fill ~31 ~5 ~68 ~32 ~5 ~68 minecraft:smooth_quartz
setblock ~33 ~5 ~68 minecraft:quartz_pillar
setblock ~34 ~5 ~68 minecraft:smooth_quartz
setblock ~35 ~5 ~68 minecraft:quartz_pillar
fill ~36 ~5 ~68 ~37 ~5 ~68 minecraft:smooth_quartz
setblock ~38 ~5 ~68 minecraft:quartz_pillar
setblock ~39 ~5 ~68 minecraft:smooth_quartz
setblock ~29 ~5 ~69 minecraft:smooth_quartz
setblock ~30 ~5 ~69 minecraft:quartz_pillar
fill ~31 ~5 ~69 ~32 ~5 ~69 minecraft:smooth_quartz
setblock ~33 ~5 ~69 minecraft:quartz_pillar
setblock ~34 ~5 ~69 minecraft:smooth_quartz
setblock ~35 ~5 ~69 minecraft:quartz_pillar
fill ~36 ~5 ~69 ~37 ~5 ~69 minecraft:smooth_quartz
setblock ~38 ~5 ~69 minecraft:quartz_pillar
setblock ~39 ~5 ~69 minecraft:smooth_quartz
fill ~9 ~5 ~70 ~11 ~5 ~70 minecraft:azalea_leaves[persistent=true]
fill ~57 ~5 ~70 ~59 ~5 ~70 minecraft:azalea_leaves[persistent=true]
fill ~8 ~5 ~71 ~12 ~5 ~71 minecraft:azalea_leaves[persistent=true]
fill ~56 ~5 ~71 ~60 ~5 ~71 minecraft:azalea_leaves[persistent=true]
fill ~8 ~5 ~72 ~12 ~5 ~72 minecraft:azalea_leaves[persistent=true]
fill ~56 ~5 ~72 ~60 ~5 ~72 minecraft:azalea_leaves[persistent=true]
fill ~8 ~5 ~73 ~12 ~5 ~73 minecraft:azalea_leaves[persistent=true]
fill ~56 ~5 ~73 ~60 ~5 ~73 minecraft:azalea_leaves[persistent=true]
fill ~9 ~5 ~74 ~11 ~5 ~74 minecraft:azalea_leaves[persistent=true]
fill ~57 ~5 ~74 ~59 ~5 ~74 minecraft:azalea_leaves[persistent=true]
fill ~6 ~5 ~82 ~8 ~5 ~82 minecraft:azalea_leaves[persistent=true]
fill ~5 ~5 ~83 ~9 ~5 ~83 minecraft:azalea_leaves[persistent=true]
fill ~5 ~5 ~84 ~9 ~5 ~84 minecraft:azalea_leaves[persistent=true]
fill ~58 ~5 ~84 ~60 ~5 ~84 minecraft:azalea_leaves[persistent=true]
fill ~5 ~5 ~85 ~9 ~5 ~85 minecraft:azalea_leaves[persistent=true]
fill ~57 ~5 ~85 ~61 ~5 ~85 minecraft:azalea_leaves[persistent=true]
fill ~6 ~5 ~86 ~8 ~5 ~86 minecraft:azalea_leaves[persistent=true]
fill ~57 ~5 ~86 ~61 ~5 ~86 minecraft:azalea_leaves[persistent=true]
fill ~57 ~5 ~87 ~61 ~5 ~87 minecraft:azalea_leaves[persistent=true]
fill ~58 ~5 ~88 ~60 ~5 ~88 minecraft:azalea_leaves[persistent=true]
setblock ~5 ~6 ~5 minecraft:spruce_leaves[persistent=true]
fill ~4 ~6 ~6 ~6 ~6 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~5 ~6 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~6 ~7 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~6 ~7 minecraft:spruce_leaves[persistent=true]
fill ~12 ~6 ~8 ~14 ~6 ~8 minecraft:spruce_leaves[persistent=true]
fill ~53 ~6 ~8 ~55 ~6 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~6 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~6 ~9 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~6 ~9 minecraft:spruce_leaves[persistent=true]
fill ~62 ~6 ~10 ~64 ~6 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~6 ~11 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~6 ~16 minecraft:quartz_pillar
setblock ~26 ~6 ~16 minecraft:quartz_pillar
setblock ~29 ~6 ~16 minecraft:quartz_pillar
setblock ~32 ~6 ~16 minecraft:quartz_pillar
setblock ~35 ~6 ~16 minecraft:quartz_pillar
setblock ~38 ~6 ~16 minecraft:quartz_pillar
setblock ~41 ~6 ~16 minecraft:quartz_pillar
setblock ~44 ~6 ~16 minecraft:quartz_pillar
setblock ~7 ~6 ~17 minecraft:azalea_leaves[persistent=true]
fill ~6 ~6 ~18 ~8 ~6 ~18 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~6 ~19 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~6 ~19 minecraft:quartz_pillar
setblock ~44 ~6 ~19 minecraft:quartz_pillar
setblock ~61 ~6 ~21 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~6 ~22 minecraft:quartz_pillar
fill ~27 ~6 ~22 ~40 ~6 ~22 minecraft:quartz_bricks
setblock ~44 ~6 ~22 minecraft:quartz_pillar
fill ~60 ~6 ~22 ~62 ~6 ~22 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~6 ~23 minecraft:quartz_bricks
setblock ~40 ~6 ~23 minecraft:quartz_bricks
setblock ~61 ~6 ~23 minecraft:azalea_leaves[persistent=true]
setblock ~27 ~6 ~24 minecraft:quartz_bricks
setblock ~40 ~6 ~24 minecraft:quartz_bricks
setblock ~23 ~6 ~25 minecraft:quartz_pillar
setblock ~27 ~6 ~25 minecraft:quartz_bricks
setblock ~30 ~6 ~25 minecraft:quartz_pillar
setblock ~37 ~6 ~25 minecraft:quartz_pillar
setblock ~40 ~6 ~25 minecraft:quartz_bricks
setblock ~44 ~6 ~25 minecraft:quartz_pillar
setblock ~27 ~6 ~26 minecraft:quartz_bricks
setblock ~40 ~6 ~26 minecraft:quartz_bricks
setblock ~27 ~6 ~27 minecraft:quartz_bricks
setblock ~40 ~6 ~27 minecraft:quartz_bricks
setblock ~23 ~6 ~28 minecraft:quartz_pillar
setblock ~27 ~6 ~28 minecraft:quartz_bricks
setblock ~30 ~6 ~28 minecraft:quartz_pillar
setblock ~37 ~6 ~28 minecraft:quartz_pillar
setblock ~40 ~6 ~28 minecraft:quartz_bricks
setblock ~44 ~6 ~28 minecraft:quartz_pillar
setblock ~27 ~6 ~29 minecraft:quartz_bricks
setblock ~40 ~6 ~29 minecraft:quartz_bricks
setblock ~27 ~6 ~30 minecraft:quartz_bricks
setblock ~40 ~6 ~30 minecraft:quartz_bricks
setblock ~23 ~6 ~31 minecraft:quartz_pillar
setblock ~27 ~6 ~31 minecraft:quartz_bricks
setblock ~30 ~6 ~31 minecraft:quartz_pillar
setblock ~37 ~6 ~31 minecraft:quartz_pillar
setblock ~40 ~6 ~31 minecraft:quartz_bricks
setblock ~44 ~6 ~31 minecraft:quartz_pillar
setblock ~4 ~6 ~32 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~6 ~32 minecraft:quartz_bricks
setblock ~40 ~6 ~32 minecraft:quartz_bricks
fill ~3 ~6 ~33 ~5 ~6 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~6 ~33 minecraft:quartz_bricks
setblock ~40 ~6 ~33 minecraft:quartz_bricks
setblock ~4 ~6 ~34 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~6 ~34 minecraft:quartz_pillar
setblock ~27 ~6 ~34 minecraft:quartz_bricks
setblock ~30 ~6 ~34 minecraft:quartz_pillar
setblock ~37 ~6 ~34 minecraft:quartz_pillar
setblock ~40 ~6 ~34 minecraft:quartz_bricks
setblock ~44 ~6 ~34 minecraft:quartz_pillar
setblock ~27 ~6 ~35 minecraft:quartz_bricks
setblock ~40 ~6 ~35 minecraft:quartz_bricks
setblock ~64 ~6 ~35 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~6 ~36 minecraft:quartz_bricks
setblock ~40 ~6 ~36 minecraft:quartz_bricks
fill ~63 ~6 ~36 ~65 ~6 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~6 ~37 minecraft:quartz_pillar
setblock ~27 ~6 ~37 minecraft:quartz_bricks
setblock ~30 ~6 ~37 minecraft:quartz_pillar
setblock ~37 ~6 ~37 minecraft:quartz_pillar
setblock ~40 ~6 ~37 minecraft:quartz_bricks
setblock ~44 ~6 ~37 minecraft:quartz_pillar
setblock ~64 ~6 ~37 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~6 ~38 minecraft:quartz_bricks
setblock ~40 ~6 ~38 minecraft:quartz_bricks
setblock ~27 ~6 ~39 minecraft:quartz_bricks
setblock ~40 ~6 ~39 minecraft:quartz_bricks
setblock ~23 ~6 ~40 minecraft:quartz_pillar
setblock ~27 ~6 ~40 minecraft:quartz_bricks
setblock ~30 ~6 ~40 minecraft:quartz_pillar
setblock ~37 ~6 ~40 minecraft:quartz_pillar
setblock ~40 ~6 ~40 minecraft:quartz_bricks
setblock ~44 ~6 ~40 minecraft:quartz_pillar
setblock ~27 ~6 ~41 minecraft:quartz_bricks
setblock ~40 ~6 ~41 minecraft:quartz_bricks
setblock ~27 ~6 ~42 minecraft:quartz_bricks
setblock ~40 ~6 ~42 minecraft:quartz_bricks
setblock ~23 ~6 ~43 minecraft:quartz_pillar
setblock ~27 ~6 ~43 minecraft:quartz_bricks
setblock ~30 ~6 ~43 minecraft:quartz_pillar
setblock ~37 ~6 ~43 minecraft:quartz_pillar
setblock ~40 ~6 ~43 minecraft:quartz_bricks
setblock ~44 ~6 ~43 minecraft:quartz_pillar
setblock ~27 ~6 ~44 minecraft:quartz_bricks
setblock ~40 ~6 ~44 minecraft:quartz_bricks
setblock ~27 ~6 ~45 minecraft:quartz_bricks
setblock ~40 ~6 ~45 minecraft:quartz_bricks
setblock ~23 ~6 ~46 minecraft:quartz_pillar
fill ~27 ~6 ~46 ~31 ~6 ~46 minecraft:quartz_bricks
fill ~36 ~6 ~46 ~40 ~6 ~46 minecraft:quartz_bricks
setblock ~44 ~6 ~46 minecraft:quartz_pillar
setblock ~7 ~6 ~47 minecraft:azalea_leaves[persistent=true]
fill ~6 ~6 ~48 ~8 ~6 ~48 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~6 ~49 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~6 ~49 minecraft:quartz_pillar
setblock ~44 ~6 ~49 minecraft:quartz_pillar
setblock ~61 ~6 ~51 minecraft:azalea_leaves[persistent=true]
setblock ~23 ~6 ~52 minecraft:quartz_pillar
setblock ~26 ~6 ~52 minecraft:quartz_pillar
setblock ~29 ~6 ~52 minecraft:quartz_pillar
setblock ~32 ~6 ~52 minecraft:quartz_pillar
setblock ~35 ~6 ~52 minecraft:quartz_pillar
setblock ~38 ~6 ~52 minecraft:quartz_pillar
setblock ~41 ~6 ~52 minecraft:quartz_pillar
setblock ~44 ~6 ~52 minecraft:quartz_pillar
fill ~60 ~6 ~52 ~62 ~6 ~52 minecraft:azalea_leaves[persistent=true]
setblock ~61 ~6 ~53 minecraft:azalea_leaves[persistent=true]
setblock ~4 ~6 ~61 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~6 ~61 minecraft:spruce_leaves[persistent=true]
fill ~3 ~6 ~62 ~5 ~6 ~62 minecraft:spruce_leaves[persistent=true]
fill ~61 ~6 ~62 ~63 ~6 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~4 ~6 ~63 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~6 ~63 minecraft:spruce_leaves[persistent=true]
setblock ~29 ~6 ~64 minecraft:smooth_quartz
setblock ~30 ~6 ~64 minecraft:quartz_pillar
fill ~31 ~6 ~64 ~32 ~6 ~64 minecraft:smooth_quartz
setblock ~33 ~6 ~64 minecraft:quartz_pillar
setblock ~34 ~6 ~64 minecraft:smooth_quartz
setblock ~35 ~6 ~64 minecraft:quartz_pillar
fill ~36 ~6 ~64 ~37 ~6 ~64 minecraft:smooth_quartz
setblock ~38 ~6 ~64 minecraft:quartz_pillar
setblock ~39 ~6 ~64 minecraft:smooth_quartz
setblock ~29 ~6 ~65 minecraft:smooth_quartz
setblock ~30 ~6 ~65 minecraft:quartz_pillar
fill ~31 ~6 ~65 ~32 ~6 ~65 minecraft:smooth_quartz
setblock ~33 ~6 ~65 minecraft:quartz_pillar
setblock ~34 ~6 ~65 minecraft:smooth_quartz
setblock ~35 ~6 ~65 minecraft:quartz_pillar
fill ~36 ~6 ~65 ~37 ~6 ~65 minecraft:smooth_quartz
setblock ~38 ~6 ~65 minecraft:quartz_pillar
setblock ~39 ~6 ~65 minecraft:smooth_quartz
setblock ~29 ~6 ~66 minecraft:smooth_quartz
setblock ~30 ~6 ~66 minecraft:quartz_pillar
fill ~31 ~6 ~66 ~32 ~6 ~66 minecraft:smooth_quartz
setblock ~33 ~6 ~66 minecraft:quartz_pillar
setblock ~34 ~6 ~66 minecraft:smooth_quartz
setblock ~35 ~6 ~66 minecraft:quartz_pillar
fill ~36 ~6 ~66 ~37 ~6 ~66 minecraft:smooth_quartz
setblock ~38 ~6 ~66 minecraft:quartz_pillar
setblock ~39 ~6 ~66 minecraft:smooth_quartz
setblock ~29 ~6 ~67 minecraft:smooth_quartz
setblock ~30 ~6 ~67 minecraft:quartz_pillar
fill ~31 ~6 ~67 ~32 ~6 ~67 minecraft:smooth_quartz
setblock ~33 ~6 ~67 minecraft:quartz_pillar
setblock ~34 ~6 ~67 minecraft:smooth_quartz
setblock ~35 ~6 ~67 minecraft:quartz_pillar
fill ~36 ~6 ~67 ~37 ~6 ~67 minecraft:smooth_quartz
setblock ~38 ~6 ~67 minecraft:quartz_pillar
setblock ~39 ~6 ~67 minecraft:smooth_quartz
setblock ~43 ~6 ~67 minecraft:oak_fence
setblock ~29 ~6 ~68 minecraft:smooth_quartz
setblock ~30 ~6 ~68 minecraft:quartz_pillar
fill ~31 ~6 ~68 ~32 ~6 ~68 minecraft:smooth_quartz
setblock ~33 ~6 ~68 minecraft:quartz_pillar
setblock ~34 ~6 ~68 minecraft:smooth_quartz
setblock ~35 ~6 ~68 minecraft:quartz_pillar
fill ~36 ~6 ~68 ~37 ~6 ~68 minecraft:smooth_quartz
setblock ~38 ~6 ~68 minecraft:quartz_pillar
setblock ~39 ~6 ~68 minecraft:smooth_quartz
setblock ~29 ~6 ~69 minecraft:smooth_quartz
setblock ~30 ~6 ~69 minecraft:quartz_pillar
fill ~31 ~6 ~69 ~32 ~6 ~69 minecraft:smooth_quartz
setblock ~33 ~6 ~69 minecraft:quartz_pillar
setblock ~34 ~6 ~69 minecraft:smooth_quartz
setblock ~35 ~6 ~69 minecraft:quartz_pillar
fill ~36 ~6 ~69 ~37 ~6 ~69 minecraft:smooth_quartz
setblock ~38 ~6 ~69 minecraft:quartz_pillar
setblock ~39 ~6 ~69 minecraft:smooth_quartz
setblock ~10 ~6 ~71 minecraft:azalea_leaves[persistent=true]
setblock ~58 ~6 ~71 minecraft:azalea_leaves[persistent=true]
fill ~9 ~6 ~72 ~11 ~6 ~72 minecraft:azalea_leaves[persistent=true]
fill ~57 ~6 ~72 ~59 ~6 ~72 minecraft:azalea_leaves[persistent=true]
setblock ~10 ~6 ~73 minecraft:azalea_leaves[persistent=true]
setblock ~58 ~6 ~73 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~6 ~83 minecraft:azalea_leaves[persistent=true]
fill ~6 ~6 ~84 ~8 ~6 ~84 minecraft:azalea_leaves[persistent=true]
setblock ~7 ~6 ~85 minecraft:azalea_leaves[persistent=true]
setblock ~59 ~6 ~85 minecraft:azalea_leaves[persistent=true]
fill ~58 ~6 ~86 ~60 ~6 ~86 minecraft:azalea_leaves[persistent=true]
setblock ~59 ~6 ~87 minecraft:azalea_leaves[persistent=true]
setblock ~5 ~7 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~7 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~7 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~7 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~7 ~16 minecraft:quartz_pillar
setblock ~26 ~7 ~16 minecraft:quartz_pillar
setblock ~29 ~7 ~16 minecraft:quartz_pillar
setblock ~32 ~7 ~16 minecraft:quartz_pillar
setblock ~35 ~7 ~16 minecraft:quartz_pillar
setblock ~38 ~7 ~16 minecraft:quartz_pillar
setblock ~41 ~7 ~16 minecraft:quartz_pillar
setblock ~44 ~7 ~16 minecraft:quartz_pillar
setblock ~23 ~7 ~19 minecraft:quartz_pillar
setblock ~44 ~7 ~19 minecraft:quartz_pillar
setblock ~23 ~7 ~22 minecraft:quartz_pillar
fill ~27 ~7 ~22 ~40 ~7 ~22 minecraft:quartz_bricks
setblock ~44 ~7 ~22 minecraft:quartz_pillar
setblock ~27 ~7 ~23 minecraft:quartz_bricks
setblock ~40 ~7 ~23 minecraft:quartz_bricks
setblock ~27 ~7 ~24 minecraft:quartz_bricks
setblock ~40 ~7 ~24 minecraft:quartz_bricks
setblock ~23 ~7 ~25 minecraft:quartz_pillar
setblock ~27 ~7 ~25 minecraft:quartz_bricks
setblock ~30 ~7 ~25 minecraft:quartz_pillar
setblock ~37 ~7 ~25 minecraft:quartz_pillar
setblock ~40 ~7 ~25 minecraft:quartz_bricks
setblock ~44 ~7 ~25 minecraft:quartz_pillar
setblock ~27 ~7 ~26 minecraft:quartz_bricks
setblock ~40 ~7 ~26 minecraft:quartz_bricks
setblock ~27 ~7 ~27 minecraft:quartz_bricks
setblock ~40 ~7 ~27 minecraft:quartz_bricks
setblock ~23 ~7 ~28 minecraft:quartz_pillar
setblock ~27 ~7 ~28 minecraft:quartz_bricks
setblock ~30 ~7 ~28 minecraft:quartz_pillar
setblock ~37 ~7 ~28 minecraft:quartz_pillar
setblock ~40 ~7 ~28 minecraft:quartz_bricks
setblock ~44 ~7 ~28 minecraft:quartz_pillar
setblock ~27 ~7 ~29 minecraft:quartz_bricks
setblock ~40 ~7 ~29 minecraft:quartz_bricks
setblock ~27 ~7 ~30 minecraft:quartz_bricks
setblock ~40 ~7 ~30 minecraft:quartz_bricks
setblock ~23 ~7 ~31 minecraft:quartz_pillar
setblock ~27 ~7 ~31 minecraft:quartz_bricks
setblock ~30 ~7 ~31 minecraft:quartz_pillar
setblock ~37 ~7 ~31 minecraft:quartz_pillar
setblock ~40 ~7 ~31 minecraft:quartz_bricks
setblock ~44 ~7 ~31 minecraft:quartz_pillar
setblock ~27 ~7 ~32 minecraft:quartz_bricks
setblock ~40 ~7 ~32 minecraft:quartz_bricks
setblock ~4 ~7 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~7 ~33 minecraft:quartz_bricks
setblock ~40 ~7 ~33 minecraft:quartz_bricks
setblock ~23 ~7 ~34 minecraft:quartz_pillar
setblock ~27 ~7 ~34 minecraft:quartz_bricks
setblock ~30 ~7 ~34 minecraft:quartz_pillar
setblock ~37 ~7 ~34 minecraft:quartz_pillar
setblock ~40 ~7 ~34 minecraft:quartz_bricks
setblock ~44 ~7 ~34 minecraft:quartz_pillar
setblock ~27 ~7 ~35 minecraft:quartz_bricks
setblock ~40 ~7 ~35 minecraft:quartz_bricks
setblock ~27 ~7 ~36 minecraft:quartz_bricks
setblock ~40 ~7 ~36 minecraft:quartz_bricks
setblock ~64 ~7 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~7 ~37 minecraft:quartz_pillar
setblock ~27 ~7 ~37 minecraft:quartz_bricks
setblock ~30 ~7 ~37 minecraft:quartz_pillar
setblock ~37 ~7 ~37 minecraft:quartz_pillar
setblock ~40 ~7 ~37 minecraft:quartz_bricks
setblock ~44 ~7 ~37 minecraft:quartz_pillar
setblock ~27 ~7 ~38 minecraft:quartz_bricks
setblock ~40 ~7 ~38 minecraft:quartz_bricks
setblock ~27 ~7 ~39 minecraft:quartz_bricks
setblock ~40 ~7 ~39 minecraft:quartz_bricks
setblock ~23 ~7 ~40 minecraft:quartz_pillar
setblock ~27 ~7 ~40 minecraft:quartz_bricks
setblock ~30 ~7 ~40 minecraft:quartz_pillar
setblock ~37 ~7 ~40 minecraft:quartz_pillar
setblock ~40 ~7 ~40 minecraft:quartz_bricks
setblock ~44 ~7 ~40 minecraft:quartz_pillar
setblock ~27 ~7 ~41 minecraft:quartz_bricks
setblock ~40 ~7 ~41 minecraft:quartz_bricks
setblock ~27 ~7 ~42 minecraft:quartz_bricks
setblock ~40 ~7 ~42 minecraft:quartz_bricks
setblock ~23 ~7 ~43 minecraft:quartz_pillar
setblock ~27 ~7 ~43 minecraft:quartz_bricks
setblock ~30 ~7 ~43 minecraft:quartz_pillar
setblock ~37 ~7 ~43 minecraft:quartz_pillar
setblock ~40 ~7 ~43 minecraft:quartz_bricks
setblock ~44 ~7 ~43 minecraft:quartz_pillar
setblock ~27 ~7 ~44 minecraft:quartz_bricks
setblock ~40 ~7 ~44 minecraft:quartz_bricks
setblock ~27 ~7 ~45 minecraft:quartz_bricks
setblock ~40 ~7 ~45 minecraft:quartz_bricks
setblock ~23 ~7 ~46 minecraft:quartz_pillar
fill ~27 ~7 ~46 ~31 ~7 ~46 minecraft:quartz_bricks
fill ~36 ~7 ~46 ~40 ~7 ~46 minecraft:quartz_bricks
setblock ~44 ~7 ~46 minecraft:quartz_pillar
setblock ~23 ~7 ~49 minecraft:quartz_pillar
setblock ~44 ~7 ~49 minecraft:quartz_pillar
setblock ~23 ~7 ~52 minecraft:quartz_pillar
setblock ~26 ~7 ~52 minecraft:quartz_pillar
setblock ~29 ~7 ~52 minecraft:quartz_pillar
setblock ~32 ~7 ~52 minecraft:quartz_pillar
setblock ~35 ~7 ~52 minecraft:quartz_pillar
setblock ~38 ~7 ~52 minecraft:quartz_pillar
setblock ~41 ~7 ~52 minecraft:quartz_pillar
setblock ~44 ~7 ~52 minecraft:quartz_pillar
setblock ~4 ~7 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~7 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~29 ~7 ~64 minecraft:smooth_quartz
setblock ~30 ~7 ~64 minecraft:quartz_pillar
fill ~31 ~7 ~64 ~32 ~7 ~64 minecraft:smooth_quartz
setblock ~33 ~7 ~64 minecraft:quartz_pillar
setblock ~34 ~7 ~64 minecraft:smooth_quartz
setblock ~35 ~7 ~64 minecraft:quartz_pillar
fill ~36 ~7 ~64 ~37 ~7 ~64 minecraft:smooth_quartz
setblock ~38 ~7 ~64 minecraft:quartz_pillar
setblock ~39 ~7 ~64 minecraft:smooth_quartz
setblock ~29 ~7 ~65 minecraft:smooth_quartz
setblock ~30 ~7 ~65 minecraft:quartz_pillar
fill ~31 ~7 ~65 ~32 ~7 ~65 minecraft:smooth_quartz
setblock ~33 ~7 ~65 minecraft:quartz_pillar
setblock ~34 ~7 ~65 minecraft:smooth_quartz
setblock ~35 ~7 ~65 minecraft:quartz_pillar
fill ~36 ~7 ~65 ~37 ~7 ~65 minecraft:smooth_quartz
setblock ~38 ~7 ~65 minecraft:quartz_pillar
setblock ~39 ~7 ~65 minecraft:smooth_quartz
setblock ~29 ~7 ~66 minecraft:smooth_quartz
setblock ~30 ~7 ~66 minecraft:quartz_pillar
fill ~31 ~7 ~66 ~32 ~7 ~66 minecraft:smooth_quartz
setblock ~33 ~7 ~66 minecraft:quartz_pillar
setblock ~34 ~7 ~66 minecraft:smooth_quartz
setblock ~35 ~7 ~66 minecraft:quartz_pillar
fill ~36 ~7 ~66 ~37 ~7 ~66 minecraft:smooth_quartz
setblock ~38 ~7 ~66 minecraft:quartz_pillar
setblock ~39 ~7 ~66 minecraft:smooth_quartz
setblock ~29 ~7 ~67 minecraft:smooth_quartz
setblock ~30 ~7 ~67 minecraft:quartz_pillar
fill ~31 ~7 ~67 ~32 ~7 ~67 minecraft:smooth_quartz
setblock ~33 ~7 ~67 minecraft:quartz_pillar
setblock ~34 ~7 ~67 minecraft:smooth_quartz
setblock ~35 ~7 ~67 minecraft:quartz_pillar
fill ~36 ~7 ~67 ~37 ~7 ~67 minecraft:smooth_quartz
setblock ~38 ~7 ~67 minecraft:quartz_pillar
setblock ~39 ~7 ~67 minecraft:smooth_quartz
setblock ~43 ~7 ~67 minecraft:oak_fence
setblock ~29 ~7 ~68 minecraft:smooth_quartz
setblock ~30 ~7 ~68 minecraft:quartz_pillar
fill ~31 ~7 ~68 ~32 ~7 ~68 minecraft:smooth_quartz
setblock ~33 ~7 ~68 minecraft:quartz_pillar
setblock ~34 ~7 ~68 minecraft:smooth_quartz
setblock ~35 ~7 ~68 minecraft:quartz_pillar
fill ~36 ~7 ~68 ~37 ~7 ~68 minecraft:smooth_quartz
setblock ~38 ~7 ~68 minecraft:quartz_pillar
setblock ~39 ~7 ~68 minecraft:smooth_quartz
setblock ~29 ~7 ~69 minecraft:smooth_quartz
setblock ~30 ~7 ~69 minecraft:quartz_pillar
fill ~31 ~7 ~69 ~32 ~7 ~69 minecraft:smooth_quartz
setblock ~33 ~7 ~69 minecraft:quartz_pillar
setblock ~34 ~7 ~69 minecraft:smooth_quartz
setblock ~35 ~7 ~69 minecraft:quartz_pillar
fill ~36 ~7 ~69 ~37 ~7 ~69 minecraft:smooth_quartz
setblock ~38 ~7 ~69 minecraft:quartz_pillar
setblock ~39 ~7 ~69 minecraft:smooth_quartz
setblock ~5 ~8 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~8 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~8 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~8 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~8 ~16 minecraft:quartz_pillar
setblock ~26 ~8 ~16 minecraft:quartz_pillar
setblock ~29 ~8 ~16 minecraft:quartz_pillar
setblock ~32 ~8 ~16 minecraft:quartz_pillar
setblock ~35 ~8 ~16 minecraft:quartz_pillar
setblock ~38 ~8 ~16 minecraft:quartz_pillar
setblock ~41 ~8 ~16 minecraft:quartz_pillar
setblock ~44 ~8 ~16 minecraft:quartz_pillar
setblock ~23 ~8 ~19 minecraft:quartz_pillar
setblock ~44 ~8 ~19 minecraft:quartz_pillar
setblock ~23 ~8 ~22 minecraft:quartz_pillar
fill ~27 ~8 ~22 ~40 ~8 ~22 minecraft:quartz_bricks
setblock ~44 ~8 ~22 minecraft:quartz_pillar
setblock ~27 ~8 ~23 minecraft:quartz_bricks
setblock ~40 ~8 ~23 minecraft:quartz_bricks
setblock ~27 ~8 ~24 minecraft:quartz_bricks
setblock ~40 ~8 ~24 minecraft:quartz_bricks
setblock ~23 ~8 ~25 minecraft:quartz_pillar
setblock ~27 ~8 ~25 minecraft:quartz_bricks
setblock ~30 ~8 ~25 minecraft:quartz_pillar
setblock ~37 ~8 ~25 minecraft:quartz_pillar
setblock ~40 ~8 ~25 minecraft:quartz_bricks
setblock ~44 ~8 ~25 minecraft:quartz_pillar
setblock ~27 ~8 ~26 minecraft:quartz_bricks
setblock ~40 ~8 ~26 minecraft:quartz_bricks
setblock ~27 ~8 ~27 minecraft:quartz_bricks
setblock ~40 ~8 ~27 minecraft:quartz_bricks
setblock ~23 ~8 ~28 minecraft:quartz_pillar
setblock ~27 ~8 ~28 minecraft:quartz_bricks
setblock ~30 ~8 ~28 minecraft:quartz_pillar
setblock ~37 ~8 ~28 minecraft:quartz_pillar
setblock ~40 ~8 ~28 minecraft:quartz_bricks
setblock ~44 ~8 ~28 minecraft:quartz_pillar
setblock ~27 ~8 ~29 minecraft:quartz_bricks
setblock ~40 ~8 ~29 minecraft:quartz_bricks
setblock ~27 ~8 ~30 minecraft:quartz_bricks
setblock ~40 ~8 ~30 minecraft:quartz_bricks
setblock ~23 ~8 ~31 minecraft:quartz_pillar
setblock ~27 ~8 ~31 minecraft:quartz_bricks
setblock ~30 ~8 ~31 minecraft:quartz_pillar
setblock ~37 ~8 ~31 minecraft:quartz_pillar
setblock ~40 ~8 ~31 minecraft:quartz_bricks
setblock ~44 ~8 ~31 minecraft:quartz_pillar
setblock ~27 ~8 ~32 minecraft:quartz_bricks
setblock ~40 ~8 ~32 minecraft:quartz_bricks
setblock ~4 ~8 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~8 ~33 minecraft:quartz_bricks
setblock ~40 ~8 ~33 minecraft:quartz_bricks
setblock ~23 ~8 ~34 minecraft:quartz_pillar
setblock ~27 ~8 ~34 minecraft:quartz_bricks
setblock ~30 ~8 ~34 minecraft:quartz_pillar
setblock ~37 ~8 ~34 minecraft:quartz_pillar
setblock ~40 ~8 ~34 minecraft:quartz_bricks
setblock ~44 ~8 ~34 minecraft:quartz_pillar
setblock ~27 ~8 ~35 minecraft:quartz_bricks
setblock ~40 ~8 ~35 minecraft:quartz_bricks
setblock ~27 ~8 ~36 minecraft:quartz_bricks
setblock ~40 ~8 ~36 minecraft:quartz_bricks
setblock ~64 ~8 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~8 ~37 minecraft:quartz_pillar
setblock ~27 ~8 ~37 minecraft:quartz_bricks
setblock ~30 ~8 ~37 minecraft:quartz_pillar
setblock ~37 ~8 ~37 minecraft:quartz_pillar
setblock ~40 ~8 ~37 minecraft:quartz_bricks
setblock ~44 ~8 ~37 minecraft:quartz_pillar
setblock ~27 ~8 ~38 minecraft:quartz_bricks
setblock ~40 ~8 ~38 minecraft:quartz_bricks
setblock ~27 ~8 ~39 minecraft:quartz_bricks
setblock ~40 ~8 ~39 minecraft:quartz_bricks
setblock ~23 ~8 ~40 minecraft:quartz_pillar
setblock ~27 ~8 ~40 minecraft:quartz_bricks
setblock ~30 ~8 ~40 minecraft:quartz_pillar
setblock ~37 ~8 ~40 minecraft:quartz_pillar
setblock ~40 ~8 ~40 minecraft:quartz_bricks
setblock ~44 ~8 ~40 minecraft:quartz_pillar
setblock ~27 ~8 ~41 minecraft:quartz_bricks
setblock ~40 ~8 ~41 minecraft:quartz_bricks
setblock ~27 ~8 ~42 minecraft:quartz_bricks
setblock ~40 ~8 ~42 minecraft:quartz_bricks
setblock ~23 ~8 ~43 minecraft:quartz_pillar
setblock ~27 ~8 ~43 minecraft:quartz_bricks
setblock ~30 ~8 ~43 minecraft:quartz_pillar
setblock ~37 ~8 ~43 minecraft:quartz_pillar
setblock ~40 ~8 ~43 minecraft:quartz_bricks
setblock ~44 ~8 ~43 minecraft:quartz_pillar
setblock ~27 ~8 ~44 minecraft:quartz_bricks
setblock ~40 ~8 ~44 minecraft:quartz_bricks
setblock ~27 ~8 ~45 minecraft:quartz_bricks
setblock ~40 ~8 ~45 minecraft:quartz_bricks
setblock ~23 ~8 ~46 minecraft:quartz_pillar
fill ~27 ~8 ~46 ~31 ~8 ~46 minecraft:quartz_bricks
fill ~36 ~8 ~46 ~40 ~8 ~46 minecraft:quartz_bricks
setblock ~44 ~8 ~46 minecraft:quartz_pillar
setblock ~23 ~8 ~49 minecraft:quartz_pillar
setblock ~44 ~8 ~49 minecraft:quartz_pillar
setblock ~23 ~8 ~52 minecraft:quartz_pillar
setblock ~26 ~8 ~52 minecraft:quartz_pillar
setblock ~29 ~8 ~52 minecraft:quartz_pillar
setblock ~32 ~8 ~52 minecraft:quartz_pillar
setblock ~35 ~8 ~52 minecraft:quartz_pillar
setblock ~38 ~8 ~52 minecraft:quartz_pillar
setblock ~41 ~8 ~52 minecraft:quartz_pillar
setblock ~44 ~8 ~52 minecraft:quartz_pillar
setblock ~4 ~8 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~8 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~29 ~8 ~64 minecraft:smooth_quartz
setblock ~30 ~8 ~64 minecraft:quartz_pillar
fill ~31 ~8 ~64 ~32 ~8 ~64 minecraft:smooth_quartz
setblock ~33 ~8 ~64 minecraft:quartz_pillar
setblock ~34 ~8 ~64 minecraft:smooth_quartz
setblock ~35 ~8 ~64 minecraft:quartz_pillar
fill ~36 ~8 ~64 ~37 ~8 ~64 minecraft:smooth_quartz
setblock ~38 ~8 ~64 minecraft:quartz_pillar
setblock ~39 ~8 ~64 minecraft:smooth_quartz
setblock ~29 ~8 ~65 minecraft:smooth_quartz
setblock ~30 ~8 ~65 minecraft:quartz_pillar
fill ~31 ~8 ~65 ~32 ~8 ~65 minecraft:smooth_quartz
setblock ~33 ~8 ~65 minecraft:quartz_pillar
setblock ~34 ~8 ~65 minecraft:smooth_quartz
setblock ~35 ~8 ~65 minecraft:quartz_pillar
fill ~36 ~8 ~65 ~37 ~8 ~65 minecraft:smooth_quartz
setblock ~38 ~8 ~65 minecraft:quartz_pillar
setblock ~39 ~8 ~65 minecraft:smooth_quartz
setblock ~29 ~8 ~66 minecraft:smooth_quartz
setblock ~30 ~8 ~66 minecraft:quartz_pillar
fill ~31 ~8 ~66 ~32 ~8 ~66 minecraft:smooth_quartz
setblock ~33 ~8 ~66 minecraft:quartz_pillar
setblock ~34 ~8 ~66 minecraft:smooth_quartz
setblock ~35 ~8 ~66 minecraft:quartz_pillar
fill ~36 ~8 ~66 ~37 ~8 ~66 minecraft:smooth_quartz
setblock ~38 ~8 ~66 minecraft:quartz_pillar
setblock ~39 ~8 ~66 minecraft:smooth_quartz
setblock ~29 ~8 ~67 minecraft:smooth_quartz
setblock ~30 ~8 ~67 minecraft:quartz_pillar
fill ~31 ~8 ~67 ~32 ~8 ~67 minecraft:smooth_quartz
setblock ~33 ~8 ~67 minecraft:quartz_pillar
setblock ~34 ~8 ~67 minecraft:smooth_quartz
setblock ~35 ~8 ~67 minecraft:quartz_pillar
fill ~36 ~8 ~67 ~37 ~8 ~67 minecraft:smooth_quartz
setblock ~38 ~8 ~67 minecraft:quartz_pillar
setblock ~39 ~8 ~67 minecraft:smooth_quartz
setblock ~43 ~8 ~67 minecraft:oak_fence
setblock ~29 ~8 ~68 minecraft:smooth_quartz
setblock ~30 ~8 ~68 minecraft:quartz_pillar
fill ~31 ~8 ~68 ~32 ~8 ~68 minecraft:smooth_quartz
setblock ~33 ~8 ~68 minecraft:quartz_pillar
setblock ~34 ~8 ~68 minecraft:smooth_quartz
setblock ~35 ~8 ~68 minecraft:quartz_pillar
fill ~36 ~8 ~68 ~37 ~8 ~68 minecraft:smooth_quartz
setblock ~38 ~8 ~68 minecraft:quartz_pillar
setblock ~39 ~8 ~68 minecraft:smooth_quartz
setblock ~29 ~8 ~69 minecraft:smooth_quartz
setblock ~30 ~8 ~69 minecraft:quartz_pillar
fill ~31 ~8 ~69 ~32 ~8 ~69 minecraft:smooth_quartz
setblock ~33 ~8 ~69 minecraft:quartz_pillar
setblock ~34 ~8 ~69 minecraft:smooth_quartz
setblock ~35 ~8 ~69 minecraft:quartz_pillar
fill ~36 ~8 ~69 ~37 ~8 ~69 minecraft:smooth_quartz
setblock ~38 ~8 ~69 minecraft:quartz_pillar
setblock ~39 ~8 ~69 minecraft:smooth_quartz
setblock ~5 ~9 ~6 minecraft:spruce_leaves[persistent=true]
setblock ~13 ~9 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~54 ~9 ~8 minecraft:spruce_leaves[persistent=true]
setblock ~63 ~9 ~10 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~9 ~16 minecraft:quartz_pillar
setblock ~26 ~9 ~16 minecraft:quartz_pillar
setblock ~29 ~9 ~16 minecraft:quartz_pillar
setblock ~32 ~9 ~16 minecraft:quartz_pillar
setblock ~35 ~9 ~16 minecraft:quartz_pillar
setblock ~38 ~9 ~16 minecraft:quartz_pillar
setblock ~41 ~9 ~16 minecraft:quartz_pillar
setblock ~44 ~9 ~16 minecraft:quartz_pillar
setblock ~23 ~9 ~19 minecraft:quartz_pillar
setblock ~44 ~9 ~19 minecraft:quartz_pillar
setblock ~23 ~9 ~22 minecraft:quartz_pillar
fill ~27 ~9 ~22 ~40 ~9 ~22 minecraft:quartz_bricks
setblock ~44 ~9 ~22 minecraft:quartz_pillar
setblock ~27 ~9 ~23 minecraft:quartz_bricks
setblock ~40 ~9 ~23 minecraft:quartz_bricks
setblock ~27 ~9 ~24 minecraft:quartz_bricks
setblock ~40 ~9 ~24 minecraft:quartz_bricks
setblock ~23 ~9 ~25 minecraft:quartz_pillar
setblock ~27 ~9 ~25 minecraft:quartz_bricks
setblock ~30 ~9 ~25 minecraft:quartz_pillar
setblock ~37 ~9 ~25 minecraft:quartz_pillar
setblock ~40 ~9 ~25 minecraft:quartz_bricks
setblock ~44 ~9 ~25 minecraft:quartz_pillar
setblock ~27 ~9 ~26 minecraft:quartz_bricks
setblock ~40 ~9 ~26 minecraft:quartz_bricks
setblock ~27 ~9 ~27 minecraft:quartz_bricks
setblock ~40 ~9 ~27 minecraft:quartz_bricks
setblock ~23 ~9 ~28 minecraft:quartz_pillar
setblock ~27 ~9 ~28 minecraft:quartz_bricks
setblock ~30 ~9 ~28 minecraft:quartz_pillar
setblock ~37 ~9 ~28 minecraft:quartz_pillar
setblock ~40 ~9 ~28 minecraft:quartz_bricks
setblock ~44 ~9 ~28 minecraft:quartz_pillar
setblock ~27 ~9 ~29 minecraft:quartz_bricks
setblock ~40 ~9 ~29 minecraft:quartz_bricks
setblock ~27 ~9 ~30 minecraft:quartz_bricks
setblock ~40 ~9 ~30 minecraft:quartz_bricks
setblock ~23 ~9 ~31 minecraft:quartz_pillar
setblock ~27 ~9 ~31 minecraft:quartz_bricks
setblock ~30 ~9 ~31 minecraft:quartz_pillar
setblock ~37 ~9 ~31 minecraft:quartz_pillar
setblock ~40 ~9 ~31 minecraft:quartz_bricks
setblock ~44 ~9 ~31 minecraft:quartz_pillar
setblock ~27 ~9 ~32 minecraft:quartz_bricks
setblock ~40 ~9 ~32 minecraft:quartz_bricks
setblock ~4 ~9 ~33 minecraft:spruce_leaves[persistent=true]
setblock ~27 ~9 ~33 minecraft:quartz_bricks
setblock ~40 ~9 ~33 minecraft:quartz_bricks
setblock ~23 ~9 ~34 minecraft:quartz_pillar
setblock ~27 ~9 ~34 minecraft:quartz_bricks
setblock ~30 ~9 ~34 minecraft:quartz_pillar
setblock ~37 ~9 ~34 minecraft:quartz_pillar
setblock ~40 ~9 ~34 minecraft:quartz_bricks
setblock ~44 ~9 ~34 minecraft:quartz_pillar
setblock ~27 ~9 ~35 minecraft:quartz_bricks
setblock ~40 ~9 ~35 minecraft:quartz_bricks
setblock ~27 ~9 ~36 minecraft:quartz_bricks
setblock ~40 ~9 ~36 minecraft:quartz_bricks
setblock ~64 ~9 ~36 minecraft:spruce_leaves[persistent=true]
setblock ~23 ~9 ~37 minecraft:quartz_pillar
setblock ~27 ~9 ~37 minecraft:quartz_bricks
setblock ~30 ~9 ~37 minecraft:quartz_pillar
setblock ~37 ~9 ~37 minecraft:quartz_pillar
setblock ~40 ~9 ~37 minecraft:quartz_bricks
setblock ~44 ~9 ~37 minecraft:quartz_pillar
setblock ~27 ~9 ~38 minecraft:quartz_bricks
setblock ~40 ~9 ~38 minecraft:quartz_bricks
setblock ~27 ~9 ~39 minecraft:quartz_bricks
setblock ~40 ~9 ~39 minecraft:quartz_bricks
setblock ~23 ~9 ~40 minecraft:quartz_pillar
setblock ~27 ~9 ~40 minecraft:quartz_bricks
setblock ~30 ~9 ~40 minecraft:quartz_pillar
setblock ~37 ~9 ~40 minecraft:quartz_pillar
setblock ~40 ~9 ~40 minecraft:quartz_bricks
setblock ~44 ~9 ~40 minecraft:quartz_pillar
setblock ~27 ~9 ~41 minecraft:quartz_bricks
setblock ~40 ~9 ~41 minecraft:quartz_bricks
setblock ~27 ~9 ~42 minecraft:quartz_bricks
setblock ~40 ~9 ~42 minecraft:quartz_bricks
setblock ~23 ~9 ~43 minecraft:quartz_pillar
setblock ~27 ~9 ~43 minecraft:quartz_bricks
setblock ~30 ~9 ~43 minecraft:quartz_pillar
setblock ~37 ~9 ~43 minecraft:quartz_pillar
setblock ~40 ~9 ~43 minecraft:quartz_bricks
setblock ~44 ~9 ~43 minecraft:quartz_pillar
setblock ~27 ~9 ~44 minecraft:quartz_bricks
setblock ~40 ~9 ~44 minecraft:quartz_bricks
setblock ~27 ~9 ~45 minecraft:quartz_bricks
setblock ~40 ~9 ~45 minecraft:quartz_bricks
setblock ~23 ~9 ~46 minecraft:quartz_pillar
fill ~27 ~9 ~46 ~40 ~9 ~46 minecraft:quartz_bricks
setblock ~44 ~9 ~46 minecraft:quartz_pillar
setblock ~23 ~9 ~49 minecraft:quartz_pillar
setblock ~44 ~9 ~49 minecraft:quartz_pillar
setblock ~23 ~9 ~52 minecraft:quartz_pillar
setblock ~26 ~9 ~52 minecraft:quartz_pillar
setblock ~29 ~9 ~52 minecraft:quartz_pillar
setblock ~32 ~9 ~52 minecraft:quartz_pillar
setblock ~35 ~9 ~52 minecraft:quartz_pillar
setblock ~38 ~9 ~52 minecraft:quartz_pillar
setblock ~41 ~9 ~52 minecraft:quartz_pillar
setblock ~44 ~9 ~52 minecraft:quartz_pillar
setblock ~4 ~9 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~62 ~9 ~62 minecraft:spruce_leaves[persistent=true]
setblock ~29 ~9 ~64 minecraft:smooth_quartz
setblock ~30 ~9 ~64 minecraft:quartz_pillar
schedule function hive:weiter/17 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 16 von 18 fertig","color":"gray"}]