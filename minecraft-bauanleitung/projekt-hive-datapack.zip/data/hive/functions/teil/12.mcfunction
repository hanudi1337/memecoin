setblock ~47 ~-26 ~47 minecraft:air
setblock ~48 ~-26 ~47 minecraft:glass
setblock ~49 ~-26 ~47 minecraft:air
setblock ~50 ~-26 ~47 minecraft:light_gray_concrete
setblock ~51 ~-26 ~47 minecraft:packed_ice
fill ~52 ~-26 ~47 ~53 ~-26 ~47 minecraft:air
setblock ~54 ~-26 ~47 minecraft:barrel
fill ~55 ~-26 ~47 ~56 ~-26 ~47 minecraft:air
setblock ~57 ~-26 ~47 minecraft:barrel
fill ~58 ~-26 ~47 ~59 ~-26 ~47 minecraft:air
setblock ~60 ~-26 ~47 minecraft:barrel
fill ~61 ~-26 ~47 ~62 ~-26 ~47 minecraft:air
setblock ~63 ~-26 ~47 minecraft:packed_ice
setblock ~64 ~-26 ~47 minecraft:light_gray_concrete
setblock ~4 ~-26 ~48 minecraft:light_gray_concrete
fill ~5 ~-26 ~48 ~17 ~-26 ~48 minecraft:air
setblock ~18 ~-26 ~48 minecraft:light_gray_concrete
fill ~19 ~-26 ~48 ~41 ~-26 ~48 minecraft:air
fill ~42 ~-26 ~48 ~44 ~-26 ~48 minecraft:glass
setblock ~45 ~-26 ~48 minecraft:air
fill ~46 ~-26 ~48 ~48 ~-26 ~48 minecraft:glass
setblock ~49 ~-26 ~48 minecraft:air
setblock ~50 ~-26 ~48 minecraft:light_gray_concrete
fill ~51 ~-26 ~48 ~63 ~-26 ~48 minecraft:air
setblock ~64 ~-26 ~48 minecraft:light_gray_concrete
setblock ~4 ~-26 ~49 minecraft:light_gray_concrete
fill ~5 ~-26 ~49 ~17 ~-26 ~49 minecraft:air
setblock ~18 ~-26 ~49 minecraft:light_gray_concrete
setblock ~19 ~-26 ~49 minecraft:air
setblock ~20 ~-26 ~49 minecraft:black_concrete
fill ~21 ~-26 ~49 ~22 ~-26 ~49 minecraft:air
setblock ~23 ~-26 ~49 minecraft:black_concrete
fill ~24 ~-26 ~49 ~25 ~-26 ~49 minecraft:air
setblock ~26 ~-26 ~49 minecraft:black_concrete
fill ~27 ~-26 ~49 ~28 ~-26 ~49 minecraft:air
setblock ~29 ~-26 ~49 minecraft:black_concrete
fill ~30 ~-26 ~49 ~31 ~-26 ~49 minecraft:air
setblock ~32 ~-26 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-26 ~49 ~35 ~-26 ~49 minecraft:air
setblock ~36 ~-26 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-26 ~49 ~40 ~-26 ~49 minecraft:air
setblock ~41 ~-26 ~49 minecraft:black_concrete
fill ~42 ~-26 ~49 ~45 ~-26 ~49 minecraft:air
setblock ~46 ~-26 ~49 minecraft:black_concrete
fill ~47 ~-26 ~49 ~49 ~-26 ~49 minecraft:air
setblock ~50 ~-26 ~49 minecraft:light_gray_concrete
fill ~51 ~-26 ~49 ~53 ~-26 ~49 minecraft:packed_ice
setblock ~54 ~-26 ~49 minecraft:air
setblock ~55 ~-26 ~49 minecraft:packed_ice
fill ~56 ~-26 ~49 ~58 ~-26 ~49 minecraft:air
fill ~59 ~-26 ~49 ~61 ~-26 ~49 minecraft:packed_ice
setblock ~62 ~-26 ~49 minecraft:air
setblock ~63 ~-26 ~49 minecraft:packed_ice
setblock ~64 ~-26 ~49 minecraft:light_gray_concrete
fill ~4 ~-26 ~50 ~10 ~-26 ~50 minecraft:light_gray_concrete
setblock ~11 ~-26 ~50 minecraft:air
fill ~12 ~-26 ~50 ~31 ~-26 ~50 minecraft:light_gray_concrete
setblock ~32 ~-26 ~50 minecraft:red_concrete
fill ~33 ~-26 ~50 ~35 ~-26 ~50 minecraft:air
setblock ~36 ~-26 ~50 minecraft:red_concrete
fill ~37 ~-26 ~50 ~56 ~-26 ~50 minecraft:light_gray_concrete
setblock ~57 ~-26 ~50 minecraft:air
fill ~58 ~-26 ~50 ~64 ~-26 ~50 minecraft:light_gray_concrete
setblock ~4 ~-26 ~51 minecraft:light_gray_concrete
fill ~5 ~-26 ~51 ~17 ~-26 ~51 minecraft:air
setblock ~18 ~-26 ~51 minecraft:light_gray_concrete
fill ~19 ~-26 ~51 ~31 ~-26 ~51 minecraft:air
setblock ~32 ~-26 ~51 minecraft:red_concrete
fill ~33 ~-26 ~51 ~35 ~-26 ~51 minecraft:air
setblock ~36 ~-26 ~51 minecraft:red_concrete
fill ~37 ~-26 ~51 ~49 ~-26 ~51 minecraft:air
setblock ~50 ~-26 ~51 minecraft:light_gray_concrete
fill ~51 ~-26 ~51 ~63 ~-26 ~51 minecraft:air
setblock ~64 ~-26 ~51 minecraft:light_gray_concrete
setblock ~4 ~-26 ~52 minecraft:light_gray_concrete
fill ~5 ~-26 ~52 ~17 ~-26 ~52 minecraft:air
setblock ~18 ~-26 ~52 minecraft:light_gray_concrete
fill ~19 ~-26 ~52 ~31 ~-26 ~52 minecraft:air
setblock ~32 ~-26 ~52 minecraft:red_concrete
fill ~33 ~-26 ~52 ~35 ~-26 ~52 minecraft:air
setblock ~36 ~-26 ~52 minecraft:red_concrete
fill ~37 ~-26 ~52 ~49 ~-26 ~52 minecraft:air
setblock ~50 ~-26 ~52 minecraft:light_gray_concrete
setblock ~51 ~-26 ~52 minecraft:air
fill ~52 ~-26 ~52 ~55 ~-26 ~52 minecraft:barrel
fill ~56 ~-26 ~52 ~57 ~-26 ~52 minecraft:air
fill ~58 ~-26 ~52 ~60 ~-26 ~52 minecraft:barrel
setblock ~61 ~-26 ~52 minecraft:air
setblock ~62 ~-26 ~52 minecraft:barrel
setblock ~63 ~-26 ~52 minecraft:air
setblock ~64 ~-26 ~52 minecraft:light_gray_concrete
setblock ~4 ~-26 ~53 minecraft:light_gray_concrete
fill ~5 ~-26 ~53 ~17 ~-26 ~53 minecraft:air
setblock ~18 ~-26 ~53 minecraft:light_gray_concrete
fill ~19 ~-26 ~53 ~31 ~-26 ~53 minecraft:air
setblock ~32 ~-26 ~53 minecraft:red_concrete
fill ~33 ~-26 ~53 ~35 ~-26 ~53 minecraft:air
setblock ~36 ~-26 ~53 minecraft:red_concrete
fill ~37 ~-26 ~53 ~49 ~-26 ~53 minecraft:air
setblock ~50 ~-26 ~53 minecraft:light_gray_concrete
fill ~51 ~-26 ~53 ~63 ~-26 ~53 minecraft:air
setblock ~64 ~-26 ~53 minecraft:light_gray_concrete
setblock ~4 ~-26 ~54 minecraft:light_gray_concrete
setblock ~5 ~-26 ~54 minecraft:air
fill ~6 ~-26 ~54 ~10 ~-26 ~54 minecraft:chiseled_bookshelf[facing=south]
setblock ~11 ~-26 ~54 minecraft:air
fill ~12 ~-26 ~54 ~16 ~-26 ~54 minecraft:chiseled_bookshelf[facing=south]
setblock ~17 ~-26 ~54 minecraft:air
setblock ~18 ~-26 ~54 minecraft:light_gray_concrete
fill ~19 ~-26 ~54 ~31 ~-26 ~54 minecraft:air
setblock ~32 ~-26 ~54 minecraft:red_concrete
fill ~33 ~-26 ~54 ~35 ~-26 ~54 minecraft:air
setblock ~36 ~-26 ~54 minecraft:red_concrete
fill ~37 ~-26 ~54 ~49 ~-26 ~54 minecraft:air
setblock ~50 ~-26 ~54 minecraft:light_gray_concrete
fill ~51 ~-26 ~54 ~63 ~-26 ~54 minecraft:air
setblock ~64 ~-26 ~54 minecraft:light_gray_concrete
setblock ~4 ~-26 ~55 minecraft:light_gray_concrete
fill ~5 ~-26 ~55 ~17 ~-26 ~55 minecraft:air
setblock ~18 ~-26 ~55 minecraft:light_gray_concrete
fill ~19 ~-26 ~55 ~31 ~-26 ~55 minecraft:air
setblock ~32 ~-26 ~55 minecraft:red_concrete
fill ~33 ~-26 ~55 ~35 ~-26 ~55 minecraft:air
setblock ~36 ~-26 ~55 minecraft:red_concrete
fill ~37 ~-26 ~55 ~49 ~-26 ~55 minecraft:air
setblock ~50 ~-26 ~55 minecraft:light_gray_concrete
setblock ~51 ~-26 ~55 minecraft:air
fill ~52 ~-26 ~55 ~55 ~-26 ~55 minecraft:barrel
setblock ~56 ~-26 ~55 minecraft:air
fill ~57 ~-26 ~55 ~60 ~-26 ~55 minecraft:barrel
setblock ~61 ~-26 ~55 minecraft:air
setblock ~62 ~-26 ~55 minecraft:barrel
setblock ~63 ~-26 ~55 minecraft:air
setblock ~64 ~-26 ~55 minecraft:light_gray_concrete
setblock ~4 ~-26 ~56 minecraft:light_gray_concrete
fill ~5 ~-26 ~56 ~17 ~-26 ~56 minecraft:air
setblock ~18 ~-26 ~56 minecraft:light_gray_concrete
fill ~19 ~-26 ~56 ~31 ~-26 ~56 minecraft:air
setblock ~32 ~-26 ~56 minecraft:red_concrete
fill ~33 ~-26 ~56 ~35 ~-26 ~56 minecraft:air
setblock ~36 ~-26 ~56 minecraft:red_concrete
fill ~37 ~-26 ~56 ~49 ~-26 ~56 minecraft:air
setblock ~50 ~-26 ~56 minecraft:light_gray_concrete
fill ~51 ~-26 ~56 ~63 ~-26 ~56 minecraft:air
setblock ~64 ~-26 ~56 minecraft:light_gray_concrete
setblock ~4 ~-26 ~57 minecraft:light_gray_concrete
setblock ~5 ~-26 ~57 minecraft:air
fill ~6 ~-26 ~57 ~10 ~-26 ~57 minecraft:chiseled_bookshelf[facing=north]
setblock ~11 ~-26 ~57 minecraft:air
fill ~12 ~-26 ~57 ~15 ~-26 ~57 minecraft:chiseled_bookshelf[facing=north]
fill ~16 ~-26 ~57 ~63 ~-26 ~57 minecraft:air
setblock ~64 ~-26 ~57 minecraft:light_gray_concrete
setblock ~4 ~-26 ~58 minecraft:light_gray_concrete
fill ~5 ~-26 ~58 ~17 ~-26 ~58 minecraft:air
setblock ~18 ~-26 ~58 minecraft:light_gray_concrete
fill ~19 ~-26 ~58 ~31 ~-26 ~58 minecraft:air
setblock ~32 ~-26 ~58 minecraft:red_concrete
fill ~33 ~-26 ~58 ~35 ~-26 ~58 minecraft:air
setblock ~36 ~-26 ~58 minecraft:red_concrete
fill ~37 ~-26 ~58 ~49 ~-26 ~58 minecraft:air
setblock ~50 ~-26 ~58 minecraft:light_gray_concrete
setblock ~51 ~-26 ~58 minecraft:air
fill ~52 ~-26 ~58 ~55 ~-26 ~58 minecraft:barrel
setblock ~56 ~-26 ~58 minecraft:air
fill ~57 ~-26 ~58 ~60 ~-26 ~58 minecraft:barrel
setblock ~61 ~-26 ~58 minecraft:air
setblock ~62 ~-26 ~58 minecraft:barrel
setblock ~63 ~-26 ~58 minecraft:air
setblock ~64 ~-26 ~58 minecraft:light_gray_concrete
setblock ~4 ~-26 ~59 minecraft:light_gray_concrete
fill ~5 ~-26 ~59 ~17 ~-26 ~59 minecraft:air
setblock ~18 ~-26 ~59 minecraft:light_gray_concrete
fill ~19 ~-26 ~59 ~31 ~-26 ~59 minecraft:air
setblock ~32 ~-26 ~59 minecraft:red_concrete
fill ~33 ~-26 ~59 ~35 ~-26 ~59 minecraft:air
setblock ~36 ~-26 ~59 minecraft:red_concrete
fill ~37 ~-26 ~59 ~49 ~-26 ~59 minecraft:air
setblock ~50 ~-26 ~59 minecraft:light_gray_concrete
fill ~51 ~-26 ~59 ~63 ~-26 ~59 minecraft:air
setblock ~64 ~-26 ~59 minecraft:light_gray_concrete
setblock ~4 ~-26 ~60 minecraft:light_gray_concrete
setblock ~5 ~-26 ~60 minecraft:air
fill ~6 ~-26 ~60 ~10 ~-26 ~60 minecraft:chiseled_bookshelf[facing=south]
setblock ~11 ~-26 ~60 minecraft:air
fill ~12 ~-26 ~60 ~16 ~-26 ~60 minecraft:chiseled_bookshelf[facing=south]
setblock ~17 ~-26 ~60 minecraft:air
setblock ~18 ~-26 ~60 minecraft:light_gray_concrete
fill ~19 ~-26 ~60 ~24 ~-26 ~60 minecraft:air
setblock ~25 ~-26 ~60 minecraft:black_concrete
fill ~26 ~-26 ~60 ~31 ~-26 ~60 minecraft:air
setblock ~32 ~-26 ~60 minecraft:red_concrete
fill ~33 ~-26 ~60 ~35 ~-26 ~60 minecraft:air
setblock ~36 ~-26 ~60 minecraft:red_concrete
fill ~37 ~-26 ~60 ~49 ~-26 ~60 minecraft:air
setblock ~50 ~-26 ~60 minecraft:light_gray_concrete
fill ~51 ~-26 ~60 ~63 ~-26 ~60 minecraft:air
setblock ~64 ~-26 ~60 minecraft:light_gray_concrete
setblock ~4 ~-26 ~61 minecraft:light_gray_concrete
fill ~5 ~-26 ~61 ~17 ~-26 ~61 minecraft:air
setblock ~18 ~-26 ~61 minecraft:light_gray_concrete
fill ~19 ~-26 ~61 ~31 ~-26 ~61 minecraft:air
setblock ~32 ~-26 ~61 minecraft:red_concrete
fill ~33 ~-26 ~61 ~35 ~-26 ~61 minecraft:air
setblock ~36 ~-26 ~61 minecraft:red_concrete
fill ~37 ~-26 ~61 ~49 ~-26 ~61 minecraft:air
setblock ~50 ~-26 ~61 minecraft:light_gray_concrete
setblock ~51 ~-26 ~61 minecraft:air
fill ~52 ~-26 ~61 ~55 ~-26 ~61 minecraft:barrel
setblock ~56 ~-26 ~61 minecraft:air
fill ~57 ~-26 ~61 ~60 ~-26 ~61 minecraft:barrel
setblock ~61 ~-26 ~61 minecraft:air
setblock ~62 ~-26 ~61 minecraft:barrel
setblock ~63 ~-26 ~61 minecraft:air
setblock ~64 ~-26 ~61 minecraft:light_gray_concrete
setblock ~4 ~-26 ~62 minecraft:light_gray_concrete
fill ~5 ~-26 ~62 ~17 ~-26 ~62 minecraft:air
setblock ~18 ~-26 ~62 minecraft:light_gray_concrete
fill ~19 ~-26 ~62 ~31 ~-26 ~62 minecraft:air
setblock ~32 ~-26 ~62 minecraft:red_concrete
fill ~33 ~-26 ~62 ~35 ~-26 ~62 minecraft:air
setblock ~36 ~-26 ~62 minecraft:red_concrete
fill ~37 ~-26 ~62 ~49 ~-26 ~62 minecraft:air
setblock ~50 ~-26 ~62 minecraft:light_gray_concrete
fill ~51 ~-26 ~62 ~63 ~-26 ~62 minecraft:air
setblock ~64 ~-26 ~62 minecraft:light_gray_concrete
setblock ~4 ~-26 ~63 minecraft:light_gray_concrete
fill ~5 ~-26 ~63 ~16 ~-26 ~63 minecraft:chiseled_bookshelf[facing=north]
setblock ~17 ~-26 ~63 minecraft:air
setblock ~18 ~-26 ~63 minecraft:light_gray_concrete
fill ~19 ~-26 ~63 ~30 ~-26 ~63 minecraft:chiseled_bookshelf[facing=north]
setblock ~31 ~-26 ~63 minecraft:air
setblock ~32 ~-26 ~63 minecraft:red_concrete
fill ~33 ~-26 ~63 ~35 ~-26 ~63 minecraft:air
setblock ~36 ~-26 ~63 minecraft:red_concrete
fill ~37 ~-26 ~63 ~49 ~-26 ~63 minecraft:air
setblock ~50 ~-26 ~63 minecraft:light_gray_concrete
fill ~51 ~-26 ~63 ~63 ~-26 ~63 minecraft:air
setblock ~64 ~-26 ~63 minecraft:light_gray_concrete
fill ~4 ~-26 ~64 ~33 ~-26 ~64 minecraft:light_gray_concrete
setblock ~34 ~-26 ~64 minecraft:air
fill ~35 ~-26 ~64 ~64 ~-26 ~64 minecraft:light_gray_concrete
setblock ~33 ~-26 ~65 minecraft:light_gray_concrete
setblock ~34 ~-26 ~65 minecraft:air
setblock ~35 ~-26 ~65 minecraft:light_gray_concrete
fill ~32 ~-26 ~66 ~33 ~-26 ~66 minecraft:polished_andesite
setblock ~34 ~-26 ~66 minecraft:air
fill ~35 ~-26 ~66 ~36 ~-26 ~66 minecraft:polished_andesite
setblock ~32 ~-26 ~67 minecraft:polished_andesite
fill ~33 ~-26 ~67 ~35 ~-26 ~67 minecraft:air
setblock ~36 ~-26 ~67 minecraft:polished_andesite
setblock ~32 ~-26 ~68 minecraft:polished_andesite
setblock ~33 ~-26 ~68 minecraft:air
setblock ~34 ~-26 ~68 minecraft:quartz_pillar
setblock ~35 ~-26 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-26 ~68 minecraft:polished_andesite
setblock ~32 ~-26 ~69 minecraft:polished_andesite
fill ~33 ~-26 ~69 ~35 ~-26 ~69 minecraft:air
setblock ~36 ~-26 ~69 minecraft:polished_andesite
fill ~32 ~-26 ~70 ~36 ~-26 ~70 minecraft:polished_andesite
fill ~4 ~-25 ~4 ~64 ~-25 ~4 minecraft:light_gray_concrete
setblock ~4 ~-25 ~5 minecraft:light_gray_concrete
fill ~5 ~-25 ~5 ~17 ~-25 ~5 minecraft:air
setblock ~18 ~-25 ~5 minecraft:light_gray_concrete
fill ~19 ~-25 ~5 ~31 ~-25 ~5 minecraft:chiseled_bookshelf[facing=south]
setblock ~32 ~-25 ~5 minecraft:light_gray_concrete
fill ~33 ~-25 ~5 ~35 ~-25 ~5 minecraft:air
setblock ~36 ~-25 ~5 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~5 ~49 ~-25 ~5 minecraft:air
setblock ~50 ~-25 ~5 minecraft:light_gray_concrete
fill ~51 ~-25 ~5 ~63 ~-25 ~5 minecraft:air
setblock ~64 ~-25 ~5 minecraft:light_gray_concrete
setblock ~4 ~-25 ~6 minecraft:light_gray_concrete
fill ~5 ~-25 ~6 ~17 ~-25 ~6 minecraft:air
setblock ~18 ~-25 ~6 minecraft:light_gray_concrete
fill ~19 ~-25 ~6 ~31 ~-25 ~6 minecraft:air
setblock ~32 ~-25 ~6 minecraft:light_gray_concrete
fill ~33 ~-25 ~6 ~35 ~-25 ~6 minecraft:air
setblock ~36 ~-25 ~6 minecraft:light_gray_concrete
fill ~37 ~-25 ~6 ~49 ~-25 ~6 minecraft:air
setblock ~50 ~-25 ~6 minecraft:light_gray_concrete
fill ~51 ~-25 ~6 ~63 ~-25 ~6 minecraft:air
setblock ~64 ~-25 ~6 minecraft:light_gray_concrete
setblock ~4 ~-25 ~7 minecraft:light_gray_concrete
fill ~5 ~-25 ~7 ~17 ~-25 ~7 minecraft:air
setblock ~18 ~-25 ~7 minecraft:light_gray_concrete
fill ~19 ~-25 ~7 ~31 ~-25 ~7 minecraft:air
setblock ~32 ~-25 ~7 minecraft:light_gray_concrete
fill ~33 ~-25 ~7 ~35 ~-25 ~7 minecraft:air
setblock ~36 ~-25 ~7 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~7 ~49 ~-25 ~7 minecraft:air
setblock ~50 ~-25 ~7 minecraft:light_gray_concrete
fill ~51 ~-25 ~7 ~63 ~-25 ~7 minecraft:air
setblock ~64 ~-25 ~7 minecraft:light_gray_concrete
setblock ~4 ~-25 ~8 minecraft:light_gray_concrete
fill ~5 ~-25 ~8 ~17 ~-25 ~8 minecraft:air
setblock ~18 ~-25 ~8 minecraft:light_gray_concrete
fill ~19 ~-25 ~8 ~31 ~-25 ~8 minecraft:air
setblock ~32 ~-25 ~8 minecraft:light_gray_concrete
fill ~33 ~-25 ~8 ~35 ~-25 ~8 minecraft:air
setblock ~36 ~-25 ~8 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~8 ~39 ~-25 ~8 minecraft:air
setblock ~40 ~-25 ~8 minecraft:glass
fill ~41 ~-25 ~8 ~43 ~-25 ~8 minecraft:air
setblock ~44 ~-25 ~8 minecraft:glass
fill ~45 ~-25 ~8 ~49 ~-25 ~8 minecraft:air
setblock ~50 ~-25 ~8 minecraft:light_gray_concrete
fill ~51 ~-25 ~8 ~63 ~-25 ~8 minecraft:air
setblock ~64 ~-25 ~8 minecraft:light_gray_concrete
setblock ~4 ~-25 ~9 minecraft:light_gray_concrete
fill ~5 ~-25 ~9 ~17 ~-25 ~9 minecraft:air
setblock ~18 ~-25 ~9 minecraft:light_gray_concrete
fill ~19 ~-25 ~9 ~31 ~-25 ~9 minecraft:air
setblock ~32 ~-25 ~9 minecraft:light_gray_concrete
fill ~33 ~-25 ~9 ~35 ~-25 ~9 minecraft:air
setblock ~36 ~-25 ~9 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~9 ~49 ~-25 ~9 minecraft:air
setblock ~50 ~-25 ~9 minecraft:light_gray_concrete
fill ~51 ~-25 ~9 ~63 ~-25 ~9 minecraft:air
setblock ~64 ~-25 ~9 minecraft:light_gray_concrete
setblock ~4 ~-25 ~10 minecraft:light_gray_concrete
fill ~5 ~-25 ~10 ~17 ~-25 ~10 minecraft:air
setblock ~18 ~-25 ~10 minecraft:light_gray_concrete
fill ~19 ~-25 ~10 ~31 ~-25 ~10 minecraft:air
setblock ~32 ~-25 ~10 minecraft:light_gray_concrete
fill ~33 ~-25 ~10 ~35 ~-25 ~10 minecraft:air
setblock ~36 ~-25 ~10 minecraft:light_gray_concrete
fill ~37 ~-25 ~10 ~49 ~-25 ~10 minecraft:air
setblock ~50 ~-25 ~10 minecraft:light_gray_concrete
fill ~51 ~-25 ~10 ~63 ~-25 ~10 minecraft:air
setblock ~64 ~-25 ~10 minecraft:light_gray_concrete
setblock ~4 ~-25 ~11 minecraft:light_gray_concrete
fill ~5 ~-25 ~11 ~17 ~-25 ~11 minecraft:air
setblock ~18 ~-25 ~11 minecraft:light_gray_concrete
fill ~19 ~-25 ~11 ~31 ~-25 ~11 minecraft:air
setblock ~32 ~-25 ~11 minecraft:light_gray_concrete
fill ~33 ~-25 ~11 ~35 ~-25 ~11 minecraft:air
setblock ~36 ~-25 ~11 minecraft:light_gray_concrete
fill ~37 ~-25 ~11 ~49 ~-25 ~11 minecraft:air
setblock ~50 ~-25 ~11 minecraft:light_gray_concrete
fill ~51 ~-25 ~11 ~63 ~-25 ~11 minecraft:air
setblock ~64 ~-25 ~11 minecraft:light_gray_concrete
setblock ~4 ~-25 ~12 minecraft:light_gray_concrete
fill ~5 ~-25 ~12 ~17 ~-25 ~12 minecraft:air
setblock ~18 ~-25 ~12 minecraft:light_gray_concrete
fill ~19 ~-25 ~12 ~31 ~-25 ~12 minecraft:air
setblock ~32 ~-25 ~12 minecraft:light_gray_concrete
fill ~33 ~-25 ~12 ~35 ~-25 ~12 minecraft:air
setblock ~36 ~-25 ~12 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~12 ~39 ~-25 ~12 minecraft:air
setblock ~40 ~-25 ~12 minecraft:glass
fill ~41 ~-25 ~12 ~43 ~-25 ~12 minecraft:air
setblock ~44 ~-25 ~12 minecraft:glass
fill ~45 ~-25 ~12 ~49 ~-25 ~12 minecraft:air
setblock ~50 ~-25 ~12 minecraft:light_gray_concrete
fill ~51 ~-25 ~12 ~63 ~-25 ~12 minecraft:air
setblock ~64 ~-25 ~12 minecraft:light_gray_concrete
setblock ~4 ~-25 ~13 minecraft:light_gray_concrete
fill ~5 ~-25 ~13 ~17 ~-25 ~13 minecraft:air
setblock ~18 ~-25 ~13 minecraft:light_gray_concrete
fill ~19 ~-25 ~13 ~31 ~-25 ~13 minecraft:air
setblock ~32 ~-25 ~13 minecraft:light_gray_concrete
fill ~33 ~-25 ~13 ~35 ~-25 ~13 minecraft:air
setblock ~36 ~-25 ~13 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~13 ~49 ~-25 ~13 minecraft:air
setblock ~50 ~-25 ~13 minecraft:light_gray_concrete
fill ~51 ~-25 ~13 ~63 ~-25 ~13 minecraft:air
setblock ~64 ~-25 ~13 minecraft:light_gray_concrete
setblock ~4 ~-25 ~14 minecraft:light_gray_concrete
fill ~5 ~-25 ~14 ~17 ~-25 ~14 minecraft:air
setblock ~18 ~-25 ~14 minecraft:light_gray_concrete
fill ~19 ~-25 ~14 ~31 ~-25 ~14 minecraft:air
setblock ~32 ~-25 ~14 minecraft:light_gray_concrete
fill ~33 ~-25 ~14 ~35 ~-25 ~14 minecraft:air
setblock ~36 ~-25 ~14 minecraft:light_gray_concrete
fill ~37 ~-25 ~14 ~49 ~-25 ~14 minecraft:air
setblock ~50 ~-25 ~14 minecraft:light_gray_concrete
fill ~51 ~-25 ~14 ~63 ~-25 ~14 minecraft:air
setblock ~64 ~-25 ~14 minecraft:light_gray_concrete
setblock ~4 ~-25 ~15 minecraft:light_gray_concrete
fill ~5 ~-25 ~15 ~17 ~-25 ~15 minecraft:air
setblock ~18 ~-25 ~15 minecraft:light_gray_concrete
fill ~19 ~-25 ~15 ~31 ~-25 ~15 minecraft:air
setblock ~32 ~-25 ~15 minecraft:light_gray_concrete
fill ~33 ~-25 ~15 ~35 ~-25 ~15 minecraft:air
setblock ~36 ~-25 ~15 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~15 ~49 ~-25 ~15 minecraft:air
setblock ~50 ~-25 ~15 minecraft:light_gray_concrete
fill ~51 ~-25 ~15 ~63 ~-25 ~15 minecraft:air
setblock ~64 ~-25 ~15 minecraft:light_gray_concrete
setblock ~4 ~-25 ~16 minecraft:light_gray_concrete
fill ~5 ~-25 ~16 ~17 ~-25 ~16 minecraft:air
setblock ~18 ~-25 ~16 minecraft:light_gray_concrete
fill ~19 ~-25 ~16 ~31 ~-25 ~16 minecraft:air
setblock ~32 ~-25 ~16 minecraft:light_gray_concrete
fill ~33 ~-25 ~16 ~35 ~-25 ~16 minecraft:air
setblock ~36 ~-25 ~16 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~16 ~49 ~-25 ~16 minecraft:air
setblock ~50 ~-25 ~16 minecraft:light_gray_concrete
fill ~51 ~-25 ~16 ~63 ~-25 ~16 minecraft:air
setblock ~64 ~-25 ~16 minecraft:light_gray_concrete
setblock ~4 ~-25 ~17 minecraft:light_gray_concrete
fill ~5 ~-25 ~17 ~17 ~-25 ~17 minecraft:air
setblock ~18 ~-25 ~17 minecraft:light_gray_concrete
fill ~19 ~-25 ~17 ~31 ~-25 ~17 minecraft:air
setblock ~32 ~-25 ~17 minecraft:light_gray_concrete
fill ~33 ~-25 ~17 ~35 ~-25 ~17 minecraft:air
setblock ~36 ~-25 ~17 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~17 ~49 ~-25 ~17 minecraft:air
setblock ~50 ~-25 ~17 minecraft:light_gray_concrete
fill ~51 ~-25 ~17 ~63 ~-25 ~17 minecraft:air
setblock ~64 ~-25 ~17 minecraft:light_gray_concrete
fill ~4 ~-25 ~18 ~32 ~-25 ~18 minecraft:light_gray_concrete
fill ~33 ~-25 ~18 ~35 ~-25 ~18 minecraft:air
fill ~36 ~-25 ~18 ~64 ~-25 ~18 minecraft:light_gray_concrete
setblock ~4 ~-25 ~19 minecraft:light_gray_concrete
fill ~5 ~-25 ~19 ~7 ~-25 ~19 minecraft:packed_ice
setblock ~8 ~-25 ~19 minecraft:air
setblock ~9 ~-25 ~19 minecraft:packed_ice
fill ~10 ~-25 ~19 ~12 ~-25 ~19 minecraft:air
fill ~13 ~-25 ~19 ~15 ~-25 ~19 minecraft:packed_ice
setblock ~16 ~-25 ~19 minecraft:air
setblock ~17 ~-25 ~19 minecraft:packed_ice
setblock ~18 ~-25 ~19 minecraft:light_gray_concrete
fill ~19 ~-25 ~19 ~31 ~-25 ~19 minecraft:air
setblock ~32 ~-25 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-25 ~19 ~35 ~-25 ~19 minecraft:air
setblock ~36 ~-25 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~19 ~49 ~-25 ~19 minecraft:air
setblock ~50 ~-25 ~19 minecraft:light_gray_concrete
fill ~51 ~-25 ~19 ~63 ~-25 ~19 minecraft:air
setblock ~64 ~-25 ~19 minecraft:light_gray_concrete
setblock ~4 ~-25 ~20 minecraft:light_gray_concrete
setblock ~5 ~-25 ~20 minecraft:packed_ice
fill ~6 ~-25 ~20 ~16 ~-25 ~20 minecraft:air
setblock ~17 ~-25 ~20 minecraft:packed_ice
setblock ~18 ~-25 ~20 minecraft:light_gray_concrete
setblock ~19 ~-25 ~20 minecraft:air
fill ~20 ~-25 ~20 ~22 ~-25 ~20 minecraft:glass
setblock ~23 ~-25 ~20 minecraft:air
fill ~24 ~-25 ~20 ~26 ~-25 ~20 minecraft:glass
fill ~27 ~-25 ~20 ~31 ~-25 ~20 minecraft:air
setblock ~32 ~-25 ~20 minecraft:light_gray_concrete
fill ~33 ~-25 ~20 ~35 ~-25 ~20 minecraft:air
setblock ~36 ~-25 ~20 minecraft:light_gray_concrete
fill ~37 ~-25 ~20 ~49 ~-25 ~20 minecraft:air
setblock ~50 ~-25 ~20 minecraft:light_gray_concrete
fill ~51 ~-25 ~20 ~63 ~-25 ~20 minecraft:air
setblock ~64 ~-25 ~20 minecraft:light_gray_concrete
setblock ~4 ~-25 ~21 minecraft:light_gray_concrete
setblock ~5 ~-25 ~21 minecraft:packed_ice
fill ~6 ~-25 ~21 ~16 ~-25 ~21 minecraft:air
setblock ~17 ~-25 ~21 minecraft:packed_ice
setblock ~18 ~-25 ~21 minecraft:light_gray_concrete
setblock ~19 ~-25 ~21 minecraft:air
setblock ~20 ~-25 ~21 minecraft:glass
setblock ~21 ~-25 ~21 minecraft:air
setblock ~22 ~-25 ~21 minecraft:glass
setblock ~23 ~-25 ~21 minecraft:air
setblock ~24 ~-25 ~21 minecraft:glass
setblock ~25 ~-25 ~21 minecraft:air
setblock ~26 ~-25 ~21 minecraft:glass
fill ~27 ~-25 ~21 ~31 ~-25 ~21 minecraft:air
setblock ~32 ~-25 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-25 ~21 ~35 ~-25 ~21 minecraft:air
setblock ~36 ~-25 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~21 ~49 ~-25 ~21 minecraft:air
setblock ~50 ~-25 ~21 minecraft:light_gray_concrete
fill ~51 ~-25 ~21 ~63 ~-25 ~21 minecraft:air
setblock ~64 ~-25 ~21 minecraft:light_gray_concrete
setblock ~4 ~-25 ~22 minecraft:light_gray_concrete
fill ~5 ~-25 ~22 ~17 ~-25 ~22 minecraft:air
setblock ~18 ~-25 ~22 minecraft:light_gray_concrete
setblock ~19 ~-25 ~22 minecraft:air
fill ~20 ~-25 ~22 ~22 ~-25 ~22 minecraft:glass
setblock ~23 ~-25 ~22 minecraft:air
fill ~24 ~-25 ~22 ~26 ~-25 ~22 minecraft:glass
fill ~27 ~-25 ~22 ~28 ~-25 ~22 minecraft:air
setblock ~29 ~-25 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-25 ~22 minecraft:quartz_pillar
setblock ~31 ~-25 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-25 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-25 ~22 ~35 ~-25 ~22 minecraft:air
setblock ~36 ~-25 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-25 ~22 ~38 ~-25 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-25 ~22 minecraft:quartz_pillar
fill ~40 ~-25 ~22 ~49 ~-25 ~22 minecraft:air
setblock ~50 ~-25 ~22 minecraft:light_gray_concrete
fill ~51 ~-25 ~22 ~63 ~-25 ~22 minecraft:air
setblock ~64 ~-25 ~22 minecraft:light_gray_concrete
setblock ~4 ~-25 ~23 minecraft:light_gray_concrete
setblock ~5 ~-25 ~23 minecraft:packed_ice
fill ~6 ~-25 ~23 ~16 ~-25 ~23 minecraft:air
setblock ~17 ~-25 ~23 minecraft:packed_ice
setblock ~18 ~-25 ~23 minecraft:light_gray_concrete
fill ~19 ~-25 ~23 ~27 ~-25 ~23 minecraft:air
setblock ~28 ~-25 ~23 minecraft:smooth_quartz
setblock ~29 ~-25 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-25 ~23 ~38 ~-25 ~23 minecraft:air
setblock ~39 ~-25 ~23 minecraft:quartz_pillar
setblock ~40 ~-25 ~23 minecraft:smooth_quartz
fill ~41 ~-25 ~23 ~49 ~-25 ~23 minecraft:air
setblock ~50 ~-25 ~23 minecraft:light_gray_concrete
fill ~51 ~-25 ~23 ~63 ~-25 ~23 minecraft:air
setblock ~64 ~-25 ~23 minecraft:light_gray_concrete
setblock ~4 ~-25 ~24 minecraft:light_gray_concrete
setblock ~5 ~-25 ~24 minecraft:packed_ice
fill ~6 ~-25 ~24 ~16 ~-25 ~24 minecraft:air
setblock ~17 ~-25 ~24 minecraft:packed_ice
setblock ~18 ~-25 ~24 minecraft:light_gray_concrete
setblock ~19 ~-25 ~24 minecraft:air
fill ~20 ~-25 ~24 ~22 ~-25 ~24 minecraft:glass
fill ~23 ~-25 ~24 ~25 ~-25 ~24 minecraft:air
setblock ~26 ~-25 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-25 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-25 ~24 ~29 ~-25 ~24 minecraft:air
setblock ~30 ~-25 ~24 minecraft:quartz_pillar
fill ~31 ~-25 ~24 ~37 ~-25 ~24 minecraft:air
setblock ~38 ~-25 ~24 minecraft:quartz_pillar
fill ~39 ~-25 ~24 ~40 ~-25 ~24 minecraft:air
setblock ~41 ~-25 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-25 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-25 ~24 ~49 ~-25 ~24 minecraft:air
setblock ~50 ~-25 ~24 minecraft:light_gray_concrete
fill ~51 ~-25 ~24 ~63 ~-25 ~24 minecraft:air
setblock ~64 ~-25 ~24 minecraft:light_gray_concrete
setblock ~4 ~-25 ~25 minecraft:light_gray_concrete
setblock ~5 ~-25 ~25 minecraft:packed_ice
fill ~6 ~-25 ~25 ~16 ~-25 ~25 minecraft:air
setblock ~17 ~-25 ~25 minecraft:packed_ice
setblock ~18 ~-25 ~25 minecraft:light_gray_concrete
setblock ~19 ~-25 ~25 minecraft:air
setblock ~20 ~-25 ~25 minecraft:glass
setblock ~21 ~-25 ~25 minecraft:air
setblock ~22 ~-25 ~25 minecraft:glass
fill ~23 ~-25 ~25 ~24 ~-25 ~25 minecraft:air
fill ~25 ~-25 ~25 ~26 ~-25 ~25 minecraft:quartz_pillar
fill ~27 ~-25 ~25 ~41 ~-25 ~25 minecraft:air
setblock ~42 ~-25 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-25 ~25 minecraft:quartz_pillar
fill ~44 ~-25 ~25 ~49 ~-25 ~25 minecraft:air
setblock ~50 ~-25 ~25 minecraft:light_gray_concrete
fill ~51 ~-25 ~25 ~63 ~-25 ~25 minecraft:air
setblock ~64 ~-25 ~25 minecraft:light_gray_concrete
setblock ~4 ~-25 ~26 minecraft:light_gray_concrete
fill ~5 ~-25 ~26 ~17 ~-25 ~26 minecraft:air
setblock ~18 ~-25 ~26 minecraft:light_gray_concrete
setblock ~19 ~-25 ~26 minecraft:air
fill ~20 ~-25 ~26 ~22 ~-25 ~26 minecraft:glass
setblock ~23 ~-25 ~26 minecraft:air
setblock ~24 ~-25 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-25 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-25 ~26 ~42 ~-25 ~26 minecraft:air
setblock ~43 ~-25 ~26 minecraft:quartz_pillar
setblock ~44 ~-25 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-25 ~26 ~49 ~-25 ~26 minecraft:air
setblock ~50 ~-25 ~26 minecraft:light_gray_concrete
fill ~51 ~-25 ~26 ~63 ~-25 ~26 minecraft:air
setblock ~64 ~-25 ~26 minecraft:light_gray_concrete
setblock ~4 ~-25 ~27 minecraft:light_gray_concrete
setblock ~5 ~-25 ~27 minecraft:packed_ice
fill ~6 ~-25 ~27 ~16 ~-25 ~27 minecraft:air
setblock ~17 ~-25 ~27 minecraft:packed_ice
setblock ~18 ~-25 ~27 minecraft:light_gray_concrete
fill ~19 ~-25 ~27 ~23 ~-25 ~27 minecraft:air
setblock ~24 ~-25 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-25 ~27 ~43 ~-25 ~27 minecraft:air
setblock ~44 ~-25 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-25 ~27 ~49 ~-25 ~27 minecraft:air
setblock ~50 ~-25 ~27 minecraft:light_gray_concrete
fill ~51 ~-25 ~27 ~63 ~-25 ~27 minecraft:air
setblock ~64 ~-25 ~27 minecraft:light_gray_concrete
setblock ~4 ~-25 ~28 minecraft:light_gray_concrete
setblock ~5 ~-25 ~28 minecraft:packed_ice
fill ~6 ~-25 ~28 ~16 ~-25 ~28 minecraft:air
setblock ~17 ~-25 ~28 minecraft:packed_ice
setblock ~18 ~-25 ~28 minecraft:light_gray_concrete
fill ~19 ~-25 ~28 ~22 ~-25 ~28 minecraft:air
setblock ~23 ~-25 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-25 ~28 ~44 ~-25 ~28 minecraft:air
setblock ~45 ~-25 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-25 ~28 ~49 ~-25 ~28 minecraft:air
setblock ~50 ~-25 ~28 minecraft:light_gray_concrete
fill ~51 ~-25 ~28 ~63 ~-25 ~28 minecraft:air
setblock ~64 ~-25 ~28 minecraft:light_gray_concrete
setblock ~4 ~-25 ~29 minecraft:light_gray_concrete
setblock ~5 ~-25 ~29 minecraft:packed_ice
fill ~6 ~-25 ~29 ~16 ~-25 ~29 minecraft:air
setblock ~17 ~-25 ~29 minecraft:packed_ice
setblock ~18 ~-25 ~29 minecraft:light_gray_concrete
fill ~19 ~-25 ~29 ~21 ~-25 ~29 minecraft:air
fill ~22 ~-25 ~29 ~23 ~-25 ~29 minecraft:quartz_pillar
fill ~24 ~-25 ~29 ~44 ~-25 ~29 minecraft:air
setblock ~45 ~-25 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-25 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-25 ~29 ~49 ~-25 ~29 minecraft:air
setblock ~50 ~-25 ~29 minecraft:light_gray_concrete
fill ~51 ~-25 ~29 ~63 ~-25 ~29 minecraft:air
setblock ~64 ~-25 ~29 minecraft:light_gray_concrete
setblock ~4 ~-25 ~30 minecraft:light_gray_concrete
fill ~5 ~-25 ~30 ~17 ~-25 ~30 minecraft:air
setblock ~18 ~-25 ~30 minecraft:light_gray_concrete
fill ~19 ~-25 ~30 ~21 ~-25 ~30 minecraft:air
setblock ~22 ~-25 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-25 ~30 minecraft:air
setblock ~24 ~-25 ~30 minecraft:quartz_pillar
fill ~25 ~-25 ~30 ~43 ~-25 ~30 minecraft:air
setblock ~44 ~-25 ~30 minecraft:quartz_pillar
setblock ~45 ~-25 ~30 minecraft:air
setblock ~46 ~-25 ~30 minecraft:quartz_pillar
fill ~47 ~-25 ~30 ~49 ~-25 ~30 minecraft:air
setblock ~50 ~-25 ~30 minecraft:light_gray_concrete
fill ~51 ~-25 ~30 ~63 ~-25 ~30 minecraft:air
setblock ~64 ~-25 ~30 minecraft:light_gray_concrete
setblock ~4 ~-25 ~31 minecraft:light_gray_concrete
fill ~5 ~-25 ~31 ~7 ~-25 ~31 minecraft:packed_ice
setblock ~8 ~-25 ~31 minecraft:air
setblock ~9 ~-25 ~31 minecraft:packed_ice
fill ~10 ~-25 ~31 ~12 ~-25 ~31 minecraft:air
fill ~13 ~-25 ~31 ~15 ~-25 ~31 minecraft:packed_ice
setblock ~16 ~-25 ~31 minecraft:air
setblock ~17 ~-25 ~31 minecraft:packed_ice
setblock ~18 ~-25 ~31 minecraft:light_gray_concrete
fill ~19 ~-25 ~31 ~21 ~-25 ~31 minecraft:air
setblock ~22 ~-25 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-25 ~31 ~45 ~-25 ~31 minecraft:air
setblock ~46 ~-25 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-25 ~31 ~49 ~-25 ~31 minecraft:air
setblock ~50 ~-25 ~31 minecraft:light_gray_concrete
fill ~51 ~-25 ~31 ~63 ~-25 ~31 minecraft:air
setblock ~64 ~-25 ~31 minecraft:light_gray_concrete
fill ~4 ~-25 ~32 ~18 ~-25 ~32 minecraft:light_gray_concrete
setblock ~19 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-25 ~32 minecraft:light_gray_concrete
setblock ~21 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-25 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-25 ~32 ~32 ~-25 ~32 minecraft:air
fill ~33 ~-25 ~32 ~35 ~-25 ~32 minecraft:glass
fill ~36 ~-25 ~32 ~45 ~-25 ~32 minecraft:air
setblock ~46 ~-25 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-25 ~32 minecraft:light_gray_concrete
setblock ~49 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~50 ~-25 ~32 minecraft:light_gray_concrete
fill ~51 ~-25 ~32 ~53 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~54 ~-25 ~32 minecraft:light_gray_concrete
fill ~55 ~-25 ~32 ~56 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
fill ~57 ~-25 ~32 ~58 ~-25 ~32 minecraft:light_gray_concrete
fill ~59 ~-25 ~32 ~61 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~62 ~-25 ~32 minecraft:light_gray_concrete
setblock ~63 ~-25 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~64 ~-25 ~32 minecraft:light_gray_concrete
setblock ~4 ~-25 ~33 minecraft:light_gray_concrete
fill ~5 ~-25 ~33 ~32 ~-25 ~33 minecraft:air
setblock ~33 ~-25 ~33 minecraft:glass
setblock ~34 ~-25 ~33 minecraft:air
setblock ~35 ~-25 ~33 minecraft:glass
fill ~36 ~-25 ~33 ~63 ~-25 ~33 minecraft:air
setblock ~64 ~-25 ~33 minecraft:light_gray_concrete
setblock ~4 ~-25 ~34 minecraft:light_gray_concrete
fill ~5 ~-25 ~34 ~32 ~-25 ~34 minecraft:air
fill ~33 ~-25 ~34 ~35 ~-25 ~34 minecraft:glass
fill ~36 ~-25 ~34 ~63 ~-25 ~34 minecraft:air
setblock ~64 ~-25 ~34 minecraft:light_gray_concrete
setblock ~4 ~-25 ~35 minecraft:light_gray_concrete
fill ~5 ~-25 ~35 ~32 ~-25 ~35 minecraft:air
setblock ~33 ~-25 ~35 minecraft:glass
setblock ~34 ~-25 ~35 minecraft:air
setblock ~35 ~-25 ~35 minecraft:glass
fill ~36 ~-25 ~35 ~63 ~-25 ~35 minecraft:air
setblock ~64 ~-25 ~35 minecraft:light_gray_concrete
fill ~4 ~-25 ~36 ~18 ~-25 ~36 minecraft:light_gray_concrete
setblock ~19 ~-25 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-25 ~36 minecraft:light_gray_concrete
setblock ~21 ~-25 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-25 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-25 ~36 ~32 ~-25 ~36 minecraft:air
fill ~33 ~-25 ~36 ~35 ~-25 ~36 minecraft:glass
fill ~36 ~-25 ~36 ~45 ~-25 ~36 minecraft:air
setblock ~46 ~-25 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-25 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-25 ~36 minecraft:light_gray_concrete
setblock ~49 ~-25 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-25 ~36 ~64 ~-25 ~36 minecraft:light_gray_concrete
setblock ~4 ~-25 ~37 minecraft:light_gray_concrete
fill ~5 ~-25 ~37 ~17 ~-25 ~37 minecraft:air
setblock ~18 ~-25 ~37 minecraft:light_gray_concrete
fill ~19 ~-25 ~37 ~21 ~-25 ~37 minecraft:air
setblock ~22 ~-25 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-25 ~37 ~45 ~-25 ~37 minecraft:air
setblock ~46 ~-25 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-25 ~37 ~49 ~-25 ~37 minecraft:air
setblock ~50 ~-25 ~37 minecraft:light_gray_concrete
fill ~51 ~-25 ~37 ~53 ~-25 ~37 minecraft:packed_ice
setblock ~54 ~-25 ~37 minecraft:air
setblock ~55 ~-25 ~37 minecraft:packed_ice
fill ~56 ~-25 ~37 ~58 ~-25 ~37 minecraft:air
fill ~59 ~-25 ~37 ~61 ~-25 ~37 minecraft:packed_ice
setblock ~62 ~-25 ~37 minecraft:air
setblock ~63 ~-25 ~37 minecraft:packed_ice
setblock ~64 ~-25 ~37 minecraft:light_gray_concrete
setblock ~4 ~-25 ~38 minecraft:light_gray_concrete
fill ~5 ~-25 ~38 ~17 ~-25 ~38 minecraft:air
setblock ~18 ~-25 ~38 minecraft:light_gray_concrete
fill ~19 ~-25 ~38 ~21 ~-25 ~38 minecraft:air
setblock ~22 ~-25 ~38 minecraft:quartz_pillar
setblock ~23 ~-25 ~38 minecraft:air
setblock ~24 ~-25 ~38 minecraft:quartz_pillar
fill ~25 ~-25 ~38 ~43 ~-25 ~38 minecraft:air
setblock ~44 ~-25 ~38 minecraft:quartz_pillar
setblock ~45 ~-25 ~38 minecraft:air
setblock ~46 ~-25 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-25 ~38 ~49 ~-25 ~38 minecraft:air
setblock ~50 ~-25 ~38 minecraft:light_gray_concrete
setblock ~51 ~-25 ~38 minecraft:packed_ice
fill ~52 ~-25 ~38 ~62 ~-25 ~38 minecraft:air
setblock ~63 ~-25 ~38 minecraft:packed_ice
setblock ~64 ~-25 ~38 minecraft:light_gray_concrete
setblock ~4 ~-25 ~39 minecraft:light_gray_concrete
fill ~5 ~-25 ~39 ~17 ~-25 ~39 minecraft:air
setblock ~18 ~-25 ~39 minecraft:light_gray_concrete
fill ~19 ~-25 ~39 ~21 ~-25 ~39 minecraft:air
setblock ~22 ~-25 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-25 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-25 ~39 ~44 ~-25 ~39 minecraft:air
fill ~45 ~-25 ~39 ~46 ~-25 ~39 minecraft:quartz_pillar
fill ~47 ~-25 ~39 ~49 ~-25 ~39 minecraft:air
setblock ~50 ~-25 ~39 minecraft:light_gray_concrete
setblock ~51 ~-25 ~39 minecraft:packed_ice
fill ~52 ~-25 ~39 ~62 ~-25 ~39 minecraft:air
setblock ~63 ~-25 ~39 minecraft:packed_ice
setblock ~64 ~-25 ~39 minecraft:light_gray_concrete
setblock ~4 ~-25 ~40 minecraft:light_gray_concrete
fill ~5 ~-25 ~40 ~17 ~-25 ~40 minecraft:air
setblock ~18 ~-25 ~40 minecraft:light_gray_concrete
fill ~19 ~-25 ~40 ~22 ~-25 ~40 minecraft:air
setblock ~23 ~-25 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-25 ~40 ~44 ~-25 ~40 minecraft:air
setblock ~45 ~-25 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-25 ~40 ~49 ~-25 ~40 minecraft:air
setblock ~50 ~-25 ~40 minecraft:light_gray_concrete
fill ~51 ~-25 ~40 ~63 ~-25 ~40 minecraft:air
setblock ~64 ~-25 ~40 minecraft:light_gray_concrete
setblock ~4 ~-25 ~41 minecraft:light_gray_concrete
fill ~5 ~-25 ~41 ~17 ~-25 ~41 minecraft:air
setblock ~18 ~-25 ~41 minecraft:light_gray_concrete
fill ~19 ~-25 ~41 ~23 ~-25 ~41 minecraft:air
setblock ~24 ~-25 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-25 ~41 ~43 ~-25 ~41 minecraft:air
setblock ~44 ~-25 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-25 ~41 ~49 ~-25 ~41 minecraft:air
setblock ~50 ~-25 ~41 minecraft:light_gray_concrete
setblock ~51 ~-25 ~41 minecraft:packed_ice
fill ~52 ~-25 ~41 ~62 ~-25 ~41 minecraft:air
setblock ~63 ~-25 ~41 minecraft:packed_ice
setblock ~64 ~-25 ~41 minecraft:light_gray_concrete
setblock ~4 ~-25 ~42 minecraft:light_gray_concrete
setblock ~5 ~-25 ~42 minecraft:black_concrete
fill ~6 ~-25 ~42 ~17 ~-25 ~42 minecraft:air
setblock ~18 ~-25 ~42 minecraft:light_gray_concrete
fill ~19 ~-25 ~42 ~21 ~-25 ~42 minecraft:air
setblock ~22 ~-25 ~42 minecraft:glass
setblock ~23 ~-25 ~42 minecraft:air
setblock ~24 ~-25 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-25 ~42 minecraft:quartz_pillar
fill ~26 ~-25 ~42 ~42 ~-25 ~42 minecraft:air
setblock ~43 ~-25 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-25 ~42 minecraft:glass_pane[north=true,west=true]
setblock ~45 ~-25 ~42 minecraft:air
fill ~46 ~-25 ~42 ~48 ~-25 ~42 minecraft:glass
setblock ~49 ~-25 ~42 minecraft:air
setblock ~50 ~-25 ~42 minecraft:light_gray_concrete
setblock ~51 ~-25 ~42 minecraft:packed_ice
fill ~52 ~-25 ~42 ~62 ~-25 ~42 minecraft:air
setblock ~63 ~-25 ~42 minecraft:packed_ice
setblock ~64 ~-25 ~42 minecraft:light_gray_concrete
setblock ~4 ~-25 ~43 minecraft:light_gray_concrete
setblock ~5 ~-25 ~43 minecraft:black_concrete
fill ~6 ~-25 ~43 ~17 ~-25 ~43 minecraft:air
setblock ~18 ~-25 ~43 minecraft:light_gray_concrete
fill ~19 ~-25 ~43 ~24 ~-25 ~43 minecraft:air
setblock ~25 ~-25 ~43 minecraft:quartz_pillar
setblock ~26 ~-25 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-25 ~43 ~41 ~-25 ~43 minecraft:air
fill ~42 ~-25 ~43 ~43 ~-25 ~43 minecraft:quartz_pillar
fill ~44 ~-25 ~43 ~45 ~-25 ~43 minecraft:air
setblock ~46 ~-25 ~43 minecraft:glass
setblock ~47 ~-25 ~43 minecraft:air
setblock ~48 ~-25 ~43 minecraft:glass
setblock ~49 ~-25 ~43 minecraft:air
setblock ~50 ~-25 ~43 minecraft:light_gray_concrete
setblock ~51 ~-25 ~43 minecraft:packed_ice
fill ~52 ~-25 ~43 ~62 ~-25 ~43 minecraft:air
setblock ~63 ~-25 ~43 minecraft:packed_ice
setblock ~64 ~-25 ~43 minecraft:light_gray_concrete
setblock ~4 ~-25 ~44 minecraft:light_gray_concrete
setblock ~5 ~-25 ~44 minecraft:black_concrete
fill ~6 ~-25 ~44 ~17 ~-25 ~44 minecraft:air
setblock ~18 ~-25 ~44 minecraft:light_gray_concrete
fill ~19 ~-25 ~44 ~25 ~-25 ~44 minecraft:air
setblock ~26 ~-25 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-25 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-25 ~44 ~29 ~-25 ~44 minecraft:air
setblock ~30 ~-25 ~44 minecraft:quartz_pillar
fill ~31 ~-25 ~44 ~37 ~-25 ~44 minecraft:air
setblock ~38 ~-25 ~44 minecraft:quartz_pillar
fill ~39 ~-25 ~44 ~40 ~-25 ~44 minecraft:air
setblock ~41 ~-25 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-25 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-25 ~44 ~45 ~-25 ~44 minecraft:air
fill ~46 ~-25 ~44 ~48 ~-25 ~44 minecraft:glass
setblock ~49 ~-25 ~44 minecraft:air
setblock ~50 ~-25 ~44 minecraft:light_gray_concrete
fill ~51 ~-25 ~44 ~63 ~-25 ~44 minecraft:air
setblock ~64 ~-25 ~44 minecraft:light_gray_concrete
setblock ~4 ~-25 ~45 minecraft:light_gray_concrete
fill ~5 ~-25 ~45 ~17 ~-25 ~45 minecraft:air
setblock ~18 ~-25 ~45 minecraft:light_gray_concrete
fill ~19 ~-25 ~45 ~27 ~-25 ~45 minecraft:air
setblock ~28 ~-25 ~45 minecraft:smooth_quartz
setblock ~29 ~-25 ~45 minecraft:quartz_pillar
fill ~30 ~-25 ~45 ~38 ~-25 ~45 minecraft:air
setblock ~39 ~-25 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-25 ~45 minecraft:smooth_quartz
fill ~41 ~-25 ~45 ~49 ~-25 ~45 minecraft:air
setblock ~50 ~-25 ~45 minecraft:light_gray_concrete
setblock ~51 ~-25 ~45 minecraft:packed_ice
fill ~52 ~-25 ~45 ~62 ~-25 ~45 minecraft:air
setblock ~63 ~-25 ~45 minecraft:packed_ice
setblock ~64 ~-25 ~45 minecraft:light_gray_concrete
setblock ~4 ~-25 ~46 minecraft:light_gray_concrete
fill ~5 ~-25 ~46 ~17 ~-25 ~46 minecraft:air
setblock ~18 ~-25 ~46 minecraft:light_gray_concrete
fill ~19 ~-25 ~46 ~21 ~-25 ~46 minecraft:air
setblock ~22 ~-25 ~46 minecraft:glass
fill ~23 ~-25 ~46 ~28 ~-25 ~46 minecraft:air
setblock ~29 ~-25 ~46 minecraft:quartz_pillar
fill ~30 ~-25 ~46 ~31 ~-25 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-25 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-25 ~46 ~35 ~-25 ~46 minecraft:air
setblock ~36 ~-25 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-25 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-25 ~46 minecraft:quartz_pillar
setblock ~39 ~-25 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-25 ~46 ~41 ~-25 ~46 minecraft:air
fill ~42 ~-25 ~46 ~44 ~-25 ~46 minecraft:glass
setblock ~45 ~-25 ~46 minecraft:air
fill ~46 ~-25 ~46 ~48 ~-25 ~46 minecraft:glass
setblock ~49 ~-25 ~46 minecraft:air
setblock ~50 ~-25 ~46 minecraft:light_gray_concrete
setblock ~51 ~-25 ~46 minecraft:packed_ice
fill ~52 ~-25 ~46 ~62 ~-25 ~46 minecraft:air
setblock ~63 ~-25 ~46 minecraft:packed_ice
setblock ~64 ~-25 ~46 minecraft:light_gray_concrete
setblock ~4 ~-25 ~47 minecraft:light_gray_concrete
fill ~5 ~-25 ~47 ~17 ~-25 ~47 minecraft:air
setblock ~18 ~-25 ~47 minecraft:light_gray_concrete
fill ~19 ~-25 ~47 ~31 ~-25 ~47 minecraft:air
setblock ~32 ~-25 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-25 ~47 ~35 ~-25 ~47 minecraft:air
setblock ~36 ~-25 ~47 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~47 ~41 ~-25 ~47 minecraft:air
setblock ~42 ~-25 ~47 minecraft:glass
setblock ~43 ~-25 ~47 minecraft:air
setblock ~44 ~-25 ~47 minecraft:glass
setblock ~45 ~-25 ~47 minecraft:air
setblock ~46 ~-25 ~47 minecraft:glass
setblock ~47 ~-25 ~47 minecraft:air
setblock ~48 ~-25 ~47 minecraft:glass
setblock ~49 ~-25 ~47 minecraft:air
setblock ~50 ~-25 ~47 minecraft:light_gray_concrete
setblock ~51 ~-25 ~47 minecraft:packed_ice
fill ~52 ~-25 ~47 ~62 ~-25 ~47 minecraft:air
setblock ~63 ~-25 ~47 minecraft:packed_ice
setblock ~64 ~-25 ~47 minecraft:light_gray_concrete
setblock ~4 ~-25 ~48 minecraft:light_gray_concrete
fill ~5 ~-25 ~48 ~17 ~-25 ~48 minecraft:air
setblock ~18 ~-25 ~48 minecraft:light_gray_concrete
fill ~19 ~-25 ~48 ~31 ~-25 ~48 minecraft:air
setblock ~32 ~-25 ~48 minecraft:light_gray_concrete
fill ~33 ~-25 ~48 ~35 ~-25 ~48 minecraft:air
setblock ~36 ~-25 ~48 minecraft:light_gray_concrete
fill ~37 ~-25 ~48 ~41 ~-25 ~48 minecraft:air
fill ~42 ~-25 ~48 ~44 ~-25 ~48 minecraft:glass
setblock ~45 ~-25 ~48 minecraft:air
fill ~46 ~-25 ~48 ~48 ~-25 ~48 minecraft:glass
setblock ~49 ~-25 ~48 minecraft:air
setblock ~50 ~-25 ~48 minecraft:light_gray_concrete
fill ~51 ~-25 ~48 ~63 ~-25 ~48 minecraft:air
setblock ~64 ~-25 ~48 minecraft:light_gray_concrete
setblock ~4 ~-25 ~49 minecraft:light_gray_concrete
fill ~5 ~-25 ~49 ~17 ~-25 ~49 minecraft:air
setblock ~18 ~-25 ~49 minecraft:light_gray_concrete
fill ~19 ~-25 ~49 ~31 ~-25 ~49 minecraft:air
setblock ~32 ~-25 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-25 ~49 ~35 ~-25 ~49 minecraft:air
setblock ~36 ~-25 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-25 ~49 ~49 ~-25 ~49 minecraft:air
setblock ~50 ~-25 ~49 minecraft:light_gray_concrete
fill ~51 ~-25 ~49 ~53 ~-25 ~49 minecraft:packed_ice
setblock ~54 ~-25 ~49 minecraft:air
setblock ~55 ~-25 ~49 minecraft:packed_ice
fill ~56 ~-25 ~49 ~58 ~-25 ~49 minecraft:air
fill ~59 ~-25 ~49 ~61 ~-25 ~49 minecraft:packed_ice
setblock ~62 ~-25 ~49 minecraft:air
setblock ~63 ~-25 ~49 minecraft:packed_ice
setblock ~64 ~-25 ~49 minecraft:light_gray_concrete
fill ~4 ~-25 ~50 ~32 ~-25 ~50 minecraft:light_gray_concrete
fill ~33 ~-25 ~50 ~35 ~-25 ~50 minecraft:air
fill ~36 ~-25 ~50 ~64 ~-25 ~50 minecraft:light_gray_concrete
setblock ~4 ~-25 ~51 minecraft:light_gray_concrete
fill ~5 ~-25 ~51 ~17 ~-25 ~51 minecraft:air
setblock ~18 ~-25 ~51 minecraft:light_gray_concrete
fill ~19 ~-25 ~51 ~31 ~-25 ~51 minecraft:air
setblock ~32 ~-25 ~51 minecraft:light_gray_concrete
fill ~33 ~-25 ~51 ~35 ~-25 ~51 minecraft:air
setblock ~36 ~-25 ~51 minecraft:light_gray_concrete
fill ~37 ~-25 ~51 ~49 ~-25 ~51 minecraft:air
setblock ~50 ~-25 ~51 minecraft:light_gray_concrete
fill ~51 ~-25 ~51 ~63 ~-25 ~51 minecraft:air
setblock ~64 ~-25 ~51 minecraft:light_gray_concrete
setblock ~4 ~-25 ~52 minecraft:light_gray_concrete
fill ~5 ~-25 ~52 ~17 ~-25 ~52 minecraft:air
setblock ~18 ~-25 ~52 minecraft:light_gray_concrete
fill ~19 ~-25 ~52 ~31 ~-25 ~52 minecraft:air
setblock ~32 ~-25 ~52 minecraft:light_gray_concrete
fill ~33 ~-25 ~52 ~35 ~-25 ~52 minecraft:air
setblock ~36 ~-25 ~52 minecraft:light_gray_concrete
fill ~37 ~-25 ~52 ~49 ~-25 ~52 minecraft:air
setblock ~50 ~-25 ~52 minecraft:light_gray_concrete
setblock ~51 ~-25 ~52 minecraft:air
fill ~52 ~-25 ~52 ~55 ~-25 ~52 minecraft:barrel
fill ~56 ~-25 ~52 ~57 ~-25 ~52 minecraft:air
fill ~58 ~-25 ~52 ~60 ~-25 ~52 minecraft:barrel
setblock ~61 ~-25 ~52 minecraft:air
setblock ~62 ~-25 ~52 minecraft:barrel
setblock ~63 ~-25 ~52 minecraft:air
setblock ~64 ~-25 ~52 minecraft:light_gray_concrete
setblock ~4 ~-25 ~53 minecraft:light_gray_concrete
fill ~5 ~-25 ~53 ~17 ~-25 ~53 minecraft:air
setblock ~18 ~-25 ~53 minecraft:light_gray_concrete
fill ~19 ~-25 ~53 ~31 ~-25 ~53 minecraft:air
setblock ~32 ~-25 ~53 minecraft:light_gray_concrete
fill ~33 ~-25 ~53 ~35 ~-25 ~53 minecraft:air
setblock ~36 ~-25 ~53 minecraft:light_gray_concrete
fill ~37 ~-25 ~53 ~49 ~-25 ~53 minecraft:air
setblock ~50 ~-25 ~53 minecraft:light_gray_concrete
fill ~51 ~-25 ~53 ~63 ~-25 ~53 minecraft:air
setblock ~64 ~-25 ~53 minecraft:light_gray_concrete
setblock ~4 ~-25 ~54 minecraft:light_gray_concrete
setblock ~5 ~-25 ~54 minecraft:air
fill ~6 ~-25 ~54 ~10 ~-25 ~54 minecraft:chiseled_bookshelf[facing=south]
setblock ~11 ~-25 ~54 minecraft:air
fill ~12 ~-25 ~54 ~16 ~-25 ~54 minecraft:chiseled_bookshelf[facing=south]
setblock ~17 ~-25 ~54 minecraft:air
setblock ~18 ~-25 ~54 minecraft:light_gray_concrete
fill ~19 ~-25 ~54 ~31 ~-25 ~54 minecraft:air
setblock ~32 ~-25 ~54 minecraft:light_gray_concrete
fill ~33 ~-25 ~54 ~35 ~-25 ~54 minecraft:air
setblock ~36 ~-25 ~54 minecraft:light_gray_concrete
fill ~37 ~-25 ~54 ~49 ~-25 ~54 minecraft:air
setblock ~50 ~-25 ~54 minecraft:light_gray_concrete
fill ~51 ~-25 ~54 ~63 ~-25 ~54 minecraft:air
setblock ~64 ~-25 ~54 minecraft:light_gray_concrete
setblock ~4 ~-25 ~55 minecraft:light_gray_concrete
fill ~5 ~-25 ~55 ~17 ~-25 ~55 minecraft:air
setblock ~18 ~-25 ~55 minecraft:light_gray_concrete
fill ~19 ~-25 ~55 ~31 ~-25 ~55 minecraft:air
setblock ~32 ~-25 ~55 minecraft:light_gray_concrete
fill ~33 ~-25 ~55 ~35 ~-25 ~55 minecraft:air
setblock ~36 ~-25 ~55 minecraft:light_gray_concrete
fill ~37 ~-25 ~55 ~49 ~-25 ~55 minecraft:air
setblock ~50 ~-25 ~55 minecraft:light_gray_concrete
setblock ~51 ~-25 ~55 minecraft:air
fill ~52 ~-25 ~55 ~55 ~-25 ~55 minecraft:barrel
setblock ~56 ~-25 ~55 minecraft:air
fill ~57 ~-25 ~55 ~60 ~-25 ~55 minecraft:barrel
setblock ~61 ~-25 ~55 minecraft:air
setblock ~62 ~-25 ~55 minecraft:barrel
setblock ~63 ~-25 ~55 minecraft:air
setblock ~64 ~-25 ~55 minecraft:light_gray_concrete
setblock ~4 ~-25 ~56 minecraft:light_gray_concrete
fill ~5 ~-25 ~56 ~17 ~-25 ~56 minecraft:air
setblock ~18 ~-25 ~56 minecraft:light_gray_concrete
fill ~19 ~-25 ~56 ~31 ~-25 ~56 minecraft:air
setblock ~32 ~-25 ~56 minecraft:light_gray_concrete
fill ~33 ~-25 ~56 ~35 ~-25 ~56 minecraft:air
setblock ~36 ~-25 ~56 minecraft:light_gray_concrete
fill ~37 ~-25 ~56 ~49 ~-25 ~56 minecraft:air
setblock ~50 ~-25 ~56 minecraft:light_gray_concrete
fill ~51 ~-25 ~56 ~63 ~-25 ~56 minecraft:air
setblock ~64 ~-25 ~56 minecraft:light_gray_concrete
setblock ~4 ~-25 ~57 minecraft:light_gray_concrete
setblock ~5 ~-25 ~57 minecraft:air
fill ~6 ~-25 ~57 ~10 ~-25 ~57 minecraft:chiseled_bookshelf[facing=north]
setblock ~11 ~-25 ~57 minecraft:air
fill ~12 ~-25 ~57 ~15 ~-25 ~57 minecraft:chiseled_bookshelf[facing=north]
fill ~16 ~-25 ~57 ~17 ~-25 ~57 minecraft:air
setblock ~18 ~-25 ~57 minecraft:light_gray_concrete
fill ~19 ~-25 ~57 ~31 ~-25 ~57 minecraft:air
setblock ~32 ~-25 ~57 minecraft:light_gray_concrete
fill ~33 ~-25 ~57 ~35 ~-25 ~57 minecraft:air
setblock ~36 ~-25 ~57 minecraft:light_gray_concrete
fill ~37 ~-25 ~57 ~49 ~-25 ~57 minecraft:air
setblock ~50 ~-25 ~57 minecraft:light_gray_concrete
fill ~51 ~-25 ~57 ~63 ~-25 ~57 minecraft:air
setblock ~64 ~-25 ~57 minecraft:light_gray_concrete
setblock ~4 ~-25 ~58 minecraft:light_gray_concrete
fill ~5 ~-25 ~58 ~17 ~-25 ~58 minecraft:air
setblock ~18 ~-25 ~58 minecraft:light_gray_concrete
fill ~19 ~-25 ~58 ~31 ~-25 ~58 minecraft:air
setblock ~32 ~-25 ~58 minecraft:light_gray_concrete
fill ~33 ~-25 ~58 ~35 ~-25 ~58 minecraft:air
setblock ~36 ~-25 ~58 minecraft:light_gray_concrete
fill ~37 ~-25 ~58 ~49 ~-25 ~58 minecraft:air
setblock ~50 ~-25 ~58 minecraft:light_gray_concrete
setblock ~51 ~-25 ~58 minecraft:air
fill ~52 ~-25 ~58 ~55 ~-25 ~58 minecraft:barrel
setblock ~56 ~-25 ~58 minecraft:air
fill ~57 ~-25 ~58 ~60 ~-25 ~58 minecraft:barrel
setblock ~61 ~-25 ~58 minecraft:air
setblock ~62 ~-25 ~58 minecraft:barrel
setblock ~63 ~-25 ~58 minecraft:air
setblock ~64 ~-25 ~58 minecraft:light_gray_concrete
setblock ~4 ~-25 ~59 minecraft:light_gray_concrete
fill ~5 ~-25 ~59 ~17 ~-25 ~59 minecraft:air
setblock ~18 ~-25 ~59 minecraft:light_gray_concrete
fill ~19 ~-25 ~59 ~31 ~-25 ~59 minecraft:air
setblock ~32 ~-25 ~59 minecraft:light_gray_concrete
fill ~33 ~-25 ~59 ~35 ~-25 ~59 minecraft:air
setblock ~36 ~-25 ~59 minecraft:light_gray_concrete
fill ~37 ~-25 ~59 ~49 ~-25 ~59 minecraft:air
setblock ~50 ~-25 ~59 minecraft:light_gray_concrete
fill ~51 ~-25 ~59 ~63 ~-25 ~59 minecraft:air
setblock ~64 ~-25 ~59 minecraft:light_gray_concrete
setblock ~4 ~-25 ~60 minecraft:light_gray_concrete
setblock ~5 ~-25 ~60 minecraft:air
fill ~6 ~-25 ~60 ~10 ~-25 ~60 minecraft:chiseled_bookshelf[facing=south]
setblock ~11 ~-25 ~60 minecraft:air
fill ~12 ~-25 ~60 ~16 ~-25 ~60 minecraft:chiseled_bookshelf[facing=south]
setblock ~17 ~-25 ~60 minecraft:air
setblock ~18 ~-25 ~60 minecraft:light_gray_concrete
fill ~19 ~-25 ~60 ~31 ~-25 ~60 minecraft:air
setblock ~32 ~-25 ~60 minecraft:light_gray_concrete
fill ~33 ~-25 ~60 ~35 ~-25 ~60 minecraft:air
setblock ~36 ~-25 ~60 minecraft:light_gray_concrete
fill ~37 ~-25 ~60 ~49 ~-25 ~60 minecraft:air
setblock ~50 ~-25 ~60 minecraft:light_gray_concrete
fill ~51 ~-25 ~60 ~63 ~-25 ~60 minecraft:air
setblock ~64 ~-25 ~60 minecraft:light_gray_concrete
setblock ~4 ~-25 ~61 minecraft:light_gray_concrete
fill ~5 ~-25 ~61 ~17 ~-25 ~61 minecraft:air
setblock ~18 ~-25 ~61 minecraft:light_gray_concrete
fill ~19 ~-25 ~61 ~31 ~-25 ~61 minecraft:air
setblock ~32 ~-25 ~61 minecraft:light_gray_concrete
fill ~33 ~-25 ~61 ~35 ~-25 ~61 minecraft:air
setblock ~36 ~-25 ~61 minecraft:light_gray_concrete
fill ~37 ~-25 ~61 ~49 ~-25 ~61 minecraft:air
setblock ~50 ~-25 ~61 minecraft:light_gray_concrete
setblock ~51 ~-25 ~61 minecraft:air
fill ~52 ~-25 ~61 ~55 ~-25 ~61 minecraft:barrel
setblock ~56 ~-25 ~61 minecraft:air
fill ~57 ~-25 ~61 ~60 ~-25 ~61 minecraft:barrel
setblock ~61 ~-25 ~61 minecraft:air
setblock ~62 ~-25 ~61 minecraft:barrel
setblock ~63 ~-25 ~61 minecraft:air
setblock ~64 ~-25 ~61 minecraft:light_gray_concrete
setblock ~4 ~-25 ~62 minecraft:light_gray_concrete
fill ~5 ~-25 ~62 ~17 ~-25 ~62 minecraft:air
setblock ~18 ~-25 ~62 minecraft:light_gray_concrete
fill ~19 ~-25 ~62 ~31 ~-25 ~62 minecraft:air
setblock ~32 ~-25 ~62 minecraft:light_gray_concrete
fill ~33 ~-25 ~62 ~35 ~-25 ~62 minecraft:air
setblock ~36 ~-25 ~62 minecraft:light_gray_concrete
fill ~37 ~-25 ~62 ~49 ~-25 ~62 minecraft:air
setblock ~50 ~-25 ~62 minecraft:light_gray_concrete
fill ~51 ~-25 ~62 ~63 ~-25 ~62 minecraft:air
setblock ~64 ~-25 ~62 minecraft:light_gray_concrete
setblock ~4 ~-25 ~63 minecraft:light_gray_concrete
fill ~5 ~-25 ~63 ~16 ~-25 ~63 minecraft:chiseled_bookshelf[facing=north]
setblock ~17 ~-25 ~63 minecraft:air
setblock ~18 ~-25 ~63 minecraft:light_gray_concrete
fill ~19 ~-25 ~63 ~30 ~-25 ~63 minecraft:chiseled_bookshelf[facing=north]
setblock ~31 ~-25 ~63 minecraft:air
setblock ~32 ~-25 ~63 minecraft:light_gray_concrete
fill ~33 ~-25 ~63 ~35 ~-25 ~63 minecraft:air
setblock ~36 ~-25 ~63 minecraft:light_gray_concrete
fill ~37 ~-25 ~63 ~49 ~-25 ~63 minecraft:air
setblock ~50 ~-25 ~63 minecraft:light_gray_concrete
fill ~51 ~-25 ~63 ~63 ~-25 ~63 minecraft:air
setblock ~64 ~-25 ~63 minecraft:light_gray_concrete
fill ~4 ~-25 ~64 ~64 ~-25 ~64 minecraft:light_gray_concrete
setblock ~34 ~-25 ~65 minecraft:light_gray_concrete
fill ~32 ~-25 ~66 ~36 ~-25 ~66 minecraft:polished_andesite
setblock ~32 ~-25 ~67 minecraft:polished_andesite
fill ~33 ~-25 ~67 ~35 ~-25 ~67 minecraft:air
setblock ~36 ~-25 ~67 minecraft:polished_andesite
setblock ~32 ~-25 ~68 minecraft:polished_andesite
setblock ~33 ~-25 ~68 minecraft:air
setblock ~34 ~-25 ~68 minecraft:quartz_pillar
setblock ~35 ~-25 ~68 minecraft:air
setblock ~36 ~-25 ~68 minecraft:polished_andesite
setblock ~32 ~-25 ~69 minecraft:polished_andesite
fill ~33 ~-25 ~69 ~34 ~-25 ~69 minecraft:air
setblock ~35 ~-25 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-25 ~69 minecraft:polished_andesite
fill ~32 ~-25 ~70 ~36 ~-25 ~70 minecraft:polished_andesite
fill ~4 ~-24 ~4 ~64 ~-24 ~4 minecraft:light_gray_concrete
setblock ~4 ~-24 ~5 minecraft:light_gray_concrete
fill ~5 ~-24 ~5 ~17 ~-24 ~5 minecraft:air
setblock ~18 ~-24 ~5 minecraft:light_gray_concrete
fill ~19 ~-24 ~5 ~31 ~-24 ~5 minecraft:air
setblock ~32 ~-24 ~5 minecraft:light_gray_concrete
fill ~33 ~-24 ~5 ~35 ~-24 ~5 minecraft:air
setblock ~36 ~-24 ~5 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~5 ~49 ~-24 ~5 minecraft:air
setblock ~50 ~-24 ~5 minecraft:light_gray_concrete
fill ~51 ~-24 ~5 ~63 ~-24 ~5 minecraft:air
setblock ~64 ~-24 ~5 minecraft:light_gray_concrete
setblock ~4 ~-24 ~6 minecraft:light_gray_concrete
fill ~5 ~-24 ~6 ~17 ~-24 ~6 minecraft:air
setblock ~18 ~-24 ~6 minecraft:light_gray_concrete
fill ~19 ~-24 ~6 ~31 ~-24 ~6 minecraft:air
setblock ~32 ~-24 ~6 minecraft:light_gray_concrete
fill ~33 ~-24 ~6 ~35 ~-24 ~6 minecraft:air
setblock ~36 ~-24 ~6 minecraft:light_gray_concrete
fill ~37 ~-24 ~6 ~49 ~-24 ~6 minecraft:air
setblock ~50 ~-24 ~6 minecraft:light_gray_concrete
fill ~51 ~-24 ~6 ~63 ~-24 ~6 minecraft:air
setblock ~64 ~-24 ~6 minecraft:light_gray_concrete
setblock ~4 ~-24 ~7 minecraft:light_gray_concrete
fill ~5 ~-24 ~7 ~17 ~-24 ~7 minecraft:air
setblock ~18 ~-24 ~7 minecraft:light_gray_concrete
fill ~19 ~-24 ~7 ~31 ~-24 ~7 minecraft:air
setblock ~32 ~-24 ~7 minecraft:light_gray_concrete
fill ~33 ~-24 ~7 ~35 ~-24 ~7 minecraft:air
setblock ~36 ~-24 ~7 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~7 ~49 ~-24 ~7 minecraft:air
setblock ~50 ~-24 ~7 minecraft:light_gray_concrete
fill ~51 ~-24 ~7 ~63 ~-24 ~7 minecraft:air
setblock ~64 ~-24 ~7 minecraft:light_gray_concrete
setblock ~4 ~-24 ~8 minecraft:light_gray_concrete
fill ~5 ~-24 ~8 ~17 ~-24 ~8 minecraft:air
setblock ~18 ~-24 ~8 minecraft:light_gray_concrete
fill ~19 ~-24 ~8 ~31 ~-24 ~8 minecraft:air
setblock ~32 ~-24 ~8 minecraft:light_gray_concrete
fill ~33 ~-24 ~8 ~35 ~-24 ~8 minecraft:air
setblock ~36 ~-24 ~8 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~8 ~49 ~-24 ~8 minecraft:air
setblock ~50 ~-24 ~8 minecraft:light_gray_concrete
fill ~51 ~-24 ~8 ~63 ~-24 ~8 minecraft:air
setblock ~64 ~-24 ~8 minecraft:light_gray_concrete
setblock ~4 ~-24 ~9 minecraft:light_gray_concrete
fill ~5 ~-24 ~9 ~17 ~-24 ~9 minecraft:air
setblock ~18 ~-24 ~9 minecraft:light_gray_concrete
fill ~19 ~-24 ~9 ~31 ~-24 ~9 minecraft:air
setblock ~32 ~-24 ~9 minecraft:light_gray_concrete
fill ~33 ~-24 ~9 ~35 ~-24 ~9 minecraft:air
setblock ~36 ~-24 ~9 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~9 ~49 ~-24 ~9 minecraft:air
setblock ~50 ~-24 ~9 minecraft:light_gray_concrete
fill ~51 ~-24 ~9 ~63 ~-24 ~9 minecraft:air
setblock ~64 ~-24 ~9 minecraft:light_gray_concrete
setblock ~4 ~-24 ~10 minecraft:light_gray_concrete
fill ~5 ~-24 ~10 ~17 ~-24 ~10 minecraft:air
setblock ~18 ~-24 ~10 minecraft:light_gray_concrete
fill ~19 ~-24 ~10 ~31 ~-24 ~10 minecraft:air
setblock ~32 ~-24 ~10 minecraft:light_gray_concrete
fill ~33 ~-24 ~10 ~35 ~-24 ~10 minecraft:air
setblock ~36 ~-24 ~10 minecraft:light_gray_concrete
fill ~37 ~-24 ~10 ~49 ~-24 ~10 minecraft:air
setblock ~50 ~-24 ~10 minecraft:light_gray_concrete
fill ~51 ~-24 ~10 ~63 ~-24 ~10 minecraft:air
setblock ~64 ~-24 ~10 minecraft:light_gray_concrete
setblock ~4 ~-24 ~11 minecraft:light_gray_concrete
fill ~5 ~-24 ~11 ~17 ~-24 ~11 minecraft:air
setblock ~18 ~-24 ~11 minecraft:light_gray_concrete
fill ~19 ~-24 ~11 ~31 ~-24 ~11 minecraft:air
setblock ~32 ~-24 ~11 minecraft:light_gray_concrete
fill ~33 ~-24 ~11 ~35 ~-24 ~11 minecraft:air
setblock ~36 ~-24 ~11 minecraft:light_gray_concrete
fill ~37 ~-24 ~11 ~49 ~-24 ~11 minecraft:air
setblock ~50 ~-24 ~11 minecraft:light_gray_concrete
fill ~51 ~-24 ~11 ~63 ~-24 ~11 minecraft:air
setblock ~64 ~-24 ~11 minecraft:light_gray_concrete
setblock ~4 ~-24 ~12 minecraft:light_gray_concrete
fill ~5 ~-24 ~12 ~17 ~-24 ~12 minecraft:air
setblock ~18 ~-24 ~12 minecraft:light_gray_concrete
fill ~19 ~-24 ~12 ~31 ~-24 ~12 minecraft:air
setblock ~32 ~-24 ~12 minecraft:light_gray_concrete
fill ~33 ~-24 ~12 ~35 ~-24 ~12 minecraft:air
setblock ~36 ~-24 ~12 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~12 ~49 ~-24 ~12 minecraft:air
setblock ~50 ~-24 ~12 minecraft:light_gray_concrete
fill ~51 ~-24 ~12 ~63 ~-24 ~12 minecraft:air
setblock ~64 ~-24 ~12 minecraft:light_gray_concrete
setblock ~4 ~-24 ~13 minecraft:light_gray_concrete
fill ~5 ~-24 ~13 ~17 ~-24 ~13 minecraft:air
setblock ~18 ~-24 ~13 minecraft:light_gray_concrete
fill ~19 ~-24 ~13 ~31 ~-24 ~13 minecraft:air
setblock ~32 ~-24 ~13 minecraft:light_gray_concrete
fill ~33 ~-24 ~13 ~35 ~-24 ~13 minecraft:air
setblock ~36 ~-24 ~13 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~13 ~49 ~-24 ~13 minecraft:air
setblock ~50 ~-24 ~13 minecraft:light_gray_concrete
fill ~51 ~-24 ~13 ~63 ~-24 ~13 minecraft:air
setblock ~64 ~-24 ~13 minecraft:light_gray_concrete
setblock ~4 ~-24 ~14 minecraft:light_gray_concrete
fill ~5 ~-24 ~14 ~17 ~-24 ~14 minecraft:air
setblock ~18 ~-24 ~14 minecraft:light_gray_concrete
fill ~19 ~-24 ~14 ~31 ~-24 ~14 minecraft:air
setblock ~32 ~-24 ~14 minecraft:light_gray_concrete
fill ~33 ~-24 ~14 ~35 ~-24 ~14 minecraft:air
setblock ~36 ~-24 ~14 minecraft:light_gray_concrete
fill ~37 ~-24 ~14 ~49 ~-24 ~14 minecraft:air
setblock ~50 ~-24 ~14 minecraft:light_gray_concrete
fill ~51 ~-24 ~14 ~63 ~-24 ~14 minecraft:air
setblock ~64 ~-24 ~14 minecraft:light_gray_concrete
setblock ~4 ~-24 ~15 minecraft:light_gray_concrete
fill ~5 ~-24 ~15 ~17 ~-24 ~15 minecraft:air
setblock ~18 ~-24 ~15 minecraft:light_gray_concrete
fill ~19 ~-24 ~15 ~31 ~-24 ~15 minecraft:air
setblock ~32 ~-24 ~15 minecraft:light_gray_concrete
fill ~33 ~-24 ~15 ~35 ~-24 ~15 minecraft:air
setblock ~36 ~-24 ~15 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~15 ~49 ~-24 ~15 minecraft:air
setblock ~50 ~-24 ~15 minecraft:light_gray_concrete
fill ~51 ~-24 ~15 ~63 ~-24 ~15 minecraft:air
setblock ~64 ~-24 ~15 minecraft:light_gray_concrete
setblock ~4 ~-24 ~16 minecraft:light_gray_concrete
fill ~5 ~-24 ~16 ~17 ~-24 ~16 minecraft:air
setblock ~18 ~-24 ~16 minecraft:light_gray_concrete
fill ~19 ~-24 ~16 ~31 ~-24 ~16 minecraft:air
setblock ~32 ~-24 ~16 minecraft:light_gray_concrete
fill ~33 ~-24 ~16 ~35 ~-24 ~16 minecraft:air
setblock ~36 ~-24 ~16 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~16 ~49 ~-24 ~16 minecraft:air
setblock ~50 ~-24 ~16 minecraft:light_gray_concrete
fill ~51 ~-24 ~16 ~63 ~-24 ~16 minecraft:air
setblock ~64 ~-24 ~16 minecraft:light_gray_concrete
setblock ~4 ~-24 ~17 minecraft:light_gray_concrete
fill ~5 ~-24 ~17 ~17 ~-24 ~17 minecraft:air
setblock ~18 ~-24 ~17 minecraft:light_gray_concrete
fill ~19 ~-24 ~17 ~31 ~-24 ~17 minecraft:air
setblock ~32 ~-24 ~17 minecraft:light_gray_concrete
fill ~33 ~-24 ~17 ~35 ~-24 ~17 minecraft:air
setblock ~36 ~-24 ~17 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~17 ~49 ~-24 ~17 minecraft:air
setblock ~50 ~-24 ~17 minecraft:light_gray_concrete
fill ~51 ~-24 ~17 ~63 ~-24 ~17 minecraft:air
setblock ~64 ~-24 ~17 minecraft:light_gray_concrete
fill ~4 ~-24 ~18 ~32 ~-24 ~18 minecraft:light_gray_concrete
fill ~33 ~-24 ~18 ~35 ~-24 ~18 minecraft:air
fill ~36 ~-24 ~18 ~64 ~-24 ~18 minecraft:light_gray_concrete
setblock ~4 ~-24 ~19 minecraft:light_gray_concrete
fill ~5 ~-24 ~19 ~17 ~-24 ~19 minecraft:air
setblock ~18 ~-24 ~19 minecraft:light_gray_concrete
fill ~19 ~-24 ~19 ~31 ~-24 ~19 minecraft:air
setblock ~32 ~-24 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-24 ~19 ~35 ~-24 ~19 minecraft:air
setblock ~36 ~-24 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~19 ~49 ~-24 ~19 minecraft:air
setblock ~50 ~-24 ~19 minecraft:light_gray_concrete
fill ~51 ~-24 ~19 ~63 ~-24 ~19 minecraft:air
setblock ~64 ~-24 ~19 minecraft:light_gray_concrete
setblock ~4 ~-24 ~20 minecraft:light_gray_concrete
fill ~5 ~-24 ~20 ~17 ~-24 ~20 minecraft:air
setblock ~18 ~-24 ~20 minecraft:light_gray_concrete
setblock ~19 ~-24 ~20 minecraft:air
fill ~20 ~-24 ~20 ~22 ~-24 ~20 minecraft:glass
setblock ~23 ~-24 ~20 minecraft:air
fill ~24 ~-24 ~20 ~26 ~-24 ~20 minecraft:glass
fill ~27 ~-24 ~20 ~31 ~-24 ~20 minecraft:air
setblock ~32 ~-24 ~20 minecraft:light_gray_concrete
fill ~33 ~-24 ~20 ~35 ~-24 ~20 minecraft:air
setblock ~36 ~-24 ~20 minecraft:light_gray_concrete
fill ~37 ~-24 ~20 ~49 ~-24 ~20 minecraft:air
setblock ~50 ~-24 ~20 minecraft:light_gray_concrete
fill ~51 ~-24 ~20 ~63 ~-24 ~20 minecraft:air
setblock ~64 ~-24 ~20 minecraft:light_gray_concrete
setblock ~4 ~-24 ~21 minecraft:light_gray_concrete
fill ~5 ~-24 ~21 ~17 ~-24 ~21 minecraft:air
setblock ~18 ~-24 ~21 minecraft:light_gray_concrete
setblock ~19 ~-24 ~21 minecraft:air
setblock ~20 ~-24 ~21 minecraft:glass
setblock ~21 ~-24 ~21 minecraft:air
setblock ~22 ~-24 ~21 minecraft:glass
setblock ~23 ~-24 ~21 minecraft:air
setblock ~24 ~-24 ~21 minecraft:glass
setblock ~25 ~-24 ~21 minecraft:air
setblock ~26 ~-24 ~21 minecraft:glass
fill ~27 ~-24 ~21 ~31 ~-24 ~21 minecraft:air
setblock ~32 ~-24 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-24 ~21 ~35 ~-24 ~21 minecraft:air
setblock ~36 ~-24 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~21 ~49 ~-24 ~21 minecraft:air
setblock ~50 ~-24 ~21 minecraft:light_gray_concrete
fill ~51 ~-24 ~21 ~63 ~-24 ~21 minecraft:air
setblock ~64 ~-24 ~21 minecraft:light_gray_concrete
setblock ~4 ~-24 ~22 minecraft:light_gray_concrete
fill ~5 ~-24 ~22 ~17 ~-24 ~22 minecraft:air
setblock ~18 ~-24 ~22 minecraft:light_gray_concrete
setblock ~19 ~-24 ~22 minecraft:air
fill ~20 ~-24 ~22 ~22 ~-24 ~22 minecraft:glass
setblock ~23 ~-24 ~22 minecraft:air
fill ~24 ~-24 ~22 ~26 ~-24 ~22 minecraft:glass
fill ~27 ~-24 ~22 ~28 ~-24 ~22 minecraft:air
setblock ~29 ~-24 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-24 ~22 minecraft:quartz_pillar
setblock ~31 ~-24 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-24 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-24 ~22 ~35 ~-24 ~22 minecraft:air
setblock ~36 ~-24 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-24 ~22 ~38 ~-24 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-24 ~22 minecraft:quartz_pillar
fill ~40 ~-24 ~22 ~49 ~-24 ~22 minecraft:air
setblock ~50 ~-24 ~22 minecraft:light_gray_concrete
fill ~51 ~-24 ~22 ~63 ~-24 ~22 minecraft:air
setblock ~64 ~-24 ~22 minecraft:light_gray_concrete
setblock ~4 ~-24 ~23 minecraft:light_gray_concrete
fill ~5 ~-24 ~23 ~17 ~-24 ~23 minecraft:air
setblock ~18 ~-24 ~23 minecraft:light_gray_concrete
fill ~19 ~-24 ~23 ~27 ~-24 ~23 minecraft:air
setblock ~28 ~-24 ~23 minecraft:smooth_quartz
setblock ~29 ~-24 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-24 ~23 ~38 ~-24 ~23 minecraft:air
setblock ~39 ~-24 ~23 minecraft:quartz_pillar
setblock ~40 ~-24 ~23 minecraft:smooth_quartz
fill ~41 ~-24 ~23 ~49 ~-24 ~23 minecraft:air
setblock ~50 ~-24 ~23 minecraft:light_gray_concrete
fill ~51 ~-24 ~23 ~63 ~-24 ~23 minecraft:air
setblock ~64 ~-24 ~23 minecraft:light_gray_concrete
setblock ~4 ~-24 ~24 minecraft:light_gray_concrete
fill ~5 ~-24 ~24 ~17 ~-24 ~24 minecraft:air
setblock ~18 ~-24 ~24 minecraft:light_gray_concrete
setblock ~19 ~-24 ~24 minecraft:air
fill ~20 ~-24 ~24 ~22 ~-24 ~24 minecraft:glass
fill ~23 ~-24 ~24 ~25 ~-24 ~24 minecraft:air
setblock ~26 ~-24 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-24 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-24 ~24 ~29 ~-24 ~24 minecraft:air
setblock ~30 ~-24 ~24 minecraft:quartz_pillar
fill ~31 ~-24 ~24 ~37 ~-24 ~24 minecraft:air
setblock ~38 ~-24 ~24 minecraft:quartz_pillar
fill ~39 ~-24 ~24 ~40 ~-24 ~24 minecraft:air
setblock ~41 ~-24 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-24 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-24 ~24 ~49 ~-24 ~24 minecraft:air
setblock ~50 ~-24 ~24 minecraft:light_gray_concrete
fill ~51 ~-24 ~24 ~63 ~-24 ~24 minecraft:air
setblock ~64 ~-24 ~24 minecraft:light_gray_concrete
setblock ~4 ~-24 ~25 minecraft:light_gray_concrete
fill ~5 ~-24 ~25 ~17 ~-24 ~25 minecraft:air
setblock ~18 ~-24 ~25 minecraft:light_gray_concrete
setblock ~19 ~-24 ~25 minecraft:air
setblock ~20 ~-24 ~25 minecraft:glass
setblock ~21 ~-24 ~25 minecraft:air
setblock ~22 ~-24 ~25 minecraft:glass
fill ~23 ~-24 ~25 ~24 ~-24 ~25 minecraft:air
fill ~25 ~-24 ~25 ~26 ~-24 ~25 minecraft:quartz_pillar
fill ~27 ~-24 ~25 ~41 ~-24 ~25 minecraft:air
setblock ~42 ~-24 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-24 ~25 minecraft:quartz_pillar
fill ~44 ~-24 ~25 ~49 ~-24 ~25 minecraft:air
setblock ~50 ~-24 ~25 minecraft:light_gray_concrete
fill ~51 ~-24 ~25 ~63 ~-24 ~25 minecraft:air
setblock ~64 ~-24 ~25 minecraft:light_gray_concrete
setblock ~4 ~-24 ~26 minecraft:light_gray_concrete
fill ~5 ~-24 ~26 ~17 ~-24 ~26 minecraft:air
setblock ~18 ~-24 ~26 minecraft:light_gray_concrete
setblock ~19 ~-24 ~26 minecraft:air
fill ~20 ~-24 ~26 ~22 ~-24 ~26 minecraft:glass
setblock ~23 ~-24 ~26 minecraft:air
setblock ~24 ~-24 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-24 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-24 ~26 ~42 ~-24 ~26 minecraft:air
setblock ~43 ~-24 ~26 minecraft:quartz_pillar
setblock ~44 ~-24 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-24 ~26 ~49 ~-24 ~26 minecraft:air
setblock ~50 ~-24 ~26 minecraft:light_gray_concrete
fill ~51 ~-24 ~26 ~63 ~-24 ~26 minecraft:air
setblock ~64 ~-24 ~26 minecraft:light_gray_concrete
setblock ~4 ~-24 ~27 minecraft:light_gray_concrete
fill ~5 ~-24 ~27 ~17 ~-24 ~27 minecraft:air
setblock ~18 ~-24 ~27 minecraft:light_gray_concrete
fill ~19 ~-24 ~27 ~23 ~-24 ~27 minecraft:air
setblock ~24 ~-24 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-24 ~27 ~43 ~-24 ~27 minecraft:air
setblock ~44 ~-24 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-24 ~27 ~49 ~-24 ~27 minecraft:air
setblock ~50 ~-24 ~27 minecraft:light_gray_concrete
fill ~51 ~-24 ~27 ~63 ~-24 ~27 minecraft:air
setblock ~64 ~-24 ~27 minecraft:light_gray_concrete
setblock ~4 ~-24 ~28 minecraft:light_gray_concrete
fill ~5 ~-24 ~28 ~17 ~-24 ~28 minecraft:air
setblock ~18 ~-24 ~28 minecraft:light_gray_concrete
fill ~19 ~-24 ~28 ~22 ~-24 ~28 minecraft:air
setblock ~23 ~-24 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-24 ~28 ~44 ~-24 ~28 minecraft:air
setblock ~45 ~-24 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-24 ~28 ~49 ~-24 ~28 minecraft:air
setblock ~50 ~-24 ~28 minecraft:light_gray_concrete
fill ~51 ~-24 ~28 ~63 ~-24 ~28 minecraft:air
setblock ~64 ~-24 ~28 minecraft:light_gray_concrete
setblock ~4 ~-24 ~29 minecraft:light_gray_concrete
fill ~5 ~-24 ~29 ~17 ~-24 ~29 minecraft:air
setblock ~18 ~-24 ~29 minecraft:light_gray_concrete
fill ~19 ~-24 ~29 ~21 ~-24 ~29 minecraft:air
fill ~22 ~-24 ~29 ~23 ~-24 ~29 minecraft:quartz_pillar
fill ~24 ~-24 ~29 ~44 ~-24 ~29 minecraft:air
setblock ~45 ~-24 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-24 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-24 ~29 ~49 ~-24 ~29 minecraft:air
setblock ~50 ~-24 ~29 minecraft:light_gray_concrete
fill ~51 ~-24 ~29 ~63 ~-24 ~29 minecraft:air
setblock ~64 ~-24 ~29 minecraft:light_gray_concrete
setblock ~4 ~-24 ~30 minecraft:light_gray_concrete
fill ~5 ~-24 ~30 ~17 ~-24 ~30 minecraft:air
setblock ~18 ~-24 ~30 minecraft:light_gray_concrete
fill ~19 ~-24 ~30 ~21 ~-24 ~30 minecraft:air
setblock ~22 ~-24 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-24 ~30 minecraft:air
setblock ~24 ~-24 ~30 minecraft:quartz_pillar
fill ~25 ~-24 ~30 ~43 ~-24 ~30 minecraft:air
setblock ~44 ~-24 ~30 minecraft:quartz_pillar
setblock ~45 ~-24 ~30 minecraft:air
setblock ~46 ~-24 ~30 minecraft:quartz_pillar
fill ~47 ~-24 ~30 ~49 ~-24 ~30 minecraft:air
setblock ~50 ~-24 ~30 minecraft:light_gray_concrete
fill ~51 ~-24 ~30 ~63 ~-24 ~30 minecraft:air
setblock ~64 ~-24 ~30 minecraft:light_gray_concrete
setblock ~4 ~-24 ~31 minecraft:light_gray_concrete
fill ~5 ~-24 ~31 ~17 ~-24 ~31 minecraft:air
setblock ~18 ~-24 ~31 minecraft:light_gray_concrete
fill ~19 ~-24 ~31 ~21 ~-24 ~31 minecraft:air
setblock ~22 ~-24 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-24 ~31 ~45 ~-24 ~31 minecraft:air
setblock ~46 ~-24 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-24 ~31 ~49 ~-24 ~31 minecraft:air
setblock ~50 ~-24 ~31 minecraft:light_gray_concrete
fill ~51 ~-24 ~31 ~63 ~-24 ~31 minecraft:air
setblock ~64 ~-24 ~31 minecraft:light_gray_concrete
fill ~4 ~-24 ~32 ~18 ~-24 ~32 minecraft:light_gray_concrete
setblock ~19 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-24 ~32 minecraft:light_gray_concrete
setblock ~21 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-24 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-24 ~32 ~32 ~-24 ~32 minecraft:air
fill ~33 ~-24 ~32 ~35 ~-24 ~32 minecraft:glass
fill ~36 ~-24 ~32 ~45 ~-24 ~32 minecraft:air
setblock ~46 ~-24 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-24 ~32 minecraft:light_gray_concrete
setblock ~49 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~50 ~-24 ~32 minecraft:light_gray_concrete
fill ~51 ~-24 ~32 ~53 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~54 ~-24 ~32 minecraft:light_gray_concrete
fill ~55 ~-24 ~32 ~56 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
fill ~57 ~-24 ~32 ~58 ~-24 ~32 minecraft:light_gray_concrete
fill ~59 ~-24 ~32 ~61 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~62 ~-24 ~32 minecraft:light_gray_concrete
setblock ~63 ~-24 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~64 ~-24 ~32 minecraft:light_gray_concrete
setblock ~4 ~-24 ~33 minecraft:light_gray_concrete
fill ~5 ~-24 ~33 ~32 ~-24 ~33 minecraft:air
setblock ~33 ~-24 ~33 minecraft:glass
setblock ~34 ~-24 ~33 minecraft:air
setblock ~35 ~-24 ~33 minecraft:glass
fill ~36 ~-24 ~33 ~63 ~-24 ~33 minecraft:air
setblock ~64 ~-24 ~33 minecraft:light_gray_concrete
setblock ~4 ~-24 ~34 minecraft:light_gray_concrete
fill ~5 ~-24 ~34 ~32 ~-24 ~34 minecraft:air
fill ~33 ~-24 ~34 ~35 ~-24 ~34 minecraft:glass
fill ~36 ~-24 ~34 ~63 ~-24 ~34 minecraft:air
setblock ~64 ~-24 ~34 minecraft:light_gray_concrete
setblock ~4 ~-24 ~35 minecraft:light_gray_concrete
fill ~5 ~-24 ~35 ~32 ~-24 ~35 minecraft:air
setblock ~33 ~-24 ~35 minecraft:glass
setblock ~34 ~-24 ~35 minecraft:air
setblock ~35 ~-24 ~35 minecraft:glass
fill ~36 ~-24 ~35 ~63 ~-24 ~35 minecraft:air
setblock ~64 ~-24 ~35 minecraft:light_gray_concrete
fill ~4 ~-24 ~36 ~18 ~-24 ~36 minecraft:light_gray_concrete
setblock ~19 ~-24 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-24 ~36 minecraft:light_gray_concrete
setblock ~21 ~-24 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-24 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-24 ~36 ~32 ~-24 ~36 minecraft:air
fill ~33 ~-24 ~36 ~35 ~-24 ~36 minecraft:glass
fill ~36 ~-24 ~36 ~45 ~-24 ~36 minecraft:air
setblock ~46 ~-24 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-24 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-24 ~36 minecraft:light_gray_concrete
setblock ~49 ~-24 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-24 ~36 ~64 ~-24 ~36 minecraft:light_gray_concrete
setblock ~4 ~-24 ~37 minecraft:light_gray_concrete
fill ~5 ~-24 ~37 ~17 ~-24 ~37 minecraft:air
setblock ~18 ~-24 ~37 minecraft:light_gray_concrete
fill ~19 ~-24 ~37 ~21 ~-24 ~37 minecraft:air
setblock ~22 ~-24 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-24 ~37 ~45 ~-24 ~37 minecraft:air
setblock ~46 ~-24 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-24 ~37 ~49 ~-24 ~37 minecraft:air
setblock ~50 ~-24 ~37 minecraft:light_gray_concrete
fill ~51 ~-24 ~37 ~63 ~-24 ~37 minecraft:air
setblock ~64 ~-24 ~37 minecraft:light_gray_concrete
setblock ~4 ~-24 ~38 minecraft:light_gray_concrete
fill ~5 ~-24 ~38 ~17 ~-24 ~38 minecraft:air
setblock ~18 ~-24 ~38 minecraft:light_gray_concrete
fill ~19 ~-24 ~38 ~21 ~-24 ~38 minecraft:air
setblock ~22 ~-24 ~38 minecraft:quartz_pillar
setblock ~23 ~-24 ~38 minecraft:air
setblock ~24 ~-24 ~38 minecraft:quartz_pillar
fill ~25 ~-24 ~38 ~43 ~-24 ~38 minecraft:air
setblock ~44 ~-24 ~38 minecraft:quartz_pillar
setblock ~45 ~-24 ~38 minecraft:air
setblock ~46 ~-24 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-24 ~38 ~49 ~-24 ~38 minecraft:air
setblock ~50 ~-24 ~38 minecraft:light_gray_concrete
fill ~51 ~-24 ~38 ~63 ~-24 ~38 minecraft:air
setblock ~64 ~-24 ~38 minecraft:light_gray_concrete
setblock ~4 ~-24 ~39 minecraft:light_gray_concrete
fill ~5 ~-24 ~39 ~17 ~-24 ~39 minecraft:air
setblock ~18 ~-24 ~39 minecraft:light_gray_concrete
fill ~19 ~-24 ~39 ~21 ~-24 ~39 minecraft:air
setblock ~22 ~-24 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-24 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-24 ~39 ~44 ~-24 ~39 minecraft:air
fill ~45 ~-24 ~39 ~46 ~-24 ~39 minecraft:quartz_pillar
fill ~47 ~-24 ~39 ~49 ~-24 ~39 minecraft:air
setblock ~50 ~-24 ~39 minecraft:light_gray_concrete
fill ~51 ~-24 ~39 ~63 ~-24 ~39 minecraft:air
setblock ~64 ~-24 ~39 minecraft:light_gray_concrete
setblock ~4 ~-24 ~40 minecraft:light_gray_concrete
fill ~5 ~-24 ~40 ~17 ~-24 ~40 minecraft:air
setblock ~18 ~-24 ~40 minecraft:light_gray_concrete
fill ~19 ~-24 ~40 ~22 ~-24 ~40 minecraft:air
setblock ~23 ~-24 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-24 ~40 ~44 ~-24 ~40 minecraft:air
setblock ~45 ~-24 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-24 ~40 ~49 ~-24 ~40 minecraft:air
setblock ~50 ~-24 ~40 minecraft:light_gray_concrete
fill ~51 ~-24 ~40 ~63 ~-24 ~40 minecraft:air
setblock ~64 ~-24 ~40 minecraft:light_gray_concrete
setblock ~4 ~-24 ~41 minecraft:light_gray_concrete
fill ~5 ~-24 ~41 ~17 ~-24 ~41 minecraft:air
setblock ~18 ~-24 ~41 minecraft:light_gray_concrete
fill ~19 ~-24 ~41 ~23 ~-24 ~41 minecraft:air
setblock ~24 ~-24 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-24 ~41 ~43 ~-24 ~41 minecraft:air
setblock ~44 ~-24 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-24 ~41 ~49 ~-24 ~41 minecraft:air
setblock ~50 ~-24 ~41 minecraft:light_gray_concrete
fill ~51 ~-24 ~41 ~63 ~-24 ~41 minecraft:air
setblock ~64 ~-24 ~41 minecraft:light_gray_concrete
setblock ~4 ~-24 ~42 minecraft:light_gray_concrete
setblock ~5 ~-24 ~42 minecraft:black_concrete
fill ~6 ~-24 ~42 ~17 ~-24 ~42 minecraft:air
setblock ~18 ~-24 ~42 minecraft:light_gray_concrete
fill ~19 ~-24 ~42 ~23 ~-24 ~42 minecraft:air
setblock ~24 ~-24 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-24 ~42 minecraft:quartz_pillar
fill ~26 ~-24 ~42 ~42 ~-24 ~42 minecraft:air
setblock ~43 ~-24 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-24 ~42 minecraft:glass_pane[north=true,west=true]
setblock ~45 ~-24 ~42 minecraft:air
fill ~46 ~-24 ~42 ~48 ~-24 ~42 minecraft:glass
setblock ~49 ~-24 ~42 minecraft:air
setblock ~50 ~-24 ~42 minecraft:light_gray_concrete
fill ~51 ~-24 ~42 ~63 ~-24 ~42 minecraft:air
setblock ~64 ~-24 ~42 minecraft:light_gray_concrete
setblock ~4 ~-24 ~43 minecraft:light_gray_concrete
setblock ~5 ~-24 ~43 minecraft:black_concrete
fill ~6 ~-24 ~43 ~17 ~-24 ~43 minecraft:air
setblock ~18 ~-24 ~43 minecraft:light_gray_concrete
fill ~19 ~-24 ~43 ~24 ~-24 ~43 minecraft:air
setblock ~25 ~-24 ~43 minecraft:quartz_pillar
setblock ~26 ~-24 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-24 ~43 ~41 ~-24 ~43 minecraft:air
fill ~42 ~-24 ~43 ~43 ~-24 ~43 minecraft:quartz_pillar
fill ~44 ~-24 ~43 ~45 ~-24 ~43 minecraft:air
setblock ~46 ~-24 ~43 minecraft:glass
setblock ~47 ~-24 ~43 minecraft:air
setblock ~48 ~-24 ~43 minecraft:glass
setblock ~49 ~-24 ~43 minecraft:air
setblock ~50 ~-24 ~43 minecraft:light_gray_concrete
fill ~51 ~-24 ~43 ~63 ~-24 ~43 minecraft:air
setblock ~64 ~-24 ~43 minecraft:light_gray_concrete
setblock ~4 ~-24 ~44 minecraft:light_gray_concrete
setblock ~5 ~-24 ~44 minecraft:black_concrete
fill ~6 ~-24 ~44 ~17 ~-24 ~44 minecraft:air
setblock ~18 ~-24 ~44 minecraft:light_gray_concrete
fill ~19 ~-24 ~44 ~25 ~-24 ~44 minecraft:air
setblock ~26 ~-24 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-24 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-24 ~44 ~29 ~-24 ~44 minecraft:air
setblock ~30 ~-24 ~44 minecraft:quartz_pillar
fill ~31 ~-24 ~44 ~37 ~-24 ~44 minecraft:air
setblock ~38 ~-24 ~44 minecraft:quartz_pillar
fill ~39 ~-24 ~44 ~40 ~-24 ~44 minecraft:air
setblock ~41 ~-24 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-24 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-24 ~44 ~45 ~-24 ~44 minecraft:air
fill ~46 ~-24 ~44 ~48 ~-24 ~44 minecraft:glass
setblock ~49 ~-24 ~44 minecraft:air
setblock ~50 ~-24 ~44 minecraft:light_gray_concrete
fill ~51 ~-24 ~44 ~63 ~-24 ~44 minecraft:air
setblock ~64 ~-24 ~44 minecraft:light_gray_concrete
setblock ~4 ~-24 ~45 minecraft:light_gray_concrete
fill ~5 ~-24 ~45 ~17 ~-24 ~45 minecraft:air
setblock ~18 ~-24 ~45 minecraft:light_gray_concrete
fill ~19 ~-24 ~45 ~27 ~-24 ~45 minecraft:air
setblock ~28 ~-24 ~45 minecraft:smooth_quartz
setblock ~29 ~-24 ~45 minecraft:quartz_pillar
fill ~30 ~-24 ~45 ~38 ~-24 ~45 minecraft:air
setblock ~39 ~-24 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-24 ~45 minecraft:smooth_quartz
fill ~41 ~-24 ~45 ~49 ~-24 ~45 minecraft:air
setblock ~50 ~-24 ~45 minecraft:light_gray_concrete
fill ~51 ~-24 ~45 ~63 ~-24 ~45 minecraft:air
setblock ~64 ~-24 ~45 minecraft:light_gray_concrete
setblock ~4 ~-24 ~46 minecraft:light_gray_concrete
fill ~5 ~-24 ~46 ~17 ~-24 ~46 minecraft:air
setblock ~18 ~-24 ~46 minecraft:light_gray_concrete
fill ~19 ~-24 ~46 ~28 ~-24 ~46 minecraft:air
setblock ~29 ~-24 ~46 minecraft:quartz_pillar
fill ~30 ~-24 ~46 ~31 ~-24 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-24 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-24 ~46 ~35 ~-24 ~46 minecraft:air
setblock ~36 ~-24 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-24 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-24 ~46 minecraft:quartz_pillar
setblock ~39 ~-24 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-24 ~46 ~41 ~-24 ~46 minecraft:air
fill ~42 ~-24 ~46 ~44 ~-24 ~46 minecraft:glass
setblock ~45 ~-24 ~46 minecraft:air
fill ~46 ~-24 ~46 ~48 ~-24 ~46 minecraft:glass
setblock ~49 ~-24 ~46 minecraft:air
setblock ~50 ~-24 ~46 minecraft:light_gray_concrete
fill ~51 ~-24 ~46 ~63 ~-24 ~46 minecraft:air
setblock ~64 ~-24 ~46 minecraft:light_gray_concrete
setblock ~4 ~-24 ~47 minecraft:light_gray_concrete
fill ~5 ~-24 ~47 ~17 ~-24 ~47 minecraft:air
setblock ~18 ~-24 ~47 minecraft:light_gray_concrete
fill ~19 ~-24 ~47 ~31 ~-24 ~47 minecraft:air
setblock ~32 ~-24 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-24 ~47 ~35 ~-24 ~47 minecraft:air
setblock ~36 ~-24 ~47 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~47 ~41 ~-24 ~47 minecraft:air
setblock ~42 ~-24 ~47 minecraft:glass
setblock ~43 ~-24 ~47 minecraft:air
setblock ~44 ~-24 ~47 minecraft:glass
setblock ~45 ~-24 ~47 minecraft:air
setblock ~46 ~-24 ~47 minecraft:glass
setblock ~47 ~-24 ~47 minecraft:air
setblock ~48 ~-24 ~47 minecraft:glass
setblock ~49 ~-24 ~47 minecraft:air
setblock ~50 ~-24 ~47 minecraft:light_gray_concrete
fill ~51 ~-24 ~47 ~63 ~-24 ~47 minecraft:air
setblock ~64 ~-24 ~47 minecraft:light_gray_concrete
setblock ~4 ~-24 ~48 minecraft:light_gray_concrete
fill ~5 ~-24 ~48 ~17 ~-24 ~48 minecraft:air
setblock ~18 ~-24 ~48 minecraft:light_gray_concrete
fill ~19 ~-24 ~48 ~31 ~-24 ~48 minecraft:air
setblock ~32 ~-24 ~48 minecraft:light_gray_concrete
fill ~33 ~-24 ~48 ~35 ~-24 ~48 minecraft:air
setblock ~36 ~-24 ~48 minecraft:light_gray_concrete
fill ~37 ~-24 ~48 ~41 ~-24 ~48 minecraft:air
fill ~42 ~-24 ~48 ~44 ~-24 ~48 minecraft:glass
setblock ~45 ~-24 ~48 minecraft:air
fill ~46 ~-24 ~48 ~48 ~-24 ~48 minecraft:glass
setblock ~49 ~-24 ~48 minecraft:air
setblock ~50 ~-24 ~48 minecraft:light_gray_concrete
fill ~51 ~-24 ~48 ~63 ~-24 ~48 minecraft:air
setblock ~64 ~-24 ~48 minecraft:light_gray_concrete
setblock ~4 ~-24 ~49 minecraft:light_gray_concrete
fill ~5 ~-24 ~49 ~17 ~-24 ~49 minecraft:air
setblock ~18 ~-24 ~49 minecraft:light_gray_concrete
fill ~19 ~-24 ~49 ~31 ~-24 ~49 minecraft:air
setblock ~32 ~-24 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-24 ~49 ~35 ~-24 ~49 minecraft:air
setblock ~36 ~-24 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-24 ~49 ~49 ~-24 ~49 minecraft:air
setblock ~50 ~-24 ~49 minecraft:light_gray_concrete
fill ~51 ~-24 ~49 ~63 ~-24 ~49 minecraft:air
setblock ~64 ~-24 ~49 minecraft:light_gray_concrete
fill ~4 ~-24 ~50 ~32 ~-24 ~50 minecraft:light_gray_concrete
fill ~33 ~-24 ~50 ~35 ~-24 ~50 minecraft:air
fill ~36 ~-24 ~50 ~64 ~-24 ~50 minecraft:light_gray_concrete
setblock ~4 ~-24 ~51 minecraft:light_gray_concrete
fill ~5 ~-24 ~51 ~17 ~-24 ~51 minecraft:air
setblock ~18 ~-24 ~51 minecraft:light_gray_concrete
fill ~19 ~-24 ~51 ~31 ~-24 ~51 minecraft:air
setblock ~32 ~-24 ~51 minecraft:light_gray_concrete
fill ~33 ~-24 ~51 ~35 ~-24 ~51 minecraft:air
setblock ~36 ~-24 ~51 minecraft:light_gray_concrete
fill ~37 ~-24 ~51 ~49 ~-24 ~51 minecraft:air
setblock ~50 ~-24 ~51 minecraft:light_gray_concrete
fill ~51 ~-24 ~51 ~63 ~-24 ~51 minecraft:air
setblock ~64 ~-24 ~51 minecraft:light_gray_concrete
setblock ~4 ~-24 ~52 minecraft:light_gray_concrete
fill ~5 ~-24 ~52 ~17 ~-24 ~52 minecraft:air
setblock ~18 ~-24 ~52 minecraft:light_gray_concrete
fill ~19 ~-24 ~52 ~31 ~-24 ~52 minecraft:air
setblock ~32 ~-24 ~52 minecraft:light_gray_concrete
fill ~33 ~-24 ~52 ~35 ~-24 ~52 minecraft:air
setblock ~36 ~-24 ~52 minecraft:light_gray_concrete
fill ~37 ~-24 ~52 ~49 ~-24 ~52 minecraft:air
setblock ~50 ~-24 ~52 minecraft:light_gray_concrete
fill ~51 ~-24 ~52 ~63 ~-24 ~52 minecraft:air
setblock ~64 ~-24 ~52 minecraft:light_gray_concrete
setblock ~4 ~-24 ~53 minecraft:light_gray_concrete
fill ~5 ~-24 ~53 ~17 ~-24 ~53 minecraft:air
setblock ~18 ~-24 ~53 minecraft:light_gray_concrete
fill ~19 ~-24 ~53 ~31 ~-24 ~53 minecraft:air
setblock ~32 ~-24 ~53 minecraft:light_gray_concrete
fill ~33 ~-24 ~53 ~35 ~-24 ~53 minecraft:air
setblock ~36 ~-24 ~53 minecraft:light_gray_concrete
fill ~37 ~-24 ~53 ~49 ~-24 ~53 minecraft:air
setblock ~50 ~-24 ~53 minecraft:light_gray_concrete
fill ~51 ~-24 ~53 ~63 ~-24 ~53 minecraft:air
setblock ~64 ~-24 ~53 minecraft:light_gray_concrete
setblock ~4 ~-24 ~54 minecraft:light_gray_concrete
fill ~5 ~-24 ~54 ~17 ~-24 ~54 minecraft:air
setblock ~18 ~-24 ~54 minecraft:light_gray_concrete
fill ~19 ~-24 ~54 ~31 ~-24 ~54 minecraft:air
setblock ~32 ~-24 ~54 minecraft:light_gray_concrete
fill ~33 ~-24 ~54 ~35 ~-24 ~54 minecraft:air
setblock ~36 ~-24 ~54 minecraft:light_gray_concrete
fill ~37 ~-24 ~54 ~49 ~-24 ~54 minecraft:air
setblock ~50 ~-24 ~54 minecraft:light_gray_concrete
fill ~51 ~-24 ~54 ~63 ~-24 ~54 minecraft:air
setblock ~64 ~-24 ~54 minecraft:light_gray_concrete
setblock ~4 ~-24 ~55 minecraft:light_gray_concrete
fill ~5 ~-24 ~55 ~17 ~-24 ~55 minecraft:air
setblock ~18 ~-24 ~55 minecraft:light_gray_concrete
fill ~19 ~-24 ~55 ~31 ~-24 ~55 minecraft:air
setblock ~32 ~-24 ~55 minecraft:light_gray_concrete
fill ~33 ~-24 ~55 ~35 ~-24 ~55 minecraft:air
setblock ~36 ~-24 ~55 minecraft:light_gray_concrete
fill ~37 ~-24 ~55 ~49 ~-24 ~55 minecraft:air
setblock ~50 ~-24 ~55 minecraft:light_gray_concrete
fill ~51 ~-24 ~55 ~63 ~-24 ~55 minecraft:air
setblock ~64 ~-24 ~55 minecraft:light_gray_concrete
setblock ~4 ~-24 ~56 minecraft:light_gray_concrete
fill ~5 ~-24 ~56 ~17 ~-24 ~56 minecraft:air
setblock ~18 ~-24 ~56 minecraft:light_gray_concrete
fill ~19 ~-24 ~56 ~31 ~-24 ~56 minecraft:air
setblock ~32 ~-24 ~56 minecraft:light_gray_concrete
fill ~33 ~-24 ~56 ~35 ~-24 ~56 minecraft:air
setblock ~36 ~-24 ~56 minecraft:light_gray_concrete
fill ~37 ~-24 ~56 ~49 ~-24 ~56 minecraft:air
setblock ~50 ~-24 ~56 minecraft:light_gray_concrete
fill ~51 ~-24 ~56 ~63 ~-24 ~56 minecraft:air
setblock ~64 ~-24 ~56 minecraft:light_gray_concrete
setblock ~4 ~-24 ~57 minecraft:light_gray_concrete
fill ~5 ~-24 ~57 ~17 ~-24 ~57 minecraft:air
setblock ~18 ~-24 ~57 minecraft:light_gray_concrete
fill ~19 ~-24 ~57 ~31 ~-24 ~57 minecraft:air
setblock ~32 ~-24 ~57 minecraft:light_gray_concrete
fill ~33 ~-24 ~57 ~35 ~-24 ~57 minecraft:air
setblock ~36 ~-24 ~57 minecraft:light_gray_concrete
fill ~37 ~-24 ~57 ~49 ~-24 ~57 minecraft:air
setblock ~50 ~-24 ~57 minecraft:light_gray_concrete
fill ~51 ~-24 ~57 ~63 ~-24 ~57 minecraft:air
setblock ~64 ~-24 ~57 minecraft:light_gray_concrete
setblock ~4 ~-24 ~58 minecraft:light_gray_concrete
fill ~5 ~-24 ~58 ~17 ~-24 ~58 minecraft:air
setblock ~18 ~-24 ~58 minecraft:light_gray_concrete
fill ~19 ~-24 ~58 ~31 ~-24 ~58 minecraft:air
setblock ~32 ~-24 ~58 minecraft:light_gray_concrete
fill ~33 ~-24 ~58 ~35 ~-24 ~58 minecraft:air
setblock ~36 ~-24 ~58 minecraft:light_gray_concrete
fill ~37 ~-24 ~58 ~49 ~-24 ~58 minecraft:air
setblock ~50 ~-24 ~58 minecraft:light_gray_concrete
fill ~51 ~-24 ~58 ~63 ~-24 ~58 minecraft:air
setblock ~64 ~-24 ~58 minecraft:light_gray_concrete
setblock ~4 ~-24 ~59 minecraft:light_gray_concrete
fill ~5 ~-24 ~59 ~17 ~-24 ~59 minecraft:air
setblock ~18 ~-24 ~59 minecraft:light_gray_concrete
fill ~19 ~-24 ~59 ~31 ~-24 ~59 minecraft:air
setblock ~32 ~-24 ~59 minecraft:light_gray_concrete
fill ~33 ~-24 ~59 ~35 ~-24 ~59 minecraft:air
setblock ~36 ~-24 ~59 minecraft:light_gray_concrete
fill ~37 ~-24 ~59 ~49 ~-24 ~59 minecraft:air
setblock ~50 ~-24 ~59 minecraft:light_gray_concrete
fill ~51 ~-24 ~59 ~63 ~-24 ~59 minecraft:air
setblock ~64 ~-24 ~59 minecraft:light_gray_concrete
setblock ~4 ~-24 ~60 minecraft:light_gray_concrete
fill ~5 ~-24 ~60 ~17 ~-24 ~60 minecraft:air
setblock ~18 ~-24 ~60 minecraft:light_gray_concrete
fill ~19 ~-24 ~60 ~31 ~-24 ~60 minecraft:air
setblock ~32 ~-24 ~60 minecraft:light_gray_concrete
fill ~33 ~-24 ~60 ~35 ~-24 ~60 minecraft:air
setblock ~36 ~-24 ~60 minecraft:light_gray_concrete
fill ~37 ~-24 ~60 ~49 ~-24 ~60 minecraft:air
setblock ~50 ~-24 ~60 minecraft:light_gray_concrete
fill ~51 ~-24 ~60 ~63 ~-24 ~60 minecraft:air
setblock ~64 ~-24 ~60 minecraft:light_gray_concrete
setblock ~4 ~-24 ~61 minecraft:light_gray_concrete
fill ~5 ~-24 ~61 ~17 ~-24 ~61 minecraft:air
setblock ~18 ~-24 ~61 minecraft:light_gray_concrete
fill ~19 ~-24 ~61 ~31 ~-24 ~61 minecraft:air
setblock ~32 ~-24 ~61 minecraft:light_gray_concrete
fill ~33 ~-24 ~61 ~35 ~-24 ~61 minecraft:air
setblock ~36 ~-24 ~61 minecraft:light_gray_concrete
fill ~37 ~-24 ~61 ~49 ~-24 ~61 minecraft:air
setblock ~50 ~-24 ~61 minecraft:light_gray_concrete
fill ~51 ~-24 ~61 ~63 ~-24 ~61 minecraft:air
setblock ~64 ~-24 ~61 minecraft:light_gray_concrete
setblock ~4 ~-24 ~62 minecraft:light_gray_concrete
fill ~5 ~-24 ~62 ~17 ~-24 ~62 minecraft:air
setblock ~18 ~-24 ~62 minecraft:light_gray_concrete
fill ~19 ~-24 ~62 ~31 ~-24 ~62 minecraft:air
setblock ~32 ~-24 ~62 minecraft:light_gray_concrete
fill ~33 ~-24 ~62 ~35 ~-24 ~62 minecraft:air
setblock ~36 ~-24 ~62 minecraft:light_gray_concrete
fill ~37 ~-24 ~62 ~49 ~-24 ~62 minecraft:air
setblock ~50 ~-24 ~62 minecraft:light_gray_concrete
fill ~51 ~-24 ~62 ~63 ~-24 ~62 minecraft:air
setblock ~64 ~-24 ~62 minecraft:light_gray_concrete
setblock ~4 ~-24 ~63 minecraft:light_gray_concrete
fill ~5 ~-24 ~63 ~17 ~-24 ~63 minecraft:air
setblock ~18 ~-24 ~63 minecraft:light_gray_concrete
fill ~19 ~-24 ~63 ~31 ~-24 ~63 minecraft:air
setblock ~32 ~-24 ~63 minecraft:light_gray_concrete
fill ~33 ~-24 ~63 ~35 ~-24 ~63 minecraft:air
setblock ~36 ~-24 ~63 minecraft:light_gray_concrete
fill ~37 ~-24 ~63 ~49 ~-24 ~63 minecraft:air
setblock ~50 ~-24 ~63 minecraft:light_gray_concrete
fill ~51 ~-24 ~63 ~63 ~-24 ~63 minecraft:air
setblock ~64 ~-24 ~63 minecraft:light_gray_concrete
fill ~4 ~-24 ~64 ~64 ~-24 ~64 minecraft:light_gray_concrete
fill ~32 ~-24 ~66 ~36 ~-24 ~66 minecraft:polished_andesite
setblock ~32 ~-24 ~67 minecraft:polished_andesite
fill ~33 ~-24 ~67 ~35 ~-24 ~67 minecraft:air
setblock ~36 ~-24 ~67 minecraft:polished_andesite
setblock ~32 ~-24 ~68 minecraft:sea_lantern
setblock ~33 ~-24 ~68 minecraft:air
setblock ~34 ~-24 ~68 minecraft:quartz_pillar
setblock ~35 ~-24 ~68 minecraft:air
setblock ~36 ~-24 ~68 minecraft:sea_lantern
setblock ~32 ~-24 ~69 minecraft:polished_andesite
setblock ~33 ~-24 ~69 minecraft:air
setblock ~34 ~-24 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-24 ~69 minecraft:air
setblock ~36 ~-24 ~69 minecraft:polished_andesite
fill ~32 ~-24 ~70 ~36 ~-24 ~70 minecraft:polished_andesite
fill ~4 ~-23 ~4 ~64 ~-23 ~4 minecraft:light_gray_concrete
setblock ~4 ~-23 ~5 minecraft:light_gray_concrete
fill ~5 ~-23 ~5 ~17 ~-23 ~5 minecraft:air
setblock ~18 ~-23 ~5 minecraft:light_gray_concrete
fill ~19 ~-23 ~5 ~31 ~-23 ~5 minecraft:air
setblock ~32 ~-23 ~5 minecraft:light_gray_concrete
fill ~33 ~-23 ~5 ~35 ~-23 ~5 minecraft:air
setblock ~36 ~-23 ~5 minecraft:light_gray_concrete
fill ~37 ~-23 ~5 ~49 ~-23 ~5 minecraft:air
setblock ~50 ~-23 ~5 minecraft:light_gray_concrete
fill ~51 ~-23 ~5 ~63 ~-23 ~5 minecraft:air
setblock ~64 ~-23 ~5 minecraft:light_gray_concrete
setblock ~4 ~-23 ~6 minecraft:light_gray_concrete
fill ~5 ~-23 ~6 ~17 ~-23 ~6 minecraft:air
setblock ~18 ~-23 ~6 minecraft:light_gray_concrete
fill ~19 ~-23 ~6 ~31 ~-23 ~6 minecraft:air
setblock ~32 ~-23 ~6 minecraft:light_gray_concrete
fill ~33 ~-23 ~6 ~35 ~-23 ~6 minecraft:air
setblock ~36 ~-23 ~6 minecraft:light_gray_concrete
fill ~37 ~-23 ~6 ~49 ~-23 ~6 minecraft:air
setblock ~50 ~-23 ~6 minecraft:light_gray_concrete
fill ~51 ~-23 ~6 ~63 ~-23 ~6 minecraft:air
setblock ~64 ~-23 ~6 minecraft:light_gray_concrete
setblock ~4 ~-23 ~7 minecraft:light_gray_concrete
fill ~5 ~-23 ~7 ~17 ~-23 ~7 minecraft:air
setblock ~18 ~-23 ~7 minecraft:light_gray_concrete
fill ~19 ~-23 ~7 ~31 ~-23 ~7 minecraft:air
setblock ~32 ~-23 ~7 minecraft:light_gray_concrete
fill ~33 ~-23 ~7 ~35 ~-23 ~7 minecraft:air
setblock ~36 ~-23 ~7 minecraft:light_gray_concrete
fill ~37 ~-23 ~7 ~49 ~-23 ~7 minecraft:air
setblock ~50 ~-23 ~7 minecraft:light_gray_concrete
fill ~51 ~-23 ~7 ~63 ~-23 ~7 minecraft:air
setblock ~64 ~-23 ~7 minecraft:light_gray_concrete
setblock ~4 ~-23 ~8 minecraft:light_gray_concrete
fill ~5 ~-23 ~8 ~17 ~-23 ~8 minecraft:air
setblock ~18 ~-23 ~8 minecraft:light_gray_concrete
fill ~19 ~-23 ~8 ~31 ~-23 ~8 minecraft:air
setblock ~32 ~-23 ~8 minecraft:light_gray_concrete
fill ~33 ~-23 ~8 ~35 ~-23 ~8 minecraft:air
setblock ~36 ~-23 ~8 minecraft:light_gray_concrete
fill ~37 ~-23 ~8 ~49 ~-23 ~8 minecraft:air
setblock ~50 ~-23 ~8 minecraft:light_gray_concrete
fill ~51 ~-23 ~8 ~63 ~-23 ~8 minecraft:air
setblock ~64 ~-23 ~8 minecraft:light_gray_concrete
setblock ~4 ~-23 ~9 minecraft:light_gray_concrete
fill ~5 ~-23 ~9 ~17 ~-23 ~9 minecraft:air
setblock ~18 ~-23 ~9 minecraft:light_gray_concrete
fill ~19 ~-23 ~9 ~31 ~-23 ~9 minecraft:air
setblock ~32 ~-23 ~9 minecraft:light_gray_concrete
fill ~33 ~-23 ~9 ~35 ~-23 ~9 minecraft:air
setblock ~36 ~-23 ~9 minecraft:light_gray_concrete
fill ~37 ~-23 ~9 ~49 ~-23 ~9 minecraft:air
setblock ~50 ~-23 ~9 minecraft:light_gray_concrete
fill ~51 ~-23 ~9 ~63 ~-23 ~9 minecraft:air
setblock ~64 ~-23 ~9 minecraft:light_gray_concrete
setblock ~4 ~-23 ~10 minecraft:light_gray_concrete
fill ~5 ~-23 ~10 ~17 ~-23 ~10 minecraft:air
setblock ~18 ~-23 ~10 minecraft:light_gray_concrete
fill ~19 ~-23 ~10 ~31 ~-23 ~10 minecraft:air
setblock ~32 ~-23 ~10 minecraft:light_gray_concrete
fill ~33 ~-23 ~10 ~35 ~-23 ~10 minecraft:air
setblock ~36 ~-23 ~10 minecraft:light_gray_concrete
fill ~37 ~-23 ~10 ~49 ~-23 ~10 minecraft:air
setblock ~50 ~-23 ~10 minecraft:light_gray_concrete
fill ~51 ~-23 ~10 ~63 ~-23 ~10 minecraft:air
setblock ~64 ~-23 ~10 minecraft:light_gray_concrete
setblock ~4 ~-23 ~11 minecraft:light_gray_concrete
fill ~5 ~-23 ~11 ~17 ~-23 ~11 minecraft:air
setblock ~18 ~-23 ~11 minecraft:light_gray_concrete
fill ~19 ~-23 ~11 ~31 ~-23 ~11 minecraft:air
setblock ~32 ~-23 ~11 minecraft:light_gray_concrete
fill ~33 ~-23 ~11 ~35 ~-23 ~11 minecraft:air
setblock ~36 ~-23 ~11 minecraft:light_gray_concrete
fill ~37 ~-23 ~11 ~49 ~-23 ~11 minecraft:air
setblock ~50 ~-23 ~11 minecraft:light_gray_concrete
fill ~51 ~-23 ~11 ~63 ~-23 ~11 minecraft:air
setblock ~64 ~-23 ~11 minecraft:light_gray_concrete
setblock ~4 ~-23 ~12 minecraft:light_gray_concrete
fill ~5 ~-23 ~12 ~17 ~-23 ~12 minecraft:air
setblock ~18 ~-23 ~12 minecraft:light_gray_concrete
fill ~19 ~-23 ~12 ~31 ~-23 ~12 minecraft:air
setblock ~32 ~-23 ~12 minecraft:light_gray_concrete
fill ~33 ~-23 ~12 ~35 ~-23 ~12 minecraft:air
setblock ~36 ~-23 ~12 minecraft:light_gray_concrete
fill ~37 ~-23 ~12 ~49 ~-23 ~12 minecraft:air
setblock ~50 ~-23 ~12 minecraft:light_gray_concrete
fill ~51 ~-23 ~12 ~63 ~-23 ~12 minecraft:air
setblock ~64 ~-23 ~12 minecraft:light_gray_concrete
setblock ~4 ~-23 ~13 minecraft:light_gray_concrete
fill ~5 ~-23 ~13 ~17 ~-23 ~13 minecraft:air
setblock ~18 ~-23 ~13 minecraft:light_gray_concrete
fill ~19 ~-23 ~13 ~31 ~-23 ~13 minecraft:air
setblock ~32 ~-23 ~13 minecraft:light_gray_concrete
fill ~33 ~-23 ~13 ~35 ~-23 ~13 minecraft:air
setblock ~36 ~-23 ~13 minecraft:light_gray_concrete
fill ~37 ~-23 ~13 ~49 ~-23 ~13 minecraft:air
setblock ~50 ~-23 ~13 minecraft:light_gray_concrete
fill ~51 ~-23 ~13 ~63 ~-23 ~13 minecraft:air
setblock ~64 ~-23 ~13 minecraft:light_gray_concrete
setblock ~4 ~-23 ~14 minecraft:light_gray_concrete
fill ~5 ~-23 ~14 ~17 ~-23 ~14 minecraft:air
setblock ~18 ~-23 ~14 minecraft:light_gray_concrete
fill ~19 ~-23 ~14 ~31 ~-23 ~14 minecraft:air
setblock ~32 ~-23 ~14 minecraft:light_gray_concrete
fill ~33 ~-23 ~14 ~35 ~-23 ~14 minecraft:air
setblock ~36 ~-23 ~14 minecraft:light_gray_concrete
fill ~37 ~-23 ~14 ~49 ~-23 ~14 minecraft:air
setblock ~50 ~-23 ~14 minecraft:light_gray_concrete
fill ~51 ~-23 ~14 ~63 ~-23 ~14 minecraft:air
setblock ~64 ~-23 ~14 minecraft:light_gray_concrete
setblock ~4 ~-23 ~15 minecraft:light_gray_concrete
fill ~5 ~-23 ~15 ~17 ~-23 ~15 minecraft:air
setblock ~18 ~-23 ~15 minecraft:light_gray_concrete
fill ~19 ~-23 ~15 ~31 ~-23 ~15 minecraft:air
setblock ~32 ~-23 ~15 minecraft:light_gray_concrete
fill ~33 ~-23 ~15 ~35 ~-23 ~15 minecraft:air
setblock ~36 ~-23 ~15 minecraft:light_gray_concrete
fill ~37 ~-23 ~15 ~49 ~-23 ~15 minecraft:air
setblock ~50 ~-23 ~15 minecraft:light_gray_concrete
fill ~51 ~-23 ~15 ~63 ~-23 ~15 minecraft:air
setblock ~64 ~-23 ~15 minecraft:light_gray_concrete
setblock ~4 ~-23 ~16 minecraft:light_gray_concrete
fill ~5 ~-23 ~16 ~17 ~-23 ~16 minecraft:air
setblock ~18 ~-23 ~16 minecraft:light_gray_concrete
fill ~19 ~-23 ~16 ~31 ~-23 ~16 minecraft:air
setblock ~32 ~-23 ~16 minecraft:light_gray_concrete
fill ~33 ~-23 ~16 ~35 ~-23 ~16 minecraft:air
setblock ~36 ~-23 ~16 minecraft:light_gray_concrete
fill ~37 ~-23 ~16 ~49 ~-23 ~16 minecraft:air
setblock ~50 ~-23 ~16 minecraft:light_gray_concrete
fill ~51 ~-23 ~16 ~63 ~-23 ~16 minecraft:air
setblock ~64 ~-23 ~16 minecraft:light_gray_concrete
setblock ~4 ~-23 ~17 minecraft:light_gray_concrete
fill ~5 ~-23 ~17 ~17 ~-23 ~17 minecraft:air
setblock ~18 ~-23 ~17 minecraft:light_gray_concrete
fill ~19 ~-23 ~17 ~31 ~-23 ~17 minecraft:air
setblock ~32 ~-23 ~17 minecraft:light_gray_concrete
fill ~33 ~-23 ~17 ~35 ~-23 ~17 minecraft:air
setblock ~36 ~-23 ~17 minecraft:light_gray_concrete
fill ~37 ~-23 ~17 ~49 ~-23 ~17 minecraft:air
setblock ~50 ~-23 ~17 minecraft:light_gray_concrete
fill ~51 ~-23 ~17 ~63 ~-23 ~17 minecraft:air
setblock ~64 ~-23 ~17 minecraft:light_gray_concrete
fill ~4 ~-23 ~18 ~32 ~-23 ~18 minecraft:light_gray_concrete
fill ~33 ~-23 ~18 ~35 ~-23 ~18 minecraft:air
fill ~36 ~-23 ~18 ~64 ~-23 ~18 minecraft:light_gray_concrete
setblock ~4 ~-23 ~19 minecraft:light_gray_concrete
fill ~5 ~-23 ~19 ~17 ~-23 ~19 minecraft:air
setblock ~18 ~-23 ~19 minecraft:light_gray_concrete
fill ~19 ~-23 ~19 ~31 ~-23 ~19 minecraft:air
setblock ~32 ~-23 ~19 minecraft:light_gray_concrete
fill ~33 ~-23 ~19 ~35 ~-23 ~19 minecraft:air
setblock ~36 ~-23 ~19 minecraft:light_gray_concrete
fill ~37 ~-23 ~19 ~49 ~-23 ~19 minecraft:air
setblock ~50 ~-23 ~19 minecraft:light_gray_concrete
fill ~51 ~-23 ~19 ~63 ~-23 ~19 minecraft:air
setblock ~64 ~-23 ~19 minecraft:light_gray_concrete
setblock ~4 ~-23 ~20 minecraft:light_gray_concrete
fill ~5 ~-23 ~20 ~17 ~-23 ~20 minecraft:air
setblock ~18 ~-23 ~20 minecraft:light_gray_concrete
setblock ~19 ~-23 ~20 minecraft:air
fill ~20 ~-23 ~20 ~22 ~-23 ~20 minecraft:iron_block
setblock ~23 ~-23 ~20 minecraft:air
fill ~24 ~-23 ~20 ~26 ~-23 ~20 minecraft:iron_block
fill ~27 ~-23 ~20 ~31 ~-23 ~20 minecraft:air
setblock ~32 ~-23 ~20 minecraft:light_gray_concrete
fill ~33 ~-23 ~20 ~35 ~-23 ~20 minecraft:air
setblock ~36 ~-23 ~20 minecraft:light_gray_concrete
fill ~37 ~-23 ~20 ~49 ~-23 ~20 minecraft:air
setblock ~50 ~-23 ~20 minecraft:light_gray_concrete
fill ~51 ~-23 ~20 ~63 ~-23 ~20 minecraft:air
setblock ~64 ~-23 ~20 minecraft:light_gray_concrete
setblock ~4 ~-23 ~21 minecraft:light_gray_concrete
fill ~5 ~-23 ~21 ~17 ~-23 ~21 minecraft:air
setblock ~18 ~-23 ~21 minecraft:light_gray_concrete
setblock ~19 ~-23 ~21 minecraft:air
fill ~20 ~-23 ~21 ~22 ~-23 ~21 minecraft:iron_block
setblock ~23 ~-23 ~21 minecraft:air
fill ~24 ~-23 ~21 ~26 ~-23 ~21 minecraft:iron_block
fill ~27 ~-23 ~21 ~31 ~-23 ~21 minecraft:air
setblock ~32 ~-23 ~21 minecraft:light_gray_concrete
setblock ~33 ~-23 ~21 minecraft:air
setblock ~34 ~-23 ~21 minecraft:smooth_quartz
setblock ~35 ~-23 ~21 minecraft:air
setblock ~36 ~-23 ~21 minecraft:light_gray_concrete
fill ~37 ~-23 ~21 ~49 ~-23 ~21 minecraft:air
setblock ~50 ~-23 ~21 minecraft:light_gray_concrete
fill ~51 ~-23 ~21 ~63 ~-23 ~21 minecraft:air
setblock ~64 ~-23 ~21 minecraft:light_gray_concrete
setblock ~4 ~-23 ~22 minecraft:light_gray_concrete
fill ~5 ~-23 ~22 ~17 ~-23 ~22 minecraft:air
setblock ~18 ~-23 ~22 minecraft:light_gray_concrete
setblock ~19 ~-23 ~22 minecraft:air
fill ~20 ~-23 ~22 ~22 ~-23 ~22 minecraft:iron_block
setblock ~23 ~-23 ~22 minecraft:air
fill ~24 ~-23 ~22 ~26 ~-23 ~22 minecraft:iron_block
fill ~27 ~-23 ~22 ~28 ~-23 ~22 minecraft:air
setblock ~29 ~-23 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-23 ~22 minecraft:quartz_pillar
setblock ~31 ~-23 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-23 ~22 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~33 ~-23 ~22 minecraft:smooth_quartz
setblock ~34 ~-23 ~22 minecraft:air
setblock ~35 ~-23 ~22 minecraft:smooth_quartz
setblock ~36 ~-23 ~22 minecraft:glass_pane[north=true,east=true,west=true]
fill ~37 ~-23 ~22 ~38 ~-23 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-23 ~22 minecraft:quartz_pillar
fill ~40 ~-23 ~22 ~49 ~-23 ~22 minecraft:air
setblock ~50 ~-23 ~22 minecraft:light_gray_concrete
fill ~51 ~-23 ~22 ~63 ~-23 ~22 minecraft:air
setblock ~64 ~-23 ~22 minecraft:light_gray_concrete
setblock ~4 ~-23 ~23 minecraft:light_gray_concrete
fill ~5 ~-23 ~23 ~17 ~-23 ~23 minecraft:air
setblock ~18 ~-23 ~23 minecraft:light_gray_concrete
fill ~19 ~-23 ~23 ~27 ~-23 ~23 minecraft:air
setblock ~28 ~-23 ~23 minecraft:smooth_quartz
setblock ~29 ~-23 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-23 ~23 ~38 ~-23 ~23 minecraft:air
setblock ~39 ~-23 ~23 minecraft:quartz_pillar
setblock ~40 ~-23 ~23 minecraft:smooth_quartz
fill ~41 ~-23 ~23 ~49 ~-23 ~23 minecraft:air
setblock ~50 ~-23 ~23 minecraft:light_gray_concrete
fill ~51 ~-23 ~23 ~63 ~-23 ~23 minecraft:air
setblock ~64 ~-23 ~23 minecraft:light_gray_concrete
setblock ~4 ~-23 ~24 minecraft:light_gray_concrete
fill ~5 ~-23 ~24 ~17 ~-23 ~24 minecraft:air
setblock ~18 ~-23 ~24 minecraft:light_gray_concrete
setblock ~19 ~-23 ~24 minecraft:air
fill ~20 ~-23 ~24 ~22 ~-23 ~24 minecraft:iron_block
fill ~23 ~-23 ~24 ~25 ~-23 ~24 minecraft:air
setblock ~26 ~-23 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-23 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-23 ~24 ~29 ~-23 ~24 minecraft:air
setblock ~30 ~-23 ~24 minecraft:quartz_pillar
fill ~31 ~-23 ~24 ~37 ~-23 ~24 minecraft:air
setblock ~38 ~-23 ~24 minecraft:quartz_pillar
fill ~39 ~-23 ~24 ~40 ~-23 ~24 minecraft:air
setblock ~41 ~-23 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-23 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-23 ~24 ~49 ~-23 ~24 minecraft:air
setblock ~50 ~-23 ~24 minecraft:light_gray_concrete
fill ~51 ~-23 ~24 ~63 ~-23 ~24 minecraft:air
setblock ~64 ~-23 ~24 minecraft:light_gray_concrete
setblock ~4 ~-23 ~25 minecraft:light_gray_concrete
fill ~5 ~-23 ~25 ~17 ~-23 ~25 minecraft:air
setblock ~18 ~-23 ~25 minecraft:light_gray_concrete
setblock ~19 ~-23 ~25 minecraft:air
fill ~20 ~-23 ~25 ~22 ~-23 ~25 minecraft:iron_block
fill ~23 ~-23 ~25 ~24 ~-23 ~25 minecraft:air
fill ~25 ~-23 ~25 ~26 ~-23 ~25 minecraft:quartz_pillar
fill ~27 ~-23 ~25 ~41 ~-23 ~25 minecraft:air
setblock ~42 ~-23 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-23 ~25 minecraft:quartz_pillar
fill ~44 ~-23 ~25 ~49 ~-23 ~25 minecraft:air
setblock ~50 ~-23 ~25 minecraft:light_gray_concrete
fill ~51 ~-23 ~25 ~63 ~-23 ~25 minecraft:air
setblock ~64 ~-23 ~25 minecraft:light_gray_concrete
setblock ~4 ~-23 ~26 minecraft:light_gray_concrete
fill ~5 ~-23 ~26 ~17 ~-23 ~26 minecraft:air
setblock ~18 ~-23 ~26 minecraft:light_gray_concrete
setblock ~19 ~-23 ~26 minecraft:air
fill ~20 ~-23 ~26 ~22 ~-23 ~26 minecraft:iron_block
setblock ~23 ~-23 ~26 minecraft:air
setblock ~24 ~-23 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-23 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-23 ~26 ~42 ~-23 ~26 minecraft:air
setblock ~43 ~-23 ~26 minecraft:quartz_pillar
setblock ~44 ~-23 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-23 ~26 ~49 ~-23 ~26 minecraft:air
setblock ~50 ~-23 ~26 minecraft:light_gray_concrete
fill ~51 ~-23 ~26 ~63 ~-23 ~26 minecraft:air
setblock ~64 ~-23 ~26 minecraft:light_gray_concrete
setblock ~4 ~-23 ~27 minecraft:light_gray_concrete
fill ~5 ~-23 ~27 ~17 ~-23 ~27 minecraft:air
setblock ~18 ~-23 ~27 minecraft:light_gray_concrete
fill ~19 ~-23 ~27 ~23 ~-23 ~27 minecraft:air
setblock ~24 ~-23 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-23 ~27 ~43 ~-23 ~27 minecraft:air
setblock ~44 ~-23 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-23 ~27 ~49 ~-23 ~27 minecraft:air
setblock ~50 ~-23 ~27 minecraft:light_gray_concrete
fill ~51 ~-23 ~27 ~63 ~-23 ~27 minecraft:air
setblock ~64 ~-23 ~27 minecraft:light_gray_concrete
setblock ~4 ~-23 ~28 minecraft:light_gray_concrete
fill ~5 ~-23 ~28 ~17 ~-23 ~28 minecraft:air
setblock ~18 ~-23 ~28 minecraft:light_gray_concrete
fill ~19 ~-23 ~28 ~22 ~-23 ~28 minecraft:air
setblock ~23 ~-23 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-23 ~28 ~44 ~-23 ~28 minecraft:air
setblock ~45 ~-23 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-23 ~28 ~49 ~-23 ~28 minecraft:air
setblock ~50 ~-23 ~28 minecraft:light_gray_concrete
fill ~51 ~-23 ~28 ~63 ~-23 ~28 minecraft:air
setblock ~64 ~-23 ~28 minecraft:light_gray_concrete
setblock ~4 ~-23 ~29 minecraft:light_gray_concrete
fill ~5 ~-23 ~29 ~17 ~-23 ~29 minecraft:air
setblock ~18 ~-23 ~29 minecraft:light_gray_concrete
fill ~19 ~-23 ~29 ~21 ~-23 ~29 minecraft:air
fill ~22 ~-23 ~29 ~23 ~-23 ~29 minecraft:quartz_pillar
fill ~24 ~-23 ~29 ~44 ~-23 ~29 minecraft:air
setblock ~45 ~-23 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-23 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-23 ~29 ~49 ~-23 ~29 minecraft:air
setblock ~50 ~-23 ~29 minecraft:light_gray_concrete
fill ~51 ~-23 ~29 ~63 ~-23 ~29 minecraft:air
setblock ~64 ~-23 ~29 minecraft:light_gray_concrete
setblock ~4 ~-23 ~30 minecraft:light_gray_concrete
fill ~5 ~-23 ~30 ~17 ~-23 ~30 minecraft:air
setblock ~18 ~-23 ~30 minecraft:light_gray_concrete
fill ~19 ~-23 ~30 ~21 ~-23 ~30 minecraft:air
setblock ~22 ~-23 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-23 ~30 minecraft:air
setblock ~24 ~-23 ~30 minecraft:quartz_pillar
fill ~25 ~-23 ~30 ~43 ~-23 ~30 minecraft:air
setblock ~44 ~-23 ~30 minecraft:quartz_pillar
setblock ~45 ~-23 ~30 minecraft:air
setblock ~46 ~-23 ~30 minecraft:quartz_pillar
fill ~47 ~-23 ~30 ~49 ~-23 ~30 minecraft:air
setblock ~50 ~-23 ~30 minecraft:light_gray_concrete
fill ~51 ~-23 ~30 ~63 ~-23 ~30 minecraft:air
setblock ~64 ~-23 ~30 minecraft:light_gray_concrete
setblock ~4 ~-23 ~31 minecraft:light_gray_concrete
fill ~5 ~-23 ~31 ~17 ~-23 ~31 minecraft:air
setblock ~18 ~-23 ~31 minecraft:light_gray_concrete
fill ~19 ~-23 ~31 ~21 ~-23 ~31 minecraft:air
setblock ~22 ~-23 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-23 ~31 ~45 ~-23 ~31 minecraft:air
setblock ~46 ~-23 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-23 ~31 ~49 ~-23 ~31 minecraft:air
setblock ~50 ~-23 ~31 minecraft:light_gray_concrete
fill ~51 ~-23 ~31 ~63 ~-23 ~31 minecraft:air
setblock ~64 ~-23 ~31 minecraft:light_gray_concrete
fill ~4 ~-23 ~32 ~21 ~-23 ~32 minecraft:light_gray_concrete
setblock ~22 ~-23 ~32 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-23 ~32 ~32 ~-23 ~32 minecraft:air
fill ~33 ~-23 ~32 ~35 ~-23 ~32 minecraft:glass
fill ~36 ~-23 ~32 ~45 ~-23 ~32 minecraft:air
setblock ~46 ~-23 ~32 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-23 ~32 ~64 ~-23 ~32 minecraft:light_gray_concrete
setblock ~4 ~-23 ~33 minecraft:light_gray_concrete
fill ~5 ~-23 ~33 ~21 ~-23 ~33 minecraft:air
setblock ~22 ~-23 ~33 minecraft:smooth_quartz
fill ~23 ~-23 ~33 ~32 ~-23 ~33 minecraft:air
setblock ~33 ~-23 ~33 minecraft:glass
setblock ~34 ~-23 ~33 minecraft:air
setblock ~35 ~-23 ~33 minecraft:glass
fill ~36 ~-23 ~33 ~45 ~-23 ~33 minecraft:air
setblock ~46 ~-23 ~33 minecraft:smooth_quartz
fill ~47 ~-23 ~33 ~63 ~-23 ~33 minecraft:air
setblock ~64 ~-23 ~33 minecraft:light_gray_concrete
setblock ~4 ~-23 ~34 minecraft:light_gray_concrete
fill ~5 ~-23 ~34 ~20 ~-23 ~34 minecraft:air
setblock ~21 ~-23 ~34 minecraft:smooth_quartz
fill ~22 ~-23 ~34 ~32 ~-23 ~34 minecraft:air
fill ~33 ~-23 ~34 ~35 ~-23 ~34 minecraft:glass
fill ~36 ~-23 ~34 ~46 ~-23 ~34 minecraft:air
setblock ~47 ~-23 ~34 minecraft:smooth_quartz
fill ~48 ~-23 ~34 ~63 ~-23 ~34 minecraft:air
setblock ~64 ~-23 ~34 minecraft:light_gray_concrete
setblock ~4 ~-23 ~35 minecraft:light_gray_concrete
fill ~5 ~-23 ~35 ~21 ~-23 ~35 minecraft:air
setblock ~22 ~-23 ~35 minecraft:smooth_quartz
fill ~23 ~-23 ~35 ~32 ~-23 ~35 minecraft:air
setblock ~33 ~-23 ~35 minecraft:glass
setblock ~34 ~-23 ~35 minecraft:air
setblock ~35 ~-23 ~35 minecraft:glass
fill ~36 ~-23 ~35 ~45 ~-23 ~35 minecraft:air
setblock ~46 ~-23 ~35 minecraft:smooth_quartz
fill ~47 ~-23 ~35 ~63 ~-23 ~35 minecraft:air
setblock ~64 ~-23 ~35 minecraft:light_gray_concrete
fill ~4 ~-23 ~36 ~21 ~-23 ~36 minecraft:light_gray_concrete
setblock ~22 ~-23 ~36 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-23 ~36 ~32 ~-23 ~36 minecraft:air
fill ~33 ~-23 ~36 ~35 ~-23 ~36 minecraft:glass
fill ~36 ~-23 ~36 ~45 ~-23 ~36 minecraft:air
setblock ~46 ~-23 ~36 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-23 ~36 ~64 ~-23 ~36 minecraft:light_gray_concrete
setblock ~4 ~-23 ~37 minecraft:light_gray_concrete
fill ~5 ~-23 ~37 ~17 ~-23 ~37 minecraft:air
setblock ~18 ~-23 ~37 minecraft:light_gray_concrete
fill ~19 ~-23 ~37 ~21 ~-23 ~37 minecraft:air
setblock ~22 ~-23 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-23 ~37 ~45 ~-23 ~37 minecraft:air
setblock ~46 ~-23 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-23 ~37 ~49 ~-23 ~37 minecraft:air
setblock ~50 ~-23 ~37 minecraft:light_gray_concrete
fill ~51 ~-23 ~37 ~63 ~-23 ~37 minecraft:air
setblock ~64 ~-23 ~37 minecraft:light_gray_concrete
setblock ~4 ~-23 ~38 minecraft:light_gray_concrete
fill ~5 ~-23 ~38 ~17 ~-23 ~38 minecraft:air
setblock ~18 ~-23 ~38 minecraft:light_gray_concrete
fill ~19 ~-23 ~38 ~21 ~-23 ~38 minecraft:air
setblock ~22 ~-23 ~38 minecraft:quartz_pillar
setblock ~23 ~-23 ~38 minecraft:air
setblock ~24 ~-23 ~38 minecraft:quartz_pillar
fill ~25 ~-23 ~38 ~43 ~-23 ~38 minecraft:air
setblock ~44 ~-23 ~38 minecraft:quartz_pillar
setblock ~45 ~-23 ~38 minecraft:air
setblock ~46 ~-23 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-23 ~38 ~49 ~-23 ~38 minecraft:air
setblock ~50 ~-23 ~38 minecraft:light_gray_concrete
fill ~51 ~-23 ~38 ~63 ~-23 ~38 minecraft:air
setblock ~64 ~-23 ~38 minecraft:light_gray_concrete
setblock ~4 ~-23 ~39 minecraft:light_gray_concrete
fill ~5 ~-23 ~39 ~17 ~-23 ~39 minecraft:air
setblock ~18 ~-23 ~39 minecraft:light_gray_concrete
fill ~19 ~-23 ~39 ~21 ~-23 ~39 minecraft:air
setblock ~22 ~-23 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-23 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-23 ~39 ~44 ~-23 ~39 minecraft:air
fill ~45 ~-23 ~39 ~46 ~-23 ~39 minecraft:quartz_pillar
fill ~47 ~-23 ~39 ~49 ~-23 ~39 minecraft:air
setblock ~50 ~-23 ~39 minecraft:light_gray_concrete
fill ~51 ~-23 ~39 ~63 ~-23 ~39 minecraft:air
setblock ~64 ~-23 ~39 minecraft:light_gray_concrete
setblock ~4 ~-23 ~40 minecraft:light_gray_concrete
fill ~5 ~-23 ~40 ~17 ~-23 ~40 minecraft:air
setblock ~18 ~-23 ~40 minecraft:light_gray_concrete
fill ~19 ~-23 ~40 ~22 ~-23 ~40 minecraft:air
setblock ~23 ~-23 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-23 ~40 ~44 ~-23 ~40 minecraft:air
setblock ~45 ~-23 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-23 ~40 ~49 ~-23 ~40 minecraft:air
setblock ~50 ~-23 ~40 minecraft:light_gray_concrete
fill ~51 ~-23 ~40 ~63 ~-23 ~40 minecraft:air
setblock ~64 ~-23 ~40 minecraft:light_gray_concrete
setblock ~4 ~-23 ~41 minecraft:light_gray_concrete
fill ~5 ~-23 ~41 ~17 ~-23 ~41 minecraft:air
setblock ~18 ~-23 ~41 minecraft:light_gray_concrete
fill ~19 ~-23 ~41 ~23 ~-23 ~41 minecraft:air
setblock ~24 ~-23 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-23 ~41 ~43 ~-23 ~41 minecraft:air
setblock ~44 ~-23 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-23 ~41 ~49 ~-23 ~41 minecraft:air
setblock ~50 ~-23 ~41 minecraft:light_gray_concrete
fill ~51 ~-23 ~41 ~63 ~-23 ~41 minecraft:air
setblock ~64 ~-23 ~41 minecraft:light_gray_concrete
setblock ~4 ~-23 ~42 minecraft:light_gray_concrete
fill ~5 ~-23 ~42 ~17 ~-23 ~42 minecraft:air
setblock ~18 ~-23 ~42 minecraft:light_gray_concrete
fill ~19 ~-23 ~42 ~23 ~-23 ~42 minecraft:air
setblock ~24 ~-23 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-23 ~42 minecraft:quartz_pillar
fill ~26 ~-23 ~42 ~42 ~-23 ~42 minecraft:air
setblock ~43 ~-23 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-23 ~42 minecraft:glass_pane[north=true,west=true]
setblock ~45 ~-23 ~42 minecraft:air
fill ~46 ~-23 ~42 ~48 ~-23 ~42 minecraft:iron_block
setblock ~49 ~-23 ~42 minecraft:air
setblock ~50 ~-23 ~42 minecraft:light_gray_concrete
fill ~51 ~-23 ~42 ~63 ~-23 ~42 minecraft:air
setblock ~64 ~-23 ~42 minecraft:light_gray_concrete
setblock ~4 ~-23 ~43 minecraft:light_gray_concrete
fill ~5 ~-23 ~43 ~17 ~-23 ~43 minecraft:air
setblock ~18 ~-23 ~43 minecraft:light_gray_concrete
fill ~19 ~-23 ~43 ~24 ~-23 ~43 minecraft:air
setblock ~25 ~-23 ~43 minecraft:quartz_pillar
setblock ~26 ~-23 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-23 ~43 ~41 ~-23 ~43 minecraft:air
fill ~42 ~-23 ~43 ~43 ~-23 ~43 minecraft:quartz_pillar
fill ~44 ~-23 ~43 ~45 ~-23 ~43 minecraft:air
fill ~46 ~-23 ~43 ~48 ~-23 ~43 minecraft:iron_block
setblock ~49 ~-23 ~43 minecraft:air
setblock ~50 ~-23 ~43 minecraft:light_gray_concrete
fill ~51 ~-23 ~43 ~63 ~-23 ~43 minecraft:air
setblock ~64 ~-23 ~43 minecraft:light_gray_concrete
setblock ~4 ~-23 ~44 minecraft:light_gray_concrete
fill ~5 ~-23 ~44 ~17 ~-23 ~44 minecraft:air
setblock ~18 ~-23 ~44 minecraft:light_gray_concrete
fill ~19 ~-23 ~44 ~25 ~-23 ~44 minecraft:air
setblock ~26 ~-23 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-23 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-23 ~44 ~29 ~-23 ~44 minecraft:air
setblock ~30 ~-23 ~44 minecraft:quartz_pillar
fill ~31 ~-23 ~44 ~37 ~-23 ~44 minecraft:air
setblock ~38 ~-23 ~44 minecraft:quartz_pillar
fill ~39 ~-23 ~44 ~40 ~-23 ~44 minecraft:air
setblock ~41 ~-23 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-23 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-23 ~44 ~45 ~-23 ~44 minecraft:air
fill ~46 ~-23 ~44 ~48 ~-23 ~44 minecraft:iron_block
setblock ~49 ~-23 ~44 minecraft:air
setblock ~50 ~-23 ~44 minecraft:light_gray_concrete
fill ~51 ~-23 ~44 ~63 ~-23 ~44 minecraft:air
setblock ~64 ~-23 ~44 minecraft:light_gray_concrete
setblock ~4 ~-23 ~45 minecraft:light_gray_concrete
fill ~5 ~-23 ~45 ~17 ~-23 ~45 minecraft:air
setblock ~18 ~-23 ~45 minecraft:light_gray_concrete
fill ~19 ~-23 ~45 ~27 ~-23 ~45 minecraft:air
setblock ~28 ~-23 ~45 minecraft:smooth_quartz
setblock ~29 ~-23 ~45 minecraft:quartz_pillar
fill ~30 ~-23 ~45 ~38 ~-23 ~45 minecraft:air
setblock ~39 ~-23 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-23 ~45 minecraft:smooth_quartz
fill ~41 ~-23 ~45 ~49 ~-23 ~45 minecraft:air
setblock ~50 ~-23 ~45 minecraft:light_gray_concrete
fill ~51 ~-23 ~45 ~63 ~-23 ~45 minecraft:air
setblock ~64 ~-23 ~45 minecraft:light_gray_concrete
setblock ~4 ~-23 ~46 minecraft:light_gray_concrete
fill ~5 ~-23 ~46 ~17 ~-23 ~46 minecraft:air
setblock ~18 ~-23 ~46 minecraft:light_gray_concrete
fill ~19 ~-23 ~46 ~28 ~-23 ~46 minecraft:air
setblock ~29 ~-23 ~46 minecraft:quartz_pillar
fill ~30 ~-23 ~46 ~31 ~-23 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-23 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~33 ~-23 ~46 minecraft:smooth_quartz
setblock ~34 ~-23 ~46 minecraft:air
setblock ~35 ~-23 ~46 minecraft:smooth_quartz
setblock ~36 ~-23 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~37 ~-23 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-23 ~46 minecraft:quartz_pillar
setblock ~39 ~-23 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-23 ~46 ~41 ~-23 ~46 minecraft:air
fill ~42 ~-23 ~46 ~44 ~-23 ~46 minecraft:iron_block
setblock ~45 ~-23 ~46 minecraft:air
fill ~46 ~-23 ~46 ~48 ~-23 ~46 minecraft:iron_block
setblock ~49 ~-23 ~46 minecraft:air
setblock ~50 ~-23 ~46 minecraft:light_gray_concrete
fill ~51 ~-23 ~46 ~63 ~-23 ~46 minecraft:air
setblock ~64 ~-23 ~46 minecraft:light_gray_concrete
setblock ~4 ~-23 ~47 minecraft:light_gray_concrete
fill ~5 ~-23 ~47 ~17 ~-23 ~47 minecraft:air
setblock ~18 ~-23 ~47 minecraft:light_gray_concrete
fill ~19 ~-23 ~47 ~31 ~-23 ~47 minecraft:air
setblock ~32 ~-23 ~47 minecraft:light_gray_concrete
setblock ~33 ~-23 ~47 minecraft:air
setblock ~34 ~-23 ~47 minecraft:smooth_quartz
setblock ~35 ~-23 ~47 minecraft:air
setblock ~36 ~-23 ~47 minecraft:light_gray_concrete
fill ~37 ~-23 ~47 ~41 ~-23 ~47 minecraft:air
fill ~42 ~-23 ~47 ~44 ~-23 ~47 minecraft:iron_block
setblock ~45 ~-23 ~47 minecraft:air
fill ~46 ~-23 ~47 ~48 ~-23 ~47 minecraft:iron_block
setblock ~49 ~-23 ~47 minecraft:air
setblock ~50 ~-23 ~47 minecraft:light_gray_concrete
fill ~51 ~-23 ~47 ~63 ~-23 ~47 minecraft:air
setblock ~64 ~-23 ~47 minecraft:light_gray_concrete
setblock ~4 ~-23 ~48 minecraft:light_gray_concrete
fill ~5 ~-23 ~48 ~17 ~-23 ~48 minecraft:air
setblock ~18 ~-23 ~48 minecraft:light_gray_concrete
fill ~19 ~-23 ~48 ~31 ~-23 ~48 minecraft:air
setblock ~32 ~-23 ~48 minecraft:light_gray_concrete
fill ~33 ~-23 ~48 ~35 ~-23 ~48 minecraft:air
setblock ~36 ~-23 ~48 minecraft:light_gray_concrete
fill ~37 ~-23 ~48 ~41 ~-23 ~48 minecraft:air
fill ~42 ~-23 ~48 ~44 ~-23 ~48 minecraft:iron_block
setblock ~45 ~-23 ~48 minecraft:air
fill ~46 ~-23 ~48 ~48 ~-23 ~48 minecraft:iron_block
setblock ~49 ~-23 ~48 minecraft:air
setblock ~50 ~-23 ~48 minecraft:light_gray_concrete
fill ~51 ~-23 ~48 ~63 ~-23 ~48 minecraft:air
setblock ~64 ~-23 ~48 minecraft:light_gray_concrete
setblock ~4 ~-23 ~49 minecraft:light_gray_concrete
fill ~5 ~-23 ~49 ~17 ~-23 ~49 minecraft:air
setblock ~18 ~-23 ~49 minecraft:light_gray_concrete
fill ~19 ~-23 ~49 ~31 ~-23 ~49 minecraft:air
setblock ~32 ~-23 ~49 minecraft:light_gray_concrete
fill ~33 ~-23 ~49 ~35 ~-23 ~49 minecraft:air
setblock ~36 ~-23 ~49 minecraft:light_gray_concrete
fill ~37 ~-23 ~49 ~49 ~-23 ~49 minecraft:air
setblock ~50 ~-23 ~49 minecraft:light_gray_concrete
fill ~51 ~-23 ~49 ~63 ~-23 ~49 minecraft:air
setblock ~64 ~-23 ~49 minecraft:light_gray_concrete
fill ~4 ~-23 ~50 ~32 ~-23 ~50 minecraft:light_gray_concrete
fill ~33 ~-23 ~50 ~35 ~-23 ~50 minecraft:air
fill ~36 ~-23 ~50 ~64 ~-23 ~50 minecraft:light_gray_concrete
setblock ~4 ~-23 ~51 minecraft:light_gray_concrete
fill ~5 ~-23 ~51 ~17 ~-23 ~51 minecraft:air
setblock ~18 ~-23 ~51 minecraft:light_gray_concrete
fill ~19 ~-23 ~51 ~31 ~-23 ~51 minecraft:air
setblock ~32 ~-23 ~51 minecraft:light_gray_concrete
fill ~33 ~-23 ~51 ~35 ~-23 ~51 minecraft:air
setblock ~36 ~-23 ~51 minecraft:light_gray_concrete
fill ~37 ~-23 ~51 ~49 ~-23 ~51 minecraft:air
setblock ~50 ~-23 ~51 minecraft:light_gray_concrete
fill ~51 ~-23 ~51 ~63 ~-23 ~51 minecraft:air
setblock ~64 ~-23 ~51 minecraft:light_gray_concrete
setblock ~4 ~-23 ~52 minecraft:light_gray_concrete
fill ~5 ~-23 ~52 ~17 ~-23 ~52 minecraft:air
setblock ~18 ~-23 ~52 minecraft:light_gray_concrete
fill ~19 ~-23 ~52 ~31 ~-23 ~52 minecraft:air
setblock ~32 ~-23 ~52 minecraft:light_gray_concrete
fill ~33 ~-23 ~52 ~35 ~-23 ~52 minecraft:air
setblock ~36 ~-23 ~52 minecraft:light_gray_concrete
fill ~37 ~-23 ~52 ~49 ~-23 ~52 minecraft:air
setblock ~50 ~-23 ~52 minecraft:light_gray_concrete
fill ~51 ~-23 ~52 ~63 ~-23 ~52 minecraft:air
setblock ~64 ~-23 ~52 minecraft:light_gray_concrete
setblock ~4 ~-23 ~53 minecraft:light_gray_concrete
fill ~5 ~-23 ~53 ~17 ~-23 ~53 minecraft:air
setblock ~18 ~-23 ~53 minecraft:light_gray_concrete
fill ~19 ~-23 ~53 ~31 ~-23 ~53 minecraft:air
setblock ~32 ~-23 ~53 minecraft:light_gray_concrete
fill ~33 ~-23 ~53 ~35 ~-23 ~53 minecraft:air
setblock ~36 ~-23 ~53 minecraft:light_gray_concrete
fill ~37 ~-23 ~53 ~49 ~-23 ~53 minecraft:air
setblock ~50 ~-23 ~53 minecraft:light_gray_concrete
fill ~51 ~-23 ~53 ~63 ~-23 ~53 minecraft:air
setblock ~64 ~-23 ~53 minecraft:light_gray_concrete
setblock ~4 ~-23 ~54 minecraft:light_gray_concrete
fill ~5 ~-23 ~54 ~17 ~-23 ~54 minecraft:air
setblock ~18 ~-23 ~54 minecraft:light_gray_concrete
fill ~19 ~-23 ~54 ~31 ~-23 ~54 minecraft:air
setblock ~32 ~-23 ~54 minecraft:light_gray_concrete
fill ~33 ~-23 ~54 ~35 ~-23 ~54 minecraft:air
setblock ~36 ~-23 ~54 minecraft:light_gray_concrete
fill ~37 ~-23 ~54 ~49 ~-23 ~54 minecraft:air
setblock ~50 ~-23 ~54 minecraft:light_gray_concrete
fill ~51 ~-23 ~54 ~63 ~-23 ~54 minecraft:air
setblock ~64 ~-23 ~54 minecraft:light_gray_concrete
setblock ~4 ~-23 ~55 minecraft:light_gray_concrete
fill ~5 ~-23 ~55 ~17 ~-23 ~55 minecraft:air
setblock ~18 ~-23 ~55 minecraft:light_gray_concrete
fill ~19 ~-23 ~55 ~31 ~-23 ~55 minecraft:air
setblock ~32 ~-23 ~55 minecraft:light_gray_concrete
fill ~33 ~-23 ~55 ~35 ~-23 ~55 minecraft:air
setblock ~36 ~-23 ~55 minecraft:light_gray_concrete
fill ~37 ~-23 ~55 ~49 ~-23 ~55 minecraft:air
setblock ~50 ~-23 ~55 minecraft:light_gray_concrete
fill ~51 ~-23 ~55 ~63 ~-23 ~55 minecraft:air
setblock ~64 ~-23 ~55 minecraft:light_gray_concrete
setblock ~4 ~-23 ~56 minecraft:light_gray_concrete
fill ~5 ~-23 ~56 ~17 ~-23 ~56 minecraft:air
setblock ~18 ~-23 ~56 minecraft:light_gray_concrete
fill ~19 ~-23 ~56 ~31 ~-23 ~56 minecraft:air
setblock ~32 ~-23 ~56 minecraft:light_gray_concrete
fill ~33 ~-23 ~56 ~35 ~-23 ~56 minecraft:air
setblock ~36 ~-23 ~56 minecraft:light_gray_concrete
fill ~37 ~-23 ~56 ~49 ~-23 ~56 minecraft:air
setblock ~50 ~-23 ~56 minecraft:light_gray_concrete
fill ~51 ~-23 ~56 ~63 ~-23 ~56 minecraft:air
setblock ~64 ~-23 ~56 minecraft:light_gray_concrete
setblock ~4 ~-23 ~57 minecraft:light_gray_concrete
fill ~5 ~-23 ~57 ~17 ~-23 ~57 minecraft:air
setblock ~18 ~-23 ~57 minecraft:light_gray_concrete
fill ~19 ~-23 ~57 ~31 ~-23 ~57 minecraft:air
setblock ~32 ~-23 ~57 minecraft:light_gray_concrete
fill ~33 ~-23 ~57 ~35 ~-23 ~57 minecraft:air
setblock ~36 ~-23 ~57 minecraft:light_gray_concrete
fill ~37 ~-23 ~57 ~49 ~-23 ~57 minecraft:air
setblock ~50 ~-23 ~57 minecraft:light_gray_concrete
fill ~51 ~-23 ~57 ~63 ~-23 ~57 minecraft:air
setblock ~64 ~-23 ~57 minecraft:light_gray_concrete
setblock ~4 ~-23 ~58 minecraft:light_gray_concrete
fill ~5 ~-23 ~58 ~17 ~-23 ~58 minecraft:air
setblock ~18 ~-23 ~58 minecraft:light_gray_concrete
fill ~19 ~-23 ~58 ~31 ~-23 ~58 minecraft:air
setblock ~32 ~-23 ~58 minecraft:light_gray_concrete
fill ~33 ~-23 ~58 ~35 ~-23 ~58 minecraft:air
setblock ~36 ~-23 ~58 minecraft:light_gray_concrete
fill ~37 ~-23 ~58 ~49 ~-23 ~58 minecraft:air
setblock ~50 ~-23 ~58 minecraft:light_gray_concrete
schedule function hive:weiter/13 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 12 von 18 fertig","color":"gray"}]