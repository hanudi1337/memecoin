fill ~19 ~-40 ~56 ~31 ~-40 ~56 minecraft:air
setblock ~32 ~-40 ~56 minecraft:light_gray_concrete
fill ~33 ~-40 ~56 ~35 ~-40 ~56 minecraft:air
setblock ~36 ~-40 ~56 minecraft:light_gray_concrete
fill ~37 ~-40 ~56 ~49 ~-40 ~56 minecraft:air
setblock ~50 ~-40 ~56 minecraft:light_gray_concrete
fill ~51 ~-40 ~56 ~63 ~-40 ~56 minecraft:air
setblock ~64 ~-40 ~56 minecraft:light_gray_concrete
setblock ~4 ~-40 ~57 minecraft:light_gray_concrete
fill ~5 ~-40 ~57 ~17 ~-40 ~57 minecraft:air
setblock ~18 ~-40 ~57 minecraft:light_gray_concrete
fill ~19 ~-40 ~57 ~31 ~-40 ~57 minecraft:air
setblock ~32 ~-40 ~57 minecraft:light_gray_concrete
fill ~33 ~-40 ~57 ~35 ~-40 ~57 minecraft:air
setblock ~36 ~-40 ~57 minecraft:light_gray_concrete
fill ~37 ~-40 ~57 ~49 ~-40 ~57 minecraft:air
setblock ~50 ~-40 ~57 minecraft:light_gray_concrete
fill ~51 ~-40 ~57 ~63 ~-40 ~57 minecraft:air
setblock ~64 ~-40 ~57 minecraft:light_gray_concrete
setblock ~4 ~-40 ~58 minecraft:light_gray_concrete
fill ~5 ~-40 ~58 ~17 ~-40 ~58 minecraft:air
setblock ~18 ~-40 ~58 minecraft:light_gray_concrete
fill ~19 ~-40 ~58 ~31 ~-40 ~58 minecraft:air
setblock ~32 ~-40 ~58 minecraft:light_gray_concrete
fill ~33 ~-40 ~58 ~35 ~-40 ~58 minecraft:air
setblock ~36 ~-40 ~58 minecraft:light_gray_concrete
fill ~37 ~-40 ~58 ~49 ~-40 ~58 minecraft:air
setblock ~50 ~-40 ~58 minecraft:light_gray_concrete
fill ~51 ~-40 ~58 ~63 ~-40 ~58 minecraft:air
setblock ~64 ~-40 ~58 minecraft:light_gray_concrete
setblock ~4 ~-40 ~59 minecraft:light_gray_concrete
fill ~5 ~-40 ~59 ~17 ~-40 ~59 minecraft:air
setblock ~18 ~-40 ~59 minecraft:light_gray_concrete
fill ~19 ~-40 ~59 ~31 ~-40 ~59 minecraft:air
setblock ~32 ~-40 ~59 minecraft:light_gray_concrete
fill ~33 ~-40 ~59 ~35 ~-40 ~59 minecraft:air
setblock ~36 ~-40 ~59 minecraft:light_gray_concrete
fill ~37 ~-40 ~59 ~49 ~-40 ~59 minecraft:air
setblock ~50 ~-40 ~59 minecraft:light_gray_concrete
fill ~51 ~-40 ~59 ~63 ~-40 ~59 minecraft:air
setblock ~64 ~-40 ~59 minecraft:light_gray_concrete
setblock ~4 ~-40 ~60 minecraft:light_gray_concrete
fill ~5 ~-40 ~60 ~17 ~-40 ~60 minecraft:air
setblock ~18 ~-40 ~60 minecraft:light_gray_concrete
setblock ~19 ~-40 ~60 minecraft:waxed_cut_copper
fill ~20 ~-40 ~60 ~30 ~-40 ~60 minecraft:air
setblock ~31 ~-40 ~60 minecraft:waxed_cut_copper
setblock ~32 ~-40 ~60 minecraft:light_gray_concrete
fill ~33 ~-40 ~60 ~35 ~-40 ~60 minecraft:air
setblock ~36 ~-40 ~60 minecraft:light_gray_concrete
fill ~37 ~-40 ~60 ~49 ~-40 ~60 minecraft:air
setblock ~50 ~-40 ~60 minecraft:light_gray_concrete
fill ~51 ~-40 ~60 ~63 ~-40 ~60 minecraft:air
setblock ~64 ~-40 ~60 minecraft:light_gray_concrete
setblock ~4 ~-40 ~61 minecraft:light_gray_concrete
fill ~5 ~-40 ~61 ~17 ~-40 ~61 minecraft:air
setblock ~18 ~-40 ~61 minecraft:light_gray_concrete
fill ~19 ~-40 ~61 ~31 ~-40 ~61 minecraft:air
setblock ~32 ~-40 ~61 minecraft:light_gray_concrete
fill ~33 ~-40 ~61 ~35 ~-40 ~61 minecraft:air
setblock ~36 ~-40 ~61 minecraft:light_gray_concrete
fill ~37 ~-40 ~61 ~49 ~-40 ~61 minecraft:air
setblock ~50 ~-40 ~61 minecraft:light_gray_concrete
fill ~51 ~-40 ~61 ~63 ~-40 ~61 minecraft:air
setblock ~64 ~-40 ~61 minecraft:light_gray_concrete
setblock ~4 ~-40 ~62 minecraft:light_gray_concrete
fill ~5 ~-40 ~62 ~17 ~-40 ~62 minecraft:air
setblock ~18 ~-40 ~62 minecraft:light_gray_concrete
fill ~19 ~-40 ~62 ~31 ~-40 ~62 minecraft:air
setblock ~32 ~-40 ~62 minecraft:light_gray_concrete
fill ~33 ~-40 ~62 ~35 ~-40 ~62 minecraft:air
setblock ~36 ~-40 ~62 minecraft:light_gray_concrete
fill ~37 ~-40 ~62 ~49 ~-40 ~62 minecraft:air
setblock ~50 ~-40 ~62 minecraft:light_gray_concrete
fill ~51 ~-40 ~62 ~63 ~-40 ~62 minecraft:air
setblock ~64 ~-40 ~62 minecraft:light_gray_concrete
setblock ~4 ~-40 ~63 minecraft:light_gray_concrete
fill ~5 ~-40 ~63 ~17 ~-40 ~63 minecraft:air
setblock ~18 ~-40 ~63 minecraft:light_gray_concrete
setblock ~19 ~-40 ~63 minecraft:waxed_cut_copper
fill ~20 ~-40 ~63 ~21 ~-40 ~63 minecraft:air
setblock ~22 ~-40 ~63 minecraft:waxed_cut_copper
fill ~23 ~-40 ~63 ~24 ~-40 ~63 minecraft:air
setblock ~25 ~-40 ~63 minecraft:waxed_cut_copper
fill ~26 ~-40 ~63 ~27 ~-40 ~63 minecraft:air
setblock ~28 ~-40 ~63 minecraft:waxed_cut_copper
fill ~29 ~-40 ~63 ~30 ~-40 ~63 minecraft:air
setblock ~31 ~-40 ~63 minecraft:waxed_cut_copper
setblock ~32 ~-40 ~63 minecraft:light_gray_concrete
fill ~33 ~-40 ~63 ~35 ~-40 ~63 minecraft:air
setblock ~36 ~-40 ~63 minecraft:light_gray_concrete
fill ~37 ~-40 ~63 ~49 ~-40 ~63 minecraft:air
setblock ~50 ~-40 ~63 minecraft:light_gray_concrete
fill ~51 ~-40 ~63 ~63 ~-40 ~63 minecraft:air
setblock ~64 ~-40 ~63 minecraft:light_gray_concrete
fill ~4 ~-40 ~64 ~64 ~-40 ~64 minecraft:light_gray_concrete
fill ~32 ~-40 ~66 ~36 ~-40 ~66 minecraft:polished_andesite
setblock ~32 ~-40 ~67 minecraft:polished_andesite
fill ~33 ~-40 ~67 ~35 ~-40 ~67 minecraft:air
setblock ~36 ~-40 ~67 minecraft:polished_andesite
setblock ~32 ~-40 ~68 minecraft:sea_lantern
setblock ~33 ~-40 ~68 minecraft:air
setblock ~34 ~-40 ~68 minecraft:quartz_pillar
setblock ~35 ~-40 ~68 minecraft:air
setblock ~36 ~-40 ~68 minecraft:sea_lantern
setblock ~32 ~-40 ~69 minecraft:polished_andesite
setblock ~33 ~-40 ~69 minecraft:air
setblock ~34 ~-40 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-40 ~69 minecraft:air
setblock ~36 ~-40 ~69 minecraft:polished_andesite
fill ~32 ~-40 ~70 ~36 ~-40 ~70 minecraft:polished_andesite
fill ~4 ~-39 ~4 ~64 ~-39 ~4 minecraft:light_gray_concrete
setblock ~4 ~-39 ~5 minecraft:light_gray_concrete
fill ~5 ~-39 ~5 ~17 ~-39 ~5 minecraft:air
setblock ~18 ~-39 ~5 minecraft:light_gray_concrete
fill ~19 ~-39 ~5 ~31 ~-39 ~5 minecraft:air
setblock ~32 ~-39 ~5 minecraft:light_gray_concrete
fill ~33 ~-39 ~5 ~35 ~-39 ~5 minecraft:air
setblock ~36 ~-39 ~5 minecraft:light_gray_concrete
fill ~37 ~-39 ~5 ~49 ~-39 ~5 minecraft:air
setblock ~50 ~-39 ~5 minecraft:light_gray_concrete
fill ~51 ~-39 ~5 ~63 ~-39 ~5 minecraft:iron_block
setblock ~64 ~-39 ~5 minecraft:light_gray_concrete
setblock ~4 ~-39 ~6 minecraft:light_gray_concrete
fill ~5 ~-39 ~6 ~17 ~-39 ~6 minecraft:air
setblock ~18 ~-39 ~6 minecraft:light_gray_concrete
fill ~19 ~-39 ~6 ~31 ~-39 ~6 minecraft:air
setblock ~32 ~-39 ~6 minecraft:light_gray_concrete
fill ~33 ~-39 ~6 ~35 ~-39 ~6 minecraft:air
setblock ~36 ~-39 ~6 minecraft:light_gray_concrete
fill ~37 ~-39 ~6 ~49 ~-39 ~6 minecraft:air
setblock ~50 ~-39 ~6 minecraft:light_gray_concrete
setblock ~51 ~-39 ~6 minecraft:iron_block
fill ~52 ~-39 ~6 ~62 ~-39 ~6 minecraft:air
setblock ~63 ~-39 ~6 minecraft:iron_block
setblock ~64 ~-39 ~6 minecraft:light_gray_concrete
setblock ~4 ~-39 ~7 minecraft:light_gray_concrete
fill ~5 ~-39 ~7 ~17 ~-39 ~7 minecraft:air
setblock ~18 ~-39 ~7 minecraft:light_gray_concrete
fill ~19 ~-39 ~7 ~31 ~-39 ~7 minecraft:air
setblock ~32 ~-39 ~7 minecraft:light_gray_concrete
fill ~33 ~-39 ~7 ~35 ~-39 ~7 minecraft:air
setblock ~36 ~-39 ~7 minecraft:light_gray_concrete
fill ~37 ~-39 ~7 ~49 ~-39 ~7 minecraft:air
setblock ~50 ~-39 ~7 minecraft:light_gray_concrete
setblock ~51 ~-39 ~7 minecraft:iron_block
fill ~52 ~-39 ~7 ~62 ~-39 ~7 minecraft:air
setblock ~63 ~-39 ~7 minecraft:iron_block
setblock ~64 ~-39 ~7 minecraft:light_gray_concrete
setblock ~4 ~-39 ~8 minecraft:light_gray_concrete
fill ~5 ~-39 ~8 ~17 ~-39 ~8 minecraft:air
setblock ~18 ~-39 ~8 minecraft:light_gray_concrete
fill ~19 ~-39 ~8 ~31 ~-39 ~8 minecraft:air
setblock ~32 ~-39 ~8 minecraft:light_gray_concrete
fill ~33 ~-39 ~8 ~35 ~-39 ~8 minecraft:air
setblock ~36 ~-39 ~8 minecraft:light_gray_concrete
fill ~37 ~-39 ~8 ~49 ~-39 ~8 minecraft:air
setblock ~50 ~-39 ~8 minecraft:light_gray_concrete
setblock ~51 ~-39 ~8 minecraft:iron_block
fill ~52 ~-39 ~8 ~62 ~-39 ~8 minecraft:air
setblock ~63 ~-39 ~8 minecraft:iron_block
setblock ~64 ~-39 ~8 minecraft:light_gray_concrete
setblock ~4 ~-39 ~9 minecraft:light_gray_concrete
fill ~5 ~-39 ~9 ~17 ~-39 ~9 minecraft:air
setblock ~18 ~-39 ~9 minecraft:light_gray_concrete
fill ~19 ~-39 ~9 ~31 ~-39 ~9 minecraft:air
setblock ~32 ~-39 ~9 minecraft:light_gray_concrete
fill ~33 ~-39 ~9 ~35 ~-39 ~9 minecraft:air
setblock ~36 ~-39 ~9 minecraft:light_gray_concrete
fill ~37 ~-39 ~9 ~49 ~-39 ~9 minecraft:air
setblock ~50 ~-39 ~9 minecraft:light_gray_concrete
setblock ~51 ~-39 ~9 minecraft:iron_block
fill ~52 ~-39 ~9 ~62 ~-39 ~9 minecraft:air
setblock ~63 ~-39 ~9 minecraft:iron_block
setblock ~64 ~-39 ~9 minecraft:light_gray_concrete
setblock ~4 ~-39 ~10 minecraft:light_gray_concrete
fill ~5 ~-39 ~10 ~17 ~-39 ~10 minecraft:air
setblock ~18 ~-39 ~10 minecraft:light_gray_concrete
fill ~19 ~-39 ~10 ~31 ~-39 ~10 minecraft:air
setblock ~32 ~-39 ~10 minecraft:light_gray_concrete
fill ~33 ~-39 ~10 ~35 ~-39 ~10 minecraft:air
setblock ~36 ~-39 ~10 minecraft:light_gray_concrete
fill ~37 ~-39 ~10 ~49 ~-39 ~10 minecraft:air
setblock ~50 ~-39 ~10 minecraft:light_gray_concrete
fill ~51 ~-39 ~10 ~62 ~-39 ~10 minecraft:air
setblock ~63 ~-39 ~10 minecraft:iron_block
setblock ~64 ~-39 ~10 minecraft:light_gray_concrete
setblock ~4 ~-39 ~11 minecraft:light_gray_concrete
fill ~5 ~-39 ~11 ~17 ~-39 ~11 minecraft:air
setblock ~18 ~-39 ~11 minecraft:light_gray_concrete
fill ~19 ~-39 ~11 ~31 ~-39 ~11 minecraft:air
setblock ~32 ~-39 ~11 minecraft:light_gray_concrete
fill ~33 ~-39 ~11 ~35 ~-39 ~11 minecraft:air
setblock ~36 ~-39 ~11 minecraft:light_gray_concrete
fill ~37 ~-39 ~11 ~49 ~-39 ~11 minecraft:air
setblock ~50 ~-39 ~11 minecraft:light_gray_concrete
fill ~51 ~-39 ~11 ~62 ~-39 ~11 minecraft:air
setblock ~63 ~-39 ~11 minecraft:iron_block
setblock ~64 ~-39 ~11 minecraft:light_gray_concrete
setblock ~4 ~-39 ~12 minecraft:light_gray_concrete
fill ~5 ~-39 ~12 ~17 ~-39 ~12 minecraft:air
setblock ~18 ~-39 ~12 minecraft:light_gray_concrete
fill ~19 ~-39 ~12 ~31 ~-39 ~12 minecraft:air
setblock ~32 ~-39 ~12 minecraft:light_gray_concrete
fill ~33 ~-39 ~12 ~35 ~-39 ~12 minecraft:air
setblock ~36 ~-39 ~12 minecraft:light_gray_concrete
fill ~37 ~-39 ~12 ~49 ~-39 ~12 minecraft:air
setblock ~50 ~-39 ~12 minecraft:light_gray_concrete
fill ~51 ~-39 ~12 ~62 ~-39 ~12 minecraft:air
setblock ~63 ~-39 ~12 minecraft:iron_block
setblock ~64 ~-39 ~12 minecraft:light_gray_concrete
setblock ~4 ~-39 ~13 minecraft:light_gray_concrete
fill ~5 ~-39 ~13 ~17 ~-39 ~13 minecraft:air
setblock ~18 ~-39 ~13 minecraft:light_gray_concrete
fill ~19 ~-39 ~13 ~31 ~-39 ~13 minecraft:air
setblock ~32 ~-39 ~13 minecraft:light_gray_concrete
fill ~33 ~-39 ~13 ~35 ~-39 ~13 minecraft:air
setblock ~36 ~-39 ~13 minecraft:light_gray_concrete
fill ~37 ~-39 ~13 ~49 ~-39 ~13 minecraft:air
setblock ~50 ~-39 ~13 minecraft:light_gray_concrete
setblock ~51 ~-39 ~13 minecraft:iron_block
fill ~52 ~-39 ~13 ~62 ~-39 ~13 minecraft:air
setblock ~63 ~-39 ~13 minecraft:iron_block
setblock ~64 ~-39 ~13 minecraft:light_gray_concrete
setblock ~4 ~-39 ~14 minecraft:light_gray_concrete
fill ~5 ~-39 ~14 ~17 ~-39 ~14 minecraft:air
setblock ~18 ~-39 ~14 minecraft:light_gray_concrete
fill ~19 ~-39 ~14 ~31 ~-39 ~14 minecraft:air
setblock ~32 ~-39 ~14 minecraft:light_gray_concrete
fill ~33 ~-39 ~14 ~35 ~-39 ~14 minecraft:air
setblock ~36 ~-39 ~14 minecraft:light_gray_concrete
fill ~37 ~-39 ~14 ~49 ~-39 ~14 minecraft:air
setblock ~50 ~-39 ~14 minecraft:light_gray_concrete
setblock ~51 ~-39 ~14 minecraft:iron_block
fill ~52 ~-39 ~14 ~62 ~-39 ~14 minecraft:air
setblock ~63 ~-39 ~14 minecraft:iron_block
setblock ~64 ~-39 ~14 minecraft:light_gray_concrete
setblock ~4 ~-39 ~15 minecraft:light_gray_concrete
fill ~5 ~-39 ~15 ~17 ~-39 ~15 minecraft:air
setblock ~18 ~-39 ~15 minecraft:light_gray_concrete
fill ~19 ~-39 ~15 ~31 ~-39 ~15 minecraft:air
setblock ~32 ~-39 ~15 minecraft:light_gray_concrete
fill ~33 ~-39 ~15 ~35 ~-39 ~15 minecraft:air
setblock ~36 ~-39 ~15 minecraft:light_gray_concrete
fill ~37 ~-39 ~15 ~49 ~-39 ~15 minecraft:air
setblock ~50 ~-39 ~15 minecraft:light_gray_concrete
setblock ~51 ~-39 ~15 minecraft:iron_block
fill ~52 ~-39 ~15 ~62 ~-39 ~15 minecraft:air
setblock ~63 ~-39 ~15 minecraft:iron_block
setblock ~64 ~-39 ~15 minecraft:light_gray_concrete
setblock ~4 ~-39 ~16 minecraft:light_gray_concrete
fill ~5 ~-39 ~16 ~17 ~-39 ~16 minecraft:air
setblock ~18 ~-39 ~16 minecraft:light_gray_concrete
fill ~19 ~-39 ~16 ~31 ~-39 ~16 minecraft:air
setblock ~32 ~-39 ~16 minecraft:light_gray_concrete
fill ~33 ~-39 ~16 ~35 ~-39 ~16 minecraft:air
setblock ~36 ~-39 ~16 minecraft:light_gray_concrete
fill ~37 ~-39 ~16 ~49 ~-39 ~16 minecraft:air
setblock ~50 ~-39 ~16 minecraft:light_gray_concrete
setblock ~51 ~-39 ~16 minecraft:iron_block
fill ~52 ~-39 ~16 ~62 ~-39 ~16 minecraft:air
setblock ~63 ~-39 ~16 minecraft:iron_block
setblock ~64 ~-39 ~16 minecraft:light_gray_concrete
setblock ~4 ~-39 ~17 minecraft:light_gray_concrete
fill ~5 ~-39 ~17 ~17 ~-39 ~17 minecraft:air
setblock ~18 ~-39 ~17 minecraft:light_gray_concrete
fill ~19 ~-39 ~17 ~31 ~-39 ~17 minecraft:air
setblock ~32 ~-39 ~17 minecraft:light_gray_concrete
fill ~33 ~-39 ~17 ~35 ~-39 ~17 minecraft:air
setblock ~36 ~-39 ~17 minecraft:light_gray_concrete
fill ~37 ~-39 ~17 ~49 ~-39 ~17 minecraft:air
setblock ~50 ~-39 ~17 minecraft:light_gray_concrete
fill ~51 ~-39 ~17 ~55 ~-39 ~17 minecraft:iron_block
fill ~56 ~-39 ~17 ~58 ~-39 ~17 minecraft:air
fill ~59 ~-39 ~17 ~63 ~-39 ~17 minecraft:iron_block
setblock ~64 ~-39 ~17 minecraft:light_gray_concrete
fill ~4 ~-39 ~18 ~32 ~-39 ~18 minecraft:light_gray_concrete
fill ~33 ~-39 ~18 ~35 ~-39 ~18 minecraft:air
fill ~36 ~-39 ~18 ~64 ~-39 ~18 minecraft:light_gray_concrete
setblock ~4 ~-39 ~19 minecraft:light_gray_concrete
setblock ~5 ~-39 ~19 minecraft:air
setblock ~6 ~-39 ~19 minecraft:waxed_cut_copper
fill ~7 ~-39 ~19 ~8 ~-39 ~19 minecraft:air
setblock ~9 ~-39 ~19 minecraft:waxed_cut_copper
fill ~10 ~-39 ~19 ~14 ~-39 ~19 minecraft:air
setblock ~15 ~-39 ~19 minecraft:waxed_cut_copper
fill ~16 ~-39 ~19 ~17 ~-39 ~19 minecraft:air
setblock ~18 ~-39 ~19 minecraft:light_gray_concrete
fill ~19 ~-39 ~19 ~30 ~-39 ~19 minecraft:black_concrete
setblock ~31 ~-39 ~19 minecraft:air
setblock ~32 ~-39 ~19 minecraft:light_gray_concrete
fill ~33 ~-39 ~19 ~35 ~-39 ~19 minecraft:air
setblock ~36 ~-39 ~19 minecraft:light_gray_concrete
fill ~37 ~-39 ~19 ~49 ~-39 ~19 minecraft:air
setblock ~50 ~-39 ~19 minecraft:light_gray_concrete
fill ~51 ~-39 ~19 ~63 ~-39 ~19 minecraft:air
setblock ~64 ~-39 ~19 minecraft:light_gray_concrete
setblock ~4 ~-39 ~20 minecraft:light_gray_concrete
setblock ~5 ~-39 ~20 minecraft:waxed_cut_copper
fill ~6 ~-39 ~20 ~16 ~-39 ~20 minecraft:air
setblock ~17 ~-39 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-39 ~20 minecraft:light_gray_concrete
fill ~19 ~-39 ~20 ~31 ~-39 ~20 minecraft:air
setblock ~32 ~-39 ~20 minecraft:light_gray_concrete
fill ~33 ~-39 ~20 ~35 ~-39 ~20 minecraft:air
setblock ~36 ~-39 ~20 minecraft:light_gray_concrete
fill ~37 ~-39 ~20 ~49 ~-39 ~20 minecraft:air
setblock ~50 ~-39 ~20 minecraft:light_gray_concrete
fill ~51 ~-39 ~20 ~63 ~-39 ~20 minecraft:air
setblock ~64 ~-39 ~20 minecraft:light_gray_concrete
setblock ~4 ~-39 ~21 minecraft:light_gray_concrete
fill ~5 ~-39 ~21 ~17 ~-39 ~21 minecraft:air
setblock ~18 ~-39 ~21 minecraft:light_gray_concrete
fill ~19 ~-39 ~21 ~31 ~-39 ~21 minecraft:air
setblock ~32 ~-39 ~21 minecraft:light_gray_concrete
setblock ~33 ~-39 ~21 minecraft:air
setblock ~34 ~-39 ~21 minecraft:smooth_quartz
setblock ~35 ~-39 ~21 minecraft:air
setblock ~36 ~-39 ~21 minecraft:light_gray_concrete
fill ~37 ~-39 ~21 ~49 ~-39 ~21 minecraft:air
setblock ~50 ~-39 ~21 minecraft:light_gray_concrete
fill ~51 ~-39 ~21 ~63 ~-39 ~21 minecraft:air
setblock ~64 ~-39 ~21 minecraft:light_gray_concrete
setblock ~4 ~-39 ~22 minecraft:light_gray_concrete
fill ~5 ~-39 ~22 ~17 ~-39 ~22 minecraft:air
setblock ~18 ~-39 ~22 minecraft:light_gray_concrete
fill ~19 ~-39 ~22 ~28 ~-39 ~22 minecraft:air
setblock ~29 ~-39 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-39 ~22 minecraft:quartz_pillar
setblock ~31 ~-39 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-39 ~22 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~33 ~-39 ~22 minecraft:smooth_quartz
setblock ~34 ~-39 ~22 minecraft:air
setblock ~35 ~-39 ~22 minecraft:smooth_quartz
setblock ~36 ~-39 ~22 minecraft:glass_pane[north=true,east=true,west=true]
fill ~37 ~-39 ~22 ~38 ~-39 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-39 ~22 minecraft:quartz_pillar
fill ~40 ~-39 ~22 ~49 ~-39 ~22 minecraft:air
setblock ~50 ~-39 ~22 minecraft:light_gray_concrete
fill ~51 ~-39 ~22 ~63 ~-39 ~22 minecraft:air
setblock ~64 ~-39 ~22 minecraft:light_gray_concrete
setblock ~4 ~-39 ~23 minecraft:light_gray_concrete
setblock ~5 ~-39 ~23 minecraft:waxed_cut_copper
fill ~6 ~-39 ~23 ~16 ~-39 ~23 minecraft:air
setblock ~17 ~-39 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-39 ~23 minecraft:light_gray_concrete
fill ~19 ~-39 ~23 ~27 ~-39 ~23 minecraft:air
setblock ~28 ~-39 ~23 minecraft:smooth_quartz
setblock ~29 ~-39 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-39 ~23 ~38 ~-39 ~23 minecraft:air
setblock ~39 ~-39 ~23 minecraft:quartz_pillar
setblock ~40 ~-39 ~23 minecraft:smooth_quartz
fill ~41 ~-39 ~23 ~49 ~-39 ~23 minecraft:air
setblock ~50 ~-39 ~23 minecraft:light_gray_concrete
fill ~51 ~-39 ~23 ~63 ~-39 ~23 minecraft:air
setblock ~64 ~-39 ~23 minecraft:light_gray_concrete
setblock ~4 ~-39 ~24 minecraft:light_gray_concrete
fill ~5 ~-39 ~24 ~17 ~-39 ~24 minecraft:air
setblock ~18 ~-39 ~24 minecraft:light_gray_concrete
fill ~19 ~-39 ~24 ~25 ~-39 ~24 minecraft:air
setblock ~26 ~-39 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-39 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-39 ~24 ~29 ~-39 ~24 minecraft:air
setblock ~30 ~-39 ~24 minecraft:quartz_pillar
fill ~31 ~-39 ~24 ~37 ~-39 ~24 minecraft:air
setblock ~38 ~-39 ~24 minecraft:quartz_pillar
fill ~39 ~-39 ~24 ~40 ~-39 ~24 minecraft:air
setblock ~41 ~-39 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-39 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-39 ~24 ~49 ~-39 ~24 minecraft:air
setblock ~50 ~-39 ~24 minecraft:light_gray_concrete
fill ~51 ~-39 ~24 ~63 ~-39 ~24 minecraft:air
setblock ~64 ~-39 ~24 minecraft:light_gray_concrete
setblock ~4 ~-39 ~25 minecraft:light_gray_concrete
fill ~5 ~-39 ~25 ~17 ~-39 ~25 minecraft:air
setblock ~18 ~-39 ~25 minecraft:light_gray_concrete
fill ~19 ~-39 ~25 ~24 ~-39 ~25 minecraft:air
fill ~25 ~-39 ~25 ~26 ~-39 ~25 minecraft:quartz_pillar
fill ~27 ~-39 ~25 ~41 ~-39 ~25 minecraft:air
setblock ~42 ~-39 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-39 ~25 minecraft:quartz_pillar
fill ~44 ~-39 ~25 ~49 ~-39 ~25 minecraft:air
setblock ~50 ~-39 ~25 minecraft:light_gray_concrete
fill ~51 ~-39 ~25 ~63 ~-39 ~25 minecraft:air
setblock ~64 ~-39 ~25 minecraft:light_gray_concrete
setblock ~4 ~-39 ~26 minecraft:light_gray_concrete
setblock ~5 ~-39 ~26 minecraft:waxed_cut_copper
fill ~6 ~-39 ~26 ~16 ~-39 ~26 minecraft:air
setblock ~17 ~-39 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-39 ~26 minecraft:light_gray_concrete
fill ~19 ~-39 ~26 ~23 ~-39 ~26 minecraft:air
setblock ~24 ~-39 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-39 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-39 ~26 ~42 ~-39 ~26 minecraft:air
setblock ~43 ~-39 ~26 minecraft:quartz_pillar
setblock ~44 ~-39 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-39 ~26 ~49 ~-39 ~26 minecraft:air
setblock ~50 ~-39 ~26 minecraft:light_gray_concrete
fill ~51 ~-39 ~26 ~63 ~-39 ~26 minecraft:air
setblock ~64 ~-39 ~26 minecraft:light_gray_concrete
setblock ~4 ~-39 ~27 minecraft:light_gray_concrete
fill ~5 ~-39 ~27 ~17 ~-39 ~27 minecraft:air
setblock ~18 ~-39 ~27 minecraft:light_gray_concrete
fill ~19 ~-39 ~27 ~23 ~-39 ~27 minecraft:air
setblock ~24 ~-39 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-39 ~27 ~43 ~-39 ~27 minecraft:air
setblock ~44 ~-39 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-39 ~27 ~49 ~-39 ~27 minecraft:air
setblock ~50 ~-39 ~27 minecraft:light_gray_concrete
fill ~51 ~-39 ~27 ~63 ~-39 ~27 minecraft:air
setblock ~64 ~-39 ~27 minecraft:light_gray_concrete
setblock ~4 ~-39 ~28 minecraft:light_gray_concrete
fill ~5 ~-39 ~28 ~17 ~-39 ~28 minecraft:air
setblock ~18 ~-39 ~28 minecraft:light_gray_concrete
fill ~19 ~-39 ~28 ~22 ~-39 ~28 minecraft:air
setblock ~23 ~-39 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-39 ~28 ~44 ~-39 ~28 minecraft:air
setblock ~45 ~-39 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-39 ~28 ~49 ~-39 ~28 minecraft:air
setblock ~50 ~-39 ~28 minecraft:light_gray_concrete
fill ~51 ~-39 ~28 ~63 ~-39 ~28 minecraft:air
setblock ~64 ~-39 ~28 minecraft:light_gray_concrete
setblock ~4 ~-39 ~29 minecraft:light_gray_concrete
setblock ~5 ~-39 ~29 minecraft:waxed_cut_copper
fill ~6 ~-39 ~29 ~16 ~-39 ~29 minecraft:air
setblock ~17 ~-39 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-39 ~29 minecraft:light_gray_concrete
fill ~19 ~-39 ~29 ~21 ~-39 ~29 minecraft:air
fill ~22 ~-39 ~29 ~23 ~-39 ~29 minecraft:quartz_pillar
fill ~24 ~-39 ~29 ~44 ~-39 ~29 minecraft:air
setblock ~45 ~-39 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-39 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-39 ~29 ~49 ~-39 ~29 minecraft:air
setblock ~50 ~-39 ~29 minecraft:light_gray_concrete
fill ~51 ~-39 ~29 ~63 ~-39 ~29 minecraft:air
setblock ~64 ~-39 ~29 minecraft:light_gray_concrete
setblock ~4 ~-39 ~30 minecraft:light_gray_concrete
fill ~5 ~-39 ~30 ~17 ~-39 ~30 minecraft:air
setblock ~18 ~-39 ~30 minecraft:light_gray_concrete
fill ~19 ~-39 ~30 ~21 ~-39 ~30 minecraft:air
setblock ~22 ~-39 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-39 ~30 minecraft:air
setblock ~24 ~-39 ~30 minecraft:quartz_pillar
fill ~25 ~-39 ~30 ~43 ~-39 ~30 minecraft:air
setblock ~44 ~-39 ~30 minecraft:quartz_pillar
setblock ~45 ~-39 ~30 minecraft:air
setblock ~46 ~-39 ~30 minecraft:quartz_pillar
fill ~47 ~-39 ~30 ~49 ~-39 ~30 minecraft:air
setblock ~50 ~-39 ~30 minecraft:light_gray_concrete
fill ~51 ~-39 ~30 ~63 ~-39 ~30 minecraft:air
setblock ~64 ~-39 ~30 minecraft:light_gray_concrete
setblock ~4 ~-39 ~31 minecraft:light_gray_concrete
setblock ~5 ~-39 ~31 minecraft:air
setblock ~6 ~-39 ~31 minecraft:waxed_cut_copper
fill ~7 ~-39 ~31 ~8 ~-39 ~31 minecraft:air
setblock ~9 ~-39 ~31 minecraft:waxed_cut_copper
fill ~10 ~-39 ~31 ~14 ~-39 ~31 minecraft:air
setblock ~15 ~-39 ~31 minecraft:waxed_cut_copper
fill ~16 ~-39 ~31 ~17 ~-39 ~31 minecraft:air
setblock ~18 ~-39 ~31 minecraft:light_gray_concrete
fill ~19 ~-39 ~31 ~21 ~-39 ~31 minecraft:air
setblock ~22 ~-39 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-39 ~31 ~45 ~-39 ~31 minecraft:air
setblock ~46 ~-39 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-39 ~31 ~49 ~-39 ~31 minecraft:air
setblock ~50 ~-39 ~31 minecraft:light_gray_concrete
fill ~51 ~-39 ~31 ~63 ~-39 ~31 minecraft:air
setblock ~64 ~-39 ~31 minecraft:light_gray_concrete
fill ~4 ~-39 ~32 ~21 ~-39 ~32 minecraft:light_gray_concrete
setblock ~22 ~-39 ~32 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-39 ~32 ~32 ~-39 ~32 minecraft:air
fill ~33 ~-39 ~32 ~35 ~-39 ~32 minecraft:glass
fill ~36 ~-39 ~32 ~45 ~-39 ~32 minecraft:air
setblock ~46 ~-39 ~32 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-39 ~32 ~64 ~-39 ~32 minecraft:light_gray_concrete
setblock ~4 ~-39 ~33 minecraft:light_gray_concrete
fill ~5 ~-39 ~33 ~21 ~-39 ~33 minecraft:air
setblock ~22 ~-39 ~33 minecraft:smooth_quartz
fill ~23 ~-39 ~33 ~32 ~-39 ~33 minecraft:air
setblock ~33 ~-39 ~33 minecraft:glass
setblock ~34 ~-39 ~33 minecraft:air
setblock ~35 ~-39 ~33 minecraft:glass
fill ~36 ~-39 ~33 ~45 ~-39 ~33 minecraft:air
setblock ~46 ~-39 ~33 minecraft:smooth_quartz
fill ~47 ~-39 ~33 ~63 ~-39 ~33 minecraft:air
setblock ~64 ~-39 ~33 minecraft:light_gray_concrete
setblock ~4 ~-39 ~34 minecraft:light_gray_concrete
fill ~5 ~-39 ~34 ~20 ~-39 ~34 minecraft:air
setblock ~21 ~-39 ~34 minecraft:smooth_quartz
fill ~22 ~-39 ~34 ~32 ~-39 ~34 minecraft:air
fill ~33 ~-39 ~34 ~35 ~-39 ~34 minecraft:glass
fill ~36 ~-39 ~34 ~46 ~-39 ~34 minecraft:air
setblock ~47 ~-39 ~34 minecraft:smooth_quartz
fill ~48 ~-39 ~34 ~63 ~-39 ~34 minecraft:air
setblock ~64 ~-39 ~34 minecraft:light_gray_concrete
setblock ~4 ~-39 ~35 minecraft:light_gray_concrete
fill ~5 ~-39 ~35 ~21 ~-39 ~35 minecraft:air
setblock ~22 ~-39 ~35 minecraft:smooth_quartz
fill ~23 ~-39 ~35 ~32 ~-39 ~35 minecraft:air
setblock ~33 ~-39 ~35 minecraft:glass
setblock ~34 ~-39 ~35 minecraft:air
setblock ~35 ~-39 ~35 minecraft:glass
fill ~36 ~-39 ~35 ~45 ~-39 ~35 minecraft:air
setblock ~46 ~-39 ~35 minecraft:smooth_quartz
fill ~47 ~-39 ~35 ~63 ~-39 ~35 minecraft:air
setblock ~64 ~-39 ~35 minecraft:light_gray_concrete
fill ~4 ~-39 ~36 ~21 ~-39 ~36 minecraft:light_gray_concrete
setblock ~22 ~-39 ~36 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-39 ~36 ~32 ~-39 ~36 minecraft:air
fill ~33 ~-39 ~36 ~35 ~-39 ~36 minecraft:glass
fill ~36 ~-39 ~36 ~45 ~-39 ~36 minecraft:air
setblock ~46 ~-39 ~36 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-39 ~36 ~64 ~-39 ~36 minecraft:light_gray_concrete
setblock ~4 ~-39 ~37 minecraft:light_gray_concrete
fill ~5 ~-39 ~37 ~17 ~-39 ~37 minecraft:air
setblock ~18 ~-39 ~37 minecraft:light_gray_concrete
fill ~19 ~-39 ~37 ~21 ~-39 ~37 minecraft:air
setblock ~22 ~-39 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-39 ~37 ~45 ~-39 ~37 minecraft:air
setblock ~46 ~-39 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-39 ~37 ~49 ~-39 ~37 minecraft:air
setblock ~50 ~-39 ~37 minecraft:light_gray_concrete
fill ~51 ~-39 ~37 ~63 ~-39 ~37 minecraft:air
setblock ~64 ~-39 ~37 minecraft:light_gray_concrete
setblock ~4 ~-39 ~38 minecraft:light_gray_concrete
fill ~5 ~-39 ~38 ~17 ~-39 ~38 minecraft:air
setblock ~18 ~-39 ~38 minecraft:light_gray_concrete
fill ~19 ~-39 ~38 ~21 ~-39 ~38 minecraft:air
setblock ~22 ~-39 ~38 minecraft:quartz_pillar
setblock ~23 ~-39 ~38 minecraft:air
setblock ~24 ~-39 ~38 minecraft:quartz_pillar
fill ~25 ~-39 ~38 ~43 ~-39 ~38 minecraft:air
setblock ~44 ~-39 ~38 minecraft:quartz_pillar
setblock ~45 ~-39 ~38 minecraft:air
setblock ~46 ~-39 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-39 ~38 ~49 ~-39 ~38 minecraft:air
setblock ~50 ~-39 ~38 minecraft:light_gray_concrete
fill ~51 ~-39 ~38 ~63 ~-39 ~38 minecraft:air
setblock ~64 ~-39 ~38 minecraft:light_gray_concrete
setblock ~4 ~-39 ~39 minecraft:light_gray_concrete
fill ~5 ~-39 ~39 ~17 ~-39 ~39 minecraft:air
setblock ~18 ~-39 ~39 minecraft:light_gray_concrete
fill ~19 ~-39 ~39 ~21 ~-39 ~39 minecraft:air
setblock ~22 ~-39 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-39 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-39 ~39 ~44 ~-39 ~39 minecraft:air
fill ~45 ~-39 ~39 ~46 ~-39 ~39 minecraft:quartz_pillar
fill ~47 ~-39 ~39 ~49 ~-39 ~39 minecraft:air
setblock ~50 ~-39 ~39 minecraft:light_gray_concrete
fill ~51 ~-39 ~39 ~63 ~-39 ~39 minecraft:air
setblock ~64 ~-39 ~39 minecraft:light_gray_concrete
setblock ~4 ~-39 ~40 minecraft:light_gray_concrete
fill ~5 ~-39 ~40 ~17 ~-39 ~40 minecraft:air
setblock ~18 ~-39 ~40 minecraft:light_gray_concrete
fill ~19 ~-39 ~40 ~22 ~-39 ~40 minecraft:air
setblock ~23 ~-39 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-39 ~40 ~44 ~-39 ~40 minecraft:air
setblock ~45 ~-39 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-39 ~40 ~49 ~-39 ~40 minecraft:air
setblock ~50 ~-39 ~40 minecraft:light_gray_concrete
fill ~51 ~-39 ~40 ~63 ~-39 ~40 minecraft:air
setblock ~64 ~-39 ~40 minecraft:light_gray_concrete
setblock ~4 ~-39 ~41 minecraft:light_gray_concrete
fill ~5 ~-39 ~41 ~17 ~-39 ~41 minecraft:air
setblock ~18 ~-39 ~41 minecraft:light_gray_concrete
fill ~19 ~-39 ~41 ~23 ~-39 ~41 minecraft:air
setblock ~24 ~-39 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-39 ~41 ~43 ~-39 ~41 minecraft:air
setblock ~44 ~-39 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-39 ~41 ~49 ~-39 ~41 minecraft:air
setblock ~50 ~-39 ~41 minecraft:light_gray_concrete
fill ~51 ~-39 ~41 ~63 ~-39 ~41 minecraft:air
setblock ~64 ~-39 ~41 minecraft:light_gray_concrete
setblock ~4 ~-39 ~42 minecraft:light_gray_concrete
fill ~5 ~-39 ~42 ~17 ~-39 ~42 minecraft:air
setblock ~18 ~-39 ~42 minecraft:light_gray_concrete
fill ~19 ~-39 ~42 ~23 ~-39 ~42 minecraft:air
setblock ~24 ~-39 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-39 ~42 minecraft:quartz_pillar
fill ~26 ~-39 ~42 ~42 ~-39 ~42 minecraft:air
setblock ~43 ~-39 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-39 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-39 ~42 ~49 ~-39 ~42 minecraft:air
setblock ~50 ~-39 ~42 minecraft:light_gray_concrete
fill ~51 ~-39 ~42 ~63 ~-39 ~42 minecraft:air
setblock ~64 ~-39 ~42 minecraft:light_gray_concrete
setblock ~4 ~-39 ~43 minecraft:light_gray_concrete
fill ~5 ~-39 ~43 ~17 ~-39 ~43 minecraft:air
setblock ~18 ~-39 ~43 minecraft:light_gray_concrete
fill ~19 ~-39 ~43 ~24 ~-39 ~43 minecraft:air
setblock ~25 ~-39 ~43 minecraft:quartz_pillar
setblock ~26 ~-39 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-39 ~43 ~41 ~-39 ~43 minecraft:air
fill ~42 ~-39 ~43 ~43 ~-39 ~43 minecraft:quartz_pillar
fill ~44 ~-39 ~43 ~49 ~-39 ~43 minecraft:air
setblock ~50 ~-39 ~43 minecraft:light_gray_concrete
fill ~51 ~-39 ~43 ~63 ~-39 ~43 minecraft:air
setblock ~64 ~-39 ~43 minecraft:light_gray_concrete
setblock ~4 ~-39 ~44 minecraft:light_gray_concrete
fill ~5 ~-39 ~44 ~17 ~-39 ~44 minecraft:air
setblock ~18 ~-39 ~44 minecraft:light_gray_concrete
fill ~19 ~-39 ~44 ~25 ~-39 ~44 minecraft:air
setblock ~26 ~-39 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-39 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-39 ~44 ~29 ~-39 ~44 minecraft:air
setblock ~30 ~-39 ~44 minecraft:quartz_pillar
fill ~31 ~-39 ~44 ~37 ~-39 ~44 minecraft:air
setblock ~38 ~-39 ~44 minecraft:quartz_pillar
fill ~39 ~-39 ~44 ~40 ~-39 ~44 minecraft:air
setblock ~41 ~-39 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-39 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-39 ~44 ~49 ~-39 ~44 minecraft:air
setblock ~50 ~-39 ~44 minecraft:light_gray_concrete
fill ~51 ~-39 ~44 ~63 ~-39 ~44 minecraft:air
setblock ~64 ~-39 ~44 minecraft:light_gray_concrete
setblock ~4 ~-39 ~45 minecraft:light_gray_concrete
fill ~5 ~-39 ~45 ~17 ~-39 ~45 minecraft:air
setblock ~18 ~-39 ~45 minecraft:light_gray_concrete
fill ~19 ~-39 ~45 ~27 ~-39 ~45 minecraft:air
setblock ~28 ~-39 ~45 minecraft:smooth_quartz
setblock ~29 ~-39 ~45 minecraft:quartz_pillar
fill ~30 ~-39 ~45 ~38 ~-39 ~45 minecraft:air
setblock ~39 ~-39 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-39 ~45 minecraft:smooth_quartz
fill ~41 ~-39 ~45 ~49 ~-39 ~45 minecraft:air
setblock ~50 ~-39 ~45 minecraft:light_gray_concrete
fill ~51 ~-39 ~45 ~63 ~-39 ~45 minecraft:air
setblock ~64 ~-39 ~45 minecraft:light_gray_concrete
setblock ~4 ~-39 ~46 minecraft:light_gray_concrete
fill ~5 ~-39 ~46 ~17 ~-39 ~46 minecraft:air
setblock ~18 ~-39 ~46 minecraft:light_gray_concrete
fill ~19 ~-39 ~46 ~28 ~-39 ~46 minecraft:air
setblock ~29 ~-39 ~46 minecraft:quartz_pillar
fill ~30 ~-39 ~46 ~31 ~-39 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-39 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~33 ~-39 ~46 minecraft:smooth_quartz
setblock ~34 ~-39 ~46 minecraft:air
setblock ~35 ~-39 ~46 minecraft:smooth_quartz
setblock ~36 ~-39 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~37 ~-39 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-39 ~46 minecraft:quartz_pillar
setblock ~39 ~-39 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-39 ~46 ~49 ~-39 ~46 minecraft:air
setblock ~50 ~-39 ~46 minecraft:light_gray_concrete
fill ~51 ~-39 ~46 ~63 ~-39 ~46 minecraft:air
setblock ~64 ~-39 ~46 minecraft:light_gray_concrete
setblock ~4 ~-39 ~47 minecraft:light_gray_concrete
fill ~5 ~-39 ~47 ~17 ~-39 ~47 minecraft:air
setblock ~18 ~-39 ~47 minecraft:light_gray_concrete
fill ~19 ~-39 ~47 ~31 ~-39 ~47 minecraft:air
setblock ~32 ~-39 ~47 minecraft:light_gray_concrete
setblock ~33 ~-39 ~47 minecraft:air
setblock ~34 ~-39 ~47 minecraft:smooth_quartz
setblock ~35 ~-39 ~47 minecraft:air
setblock ~36 ~-39 ~47 minecraft:light_gray_concrete
fill ~37 ~-39 ~47 ~49 ~-39 ~47 minecraft:air
setblock ~50 ~-39 ~47 minecraft:light_gray_concrete
fill ~51 ~-39 ~47 ~63 ~-39 ~47 minecraft:air
setblock ~64 ~-39 ~47 minecraft:light_gray_concrete
setblock ~4 ~-39 ~48 minecraft:light_gray_concrete
fill ~5 ~-39 ~48 ~17 ~-39 ~48 minecraft:air
setblock ~18 ~-39 ~48 minecraft:light_gray_concrete
fill ~19 ~-39 ~48 ~31 ~-39 ~48 minecraft:air
setblock ~32 ~-39 ~48 minecraft:light_gray_concrete
fill ~33 ~-39 ~48 ~35 ~-39 ~48 minecraft:air
setblock ~36 ~-39 ~48 minecraft:light_gray_concrete
fill ~37 ~-39 ~48 ~49 ~-39 ~48 minecraft:air
setblock ~50 ~-39 ~48 minecraft:light_gray_concrete
fill ~51 ~-39 ~48 ~63 ~-39 ~48 minecraft:air
setblock ~64 ~-39 ~48 minecraft:light_gray_concrete
setblock ~4 ~-39 ~49 minecraft:light_gray_concrete
fill ~5 ~-39 ~49 ~17 ~-39 ~49 minecraft:air
setblock ~18 ~-39 ~49 minecraft:light_gray_concrete
fill ~19 ~-39 ~49 ~30 ~-39 ~49 minecraft:black_concrete
setblock ~31 ~-39 ~49 minecraft:air
setblock ~32 ~-39 ~49 minecraft:light_gray_concrete
fill ~33 ~-39 ~49 ~35 ~-39 ~49 minecraft:air
setblock ~36 ~-39 ~49 minecraft:light_gray_concrete
fill ~37 ~-39 ~49 ~49 ~-39 ~49 minecraft:air
setblock ~50 ~-39 ~49 minecraft:light_gray_concrete
fill ~51 ~-39 ~49 ~63 ~-39 ~49 minecraft:air
setblock ~64 ~-39 ~49 minecraft:light_gray_concrete
fill ~4 ~-39 ~50 ~32 ~-39 ~50 minecraft:light_gray_concrete
fill ~33 ~-39 ~50 ~35 ~-39 ~50 minecraft:air
fill ~36 ~-39 ~50 ~64 ~-39 ~50 minecraft:light_gray_concrete
setblock ~4 ~-39 ~51 minecraft:light_gray_concrete
fill ~5 ~-39 ~51 ~17 ~-39 ~51 minecraft:air
setblock ~18 ~-39 ~51 minecraft:light_gray_concrete
setblock ~19 ~-39 ~51 minecraft:waxed_cut_copper
fill ~20 ~-39 ~51 ~21 ~-39 ~51 minecraft:air
setblock ~22 ~-39 ~51 minecraft:waxed_cut_copper
fill ~23 ~-39 ~51 ~24 ~-39 ~51 minecraft:air
setblock ~25 ~-39 ~51 minecraft:waxed_cut_copper
fill ~26 ~-39 ~51 ~27 ~-39 ~51 minecraft:air
setblock ~28 ~-39 ~51 minecraft:waxed_cut_copper
fill ~29 ~-39 ~51 ~30 ~-39 ~51 minecraft:air
setblock ~31 ~-39 ~51 minecraft:waxed_cut_copper
setblock ~32 ~-39 ~51 minecraft:light_gray_concrete
fill ~33 ~-39 ~51 ~35 ~-39 ~51 minecraft:air
setblock ~36 ~-39 ~51 minecraft:light_gray_concrete
fill ~37 ~-39 ~51 ~49 ~-39 ~51 minecraft:air
setblock ~50 ~-39 ~51 minecraft:light_gray_concrete
fill ~51 ~-39 ~51 ~63 ~-39 ~51 minecraft:air
setblock ~64 ~-39 ~51 minecraft:light_gray_concrete
setblock ~4 ~-39 ~52 minecraft:light_gray_concrete
fill ~5 ~-39 ~52 ~17 ~-39 ~52 minecraft:air
setblock ~18 ~-39 ~52 minecraft:light_gray_concrete
fill ~19 ~-39 ~52 ~31 ~-39 ~52 minecraft:air
setblock ~32 ~-39 ~52 minecraft:light_gray_concrete
fill ~33 ~-39 ~52 ~35 ~-39 ~52 minecraft:air
setblock ~36 ~-39 ~52 minecraft:light_gray_concrete
fill ~37 ~-39 ~52 ~49 ~-39 ~52 minecraft:air
setblock ~50 ~-39 ~52 minecraft:light_gray_concrete
fill ~51 ~-39 ~52 ~63 ~-39 ~52 minecraft:air
setblock ~64 ~-39 ~52 minecraft:light_gray_concrete
setblock ~4 ~-39 ~53 minecraft:light_gray_concrete
fill ~5 ~-39 ~53 ~17 ~-39 ~53 minecraft:air
setblock ~18 ~-39 ~53 minecraft:light_gray_concrete
fill ~19 ~-39 ~53 ~31 ~-39 ~53 minecraft:air
setblock ~32 ~-39 ~53 minecraft:light_gray_concrete
fill ~33 ~-39 ~53 ~35 ~-39 ~53 minecraft:air
setblock ~36 ~-39 ~53 minecraft:light_gray_concrete
fill ~37 ~-39 ~53 ~49 ~-39 ~53 minecraft:air
setblock ~50 ~-39 ~53 minecraft:light_gray_concrete
fill ~51 ~-39 ~53 ~63 ~-39 ~53 minecraft:air
setblock ~64 ~-39 ~53 minecraft:light_gray_concrete
setblock ~4 ~-39 ~54 minecraft:light_gray_concrete
fill ~5 ~-39 ~54 ~17 ~-39 ~54 minecraft:air
setblock ~18 ~-39 ~54 minecraft:light_gray_concrete
setblock ~19 ~-39 ~54 minecraft:waxed_cut_copper
fill ~20 ~-39 ~54 ~30 ~-39 ~54 minecraft:air
setblock ~31 ~-39 ~54 minecraft:waxed_cut_copper
setblock ~32 ~-39 ~54 minecraft:light_gray_concrete
fill ~33 ~-39 ~54 ~35 ~-39 ~54 minecraft:air
setblock ~36 ~-39 ~54 minecraft:light_gray_concrete
fill ~37 ~-39 ~54 ~49 ~-39 ~54 minecraft:air
setblock ~50 ~-39 ~54 minecraft:light_gray_concrete
fill ~51 ~-39 ~54 ~63 ~-39 ~54 minecraft:air
setblock ~64 ~-39 ~54 minecraft:light_gray_concrete
setblock ~4 ~-39 ~55 minecraft:light_gray_concrete
fill ~5 ~-39 ~55 ~17 ~-39 ~55 minecraft:air
setblock ~18 ~-39 ~55 minecraft:light_gray_concrete
fill ~19 ~-39 ~55 ~31 ~-39 ~55 minecraft:air
setblock ~32 ~-39 ~55 minecraft:light_gray_concrete
fill ~33 ~-39 ~55 ~35 ~-39 ~55 minecraft:air
setblock ~36 ~-39 ~55 minecraft:light_gray_concrete
fill ~37 ~-39 ~55 ~49 ~-39 ~55 minecraft:air
setblock ~50 ~-39 ~55 minecraft:light_gray_concrete
fill ~51 ~-39 ~55 ~63 ~-39 ~55 minecraft:air
setblock ~64 ~-39 ~55 minecraft:light_gray_concrete
setblock ~4 ~-39 ~56 minecraft:light_gray_concrete
fill ~5 ~-39 ~56 ~17 ~-39 ~56 minecraft:air
setblock ~18 ~-39 ~56 minecraft:light_gray_concrete
fill ~19 ~-39 ~56 ~31 ~-39 ~56 minecraft:air
setblock ~32 ~-39 ~56 minecraft:light_gray_concrete
fill ~33 ~-39 ~56 ~35 ~-39 ~56 minecraft:air
setblock ~36 ~-39 ~56 minecraft:light_gray_concrete
fill ~37 ~-39 ~56 ~49 ~-39 ~56 minecraft:air
setblock ~50 ~-39 ~56 minecraft:light_gray_concrete
fill ~51 ~-39 ~56 ~63 ~-39 ~56 minecraft:air
setblock ~64 ~-39 ~56 minecraft:light_gray_concrete
setblock ~4 ~-39 ~57 minecraft:light_gray_concrete
fill ~5 ~-39 ~57 ~17 ~-39 ~57 minecraft:air
setblock ~18 ~-39 ~57 minecraft:light_gray_concrete
fill ~19 ~-39 ~57 ~31 ~-39 ~57 minecraft:air
setblock ~32 ~-39 ~57 minecraft:light_gray_concrete
fill ~33 ~-39 ~57 ~35 ~-39 ~57 minecraft:air
setblock ~36 ~-39 ~57 minecraft:light_gray_concrete
fill ~37 ~-39 ~57 ~49 ~-39 ~57 minecraft:air
setblock ~50 ~-39 ~57 minecraft:light_gray_concrete
fill ~51 ~-39 ~57 ~63 ~-39 ~57 minecraft:air
setblock ~64 ~-39 ~57 minecraft:light_gray_concrete
setblock ~4 ~-39 ~58 minecraft:light_gray_concrete
fill ~5 ~-39 ~58 ~17 ~-39 ~58 minecraft:air
setblock ~18 ~-39 ~58 minecraft:light_gray_concrete
fill ~19 ~-39 ~58 ~31 ~-39 ~58 minecraft:air
setblock ~32 ~-39 ~58 minecraft:light_gray_concrete
fill ~33 ~-39 ~58 ~35 ~-39 ~58 minecraft:air
setblock ~36 ~-39 ~58 minecraft:light_gray_concrete
fill ~37 ~-39 ~58 ~49 ~-39 ~58 minecraft:air
setblock ~50 ~-39 ~58 minecraft:light_gray_concrete
fill ~51 ~-39 ~58 ~63 ~-39 ~58 minecraft:air
setblock ~64 ~-39 ~58 minecraft:light_gray_concrete
setblock ~4 ~-39 ~59 minecraft:light_gray_concrete
fill ~5 ~-39 ~59 ~17 ~-39 ~59 minecraft:air
setblock ~18 ~-39 ~59 minecraft:light_gray_concrete
fill ~19 ~-39 ~59 ~31 ~-39 ~59 minecraft:air
setblock ~32 ~-39 ~59 minecraft:light_gray_concrete
fill ~33 ~-39 ~59 ~35 ~-39 ~59 minecraft:air
setblock ~36 ~-39 ~59 minecraft:light_gray_concrete
fill ~37 ~-39 ~59 ~49 ~-39 ~59 minecraft:air
setblock ~50 ~-39 ~59 minecraft:light_gray_concrete
fill ~51 ~-39 ~59 ~63 ~-39 ~59 minecraft:air
setblock ~64 ~-39 ~59 minecraft:light_gray_concrete
setblock ~4 ~-39 ~60 minecraft:light_gray_concrete
fill ~5 ~-39 ~60 ~17 ~-39 ~60 minecraft:air
setblock ~18 ~-39 ~60 minecraft:light_gray_concrete
setblock ~19 ~-39 ~60 minecraft:waxed_cut_copper
fill ~20 ~-39 ~60 ~30 ~-39 ~60 minecraft:air
setblock ~31 ~-39 ~60 minecraft:waxed_cut_copper
setblock ~32 ~-39 ~60 minecraft:light_gray_concrete
fill ~33 ~-39 ~60 ~35 ~-39 ~60 minecraft:air
setblock ~36 ~-39 ~60 minecraft:light_gray_concrete
fill ~37 ~-39 ~60 ~49 ~-39 ~60 minecraft:air
setblock ~50 ~-39 ~60 minecraft:light_gray_concrete
fill ~51 ~-39 ~60 ~63 ~-39 ~60 minecraft:air
setblock ~64 ~-39 ~60 minecraft:light_gray_concrete
setblock ~4 ~-39 ~61 minecraft:light_gray_concrete
fill ~5 ~-39 ~61 ~17 ~-39 ~61 minecraft:air
setblock ~18 ~-39 ~61 minecraft:light_gray_concrete
fill ~19 ~-39 ~61 ~31 ~-39 ~61 minecraft:air
setblock ~32 ~-39 ~61 minecraft:light_gray_concrete
fill ~33 ~-39 ~61 ~35 ~-39 ~61 minecraft:air
setblock ~36 ~-39 ~61 minecraft:light_gray_concrete
fill ~37 ~-39 ~61 ~49 ~-39 ~61 minecraft:air
setblock ~50 ~-39 ~61 minecraft:light_gray_concrete
fill ~51 ~-39 ~61 ~63 ~-39 ~61 minecraft:air
setblock ~64 ~-39 ~61 minecraft:light_gray_concrete
setblock ~4 ~-39 ~62 minecraft:light_gray_concrete
fill ~5 ~-39 ~62 ~17 ~-39 ~62 minecraft:air
setblock ~18 ~-39 ~62 minecraft:light_gray_concrete
fill ~19 ~-39 ~62 ~31 ~-39 ~62 minecraft:air
setblock ~32 ~-39 ~62 minecraft:light_gray_concrete
fill ~33 ~-39 ~62 ~35 ~-39 ~62 minecraft:air
setblock ~36 ~-39 ~62 minecraft:light_gray_concrete
fill ~37 ~-39 ~62 ~49 ~-39 ~62 minecraft:air
setblock ~50 ~-39 ~62 minecraft:light_gray_concrete
fill ~51 ~-39 ~62 ~63 ~-39 ~62 minecraft:air
setblock ~64 ~-39 ~62 minecraft:light_gray_concrete
setblock ~4 ~-39 ~63 minecraft:light_gray_concrete
fill ~5 ~-39 ~63 ~17 ~-39 ~63 minecraft:air
setblock ~18 ~-39 ~63 minecraft:light_gray_concrete
setblock ~19 ~-39 ~63 minecraft:waxed_cut_copper
fill ~20 ~-39 ~63 ~21 ~-39 ~63 minecraft:air
setblock ~22 ~-39 ~63 minecraft:waxed_cut_copper
fill ~23 ~-39 ~63 ~24 ~-39 ~63 minecraft:air
setblock ~25 ~-39 ~63 minecraft:waxed_cut_copper
fill ~26 ~-39 ~63 ~27 ~-39 ~63 minecraft:air
setblock ~28 ~-39 ~63 minecraft:waxed_cut_copper
fill ~29 ~-39 ~63 ~30 ~-39 ~63 minecraft:air
setblock ~31 ~-39 ~63 minecraft:waxed_cut_copper
setblock ~32 ~-39 ~63 minecraft:light_gray_concrete
fill ~33 ~-39 ~63 ~35 ~-39 ~63 minecraft:air
setblock ~36 ~-39 ~63 minecraft:light_gray_concrete
fill ~37 ~-39 ~63 ~49 ~-39 ~63 minecraft:air
setblock ~50 ~-39 ~63 minecraft:light_gray_concrete
fill ~51 ~-39 ~63 ~63 ~-39 ~63 minecraft:air
setblock ~64 ~-39 ~63 minecraft:light_gray_concrete
fill ~4 ~-39 ~64 ~64 ~-39 ~64 minecraft:light_gray_concrete
fill ~32 ~-39 ~66 ~36 ~-39 ~66 minecraft:polished_andesite
setblock ~32 ~-39 ~67 minecraft:polished_andesite
fill ~33 ~-39 ~67 ~35 ~-39 ~67 minecraft:air
setblock ~36 ~-39 ~67 minecraft:polished_andesite
setblock ~32 ~-39 ~68 minecraft:polished_andesite
setblock ~33 ~-39 ~68 minecraft:air
setblock ~34 ~-39 ~68 minecraft:quartz_pillar
setblock ~35 ~-39 ~68 minecraft:air
setblock ~36 ~-39 ~68 minecraft:polished_andesite
setblock ~32 ~-39 ~69 minecraft:polished_andesite
setblock ~33 ~-39 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-39 ~69 ~35 ~-39 ~69 minecraft:air
setblock ~36 ~-39 ~69 minecraft:polished_andesite
fill ~32 ~-39 ~70 ~36 ~-39 ~70 minecraft:polished_andesite
fill ~4 ~-38 ~4 ~64 ~-38 ~4 minecraft:light_gray_concrete
setblock ~4 ~-38 ~5 minecraft:light_gray_concrete
fill ~5 ~-38 ~5 ~17 ~-38 ~5 minecraft:air
setblock ~18 ~-38 ~5 minecraft:light_gray_concrete
fill ~19 ~-38 ~5 ~31 ~-38 ~5 minecraft:air
setblock ~32 ~-38 ~5 minecraft:light_gray_concrete
fill ~33 ~-38 ~5 ~35 ~-38 ~5 minecraft:air
setblock ~36 ~-38 ~5 minecraft:light_gray_concrete
fill ~37 ~-38 ~5 ~49 ~-38 ~5 minecraft:air
setblock ~50 ~-38 ~5 minecraft:light_gray_concrete
fill ~51 ~-38 ~5 ~63 ~-38 ~5 minecraft:iron_block
setblock ~64 ~-38 ~5 minecraft:light_gray_concrete
setblock ~4 ~-38 ~6 minecraft:light_gray_concrete
fill ~5 ~-38 ~6 ~17 ~-38 ~6 minecraft:air
setblock ~18 ~-38 ~6 minecraft:light_gray_concrete
fill ~19 ~-38 ~6 ~31 ~-38 ~6 minecraft:air
setblock ~32 ~-38 ~6 minecraft:light_gray_concrete
fill ~33 ~-38 ~6 ~35 ~-38 ~6 minecraft:air
setblock ~36 ~-38 ~6 minecraft:light_gray_concrete
fill ~37 ~-38 ~6 ~49 ~-38 ~6 minecraft:air
setblock ~50 ~-38 ~6 minecraft:light_gray_concrete
setblock ~51 ~-38 ~6 minecraft:iron_block
fill ~52 ~-38 ~6 ~62 ~-38 ~6 minecraft:air
setblock ~63 ~-38 ~6 minecraft:iron_block
setblock ~64 ~-38 ~6 minecraft:light_gray_concrete
setblock ~4 ~-38 ~7 minecraft:light_gray_concrete
setblock ~5 ~-38 ~7 minecraft:air
setblock ~6 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~7 minecraft:air
fill ~8 ~-38 ~7 ~10 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~7 minecraft:air
fill ~12 ~-38 ~7 ~14 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~7 minecraft:air
setblock ~16 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~7 minecraft:air
setblock ~18 ~-38 ~7 minecraft:light_gray_concrete
setblock ~19 ~-38 ~7 minecraft:air
setblock ~20 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~21 ~-38 ~7 minecraft:air
fill ~22 ~-38 ~7 ~24 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~25 ~-38 ~7 minecraft:air
fill ~26 ~-38 ~7 ~28 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~29 ~-38 ~7 minecraft:air
setblock ~30 ~-38 ~7 minecraft:waxed_cut_copper
setblock ~31 ~-38 ~7 minecraft:air
setblock ~32 ~-38 ~7 minecraft:light_gray_concrete
fill ~33 ~-38 ~7 ~35 ~-38 ~7 minecraft:air
setblock ~36 ~-38 ~7 minecraft:light_gray_concrete
fill ~37 ~-38 ~7 ~49 ~-38 ~7 minecraft:air
setblock ~50 ~-38 ~7 minecraft:light_gray_concrete
setblock ~51 ~-38 ~7 minecraft:iron_block
fill ~52 ~-38 ~7 ~62 ~-38 ~7 minecraft:air
setblock ~63 ~-38 ~7 minecraft:iron_block
setblock ~64 ~-38 ~7 minecraft:light_gray_concrete
setblock ~4 ~-38 ~8 minecraft:light_gray_concrete
fill ~5 ~-38 ~8 ~17 ~-38 ~8 minecraft:air
setblock ~18 ~-38 ~8 minecraft:light_gray_concrete
fill ~19 ~-38 ~8 ~31 ~-38 ~8 minecraft:air
setblock ~32 ~-38 ~8 minecraft:light_gray_concrete
fill ~33 ~-38 ~8 ~35 ~-38 ~8 minecraft:air
setblock ~36 ~-38 ~8 minecraft:light_gray_concrete
fill ~37 ~-38 ~8 ~49 ~-38 ~8 minecraft:air
setblock ~50 ~-38 ~8 minecraft:light_gray_concrete
setblock ~51 ~-38 ~8 minecraft:iron_block
fill ~52 ~-38 ~8 ~62 ~-38 ~8 minecraft:air
setblock ~63 ~-38 ~8 minecraft:iron_block
setblock ~64 ~-38 ~8 minecraft:light_gray_concrete
setblock ~4 ~-38 ~9 minecraft:light_gray_concrete
fill ~5 ~-38 ~9 ~17 ~-38 ~9 minecraft:air
setblock ~18 ~-38 ~9 minecraft:light_gray_concrete
fill ~19 ~-38 ~9 ~31 ~-38 ~9 minecraft:air
setblock ~32 ~-38 ~9 minecraft:light_gray_concrete
fill ~33 ~-38 ~9 ~35 ~-38 ~9 minecraft:air
setblock ~36 ~-38 ~9 minecraft:light_gray_concrete
fill ~37 ~-38 ~9 ~49 ~-38 ~9 minecraft:air
setblock ~50 ~-38 ~9 minecraft:light_gray_concrete
setblock ~51 ~-38 ~9 minecraft:iron_block
fill ~52 ~-38 ~9 ~62 ~-38 ~9 minecraft:air
setblock ~63 ~-38 ~9 minecraft:iron_block
setblock ~64 ~-38 ~9 minecraft:light_gray_concrete
setblock ~4 ~-38 ~10 minecraft:light_gray_concrete
setblock ~5 ~-38 ~10 minecraft:air
setblock ~6 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~10 minecraft:air
fill ~8 ~-38 ~10 ~10 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~10 minecraft:air
fill ~12 ~-38 ~10 ~14 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~10 minecraft:air
setblock ~16 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~10 minecraft:air
setblock ~18 ~-38 ~10 minecraft:light_gray_concrete
setblock ~19 ~-38 ~10 minecraft:air
setblock ~20 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~21 ~-38 ~10 minecraft:air
fill ~22 ~-38 ~10 ~24 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~25 ~-38 ~10 minecraft:air
fill ~26 ~-38 ~10 ~28 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~29 ~-38 ~10 minecraft:air
setblock ~30 ~-38 ~10 minecraft:waxed_cut_copper
setblock ~31 ~-38 ~10 minecraft:air
setblock ~32 ~-38 ~10 minecraft:light_gray_concrete
fill ~33 ~-38 ~10 ~35 ~-38 ~10 minecraft:air
setblock ~36 ~-38 ~10 minecraft:light_gray_concrete
fill ~37 ~-38 ~10 ~49 ~-38 ~10 minecraft:air
setblock ~50 ~-38 ~10 minecraft:light_gray_concrete
fill ~51 ~-38 ~10 ~62 ~-38 ~10 minecraft:air
setblock ~63 ~-38 ~10 minecraft:iron_block
setblock ~64 ~-38 ~10 minecraft:light_gray_concrete
setblock ~4 ~-38 ~11 minecraft:light_gray_concrete
fill ~5 ~-38 ~11 ~17 ~-38 ~11 minecraft:air
setblock ~18 ~-38 ~11 minecraft:light_gray_concrete
fill ~19 ~-38 ~11 ~31 ~-38 ~11 minecraft:air
setblock ~32 ~-38 ~11 minecraft:light_gray_concrete
fill ~33 ~-38 ~11 ~35 ~-38 ~11 minecraft:air
setblock ~36 ~-38 ~11 minecraft:light_gray_concrete
fill ~37 ~-38 ~11 ~49 ~-38 ~11 minecraft:air
setblock ~50 ~-38 ~11 minecraft:light_gray_concrete
fill ~51 ~-38 ~11 ~62 ~-38 ~11 minecraft:air
setblock ~63 ~-38 ~11 minecraft:iron_block
setblock ~64 ~-38 ~11 minecraft:light_gray_concrete
setblock ~4 ~-38 ~12 minecraft:light_gray_concrete
fill ~5 ~-38 ~12 ~17 ~-38 ~12 minecraft:air
setblock ~18 ~-38 ~12 minecraft:light_gray_concrete
fill ~19 ~-38 ~12 ~31 ~-38 ~12 minecraft:air
setblock ~32 ~-38 ~12 minecraft:light_gray_concrete
fill ~33 ~-38 ~12 ~35 ~-38 ~12 minecraft:air
setblock ~36 ~-38 ~12 minecraft:light_gray_concrete
fill ~37 ~-38 ~12 ~49 ~-38 ~12 minecraft:air
setblock ~50 ~-38 ~12 minecraft:light_gray_concrete
fill ~51 ~-38 ~12 ~62 ~-38 ~12 minecraft:air
setblock ~63 ~-38 ~12 minecraft:iron_block
setblock ~64 ~-38 ~12 minecraft:light_gray_concrete
setblock ~4 ~-38 ~13 minecraft:light_gray_concrete
setblock ~5 ~-38 ~13 minecraft:air
setblock ~6 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~13 minecraft:air
fill ~8 ~-38 ~13 ~10 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~13 minecraft:air
fill ~12 ~-38 ~13 ~14 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~13 minecraft:air
setblock ~16 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~13 minecraft:air
setblock ~18 ~-38 ~13 minecraft:light_gray_concrete
setblock ~19 ~-38 ~13 minecraft:air
setblock ~20 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~21 ~-38 ~13 minecraft:air
fill ~22 ~-38 ~13 ~24 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~25 ~-38 ~13 minecraft:air
fill ~26 ~-38 ~13 ~28 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~29 ~-38 ~13 minecraft:air
setblock ~30 ~-38 ~13 minecraft:waxed_cut_copper
setblock ~31 ~-38 ~13 minecraft:air
setblock ~32 ~-38 ~13 minecraft:light_gray_concrete
fill ~33 ~-38 ~13 ~35 ~-38 ~13 minecraft:air
setblock ~36 ~-38 ~13 minecraft:light_gray_concrete
fill ~37 ~-38 ~13 ~49 ~-38 ~13 minecraft:air
setblock ~50 ~-38 ~13 minecraft:light_gray_concrete
setblock ~51 ~-38 ~13 minecraft:iron_block
fill ~52 ~-38 ~13 ~62 ~-38 ~13 minecraft:air
setblock ~63 ~-38 ~13 minecraft:iron_block
setblock ~64 ~-38 ~13 minecraft:light_gray_concrete
setblock ~4 ~-38 ~14 minecraft:light_gray_concrete
fill ~5 ~-38 ~14 ~17 ~-38 ~14 minecraft:air
setblock ~18 ~-38 ~14 minecraft:light_gray_concrete
fill ~19 ~-38 ~14 ~31 ~-38 ~14 minecraft:air
setblock ~32 ~-38 ~14 minecraft:light_gray_concrete
fill ~33 ~-38 ~14 ~35 ~-38 ~14 minecraft:air
setblock ~36 ~-38 ~14 minecraft:light_gray_concrete
fill ~37 ~-38 ~14 ~49 ~-38 ~14 minecraft:air
setblock ~50 ~-38 ~14 minecraft:light_gray_concrete
setblock ~51 ~-38 ~14 minecraft:iron_block
fill ~52 ~-38 ~14 ~62 ~-38 ~14 minecraft:air
setblock ~63 ~-38 ~14 minecraft:iron_block
setblock ~64 ~-38 ~14 minecraft:light_gray_concrete
setblock ~4 ~-38 ~15 minecraft:light_gray_concrete
fill ~5 ~-38 ~15 ~17 ~-38 ~15 minecraft:air
setblock ~18 ~-38 ~15 minecraft:light_gray_concrete
fill ~19 ~-38 ~15 ~31 ~-38 ~15 minecraft:air
setblock ~32 ~-38 ~15 minecraft:light_gray_concrete
fill ~33 ~-38 ~15 ~35 ~-38 ~15 minecraft:air
setblock ~36 ~-38 ~15 minecraft:light_gray_concrete
fill ~37 ~-38 ~15 ~49 ~-38 ~15 minecraft:air
setblock ~50 ~-38 ~15 minecraft:light_gray_concrete
setblock ~51 ~-38 ~15 minecraft:iron_block
fill ~52 ~-38 ~15 ~62 ~-38 ~15 minecraft:air
setblock ~63 ~-38 ~15 minecraft:iron_block
setblock ~64 ~-38 ~15 minecraft:light_gray_concrete
setblock ~4 ~-38 ~16 minecraft:light_gray_concrete
setblock ~5 ~-38 ~16 minecraft:air
setblock ~6 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~16 minecraft:air
fill ~8 ~-38 ~16 ~10 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~16 minecraft:air
fill ~12 ~-38 ~16 ~14 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~16 minecraft:air
setblock ~16 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~16 minecraft:air
setblock ~18 ~-38 ~16 minecraft:light_gray_concrete
setblock ~19 ~-38 ~16 minecraft:air
setblock ~20 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~21 ~-38 ~16 minecraft:air
fill ~22 ~-38 ~16 ~24 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~25 ~-38 ~16 minecraft:air
fill ~26 ~-38 ~16 ~28 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~29 ~-38 ~16 minecraft:air
setblock ~30 ~-38 ~16 minecraft:waxed_cut_copper
setblock ~31 ~-38 ~16 minecraft:air
setblock ~32 ~-38 ~16 minecraft:light_gray_concrete
fill ~33 ~-38 ~16 ~35 ~-38 ~16 minecraft:air
setblock ~36 ~-38 ~16 minecraft:light_gray_concrete
fill ~37 ~-38 ~16 ~49 ~-38 ~16 minecraft:air
setblock ~50 ~-38 ~16 minecraft:light_gray_concrete
setblock ~51 ~-38 ~16 minecraft:iron_block
fill ~52 ~-38 ~16 ~62 ~-38 ~16 minecraft:air
setblock ~63 ~-38 ~16 minecraft:iron_block
setblock ~64 ~-38 ~16 minecraft:light_gray_concrete
setblock ~4 ~-38 ~17 minecraft:light_gray_concrete
fill ~5 ~-38 ~17 ~17 ~-38 ~17 minecraft:air
setblock ~18 ~-38 ~17 minecraft:light_gray_concrete
fill ~19 ~-38 ~17 ~31 ~-38 ~17 minecraft:air
setblock ~32 ~-38 ~17 minecraft:light_gray_concrete
fill ~33 ~-38 ~17 ~35 ~-38 ~17 minecraft:air
setblock ~36 ~-38 ~17 minecraft:light_gray_concrete
fill ~37 ~-38 ~17 ~49 ~-38 ~17 minecraft:air
setblock ~50 ~-38 ~17 minecraft:light_gray_concrete
fill ~51 ~-38 ~17 ~55 ~-38 ~17 minecraft:iron_block
fill ~56 ~-38 ~17 ~58 ~-38 ~17 minecraft:air
fill ~59 ~-38 ~17 ~63 ~-38 ~17 minecraft:iron_block
setblock ~64 ~-38 ~17 minecraft:light_gray_concrete
fill ~4 ~-38 ~18 ~32 ~-38 ~18 minecraft:light_gray_concrete
fill ~33 ~-38 ~18 ~35 ~-38 ~18 minecraft:air
fill ~36 ~-38 ~18 ~64 ~-38 ~18 minecraft:light_gray_concrete
setblock ~4 ~-38 ~19 minecraft:light_gray_concrete
setblock ~5 ~-38 ~19 minecraft:air
setblock ~6 ~-38 ~19 minecraft:waxed_cut_copper
fill ~7 ~-38 ~19 ~8 ~-38 ~19 minecraft:air
setblock ~9 ~-38 ~19 minecraft:waxed_cut_copper
fill ~10 ~-38 ~19 ~14 ~-38 ~19 minecraft:air
setblock ~15 ~-38 ~19 minecraft:waxed_cut_copper
fill ~16 ~-38 ~19 ~17 ~-38 ~19 minecraft:air
setblock ~18 ~-38 ~19 minecraft:light_gray_concrete
fill ~19 ~-38 ~19 ~30 ~-38 ~19 minecraft:black_concrete
setblock ~31 ~-38 ~19 minecraft:air
setblock ~32 ~-38 ~19 minecraft:light_gray_concrete
fill ~33 ~-38 ~19 ~35 ~-38 ~19 minecraft:air
setblock ~36 ~-38 ~19 minecraft:light_gray_concrete
fill ~37 ~-38 ~19 ~49 ~-38 ~19 minecraft:air
setblock ~50 ~-38 ~19 minecraft:light_gray_concrete
fill ~51 ~-38 ~19 ~63 ~-38 ~19 minecraft:air
setblock ~64 ~-38 ~19 minecraft:light_gray_concrete
setblock ~4 ~-38 ~20 minecraft:light_gray_concrete
setblock ~5 ~-38 ~20 minecraft:waxed_cut_copper
fill ~6 ~-38 ~20 ~16 ~-38 ~20 minecraft:air
setblock ~17 ~-38 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-38 ~20 minecraft:light_gray_concrete
fill ~19 ~-38 ~20 ~31 ~-38 ~20 minecraft:air
setblock ~32 ~-38 ~20 minecraft:light_gray_concrete
fill ~33 ~-38 ~20 ~35 ~-38 ~20 minecraft:air
setblock ~36 ~-38 ~20 minecraft:light_gray_concrete
fill ~37 ~-38 ~20 ~49 ~-38 ~20 minecraft:air
setblock ~50 ~-38 ~20 minecraft:light_gray_concrete
fill ~51 ~-38 ~20 ~63 ~-38 ~20 minecraft:air
setblock ~64 ~-38 ~20 minecraft:light_gray_concrete
setblock ~4 ~-38 ~21 minecraft:light_gray_concrete
fill ~5 ~-38 ~21 ~17 ~-38 ~21 minecraft:air
setblock ~18 ~-38 ~21 minecraft:light_gray_concrete
fill ~19 ~-38 ~21 ~31 ~-38 ~21 minecraft:air
setblock ~32 ~-38 ~21 minecraft:light_gray_concrete
setblock ~33 ~-38 ~21 minecraft:air
setblock ~34 ~-38 ~21 minecraft:smooth_quartz
setblock ~35 ~-38 ~21 minecraft:air
setblock ~36 ~-38 ~21 minecraft:light_gray_concrete
setblock ~37 ~-38 ~21 minecraft:air
setblock ~38 ~-38 ~21 minecraft:waxed_cut_copper
fill ~39 ~-38 ~21 ~40 ~-38 ~21 minecraft:air
fill ~41 ~-38 ~21 ~42 ~-38 ~21 minecraft:waxed_cut_copper
setblock ~43 ~-38 ~21 minecraft:air
fill ~44 ~-38 ~21 ~46 ~-38 ~21 minecraft:waxed_cut_copper
setblock ~47 ~-38 ~21 minecraft:air
setblock ~48 ~-38 ~21 minecraft:waxed_cut_copper
setblock ~49 ~-38 ~21 minecraft:air
setblock ~50 ~-38 ~21 minecraft:light_gray_concrete
fill ~51 ~-38 ~21 ~63 ~-38 ~21 minecraft:air
setblock ~64 ~-38 ~21 minecraft:light_gray_concrete
setblock ~4 ~-38 ~22 minecraft:light_gray_concrete
fill ~5 ~-38 ~22 ~17 ~-38 ~22 minecraft:air
setblock ~18 ~-38 ~22 minecraft:light_gray_concrete
fill ~19 ~-38 ~22 ~28 ~-38 ~22 minecraft:air
fill ~29 ~-38 ~22 ~33 ~-38 ~22 minecraft:smooth_quartz
setblock ~34 ~-38 ~22 minecraft:air
fill ~35 ~-38 ~22 ~39 ~-38 ~22 minecraft:smooth_quartz
fill ~40 ~-38 ~22 ~49 ~-38 ~22 minecraft:air
setblock ~50 ~-38 ~22 minecraft:light_gray_concrete
fill ~51 ~-38 ~22 ~63 ~-38 ~22 minecraft:air
setblock ~64 ~-38 ~22 minecraft:light_gray_concrete
setblock ~4 ~-38 ~23 minecraft:light_gray_concrete
setblock ~5 ~-38 ~23 minecraft:waxed_cut_copper
fill ~6 ~-38 ~23 ~16 ~-38 ~23 minecraft:air
setblock ~17 ~-38 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-38 ~23 minecraft:light_gray_concrete
fill ~19 ~-38 ~23 ~27 ~-38 ~23 minecraft:air
fill ~28 ~-38 ~23 ~29 ~-38 ~23 minecraft:smooth_quartz
fill ~30 ~-38 ~23 ~38 ~-38 ~23 minecraft:air
fill ~39 ~-38 ~23 ~40 ~-38 ~23 minecraft:smooth_quartz
fill ~41 ~-38 ~23 ~49 ~-38 ~23 minecraft:air
setblock ~50 ~-38 ~23 minecraft:light_gray_concrete
fill ~51 ~-38 ~23 ~63 ~-38 ~23 minecraft:air
setblock ~64 ~-38 ~23 minecraft:light_gray_concrete
setblock ~4 ~-38 ~24 minecraft:light_gray_concrete
fill ~5 ~-38 ~24 ~17 ~-38 ~24 minecraft:air
setblock ~18 ~-38 ~24 minecraft:light_gray_concrete
fill ~19 ~-38 ~24 ~25 ~-38 ~24 minecraft:air
fill ~26 ~-38 ~24 ~27 ~-38 ~24 minecraft:smooth_quartz
fill ~28 ~-38 ~24 ~29 ~-38 ~24 minecraft:air
setblock ~30 ~-38 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-38 ~24 ~37 ~-38 ~24 minecraft:air
setblock ~38 ~-38 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-38 ~24 ~40 ~-38 ~24 minecraft:air
fill ~41 ~-38 ~24 ~42 ~-38 ~24 minecraft:smooth_quartz
setblock ~43 ~-38 ~24 minecraft:air
fill ~44 ~-38 ~24 ~46 ~-38 ~24 minecraft:waxed_cut_copper
setblock ~47 ~-38 ~24 minecraft:air
setblock ~48 ~-38 ~24 minecraft:waxed_cut_copper
setblock ~49 ~-38 ~24 minecraft:air
setblock ~50 ~-38 ~24 minecraft:light_gray_concrete
fill ~51 ~-38 ~24 ~63 ~-38 ~24 minecraft:air
setblock ~64 ~-38 ~24 minecraft:light_gray_concrete
setblock ~4 ~-38 ~25 minecraft:light_gray_concrete
fill ~5 ~-38 ~25 ~17 ~-38 ~25 minecraft:air
setblock ~18 ~-38 ~25 minecraft:light_gray_concrete
fill ~19 ~-38 ~25 ~24 ~-38 ~25 minecraft:air
fill ~25 ~-38 ~25 ~26 ~-38 ~25 minecraft:smooth_quartz
fill ~27 ~-38 ~25 ~41 ~-38 ~25 minecraft:air
fill ~42 ~-38 ~25 ~43 ~-38 ~25 minecraft:smooth_quartz
fill ~44 ~-38 ~25 ~49 ~-38 ~25 minecraft:air
setblock ~50 ~-38 ~25 minecraft:light_gray_concrete
fill ~51 ~-38 ~25 ~63 ~-38 ~25 minecraft:air
setblock ~64 ~-38 ~25 minecraft:light_gray_concrete
setblock ~4 ~-38 ~26 minecraft:light_gray_concrete
setblock ~5 ~-38 ~26 minecraft:waxed_cut_copper
fill ~6 ~-38 ~26 ~16 ~-38 ~26 minecraft:air
setblock ~17 ~-38 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-38 ~26 minecraft:light_gray_concrete
fill ~19 ~-38 ~26 ~23 ~-38 ~26 minecraft:air
fill ~24 ~-38 ~26 ~25 ~-38 ~26 minecraft:smooth_quartz
fill ~26 ~-38 ~26 ~42 ~-38 ~26 minecraft:air
fill ~43 ~-38 ~26 ~44 ~-38 ~26 minecraft:smooth_quartz
fill ~45 ~-38 ~26 ~49 ~-38 ~26 minecraft:air
setblock ~50 ~-38 ~26 minecraft:light_gray_concrete
fill ~51 ~-38 ~26 ~63 ~-38 ~26 minecraft:air
setblock ~64 ~-38 ~26 minecraft:light_gray_concrete
setblock ~4 ~-38 ~27 minecraft:light_gray_concrete
fill ~5 ~-38 ~27 ~17 ~-38 ~27 minecraft:air
setblock ~18 ~-38 ~27 minecraft:light_gray_concrete
fill ~19 ~-38 ~27 ~23 ~-38 ~27 minecraft:air
setblock ~24 ~-38 ~27 minecraft:smooth_quartz
fill ~25 ~-38 ~27 ~43 ~-38 ~27 minecraft:air
setblock ~44 ~-38 ~27 minecraft:smooth_quartz
fill ~45 ~-38 ~27 ~46 ~-38 ~27 minecraft:waxed_cut_copper
setblock ~47 ~-38 ~27 minecraft:air
setblock ~48 ~-38 ~27 minecraft:waxed_cut_copper
setblock ~49 ~-38 ~27 minecraft:air
setblock ~50 ~-38 ~27 minecraft:light_gray_concrete
fill ~51 ~-38 ~27 ~63 ~-38 ~27 minecraft:air
setblock ~64 ~-38 ~27 minecraft:light_gray_concrete
setblock ~4 ~-38 ~28 minecraft:light_gray_concrete
fill ~5 ~-38 ~28 ~17 ~-38 ~28 minecraft:air
setblock ~18 ~-38 ~28 minecraft:light_gray_concrete
fill ~19 ~-38 ~28 ~22 ~-38 ~28 minecraft:air
setblock ~23 ~-38 ~28 minecraft:smooth_quartz
fill ~24 ~-38 ~28 ~44 ~-38 ~28 minecraft:air
setblock ~45 ~-38 ~28 minecraft:smooth_quartz
fill ~46 ~-38 ~28 ~49 ~-38 ~28 minecraft:air
setblock ~50 ~-38 ~28 minecraft:light_gray_concrete
fill ~51 ~-38 ~28 ~63 ~-38 ~28 minecraft:air
setblock ~64 ~-38 ~28 minecraft:light_gray_concrete
setblock ~4 ~-38 ~29 minecraft:light_gray_concrete
setblock ~5 ~-38 ~29 minecraft:waxed_cut_copper
fill ~6 ~-38 ~29 ~16 ~-38 ~29 minecraft:air
setblock ~17 ~-38 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-38 ~29 minecraft:light_gray_concrete
fill ~19 ~-38 ~29 ~21 ~-38 ~29 minecraft:air
fill ~22 ~-38 ~29 ~23 ~-38 ~29 minecraft:smooth_quartz
fill ~24 ~-38 ~29 ~44 ~-38 ~29 minecraft:air
fill ~45 ~-38 ~29 ~46 ~-38 ~29 minecraft:smooth_quartz
fill ~47 ~-38 ~29 ~49 ~-38 ~29 minecraft:air
setblock ~50 ~-38 ~29 minecraft:light_gray_concrete
fill ~51 ~-38 ~29 ~63 ~-38 ~29 minecraft:air
setblock ~64 ~-38 ~29 minecraft:light_gray_concrete
setblock ~4 ~-38 ~30 minecraft:light_gray_concrete
fill ~5 ~-38 ~30 ~17 ~-38 ~30 minecraft:air
setblock ~18 ~-38 ~30 minecraft:light_gray_concrete
fill ~19 ~-38 ~30 ~21 ~-38 ~30 minecraft:air
setblock ~22 ~-38 ~30 minecraft:smooth_quartz
setblock ~23 ~-38 ~30 minecraft:air
setblock ~24 ~-38 ~30 minecraft:chiseled_quartz_block
fill ~25 ~-38 ~30 ~43 ~-38 ~30 minecraft:air
setblock ~44 ~-38 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-38 ~30 minecraft:air
setblock ~46 ~-38 ~30 minecraft:smooth_quartz
fill ~47 ~-38 ~30 ~49 ~-38 ~30 minecraft:air
setblock ~50 ~-38 ~30 minecraft:light_gray_concrete
fill ~51 ~-38 ~30 ~63 ~-38 ~30 minecraft:air
setblock ~64 ~-38 ~30 minecraft:light_gray_concrete
setblock ~4 ~-38 ~31 minecraft:light_gray_concrete
setblock ~5 ~-38 ~31 minecraft:air
setblock ~6 ~-38 ~31 minecraft:waxed_cut_copper
fill ~7 ~-38 ~31 ~8 ~-38 ~31 minecraft:air
setblock ~9 ~-38 ~31 minecraft:waxed_cut_copper
fill ~10 ~-38 ~31 ~14 ~-38 ~31 minecraft:air
setblock ~15 ~-38 ~31 minecraft:waxed_cut_copper
fill ~16 ~-38 ~31 ~17 ~-38 ~31 minecraft:air
setblock ~18 ~-38 ~31 minecraft:light_gray_concrete
fill ~19 ~-38 ~31 ~21 ~-38 ~31 minecraft:air
setblock ~22 ~-38 ~31 minecraft:smooth_quartz
fill ~23 ~-38 ~31 ~31 ~-38 ~31 minecraft:air
fill ~32 ~-38 ~31 ~36 ~-38 ~31 minecraft:sea_lantern
fill ~37 ~-38 ~31 ~45 ~-38 ~31 minecraft:air
setblock ~46 ~-38 ~31 minecraft:smooth_quartz
fill ~47 ~-38 ~31 ~49 ~-38 ~31 minecraft:air
setblock ~50 ~-38 ~31 minecraft:light_gray_concrete
fill ~51 ~-38 ~31 ~63 ~-38 ~31 minecraft:air
setblock ~64 ~-38 ~31 minecraft:light_gray_concrete
fill ~4 ~-38 ~32 ~21 ~-38 ~32 minecraft:light_gray_concrete
setblock ~22 ~-38 ~32 minecraft:smooth_quartz
fill ~23 ~-38 ~32 ~31 ~-38 ~32 minecraft:air
setblock ~32 ~-38 ~32 minecraft:sea_lantern
fill ~33 ~-38 ~32 ~35 ~-38 ~32 minecraft:glass
setblock ~36 ~-38 ~32 minecraft:sea_lantern
fill ~37 ~-38 ~32 ~45 ~-38 ~32 minecraft:air
setblock ~46 ~-38 ~32 minecraft:smooth_quartz
fill ~47 ~-38 ~32 ~64 ~-38 ~32 minecraft:light_gray_concrete
setblock ~4 ~-38 ~33 minecraft:light_gray_concrete
fill ~5 ~-38 ~33 ~21 ~-38 ~33 minecraft:air
setblock ~22 ~-38 ~33 minecraft:smooth_quartz
fill ~23 ~-38 ~33 ~31 ~-38 ~33 minecraft:air
setblock ~32 ~-38 ~33 minecraft:sea_lantern
setblock ~33 ~-38 ~33 minecraft:glass
setblock ~34 ~-38 ~33 minecraft:air
setblock ~35 ~-38 ~33 minecraft:glass
setblock ~36 ~-38 ~33 minecraft:sea_lantern
fill ~37 ~-38 ~33 ~45 ~-38 ~33 minecraft:air
setblock ~46 ~-38 ~33 minecraft:smooth_quartz
fill ~47 ~-38 ~33 ~63 ~-38 ~33 minecraft:air
setblock ~64 ~-38 ~33 minecraft:light_gray_concrete
setblock ~4 ~-38 ~34 minecraft:light_gray_concrete
fill ~5 ~-38 ~34 ~20 ~-38 ~34 minecraft:air
setblock ~21 ~-38 ~34 minecraft:smooth_quartz
fill ~22 ~-38 ~34 ~31 ~-38 ~34 minecraft:air
setblock ~32 ~-38 ~34 minecraft:sea_lantern
fill ~33 ~-38 ~34 ~35 ~-38 ~34 minecraft:glass
setblock ~36 ~-38 ~34 minecraft:sea_lantern
fill ~37 ~-38 ~34 ~46 ~-38 ~34 minecraft:air
setblock ~47 ~-38 ~34 minecraft:smooth_quartz
fill ~48 ~-38 ~34 ~63 ~-38 ~34 minecraft:air
setblock ~64 ~-38 ~34 minecraft:light_gray_concrete
setblock ~4 ~-38 ~35 minecraft:light_gray_concrete
fill ~5 ~-38 ~35 ~21 ~-38 ~35 minecraft:air
setblock ~22 ~-38 ~35 minecraft:smooth_quartz
fill ~23 ~-38 ~35 ~31 ~-38 ~35 minecraft:air
setblock ~32 ~-38 ~35 minecraft:sea_lantern
setblock ~33 ~-38 ~35 minecraft:glass
setblock ~34 ~-38 ~35 minecraft:air
setblock ~35 ~-38 ~35 minecraft:glass
setblock ~36 ~-38 ~35 minecraft:sea_lantern
fill ~37 ~-38 ~35 ~45 ~-38 ~35 minecraft:air
setblock ~46 ~-38 ~35 minecraft:smooth_quartz
fill ~47 ~-38 ~35 ~63 ~-38 ~35 minecraft:air
setblock ~64 ~-38 ~35 minecraft:light_gray_concrete
fill ~4 ~-38 ~36 ~21 ~-38 ~36 minecraft:light_gray_concrete
setblock ~22 ~-38 ~36 minecraft:smooth_quartz
fill ~23 ~-38 ~36 ~31 ~-38 ~36 minecraft:air
setblock ~32 ~-38 ~36 minecraft:sea_lantern
fill ~33 ~-38 ~36 ~35 ~-38 ~36 minecraft:glass
setblock ~36 ~-38 ~36 minecraft:sea_lantern
fill ~37 ~-38 ~36 ~45 ~-38 ~36 minecraft:air
setblock ~46 ~-38 ~36 minecraft:smooth_quartz
fill ~47 ~-38 ~36 ~64 ~-38 ~36 minecraft:light_gray_concrete
setblock ~4 ~-38 ~37 minecraft:light_gray_concrete
fill ~5 ~-38 ~37 ~17 ~-38 ~37 minecraft:air
setblock ~18 ~-38 ~37 minecraft:light_gray_concrete
fill ~19 ~-38 ~37 ~21 ~-38 ~37 minecraft:air
setblock ~22 ~-38 ~37 minecraft:smooth_quartz
fill ~23 ~-38 ~37 ~31 ~-38 ~37 minecraft:air
fill ~32 ~-38 ~37 ~36 ~-38 ~37 minecraft:sea_lantern
fill ~37 ~-38 ~37 ~45 ~-38 ~37 minecraft:air
setblock ~46 ~-38 ~37 minecraft:smooth_quartz
fill ~47 ~-38 ~37 ~49 ~-38 ~37 minecraft:air
setblock ~50 ~-38 ~37 minecraft:light_gray_concrete
fill ~51 ~-38 ~37 ~63 ~-38 ~37 minecraft:air
setblock ~64 ~-38 ~37 minecraft:light_gray_concrete
setblock ~4 ~-38 ~38 minecraft:light_gray_concrete
fill ~5 ~-38 ~38 ~17 ~-38 ~38 minecraft:air
setblock ~18 ~-38 ~38 minecraft:light_gray_concrete
fill ~19 ~-38 ~38 ~21 ~-38 ~38 minecraft:air
setblock ~22 ~-38 ~38 minecraft:smooth_quartz
setblock ~23 ~-38 ~38 minecraft:air
setblock ~24 ~-38 ~38 minecraft:chiseled_quartz_block
fill ~25 ~-38 ~38 ~43 ~-38 ~38 minecraft:air
setblock ~44 ~-38 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-38 ~38 minecraft:air
setblock ~46 ~-38 ~38 minecraft:smooth_quartz
fill ~47 ~-38 ~38 ~49 ~-38 ~38 minecraft:air
setblock ~50 ~-38 ~38 minecraft:light_gray_concrete
fill ~51 ~-38 ~38 ~63 ~-38 ~38 minecraft:air
setblock ~64 ~-38 ~38 minecraft:light_gray_concrete
setblock ~4 ~-38 ~39 minecraft:light_gray_concrete
fill ~5 ~-38 ~39 ~17 ~-38 ~39 minecraft:air
setblock ~18 ~-38 ~39 minecraft:light_gray_concrete
fill ~19 ~-38 ~39 ~21 ~-38 ~39 minecraft:air
fill ~22 ~-38 ~39 ~23 ~-38 ~39 minecraft:smooth_quartz
fill ~24 ~-38 ~39 ~44 ~-38 ~39 minecraft:air
fill ~45 ~-38 ~39 ~46 ~-38 ~39 minecraft:smooth_quartz
fill ~47 ~-38 ~39 ~49 ~-38 ~39 minecraft:air
setblock ~50 ~-38 ~39 minecraft:light_gray_concrete
fill ~51 ~-38 ~39 ~63 ~-38 ~39 minecraft:air
setblock ~64 ~-38 ~39 minecraft:light_gray_concrete
setblock ~4 ~-38 ~40 minecraft:light_gray_concrete
fill ~5 ~-38 ~40 ~17 ~-38 ~40 minecraft:air
setblock ~18 ~-38 ~40 minecraft:light_gray_concrete
fill ~19 ~-38 ~40 ~22 ~-38 ~40 minecraft:air
setblock ~23 ~-38 ~40 minecraft:smooth_quartz
fill ~24 ~-38 ~40 ~44 ~-38 ~40 minecraft:air
setblock ~45 ~-38 ~40 minecraft:smooth_quartz
fill ~46 ~-38 ~40 ~49 ~-38 ~40 minecraft:air
setblock ~50 ~-38 ~40 minecraft:light_gray_concrete
fill ~51 ~-38 ~40 ~63 ~-38 ~40 minecraft:air
setblock ~64 ~-38 ~40 minecraft:light_gray_concrete
setblock ~4 ~-38 ~41 minecraft:light_gray_concrete
fill ~5 ~-38 ~41 ~17 ~-38 ~41 minecraft:air
setblock ~18 ~-38 ~41 minecraft:light_gray_concrete
fill ~19 ~-38 ~41 ~23 ~-38 ~41 minecraft:air
setblock ~24 ~-38 ~41 minecraft:smooth_quartz
fill ~25 ~-38 ~41 ~43 ~-38 ~41 minecraft:air
setblock ~44 ~-38 ~41 minecraft:smooth_quartz
fill ~45 ~-38 ~41 ~46 ~-38 ~41 minecraft:waxed_cut_copper
setblock ~47 ~-38 ~41 minecraft:air
setblock ~48 ~-38 ~41 minecraft:waxed_cut_copper
setblock ~49 ~-38 ~41 minecraft:air
setblock ~50 ~-38 ~41 minecraft:light_gray_concrete
fill ~51 ~-38 ~41 ~63 ~-38 ~41 minecraft:air
setblock ~64 ~-38 ~41 minecraft:light_gray_concrete
setblock ~4 ~-38 ~42 minecraft:light_gray_concrete
fill ~5 ~-38 ~42 ~17 ~-38 ~42 minecraft:air
setblock ~18 ~-38 ~42 minecraft:light_gray_concrete
fill ~19 ~-38 ~42 ~23 ~-38 ~42 minecraft:air
fill ~24 ~-38 ~42 ~25 ~-38 ~42 minecraft:smooth_quartz
fill ~26 ~-38 ~42 ~42 ~-38 ~42 minecraft:air
fill ~43 ~-38 ~42 ~44 ~-38 ~42 minecraft:smooth_quartz
fill ~45 ~-38 ~42 ~49 ~-38 ~42 minecraft:air
setblock ~50 ~-38 ~42 minecraft:light_gray_concrete
fill ~51 ~-38 ~42 ~63 ~-38 ~42 minecraft:air
setblock ~64 ~-38 ~42 minecraft:light_gray_concrete
setblock ~4 ~-38 ~43 minecraft:light_gray_concrete
fill ~5 ~-38 ~43 ~17 ~-38 ~43 minecraft:air
setblock ~18 ~-38 ~43 minecraft:light_gray_concrete
fill ~19 ~-38 ~43 ~24 ~-38 ~43 minecraft:air
fill ~25 ~-38 ~43 ~26 ~-38 ~43 minecraft:smooth_quartz
fill ~27 ~-38 ~43 ~41 ~-38 ~43 minecraft:air
fill ~42 ~-38 ~43 ~43 ~-38 ~43 minecraft:smooth_quartz
fill ~44 ~-38 ~43 ~49 ~-38 ~43 minecraft:air
setblock ~50 ~-38 ~43 minecraft:light_gray_concrete
fill ~51 ~-38 ~43 ~63 ~-38 ~43 minecraft:air
setblock ~64 ~-38 ~43 minecraft:light_gray_concrete
setblock ~4 ~-38 ~44 minecraft:light_gray_concrete
fill ~5 ~-38 ~44 ~17 ~-38 ~44 minecraft:air
setblock ~18 ~-38 ~44 minecraft:light_gray_concrete
fill ~19 ~-38 ~44 ~25 ~-38 ~44 minecraft:air
fill ~26 ~-38 ~44 ~27 ~-38 ~44 minecraft:smooth_quartz
fill ~28 ~-38 ~44 ~29 ~-38 ~44 minecraft:air
setblock ~30 ~-38 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-38 ~44 ~37 ~-38 ~44 minecraft:air
setblock ~38 ~-38 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-38 ~44 ~40 ~-38 ~44 minecraft:air
fill ~41 ~-38 ~44 ~42 ~-38 ~44 minecraft:smooth_quartz
setblock ~43 ~-38 ~44 minecraft:air
fill ~44 ~-38 ~44 ~46 ~-38 ~44 minecraft:waxed_cut_copper
setblock ~47 ~-38 ~44 minecraft:air
setblock ~48 ~-38 ~44 minecraft:waxed_cut_copper
setblock ~49 ~-38 ~44 minecraft:air
setblock ~50 ~-38 ~44 minecraft:light_gray_concrete
fill ~51 ~-38 ~44 ~63 ~-38 ~44 minecraft:air
setblock ~64 ~-38 ~44 minecraft:light_gray_concrete
setblock ~4 ~-38 ~45 minecraft:light_gray_concrete
fill ~5 ~-38 ~45 ~17 ~-38 ~45 minecraft:air
setblock ~18 ~-38 ~45 minecraft:light_gray_concrete
fill ~19 ~-38 ~45 ~27 ~-38 ~45 minecraft:air
fill ~28 ~-38 ~45 ~29 ~-38 ~45 minecraft:smooth_quartz
fill ~30 ~-38 ~45 ~38 ~-38 ~45 minecraft:air
fill ~39 ~-38 ~45 ~40 ~-38 ~45 minecraft:smooth_quartz
fill ~41 ~-38 ~45 ~49 ~-38 ~45 minecraft:air
setblock ~50 ~-38 ~45 minecraft:light_gray_concrete
fill ~51 ~-38 ~45 ~63 ~-38 ~45 minecraft:air
setblock ~64 ~-38 ~45 minecraft:light_gray_concrete
setblock ~4 ~-38 ~46 minecraft:light_gray_concrete
fill ~5 ~-38 ~46 ~17 ~-38 ~46 minecraft:air
setblock ~18 ~-38 ~46 minecraft:light_gray_concrete
fill ~19 ~-38 ~46 ~28 ~-38 ~46 minecraft:air
fill ~29 ~-38 ~46 ~33 ~-38 ~46 minecraft:smooth_quartz
setblock ~34 ~-38 ~46 minecraft:air
fill ~35 ~-38 ~46 ~39 ~-38 ~46 minecraft:smooth_quartz
fill ~40 ~-38 ~46 ~49 ~-38 ~46 minecraft:air
setblock ~50 ~-38 ~46 minecraft:light_gray_concrete
fill ~51 ~-38 ~46 ~63 ~-38 ~46 minecraft:air
setblock ~64 ~-38 ~46 minecraft:light_gray_concrete
setblock ~4 ~-38 ~47 minecraft:light_gray_concrete
fill ~5 ~-38 ~47 ~17 ~-38 ~47 minecraft:air
setblock ~18 ~-38 ~47 minecraft:light_gray_concrete
fill ~19 ~-38 ~47 ~31 ~-38 ~47 minecraft:air
setblock ~32 ~-38 ~47 minecraft:light_gray_concrete
setblock ~33 ~-38 ~47 minecraft:air
setblock ~34 ~-38 ~47 minecraft:smooth_quartz
setblock ~35 ~-38 ~47 minecraft:air
setblock ~36 ~-38 ~47 minecraft:light_gray_concrete
setblock ~37 ~-38 ~47 minecraft:air
setblock ~38 ~-38 ~47 minecraft:waxed_cut_copper
fill ~39 ~-38 ~47 ~40 ~-38 ~47 minecraft:air
fill ~41 ~-38 ~47 ~42 ~-38 ~47 minecraft:waxed_cut_copper
setblock ~43 ~-38 ~47 minecraft:air
fill ~44 ~-38 ~47 ~46 ~-38 ~47 minecraft:waxed_cut_copper
setblock ~47 ~-38 ~47 minecraft:air
setblock ~48 ~-38 ~47 minecraft:waxed_cut_copper
setblock ~49 ~-38 ~47 minecraft:air
setblock ~50 ~-38 ~47 minecraft:light_gray_concrete
fill ~51 ~-38 ~47 ~63 ~-38 ~47 minecraft:air
setblock ~64 ~-38 ~47 minecraft:light_gray_concrete
setblock ~4 ~-38 ~48 minecraft:light_gray_concrete
fill ~5 ~-38 ~48 ~17 ~-38 ~48 minecraft:air
setblock ~18 ~-38 ~48 minecraft:light_gray_concrete
fill ~19 ~-38 ~48 ~31 ~-38 ~48 minecraft:air
setblock ~32 ~-38 ~48 minecraft:light_gray_concrete
fill ~33 ~-38 ~48 ~35 ~-38 ~48 minecraft:air
setblock ~36 ~-38 ~48 minecraft:light_gray_concrete
fill ~37 ~-38 ~48 ~49 ~-38 ~48 minecraft:air
setblock ~50 ~-38 ~48 minecraft:light_gray_concrete
fill ~51 ~-38 ~48 ~63 ~-38 ~48 minecraft:air
setblock ~64 ~-38 ~48 minecraft:light_gray_concrete
setblock ~4 ~-38 ~49 minecraft:light_gray_concrete
fill ~5 ~-38 ~49 ~17 ~-38 ~49 minecraft:air
setblock ~18 ~-38 ~49 minecraft:light_gray_concrete
fill ~19 ~-38 ~49 ~30 ~-38 ~49 minecraft:black_concrete
setblock ~31 ~-38 ~49 minecraft:air
setblock ~32 ~-38 ~49 minecraft:light_gray_concrete
fill ~33 ~-38 ~49 ~35 ~-38 ~49 minecraft:air
setblock ~36 ~-38 ~49 minecraft:light_gray_concrete
fill ~37 ~-38 ~49 ~49 ~-38 ~49 minecraft:air
setblock ~50 ~-38 ~49 minecraft:light_gray_concrete
fill ~51 ~-38 ~49 ~63 ~-38 ~49 minecraft:air
setblock ~64 ~-38 ~49 minecraft:light_gray_concrete
fill ~4 ~-38 ~50 ~32 ~-38 ~50 minecraft:light_gray_concrete
fill ~33 ~-38 ~50 ~35 ~-38 ~50 minecraft:air
fill ~36 ~-38 ~50 ~64 ~-38 ~50 minecraft:light_gray_concrete
setblock ~4 ~-38 ~51 minecraft:light_gray_concrete
fill ~5 ~-38 ~51 ~17 ~-38 ~51 minecraft:air
setblock ~18 ~-38 ~51 minecraft:light_gray_concrete
setblock ~19 ~-38 ~51 minecraft:waxed_cut_copper
fill ~20 ~-38 ~51 ~21 ~-38 ~51 minecraft:air
setblock ~22 ~-38 ~51 minecraft:waxed_cut_copper
fill ~23 ~-38 ~51 ~24 ~-38 ~51 minecraft:air
setblock ~25 ~-38 ~51 minecraft:waxed_cut_copper
fill ~26 ~-38 ~51 ~27 ~-38 ~51 minecraft:air
setblock ~28 ~-38 ~51 minecraft:waxed_cut_copper
fill ~29 ~-38 ~51 ~30 ~-38 ~51 minecraft:air
setblock ~31 ~-38 ~51 minecraft:waxed_cut_copper
setblock ~32 ~-38 ~51 minecraft:light_gray_concrete
fill ~33 ~-38 ~51 ~35 ~-38 ~51 minecraft:air
setblock ~36 ~-38 ~51 minecraft:light_gray_concrete
fill ~37 ~-38 ~51 ~49 ~-38 ~51 minecraft:air
setblock ~50 ~-38 ~51 minecraft:light_gray_concrete
fill ~51 ~-38 ~51 ~63 ~-38 ~51 minecraft:air
setblock ~64 ~-38 ~51 minecraft:light_gray_concrete
setblock ~4 ~-38 ~52 minecraft:light_gray_concrete
setblock ~5 ~-38 ~52 minecraft:air
setblock ~6 ~-38 ~52 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~52 minecraft:air
fill ~8 ~-38 ~52 ~10 ~-38 ~52 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~52 minecraft:air
fill ~12 ~-38 ~52 ~14 ~-38 ~52 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~52 minecraft:air
setblock ~16 ~-38 ~52 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~52 minecraft:air
setblock ~18 ~-38 ~52 minecraft:light_gray_concrete
fill ~19 ~-38 ~52 ~31 ~-38 ~52 minecraft:air
setblock ~32 ~-38 ~52 minecraft:light_gray_concrete
fill ~33 ~-38 ~52 ~35 ~-38 ~52 minecraft:air
setblock ~36 ~-38 ~52 minecraft:light_gray_concrete
fill ~37 ~-38 ~52 ~49 ~-38 ~52 minecraft:air
setblock ~50 ~-38 ~52 minecraft:light_gray_concrete
fill ~51 ~-38 ~52 ~63 ~-38 ~52 minecraft:air
setblock ~64 ~-38 ~52 minecraft:light_gray_concrete
setblock ~4 ~-38 ~53 minecraft:light_gray_concrete
fill ~5 ~-38 ~53 ~17 ~-38 ~53 minecraft:air
setblock ~18 ~-38 ~53 minecraft:light_gray_concrete
fill ~19 ~-38 ~53 ~31 ~-38 ~53 minecraft:air
setblock ~32 ~-38 ~53 minecraft:light_gray_concrete
fill ~33 ~-38 ~53 ~35 ~-38 ~53 minecraft:air
setblock ~36 ~-38 ~53 minecraft:light_gray_concrete
fill ~37 ~-38 ~53 ~49 ~-38 ~53 minecraft:air
setblock ~50 ~-38 ~53 minecraft:light_gray_concrete
fill ~51 ~-38 ~53 ~63 ~-38 ~53 minecraft:air
setblock ~64 ~-38 ~53 minecraft:light_gray_concrete
setblock ~4 ~-38 ~54 minecraft:light_gray_concrete
fill ~5 ~-38 ~54 ~17 ~-38 ~54 minecraft:air
setblock ~18 ~-38 ~54 minecraft:light_gray_concrete
setblock ~19 ~-38 ~54 minecraft:waxed_cut_copper
fill ~20 ~-38 ~54 ~30 ~-38 ~54 minecraft:air
setblock ~31 ~-38 ~54 minecraft:waxed_cut_copper
setblock ~32 ~-38 ~54 minecraft:light_gray_concrete
fill ~33 ~-38 ~54 ~35 ~-38 ~54 minecraft:air
setblock ~36 ~-38 ~54 minecraft:light_gray_concrete
fill ~37 ~-38 ~54 ~49 ~-38 ~54 minecraft:air
setblock ~50 ~-38 ~54 minecraft:light_gray_concrete
fill ~51 ~-38 ~54 ~63 ~-38 ~54 minecraft:air
setblock ~64 ~-38 ~54 minecraft:light_gray_concrete
setblock ~4 ~-38 ~55 minecraft:light_gray_concrete
setblock ~5 ~-38 ~55 minecraft:air
setblock ~6 ~-38 ~55 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~55 minecraft:air
fill ~8 ~-38 ~55 ~10 ~-38 ~55 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~55 minecraft:air
fill ~12 ~-38 ~55 ~14 ~-38 ~55 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~55 minecraft:air
setblock ~16 ~-38 ~55 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~55 minecraft:air
setblock ~18 ~-38 ~55 minecraft:light_gray_concrete
fill ~19 ~-38 ~55 ~31 ~-38 ~55 minecraft:air
setblock ~32 ~-38 ~55 minecraft:light_gray_concrete
fill ~33 ~-38 ~55 ~35 ~-38 ~55 minecraft:air
setblock ~36 ~-38 ~55 minecraft:light_gray_concrete
fill ~37 ~-38 ~55 ~49 ~-38 ~55 minecraft:air
setblock ~50 ~-38 ~55 minecraft:light_gray_concrete
fill ~51 ~-38 ~55 ~63 ~-38 ~55 minecraft:air
setblock ~64 ~-38 ~55 minecraft:light_gray_concrete
setblock ~4 ~-38 ~56 minecraft:light_gray_concrete
fill ~5 ~-38 ~56 ~17 ~-38 ~56 minecraft:air
setblock ~18 ~-38 ~56 minecraft:light_gray_concrete
fill ~19 ~-38 ~56 ~31 ~-38 ~56 minecraft:air
setblock ~32 ~-38 ~56 minecraft:light_gray_concrete
fill ~33 ~-38 ~56 ~35 ~-38 ~56 minecraft:air
setblock ~36 ~-38 ~56 minecraft:light_gray_concrete
fill ~37 ~-38 ~56 ~49 ~-38 ~56 minecraft:air
setblock ~50 ~-38 ~56 minecraft:light_gray_concrete
fill ~51 ~-38 ~56 ~63 ~-38 ~56 minecraft:air
setblock ~64 ~-38 ~56 minecraft:light_gray_concrete
setblock ~4 ~-38 ~57 minecraft:light_gray_concrete
fill ~5 ~-38 ~57 ~17 ~-38 ~57 minecraft:air
setblock ~18 ~-38 ~57 minecraft:light_gray_concrete
fill ~19 ~-38 ~57 ~31 ~-38 ~57 minecraft:air
setblock ~32 ~-38 ~57 minecraft:light_gray_concrete
fill ~33 ~-38 ~57 ~35 ~-38 ~57 minecraft:air
setblock ~36 ~-38 ~57 minecraft:light_gray_concrete
fill ~37 ~-38 ~57 ~49 ~-38 ~57 minecraft:air
setblock ~50 ~-38 ~57 minecraft:light_gray_concrete
fill ~51 ~-38 ~57 ~63 ~-38 ~57 minecraft:air
setblock ~64 ~-38 ~57 minecraft:light_gray_concrete
setblock ~4 ~-38 ~58 minecraft:light_gray_concrete
setblock ~5 ~-38 ~58 minecraft:air
setblock ~6 ~-38 ~58 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~58 minecraft:air
fill ~8 ~-38 ~58 ~10 ~-38 ~58 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~58 minecraft:air
fill ~12 ~-38 ~58 ~14 ~-38 ~58 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~58 minecraft:air
setblock ~16 ~-38 ~58 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~58 minecraft:air
setblock ~18 ~-38 ~58 minecraft:light_gray_concrete
fill ~19 ~-38 ~58 ~31 ~-38 ~58 minecraft:air
setblock ~32 ~-38 ~58 minecraft:light_gray_concrete
fill ~33 ~-38 ~58 ~35 ~-38 ~58 minecraft:air
setblock ~36 ~-38 ~58 minecraft:light_gray_concrete
fill ~37 ~-38 ~58 ~49 ~-38 ~58 minecraft:air
setblock ~50 ~-38 ~58 minecraft:light_gray_concrete
fill ~51 ~-38 ~58 ~63 ~-38 ~58 minecraft:air
setblock ~64 ~-38 ~58 minecraft:light_gray_concrete
setblock ~4 ~-38 ~59 minecraft:light_gray_concrete
fill ~5 ~-38 ~59 ~17 ~-38 ~59 minecraft:air
setblock ~18 ~-38 ~59 minecraft:light_gray_concrete
fill ~19 ~-38 ~59 ~31 ~-38 ~59 minecraft:air
setblock ~32 ~-38 ~59 minecraft:light_gray_concrete
fill ~33 ~-38 ~59 ~35 ~-38 ~59 minecraft:air
setblock ~36 ~-38 ~59 minecraft:light_gray_concrete
fill ~37 ~-38 ~59 ~49 ~-38 ~59 minecraft:air
setblock ~50 ~-38 ~59 minecraft:light_gray_concrete
fill ~51 ~-38 ~59 ~63 ~-38 ~59 minecraft:air
setblock ~64 ~-38 ~59 minecraft:light_gray_concrete
setblock ~4 ~-38 ~60 minecraft:light_gray_concrete
fill ~5 ~-38 ~60 ~17 ~-38 ~60 minecraft:air
setblock ~18 ~-38 ~60 minecraft:light_gray_concrete
setblock ~19 ~-38 ~60 minecraft:waxed_cut_copper
fill ~20 ~-38 ~60 ~30 ~-38 ~60 minecraft:air
setblock ~31 ~-38 ~60 minecraft:waxed_cut_copper
setblock ~32 ~-38 ~60 minecraft:light_gray_concrete
fill ~33 ~-38 ~60 ~35 ~-38 ~60 minecraft:air
setblock ~36 ~-38 ~60 minecraft:light_gray_concrete
fill ~37 ~-38 ~60 ~49 ~-38 ~60 minecraft:air
setblock ~50 ~-38 ~60 minecraft:light_gray_concrete
fill ~51 ~-38 ~60 ~63 ~-38 ~60 minecraft:air
setblock ~64 ~-38 ~60 minecraft:light_gray_concrete
setblock ~4 ~-38 ~61 minecraft:light_gray_concrete
setblock ~5 ~-38 ~61 minecraft:air
setblock ~6 ~-38 ~61 minecraft:waxed_cut_copper
setblock ~7 ~-38 ~61 minecraft:air
fill ~8 ~-38 ~61 ~10 ~-38 ~61 minecraft:waxed_cut_copper
setblock ~11 ~-38 ~61 minecraft:air
fill ~12 ~-38 ~61 ~14 ~-38 ~61 minecraft:waxed_cut_copper
setblock ~15 ~-38 ~61 minecraft:air
setblock ~16 ~-38 ~61 minecraft:waxed_cut_copper
setblock ~17 ~-38 ~61 minecraft:air
setblock ~18 ~-38 ~61 minecraft:light_gray_concrete
fill ~19 ~-38 ~61 ~31 ~-38 ~61 minecraft:air
setblock ~32 ~-38 ~61 minecraft:light_gray_concrete
fill ~33 ~-38 ~61 ~35 ~-38 ~61 minecraft:air
setblock ~36 ~-38 ~61 minecraft:light_gray_concrete
fill ~37 ~-38 ~61 ~49 ~-38 ~61 minecraft:air
setblock ~50 ~-38 ~61 minecraft:light_gray_concrete
fill ~51 ~-38 ~61 ~63 ~-38 ~61 minecraft:air
setblock ~64 ~-38 ~61 minecraft:light_gray_concrete
setblock ~4 ~-38 ~62 minecraft:light_gray_concrete
fill ~5 ~-38 ~62 ~17 ~-38 ~62 minecraft:air
setblock ~18 ~-38 ~62 minecraft:light_gray_concrete
fill ~19 ~-38 ~62 ~31 ~-38 ~62 minecraft:air
setblock ~32 ~-38 ~62 minecraft:light_gray_concrete
fill ~33 ~-38 ~62 ~35 ~-38 ~62 minecraft:air
setblock ~36 ~-38 ~62 minecraft:light_gray_concrete
fill ~37 ~-38 ~62 ~49 ~-38 ~62 minecraft:air
setblock ~50 ~-38 ~62 minecraft:light_gray_concrete
fill ~51 ~-38 ~62 ~63 ~-38 ~62 minecraft:air
setblock ~64 ~-38 ~62 minecraft:light_gray_concrete
setblock ~4 ~-38 ~63 minecraft:light_gray_concrete
fill ~5 ~-38 ~63 ~17 ~-38 ~63 minecraft:air
setblock ~18 ~-38 ~63 minecraft:light_gray_concrete
setblock ~19 ~-38 ~63 minecraft:waxed_cut_copper
fill ~20 ~-38 ~63 ~21 ~-38 ~63 minecraft:air
setblock ~22 ~-38 ~63 minecraft:waxed_cut_copper
fill ~23 ~-38 ~63 ~24 ~-38 ~63 minecraft:air
setblock ~25 ~-38 ~63 minecraft:waxed_cut_copper
fill ~26 ~-38 ~63 ~27 ~-38 ~63 minecraft:air
setblock ~28 ~-38 ~63 minecraft:waxed_cut_copper
fill ~29 ~-38 ~63 ~30 ~-38 ~63 minecraft:air
setblock ~31 ~-38 ~63 minecraft:waxed_cut_copper
setblock ~32 ~-38 ~63 minecraft:light_gray_concrete
fill ~33 ~-38 ~63 ~35 ~-38 ~63 minecraft:air
setblock ~36 ~-38 ~63 minecraft:light_gray_concrete
fill ~37 ~-38 ~63 ~49 ~-38 ~63 minecraft:air
setblock ~50 ~-38 ~63 minecraft:light_gray_concrete
fill ~51 ~-38 ~63 ~63 ~-38 ~63 minecraft:air
setblock ~64 ~-38 ~63 minecraft:light_gray_concrete
fill ~4 ~-38 ~64 ~64 ~-38 ~64 minecraft:light_gray_concrete
fill ~32 ~-38 ~66 ~36 ~-38 ~66 minecraft:polished_andesite
setblock ~32 ~-38 ~67 minecraft:polished_andesite
fill ~33 ~-38 ~67 ~35 ~-38 ~67 minecraft:air
setblock ~36 ~-38 ~67 minecraft:polished_andesite
setblock ~32 ~-38 ~68 minecraft:polished_andesite
setblock ~33 ~-38 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-38 ~68 minecraft:quartz_pillar
setblock ~35 ~-38 ~68 minecraft:air
setblock ~36 ~-38 ~68 minecraft:polished_andesite
setblock ~32 ~-38 ~69 minecraft:polished_andesite
fill ~33 ~-38 ~69 ~35 ~-38 ~69 minecraft:air
setblock ~36 ~-38 ~69 minecraft:polished_andesite
fill ~32 ~-38 ~70 ~36 ~-38 ~70 minecraft:polished_andesite
fill ~4 ~-37 ~4 ~64 ~-37 ~4 minecraft:smooth_stone
fill ~4 ~-37 ~5 ~64 ~-37 ~5 minecraft:smooth_stone
fill ~4 ~-37 ~6 ~5 ~-37 ~6 minecraft:smooth_stone
setblock ~6 ~-37 ~6 minecraft:sea_lantern
fill ~7 ~-37 ~6 ~9 ~-37 ~6 minecraft:smooth_stone
setblock ~10 ~-37 ~6 minecraft:sea_lantern
fill ~11 ~-37 ~6 ~13 ~-37 ~6 minecraft:smooth_stone
setblock ~14 ~-37 ~6 minecraft:sea_lantern
fill ~15 ~-37 ~6 ~21 ~-37 ~6 minecraft:smooth_stone
setblock ~22 ~-37 ~6 minecraft:sea_lantern
fill ~23 ~-37 ~6 ~25 ~-37 ~6 minecraft:smooth_stone
setblock ~26 ~-37 ~6 minecraft:sea_lantern
fill ~27 ~-37 ~6 ~29 ~-37 ~6 minecraft:smooth_stone
setblock ~30 ~-37 ~6 minecraft:sea_lantern
fill ~31 ~-37 ~6 ~33 ~-37 ~6 minecraft:smooth_stone
setblock ~34 ~-37 ~6 minecraft:sea_lantern
fill ~35 ~-37 ~6 ~37 ~-37 ~6 minecraft:smooth_stone
setblock ~38 ~-37 ~6 minecraft:sea_lantern
fill ~39 ~-37 ~6 ~41 ~-37 ~6 minecraft:smooth_stone
setblock ~42 ~-37 ~6 minecraft:sea_lantern
fill ~43 ~-37 ~6 ~45 ~-37 ~6 minecraft:smooth_stone
setblock ~46 ~-37 ~6 minecraft:sea_lantern
fill ~47 ~-37 ~6 ~53 ~-37 ~6 minecraft:smooth_stone
setblock ~54 ~-37 ~6 minecraft:sea_lantern
fill ~55 ~-37 ~6 ~57 ~-37 ~6 minecraft:smooth_stone
setblock ~58 ~-37 ~6 minecraft:sea_lantern
fill ~59 ~-37 ~6 ~61 ~-37 ~6 minecraft:smooth_stone
setblock ~62 ~-37 ~6 minecraft:sea_lantern
fill ~63 ~-37 ~6 ~64 ~-37 ~6 minecraft:smooth_stone
fill ~4 ~-37 ~7 ~64 ~-37 ~7 minecraft:smooth_stone
fill ~4 ~-37 ~8 ~64 ~-37 ~8 minecraft:smooth_stone
fill ~4 ~-37 ~9 ~64 ~-37 ~9 minecraft:smooth_stone
fill ~4 ~-37 ~10 ~5 ~-37 ~10 minecraft:smooth_stone
setblock ~6 ~-37 ~10 minecraft:sea_lantern
fill ~7 ~-37 ~10 ~9 ~-37 ~10 minecraft:smooth_stone
setblock ~10 ~-37 ~10 minecraft:sea_lantern
fill ~11 ~-37 ~10 ~13 ~-37 ~10 minecraft:smooth_stone
setblock ~14 ~-37 ~10 minecraft:sea_lantern
fill ~15 ~-37 ~10 ~21 ~-37 ~10 minecraft:smooth_stone
setblock ~22 ~-37 ~10 minecraft:sea_lantern
fill ~23 ~-37 ~10 ~25 ~-37 ~10 minecraft:smooth_stone
setblock ~26 ~-37 ~10 minecraft:sea_lantern
fill ~27 ~-37 ~10 ~29 ~-37 ~10 minecraft:smooth_stone
setblock ~30 ~-37 ~10 minecraft:sea_lantern
fill ~31 ~-37 ~10 ~33 ~-37 ~10 minecraft:smooth_stone
setblock ~34 ~-37 ~10 minecraft:sea_lantern
fill ~35 ~-37 ~10 ~37 ~-37 ~10 minecraft:smooth_stone
setblock ~38 ~-37 ~10 minecraft:sea_lantern
fill ~39 ~-37 ~10 ~41 ~-37 ~10 minecraft:smooth_stone
setblock ~42 ~-37 ~10 minecraft:sea_lantern
fill ~43 ~-37 ~10 ~45 ~-37 ~10 minecraft:smooth_stone
setblock ~46 ~-37 ~10 minecraft:sea_lantern
fill ~47 ~-37 ~10 ~53 ~-37 ~10 minecraft:smooth_stone
setblock ~54 ~-37 ~10 minecraft:sea_lantern
fill ~55 ~-37 ~10 ~57 ~-37 ~10 minecraft:smooth_stone
setblock ~58 ~-37 ~10 minecraft:sea_lantern
fill ~59 ~-37 ~10 ~61 ~-37 ~10 minecraft:smooth_stone
setblock ~62 ~-37 ~10 minecraft:sea_lantern
fill ~63 ~-37 ~10 ~64 ~-37 ~10 minecraft:smooth_stone
fill ~4 ~-37 ~11 ~64 ~-37 ~11 minecraft:smooth_stone
fill ~4 ~-37 ~12 ~64 ~-37 ~12 minecraft:smooth_stone
fill ~4 ~-37 ~13 ~64 ~-37 ~13 minecraft:smooth_stone
fill ~4 ~-37 ~14 ~5 ~-37 ~14 minecraft:smooth_stone
setblock ~6 ~-37 ~14 minecraft:sea_lantern
fill ~7 ~-37 ~14 ~9 ~-37 ~14 minecraft:smooth_stone
setblock ~10 ~-37 ~14 minecraft:sea_lantern
fill ~11 ~-37 ~14 ~13 ~-37 ~14 minecraft:smooth_stone
setblock ~14 ~-37 ~14 minecraft:sea_lantern
fill ~15 ~-37 ~14 ~21 ~-37 ~14 minecraft:smooth_stone
setblock ~22 ~-37 ~14 minecraft:sea_lantern
fill ~23 ~-37 ~14 ~25 ~-37 ~14 minecraft:smooth_stone
setblock ~26 ~-37 ~14 minecraft:sea_lantern
fill ~27 ~-37 ~14 ~29 ~-37 ~14 minecraft:smooth_stone
setblock ~30 ~-37 ~14 minecraft:sea_lantern
fill ~31 ~-37 ~14 ~33 ~-37 ~14 minecraft:smooth_stone
setblock ~34 ~-37 ~14 minecraft:sea_lantern
fill ~35 ~-37 ~14 ~37 ~-37 ~14 minecraft:smooth_stone
setblock ~38 ~-37 ~14 minecraft:sea_lantern
fill ~39 ~-37 ~14 ~41 ~-37 ~14 minecraft:smooth_stone
setblock ~42 ~-37 ~14 minecraft:sea_lantern
fill ~43 ~-37 ~14 ~45 ~-37 ~14 minecraft:smooth_stone
setblock ~46 ~-37 ~14 minecraft:sea_lantern
fill ~47 ~-37 ~14 ~53 ~-37 ~14 minecraft:smooth_stone
setblock ~54 ~-37 ~14 minecraft:sea_lantern
fill ~55 ~-37 ~14 ~57 ~-37 ~14 minecraft:smooth_stone
setblock ~58 ~-37 ~14 minecraft:sea_lantern
fill ~59 ~-37 ~14 ~61 ~-37 ~14 minecraft:smooth_stone
setblock ~62 ~-37 ~14 minecraft:sea_lantern
fill ~63 ~-37 ~14 ~64 ~-37 ~14 minecraft:smooth_stone
fill ~4 ~-37 ~15 ~64 ~-37 ~15 minecraft:smooth_stone
fill ~4 ~-37 ~16 ~64 ~-37 ~16 minecraft:smooth_stone
fill ~4 ~-37 ~17 ~64 ~-37 ~17 minecraft:smooth_stone
fill ~4 ~-37 ~18 ~33 ~-37 ~18 minecraft:smooth_stone
setblock ~34 ~-37 ~18 minecraft:sea_lantern
fill ~35 ~-37 ~18 ~64 ~-37 ~18 minecraft:smooth_stone
fill ~4 ~-37 ~19 ~64 ~-37 ~19 minecraft:smooth_stone
fill ~4 ~-37 ~20 ~64 ~-37 ~20 minecraft:smooth_stone
fill ~4 ~-37 ~21 ~33 ~-37 ~21 minecraft:smooth_stone
setblock ~34 ~-37 ~21 minecraft:smooth_quartz
fill ~35 ~-37 ~21 ~64 ~-37 ~21 minecraft:smooth_stone
fill ~4 ~-37 ~22 ~5 ~-37 ~22 minecraft:smooth_stone
setblock ~6 ~-37 ~22 minecraft:sea_lantern
fill ~7 ~-37 ~22 ~9 ~-37 ~22 minecraft:smooth_stone
setblock ~10 ~-37 ~22 minecraft:sea_lantern
fill ~11 ~-37 ~22 ~13 ~-37 ~22 minecraft:smooth_stone
setblock ~14 ~-37 ~22 minecraft:sea_lantern
fill ~15 ~-37 ~22 ~21 ~-37 ~22 minecraft:smooth_stone
setblock ~22 ~-37 ~22 minecraft:sea_lantern
fill ~23 ~-37 ~22 ~25 ~-37 ~22 minecraft:smooth_stone
setblock ~26 ~-37 ~22 minecraft:sea_lantern
fill ~27 ~-37 ~22 ~28 ~-37 ~22 minecraft:smooth_stone
fill ~29 ~-37 ~22 ~39 ~-37 ~22 minecraft:smooth_quartz
fill ~40 ~-37 ~22 ~41 ~-37 ~22 minecraft:smooth_stone
setblock ~42 ~-37 ~22 minecraft:sea_lantern
fill ~43 ~-37 ~22 ~45 ~-37 ~22 minecraft:smooth_stone
setblock ~46 ~-37 ~22 minecraft:sea_lantern
fill ~47 ~-37 ~22 ~53 ~-37 ~22 minecraft:smooth_stone
setblock ~54 ~-37 ~22 minecraft:sea_lantern
fill ~55 ~-37 ~22 ~57 ~-37 ~22 minecraft:smooth_stone
setblock ~58 ~-37 ~22 minecraft:sea_lantern
fill ~59 ~-37 ~22 ~61 ~-37 ~22 minecraft:smooth_stone
setblock ~62 ~-37 ~22 minecraft:sea_lantern
fill ~63 ~-37 ~22 ~64 ~-37 ~22 minecraft:smooth_stone
fill ~4 ~-37 ~23 ~27 ~-37 ~23 minecraft:smooth_stone
fill ~28 ~-37 ~23 ~40 ~-37 ~23 minecraft:smooth_quartz
fill ~41 ~-37 ~23 ~64 ~-37 ~23 minecraft:smooth_stone
fill ~4 ~-37 ~24 ~25 ~-37 ~24 minecraft:smooth_stone
fill ~26 ~-37 ~24 ~42 ~-37 ~24 minecraft:smooth_quartz
fill ~43 ~-37 ~24 ~64 ~-37 ~24 minecraft:smooth_stone
fill ~4 ~-37 ~25 ~24 ~-37 ~25 minecraft:smooth_stone
fill ~25 ~-37 ~25 ~31 ~-37 ~25 minecraft:smooth_quartz
fill ~32 ~-37 ~25 ~36 ~-37 ~25 minecraft:sea_lantern
fill ~37 ~-37 ~25 ~43 ~-37 ~25 minecraft:smooth_quartz
fill ~44 ~-37 ~25 ~64 ~-37 ~25 minecraft:smooth_stone
fill ~4 ~-37 ~26 ~5 ~-37 ~26 minecraft:smooth_stone
setblock ~6 ~-37 ~26 minecraft:sea_lantern
fill ~7 ~-37 ~26 ~9 ~-37 ~26 minecraft:smooth_stone
setblock ~10 ~-37 ~26 minecraft:sea_lantern
fill ~11 ~-37 ~26 ~13 ~-37 ~26 minecraft:smooth_stone
setblock ~14 ~-37 ~26 minecraft:sea_lantern
fill ~15 ~-37 ~26 ~21 ~-37 ~26 minecraft:smooth_stone
setblock ~22 ~-37 ~26 minecraft:sea_lantern
setblock ~23 ~-37 ~26 minecraft:smooth_stone
fill ~24 ~-37 ~26 ~29 ~-37 ~26 minecraft:smooth_quartz
fill ~30 ~-37 ~26 ~31 ~-37 ~26 minecraft:sea_lantern
fill ~32 ~-37 ~26 ~36 ~-37 ~26 minecraft:air
fill ~37 ~-37 ~26 ~38 ~-37 ~26 minecraft:sea_lantern
fill ~39 ~-37 ~26 ~44 ~-37 ~26 minecraft:smooth_quartz
setblock ~45 ~-37 ~26 minecraft:smooth_stone
setblock ~46 ~-37 ~26 minecraft:sea_lantern
fill ~47 ~-37 ~26 ~53 ~-37 ~26 minecraft:smooth_stone
setblock ~54 ~-37 ~26 minecraft:sea_lantern
fill ~55 ~-37 ~26 ~57 ~-37 ~26 minecraft:smooth_stone
setblock ~58 ~-37 ~26 minecraft:sea_lantern
fill ~59 ~-37 ~26 ~61 ~-37 ~26 minecraft:smooth_stone
setblock ~62 ~-37 ~26 minecraft:sea_lantern
fill ~63 ~-37 ~26 ~64 ~-37 ~26 minecraft:smooth_stone
fill ~4 ~-37 ~27 ~23 ~-37 ~27 minecraft:smooth_stone
fill ~24 ~-37 ~27 ~27 ~-37 ~27 minecraft:smooth_quartz
fill ~28 ~-37 ~27 ~29 ~-37 ~27 minecraft:sea_lantern
fill ~30 ~-37 ~27 ~38 ~-37 ~27 minecraft:air
fill ~39 ~-37 ~27 ~40 ~-37 ~27 minecraft:sea_lantern
fill ~41 ~-37 ~27 ~44 ~-37 ~27 minecraft:smooth_quartz
fill ~45 ~-37 ~27 ~64 ~-37 ~27 minecraft:smooth_stone
fill ~4 ~-37 ~28 ~22 ~-37 ~28 minecraft:smooth_stone
fill ~23 ~-37 ~28 ~26 ~-37 ~28 minecraft:smooth_quartz
setblock ~27 ~-37 ~28 minecraft:sea_lantern
fill ~28 ~-37 ~28 ~40 ~-37 ~28 minecraft:air
setblock ~41 ~-37 ~28 minecraft:sea_lantern
fill ~42 ~-37 ~28 ~45 ~-37 ~28 minecraft:smooth_quartz
fill ~46 ~-37 ~28 ~64 ~-37 ~28 minecraft:smooth_stone
fill ~4 ~-37 ~29 ~21 ~-37 ~29 minecraft:smooth_stone
fill ~22 ~-37 ~29 ~26 ~-37 ~29 minecraft:smooth_quartz
setblock ~27 ~-37 ~29 minecraft:sea_lantern
fill ~28 ~-37 ~29 ~40 ~-37 ~29 minecraft:air
setblock ~41 ~-37 ~29 minecraft:sea_lantern
fill ~42 ~-37 ~29 ~46 ~-37 ~29 minecraft:smooth_quartz
fill ~47 ~-37 ~29 ~64 ~-37 ~29 minecraft:smooth_stone
fill ~4 ~-37 ~30 ~5 ~-37 ~30 minecraft:smooth_stone
setblock ~6 ~-37 ~30 minecraft:sea_lantern
fill ~7 ~-37 ~30 ~9 ~-37 ~30 minecraft:smooth_stone
setblock ~10 ~-37 ~30 minecraft:sea_lantern
fill ~11 ~-37 ~30 ~13 ~-37 ~30 minecraft:smooth_stone
setblock ~14 ~-37 ~30 minecraft:sea_lantern
fill ~15 ~-37 ~30 ~21 ~-37 ~30 minecraft:smooth_stone
fill ~22 ~-37 ~30 ~25 ~-37 ~30 minecraft:smooth_quartz
setblock ~26 ~-37 ~30 minecraft:sea_lantern
fill ~27 ~-37 ~30 ~41 ~-37 ~30 minecraft:air
setblock ~42 ~-37 ~30 minecraft:sea_lantern
fill ~43 ~-37 ~30 ~46 ~-37 ~30 minecraft:smooth_quartz
fill ~47 ~-37 ~30 ~53 ~-37 ~30 minecraft:smooth_stone
setblock ~54 ~-37 ~30 minecraft:sea_lantern
fill ~55 ~-37 ~30 ~57 ~-37 ~30 minecraft:smooth_stone
setblock ~58 ~-37 ~30 minecraft:sea_lantern
fill ~59 ~-37 ~30 ~61 ~-37 ~30 minecraft:smooth_stone
setblock ~62 ~-37 ~30 minecraft:sea_lantern
fill ~63 ~-37 ~30 ~64 ~-37 ~30 minecraft:smooth_stone
fill ~4 ~-37 ~31 ~21 ~-37 ~31 minecraft:smooth_stone
fill ~22 ~-37 ~31 ~25 ~-37 ~31 minecraft:smooth_quartz
setblock ~26 ~-37 ~31 minecraft:sea_lantern
fill ~27 ~-37 ~31 ~41 ~-37 ~31 minecraft:air
setblock ~42 ~-37 ~31 minecraft:sea_lantern
fill ~43 ~-37 ~31 ~46 ~-37 ~31 minecraft:smooth_quartz
fill ~47 ~-37 ~31 ~64 ~-37 ~31 minecraft:smooth_stone
fill ~4 ~-37 ~32 ~21 ~-37 ~32 minecraft:smooth_stone
fill ~22 ~-37 ~32 ~24 ~-37 ~32 minecraft:smooth_quartz
setblock ~25 ~-37 ~32 minecraft:sea_lantern
fill ~26 ~-37 ~32 ~32 ~-37 ~32 minecraft:air
fill ~33 ~-37 ~32 ~35 ~-37 ~32 minecraft:glass
fill ~36 ~-37 ~32 ~42 ~-37 ~32 minecraft:air
setblock ~43 ~-37 ~32 minecraft:sea_lantern
fill ~44 ~-37 ~32 ~46 ~-37 ~32 minecraft:smooth_quartz
fill ~47 ~-37 ~32 ~64 ~-37 ~32 minecraft:smooth_stone
fill ~4 ~-37 ~33 ~21 ~-37 ~33 minecraft:smooth_stone
fill ~22 ~-37 ~33 ~24 ~-37 ~33 minecraft:smooth_quartz
setblock ~25 ~-37 ~33 minecraft:sea_lantern
fill ~26 ~-37 ~33 ~32 ~-37 ~33 minecraft:air
setblock ~33 ~-37 ~33 minecraft:glass
setblock ~34 ~-37 ~33 minecraft:air
setblock ~35 ~-37 ~33 minecraft:glass
fill ~36 ~-37 ~33 ~42 ~-37 ~33 minecraft:air
setblock ~43 ~-37 ~33 minecraft:sea_lantern
fill ~44 ~-37 ~33 ~46 ~-37 ~33 minecraft:smooth_quartz
fill ~47 ~-37 ~33 ~64 ~-37 ~33 minecraft:smooth_stone
fill ~4 ~-37 ~34 ~5 ~-37 ~34 minecraft:smooth_stone
setblock ~6 ~-37 ~34 minecraft:sea_lantern
fill ~7 ~-37 ~34 ~9 ~-37 ~34 minecraft:smooth_stone
setblock ~10 ~-37 ~34 minecraft:sea_lantern
fill ~11 ~-37 ~34 ~13 ~-37 ~34 minecraft:smooth_stone
setblock ~14 ~-37 ~34 minecraft:sea_lantern
fill ~15 ~-37 ~34 ~17 ~-37 ~34 minecraft:smooth_stone
setblock ~18 ~-37 ~34 minecraft:sea_lantern
fill ~19 ~-37 ~34 ~20 ~-37 ~34 minecraft:smooth_stone
fill ~21 ~-37 ~34 ~24 ~-37 ~34 minecraft:smooth_quartz
setblock ~25 ~-37 ~34 minecraft:sea_lantern
fill ~26 ~-37 ~34 ~32 ~-37 ~34 minecraft:air
fill ~33 ~-37 ~34 ~35 ~-37 ~34 minecraft:glass
fill ~36 ~-37 ~34 ~42 ~-37 ~34 minecraft:air
setblock ~43 ~-37 ~34 minecraft:sea_lantern
fill ~44 ~-37 ~34 ~47 ~-37 ~34 minecraft:smooth_quartz
fill ~48 ~-37 ~34 ~49 ~-37 ~34 minecraft:smooth_stone
setblock ~50 ~-37 ~34 minecraft:sea_lantern
fill ~51 ~-37 ~34 ~53 ~-37 ~34 minecraft:smooth_stone
setblock ~54 ~-37 ~34 minecraft:sea_lantern
fill ~55 ~-37 ~34 ~57 ~-37 ~34 minecraft:smooth_stone
setblock ~58 ~-37 ~34 minecraft:sea_lantern
fill ~59 ~-37 ~34 ~61 ~-37 ~34 minecraft:smooth_stone
setblock ~62 ~-37 ~34 minecraft:sea_lantern
fill ~63 ~-37 ~34 ~64 ~-37 ~34 minecraft:smooth_stone
fill ~4 ~-37 ~35 ~21 ~-37 ~35 minecraft:smooth_stone
fill ~22 ~-37 ~35 ~24 ~-37 ~35 minecraft:smooth_quartz
setblock ~25 ~-37 ~35 minecraft:sea_lantern
fill ~26 ~-37 ~35 ~32 ~-37 ~35 minecraft:air
setblock ~33 ~-37 ~35 minecraft:glass
setblock ~34 ~-37 ~35 minecraft:air
setblock ~35 ~-37 ~35 minecraft:glass
fill ~36 ~-37 ~35 ~42 ~-37 ~35 minecraft:air
setblock ~43 ~-37 ~35 minecraft:sea_lantern
fill ~44 ~-37 ~35 ~46 ~-37 ~35 minecraft:smooth_quartz
fill ~47 ~-37 ~35 ~64 ~-37 ~35 minecraft:smooth_stone
fill ~4 ~-37 ~36 ~21 ~-37 ~36 minecraft:smooth_stone
fill ~22 ~-37 ~36 ~24 ~-37 ~36 minecraft:smooth_quartz
setblock ~25 ~-37 ~36 minecraft:sea_lantern
fill ~26 ~-37 ~36 ~32 ~-37 ~36 minecraft:air
fill ~33 ~-37 ~36 ~35 ~-37 ~36 minecraft:glass
fill ~36 ~-37 ~36 ~42 ~-37 ~36 minecraft:air
setblock ~43 ~-37 ~36 minecraft:sea_lantern
fill ~44 ~-37 ~36 ~46 ~-37 ~36 minecraft:smooth_quartz
fill ~47 ~-37 ~36 ~64 ~-37 ~36 minecraft:smooth_stone
fill ~4 ~-37 ~37 ~21 ~-37 ~37 minecraft:smooth_stone
fill ~22 ~-37 ~37 ~25 ~-37 ~37 minecraft:smooth_quartz
setblock ~26 ~-37 ~37 minecraft:sea_lantern
fill ~27 ~-37 ~37 ~41 ~-37 ~37 minecraft:air
setblock ~42 ~-37 ~37 minecraft:sea_lantern
fill ~43 ~-37 ~37 ~46 ~-37 ~37 minecraft:smooth_quartz
fill ~47 ~-37 ~37 ~64 ~-37 ~37 minecraft:smooth_stone
fill ~4 ~-37 ~38 ~5 ~-37 ~38 minecraft:smooth_stone
setblock ~6 ~-37 ~38 minecraft:sea_lantern
fill ~7 ~-37 ~38 ~9 ~-37 ~38 minecraft:smooth_stone
setblock ~10 ~-37 ~38 minecraft:sea_lantern
fill ~11 ~-37 ~38 ~13 ~-37 ~38 minecraft:smooth_stone
setblock ~14 ~-37 ~38 minecraft:sea_lantern
fill ~15 ~-37 ~38 ~21 ~-37 ~38 minecraft:smooth_stone
fill ~22 ~-37 ~38 ~25 ~-37 ~38 minecraft:smooth_quartz
setblock ~26 ~-37 ~38 minecraft:sea_lantern
fill ~27 ~-37 ~38 ~41 ~-37 ~38 minecraft:air
setblock ~42 ~-37 ~38 minecraft:sea_lantern
fill ~43 ~-37 ~38 ~46 ~-37 ~38 minecraft:smooth_quartz
fill ~47 ~-37 ~38 ~53 ~-37 ~38 minecraft:smooth_stone
setblock ~54 ~-37 ~38 minecraft:sea_lantern
fill ~55 ~-37 ~38 ~57 ~-37 ~38 minecraft:smooth_stone
setblock ~58 ~-37 ~38 minecraft:sea_lantern
fill ~59 ~-37 ~38 ~61 ~-37 ~38 minecraft:smooth_stone
setblock ~62 ~-37 ~38 minecraft:sea_lantern
fill ~63 ~-37 ~38 ~64 ~-37 ~38 minecraft:smooth_stone
fill ~4 ~-37 ~39 ~21 ~-37 ~39 minecraft:smooth_stone
fill ~22 ~-37 ~39 ~26 ~-37 ~39 minecraft:smooth_quartz
setblock ~27 ~-37 ~39 minecraft:sea_lantern
fill ~28 ~-37 ~39 ~40 ~-37 ~39 minecraft:air
setblock ~41 ~-37 ~39 minecraft:sea_lantern
fill ~42 ~-37 ~39 ~46 ~-37 ~39 minecraft:smooth_quartz
fill ~47 ~-37 ~39 ~64 ~-37 ~39 minecraft:smooth_stone
fill ~4 ~-37 ~40 ~22 ~-37 ~40 minecraft:smooth_stone
fill ~23 ~-37 ~40 ~26 ~-37 ~40 minecraft:smooth_quartz
setblock ~27 ~-37 ~40 minecraft:sea_lantern
fill ~28 ~-37 ~40 ~40 ~-37 ~40 minecraft:air
setblock ~41 ~-37 ~40 minecraft:sea_lantern
fill ~42 ~-37 ~40 ~45 ~-37 ~40 minecraft:smooth_quartz
fill ~46 ~-37 ~40 ~64 ~-37 ~40 minecraft:smooth_stone
fill ~4 ~-37 ~41 ~23 ~-37 ~41 minecraft:smooth_stone
fill ~24 ~-37 ~41 ~27 ~-37 ~41 minecraft:smooth_quartz
fill ~28 ~-37 ~41 ~29 ~-37 ~41 minecraft:sea_lantern
fill ~30 ~-37 ~41 ~38 ~-37 ~41 minecraft:air
fill ~39 ~-37 ~41 ~40 ~-37 ~41 minecraft:sea_lantern
fill ~41 ~-37 ~41 ~44 ~-37 ~41 minecraft:smooth_quartz
fill ~45 ~-37 ~41 ~64 ~-37 ~41 minecraft:smooth_stone
fill ~4 ~-37 ~42 ~5 ~-37 ~42 minecraft:smooth_stone
setblock ~6 ~-37 ~42 minecraft:sea_lantern
fill ~7 ~-37 ~42 ~9 ~-37 ~42 minecraft:smooth_stone
setblock ~10 ~-37 ~42 minecraft:sea_lantern
fill ~11 ~-37 ~42 ~13 ~-37 ~42 minecraft:smooth_stone
setblock ~14 ~-37 ~42 minecraft:sea_lantern
fill ~15 ~-37 ~42 ~21 ~-37 ~42 minecraft:smooth_stone
setblock ~22 ~-37 ~42 minecraft:sea_lantern
setblock ~23 ~-37 ~42 minecraft:smooth_stone
fill ~24 ~-37 ~42 ~29 ~-37 ~42 minecraft:smooth_quartz
fill ~30 ~-37 ~42 ~31 ~-37 ~42 minecraft:sea_lantern
fill ~32 ~-37 ~42 ~36 ~-37 ~42 minecraft:air
fill ~37 ~-37 ~42 ~38 ~-37 ~42 minecraft:sea_lantern
fill ~39 ~-37 ~42 ~44 ~-37 ~42 minecraft:smooth_quartz
setblock ~45 ~-37 ~42 minecraft:smooth_stone
setblock ~46 ~-37 ~42 minecraft:sea_lantern
fill ~47 ~-37 ~42 ~53 ~-37 ~42 minecraft:smooth_stone
setblock ~54 ~-37 ~42 minecraft:sea_lantern
fill ~55 ~-37 ~42 ~57 ~-37 ~42 minecraft:smooth_stone
setblock ~58 ~-37 ~42 minecraft:sea_lantern
fill ~59 ~-37 ~42 ~61 ~-37 ~42 minecraft:smooth_stone
setblock ~62 ~-37 ~42 minecraft:sea_lantern
fill ~63 ~-37 ~42 ~64 ~-37 ~42 minecraft:smooth_stone
fill ~4 ~-37 ~43 ~24 ~-37 ~43 minecraft:smooth_stone
fill ~25 ~-37 ~43 ~31 ~-37 ~43 minecraft:smooth_quartz
fill ~32 ~-37 ~43 ~36 ~-37 ~43 minecraft:sea_lantern
fill ~37 ~-37 ~43 ~43 ~-37 ~43 minecraft:smooth_quartz
fill ~44 ~-37 ~43 ~64 ~-37 ~43 minecraft:smooth_stone
fill ~4 ~-37 ~44 ~25 ~-37 ~44 minecraft:smooth_stone
fill ~26 ~-37 ~44 ~42 ~-37 ~44 minecraft:smooth_quartz
fill ~43 ~-37 ~44 ~64 ~-37 ~44 minecraft:smooth_stone
fill ~4 ~-37 ~45 ~27 ~-37 ~45 minecraft:smooth_stone
fill ~28 ~-37 ~45 ~40 ~-37 ~45 minecraft:smooth_quartz
fill ~41 ~-37 ~45 ~64 ~-37 ~45 minecraft:smooth_stone
fill ~4 ~-37 ~46 ~5 ~-37 ~46 minecraft:smooth_stone
setblock ~6 ~-37 ~46 minecraft:sea_lantern
fill ~7 ~-37 ~46 ~9 ~-37 ~46 minecraft:smooth_stone
setblock ~10 ~-37 ~46 minecraft:sea_lantern
fill ~11 ~-37 ~46 ~13 ~-37 ~46 minecraft:smooth_stone
setblock ~14 ~-37 ~46 minecraft:sea_lantern
fill ~15 ~-37 ~46 ~21 ~-37 ~46 minecraft:smooth_stone
setblock ~22 ~-37 ~46 minecraft:sea_lantern
fill ~23 ~-37 ~46 ~25 ~-37 ~46 minecraft:smooth_stone
setblock ~26 ~-37 ~46 minecraft:sea_lantern
fill ~27 ~-37 ~46 ~28 ~-37 ~46 minecraft:smooth_stone
fill ~29 ~-37 ~46 ~39 ~-37 ~46 minecraft:smooth_quartz
fill ~40 ~-37 ~46 ~41 ~-37 ~46 minecraft:smooth_stone
setblock ~42 ~-37 ~46 minecraft:sea_lantern
fill ~43 ~-37 ~46 ~45 ~-37 ~46 minecraft:smooth_stone
setblock ~46 ~-37 ~46 minecraft:sea_lantern
fill ~47 ~-37 ~46 ~53 ~-37 ~46 minecraft:smooth_stone
setblock ~54 ~-37 ~46 minecraft:sea_lantern
fill ~55 ~-37 ~46 ~57 ~-37 ~46 minecraft:smooth_stone
setblock ~58 ~-37 ~46 minecraft:sea_lantern
fill ~59 ~-37 ~46 ~61 ~-37 ~46 minecraft:smooth_stone
setblock ~62 ~-37 ~46 minecraft:sea_lantern
fill ~63 ~-37 ~46 ~64 ~-37 ~46 minecraft:smooth_stone
fill ~4 ~-37 ~47 ~33 ~-37 ~47 minecraft:smooth_stone
setblock ~34 ~-37 ~47 minecraft:smooth_quartz
fill ~35 ~-37 ~47 ~64 ~-37 ~47 minecraft:smooth_stone
fill ~4 ~-37 ~48 ~64 ~-37 ~48 minecraft:smooth_stone
fill ~4 ~-37 ~49 ~64 ~-37 ~49 minecraft:smooth_stone
fill ~4 ~-37 ~50 ~33 ~-37 ~50 minecraft:smooth_stone
setblock ~34 ~-37 ~50 minecraft:sea_lantern
fill ~35 ~-37 ~50 ~64 ~-37 ~50 minecraft:smooth_stone
fill ~4 ~-37 ~51 ~64 ~-37 ~51 minecraft:smooth_stone
fill ~4 ~-37 ~52 ~64 ~-37 ~52 minecraft:smooth_stone
fill ~4 ~-37 ~53 ~64 ~-37 ~53 minecraft:smooth_stone
fill ~4 ~-37 ~54 ~5 ~-37 ~54 minecraft:smooth_stone
setblock ~6 ~-37 ~54 minecraft:sea_lantern
fill ~7 ~-37 ~54 ~9 ~-37 ~54 minecraft:smooth_stone
setblock ~10 ~-37 ~54 minecraft:sea_lantern
fill ~11 ~-37 ~54 ~13 ~-37 ~54 minecraft:smooth_stone
setblock ~14 ~-37 ~54 minecraft:sea_lantern
fill ~15 ~-37 ~54 ~21 ~-37 ~54 minecraft:smooth_stone
setblock ~22 ~-37 ~54 minecraft:sea_lantern
fill ~23 ~-37 ~54 ~25 ~-37 ~54 minecraft:smooth_stone
setblock ~26 ~-37 ~54 minecraft:sea_lantern
fill ~27 ~-37 ~54 ~29 ~-37 ~54 minecraft:smooth_stone
setblock ~30 ~-37 ~54 minecraft:sea_lantern
fill ~31 ~-37 ~54 ~33 ~-37 ~54 minecraft:smooth_stone
setblock ~34 ~-37 ~54 minecraft:sea_lantern
fill ~35 ~-37 ~54 ~37 ~-37 ~54 minecraft:smooth_stone
setblock ~38 ~-37 ~54 minecraft:sea_lantern
fill ~39 ~-37 ~54 ~41 ~-37 ~54 minecraft:smooth_stone
setblock ~42 ~-37 ~54 minecraft:sea_lantern
fill ~43 ~-37 ~54 ~45 ~-37 ~54 minecraft:smooth_stone
setblock ~46 ~-37 ~54 minecraft:sea_lantern
fill ~47 ~-37 ~54 ~53 ~-37 ~54 minecraft:smooth_stone
setblock ~54 ~-37 ~54 minecraft:sea_lantern
fill ~55 ~-37 ~54 ~57 ~-37 ~54 minecraft:smooth_stone
setblock ~58 ~-37 ~54 minecraft:sea_lantern
fill ~59 ~-37 ~54 ~61 ~-37 ~54 minecraft:smooth_stone
setblock ~62 ~-37 ~54 minecraft:sea_lantern
fill ~63 ~-37 ~54 ~64 ~-37 ~54 minecraft:smooth_stone
fill ~4 ~-37 ~55 ~64 ~-37 ~55 minecraft:smooth_stone
fill ~4 ~-37 ~56 ~64 ~-37 ~56 minecraft:smooth_stone
fill ~4 ~-37 ~57 ~64 ~-37 ~57 minecraft:smooth_stone
fill ~4 ~-37 ~58 ~5 ~-37 ~58 minecraft:smooth_stone
setblock ~6 ~-37 ~58 minecraft:sea_lantern
fill ~7 ~-37 ~58 ~9 ~-37 ~58 minecraft:smooth_stone
setblock ~10 ~-37 ~58 minecraft:sea_lantern
fill ~11 ~-37 ~58 ~13 ~-37 ~58 minecraft:smooth_stone
setblock ~14 ~-37 ~58 minecraft:sea_lantern
fill ~15 ~-37 ~58 ~21 ~-37 ~58 minecraft:smooth_stone
setblock ~22 ~-37 ~58 minecraft:sea_lantern
fill ~23 ~-37 ~58 ~25 ~-37 ~58 minecraft:smooth_stone
setblock ~26 ~-37 ~58 minecraft:sea_lantern
fill ~27 ~-37 ~58 ~29 ~-37 ~58 minecraft:smooth_stone
setblock ~30 ~-37 ~58 minecraft:sea_lantern
fill ~31 ~-37 ~58 ~33 ~-37 ~58 minecraft:smooth_stone
setblock ~34 ~-37 ~58 minecraft:sea_lantern
fill ~35 ~-37 ~58 ~37 ~-37 ~58 minecraft:smooth_stone
setblock ~38 ~-37 ~58 minecraft:sea_lantern
fill ~39 ~-37 ~58 ~41 ~-37 ~58 minecraft:smooth_stone
setblock ~42 ~-37 ~58 minecraft:sea_lantern
fill ~43 ~-37 ~58 ~45 ~-37 ~58 minecraft:smooth_stone
setblock ~46 ~-37 ~58 minecraft:sea_lantern
fill ~47 ~-37 ~58 ~53 ~-37 ~58 minecraft:smooth_stone
setblock ~54 ~-37 ~58 minecraft:sea_lantern
fill ~55 ~-37 ~58 ~57 ~-37 ~58 minecraft:smooth_stone
setblock ~58 ~-37 ~58 minecraft:sea_lantern
fill ~59 ~-37 ~58 ~61 ~-37 ~58 minecraft:smooth_stone
setblock ~62 ~-37 ~58 minecraft:sea_lantern
fill ~63 ~-37 ~58 ~64 ~-37 ~58 minecraft:smooth_stone
fill ~4 ~-37 ~59 ~64 ~-37 ~59 minecraft:smooth_stone
fill ~4 ~-37 ~60 ~64 ~-37 ~60 minecraft:smooth_stone
fill ~4 ~-37 ~61 ~64 ~-37 ~61 minecraft:smooth_stone
fill ~4 ~-37 ~62 ~5 ~-37 ~62 minecraft:smooth_stone
setblock ~6 ~-37 ~62 minecraft:sea_lantern
fill ~7 ~-37 ~62 ~9 ~-37 ~62 minecraft:smooth_stone
setblock ~10 ~-37 ~62 minecraft:sea_lantern
fill ~11 ~-37 ~62 ~13 ~-37 ~62 minecraft:smooth_stone
setblock ~14 ~-37 ~62 minecraft:sea_lantern
fill ~15 ~-37 ~62 ~21 ~-37 ~62 minecraft:smooth_stone
setblock ~22 ~-37 ~62 minecraft:sea_lantern
fill ~23 ~-37 ~62 ~25 ~-37 ~62 minecraft:smooth_stone
setblock ~26 ~-37 ~62 minecraft:sea_lantern
fill ~27 ~-37 ~62 ~29 ~-37 ~62 minecraft:smooth_stone
setblock ~30 ~-37 ~62 minecraft:sea_lantern
fill ~31 ~-37 ~62 ~33 ~-37 ~62 minecraft:smooth_stone
setblock ~34 ~-37 ~62 minecraft:sea_lantern
fill ~35 ~-37 ~62 ~37 ~-37 ~62 minecraft:smooth_stone
setblock ~38 ~-37 ~62 minecraft:sea_lantern
fill ~39 ~-37 ~62 ~41 ~-37 ~62 minecraft:smooth_stone
setblock ~42 ~-37 ~62 minecraft:sea_lantern
fill ~43 ~-37 ~62 ~45 ~-37 ~62 minecraft:smooth_stone
setblock ~46 ~-37 ~62 minecraft:sea_lantern
fill ~47 ~-37 ~62 ~53 ~-37 ~62 minecraft:smooth_stone
setblock ~54 ~-37 ~62 minecraft:sea_lantern
fill ~55 ~-37 ~62 ~57 ~-37 ~62 minecraft:smooth_stone
setblock ~58 ~-37 ~62 minecraft:sea_lantern
fill ~59 ~-37 ~62 ~61 ~-37 ~62 minecraft:smooth_stone
setblock ~62 ~-37 ~62 minecraft:sea_lantern
fill ~63 ~-37 ~62 ~64 ~-37 ~62 minecraft:smooth_stone
fill ~4 ~-37 ~63 ~64 ~-37 ~63 minecraft:smooth_stone
fill ~4 ~-37 ~64 ~64 ~-37 ~64 minecraft:smooth_stone
fill ~32 ~-37 ~66 ~36 ~-37 ~66 minecraft:polished_andesite
setblock ~32 ~-37 ~67 minecraft:polished_andesite
setblock ~33 ~-37 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-37 ~67 ~35 ~-37 ~67 minecraft:air
setblock ~36 ~-37 ~67 minecraft:polished_andesite
setblock ~32 ~-37 ~68 minecraft:polished_andesite
setblock ~33 ~-37 ~68 minecraft:air
setblock ~34 ~-37 ~68 minecraft:quartz_pillar
setblock ~35 ~-37 ~68 minecraft:air
setblock ~36 ~-37 ~68 minecraft:polished_andesite
setblock ~32 ~-37 ~69 minecraft:polished_andesite
fill ~33 ~-37 ~69 ~35 ~-37 ~69 minecraft:air
setblock ~36 ~-37 ~69 minecraft:polished_andesite
fill ~32 ~-37 ~70 ~36 ~-37 ~70 minecraft:polished_andesite
fill ~4 ~-36 ~4 ~64 ~-36 ~4 minecraft:light_gray_concrete
setblock ~4 ~-36 ~5 minecraft:light_gray_concrete
fill ~5 ~-36 ~5 ~17 ~-36 ~5 minecraft:white_concrete
setblock ~18 ~-36 ~5 minecraft:light_gray_concrete
fill ~19 ~-36 ~5 ~31 ~-36 ~5 minecraft:white_concrete
setblock ~32 ~-36 ~5 minecraft:light_gray_concrete
setblock ~33 ~-36 ~5 minecraft:white_concrete
setblock ~34 ~-36 ~5 minecraft:red_concrete
setblock ~35 ~-36 ~5 minecraft:white_concrete
setblock ~36 ~-36 ~5 minecraft:light_gray_concrete
fill ~37 ~-36 ~5 ~49 ~-36 ~5 minecraft:white_concrete
setblock ~50 ~-36 ~5 minecraft:light_gray_concrete
setblock ~51 ~-36 ~5 minecraft:white_concrete
fill ~52 ~-36 ~5 ~54 ~-36 ~5 minecraft:polished_andesite
setblock ~55 ~-36 ~5 minecraft:white_concrete
fill ~56 ~-36 ~5 ~58 ~-36 ~5 minecraft:polished_andesite
setblock ~59 ~-36 ~5 minecraft:white_concrete
fill ~60 ~-36 ~5 ~62 ~-36 ~5 minecraft:polished_andesite
setblock ~63 ~-36 ~5 minecraft:white_concrete
setblock ~64 ~-36 ~5 minecraft:light_gray_concrete
setblock ~4 ~-36 ~6 minecraft:light_gray_concrete
fill ~5 ~-36 ~6 ~17 ~-36 ~6 minecraft:white_concrete
setblock ~18 ~-36 ~6 minecraft:light_gray_concrete
fill ~19 ~-36 ~6 ~31 ~-36 ~6 minecraft:white_concrete
setblock ~32 ~-36 ~6 minecraft:light_gray_concrete
setblock ~33 ~-36 ~6 minecraft:white_concrete
setblock ~34 ~-36 ~6 minecraft:red_concrete
setblock ~35 ~-36 ~6 minecraft:white_concrete
setblock ~36 ~-36 ~6 minecraft:light_gray_concrete
fill ~37 ~-36 ~6 ~49 ~-36 ~6 minecraft:white_concrete
setblock ~50 ~-36 ~6 minecraft:light_gray_concrete
setblock ~51 ~-36 ~6 minecraft:white_concrete
fill ~52 ~-36 ~6 ~54 ~-36 ~6 minecraft:polished_andesite
setblock ~55 ~-36 ~6 minecraft:white_concrete
fill ~56 ~-36 ~6 ~58 ~-36 ~6 minecraft:polished_andesite
setblock ~59 ~-36 ~6 minecraft:white_concrete
fill ~60 ~-36 ~6 ~62 ~-36 ~6 minecraft:polished_andesite
setblock ~63 ~-36 ~6 minecraft:white_concrete
setblock ~64 ~-36 ~6 minecraft:light_gray_concrete
setblock ~4 ~-36 ~7 minecraft:light_gray_concrete
fill ~5 ~-36 ~7 ~17 ~-36 ~7 minecraft:white_concrete
setblock ~18 ~-36 ~7 minecraft:light_gray_concrete
fill ~19 ~-36 ~7 ~31 ~-36 ~7 minecraft:white_concrete
setblock ~32 ~-36 ~7 minecraft:light_gray_concrete
setblock ~33 ~-36 ~7 minecraft:white_concrete
setblock ~34 ~-36 ~7 minecraft:red_concrete
setblock ~35 ~-36 ~7 minecraft:white_concrete
setblock ~36 ~-36 ~7 minecraft:light_gray_concrete
fill ~37 ~-36 ~7 ~49 ~-36 ~7 minecraft:white_concrete
setblock ~50 ~-36 ~7 minecraft:light_gray_concrete
setblock ~51 ~-36 ~7 minecraft:white_concrete
fill ~52 ~-36 ~7 ~54 ~-36 ~7 minecraft:polished_andesite
setblock ~55 ~-36 ~7 minecraft:white_concrete
fill ~56 ~-36 ~7 ~58 ~-36 ~7 minecraft:polished_andesite
setblock ~59 ~-36 ~7 minecraft:white_concrete
fill ~60 ~-36 ~7 ~62 ~-36 ~7 minecraft:polished_andesite
setblock ~63 ~-36 ~7 minecraft:white_concrete
setblock ~64 ~-36 ~7 minecraft:light_gray_concrete
setblock ~4 ~-36 ~8 minecraft:light_gray_concrete
fill ~5 ~-36 ~8 ~17 ~-36 ~8 minecraft:white_concrete
setblock ~18 ~-36 ~8 minecraft:light_gray_concrete
fill ~19 ~-36 ~8 ~31 ~-36 ~8 minecraft:white_concrete
setblock ~32 ~-36 ~8 minecraft:light_gray_concrete
setblock ~33 ~-36 ~8 minecraft:white_concrete
setblock ~34 ~-36 ~8 minecraft:red_concrete
setblock ~35 ~-36 ~8 minecraft:white_concrete
setblock ~36 ~-36 ~8 minecraft:light_gray_concrete
fill ~37 ~-36 ~8 ~49 ~-36 ~8 minecraft:white_concrete
setblock ~50 ~-36 ~8 minecraft:light_gray_concrete
fill ~51 ~-36 ~8 ~63 ~-36 ~8 minecraft:white_concrete
setblock ~64 ~-36 ~8 minecraft:light_gray_concrete
setblock ~4 ~-36 ~9 minecraft:light_gray_concrete
fill ~5 ~-36 ~9 ~8 ~-36 ~9 minecraft:white_concrete
fill ~9 ~-36 ~9 ~13 ~-36 ~9 minecraft:cyan_concrete
fill ~14 ~-36 ~9 ~17 ~-36 ~9 minecraft:white_concrete
setblock ~18 ~-36 ~9 minecraft:light_gray_concrete
fill ~19 ~-36 ~9 ~31 ~-36 ~9 minecraft:white_concrete
setblock ~32 ~-36 ~9 minecraft:light_gray_concrete
setblock ~33 ~-36 ~9 minecraft:white_concrete
setblock ~34 ~-36 ~9 minecraft:red_concrete
setblock ~35 ~-36 ~9 minecraft:white_concrete
setblock ~36 ~-36 ~9 minecraft:light_gray_concrete
fill ~37 ~-36 ~9 ~49 ~-36 ~9 minecraft:white_concrete
setblock ~50 ~-36 ~9 minecraft:light_gray_concrete
fill ~51 ~-36 ~9 ~63 ~-36 ~9 minecraft:white_concrete
setblock ~64 ~-36 ~9 minecraft:light_gray_concrete
setblock ~4 ~-36 ~10 minecraft:light_gray_concrete
fill ~5 ~-36 ~10 ~8 ~-36 ~10 minecraft:white_concrete
fill ~9 ~-36 ~10 ~13 ~-36 ~10 minecraft:cyan_concrete
fill ~14 ~-36 ~10 ~17 ~-36 ~10 minecraft:white_concrete
setblock ~18 ~-36 ~10 minecraft:light_gray_concrete
fill ~19 ~-36 ~10 ~31 ~-36 ~10 minecraft:white_concrete
setblock ~32 ~-36 ~10 minecraft:light_gray_concrete
setblock ~33 ~-36 ~10 minecraft:white_concrete
setblock ~34 ~-36 ~10 minecraft:red_concrete
setblock ~35 ~-36 ~10 minecraft:white_concrete
setblock ~36 ~-36 ~10 minecraft:light_gray_concrete
fill ~37 ~-36 ~10 ~49 ~-36 ~10 minecraft:white_concrete
setblock ~50 ~-36 ~10 minecraft:light_gray_concrete
fill ~51 ~-36 ~10 ~63 ~-36 ~10 minecraft:white_concrete
setblock ~64 ~-36 ~10 minecraft:light_gray_concrete
setblock ~4 ~-36 ~11 minecraft:light_gray_concrete
fill ~5 ~-36 ~11 ~8 ~-36 ~11 minecraft:white_concrete
fill ~9 ~-36 ~11 ~13 ~-36 ~11 minecraft:cyan_concrete
fill ~14 ~-36 ~11 ~17 ~-36 ~11 minecraft:white_concrete
setblock ~18 ~-36 ~11 minecraft:light_gray_concrete
fill ~19 ~-36 ~11 ~31 ~-36 ~11 minecraft:white_concrete
setblock ~32 ~-36 ~11 minecraft:light_gray_concrete
setblock ~33 ~-36 ~11 minecraft:white_concrete
setblock ~34 ~-36 ~11 minecraft:red_concrete
setblock ~35 ~-36 ~11 minecraft:white_concrete
setblock ~36 ~-36 ~11 minecraft:light_gray_concrete
fill ~37 ~-36 ~11 ~49 ~-36 ~11 minecraft:white_concrete
setblock ~50 ~-36 ~11 minecraft:light_gray_concrete
fill ~51 ~-36 ~11 ~63 ~-36 ~11 minecraft:white_concrete
setblock ~64 ~-36 ~11 minecraft:light_gray_concrete
setblock ~4 ~-36 ~12 minecraft:light_gray_concrete
fill ~5 ~-36 ~12 ~8 ~-36 ~12 minecraft:white_concrete
fill ~9 ~-36 ~12 ~13 ~-36 ~12 minecraft:cyan_concrete
fill ~14 ~-36 ~12 ~17 ~-36 ~12 minecraft:white_concrete
setblock ~18 ~-36 ~12 minecraft:light_gray_concrete
fill ~19 ~-36 ~12 ~31 ~-36 ~12 minecraft:white_concrete
setblock ~32 ~-36 ~12 minecraft:light_gray_concrete
setblock ~33 ~-36 ~12 minecraft:white_concrete
setblock ~34 ~-36 ~12 minecraft:red_concrete
setblock ~35 ~-36 ~12 minecraft:white_concrete
setblock ~36 ~-36 ~12 minecraft:light_gray_concrete
fill ~37 ~-36 ~12 ~49 ~-36 ~12 minecraft:white_concrete
setblock ~50 ~-36 ~12 minecraft:light_gray_concrete
fill ~51 ~-36 ~12 ~63 ~-36 ~12 minecraft:white_concrete
setblock ~64 ~-36 ~12 minecraft:light_gray_concrete
setblock ~4 ~-36 ~13 minecraft:light_gray_concrete
fill ~5 ~-36 ~13 ~8 ~-36 ~13 minecraft:white_concrete
fill ~9 ~-36 ~13 ~13 ~-36 ~13 minecraft:cyan_concrete
fill ~14 ~-36 ~13 ~17 ~-36 ~13 minecraft:white_concrete
setblock ~18 ~-36 ~13 minecraft:light_gray_concrete
fill ~19 ~-36 ~13 ~31 ~-36 ~13 minecraft:white_concrete
setblock ~32 ~-36 ~13 minecraft:light_gray_concrete
setblock ~33 ~-36 ~13 minecraft:white_concrete
setblock ~34 ~-36 ~13 minecraft:red_concrete
setblock ~35 ~-36 ~13 minecraft:white_concrete
setblock ~36 ~-36 ~13 minecraft:light_gray_concrete
fill ~37 ~-36 ~13 ~49 ~-36 ~13 minecraft:white_concrete
setblock ~50 ~-36 ~13 minecraft:light_gray_concrete
fill ~51 ~-36 ~13 ~63 ~-36 ~13 minecraft:white_concrete
setblock ~64 ~-36 ~13 minecraft:light_gray_concrete
setblock ~4 ~-36 ~14 minecraft:light_gray_concrete
fill ~5 ~-36 ~14 ~8 ~-36 ~14 minecraft:white_concrete
fill ~9 ~-36 ~14 ~13 ~-36 ~14 minecraft:cyan_concrete
fill ~14 ~-36 ~14 ~17 ~-36 ~14 minecraft:white_concrete
setblock ~18 ~-36 ~14 minecraft:light_gray_concrete
fill ~19 ~-36 ~14 ~31 ~-36 ~14 minecraft:white_concrete
setblock ~32 ~-36 ~14 minecraft:light_gray_concrete
setblock ~33 ~-36 ~14 minecraft:white_concrete
setblock ~34 ~-36 ~14 minecraft:red_concrete
setblock ~35 ~-36 ~14 minecraft:white_concrete
setblock ~36 ~-36 ~14 minecraft:light_gray_concrete
fill ~37 ~-36 ~14 ~49 ~-36 ~14 minecraft:white_concrete
setblock ~50 ~-36 ~14 minecraft:light_gray_concrete
fill ~51 ~-36 ~14 ~63 ~-36 ~14 minecraft:white_concrete
setblock ~64 ~-36 ~14 minecraft:light_gray_concrete
setblock ~4 ~-36 ~15 minecraft:light_gray_concrete
fill ~5 ~-36 ~15 ~17 ~-36 ~15 minecraft:white_concrete
setblock ~18 ~-36 ~15 minecraft:light_gray_concrete
fill ~19 ~-36 ~15 ~31 ~-36 ~15 minecraft:white_concrete
setblock ~32 ~-36 ~15 minecraft:light_gray_concrete
setblock ~33 ~-36 ~15 minecraft:white_concrete
setblock ~34 ~-36 ~15 minecraft:red_concrete
setblock ~35 ~-36 ~15 minecraft:white_concrete
setblock ~36 ~-36 ~15 minecraft:light_gray_concrete
fill ~37 ~-36 ~15 ~49 ~-36 ~15 minecraft:white_concrete
setblock ~50 ~-36 ~15 minecraft:light_gray_concrete
fill ~51 ~-36 ~15 ~63 ~-36 ~15 minecraft:white_concrete
setblock ~64 ~-36 ~15 minecraft:light_gray_concrete
setblock ~4 ~-36 ~16 minecraft:light_gray_concrete
fill ~5 ~-36 ~16 ~17 ~-36 ~16 minecraft:white_concrete
setblock ~18 ~-36 ~16 minecraft:light_gray_concrete
fill ~19 ~-36 ~16 ~31 ~-36 ~16 minecraft:white_concrete
setblock ~32 ~-36 ~16 minecraft:light_gray_concrete
setblock ~33 ~-36 ~16 minecraft:white_concrete
setblock ~34 ~-36 ~16 minecraft:red_concrete
setblock ~35 ~-36 ~16 minecraft:white_concrete
setblock ~36 ~-36 ~16 minecraft:light_gray_concrete
fill ~37 ~-36 ~16 ~49 ~-36 ~16 minecraft:white_concrete
setblock ~50 ~-36 ~16 minecraft:light_gray_concrete
fill ~51 ~-36 ~16 ~63 ~-36 ~16 minecraft:white_concrete
setblock ~64 ~-36 ~16 minecraft:light_gray_concrete
setblock ~4 ~-36 ~17 minecraft:light_gray_concrete
fill ~5 ~-36 ~17 ~17 ~-36 ~17 minecraft:white_concrete
setblock ~18 ~-36 ~17 minecraft:light_gray_concrete
fill ~19 ~-36 ~17 ~31 ~-36 ~17 minecraft:white_concrete
setblock ~32 ~-36 ~17 minecraft:light_gray_concrete
setblock ~33 ~-36 ~17 minecraft:white_concrete
setblock ~34 ~-36 ~17 minecraft:red_concrete
setblock ~35 ~-36 ~17 minecraft:white_concrete
setblock ~36 ~-36 ~17 minecraft:light_gray_concrete
fill ~37 ~-36 ~17 ~49 ~-36 ~17 minecraft:white_concrete
setblock ~50 ~-36 ~17 minecraft:light_gray_concrete
fill ~51 ~-36 ~17 ~63 ~-36 ~17 minecraft:white_concrete
setblock ~64 ~-36 ~17 minecraft:light_gray_concrete
fill ~4 ~-36 ~18 ~32 ~-36 ~18 minecraft:light_gray_concrete
setblock ~33 ~-36 ~18 minecraft:white_concrete
setblock ~34 ~-36 ~18 minecraft:red_concrete
setblock ~35 ~-36 ~18 minecraft:white_concrete
fill ~36 ~-36 ~18 ~64 ~-36 ~18 minecraft:light_gray_concrete
setblock ~4 ~-36 ~19 minecraft:light_gray_concrete
fill ~5 ~-36 ~19 ~17 ~-36 ~19 minecraft:white_concrete
setblock ~18 ~-36 ~19 minecraft:light_gray_concrete
setblock ~19 ~-36 ~19 minecraft:white_concrete
fill ~20 ~-36 ~19 ~22 ~-36 ~19 minecraft:polished_andesite
setblock ~23 ~-36 ~19 minecraft:white_concrete
fill ~24 ~-36 ~19 ~26 ~-36 ~19 minecraft:polished_andesite
setblock ~27 ~-36 ~19 minecraft:white_concrete
fill ~28 ~-36 ~19 ~30 ~-36 ~19 minecraft:polished_andesite
setblock ~31 ~-36 ~19 minecraft:white_concrete
setblock ~32 ~-36 ~19 minecraft:light_gray_concrete
setblock ~33 ~-36 ~19 minecraft:white_concrete
setblock ~34 ~-36 ~19 minecraft:red_concrete
setblock ~35 ~-36 ~19 minecraft:white_concrete
setblock ~36 ~-36 ~19 minecraft:light_gray_concrete
fill ~37 ~-36 ~19 ~49 ~-36 ~19 minecraft:white_concrete
setblock ~50 ~-36 ~19 minecraft:light_gray_concrete
fill ~51 ~-36 ~19 ~63 ~-36 ~19 minecraft:white_concrete
setblock ~64 ~-36 ~19 minecraft:light_gray_concrete
setblock ~4 ~-36 ~20 minecraft:light_gray_concrete
fill ~5 ~-36 ~20 ~17 ~-36 ~20 minecraft:white_concrete
setblock ~18 ~-36 ~20 minecraft:light_gray_concrete
setblock ~19 ~-36 ~20 minecraft:white_concrete
fill ~20 ~-36 ~20 ~22 ~-36 ~20 minecraft:polished_andesite
setblock ~23 ~-36 ~20 minecraft:white_concrete
fill ~24 ~-36 ~20 ~26 ~-36 ~20 minecraft:polished_andesite
setblock ~27 ~-36 ~20 minecraft:white_concrete
fill ~28 ~-36 ~20 ~29 ~-36 ~20 minecraft:polished_andesite
fill ~30 ~-36 ~20 ~31 ~-36 ~20 minecraft:white_concrete
setblock ~32 ~-36 ~20 minecraft:light_gray_concrete
setblock ~33 ~-36 ~20 minecraft:white_concrete
setblock ~34 ~-36 ~20 minecraft:red_concrete
setblock ~35 ~-36 ~20 minecraft:white_concrete
setblock ~36 ~-36 ~20 minecraft:light_gray_concrete
fill ~37 ~-36 ~20 ~49 ~-36 ~20 minecraft:white_concrete
setblock ~50 ~-36 ~20 minecraft:light_gray_concrete
fill ~51 ~-36 ~20 ~63 ~-36 ~20 minecraft:white_concrete
setblock ~64 ~-36 ~20 minecraft:light_gray_concrete
setblock ~4 ~-36 ~21 minecraft:light_gray_concrete
fill ~5 ~-36 ~21 ~17 ~-36 ~21 minecraft:white_concrete
setblock ~18 ~-36 ~21 minecraft:light_gray_concrete
setblock ~19 ~-36 ~21 minecraft:white_concrete
fill ~20 ~-36 ~21 ~22 ~-36 ~21 minecraft:polished_andesite
setblock ~23 ~-36 ~21 minecraft:white_concrete
fill ~24 ~-36 ~21 ~26 ~-36 ~21 minecraft:polished_andesite
fill ~27 ~-36 ~21 ~28 ~-36 ~21 minecraft:white_concrete
fill ~29 ~-36 ~21 ~30 ~-36 ~21 minecraft:polished_andesite
setblock ~31 ~-36 ~21 minecraft:white_concrete
setblock ~32 ~-36 ~21 minecraft:light_gray_concrete
setblock ~33 ~-36 ~21 minecraft:white_concrete
setblock ~34 ~-36 ~21 minecraft:smooth_quartz
setblock ~35 ~-36 ~21 minecraft:white_concrete
setblock ~36 ~-36 ~21 minecraft:light_gray_concrete
fill ~37 ~-36 ~21 ~49 ~-36 ~21 minecraft:white_concrete
setblock ~50 ~-36 ~21 minecraft:light_gray_concrete
fill ~51 ~-36 ~21 ~63 ~-36 ~21 minecraft:white_concrete
setblock ~64 ~-36 ~21 minecraft:light_gray_concrete
setblock ~4 ~-36 ~22 minecraft:light_gray_concrete
fill ~5 ~-36 ~22 ~17 ~-36 ~22 minecraft:white_concrete
setblock ~18 ~-36 ~22 minecraft:light_gray_concrete
fill ~19 ~-36 ~22 ~28 ~-36 ~22 minecraft:white_concrete
fill ~29 ~-36 ~22 ~32 ~-36 ~22 minecraft:polished_andesite
fill ~33 ~-36 ~22 ~35 ~-36 ~22 minecraft:smooth_quartz
fill ~36 ~-36 ~22 ~39 ~-36 ~22 minecraft:polished_andesite
fill ~40 ~-36 ~22 ~45 ~-36 ~22 minecraft:white_concrete
setblock ~46 ~-36 ~22 minecraft:soul_sand
fill ~47 ~-36 ~22 ~49 ~-36 ~22 minecraft:white_concrete
setblock ~50 ~-36 ~22 minecraft:light_gray_concrete
fill ~51 ~-36 ~22 ~63 ~-36 ~22 minecraft:white_concrete
setblock ~64 ~-36 ~22 minecraft:light_gray_concrete
setblock ~4 ~-36 ~23 minecraft:light_gray_concrete
fill ~5 ~-36 ~23 ~17 ~-36 ~23 minecraft:white_concrete
setblock ~18 ~-36 ~23 minecraft:light_gray_concrete
fill ~19 ~-36 ~23 ~27 ~-36 ~23 minecraft:white_concrete
fill ~28 ~-36 ~23 ~29 ~-36 ~23 minecraft:polished_andesite
fill ~30 ~-36 ~23 ~33 ~-36 ~23 minecraft:smooth_quartz
setblock ~34 ~-36 ~23 minecraft:polished_diorite
fill ~35 ~-36 ~23 ~38 ~-36 ~23 minecraft:smooth_quartz
fill ~39 ~-36 ~23 ~40 ~-36 ~23 minecraft:polished_andesite
fill ~41 ~-36 ~23 ~49 ~-36 ~23 minecraft:white_concrete
setblock ~50 ~-36 ~23 minecraft:light_gray_concrete
fill ~51 ~-36 ~23 ~53 ~-36 ~23 minecraft:white_concrete
fill ~54 ~-36 ~23 ~59 ~-36 ~23 minecraft:cyan_concrete
fill ~60 ~-36 ~23 ~63 ~-36 ~23 minecraft:white_concrete
schedule function hive:weiter/8 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 7 von 18 fertig","color":"gray"}]