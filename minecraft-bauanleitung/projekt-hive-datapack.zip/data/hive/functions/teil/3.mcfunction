setblock ~64 ~-63 ~5 minecraft:deepslate_tiles
setblock ~4 ~-63 ~6 minecraft:deepslate_tiles
setblock ~5 ~-63 ~6 minecraft:waxed_cut_copper
fill ~6 ~-63 ~6 ~16 ~-63 ~6 minecraft:air
setblock ~17 ~-63 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~6 minecraft:deepslate_tiles
setblock ~19 ~-63 ~6 minecraft:waxed_cut_copper
fill ~20 ~-63 ~6 ~30 ~-63 ~6 minecraft:air
setblock ~31 ~-63 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~6 minecraft:deepslate_tiles
fill ~33 ~-63 ~6 ~35 ~-63 ~6 minecraft:air
setblock ~36 ~-63 ~6 minecraft:deepslate_tiles
fill ~37 ~-63 ~6 ~49 ~-63 ~6 minecraft:air
setblock ~50 ~-63 ~6 minecraft:deepslate_tiles
setblock ~51 ~-63 ~6 minecraft:waxed_cut_copper
fill ~52 ~-63 ~6 ~62 ~-63 ~6 minecraft:air
setblock ~63 ~-63 ~6 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~6 minecraft:deepslate_tiles
setblock ~4 ~-63 ~7 minecraft:deepslate_tiles
setblock ~5 ~-63 ~7 minecraft:waxed_cut_copper
fill ~6 ~-63 ~7 ~16 ~-63 ~7 minecraft:air
setblock ~17 ~-63 ~7 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~7 minecraft:deepslate_tiles
setblock ~19 ~-63 ~7 minecraft:waxed_cut_copper
fill ~20 ~-63 ~7 ~30 ~-63 ~7 minecraft:air
setblock ~31 ~-63 ~7 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~7 minecraft:deepslate_tiles
fill ~33 ~-63 ~7 ~35 ~-63 ~7 minecraft:air
setblock ~36 ~-63 ~7 minecraft:deepslate_tiles
fill ~37 ~-63 ~7 ~49 ~-63 ~7 minecraft:air
setblock ~50 ~-63 ~7 minecraft:deepslate_tiles
fill ~51 ~-63 ~7 ~63 ~-63 ~7 minecraft:air
setblock ~64 ~-63 ~7 minecraft:deepslate_tiles
setblock ~4 ~-63 ~8 minecraft:deepslate_tiles
setblock ~5 ~-63 ~8 minecraft:waxed_cut_copper
fill ~6 ~-63 ~8 ~16 ~-63 ~8 minecraft:air
setblock ~17 ~-63 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~8 minecraft:deepslate_tiles
setblock ~19 ~-63 ~8 minecraft:waxed_cut_copper
fill ~20 ~-63 ~8 ~30 ~-63 ~8 minecraft:air
setblock ~31 ~-63 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~8 minecraft:deepslate_tiles
fill ~33 ~-63 ~8 ~35 ~-63 ~8 minecraft:air
setblock ~36 ~-63 ~8 minecraft:deepslate_tiles
setblock ~37 ~-63 ~8 minecraft:waxed_cut_copper
fill ~38 ~-63 ~8 ~48 ~-63 ~8 minecraft:air
setblock ~49 ~-63 ~8 minecraft:waxed_cut_copper
setblock ~50 ~-63 ~8 minecraft:deepslate_tiles
fill ~51 ~-63 ~8 ~63 ~-63 ~8 minecraft:air
setblock ~64 ~-63 ~8 minecraft:deepslate_tiles
setblock ~4 ~-63 ~9 minecraft:deepslate_tiles
setblock ~5 ~-63 ~9 minecraft:waxed_cut_copper
fill ~6 ~-63 ~9 ~16 ~-63 ~9 minecraft:air
setblock ~17 ~-63 ~9 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~9 minecraft:deepslate_tiles
setblock ~19 ~-63 ~9 minecraft:waxed_cut_copper
fill ~20 ~-63 ~9 ~30 ~-63 ~9 minecraft:air
setblock ~31 ~-63 ~9 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~9 minecraft:deepslate_tiles
fill ~33 ~-63 ~9 ~35 ~-63 ~9 minecraft:air
setblock ~36 ~-63 ~9 minecraft:deepslate_tiles
fill ~37 ~-63 ~9 ~49 ~-63 ~9 minecraft:air
setblock ~50 ~-63 ~9 minecraft:deepslate_tiles
setblock ~51 ~-63 ~9 minecraft:waxed_cut_copper
fill ~52 ~-63 ~9 ~62 ~-63 ~9 minecraft:air
setblock ~63 ~-63 ~9 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~9 minecraft:deepslate_tiles
setblock ~4 ~-63 ~10 minecraft:deepslate_tiles
setblock ~5 ~-63 ~10 minecraft:waxed_cut_copper
fill ~6 ~-63 ~10 ~17 ~-63 ~10 minecraft:air
setblock ~18 ~-63 ~10 minecraft:deepslate_tiles
fill ~19 ~-63 ~10 ~31 ~-63 ~10 minecraft:air
setblock ~32 ~-63 ~10 minecraft:deepslate_tiles
fill ~33 ~-63 ~10 ~35 ~-63 ~10 minecraft:air
setblock ~36 ~-63 ~10 minecraft:deepslate_tiles
fill ~37 ~-63 ~10 ~49 ~-63 ~10 minecraft:air
setblock ~50 ~-63 ~10 minecraft:deepslate_tiles
fill ~51 ~-63 ~10 ~63 ~-63 ~10 minecraft:air
setblock ~64 ~-63 ~10 minecraft:deepslate_tiles
setblock ~4 ~-63 ~11 minecraft:deepslate_tiles
setblock ~5 ~-63 ~11 minecraft:waxed_cut_copper
fill ~6 ~-63 ~11 ~17 ~-63 ~11 minecraft:air
setblock ~18 ~-63 ~11 minecraft:deepslate_tiles
fill ~19 ~-63 ~11 ~31 ~-63 ~11 minecraft:air
setblock ~32 ~-63 ~11 minecraft:deepslate_tiles
fill ~33 ~-63 ~11 ~35 ~-63 ~11 minecraft:air
setblock ~36 ~-63 ~11 minecraft:deepslate_tiles
fill ~37 ~-63 ~11 ~49 ~-63 ~11 minecraft:air
setblock ~50 ~-63 ~11 minecraft:deepslate_tiles
fill ~51 ~-63 ~11 ~63 ~-63 ~11 minecraft:air
setblock ~64 ~-63 ~11 minecraft:deepslate_tiles
setblock ~4 ~-63 ~12 minecraft:deepslate_tiles
setblock ~5 ~-63 ~12 minecraft:waxed_cut_copper
fill ~6 ~-63 ~12 ~11 ~-63 ~12 minecraft:air
setblock ~12 ~-63 ~12 minecraft:lightning_rod[facing=up]
fill ~13 ~-63 ~12 ~17 ~-63 ~12 minecraft:air
setblock ~18 ~-63 ~12 minecraft:deepslate_tiles
fill ~19 ~-63 ~12 ~21 ~-63 ~12 minecraft:air
setblock ~22 ~-63 ~12 minecraft:lightning_rod[facing=up]
fill ~23 ~-63 ~12 ~26 ~-63 ~12 minecraft:air
setblock ~27 ~-63 ~12 minecraft:lightning_rod[facing=up]
fill ~28 ~-63 ~12 ~31 ~-63 ~12 minecraft:air
setblock ~32 ~-63 ~12 minecraft:deepslate_tiles
fill ~33 ~-63 ~12 ~35 ~-63 ~12 minecraft:air
setblock ~36 ~-63 ~12 minecraft:deepslate_tiles
fill ~37 ~-63 ~12 ~49 ~-63 ~12 minecraft:air
setblock ~50 ~-63 ~12 minecraft:deepslate_tiles
fill ~51 ~-63 ~12 ~62 ~-63 ~12 minecraft:air
setblock ~63 ~-63 ~12 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~12 minecraft:deepslate_tiles
setblock ~4 ~-63 ~13 minecraft:deepslate_tiles
setblock ~5 ~-63 ~13 minecraft:waxed_cut_copper
fill ~6 ~-63 ~13 ~16 ~-63 ~13 minecraft:air
setblock ~17 ~-63 ~13 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~13 minecraft:deepslate_tiles
setblock ~19 ~-63 ~13 minecraft:waxed_cut_copper
fill ~20 ~-63 ~13 ~30 ~-63 ~13 minecraft:air
setblock ~31 ~-63 ~13 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~13 minecraft:deepslate_tiles
fill ~33 ~-63 ~13 ~35 ~-63 ~13 minecraft:air
setblock ~36 ~-63 ~13 minecraft:deepslate_tiles
fill ~37 ~-63 ~13 ~49 ~-63 ~13 minecraft:air
setblock ~50 ~-63 ~13 minecraft:deepslate_tiles
fill ~51 ~-63 ~13 ~63 ~-63 ~13 minecraft:air
setblock ~64 ~-63 ~13 minecraft:deepslate_tiles
setblock ~4 ~-63 ~14 minecraft:deepslate_tiles
setblock ~5 ~-63 ~14 minecraft:waxed_cut_copper
fill ~6 ~-63 ~14 ~16 ~-63 ~14 minecraft:air
setblock ~17 ~-63 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~14 minecraft:deepslate_tiles
setblock ~19 ~-63 ~14 minecraft:waxed_cut_copper
fill ~20 ~-63 ~14 ~30 ~-63 ~14 minecraft:air
setblock ~31 ~-63 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~14 minecraft:deepslate_tiles
fill ~33 ~-63 ~14 ~35 ~-63 ~14 minecraft:air
setblock ~36 ~-63 ~14 minecraft:deepslate_tiles
setblock ~37 ~-63 ~14 minecraft:waxed_cut_copper
fill ~38 ~-63 ~14 ~48 ~-63 ~14 minecraft:air
setblock ~49 ~-63 ~14 minecraft:waxed_cut_copper
setblock ~50 ~-63 ~14 minecraft:deepslate_tiles
fill ~51 ~-63 ~14 ~63 ~-63 ~14 minecraft:air
setblock ~64 ~-63 ~14 minecraft:deepslate_tiles
setblock ~4 ~-63 ~15 minecraft:deepslate_tiles
setblock ~5 ~-63 ~15 minecraft:waxed_cut_copper
fill ~6 ~-63 ~15 ~16 ~-63 ~15 minecraft:air
setblock ~17 ~-63 ~15 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~15 minecraft:deepslate_tiles
setblock ~19 ~-63 ~15 minecraft:waxed_cut_copper
fill ~20 ~-63 ~15 ~30 ~-63 ~15 minecraft:air
setblock ~31 ~-63 ~15 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~15 minecraft:deepslate_tiles
fill ~33 ~-63 ~15 ~35 ~-63 ~15 minecraft:air
setblock ~36 ~-63 ~15 minecraft:deepslate_tiles
fill ~37 ~-63 ~15 ~49 ~-63 ~15 minecraft:air
setblock ~50 ~-63 ~15 minecraft:deepslate_tiles
setblock ~51 ~-63 ~15 minecraft:waxed_cut_copper
fill ~52 ~-63 ~15 ~62 ~-63 ~15 minecraft:air
setblock ~63 ~-63 ~15 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~15 minecraft:deepslate_tiles
setblock ~4 ~-63 ~16 minecraft:deepslate_tiles
setblock ~5 ~-63 ~16 minecraft:waxed_cut_copper
fill ~6 ~-63 ~16 ~16 ~-63 ~16 minecraft:air
setblock ~17 ~-63 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~16 minecraft:deepslate_tiles
setblock ~19 ~-63 ~16 minecraft:waxed_cut_copper
fill ~20 ~-63 ~16 ~30 ~-63 ~16 minecraft:air
setblock ~31 ~-63 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~16 minecraft:deepslate_tiles
fill ~33 ~-63 ~16 ~35 ~-63 ~16 minecraft:air
setblock ~36 ~-63 ~16 minecraft:deepslate_tiles
fill ~37 ~-63 ~16 ~49 ~-63 ~16 minecraft:air
setblock ~50 ~-63 ~16 minecraft:deepslate_tiles
fill ~51 ~-63 ~16 ~63 ~-63 ~16 minecraft:air
setblock ~64 ~-63 ~16 minecraft:deepslate_tiles
setblock ~4 ~-63 ~17 minecraft:deepslate_tiles
fill ~5 ~-63 ~17 ~9 ~-63 ~17 minecraft:waxed_cut_copper
fill ~10 ~-63 ~17 ~12 ~-63 ~17 minecraft:air
fill ~13 ~-63 ~17 ~17 ~-63 ~17 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~17 minecraft:deepslate_tiles
fill ~19 ~-63 ~17 ~31 ~-63 ~17 minecraft:waxed_cut_copper
setblock ~32 ~-63 ~17 minecraft:deepslate_tiles
fill ~33 ~-63 ~17 ~35 ~-63 ~17 minecraft:air
setblock ~36 ~-63 ~17 minecraft:deepslate_tiles
setblock ~37 ~-63 ~17 minecraft:waxed_cut_copper
fill ~38 ~-63 ~17 ~39 ~-63 ~17 minecraft:air
setblock ~40 ~-63 ~17 minecraft:waxed_cut_copper
fill ~41 ~-63 ~17 ~42 ~-63 ~17 minecraft:air
setblock ~43 ~-63 ~17 minecraft:waxed_cut_copper
fill ~44 ~-63 ~17 ~45 ~-63 ~17 minecraft:air
setblock ~46 ~-63 ~17 minecraft:waxed_cut_copper
fill ~47 ~-63 ~17 ~48 ~-63 ~17 minecraft:air
setblock ~49 ~-63 ~17 minecraft:waxed_cut_copper
setblock ~50 ~-63 ~17 minecraft:deepslate_tiles
setblock ~51 ~-63 ~17 minecraft:air
setblock ~52 ~-63 ~17 minecraft:waxed_cut_copper
fill ~53 ~-63 ~17 ~54 ~-63 ~17 minecraft:air
setblock ~55 ~-63 ~17 minecraft:waxed_cut_copper
fill ~56 ~-63 ~17 ~60 ~-63 ~17 minecraft:air
setblock ~61 ~-63 ~17 minecraft:waxed_cut_copper
fill ~62 ~-63 ~17 ~63 ~-63 ~17 minecraft:air
setblock ~64 ~-63 ~17 minecraft:deepslate_tiles
fill ~4 ~-63 ~18 ~32 ~-63 ~18 minecraft:deepslate_tiles
fill ~33 ~-63 ~18 ~35 ~-63 ~18 minecraft:air
fill ~36 ~-63 ~18 ~64 ~-63 ~18 minecraft:deepslate_tiles
setblock ~4 ~-63 ~19 minecraft:deepslate_tiles
setblock ~5 ~-63 ~19 minecraft:air
setblock ~6 ~-63 ~19 minecraft:waxed_cut_copper
fill ~7 ~-63 ~19 ~8 ~-63 ~19 minecraft:air
setblock ~9 ~-63 ~19 minecraft:waxed_cut_copper
fill ~10 ~-63 ~19 ~14 ~-63 ~19 minecraft:air
setblock ~15 ~-63 ~19 minecraft:waxed_cut_copper
fill ~16 ~-63 ~19 ~17 ~-63 ~19 minecraft:air
setblock ~18 ~-63 ~19 minecraft:deepslate_tiles
fill ~19 ~-63 ~19 ~31 ~-63 ~19 minecraft:air
setblock ~32 ~-63 ~19 minecraft:deepslate_tiles
setblock ~33 ~-63 ~19 minecraft:air
setblock ~34 ~-63 ~19 minecraft:deepslate_tiles
setblock ~35 ~-63 ~19 minecraft:air
setblock ~36 ~-63 ~19 minecraft:deepslate_tiles
fill ~37 ~-63 ~19 ~49 ~-63 ~19 minecraft:air
setblock ~50 ~-63 ~19 minecraft:deepslate_tiles
fill ~51 ~-63 ~19 ~63 ~-63 ~19 minecraft:air
setblock ~64 ~-63 ~19 minecraft:deepslate_tiles
setblock ~4 ~-63 ~20 minecraft:deepslate_tiles
setblock ~5 ~-63 ~20 minecraft:waxed_cut_copper
fill ~6 ~-63 ~20 ~16 ~-63 ~20 minecraft:air
setblock ~17 ~-63 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~20 minecraft:deepslate_tiles
fill ~19 ~-63 ~20 ~28 ~-63 ~20 minecraft:air
fill ~29 ~-63 ~20 ~33 ~-63 ~20 minecraft:deepslate_tiles
setblock ~34 ~-63 ~20 minecraft:air
fill ~35 ~-63 ~20 ~39 ~-63 ~20 minecraft:deepslate_tiles
fill ~40 ~-63 ~20 ~49 ~-63 ~20 minecraft:air
setblock ~50 ~-63 ~20 minecraft:deepslate_tiles
fill ~51 ~-63 ~20 ~63 ~-63 ~20 minecraft:air
setblock ~64 ~-63 ~20 minecraft:deepslate_tiles
setblock ~4 ~-63 ~21 minecraft:deepslate_tiles
fill ~5 ~-63 ~21 ~17 ~-63 ~21 minecraft:air
setblock ~18 ~-63 ~21 minecraft:deepslate_tiles
fill ~19 ~-63 ~21 ~26 ~-63 ~21 minecraft:air
fill ~27 ~-63 ~21 ~28 ~-63 ~21 minecraft:deepslate_tiles
fill ~29 ~-63 ~21 ~39 ~-63 ~21 minecraft:air
fill ~40 ~-63 ~21 ~41 ~-63 ~21 minecraft:deepslate_tiles
fill ~42 ~-63 ~21 ~49 ~-63 ~21 minecraft:air
setblock ~50 ~-63 ~21 minecraft:deepslate_tiles
fill ~51 ~-63 ~21 ~63 ~-63 ~21 minecraft:air
setblock ~64 ~-63 ~21 minecraft:deepslate_tiles
setblock ~4 ~-63 ~22 minecraft:deepslate_tiles
fill ~5 ~-63 ~22 ~17 ~-63 ~22 minecraft:air
setblock ~18 ~-63 ~22 minecraft:deepslate_tiles
fill ~19 ~-63 ~22 ~24 ~-63 ~22 minecraft:air
fill ~25 ~-63 ~22 ~26 ~-63 ~22 minecraft:deepslate_tiles
fill ~27 ~-63 ~22 ~41 ~-63 ~22 minecraft:air
fill ~42 ~-63 ~22 ~43 ~-63 ~22 minecraft:deepslate_tiles
fill ~44 ~-63 ~22 ~49 ~-63 ~22 minecraft:air
setblock ~50 ~-63 ~22 minecraft:deepslate_tiles
fill ~51 ~-63 ~22 ~63 ~-63 ~22 minecraft:air
setblock ~64 ~-63 ~22 minecraft:deepslate_tiles
setblock ~4 ~-63 ~23 minecraft:deepslate_tiles
setblock ~5 ~-63 ~23 minecraft:waxed_cut_copper
fill ~6 ~-63 ~23 ~16 ~-63 ~23 minecraft:air
setblock ~17 ~-63 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~23 minecraft:deepslate_tiles
fill ~19 ~-63 ~23 ~23 ~-63 ~23 minecraft:air
fill ~24 ~-63 ~23 ~25 ~-63 ~23 minecraft:deepslate_tiles
fill ~26 ~-63 ~23 ~42 ~-63 ~23 minecraft:air
fill ~43 ~-63 ~23 ~44 ~-63 ~23 minecraft:deepslate_tiles
fill ~45 ~-63 ~23 ~49 ~-63 ~23 minecraft:air
setblock ~50 ~-63 ~23 minecraft:deepslate_tiles
fill ~51 ~-63 ~23 ~63 ~-63 ~23 minecraft:air
setblock ~64 ~-63 ~23 minecraft:deepslate_tiles
setblock ~4 ~-63 ~24 minecraft:deepslate_tiles
fill ~5 ~-63 ~24 ~17 ~-63 ~24 minecraft:air
setblock ~18 ~-63 ~24 minecraft:deepslate_tiles
fill ~19 ~-63 ~24 ~22 ~-63 ~24 minecraft:air
fill ~23 ~-63 ~24 ~24 ~-63 ~24 minecraft:deepslate_tiles
fill ~25 ~-63 ~24 ~43 ~-63 ~24 minecraft:air
fill ~44 ~-63 ~24 ~45 ~-63 ~24 minecraft:deepslate_tiles
fill ~46 ~-63 ~24 ~49 ~-63 ~24 minecraft:air
setblock ~50 ~-63 ~24 minecraft:deepslate_tiles
fill ~51 ~-63 ~24 ~63 ~-63 ~24 minecraft:air
setblock ~64 ~-63 ~24 minecraft:deepslate_tiles
setblock ~4 ~-63 ~25 minecraft:deepslate_tiles
fill ~5 ~-63 ~25 ~17 ~-63 ~25 minecraft:air
setblock ~18 ~-63 ~25 minecraft:deepslate_tiles
fill ~19 ~-63 ~25 ~21 ~-63 ~25 minecraft:air
fill ~22 ~-63 ~25 ~23 ~-63 ~25 minecraft:deepslate_tiles
fill ~24 ~-63 ~25 ~44 ~-63 ~25 minecraft:air
fill ~45 ~-63 ~25 ~46 ~-63 ~25 minecraft:deepslate_tiles
fill ~47 ~-63 ~25 ~49 ~-63 ~25 minecraft:air
setblock ~50 ~-63 ~25 minecraft:deepslate_tiles
fill ~51 ~-63 ~25 ~63 ~-63 ~25 minecraft:air
setblock ~64 ~-63 ~25 minecraft:deepslate_tiles
setblock ~4 ~-63 ~26 minecraft:deepslate_tiles
setblock ~5 ~-63 ~26 minecraft:waxed_cut_copper
fill ~6 ~-63 ~26 ~16 ~-63 ~26 minecraft:air
setblock ~17 ~-63 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~26 minecraft:deepslate_tiles
fill ~19 ~-63 ~26 ~21 ~-63 ~26 minecraft:air
setblock ~22 ~-63 ~26 minecraft:deepslate_tiles
fill ~23 ~-63 ~26 ~25 ~-63 ~26 minecraft:air
setblock ~26 ~-63 ~26 minecraft:waxed_cut_copper
fill ~27 ~-63 ~26 ~41 ~-63 ~26 minecraft:air
setblock ~42 ~-63 ~26 minecraft:waxed_cut_copper
fill ~43 ~-63 ~26 ~45 ~-63 ~26 minecraft:air
setblock ~46 ~-63 ~26 minecraft:deepslate_tiles
fill ~47 ~-63 ~26 ~49 ~-63 ~26 minecraft:air
setblock ~50 ~-63 ~26 minecraft:deepslate_tiles
fill ~51 ~-63 ~26 ~63 ~-63 ~26 minecraft:air
setblock ~64 ~-63 ~26 minecraft:deepslate_tiles
setblock ~4 ~-63 ~27 minecraft:deepslate_tiles
fill ~5 ~-63 ~27 ~17 ~-63 ~27 minecraft:air
setblock ~18 ~-63 ~27 minecraft:deepslate_tiles
fill ~19 ~-63 ~27 ~20 ~-63 ~27 minecraft:air
setblock ~21 ~-63 ~27 minecraft:deepslate_tiles
fill ~22 ~-63 ~27 ~46 ~-63 ~27 minecraft:air
setblock ~47 ~-63 ~27 minecraft:deepslate_tiles
fill ~48 ~-63 ~27 ~49 ~-63 ~27 minecraft:air
setblock ~50 ~-63 ~27 minecraft:deepslate_tiles
fill ~51 ~-63 ~27 ~63 ~-63 ~27 minecraft:air
setblock ~64 ~-63 ~27 minecraft:deepslate_tiles
setblock ~4 ~-63 ~28 minecraft:deepslate_tiles
fill ~5 ~-63 ~28 ~17 ~-63 ~28 minecraft:air
setblock ~18 ~-63 ~28 minecraft:deepslate_tiles
fill ~19 ~-63 ~28 ~20 ~-63 ~28 minecraft:air
setblock ~21 ~-63 ~28 minecraft:deepslate_tiles
fill ~22 ~-63 ~28 ~46 ~-63 ~28 minecraft:air
setblock ~47 ~-63 ~28 minecraft:deepslate_tiles
fill ~48 ~-63 ~28 ~49 ~-63 ~28 minecraft:air
setblock ~50 ~-63 ~28 minecraft:deepslate_tiles
fill ~51 ~-63 ~28 ~63 ~-63 ~28 minecraft:air
setblock ~64 ~-63 ~28 minecraft:deepslate_tiles
setblock ~4 ~-63 ~29 minecraft:deepslate_tiles
setblock ~5 ~-63 ~29 minecraft:waxed_cut_copper
fill ~6 ~-63 ~29 ~16 ~-63 ~29 minecraft:air
setblock ~17 ~-63 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~29 minecraft:deepslate_tiles
setblock ~19 ~-63 ~29 minecraft:air
setblock ~20 ~-63 ~29 minecraft:deepslate_tiles
fill ~21 ~-63 ~29 ~47 ~-63 ~29 minecraft:air
setblock ~48 ~-63 ~29 minecraft:deepslate_tiles
setblock ~49 ~-63 ~29 minecraft:air
setblock ~50 ~-63 ~29 minecraft:deepslate_tiles
fill ~51 ~-63 ~29 ~63 ~-63 ~29 minecraft:air
setblock ~64 ~-63 ~29 minecraft:deepslate_tiles
setblock ~4 ~-63 ~30 minecraft:deepslate_tiles
fill ~5 ~-63 ~30 ~17 ~-63 ~30 minecraft:air
setblock ~18 ~-63 ~30 minecraft:deepslate_tiles
setblock ~19 ~-63 ~30 minecraft:air
setblock ~20 ~-63 ~30 minecraft:deepslate_tiles
fill ~21 ~-63 ~30 ~47 ~-63 ~30 minecraft:air
setblock ~48 ~-63 ~30 minecraft:deepslate_tiles
setblock ~49 ~-63 ~30 minecraft:air
setblock ~50 ~-63 ~30 minecraft:deepslate_tiles
fill ~51 ~-63 ~30 ~63 ~-63 ~30 minecraft:air
setblock ~64 ~-63 ~30 minecraft:deepslate_tiles
setblock ~4 ~-63 ~31 minecraft:deepslate_tiles
setblock ~5 ~-63 ~31 minecraft:air
setblock ~6 ~-63 ~31 minecraft:waxed_cut_copper
fill ~7 ~-63 ~31 ~8 ~-63 ~31 minecraft:air
setblock ~9 ~-63 ~31 minecraft:waxed_cut_copper
fill ~10 ~-63 ~31 ~14 ~-63 ~31 minecraft:air
setblock ~15 ~-63 ~31 minecraft:waxed_cut_copper
fill ~16 ~-63 ~31 ~17 ~-63 ~31 minecraft:air
setblock ~18 ~-63 ~31 minecraft:deepslate_tiles
setblock ~19 ~-63 ~31 minecraft:air
setblock ~20 ~-63 ~31 minecraft:deepslate_tiles
fill ~21 ~-63 ~31 ~47 ~-63 ~31 minecraft:air
setblock ~48 ~-63 ~31 minecraft:deepslate_tiles
setblock ~49 ~-63 ~31 minecraft:air
setblock ~50 ~-63 ~31 minecraft:deepslate_tiles
fill ~51 ~-63 ~31 ~63 ~-63 ~31 minecraft:air
setblock ~64 ~-63 ~31 minecraft:deepslate_tiles
fill ~4 ~-63 ~32 ~20 ~-63 ~32 minecraft:deepslate_tiles
fill ~21 ~-63 ~32 ~32 ~-63 ~32 minecraft:air
fill ~33 ~-63 ~32 ~35 ~-63 ~32 minecraft:glass
fill ~36 ~-63 ~32 ~47 ~-63 ~32 minecraft:air
fill ~48 ~-63 ~32 ~64 ~-63 ~32 minecraft:deepslate_tiles
setblock ~4 ~-63 ~33 minecraft:deepslate_tiles
fill ~5 ~-63 ~33 ~19 ~-63 ~33 minecraft:air
setblock ~20 ~-63 ~33 minecraft:deepslate_tiles
fill ~21 ~-63 ~33 ~31 ~-63 ~33 minecraft:air
setblock ~32 ~-63 ~33 minecraft:glass
fill ~33 ~-63 ~33 ~35 ~-63 ~33 minecraft:sea_lantern
setblock ~36 ~-63 ~33 minecraft:glass
fill ~37 ~-63 ~33 ~47 ~-63 ~33 minecraft:air
setblock ~48 ~-63 ~33 minecraft:deepslate_tiles
fill ~49 ~-63 ~33 ~63 ~-63 ~33 minecraft:air
setblock ~64 ~-63 ~33 minecraft:deepslate_tiles
setblock ~4 ~-63 ~34 minecraft:deepslate_tiles
fill ~5 ~-63 ~34 ~18 ~-63 ~34 minecraft:air
setblock ~19 ~-63 ~34 minecraft:deepslate_tiles
fill ~20 ~-63 ~34 ~31 ~-63 ~34 minecraft:air
setblock ~32 ~-63 ~34 minecraft:glass
fill ~33 ~-63 ~34 ~35 ~-63 ~34 minecraft:sea_lantern
setblock ~36 ~-63 ~34 minecraft:glass
fill ~37 ~-63 ~34 ~48 ~-63 ~34 minecraft:air
setblock ~49 ~-63 ~34 minecraft:deepslate_tiles
fill ~50 ~-63 ~34 ~63 ~-63 ~34 minecraft:air
setblock ~64 ~-63 ~34 minecraft:deepslate_tiles
setblock ~4 ~-63 ~35 minecraft:deepslate_tiles
fill ~5 ~-63 ~35 ~19 ~-63 ~35 minecraft:air
setblock ~20 ~-63 ~35 minecraft:deepslate_tiles
fill ~21 ~-63 ~35 ~31 ~-63 ~35 minecraft:air
setblock ~32 ~-63 ~35 minecraft:glass
fill ~33 ~-63 ~35 ~35 ~-63 ~35 minecraft:sea_lantern
setblock ~36 ~-63 ~35 minecraft:glass
fill ~37 ~-63 ~35 ~47 ~-63 ~35 minecraft:air
setblock ~48 ~-63 ~35 minecraft:deepslate_tiles
fill ~49 ~-63 ~35 ~63 ~-63 ~35 minecraft:air
setblock ~64 ~-63 ~35 minecraft:deepslate_tiles
fill ~4 ~-63 ~36 ~20 ~-63 ~36 minecraft:deepslate_tiles
fill ~21 ~-63 ~36 ~32 ~-63 ~36 minecraft:air
fill ~33 ~-63 ~36 ~35 ~-63 ~36 minecraft:glass
fill ~36 ~-63 ~36 ~47 ~-63 ~36 minecraft:air
fill ~48 ~-63 ~36 ~64 ~-63 ~36 minecraft:deepslate_tiles
setblock ~4 ~-63 ~37 minecraft:deepslate_tiles
setblock ~5 ~-63 ~37 minecraft:air
setblock ~6 ~-63 ~37 minecraft:waxed_cut_copper
fill ~7 ~-63 ~37 ~8 ~-63 ~37 minecraft:air
setblock ~9 ~-63 ~37 minecraft:waxed_cut_copper
fill ~10 ~-63 ~37 ~14 ~-63 ~37 minecraft:air
setblock ~15 ~-63 ~37 minecraft:waxed_cut_copper
fill ~16 ~-63 ~37 ~17 ~-63 ~37 minecraft:air
setblock ~18 ~-63 ~37 minecraft:deepslate_tiles
setblock ~19 ~-63 ~37 minecraft:air
setblock ~20 ~-63 ~37 minecraft:deepslate_tiles
fill ~21 ~-63 ~37 ~47 ~-63 ~37 minecraft:air
setblock ~48 ~-63 ~37 minecraft:deepslate_tiles
setblock ~49 ~-63 ~37 minecraft:air
setblock ~50 ~-63 ~37 minecraft:deepslate_tiles
fill ~51 ~-63 ~37 ~63 ~-63 ~37 minecraft:air
setblock ~64 ~-63 ~37 minecraft:deepslate_tiles
setblock ~4 ~-63 ~38 minecraft:deepslate_tiles
setblock ~5 ~-63 ~38 minecraft:waxed_cut_copper
fill ~6 ~-63 ~38 ~16 ~-63 ~38 minecraft:air
setblock ~17 ~-63 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~38 minecraft:deepslate_tiles
setblock ~19 ~-63 ~38 minecraft:air
setblock ~20 ~-63 ~38 minecraft:deepslate_tiles
fill ~21 ~-63 ~38 ~47 ~-63 ~38 minecraft:air
setblock ~48 ~-63 ~38 minecraft:deepslate_tiles
setblock ~49 ~-63 ~38 minecraft:air
setblock ~50 ~-63 ~38 minecraft:deepslate_tiles
fill ~51 ~-63 ~38 ~63 ~-63 ~38 minecraft:air
setblock ~64 ~-63 ~38 minecraft:deepslate_tiles
setblock ~4 ~-63 ~39 minecraft:deepslate_tiles
fill ~5 ~-63 ~39 ~17 ~-63 ~39 minecraft:air
setblock ~18 ~-63 ~39 minecraft:deepslate_tiles
setblock ~19 ~-63 ~39 minecraft:air
setblock ~20 ~-63 ~39 minecraft:deepslate_tiles
fill ~21 ~-63 ~39 ~47 ~-63 ~39 minecraft:air
setblock ~48 ~-63 ~39 minecraft:deepslate_tiles
setblock ~49 ~-63 ~39 minecraft:air
setblock ~50 ~-63 ~39 minecraft:deepslate_tiles
fill ~51 ~-63 ~39 ~63 ~-63 ~39 minecraft:air
setblock ~64 ~-63 ~39 minecraft:deepslate_tiles
setblock ~4 ~-63 ~40 minecraft:deepslate_tiles
fill ~5 ~-63 ~40 ~17 ~-63 ~40 minecraft:air
setblock ~18 ~-63 ~40 minecraft:deepslate_tiles
fill ~19 ~-63 ~40 ~20 ~-63 ~40 minecraft:air
setblock ~21 ~-63 ~40 minecraft:deepslate_tiles
fill ~22 ~-63 ~40 ~46 ~-63 ~40 minecraft:air
setblock ~47 ~-63 ~40 minecraft:deepslate_tiles
fill ~48 ~-63 ~40 ~49 ~-63 ~40 minecraft:air
setblock ~50 ~-63 ~40 minecraft:deepslate_tiles
fill ~51 ~-63 ~40 ~63 ~-63 ~40 minecraft:air
setblock ~64 ~-63 ~40 minecraft:deepslate_tiles
setblock ~4 ~-63 ~41 minecraft:deepslate_tiles
setblock ~5 ~-63 ~41 minecraft:waxed_cut_copper
fill ~6 ~-63 ~41 ~16 ~-63 ~41 minecraft:air
setblock ~17 ~-63 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~41 minecraft:deepslate_tiles
fill ~19 ~-63 ~41 ~20 ~-63 ~41 minecraft:air
setblock ~21 ~-63 ~41 minecraft:deepslate_tiles
fill ~22 ~-63 ~41 ~46 ~-63 ~41 minecraft:air
setblock ~47 ~-63 ~41 minecraft:deepslate_tiles
fill ~48 ~-63 ~41 ~49 ~-63 ~41 minecraft:air
setblock ~50 ~-63 ~41 minecraft:deepslate_tiles
fill ~51 ~-63 ~41 ~63 ~-63 ~41 minecraft:air
setblock ~64 ~-63 ~41 minecraft:deepslate_tiles
setblock ~4 ~-63 ~42 minecraft:deepslate_tiles
fill ~5 ~-63 ~42 ~17 ~-63 ~42 minecraft:air
setblock ~18 ~-63 ~42 minecraft:deepslate_tiles
fill ~19 ~-63 ~42 ~21 ~-63 ~42 minecraft:air
setblock ~22 ~-63 ~42 minecraft:deepslate_tiles
fill ~23 ~-63 ~42 ~25 ~-63 ~42 minecraft:air
setblock ~26 ~-63 ~42 minecraft:waxed_cut_copper
fill ~27 ~-63 ~42 ~41 ~-63 ~42 minecraft:air
setblock ~42 ~-63 ~42 minecraft:waxed_cut_copper
fill ~43 ~-63 ~42 ~45 ~-63 ~42 minecraft:air
setblock ~46 ~-63 ~42 minecraft:deepslate_tiles
fill ~47 ~-63 ~42 ~49 ~-63 ~42 minecraft:air
setblock ~50 ~-63 ~42 minecraft:deepslate_tiles
fill ~51 ~-63 ~42 ~63 ~-63 ~42 minecraft:air
setblock ~64 ~-63 ~42 minecraft:deepslate_tiles
setblock ~4 ~-63 ~43 minecraft:deepslate_tiles
fill ~5 ~-63 ~43 ~17 ~-63 ~43 minecraft:air
setblock ~18 ~-63 ~43 minecraft:deepslate_tiles
fill ~19 ~-63 ~43 ~21 ~-63 ~43 minecraft:air
fill ~22 ~-63 ~43 ~23 ~-63 ~43 minecraft:deepslate_tiles
fill ~24 ~-63 ~43 ~44 ~-63 ~43 minecraft:air
fill ~45 ~-63 ~43 ~46 ~-63 ~43 minecraft:deepslate_tiles
fill ~47 ~-63 ~43 ~49 ~-63 ~43 minecraft:air
setblock ~50 ~-63 ~43 minecraft:deepslate_tiles
fill ~51 ~-63 ~43 ~63 ~-63 ~43 minecraft:air
setblock ~64 ~-63 ~43 minecraft:deepslate_tiles
setblock ~4 ~-63 ~44 minecraft:deepslate_tiles
setblock ~5 ~-63 ~44 minecraft:waxed_cut_copper
fill ~6 ~-63 ~44 ~16 ~-63 ~44 minecraft:air
setblock ~17 ~-63 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~44 minecraft:deepslate_tiles
fill ~19 ~-63 ~44 ~22 ~-63 ~44 minecraft:air
fill ~23 ~-63 ~44 ~24 ~-63 ~44 minecraft:deepslate_tiles
fill ~25 ~-63 ~44 ~43 ~-63 ~44 minecraft:air
fill ~44 ~-63 ~44 ~45 ~-63 ~44 minecraft:deepslate_tiles
fill ~46 ~-63 ~44 ~49 ~-63 ~44 minecraft:air
setblock ~50 ~-63 ~44 minecraft:deepslate_tiles
fill ~51 ~-63 ~44 ~63 ~-63 ~44 minecraft:air
setblock ~64 ~-63 ~44 minecraft:deepslate_tiles
setblock ~4 ~-63 ~45 minecraft:deepslate_tiles
fill ~5 ~-63 ~45 ~17 ~-63 ~45 minecraft:air
setblock ~18 ~-63 ~45 minecraft:deepslate_tiles
fill ~19 ~-63 ~45 ~23 ~-63 ~45 minecraft:air
fill ~24 ~-63 ~45 ~25 ~-63 ~45 minecraft:deepslate_tiles
fill ~26 ~-63 ~45 ~42 ~-63 ~45 minecraft:air
fill ~43 ~-63 ~45 ~44 ~-63 ~45 minecraft:deepslate_tiles
fill ~45 ~-63 ~45 ~49 ~-63 ~45 minecraft:air
setblock ~50 ~-63 ~45 minecraft:deepslate_tiles
fill ~51 ~-63 ~45 ~63 ~-63 ~45 minecraft:air
setblock ~64 ~-63 ~45 minecraft:deepslate_tiles
setblock ~4 ~-63 ~46 minecraft:deepslate_tiles
fill ~5 ~-63 ~46 ~17 ~-63 ~46 minecraft:air
setblock ~18 ~-63 ~46 minecraft:deepslate_tiles
fill ~19 ~-63 ~46 ~24 ~-63 ~46 minecraft:air
fill ~25 ~-63 ~46 ~26 ~-63 ~46 minecraft:deepslate_tiles
fill ~27 ~-63 ~46 ~41 ~-63 ~46 minecraft:air
fill ~42 ~-63 ~46 ~43 ~-63 ~46 minecraft:deepslate_tiles
fill ~44 ~-63 ~46 ~49 ~-63 ~46 minecraft:air
setblock ~50 ~-63 ~46 minecraft:deepslate_tiles
fill ~51 ~-63 ~46 ~63 ~-63 ~46 minecraft:air
setblock ~64 ~-63 ~46 minecraft:deepslate_tiles
setblock ~4 ~-63 ~47 minecraft:deepslate_tiles
setblock ~5 ~-63 ~47 minecraft:waxed_cut_copper
fill ~6 ~-63 ~47 ~16 ~-63 ~47 minecraft:air
setblock ~17 ~-63 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~47 minecraft:deepslate_tiles
fill ~19 ~-63 ~47 ~26 ~-63 ~47 minecraft:air
fill ~27 ~-63 ~47 ~28 ~-63 ~47 minecraft:deepslate_tiles
fill ~29 ~-63 ~47 ~39 ~-63 ~47 minecraft:air
fill ~40 ~-63 ~47 ~41 ~-63 ~47 minecraft:deepslate_tiles
fill ~42 ~-63 ~47 ~49 ~-63 ~47 minecraft:air
setblock ~50 ~-63 ~47 minecraft:deepslate_tiles
fill ~51 ~-63 ~47 ~63 ~-63 ~47 minecraft:air
setblock ~64 ~-63 ~47 minecraft:deepslate_tiles
setblock ~4 ~-63 ~48 minecraft:deepslate_tiles
fill ~5 ~-63 ~48 ~17 ~-63 ~48 minecraft:air
setblock ~18 ~-63 ~48 minecraft:deepslate_tiles
fill ~19 ~-63 ~48 ~28 ~-63 ~48 minecraft:air
fill ~29 ~-63 ~48 ~33 ~-63 ~48 minecraft:deepslate_tiles
setblock ~34 ~-63 ~48 minecraft:air
fill ~35 ~-63 ~48 ~39 ~-63 ~48 minecraft:deepslate_tiles
fill ~40 ~-63 ~48 ~49 ~-63 ~48 minecraft:air
setblock ~50 ~-63 ~48 minecraft:deepslate_tiles
fill ~51 ~-63 ~48 ~63 ~-63 ~48 minecraft:air
setblock ~64 ~-63 ~48 minecraft:deepslate_tiles
setblock ~4 ~-63 ~49 minecraft:deepslate_tiles
setblock ~5 ~-63 ~49 minecraft:air
setblock ~6 ~-63 ~49 minecraft:waxed_cut_copper
fill ~7 ~-63 ~49 ~8 ~-63 ~49 minecraft:air
setblock ~9 ~-63 ~49 minecraft:waxed_cut_copper
fill ~10 ~-63 ~49 ~14 ~-63 ~49 minecraft:air
setblock ~15 ~-63 ~49 minecraft:waxed_cut_copper
fill ~16 ~-63 ~49 ~17 ~-63 ~49 minecraft:air
setblock ~18 ~-63 ~49 minecraft:deepslate_tiles
fill ~19 ~-63 ~49 ~31 ~-63 ~49 minecraft:air
setblock ~32 ~-63 ~49 minecraft:deepslate_tiles
setblock ~33 ~-63 ~49 minecraft:air
setblock ~34 ~-63 ~49 minecraft:deepslate_tiles
setblock ~35 ~-63 ~49 minecraft:air
setblock ~36 ~-63 ~49 minecraft:deepslate_tiles
fill ~37 ~-63 ~49 ~49 ~-63 ~49 minecraft:air
setblock ~50 ~-63 ~49 minecraft:deepslate_tiles
fill ~51 ~-63 ~49 ~63 ~-63 ~49 minecraft:air
setblock ~64 ~-63 ~49 minecraft:deepslate_tiles
fill ~4 ~-63 ~50 ~32 ~-63 ~50 minecraft:deepslate_tiles
fill ~33 ~-63 ~50 ~35 ~-63 ~50 minecraft:air
fill ~36 ~-63 ~50 ~64 ~-63 ~50 minecraft:deepslate_tiles
setblock ~4 ~-63 ~51 minecraft:deepslate_tiles
fill ~5 ~-63 ~51 ~9 ~-63 ~51 minecraft:waxed_cut_copper
fill ~10 ~-63 ~51 ~12 ~-63 ~51 minecraft:air
fill ~13 ~-63 ~51 ~17 ~-63 ~51 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~51 minecraft:deepslate_tiles
fill ~19 ~-63 ~51 ~31 ~-63 ~51 minecraft:air
setblock ~32 ~-63 ~51 minecraft:deepslate_tiles
fill ~33 ~-63 ~51 ~35 ~-63 ~51 minecraft:air
setblock ~36 ~-63 ~51 minecraft:deepslate_tiles
fill ~37 ~-63 ~51 ~49 ~-63 ~51 minecraft:air
setblock ~50 ~-63 ~51 minecraft:deepslate_tiles
setblock ~51 ~-63 ~51 minecraft:waxed_cut_copper
fill ~52 ~-63 ~51 ~53 ~-63 ~51 minecraft:air
setblock ~54 ~-63 ~51 minecraft:waxed_cut_copper
fill ~55 ~-63 ~51 ~59 ~-63 ~51 minecraft:air
setblock ~60 ~-63 ~51 minecraft:waxed_cut_copper
fill ~61 ~-63 ~51 ~62 ~-63 ~51 minecraft:air
setblock ~63 ~-63 ~51 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~51 minecraft:deepslate_tiles
setblock ~4 ~-63 ~52 minecraft:deepslate_tiles
setblock ~5 ~-63 ~52 minecraft:waxed_cut_copper
fill ~6 ~-63 ~52 ~16 ~-63 ~52 minecraft:air
setblock ~17 ~-63 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~52 minecraft:deepslate_tiles
fill ~19 ~-63 ~52 ~31 ~-63 ~52 minecraft:air
setblock ~32 ~-63 ~52 minecraft:deepslate_tiles
fill ~33 ~-63 ~52 ~35 ~-63 ~52 minecraft:air
setblock ~36 ~-63 ~52 minecraft:deepslate_tiles
fill ~37 ~-63 ~52 ~49 ~-63 ~52 minecraft:air
setblock ~50 ~-63 ~52 minecraft:deepslate_tiles
fill ~51 ~-63 ~52 ~63 ~-63 ~52 minecraft:air
setblock ~64 ~-63 ~52 minecraft:deepslate_tiles
setblock ~4 ~-63 ~53 minecraft:deepslate_tiles
setblock ~5 ~-63 ~53 minecraft:waxed_cut_copper
fill ~6 ~-63 ~53 ~16 ~-63 ~53 minecraft:air
setblock ~17 ~-63 ~53 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~53 minecraft:deepslate_tiles
fill ~19 ~-63 ~53 ~31 ~-63 ~53 minecraft:air
setblock ~32 ~-63 ~53 minecraft:deepslate_tiles
fill ~33 ~-63 ~53 ~35 ~-63 ~53 minecraft:air
setblock ~36 ~-63 ~53 minecraft:deepslate_tiles
fill ~37 ~-63 ~53 ~49 ~-63 ~53 minecraft:air
setblock ~50 ~-63 ~53 minecraft:deepslate_tiles
fill ~51 ~-63 ~53 ~63 ~-63 ~53 minecraft:air
setblock ~64 ~-63 ~53 minecraft:deepslate_tiles
setblock ~4 ~-63 ~54 minecraft:deepslate_tiles
setblock ~5 ~-63 ~54 minecraft:waxed_cut_copper
fill ~6 ~-63 ~54 ~16 ~-63 ~54 minecraft:air
setblock ~17 ~-63 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~54 minecraft:deepslate_tiles
fill ~19 ~-63 ~54 ~31 ~-63 ~54 minecraft:air
setblock ~32 ~-63 ~54 minecraft:deepslate_tiles
fill ~33 ~-63 ~54 ~35 ~-63 ~54 minecraft:air
setblock ~36 ~-63 ~54 minecraft:deepslate_tiles
fill ~37 ~-63 ~54 ~49 ~-63 ~54 minecraft:air
setblock ~50 ~-63 ~54 minecraft:deepslate_tiles
setblock ~51 ~-63 ~54 minecraft:waxed_cut_copper
fill ~52 ~-63 ~54 ~62 ~-63 ~54 minecraft:air
setblock ~63 ~-63 ~54 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~54 minecraft:deepslate_tiles
setblock ~4 ~-63 ~55 minecraft:deepslate_tiles
setblock ~5 ~-63 ~55 minecraft:waxed_cut_copper
fill ~6 ~-63 ~55 ~16 ~-63 ~55 minecraft:air
setblock ~17 ~-63 ~55 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~55 minecraft:deepslate_tiles
fill ~19 ~-63 ~55 ~31 ~-63 ~55 minecraft:air
setblock ~32 ~-63 ~55 minecraft:deepslate_tiles
fill ~33 ~-63 ~55 ~35 ~-63 ~55 minecraft:air
setblock ~36 ~-63 ~55 minecraft:deepslate_tiles
fill ~37 ~-63 ~55 ~49 ~-63 ~55 minecraft:air
setblock ~50 ~-63 ~55 minecraft:deepslate_tiles
fill ~51 ~-63 ~55 ~63 ~-63 ~55 minecraft:air
setblock ~64 ~-63 ~55 minecraft:deepslate_tiles
setblock ~4 ~-63 ~56 minecraft:deepslate_tiles
setblock ~5 ~-63 ~56 minecraft:waxed_cut_copper
fill ~6 ~-63 ~56 ~17 ~-63 ~56 minecraft:air
setblock ~18 ~-63 ~56 minecraft:deepslate_tiles
fill ~19 ~-63 ~56 ~31 ~-63 ~56 minecraft:air
setblock ~32 ~-63 ~56 minecraft:deepslate_tiles
fill ~33 ~-63 ~56 ~35 ~-63 ~56 minecraft:air
setblock ~36 ~-63 ~56 minecraft:deepslate_tiles
fill ~37 ~-63 ~56 ~49 ~-63 ~56 minecraft:air
setblock ~50 ~-63 ~56 minecraft:deepslate_tiles
fill ~51 ~-63 ~56 ~63 ~-63 ~56 minecraft:air
setblock ~64 ~-63 ~56 minecraft:deepslate_tiles
setblock ~4 ~-63 ~57 minecraft:deepslate_tiles
setblock ~5 ~-63 ~57 minecraft:waxed_cut_copper
fill ~6 ~-63 ~57 ~11 ~-63 ~57 minecraft:air
setblock ~12 ~-63 ~57 minecraft:lightning_rod[facing=up]
fill ~13 ~-63 ~57 ~17 ~-63 ~57 minecraft:air
setblock ~18 ~-63 ~57 minecraft:deepslate_tiles
fill ~19 ~-63 ~57 ~31 ~-63 ~57 minecraft:air
setblock ~32 ~-63 ~57 minecraft:deepslate_tiles
fill ~33 ~-63 ~57 ~35 ~-63 ~57 minecraft:air
setblock ~36 ~-63 ~57 minecraft:deepslate_tiles
fill ~37 ~-63 ~57 ~49 ~-63 ~57 minecraft:air
setblock ~50 ~-63 ~57 minecraft:deepslate_tiles
fill ~51 ~-63 ~57 ~62 ~-63 ~57 minecraft:air
setblock ~63 ~-63 ~57 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~57 minecraft:deepslate_tiles
setblock ~4 ~-63 ~58 minecraft:deepslate_tiles
setblock ~5 ~-63 ~58 minecraft:waxed_cut_copper
fill ~6 ~-63 ~58 ~17 ~-63 ~58 minecraft:air
setblock ~18 ~-63 ~58 minecraft:deepslate_tiles
fill ~19 ~-63 ~58 ~31 ~-63 ~58 minecraft:air
setblock ~32 ~-63 ~58 minecraft:deepslate_tiles
fill ~33 ~-63 ~58 ~35 ~-63 ~58 minecraft:air
setblock ~36 ~-63 ~58 minecraft:deepslate_tiles
fill ~37 ~-63 ~58 ~49 ~-63 ~58 minecraft:air
setblock ~50 ~-63 ~58 minecraft:deepslate_tiles
fill ~51 ~-63 ~58 ~63 ~-63 ~58 minecraft:air
setblock ~64 ~-63 ~58 minecraft:deepslate_tiles
setblock ~4 ~-63 ~59 minecraft:deepslate_tiles
setblock ~5 ~-63 ~59 minecraft:waxed_cut_copper
fill ~6 ~-63 ~59 ~16 ~-63 ~59 minecraft:air
setblock ~17 ~-63 ~59 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~59 minecraft:deepslate_tiles
fill ~19 ~-63 ~59 ~31 ~-63 ~59 minecraft:air
setblock ~32 ~-63 ~59 minecraft:deepslate_tiles
fill ~33 ~-63 ~59 ~35 ~-63 ~59 minecraft:air
setblock ~36 ~-63 ~59 minecraft:deepslate_tiles
fill ~37 ~-63 ~59 ~49 ~-63 ~59 minecraft:air
setblock ~50 ~-63 ~59 minecraft:deepslate_tiles
fill ~51 ~-63 ~59 ~63 ~-63 ~59 minecraft:air
setblock ~64 ~-63 ~59 minecraft:deepslate_tiles
setblock ~4 ~-63 ~60 minecraft:deepslate_tiles
setblock ~5 ~-63 ~60 minecraft:waxed_cut_copper
fill ~6 ~-63 ~60 ~16 ~-63 ~60 minecraft:air
setblock ~17 ~-63 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~60 minecraft:deepslate_tiles
fill ~19 ~-63 ~60 ~31 ~-63 ~60 minecraft:air
setblock ~32 ~-63 ~60 minecraft:deepslate_tiles
fill ~33 ~-63 ~60 ~35 ~-63 ~60 minecraft:air
setblock ~36 ~-63 ~60 minecraft:deepslate_tiles
fill ~37 ~-63 ~60 ~49 ~-63 ~60 minecraft:air
setblock ~50 ~-63 ~60 minecraft:deepslate_tiles
setblock ~51 ~-63 ~60 minecraft:waxed_cut_copper
fill ~52 ~-63 ~60 ~62 ~-63 ~60 minecraft:air
setblock ~63 ~-63 ~60 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~60 minecraft:deepslate_tiles
setblock ~4 ~-63 ~61 minecraft:deepslate_tiles
setblock ~5 ~-63 ~61 minecraft:waxed_cut_copper
fill ~6 ~-63 ~61 ~16 ~-63 ~61 minecraft:air
setblock ~17 ~-63 ~61 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~61 minecraft:deepslate_tiles
fill ~19 ~-63 ~61 ~31 ~-63 ~61 minecraft:air
setblock ~32 ~-63 ~61 minecraft:deepslate_tiles
fill ~33 ~-63 ~61 ~35 ~-63 ~61 minecraft:air
setblock ~36 ~-63 ~61 minecraft:deepslate_tiles
fill ~37 ~-63 ~61 ~49 ~-63 ~61 minecraft:air
setblock ~50 ~-63 ~61 minecraft:deepslate_tiles
fill ~51 ~-63 ~61 ~63 ~-63 ~61 minecraft:air
setblock ~64 ~-63 ~61 minecraft:deepslate_tiles
setblock ~4 ~-63 ~62 minecraft:deepslate_tiles
setblock ~5 ~-63 ~62 minecraft:waxed_cut_copper
fill ~6 ~-63 ~62 ~16 ~-63 ~62 minecraft:air
setblock ~17 ~-63 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~62 minecraft:deepslate_tiles
fill ~19 ~-63 ~62 ~31 ~-63 ~62 minecraft:air
setblock ~32 ~-63 ~62 minecraft:deepslate_tiles
fill ~33 ~-63 ~62 ~35 ~-63 ~62 minecraft:air
setblock ~36 ~-63 ~62 minecraft:deepslate_tiles
fill ~37 ~-63 ~62 ~49 ~-63 ~62 minecraft:air
setblock ~50 ~-63 ~62 minecraft:deepslate_tiles
fill ~51 ~-63 ~62 ~63 ~-63 ~62 minecraft:air
setblock ~64 ~-63 ~62 minecraft:deepslate_tiles
setblock ~4 ~-63 ~63 minecraft:deepslate_tiles
fill ~5 ~-63 ~63 ~17 ~-63 ~63 minecraft:waxed_cut_copper
setblock ~18 ~-63 ~63 minecraft:deepslate_tiles
fill ~19 ~-63 ~63 ~31 ~-63 ~63 minecraft:air
setblock ~32 ~-63 ~63 minecraft:deepslate_tiles
fill ~33 ~-63 ~63 ~35 ~-63 ~63 minecraft:air
setblock ~36 ~-63 ~63 minecraft:deepslate_tiles
fill ~37 ~-63 ~63 ~49 ~-63 ~63 minecraft:air
setblock ~50 ~-63 ~63 minecraft:deepslate_tiles
setblock ~51 ~-63 ~63 minecraft:waxed_cut_copper
fill ~52 ~-63 ~63 ~53 ~-63 ~63 minecraft:air
setblock ~54 ~-63 ~63 minecraft:waxed_cut_copper
fill ~55 ~-63 ~63 ~56 ~-63 ~63 minecraft:air
setblock ~57 ~-63 ~63 minecraft:waxed_cut_copper
fill ~58 ~-63 ~63 ~59 ~-63 ~63 minecraft:air
setblock ~60 ~-63 ~63 minecraft:waxed_cut_copper
fill ~61 ~-63 ~63 ~62 ~-63 ~63 minecraft:air
setblock ~63 ~-63 ~63 minecraft:waxed_cut_copper
setblock ~64 ~-63 ~63 minecraft:deepslate_tiles
fill ~4 ~-63 ~64 ~64 ~-63 ~64 minecraft:deepslate_tiles
fill ~32 ~-63 ~66 ~36 ~-63 ~66 minecraft:polished_andesite
setblock ~32 ~-63 ~67 minecraft:polished_andesite
fill ~33 ~-63 ~67 ~35 ~-63 ~67 minecraft:air
setblock ~36 ~-63 ~67 minecraft:polished_andesite
setblock ~32 ~-63 ~68 minecraft:polished_andesite
setblock ~33 ~-63 ~68 minecraft:air
setblock ~34 ~-63 ~68 minecraft:quartz_pillar
setblock ~35 ~-63 ~68 minecraft:air
setblock ~36 ~-63 ~68 minecraft:polished_andesite
setblock ~32 ~-63 ~69 minecraft:polished_andesite
setblock ~33 ~-63 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-63 ~69 ~35 ~-63 ~69 minecraft:air
setblock ~36 ~-63 ~69 minecraft:polished_andesite
fill ~32 ~-63 ~70 ~36 ~-63 ~70 minecraft:polished_andesite
fill ~4 ~-62 ~4 ~64 ~-62 ~4 minecraft:deepslate_tiles
setblock ~4 ~-62 ~5 minecraft:deepslate_tiles
fill ~5 ~-62 ~5 ~17 ~-62 ~5 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~5 minecraft:deepslate_tiles
fill ~19 ~-62 ~5 ~31 ~-62 ~5 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~5 minecraft:deepslate_tiles
fill ~33 ~-62 ~5 ~35 ~-62 ~5 minecraft:air
setblock ~36 ~-62 ~5 minecraft:deepslate_tiles
setblock ~37 ~-62 ~5 minecraft:waxed_cut_copper
fill ~38 ~-62 ~5 ~39 ~-62 ~5 minecraft:air
setblock ~40 ~-62 ~5 minecraft:waxed_cut_copper
fill ~41 ~-62 ~5 ~42 ~-62 ~5 minecraft:air
setblock ~43 ~-62 ~5 minecraft:waxed_cut_copper
fill ~44 ~-62 ~5 ~45 ~-62 ~5 minecraft:air
setblock ~46 ~-62 ~5 minecraft:waxed_cut_copper
fill ~47 ~-62 ~5 ~48 ~-62 ~5 minecraft:air
setblock ~49 ~-62 ~5 minecraft:waxed_cut_copper
setblock ~50 ~-62 ~5 minecraft:deepslate_tiles
setblock ~51 ~-62 ~5 minecraft:air
setblock ~52 ~-62 ~5 minecraft:waxed_cut_copper
fill ~53 ~-62 ~5 ~54 ~-62 ~5 minecraft:air
setblock ~55 ~-62 ~5 minecraft:waxed_cut_copper
fill ~56 ~-62 ~5 ~57 ~-62 ~5 minecraft:air
setblock ~58 ~-62 ~5 minecraft:waxed_cut_copper
fill ~59 ~-62 ~5 ~60 ~-62 ~5 minecraft:air
setblock ~61 ~-62 ~5 minecraft:waxed_cut_copper
fill ~62 ~-62 ~5 ~63 ~-62 ~5 minecraft:air
setblock ~64 ~-62 ~5 minecraft:deepslate_tiles
setblock ~4 ~-62 ~6 minecraft:deepslate_tiles
setblock ~5 ~-62 ~6 minecraft:waxed_cut_copper
fill ~6 ~-62 ~6 ~16 ~-62 ~6 minecraft:air
setblock ~17 ~-62 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~6 minecraft:deepslate_tiles
setblock ~19 ~-62 ~6 minecraft:waxed_cut_copper
fill ~20 ~-62 ~6 ~30 ~-62 ~6 minecraft:air
setblock ~31 ~-62 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~6 minecraft:deepslate_tiles
fill ~33 ~-62 ~6 ~35 ~-62 ~6 minecraft:air
setblock ~36 ~-62 ~6 minecraft:deepslate_tiles
fill ~37 ~-62 ~6 ~49 ~-62 ~6 minecraft:air
setblock ~50 ~-62 ~6 minecraft:deepslate_tiles
setblock ~51 ~-62 ~6 minecraft:waxed_cut_copper
fill ~52 ~-62 ~6 ~62 ~-62 ~6 minecraft:air
setblock ~63 ~-62 ~6 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~6 minecraft:deepslate_tiles
setblock ~4 ~-62 ~7 minecraft:deepslate_tiles
setblock ~5 ~-62 ~7 minecraft:waxed_cut_copper
fill ~6 ~-62 ~7 ~16 ~-62 ~7 minecraft:air
setblock ~17 ~-62 ~7 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~7 minecraft:deepslate_tiles
setblock ~19 ~-62 ~7 minecraft:waxed_cut_copper
fill ~20 ~-62 ~7 ~30 ~-62 ~7 minecraft:air
setblock ~31 ~-62 ~7 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~7 minecraft:deepslate_tiles
fill ~33 ~-62 ~7 ~35 ~-62 ~7 minecraft:air
setblock ~36 ~-62 ~7 minecraft:deepslate_tiles
fill ~37 ~-62 ~7 ~49 ~-62 ~7 minecraft:air
setblock ~50 ~-62 ~7 minecraft:deepslate_tiles
fill ~51 ~-62 ~7 ~63 ~-62 ~7 minecraft:air
setblock ~64 ~-62 ~7 minecraft:deepslate_tiles
setblock ~4 ~-62 ~8 minecraft:deepslate_tiles
setblock ~5 ~-62 ~8 minecraft:waxed_cut_copper
fill ~6 ~-62 ~8 ~16 ~-62 ~8 minecraft:air
setblock ~17 ~-62 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~8 minecraft:deepslate_tiles
setblock ~19 ~-62 ~8 minecraft:waxed_cut_copper
fill ~20 ~-62 ~8 ~30 ~-62 ~8 minecraft:air
setblock ~31 ~-62 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~8 minecraft:deepslate_tiles
fill ~33 ~-62 ~8 ~35 ~-62 ~8 minecraft:air
setblock ~36 ~-62 ~8 minecraft:deepslate_tiles
setblock ~37 ~-62 ~8 minecraft:waxed_cut_copper
fill ~38 ~-62 ~8 ~48 ~-62 ~8 minecraft:air
setblock ~49 ~-62 ~8 minecraft:waxed_cut_copper
setblock ~50 ~-62 ~8 minecraft:deepslate_tiles
fill ~51 ~-62 ~8 ~63 ~-62 ~8 minecraft:air
setblock ~64 ~-62 ~8 minecraft:deepslate_tiles
setblock ~4 ~-62 ~9 minecraft:deepslate_tiles
setblock ~5 ~-62 ~9 minecraft:waxed_cut_copper
fill ~6 ~-62 ~9 ~16 ~-62 ~9 minecraft:air
setblock ~17 ~-62 ~9 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~9 minecraft:deepslate_tiles
setblock ~19 ~-62 ~9 minecraft:waxed_cut_copper
fill ~20 ~-62 ~9 ~30 ~-62 ~9 minecraft:air
setblock ~31 ~-62 ~9 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~9 minecraft:deepslate_tiles
fill ~33 ~-62 ~9 ~35 ~-62 ~9 minecraft:air
setblock ~36 ~-62 ~9 minecraft:deepslate_tiles
fill ~37 ~-62 ~9 ~49 ~-62 ~9 minecraft:air
setblock ~50 ~-62 ~9 minecraft:deepslate_tiles
setblock ~51 ~-62 ~9 minecraft:waxed_cut_copper
fill ~52 ~-62 ~9 ~62 ~-62 ~9 minecraft:air
setblock ~63 ~-62 ~9 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~9 minecraft:deepslate_tiles
setblock ~4 ~-62 ~10 minecraft:deepslate_tiles
setblock ~5 ~-62 ~10 minecraft:waxed_cut_copper
fill ~6 ~-62 ~10 ~17 ~-62 ~10 minecraft:air
setblock ~18 ~-62 ~10 minecraft:deepslate_tiles
fill ~19 ~-62 ~10 ~31 ~-62 ~10 minecraft:air
setblock ~32 ~-62 ~10 minecraft:deepslate_tiles
fill ~33 ~-62 ~10 ~35 ~-62 ~10 minecraft:air
setblock ~36 ~-62 ~10 minecraft:deepslate_tiles
fill ~37 ~-62 ~10 ~49 ~-62 ~10 minecraft:air
setblock ~50 ~-62 ~10 minecraft:deepslate_tiles
fill ~51 ~-62 ~10 ~63 ~-62 ~10 minecraft:air
setblock ~64 ~-62 ~10 minecraft:deepslate_tiles
setblock ~4 ~-62 ~11 minecraft:deepslate_tiles
setblock ~5 ~-62 ~11 minecraft:waxed_cut_copper
fill ~6 ~-62 ~11 ~17 ~-62 ~11 minecraft:air
setblock ~18 ~-62 ~11 minecraft:deepslate_tiles
fill ~19 ~-62 ~11 ~31 ~-62 ~11 minecraft:air
setblock ~32 ~-62 ~11 minecraft:deepslate_tiles
fill ~33 ~-62 ~11 ~35 ~-62 ~11 minecraft:air
setblock ~36 ~-62 ~11 minecraft:deepslate_tiles
fill ~37 ~-62 ~11 ~49 ~-62 ~11 minecraft:air
setblock ~50 ~-62 ~11 minecraft:deepslate_tiles
fill ~51 ~-62 ~11 ~63 ~-62 ~11 minecraft:air
setblock ~64 ~-62 ~11 minecraft:deepslate_tiles
setblock ~4 ~-62 ~12 minecraft:deepslate_tiles
setblock ~5 ~-62 ~12 minecraft:waxed_cut_copper
fill ~6 ~-62 ~12 ~17 ~-62 ~12 minecraft:air
setblock ~18 ~-62 ~12 minecraft:deepslate_tiles
fill ~19 ~-62 ~12 ~31 ~-62 ~12 minecraft:air
setblock ~32 ~-62 ~12 minecraft:deepslate_tiles
fill ~33 ~-62 ~12 ~35 ~-62 ~12 minecraft:air
setblock ~36 ~-62 ~12 minecraft:deepslate_tiles
fill ~37 ~-62 ~12 ~49 ~-62 ~12 minecraft:air
setblock ~50 ~-62 ~12 minecraft:deepslate_tiles
fill ~51 ~-62 ~12 ~62 ~-62 ~12 minecraft:air
setblock ~63 ~-62 ~12 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~12 minecraft:deepslate_tiles
setblock ~4 ~-62 ~13 minecraft:deepslate_tiles
setblock ~5 ~-62 ~13 minecraft:waxed_cut_copper
fill ~6 ~-62 ~13 ~16 ~-62 ~13 minecraft:air
setblock ~17 ~-62 ~13 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~13 minecraft:deepslate_tiles
setblock ~19 ~-62 ~13 minecraft:waxed_cut_copper
fill ~20 ~-62 ~13 ~30 ~-62 ~13 minecraft:air
setblock ~31 ~-62 ~13 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~13 minecraft:deepslate_tiles
fill ~33 ~-62 ~13 ~35 ~-62 ~13 minecraft:air
setblock ~36 ~-62 ~13 minecraft:deepslate_tiles
fill ~37 ~-62 ~13 ~49 ~-62 ~13 minecraft:air
setblock ~50 ~-62 ~13 minecraft:deepslate_tiles
fill ~51 ~-62 ~13 ~63 ~-62 ~13 minecraft:air
setblock ~64 ~-62 ~13 minecraft:deepslate_tiles
setblock ~4 ~-62 ~14 minecraft:deepslate_tiles
setblock ~5 ~-62 ~14 minecraft:waxed_cut_copper
fill ~6 ~-62 ~14 ~16 ~-62 ~14 minecraft:air
setblock ~17 ~-62 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~14 minecraft:deepslate_tiles
setblock ~19 ~-62 ~14 minecraft:waxed_cut_copper
fill ~20 ~-62 ~14 ~30 ~-62 ~14 minecraft:air
setblock ~31 ~-62 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~14 minecraft:deepslate_tiles
fill ~33 ~-62 ~14 ~35 ~-62 ~14 minecraft:air
setblock ~36 ~-62 ~14 minecraft:deepslate_tiles
setblock ~37 ~-62 ~14 minecraft:waxed_cut_copper
fill ~38 ~-62 ~14 ~48 ~-62 ~14 minecraft:air
setblock ~49 ~-62 ~14 minecraft:waxed_cut_copper
setblock ~50 ~-62 ~14 minecraft:deepslate_tiles
fill ~51 ~-62 ~14 ~63 ~-62 ~14 minecraft:air
setblock ~64 ~-62 ~14 minecraft:deepslate_tiles
setblock ~4 ~-62 ~15 minecraft:deepslate_tiles
setblock ~5 ~-62 ~15 minecraft:waxed_cut_copper
fill ~6 ~-62 ~15 ~16 ~-62 ~15 minecraft:air
setblock ~17 ~-62 ~15 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~15 minecraft:deepslate_tiles
setblock ~19 ~-62 ~15 minecraft:waxed_cut_copper
fill ~20 ~-62 ~15 ~30 ~-62 ~15 minecraft:air
setblock ~31 ~-62 ~15 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~15 minecraft:deepslate_tiles
fill ~33 ~-62 ~15 ~35 ~-62 ~15 minecraft:air
setblock ~36 ~-62 ~15 minecraft:deepslate_tiles
fill ~37 ~-62 ~15 ~49 ~-62 ~15 minecraft:air
setblock ~50 ~-62 ~15 minecraft:deepslate_tiles
setblock ~51 ~-62 ~15 minecraft:waxed_cut_copper
fill ~52 ~-62 ~15 ~62 ~-62 ~15 minecraft:air
setblock ~63 ~-62 ~15 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~15 minecraft:deepslate_tiles
setblock ~4 ~-62 ~16 minecraft:deepslate_tiles
setblock ~5 ~-62 ~16 minecraft:waxed_cut_copper
fill ~6 ~-62 ~16 ~16 ~-62 ~16 minecraft:air
setblock ~17 ~-62 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~16 minecraft:deepslate_tiles
setblock ~19 ~-62 ~16 minecraft:waxed_cut_copper
fill ~20 ~-62 ~16 ~30 ~-62 ~16 minecraft:air
setblock ~31 ~-62 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~16 minecraft:deepslate_tiles
fill ~33 ~-62 ~16 ~35 ~-62 ~16 minecraft:air
setblock ~36 ~-62 ~16 minecraft:deepslate_tiles
fill ~37 ~-62 ~16 ~49 ~-62 ~16 minecraft:air
setblock ~50 ~-62 ~16 minecraft:deepslate_tiles
fill ~51 ~-62 ~16 ~63 ~-62 ~16 minecraft:air
setblock ~64 ~-62 ~16 minecraft:deepslate_tiles
setblock ~4 ~-62 ~17 minecraft:deepslate_tiles
fill ~5 ~-62 ~17 ~9 ~-62 ~17 minecraft:waxed_cut_copper
fill ~10 ~-62 ~17 ~12 ~-62 ~17 minecraft:air
fill ~13 ~-62 ~17 ~17 ~-62 ~17 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~17 minecraft:deepslate_tiles
fill ~19 ~-62 ~17 ~31 ~-62 ~17 minecraft:waxed_cut_copper
setblock ~32 ~-62 ~17 minecraft:deepslate_tiles
fill ~33 ~-62 ~17 ~35 ~-62 ~17 minecraft:air
setblock ~36 ~-62 ~17 minecraft:deepslate_tiles
setblock ~37 ~-62 ~17 minecraft:waxed_cut_copper
fill ~38 ~-62 ~17 ~39 ~-62 ~17 minecraft:air
setblock ~40 ~-62 ~17 minecraft:waxed_cut_copper
fill ~41 ~-62 ~17 ~42 ~-62 ~17 minecraft:air
setblock ~43 ~-62 ~17 minecraft:waxed_cut_copper
fill ~44 ~-62 ~17 ~45 ~-62 ~17 minecraft:air
setblock ~46 ~-62 ~17 minecraft:waxed_cut_copper
fill ~47 ~-62 ~17 ~48 ~-62 ~17 minecraft:air
setblock ~49 ~-62 ~17 minecraft:waxed_cut_copper
setblock ~50 ~-62 ~17 minecraft:deepslate_tiles
setblock ~51 ~-62 ~17 minecraft:air
setblock ~52 ~-62 ~17 minecraft:waxed_cut_copper
fill ~53 ~-62 ~17 ~54 ~-62 ~17 minecraft:air
setblock ~55 ~-62 ~17 minecraft:waxed_cut_copper
fill ~56 ~-62 ~17 ~60 ~-62 ~17 minecraft:air
setblock ~61 ~-62 ~17 minecraft:waxed_cut_copper
fill ~62 ~-62 ~17 ~63 ~-62 ~17 minecraft:air
setblock ~64 ~-62 ~17 minecraft:deepslate_tiles
fill ~4 ~-62 ~18 ~32 ~-62 ~18 minecraft:deepslate_tiles
fill ~33 ~-62 ~18 ~35 ~-62 ~18 minecraft:air
fill ~36 ~-62 ~18 ~64 ~-62 ~18 minecraft:deepslate_tiles
setblock ~4 ~-62 ~19 minecraft:deepslate_tiles
setblock ~5 ~-62 ~19 minecraft:air
setblock ~6 ~-62 ~19 minecraft:waxed_cut_copper
fill ~7 ~-62 ~19 ~8 ~-62 ~19 minecraft:air
setblock ~9 ~-62 ~19 minecraft:waxed_cut_copper
fill ~10 ~-62 ~19 ~14 ~-62 ~19 minecraft:air
setblock ~15 ~-62 ~19 minecraft:waxed_cut_copper
fill ~16 ~-62 ~19 ~17 ~-62 ~19 minecraft:air
setblock ~18 ~-62 ~19 minecraft:deepslate_tiles
fill ~19 ~-62 ~19 ~31 ~-62 ~19 minecraft:air
setblock ~32 ~-62 ~19 minecraft:deepslate_tiles
setblock ~33 ~-62 ~19 minecraft:air
setblock ~34 ~-62 ~19 minecraft:deepslate_tiles
setblock ~35 ~-62 ~19 minecraft:air
setblock ~36 ~-62 ~19 minecraft:deepslate_tiles
fill ~37 ~-62 ~19 ~49 ~-62 ~19 minecraft:air
setblock ~50 ~-62 ~19 minecraft:deepslate_tiles
fill ~51 ~-62 ~19 ~63 ~-62 ~19 minecraft:air
setblock ~64 ~-62 ~19 minecraft:deepslate_tiles
setblock ~4 ~-62 ~20 minecraft:deepslate_tiles
setblock ~5 ~-62 ~20 minecraft:waxed_cut_copper
fill ~6 ~-62 ~20 ~16 ~-62 ~20 minecraft:air
setblock ~17 ~-62 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~20 minecraft:deepslate_tiles
fill ~19 ~-62 ~20 ~28 ~-62 ~20 minecraft:air
fill ~29 ~-62 ~20 ~33 ~-62 ~20 minecraft:deepslate_tiles
setblock ~34 ~-62 ~20 minecraft:air
fill ~35 ~-62 ~20 ~39 ~-62 ~20 minecraft:deepslate_tiles
fill ~40 ~-62 ~20 ~49 ~-62 ~20 minecraft:air
setblock ~50 ~-62 ~20 minecraft:deepslate_tiles
fill ~51 ~-62 ~20 ~63 ~-62 ~20 minecraft:air
setblock ~64 ~-62 ~20 minecraft:deepslate_tiles
setblock ~4 ~-62 ~21 minecraft:deepslate_tiles
fill ~5 ~-62 ~21 ~17 ~-62 ~21 minecraft:air
setblock ~18 ~-62 ~21 minecraft:deepslate_tiles
fill ~19 ~-62 ~21 ~26 ~-62 ~21 minecraft:air
fill ~27 ~-62 ~21 ~28 ~-62 ~21 minecraft:deepslate_tiles
fill ~29 ~-62 ~21 ~39 ~-62 ~21 minecraft:air
fill ~40 ~-62 ~21 ~41 ~-62 ~21 minecraft:deepslate_tiles
fill ~42 ~-62 ~21 ~49 ~-62 ~21 minecraft:air
setblock ~50 ~-62 ~21 minecraft:deepslate_tiles
fill ~51 ~-62 ~21 ~63 ~-62 ~21 minecraft:air
setblock ~64 ~-62 ~21 minecraft:deepslate_tiles
setblock ~4 ~-62 ~22 minecraft:deepslate_tiles
fill ~5 ~-62 ~22 ~17 ~-62 ~22 minecraft:air
setblock ~18 ~-62 ~22 minecraft:deepslate_tiles
fill ~19 ~-62 ~22 ~24 ~-62 ~22 minecraft:air
fill ~25 ~-62 ~22 ~26 ~-62 ~22 minecraft:deepslate_tiles
fill ~27 ~-62 ~22 ~41 ~-62 ~22 minecraft:air
fill ~42 ~-62 ~22 ~43 ~-62 ~22 minecraft:deepslate_tiles
fill ~44 ~-62 ~22 ~49 ~-62 ~22 minecraft:air
setblock ~50 ~-62 ~22 minecraft:deepslate_tiles
fill ~51 ~-62 ~22 ~63 ~-62 ~22 minecraft:air
setblock ~64 ~-62 ~22 minecraft:deepslate_tiles
setblock ~4 ~-62 ~23 minecraft:deepslate_tiles
setblock ~5 ~-62 ~23 minecraft:waxed_cut_copper
fill ~6 ~-62 ~23 ~16 ~-62 ~23 minecraft:air
setblock ~17 ~-62 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~23 minecraft:deepslate_tiles
fill ~19 ~-62 ~23 ~23 ~-62 ~23 minecraft:air
fill ~24 ~-62 ~23 ~25 ~-62 ~23 minecraft:deepslate_tiles
fill ~26 ~-62 ~23 ~42 ~-62 ~23 minecraft:air
fill ~43 ~-62 ~23 ~44 ~-62 ~23 minecraft:deepslate_tiles
fill ~45 ~-62 ~23 ~49 ~-62 ~23 minecraft:air
setblock ~50 ~-62 ~23 minecraft:deepslate_tiles
fill ~51 ~-62 ~23 ~63 ~-62 ~23 minecraft:air
setblock ~64 ~-62 ~23 minecraft:deepslate_tiles
setblock ~4 ~-62 ~24 minecraft:deepslate_tiles
fill ~5 ~-62 ~24 ~17 ~-62 ~24 minecraft:air
setblock ~18 ~-62 ~24 minecraft:deepslate_tiles
fill ~19 ~-62 ~24 ~22 ~-62 ~24 minecraft:air
fill ~23 ~-62 ~24 ~24 ~-62 ~24 minecraft:deepslate_tiles
fill ~25 ~-62 ~24 ~43 ~-62 ~24 minecraft:air
fill ~44 ~-62 ~24 ~45 ~-62 ~24 minecraft:deepslate_tiles
fill ~46 ~-62 ~24 ~49 ~-62 ~24 minecraft:air
setblock ~50 ~-62 ~24 minecraft:deepslate_tiles
fill ~51 ~-62 ~24 ~63 ~-62 ~24 minecraft:air
setblock ~64 ~-62 ~24 minecraft:deepslate_tiles
setblock ~4 ~-62 ~25 minecraft:deepslate_tiles
fill ~5 ~-62 ~25 ~17 ~-62 ~25 minecraft:air
setblock ~18 ~-62 ~25 minecraft:deepslate_tiles
fill ~19 ~-62 ~25 ~21 ~-62 ~25 minecraft:air
fill ~22 ~-62 ~25 ~23 ~-62 ~25 minecraft:deepslate_tiles
fill ~24 ~-62 ~25 ~44 ~-62 ~25 minecraft:air
fill ~45 ~-62 ~25 ~46 ~-62 ~25 minecraft:deepslate_tiles
fill ~47 ~-62 ~25 ~49 ~-62 ~25 minecraft:air
setblock ~50 ~-62 ~25 minecraft:deepslate_tiles
fill ~51 ~-62 ~25 ~63 ~-62 ~25 minecraft:air
setblock ~64 ~-62 ~25 minecraft:deepslate_tiles
setblock ~4 ~-62 ~26 minecraft:deepslate_tiles
setblock ~5 ~-62 ~26 minecraft:waxed_cut_copper
fill ~6 ~-62 ~26 ~16 ~-62 ~26 minecraft:air
setblock ~17 ~-62 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~26 minecraft:deepslate_tiles
fill ~19 ~-62 ~26 ~21 ~-62 ~26 minecraft:air
setblock ~22 ~-62 ~26 minecraft:deepslate_tiles
fill ~23 ~-62 ~26 ~25 ~-62 ~26 minecraft:air
setblock ~26 ~-62 ~26 minecraft:waxed_cut_copper
fill ~27 ~-62 ~26 ~41 ~-62 ~26 minecraft:air
setblock ~42 ~-62 ~26 minecraft:waxed_cut_copper
fill ~43 ~-62 ~26 ~45 ~-62 ~26 minecraft:air
setblock ~46 ~-62 ~26 minecraft:deepslate_tiles
fill ~47 ~-62 ~26 ~49 ~-62 ~26 minecraft:air
setblock ~50 ~-62 ~26 minecraft:deepslate_tiles
fill ~51 ~-62 ~26 ~63 ~-62 ~26 minecraft:air
setblock ~64 ~-62 ~26 minecraft:deepslate_tiles
setblock ~4 ~-62 ~27 minecraft:deepslate_tiles
fill ~5 ~-62 ~27 ~17 ~-62 ~27 minecraft:air
setblock ~18 ~-62 ~27 minecraft:deepslate_tiles
fill ~19 ~-62 ~27 ~20 ~-62 ~27 minecraft:air
setblock ~21 ~-62 ~27 minecraft:deepslate_tiles
fill ~22 ~-62 ~27 ~46 ~-62 ~27 minecraft:air
setblock ~47 ~-62 ~27 minecraft:deepslate_tiles
fill ~48 ~-62 ~27 ~49 ~-62 ~27 minecraft:air
setblock ~50 ~-62 ~27 minecraft:deepslate_tiles
fill ~51 ~-62 ~27 ~63 ~-62 ~27 minecraft:air
setblock ~64 ~-62 ~27 minecraft:deepslate_tiles
setblock ~4 ~-62 ~28 minecraft:deepslate_tiles
fill ~5 ~-62 ~28 ~17 ~-62 ~28 minecraft:air
setblock ~18 ~-62 ~28 minecraft:deepslate_tiles
fill ~19 ~-62 ~28 ~20 ~-62 ~28 minecraft:air
setblock ~21 ~-62 ~28 minecraft:deepslate_tiles
fill ~22 ~-62 ~28 ~46 ~-62 ~28 minecraft:air
setblock ~47 ~-62 ~28 minecraft:deepslate_tiles
fill ~48 ~-62 ~28 ~49 ~-62 ~28 minecraft:air
setblock ~50 ~-62 ~28 minecraft:deepslate_tiles
fill ~51 ~-62 ~28 ~63 ~-62 ~28 minecraft:air
setblock ~64 ~-62 ~28 minecraft:deepslate_tiles
setblock ~4 ~-62 ~29 minecraft:deepslate_tiles
setblock ~5 ~-62 ~29 minecraft:waxed_cut_copper
fill ~6 ~-62 ~29 ~16 ~-62 ~29 minecraft:air
setblock ~17 ~-62 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~29 minecraft:deepslate_tiles
setblock ~19 ~-62 ~29 minecraft:air
setblock ~20 ~-62 ~29 minecraft:deepslate_tiles
fill ~21 ~-62 ~29 ~47 ~-62 ~29 minecraft:air
setblock ~48 ~-62 ~29 minecraft:deepslate_tiles
setblock ~49 ~-62 ~29 minecraft:air
setblock ~50 ~-62 ~29 minecraft:deepslate_tiles
fill ~51 ~-62 ~29 ~63 ~-62 ~29 minecraft:air
setblock ~64 ~-62 ~29 minecraft:deepslate_tiles
setblock ~4 ~-62 ~30 minecraft:deepslate_tiles
fill ~5 ~-62 ~30 ~17 ~-62 ~30 minecraft:air
setblock ~18 ~-62 ~30 minecraft:deepslate_tiles
setblock ~19 ~-62 ~30 minecraft:air
setblock ~20 ~-62 ~30 minecraft:deepslate_tiles
fill ~21 ~-62 ~30 ~47 ~-62 ~30 minecraft:air
setblock ~48 ~-62 ~30 minecraft:deepslate_tiles
setblock ~49 ~-62 ~30 minecraft:air
setblock ~50 ~-62 ~30 minecraft:deepslate_tiles
fill ~51 ~-62 ~30 ~63 ~-62 ~30 minecraft:air
setblock ~64 ~-62 ~30 minecraft:deepslate_tiles
setblock ~4 ~-62 ~31 minecraft:deepslate_tiles
setblock ~5 ~-62 ~31 minecraft:air
setblock ~6 ~-62 ~31 minecraft:waxed_cut_copper
fill ~7 ~-62 ~31 ~8 ~-62 ~31 minecraft:air
setblock ~9 ~-62 ~31 minecraft:waxed_cut_copper
fill ~10 ~-62 ~31 ~14 ~-62 ~31 minecraft:air
setblock ~15 ~-62 ~31 minecraft:waxed_cut_copper
fill ~16 ~-62 ~31 ~17 ~-62 ~31 minecraft:air
setblock ~18 ~-62 ~31 minecraft:deepslate_tiles
setblock ~19 ~-62 ~31 minecraft:air
setblock ~20 ~-62 ~31 minecraft:deepslate_tiles
fill ~21 ~-62 ~31 ~47 ~-62 ~31 minecraft:air
setblock ~48 ~-62 ~31 minecraft:deepslate_tiles
setblock ~49 ~-62 ~31 minecraft:air
setblock ~50 ~-62 ~31 minecraft:deepslate_tiles
fill ~51 ~-62 ~31 ~63 ~-62 ~31 minecraft:air
setblock ~64 ~-62 ~31 minecraft:deepslate_tiles
fill ~4 ~-62 ~32 ~20 ~-62 ~32 minecraft:deepslate_tiles
fill ~21 ~-62 ~32 ~32 ~-62 ~32 minecraft:air
fill ~33 ~-62 ~32 ~35 ~-62 ~32 minecraft:glass
fill ~36 ~-62 ~32 ~47 ~-62 ~32 minecraft:air
fill ~48 ~-62 ~32 ~64 ~-62 ~32 minecraft:deepslate_tiles
setblock ~4 ~-62 ~33 minecraft:deepslate_tiles
fill ~5 ~-62 ~33 ~19 ~-62 ~33 minecraft:air
setblock ~20 ~-62 ~33 minecraft:deepslate_tiles
fill ~21 ~-62 ~33 ~31 ~-62 ~33 minecraft:air
setblock ~32 ~-62 ~33 minecraft:glass
fill ~33 ~-62 ~33 ~35 ~-62 ~33 minecraft:sea_lantern
setblock ~36 ~-62 ~33 minecraft:glass
fill ~37 ~-62 ~33 ~47 ~-62 ~33 minecraft:air
setblock ~48 ~-62 ~33 minecraft:deepslate_tiles
fill ~49 ~-62 ~33 ~63 ~-62 ~33 minecraft:air
setblock ~64 ~-62 ~33 minecraft:deepslate_tiles
setblock ~4 ~-62 ~34 minecraft:deepslate_tiles
fill ~5 ~-62 ~34 ~18 ~-62 ~34 minecraft:air
setblock ~19 ~-62 ~34 minecraft:deepslate_tiles
fill ~20 ~-62 ~34 ~31 ~-62 ~34 minecraft:air
setblock ~32 ~-62 ~34 minecraft:glass
fill ~33 ~-62 ~34 ~35 ~-62 ~34 minecraft:sea_lantern
setblock ~36 ~-62 ~34 minecraft:glass
fill ~37 ~-62 ~34 ~48 ~-62 ~34 minecraft:air
setblock ~49 ~-62 ~34 minecraft:deepslate_tiles
fill ~50 ~-62 ~34 ~63 ~-62 ~34 minecraft:air
setblock ~64 ~-62 ~34 minecraft:deepslate_tiles
setblock ~4 ~-62 ~35 minecraft:deepslate_tiles
fill ~5 ~-62 ~35 ~19 ~-62 ~35 minecraft:air
setblock ~20 ~-62 ~35 minecraft:deepslate_tiles
fill ~21 ~-62 ~35 ~31 ~-62 ~35 minecraft:air
setblock ~32 ~-62 ~35 minecraft:glass
fill ~33 ~-62 ~35 ~35 ~-62 ~35 minecraft:sea_lantern
setblock ~36 ~-62 ~35 minecraft:glass
fill ~37 ~-62 ~35 ~47 ~-62 ~35 minecraft:air
setblock ~48 ~-62 ~35 minecraft:deepslate_tiles
fill ~49 ~-62 ~35 ~63 ~-62 ~35 minecraft:air
setblock ~64 ~-62 ~35 minecraft:deepslate_tiles
fill ~4 ~-62 ~36 ~20 ~-62 ~36 minecraft:deepslate_tiles
fill ~21 ~-62 ~36 ~32 ~-62 ~36 minecraft:air
fill ~33 ~-62 ~36 ~35 ~-62 ~36 minecraft:glass
fill ~36 ~-62 ~36 ~47 ~-62 ~36 minecraft:air
fill ~48 ~-62 ~36 ~64 ~-62 ~36 minecraft:deepslate_tiles
setblock ~4 ~-62 ~37 minecraft:deepslate_tiles
setblock ~5 ~-62 ~37 minecraft:air
setblock ~6 ~-62 ~37 minecraft:waxed_cut_copper
fill ~7 ~-62 ~37 ~8 ~-62 ~37 minecraft:air
setblock ~9 ~-62 ~37 minecraft:waxed_cut_copper
fill ~10 ~-62 ~37 ~14 ~-62 ~37 minecraft:air
setblock ~15 ~-62 ~37 minecraft:waxed_cut_copper
fill ~16 ~-62 ~37 ~17 ~-62 ~37 minecraft:air
setblock ~18 ~-62 ~37 minecraft:deepslate_tiles
setblock ~19 ~-62 ~37 minecraft:air
setblock ~20 ~-62 ~37 minecraft:deepslate_tiles
fill ~21 ~-62 ~37 ~47 ~-62 ~37 minecraft:air
setblock ~48 ~-62 ~37 minecraft:deepslate_tiles
setblock ~49 ~-62 ~37 minecraft:air
setblock ~50 ~-62 ~37 minecraft:deepslate_tiles
fill ~51 ~-62 ~37 ~63 ~-62 ~37 minecraft:air
setblock ~64 ~-62 ~37 minecraft:deepslate_tiles
setblock ~4 ~-62 ~38 minecraft:deepslate_tiles
setblock ~5 ~-62 ~38 minecraft:waxed_cut_copper
fill ~6 ~-62 ~38 ~16 ~-62 ~38 minecraft:air
setblock ~17 ~-62 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~38 minecraft:deepslate_tiles
setblock ~19 ~-62 ~38 minecraft:air
setblock ~20 ~-62 ~38 minecraft:deepslate_tiles
fill ~21 ~-62 ~38 ~47 ~-62 ~38 minecraft:air
setblock ~48 ~-62 ~38 minecraft:deepslate_tiles
setblock ~49 ~-62 ~38 minecraft:air
setblock ~50 ~-62 ~38 minecraft:deepslate_tiles
fill ~51 ~-62 ~38 ~63 ~-62 ~38 minecraft:air
setblock ~64 ~-62 ~38 minecraft:deepslate_tiles
setblock ~4 ~-62 ~39 minecraft:deepslate_tiles
fill ~5 ~-62 ~39 ~17 ~-62 ~39 minecraft:air
setblock ~18 ~-62 ~39 minecraft:deepslate_tiles
setblock ~19 ~-62 ~39 minecraft:air
setblock ~20 ~-62 ~39 minecraft:deepslate_tiles
fill ~21 ~-62 ~39 ~47 ~-62 ~39 minecraft:air
setblock ~48 ~-62 ~39 minecraft:deepslate_tiles
setblock ~49 ~-62 ~39 minecraft:air
setblock ~50 ~-62 ~39 minecraft:deepslate_tiles
fill ~51 ~-62 ~39 ~63 ~-62 ~39 minecraft:air
setblock ~64 ~-62 ~39 minecraft:deepslate_tiles
setblock ~4 ~-62 ~40 minecraft:deepslate_tiles
fill ~5 ~-62 ~40 ~17 ~-62 ~40 minecraft:air
setblock ~18 ~-62 ~40 minecraft:deepslate_tiles
fill ~19 ~-62 ~40 ~20 ~-62 ~40 minecraft:air
setblock ~21 ~-62 ~40 minecraft:deepslate_tiles
fill ~22 ~-62 ~40 ~46 ~-62 ~40 minecraft:air
setblock ~47 ~-62 ~40 minecraft:deepslate_tiles
fill ~48 ~-62 ~40 ~49 ~-62 ~40 minecraft:air
setblock ~50 ~-62 ~40 minecraft:deepslate_tiles
fill ~51 ~-62 ~40 ~63 ~-62 ~40 minecraft:air
setblock ~64 ~-62 ~40 minecraft:deepslate_tiles
setblock ~4 ~-62 ~41 minecraft:deepslate_tiles
setblock ~5 ~-62 ~41 minecraft:waxed_cut_copper
fill ~6 ~-62 ~41 ~16 ~-62 ~41 minecraft:air
setblock ~17 ~-62 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~41 minecraft:deepslate_tiles
fill ~19 ~-62 ~41 ~20 ~-62 ~41 minecraft:air
setblock ~21 ~-62 ~41 minecraft:deepslate_tiles
fill ~22 ~-62 ~41 ~46 ~-62 ~41 minecraft:air
setblock ~47 ~-62 ~41 minecraft:deepslate_tiles
fill ~48 ~-62 ~41 ~49 ~-62 ~41 minecraft:air
setblock ~50 ~-62 ~41 minecraft:deepslate_tiles
fill ~51 ~-62 ~41 ~63 ~-62 ~41 minecraft:air
setblock ~64 ~-62 ~41 minecraft:deepslate_tiles
setblock ~4 ~-62 ~42 minecraft:deepslate_tiles
fill ~5 ~-62 ~42 ~17 ~-62 ~42 minecraft:air
setblock ~18 ~-62 ~42 minecraft:deepslate_tiles
fill ~19 ~-62 ~42 ~21 ~-62 ~42 minecraft:air
setblock ~22 ~-62 ~42 minecraft:deepslate_tiles
fill ~23 ~-62 ~42 ~25 ~-62 ~42 minecraft:air
setblock ~26 ~-62 ~42 minecraft:waxed_cut_copper
fill ~27 ~-62 ~42 ~41 ~-62 ~42 minecraft:air
setblock ~42 ~-62 ~42 minecraft:waxed_cut_copper
fill ~43 ~-62 ~42 ~45 ~-62 ~42 minecraft:air
setblock ~46 ~-62 ~42 minecraft:deepslate_tiles
fill ~47 ~-62 ~42 ~49 ~-62 ~42 minecraft:air
setblock ~50 ~-62 ~42 minecraft:deepslate_tiles
fill ~51 ~-62 ~42 ~63 ~-62 ~42 minecraft:air
setblock ~64 ~-62 ~42 minecraft:deepslate_tiles
setblock ~4 ~-62 ~43 minecraft:deepslate_tiles
fill ~5 ~-62 ~43 ~17 ~-62 ~43 minecraft:air
setblock ~18 ~-62 ~43 minecraft:deepslate_tiles
fill ~19 ~-62 ~43 ~21 ~-62 ~43 minecraft:air
fill ~22 ~-62 ~43 ~23 ~-62 ~43 minecraft:deepslate_tiles
fill ~24 ~-62 ~43 ~44 ~-62 ~43 minecraft:air
fill ~45 ~-62 ~43 ~46 ~-62 ~43 minecraft:deepslate_tiles
fill ~47 ~-62 ~43 ~49 ~-62 ~43 minecraft:air
setblock ~50 ~-62 ~43 minecraft:deepslate_tiles
fill ~51 ~-62 ~43 ~63 ~-62 ~43 minecraft:air
setblock ~64 ~-62 ~43 minecraft:deepslate_tiles
setblock ~4 ~-62 ~44 minecraft:deepslate_tiles
setblock ~5 ~-62 ~44 minecraft:waxed_cut_copper
fill ~6 ~-62 ~44 ~16 ~-62 ~44 minecraft:air
setblock ~17 ~-62 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~44 minecraft:deepslate_tiles
fill ~19 ~-62 ~44 ~22 ~-62 ~44 minecraft:air
fill ~23 ~-62 ~44 ~24 ~-62 ~44 minecraft:deepslate_tiles
fill ~25 ~-62 ~44 ~43 ~-62 ~44 minecraft:air
fill ~44 ~-62 ~44 ~45 ~-62 ~44 minecraft:deepslate_tiles
fill ~46 ~-62 ~44 ~49 ~-62 ~44 minecraft:air
setblock ~50 ~-62 ~44 minecraft:deepslate_tiles
fill ~51 ~-62 ~44 ~63 ~-62 ~44 minecraft:air
setblock ~64 ~-62 ~44 minecraft:deepslate_tiles
setblock ~4 ~-62 ~45 minecraft:deepslate_tiles
fill ~5 ~-62 ~45 ~17 ~-62 ~45 minecraft:air
setblock ~18 ~-62 ~45 minecraft:deepslate_tiles
fill ~19 ~-62 ~45 ~23 ~-62 ~45 minecraft:air
fill ~24 ~-62 ~45 ~25 ~-62 ~45 minecraft:deepslate_tiles
fill ~26 ~-62 ~45 ~42 ~-62 ~45 minecraft:air
fill ~43 ~-62 ~45 ~44 ~-62 ~45 minecraft:deepslate_tiles
fill ~45 ~-62 ~45 ~49 ~-62 ~45 minecraft:air
setblock ~50 ~-62 ~45 minecraft:deepslate_tiles
fill ~51 ~-62 ~45 ~63 ~-62 ~45 minecraft:air
setblock ~64 ~-62 ~45 minecraft:deepslate_tiles
setblock ~4 ~-62 ~46 minecraft:deepslate_tiles
fill ~5 ~-62 ~46 ~17 ~-62 ~46 minecraft:air
setblock ~18 ~-62 ~46 minecraft:deepslate_tiles
fill ~19 ~-62 ~46 ~24 ~-62 ~46 minecraft:air
fill ~25 ~-62 ~46 ~26 ~-62 ~46 minecraft:deepslate_tiles
fill ~27 ~-62 ~46 ~41 ~-62 ~46 minecraft:air
fill ~42 ~-62 ~46 ~43 ~-62 ~46 minecraft:deepslate_tiles
fill ~44 ~-62 ~46 ~49 ~-62 ~46 minecraft:air
setblock ~50 ~-62 ~46 minecraft:deepslate_tiles
fill ~51 ~-62 ~46 ~63 ~-62 ~46 minecraft:air
setblock ~64 ~-62 ~46 minecraft:deepslate_tiles
setblock ~4 ~-62 ~47 minecraft:deepslate_tiles
setblock ~5 ~-62 ~47 minecraft:waxed_cut_copper
fill ~6 ~-62 ~47 ~16 ~-62 ~47 minecraft:air
setblock ~17 ~-62 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~47 minecraft:deepslate_tiles
fill ~19 ~-62 ~47 ~26 ~-62 ~47 minecraft:air
fill ~27 ~-62 ~47 ~28 ~-62 ~47 minecraft:deepslate_tiles
fill ~29 ~-62 ~47 ~39 ~-62 ~47 minecraft:air
fill ~40 ~-62 ~47 ~41 ~-62 ~47 minecraft:deepslate_tiles
fill ~42 ~-62 ~47 ~49 ~-62 ~47 minecraft:air
setblock ~50 ~-62 ~47 minecraft:deepslate_tiles
fill ~51 ~-62 ~47 ~63 ~-62 ~47 minecraft:air
setblock ~64 ~-62 ~47 minecraft:deepslate_tiles
setblock ~4 ~-62 ~48 minecraft:deepslate_tiles
fill ~5 ~-62 ~48 ~17 ~-62 ~48 minecraft:air
setblock ~18 ~-62 ~48 minecraft:deepslate_tiles
fill ~19 ~-62 ~48 ~28 ~-62 ~48 minecraft:air
fill ~29 ~-62 ~48 ~33 ~-62 ~48 minecraft:deepslate_tiles
setblock ~34 ~-62 ~48 minecraft:air
fill ~35 ~-62 ~48 ~39 ~-62 ~48 minecraft:deepslate_tiles
fill ~40 ~-62 ~48 ~49 ~-62 ~48 minecraft:air
setblock ~50 ~-62 ~48 minecraft:deepslate_tiles
fill ~51 ~-62 ~48 ~63 ~-62 ~48 minecraft:air
setblock ~64 ~-62 ~48 minecraft:deepslate_tiles
setblock ~4 ~-62 ~49 minecraft:deepslate_tiles
setblock ~5 ~-62 ~49 minecraft:air
setblock ~6 ~-62 ~49 minecraft:waxed_cut_copper
fill ~7 ~-62 ~49 ~8 ~-62 ~49 minecraft:air
setblock ~9 ~-62 ~49 minecraft:waxed_cut_copper
fill ~10 ~-62 ~49 ~14 ~-62 ~49 minecraft:air
setblock ~15 ~-62 ~49 minecraft:waxed_cut_copper
fill ~16 ~-62 ~49 ~17 ~-62 ~49 minecraft:air
setblock ~18 ~-62 ~49 minecraft:deepslate_tiles
fill ~19 ~-62 ~49 ~31 ~-62 ~49 minecraft:air
setblock ~32 ~-62 ~49 minecraft:deepslate_tiles
setblock ~33 ~-62 ~49 minecraft:air
setblock ~34 ~-62 ~49 minecraft:deepslate_tiles
setblock ~35 ~-62 ~49 minecraft:air
setblock ~36 ~-62 ~49 minecraft:deepslate_tiles
fill ~37 ~-62 ~49 ~49 ~-62 ~49 minecraft:air
setblock ~50 ~-62 ~49 minecraft:deepslate_tiles
fill ~51 ~-62 ~49 ~63 ~-62 ~49 minecraft:air
setblock ~64 ~-62 ~49 minecraft:deepslate_tiles
fill ~4 ~-62 ~50 ~32 ~-62 ~50 minecraft:deepslate_tiles
fill ~33 ~-62 ~50 ~35 ~-62 ~50 minecraft:air
fill ~36 ~-62 ~50 ~64 ~-62 ~50 minecraft:deepslate_tiles
setblock ~4 ~-62 ~51 minecraft:deepslate_tiles
fill ~5 ~-62 ~51 ~9 ~-62 ~51 minecraft:waxed_cut_copper
fill ~10 ~-62 ~51 ~12 ~-62 ~51 minecraft:air
fill ~13 ~-62 ~51 ~17 ~-62 ~51 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~51 minecraft:deepslate_tiles
fill ~19 ~-62 ~51 ~31 ~-62 ~51 minecraft:air
setblock ~32 ~-62 ~51 minecraft:deepslate_tiles
fill ~33 ~-62 ~51 ~35 ~-62 ~51 minecraft:air
setblock ~36 ~-62 ~51 minecraft:deepslate_tiles
fill ~37 ~-62 ~51 ~49 ~-62 ~51 minecraft:air
setblock ~50 ~-62 ~51 minecraft:deepslate_tiles
setblock ~51 ~-62 ~51 minecraft:waxed_cut_copper
fill ~52 ~-62 ~51 ~53 ~-62 ~51 minecraft:air
setblock ~54 ~-62 ~51 minecraft:waxed_cut_copper
fill ~55 ~-62 ~51 ~59 ~-62 ~51 minecraft:air
setblock ~60 ~-62 ~51 minecraft:waxed_cut_copper
fill ~61 ~-62 ~51 ~62 ~-62 ~51 minecraft:air
setblock ~63 ~-62 ~51 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~51 minecraft:deepslate_tiles
setblock ~4 ~-62 ~52 minecraft:deepslate_tiles
setblock ~5 ~-62 ~52 minecraft:waxed_cut_copper
fill ~6 ~-62 ~52 ~16 ~-62 ~52 minecraft:air
setblock ~17 ~-62 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~52 minecraft:deepslate_tiles
fill ~19 ~-62 ~52 ~31 ~-62 ~52 minecraft:air
setblock ~32 ~-62 ~52 minecraft:deepslate_tiles
fill ~33 ~-62 ~52 ~35 ~-62 ~52 minecraft:air
setblock ~36 ~-62 ~52 minecraft:deepslate_tiles
fill ~37 ~-62 ~52 ~49 ~-62 ~52 minecraft:air
setblock ~50 ~-62 ~52 minecraft:deepslate_tiles
fill ~51 ~-62 ~52 ~63 ~-62 ~52 minecraft:air
setblock ~64 ~-62 ~52 minecraft:deepslate_tiles
setblock ~4 ~-62 ~53 minecraft:deepslate_tiles
setblock ~5 ~-62 ~53 minecraft:waxed_cut_copper
fill ~6 ~-62 ~53 ~16 ~-62 ~53 minecraft:air
setblock ~17 ~-62 ~53 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~53 minecraft:deepslate_tiles
fill ~19 ~-62 ~53 ~31 ~-62 ~53 minecraft:air
setblock ~32 ~-62 ~53 minecraft:deepslate_tiles
fill ~33 ~-62 ~53 ~35 ~-62 ~53 minecraft:air
setblock ~36 ~-62 ~53 minecraft:deepslate_tiles
fill ~37 ~-62 ~53 ~49 ~-62 ~53 minecraft:air
setblock ~50 ~-62 ~53 minecraft:deepslate_tiles
fill ~51 ~-62 ~53 ~63 ~-62 ~53 minecraft:air
setblock ~64 ~-62 ~53 minecraft:deepslate_tiles
setblock ~4 ~-62 ~54 minecraft:deepslate_tiles
setblock ~5 ~-62 ~54 minecraft:waxed_cut_copper
fill ~6 ~-62 ~54 ~16 ~-62 ~54 minecraft:air
setblock ~17 ~-62 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~54 minecraft:deepslate_tiles
fill ~19 ~-62 ~54 ~31 ~-62 ~54 minecraft:air
setblock ~32 ~-62 ~54 minecraft:deepslate_tiles
fill ~33 ~-62 ~54 ~35 ~-62 ~54 minecraft:air
setblock ~36 ~-62 ~54 minecraft:deepslate_tiles
fill ~37 ~-62 ~54 ~49 ~-62 ~54 minecraft:air
setblock ~50 ~-62 ~54 minecraft:deepslate_tiles
setblock ~51 ~-62 ~54 minecraft:waxed_cut_copper
fill ~52 ~-62 ~54 ~62 ~-62 ~54 minecraft:air
setblock ~63 ~-62 ~54 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~54 minecraft:deepslate_tiles
setblock ~4 ~-62 ~55 minecraft:deepslate_tiles
setblock ~5 ~-62 ~55 minecraft:waxed_cut_copper
fill ~6 ~-62 ~55 ~16 ~-62 ~55 minecraft:air
setblock ~17 ~-62 ~55 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~55 minecraft:deepslate_tiles
fill ~19 ~-62 ~55 ~31 ~-62 ~55 minecraft:air
setblock ~32 ~-62 ~55 minecraft:deepslate_tiles
fill ~33 ~-62 ~55 ~35 ~-62 ~55 minecraft:air
setblock ~36 ~-62 ~55 minecraft:deepslate_tiles
fill ~37 ~-62 ~55 ~49 ~-62 ~55 minecraft:air
setblock ~50 ~-62 ~55 minecraft:deepslate_tiles
fill ~51 ~-62 ~55 ~63 ~-62 ~55 minecraft:air
setblock ~64 ~-62 ~55 minecraft:deepslate_tiles
setblock ~4 ~-62 ~56 minecraft:deepslate_tiles
setblock ~5 ~-62 ~56 minecraft:waxed_cut_copper
fill ~6 ~-62 ~56 ~17 ~-62 ~56 minecraft:air
setblock ~18 ~-62 ~56 minecraft:deepslate_tiles
fill ~19 ~-62 ~56 ~31 ~-62 ~56 minecraft:air
setblock ~32 ~-62 ~56 minecraft:deepslate_tiles
fill ~33 ~-62 ~56 ~35 ~-62 ~56 minecraft:air
setblock ~36 ~-62 ~56 minecraft:deepslate_tiles
fill ~37 ~-62 ~56 ~49 ~-62 ~56 minecraft:air
setblock ~50 ~-62 ~56 minecraft:deepslate_tiles
fill ~51 ~-62 ~56 ~63 ~-62 ~56 minecraft:air
setblock ~64 ~-62 ~56 minecraft:deepslate_tiles
setblock ~4 ~-62 ~57 minecraft:deepslate_tiles
setblock ~5 ~-62 ~57 minecraft:waxed_cut_copper
fill ~6 ~-62 ~57 ~17 ~-62 ~57 minecraft:air
setblock ~18 ~-62 ~57 minecraft:deepslate_tiles
fill ~19 ~-62 ~57 ~31 ~-62 ~57 minecraft:air
setblock ~32 ~-62 ~57 minecraft:deepslate_tiles
fill ~33 ~-62 ~57 ~35 ~-62 ~57 minecraft:air
setblock ~36 ~-62 ~57 minecraft:deepslate_tiles
fill ~37 ~-62 ~57 ~49 ~-62 ~57 minecraft:air
setblock ~50 ~-62 ~57 minecraft:deepslate_tiles
fill ~51 ~-62 ~57 ~62 ~-62 ~57 minecraft:air
setblock ~63 ~-62 ~57 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~57 minecraft:deepslate_tiles
setblock ~4 ~-62 ~58 minecraft:deepslate_tiles
setblock ~5 ~-62 ~58 minecraft:waxed_cut_copper
fill ~6 ~-62 ~58 ~17 ~-62 ~58 minecraft:air
setblock ~18 ~-62 ~58 minecraft:deepslate_tiles
fill ~19 ~-62 ~58 ~31 ~-62 ~58 minecraft:air
setblock ~32 ~-62 ~58 minecraft:deepslate_tiles
fill ~33 ~-62 ~58 ~35 ~-62 ~58 minecraft:air
setblock ~36 ~-62 ~58 minecraft:deepslate_tiles
fill ~37 ~-62 ~58 ~49 ~-62 ~58 minecraft:air
setblock ~50 ~-62 ~58 minecraft:deepslate_tiles
fill ~51 ~-62 ~58 ~63 ~-62 ~58 minecraft:air
setblock ~64 ~-62 ~58 minecraft:deepslate_tiles
setblock ~4 ~-62 ~59 minecraft:deepslate_tiles
setblock ~5 ~-62 ~59 minecraft:waxed_cut_copper
fill ~6 ~-62 ~59 ~16 ~-62 ~59 minecraft:air
setblock ~17 ~-62 ~59 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~59 minecraft:deepslate_tiles
fill ~19 ~-62 ~59 ~31 ~-62 ~59 minecraft:air
setblock ~32 ~-62 ~59 minecraft:deepslate_tiles
fill ~33 ~-62 ~59 ~35 ~-62 ~59 minecraft:air
setblock ~36 ~-62 ~59 minecraft:deepslate_tiles
fill ~37 ~-62 ~59 ~49 ~-62 ~59 minecraft:air
setblock ~50 ~-62 ~59 minecraft:deepslate_tiles
fill ~51 ~-62 ~59 ~63 ~-62 ~59 minecraft:air
setblock ~64 ~-62 ~59 minecraft:deepslate_tiles
setblock ~4 ~-62 ~60 minecraft:deepslate_tiles
setblock ~5 ~-62 ~60 minecraft:waxed_cut_copper
fill ~6 ~-62 ~60 ~16 ~-62 ~60 minecraft:air
setblock ~17 ~-62 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~60 minecraft:deepslate_tiles
fill ~19 ~-62 ~60 ~31 ~-62 ~60 minecraft:air
setblock ~32 ~-62 ~60 minecraft:deepslate_tiles
fill ~33 ~-62 ~60 ~35 ~-62 ~60 minecraft:air
setblock ~36 ~-62 ~60 minecraft:deepslate_tiles
fill ~37 ~-62 ~60 ~49 ~-62 ~60 minecraft:air
setblock ~50 ~-62 ~60 minecraft:deepslate_tiles
setblock ~51 ~-62 ~60 minecraft:waxed_cut_copper
fill ~52 ~-62 ~60 ~62 ~-62 ~60 minecraft:air
setblock ~63 ~-62 ~60 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~60 minecraft:deepslate_tiles
setblock ~4 ~-62 ~61 minecraft:deepslate_tiles
setblock ~5 ~-62 ~61 minecraft:waxed_cut_copper
fill ~6 ~-62 ~61 ~16 ~-62 ~61 minecraft:air
setblock ~17 ~-62 ~61 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~61 minecraft:deepslate_tiles
fill ~19 ~-62 ~61 ~31 ~-62 ~61 minecraft:air
setblock ~32 ~-62 ~61 minecraft:deepslate_tiles
fill ~33 ~-62 ~61 ~35 ~-62 ~61 minecraft:air
setblock ~36 ~-62 ~61 minecraft:deepslate_tiles
fill ~37 ~-62 ~61 ~49 ~-62 ~61 minecraft:air
setblock ~50 ~-62 ~61 minecraft:deepslate_tiles
fill ~51 ~-62 ~61 ~63 ~-62 ~61 minecraft:air
setblock ~64 ~-62 ~61 minecraft:deepslate_tiles
setblock ~4 ~-62 ~62 minecraft:deepslate_tiles
setblock ~5 ~-62 ~62 minecraft:waxed_cut_copper
fill ~6 ~-62 ~62 ~16 ~-62 ~62 minecraft:air
setblock ~17 ~-62 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~62 minecraft:deepslate_tiles
fill ~19 ~-62 ~62 ~31 ~-62 ~62 minecraft:air
setblock ~32 ~-62 ~62 minecraft:deepslate_tiles
fill ~33 ~-62 ~62 ~35 ~-62 ~62 minecraft:air
setblock ~36 ~-62 ~62 minecraft:deepslate_tiles
fill ~37 ~-62 ~62 ~49 ~-62 ~62 minecraft:air
setblock ~50 ~-62 ~62 minecraft:deepslate_tiles
fill ~51 ~-62 ~62 ~63 ~-62 ~62 minecraft:air
setblock ~64 ~-62 ~62 minecraft:deepslate_tiles
setblock ~4 ~-62 ~63 minecraft:deepslate_tiles
fill ~5 ~-62 ~63 ~17 ~-62 ~63 minecraft:waxed_cut_copper
setblock ~18 ~-62 ~63 minecraft:deepslate_tiles
fill ~19 ~-62 ~63 ~31 ~-62 ~63 minecraft:air
setblock ~32 ~-62 ~63 minecraft:deepslate_tiles
fill ~33 ~-62 ~63 ~35 ~-62 ~63 minecraft:air
setblock ~36 ~-62 ~63 minecraft:deepslate_tiles
fill ~37 ~-62 ~63 ~49 ~-62 ~63 minecraft:air
setblock ~50 ~-62 ~63 minecraft:deepslate_tiles
setblock ~51 ~-62 ~63 minecraft:waxed_cut_copper
fill ~52 ~-62 ~63 ~53 ~-62 ~63 minecraft:air
setblock ~54 ~-62 ~63 minecraft:waxed_cut_copper
fill ~55 ~-62 ~63 ~56 ~-62 ~63 minecraft:air
setblock ~57 ~-62 ~63 minecraft:waxed_cut_copper
fill ~58 ~-62 ~63 ~59 ~-62 ~63 minecraft:air
setblock ~60 ~-62 ~63 minecraft:waxed_cut_copper
fill ~61 ~-62 ~63 ~62 ~-62 ~63 minecraft:air
setblock ~63 ~-62 ~63 minecraft:waxed_cut_copper
setblock ~64 ~-62 ~63 minecraft:deepslate_tiles
fill ~4 ~-62 ~64 ~64 ~-62 ~64 minecraft:deepslate_tiles
fill ~32 ~-62 ~66 ~36 ~-62 ~66 minecraft:polished_andesite
setblock ~32 ~-62 ~67 minecraft:polished_andesite
fill ~33 ~-62 ~67 ~35 ~-62 ~67 minecraft:air
setblock ~36 ~-62 ~67 minecraft:polished_andesite
setblock ~32 ~-62 ~68 minecraft:polished_andesite
setblock ~33 ~-62 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-62 ~68 minecraft:quartz_pillar
setblock ~35 ~-62 ~68 minecraft:air
setblock ~36 ~-62 ~68 minecraft:polished_andesite
setblock ~32 ~-62 ~69 minecraft:polished_andesite
fill ~33 ~-62 ~69 ~35 ~-62 ~69 minecraft:air
setblock ~36 ~-62 ~69 minecraft:polished_andesite
fill ~32 ~-62 ~70 ~36 ~-62 ~70 minecraft:polished_andesite
fill ~4 ~-61 ~4 ~64 ~-61 ~4 minecraft:deepslate_tiles
setblock ~4 ~-61 ~5 minecraft:deepslate_tiles
fill ~5 ~-61 ~5 ~17 ~-61 ~5 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~5 minecraft:deepslate_tiles
fill ~19 ~-61 ~5 ~31 ~-61 ~5 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~5 minecraft:deepslate_tiles
fill ~33 ~-61 ~5 ~35 ~-61 ~5 minecraft:air
setblock ~36 ~-61 ~5 minecraft:deepslate_tiles
setblock ~37 ~-61 ~5 minecraft:waxed_cut_copper
fill ~38 ~-61 ~5 ~39 ~-61 ~5 minecraft:air
setblock ~40 ~-61 ~5 minecraft:waxed_cut_copper
fill ~41 ~-61 ~5 ~42 ~-61 ~5 minecraft:air
setblock ~43 ~-61 ~5 minecraft:waxed_cut_copper
fill ~44 ~-61 ~5 ~45 ~-61 ~5 minecraft:air
setblock ~46 ~-61 ~5 minecraft:waxed_cut_copper
fill ~47 ~-61 ~5 ~48 ~-61 ~5 minecraft:air
setblock ~49 ~-61 ~5 minecraft:waxed_cut_copper
setblock ~50 ~-61 ~5 minecraft:deepslate_tiles
setblock ~51 ~-61 ~5 minecraft:air
setblock ~52 ~-61 ~5 minecraft:waxed_cut_copper
fill ~53 ~-61 ~5 ~54 ~-61 ~5 minecraft:air
setblock ~55 ~-61 ~5 minecraft:waxed_cut_copper
fill ~56 ~-61 ~5 ~57 ~-61 ~5 minecraft:air
setblock ~58 ~-61 ~5 minecraft:waxed_cut_copper
fill ~59 ~-61 ~5 ~60 ~-61 ~5 minecraft:air
setblock ~61 ~-61 ~5 minecraft:waxed_cut_copper
fill ~62 ~-61 ~5 ~63 ~-61 ~5 minecraft:air
setblock ~64 ~-61 ~5 minecraft:deepslate_tiles
setblock ~4 ~-61 ~6 minecraft:deepslate_tiles
setblock ~5 ~-61 ~6 minecraft:waxed_cut_copper
fill ~6 ~-61 ~6 ~16 ~-61 ~6 minecraft:air
setblock ~17 ~-61 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~6 minecraft:deepslate_tiles
setblock ~19 ~-61 ~6 minecraft:waxed_cut_copper
fill ~20 ~-61 ~6 ~30 ~-61 ~6 minecraft:air
setblock ~31 ~-61 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~6 minecraft:deepslate_tiles
fill ~33 ~-61 ~6 ~35 ~-61 ~6 minecraft:air
setblock ~36 ~-61 ~6 minecraft:deepslate_tiles
fill ~37 ~-61 ~6 ~49 ~-61 ~6 minecraft:air
setblock ~50 ~-61 ~6 minecraft:deepslate_tiles
setblock ~51 ~-61 ~6 minecraft:waxed_cut_copper
fill ~52 ~-61 ~6 ~62 ~-61 ~6 minecraft:air
setblock ~63 ~-61 ~6 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~6 minecraft:deepslate_tiles
setblock ~4 ~-61 ~7 minecraft:deepslate_tiles
setblock ~5 ~-61 ~7 minecraft:waxed_cut_copper
fill ~6 ~-61 ~7 ~16 ~-61 ~7 minecraft:air
setblock ~17 ~-61 ~7 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~7 minecraft:deepslate_tiles
setblock ~19 ~-61 ~7 minecraft:waxed_cut_copper
fill ~20 ~-61 ~7 ~30 ~-61 ~7 minecraft:air
setblock ~31 ~-61 ~7 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~7 minecraft:deepslate_tiles
fill ~33 ~-61 ~7 ~35 ~-61 ~7 minecraft:air
setblock ~36 ~-61 ~7 minecraft:deepslate_tiles
fill ~37 ~-61 ~7 ~49 ~-61 ~7 minecraft:air
setblock ~50 ~-61 ~7 minecraft:deepslate_tiles
fill ~51 ~-61 ~7 ~63 ~-61 ~7 minecraft:air
setblock ~64 ~-61 ~7 minecraft:deepslate_tiles
setblock ~4 ~-61 ~8 minecraft:deepslate_tiles
setblock ~5 ~-61 ~8 minecraft:waxed_cut_copper
fill ~6 ~-61 ~8 ~16 ~-61 ~8 minecraft:air
setblock ~17 ~-61 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~8 minecraft:deepslate_tiles
setblock ~19 ~-61 ~8 minecraft:waxed_cut_copper
fill ~20 ~-61 ~8 ~30 ~-61 ~8 minecraft:air
setblock ~31 ~-61 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~8 minecraft:deepslate_tiles
fill ~33 ~-61 ~8 ~35 ~-61 ~8 minecraft:air
setblock ~36 ~-61 ~8 minecraft:deepslate_tiles
setblock ~37 ~-61 ~8 minecraft:waxed_cut_copper
fill ~38 ~-61 ~8 ~48 ~-61 ~8 minecraft:air
setblock ~49 ~-61 ~8 minecraft:waxed_cut_copper
setblock ~50 ~-61 ~8 minecraft:deepslate_tiles
fill ~51 ~-61 ~8 ~63 ~-61 ~8 minecraft:air
setblock ~64 ~-61 ~8 minecraft:deepslate_tiles
setblock ~4 ~-61 ~9 minecraft:deepslate_tiles
setblock ~5 ~-61 ~9 minecraft:waxed_cut_copper
fill ~6 ~-61 ~9 ~16 ~-61 ~9 minecraft:air
setblock ~17 ~-61 ~9 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~9 minecraft:deepslate_tiles
setblock ~19 ~-61 ~9 minecraft:waxed_cut_copper
fill ~20 ~-61 ~9 ~30 ~-61 ~9 minecraft:air
setblock ~31 ~-61 ~9 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~9 minecraft:deepslate_tiles
fill ~33 ~-61 ~9 ~35 ~-61 ~9 minecraft:air
setblock ~36 ~-61 ~9 minecraft:deepslate_tiles
fill ~37 ~-61 ~9 ~49 ~-61 ~9 minecraft:air
setblock ~50 ~-61 ~9 minecraft:deepslate_tiles
setblock ~51 ~-61 ~9 minecraft:waxed_cut_copper
fill ~52 ~-61 ~9 ~62 ~-61 ~9 minecraft:air
setblock ~63 ~-61 ~9 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~9 minecraft:deepslate_tiles
setblock ~4 ~-61 ~10 minecraft:deepslate_tiles
setblock ~5 ~-61 ~10 minecraft:waxed_cut_copper
fill ~6 ~-61 ~10 ~17 ~-61 ~10 minecraft:air
setblock ~18 ~-61 ~10 minecraft:deepslate_tiles
fill ~19 ~-61 ~10 ~31 ~-61 ~10 minecraft:air
setblock ~32 ~-61 ~10 minecraft:deepslate_tiles
fill ~33 ~-61 ~10 ~35 ~-61 ~10 minecraft:air
setblock ~36 ~-61 ~10 minecraft:deepslate_tiles
fill ~37 ~-61 ~10 ~49 ~-61 ~10 minecraft:air
setblock ~50 ~-61 ~10 minecraft:deepslate_tiles
fill ~51 ~-61 ~10 ~63 ~-61 ~10 minecraft:air
setblock ~64 ~-61 ~10 minecraft:deepslate_tiles
setblock ~4 ~-61 ~11 minecraft:deepslate_tiles
setblock ~5 ~-61 ~11 minecraft:waxed_cut_copper
fill ~6 ~-61 ~11 ~17 ~-61 ~11 minecraft:air
setblock ~18 ~-61 ~11 minecraft:deepslate_tiles
fill ~19 ~-61 ~11 ~31 ~-61 ~11 minecraft:air
setblock ~32 ~-61 ~11 minecraft:deepslate_tiles
fill ~33 ~-61 ~11 ~35 ~-61 ~11 minecraft:air
setblock ~36 ~-61 ~11 minecraft:deepslate_tiles
fill ~37 ~-61 ~11 ~49 ~-61 ~11 minecraft:air
setblock ~50 ~-61 ~11 minecraft:deepslate_tiles
fill ~51 ~-61 ~11 ~63 ~-61 ~11 minecraft:air
setblock ~64 ~-61 ~11 minecraft:deepslate_tiles
setblock ~4 ~-61 ~12 minecraft:deepslate_tiles
setblock ~5 ~-61 ~12 minecraft:waxed_cut_copper
fill ~6 ~-61 ~12 ~17 ~-61 ~12 minecraft:air
setblock ~18 ~-61 ~12 minecraft:deepslate_tiles
fill ~19 ~-61 ~12 ~31 ~-61 ~12 minecraft:air
setblock ~32 ~-61 ~12 minecraft:deepslate_tiles
fill ~33 ~-61 ~12 ~35 ~-61 ~12 minecraft:air
setblock ~36 ~-61 ~12 minecraft:deepslate_tiles
fill ~37 ~-61 ~12 ~49 ~-61 ~12 minecraft:air
setblock ~50 ~-61 ~12 minecraft:deepslate_tiles
fill ~51 ~-61 ~12 ~62 ~-61 ~12 minecraft:air
setblock ~63 ~-61 ~12 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~12 minecraft:deepslate_tiles
setblock ~4 ~-61 ~13 minecraft:deepslate_tiles
setblock ~5 ~-61 ~13 minecraft:waxed_cut_copper
fill ~6 ~-61 ~13 ~16 ~-61 ~13 minecraft:air
setblock ~17 ~-61 ~13 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~13 minecraft:deepslate_tiles
setblock ~19 ~-61 ~13 minecraft:waxed_cut_copper
fill ~20 ~-61 ~13 ~30 ~-61 ~13 minecraft:air
setblock ~31 ~-61 ~13 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~13 minecraft:deepslate_tiles
fill ~33 ~-61 ~13 ~35 ~-61 ~13 minecraft:air
setblock ~36 ~-61 ~13 minecraft:deepslate_tiles
fill ~37 ~-61 ~13 ~49 ~-61 ~13 minecraft:air
setblock ~50 ~-61 ~13 minecraft:deepslate_tiles
fill ~51 ~-61 ~13 ~63 ~-61 ~13 minecraft:air
setblock ~64 ~-61 ~13 minecraft:deepslate_tiles
setblock ~4 ~-61 ~14 minecraft:deepslate_tiles
setblock ~5 ~-61 ~14 minecraft:waxed_cut_copper
fill ~6 ~-61 ~14 ~16 ~-61 ~14 minecraft:air
setblock ~17 ~-61 ~14 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~14 minecraft:deepslate_tiles
setblock ~19 ~-61 ~14 minecraft:waxed_cut_copper
fill ~20 ~-61 ~14 ~30 ~-61 ~14 minecraft:air
setblock ~31 ~-61 ~14 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~14 minecraft:deepslate_tiles
fill ~33 ~-61 ~14 ~35 ~-61 ~14 minecraft:air
setblock ~36 ~-61 ~14 minecraft:deepslate_tiles
setblock ~37 ~-61 ~14 minecraft:waxed_cut_copper
fill ~38 ~-61 ~14 ~48 ~-61 ~14 minecraft:air
setblock ~49 ~-61 ~14 minecraft:waxed_cut_copper
setblock ~50 ~-61 ~14 minecraft:deepslate_tiles
fill ~51 ~-61 ~14 ~63 ~-61 ~14 minecraft:air
setblock ~64 ~-61 ~14 minecraft:deepslate_tiles
setblock ~4 ~-61 ~15 minecraft:deepslate_tiles
setblock ~5 ~-61 ~15 minecraft:waxed_cut_copper
fill ~6 ~-61 ~15 ~16 ~-61 ~15 minecraft:air
setblock ~17 ~-61 ~15 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~15 minecraft:deepslate_tiles
setblock ~19 ~-61 ~15 minecraft:waxed_cut_copper
fill ~20 ~-61 ~15 ~30 ~-61 ~15 minecraft:air
setblock ~31 ~-61 ~15 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~15 minecraft:deepslate_tiles
fill ~33 ~-61 ~15 ~35 ~-61 ~15 minecraft:air
setblock ~36 ~-61 ~15 minecraft:deepslate_tiles
fill ~37 ~-61 ~15 ~49 ~-61 ~15 minecraft:air
setblock ~50 ~-61 ~15 minecraft:deepslate_tiles
setblock ~51 ~-61 ~15 minecraft:waxed_cut_copper
fill ~52 ~-61 ~15 ~62 ~-61 ~15 minecraft:air
setblock ~63 ~-61 ~15 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~15 minecraft:deepslate_tiles
setblock ~4 ~-61 ~16 minecraft:deepslate_tiles
setblock ~5 ~-61 ~16 minecraft:waxed_cut_copper
fill ~6 ~-61 ~16 ~16 ~-61 ~16 minecraft:air
setblock ~17 ~-61 ~16 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~16 minecraft:deepslate_tiles
setblock ~19 ~-61 ~16 minecraft:waxed_cut_copper
fill ~20 ~-61 ~16 ~30 ~-61 ~16 minecraft:air
setblock ~31 ~-61 ~16 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~16 minecraft:deepslate_tiles
fill ~33 ~-61 ~16 ~35 ~-61 ~16 minecraft:air
setblock ~36 ~-61 ~16 minecraft:deepslate_tiles
fill ~37 ~-61 ~16 ~49 ~-61 ~16 minecraft:air
setblock ~50 ~-61 ~16 minecraft:deepslate_tiles
fill ~51 ~-61 ~16 ~63 ~-61 ~16 minecraft:air
setblock ~64 ~-61 ~16 minecraft:deepslate_tiles
setblock ~4 ~-61 ~17 minecraft:deepslate_tiles
fill ~5 ~-61 ~17 ~9 ~-61 ~17 minecraft:waxed_cut_copper
fill ~10 ~-61 ~17 ~12 ~-61 ~17 minecraft:air
fill ~13 ~-61 ~17 ~17 ~-61 ~17 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~17 minecraft:deepslate_tiles
fill ~19 ~-61 ~17 ~31 ~-61 ~17 minecraft:waxed_cut_copper
setblock ~32 ~-61 ~17 minecraft:deepslate_tiles
fill ~33 ~-61 ~17 ~35 ~-61 ~17 minecraft:air
setblock ~36 ~-61 ~17 minecraft:deepslate_tiles
setblock ~37 ~-61 ~17 minecraft:waxed_cut_copper
fill ~38 ~-61 ~17 ~39 ~-61 ~17 minecraft:air
setblock ~40 ~-61 ~17 minecraft:waxed_cut_copper
fill ~41 ~-61 ~17 ~42 ~-61 ~17 minecraft:air
setblock ~43 ~-61 ~17 minecraft:waxed_cut_copper
fill ~44 ~-61 ~17 ~45 ~-61 ~17 minecraft:air
setblock ~46 ~-61 ~17 minecraft:waxed_cut_copper
fill ~47 ~-61 ~17 ~48 ~-61 ~17 minecraft:air
setblock ~49 ~-61 ~17 minecraft:waxed_cut_copper
setblock ~50 ~-61 ~17 minecraft:deepslate_tiles
setblock ~51 ~-61 ~17 minecraft:air
setblock ~52 ~-61 ~17 minecraft:waxed_cut_copper
fill ~53 ~-61 ~17 ~54 ~-61 ~17 minecraft:air
setblock ~55 ~-61 ~17 minecraft:waxed_cut_copper
fill ~56 ~-61 ~17 ~60 ~-61 ~17 minecraft:air
setblock ~61 ~-61 ~17 minecraft:waxed_cut_copper
fill ~62 ~-61 ~17 ~63 ~-61 ~17 minecraft:air
setblock ~64 ~-61 ~17 minecraft:deepslate_tiles
fill ~4 ~-61 ~18 ~32 ~-61 ~18 minecraft:deepslate_tiles
fill ~33 ~-61 ~18 ~35 ~-61 ~18 minecraft:air
fill ~36 ~-61 ~18 ~64 ~-61 ~18 minecraft:deepslate_tiles
setblock ~4 ~-61 ~19 minecraft:deepslate_tiles
setblock ~5 ~-61 ~19 minecraft:air
setblock ~6 ~-61 ~19 minecraft:waxed_cut_copper
fill ~7 ~-61 ~19 ~8 ~-61 ~19 minecraft:air
setblock ~9 ~-61 ~19 minecraft:waxed_cut_copper
fill ~10 ~-61 ~19 ~14 ~-61 ~19 minecraft:air
setblock ~15 ~-61 ~19 minecraft:waxed_cut_copper
fill ~16 ~-61 ~19 ~17 ~-61 ~19 minecraft:air
setblock ~18 ~-61 ~19 minecraft:deepslate_tiles
fill ~19 ~-61 ~19 ~31 ~-61 ~19 minecraft:air
setblock ~32 ~-61 ~19 minecraft:deepslate_tiles
setblock ~33 ~-61 ~19 minecraft:air
setblock ~34 ~-61 ~19 minecraft:deepslate_tiles
setblock ~35 ~-61 ~19 minecraft:air
setblock ~36 ~-61 ~19 minecraft:deepslate_tiles
fill ~37 ~-61 ~19 ~49 ~-61 ~19 minecraft:air
setblock ~50 ~-61 ~19 minecraft:deepslate_tiles
fill ~51 ~-61 ~19 ~63 ~-61 ~19 minecraft:air
setblock ~64 ~-61 ~19 minecraft:deepslate_tiles
setblock ~4 ~-61 ~20 minecraft:deepslate_tiles
setblock ~5 ~-61 ~20 minecraft:waxed_cut_copper
fill ~6 ~-61 ~20 ~16 ~-61 ~20 minecraft:air
setblock ~17 ~-61 ~20 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~20 minecraft:deepslate_tiles
fill ~19 ~-61 ~20 ~28 ~-61 ~20 minecraft:air
fill ~29 ~-61 ~20 ~33 ~-61 ~20 minecraft:deepslate_tiles
setblock ~34 ~-61 ~20 minecraft:air
fill ~35 ~-61 ~20 ~39 ~-61 ~20 minecraft:deepslate_tiles
fill ~40 ~-61 ~20 ~49 ~-61 ~20 minecraft:air
setblock ~50 ~-61 ~20 minecraft:deepslate_tiles
fill ~51 ~-61 ~20 ~63 ~-61 ~20 minecraft:air
setblock ~64 ~-61 ~20 minecraft:deepslate_tiles
setblock ~4 ~-61 ~21 minecraft:deepslate_tiles
fill ~5 ~-61 ~21 ~17 ~-61 ~21 minecraft:air
setblock ~18 ~-61 ~21 minecraft:deepslate_tiles
fill ~19 ~-61 ~21 ~26 ~-61 ~21 minecraft:air
fill ~27 ~-61 ~21 ~28 ~-61 ~21 minecraft:deepslate_tiles
fill ~29 ~-61 ~21 ~39 ~-61 ~21 minecraft:air
fill ~40 ~-61 ~21 ~41 ~-61 ~21 minecraft:deepslate_tiles
fill ~42 ~-61 ~21 ~49 ~-61 ~21 minecraft:air
setblock ~50 ~-61 ~21 minecraft:deepslate_tiles
fill ~51 ~-61 ~21 ~63 ~-61 ~21 minecraft:air
setblock ~64 ~-61 ~21 minecraft:deepslate_tiles
setblock ~4 ~-61 ~22 minecraft:deepslate_tiles
fill ~5 ~-61 ~22 ~17 ~-61 ~22 minecraft:air
setblock ~18 ~-61 ~22 minecraft:deepslate_tiles
fill ~19 ~-61 ~22 ~24 ~-61 ~22 minecraft:air
fill ~25 ~-61 ~22 ~26 ~-61 ~22 minecraft:deepslate_tiles
fill ~27 ~-61 ~22 ~41 ~-61 ~22 minecraft:air
fill ~42 ~-61 ~22 ~43 ~-61 ~22 minecraft:deepslate_tiles
fill ~44 ~-61 ~22 ~49 ~-61 ~22 minecraft:air
setblock ~50 ~-61 ~22 minecraft:deepslate_tiles
fill ~51 ~-61 ~22 ~63 ~-61 ~22 minecraft:air
setblock ~64 ~-61 ~22 minecraft:deepslate_tiles
setblock ~4 ~-61 ~23 minecraft:deepslate_tiles
setblock ~5 ~-61 ~23 minecraft:waxed_cut_copper
fill ~6 ~-61 ~23 ~16 ~-61 ~23 minecraft:air
setblock ~17 ~-61 ~23 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~23 minecraft:deepslate_tiles
fill ~19 ~-61 ~23 ~23 ~-61 ~23 minecraft:air
fill ~24 ~-61 ~23 ~25 ~-61 ~23 minecraft:deepslate_tiles
fill ~26 ~-61 ~23 ~42 ~-61 ~23 minecraft:air
fill ~43 ~-61 ~23 ~44 ~-61 ~23 minecraft:deepslate_tiles
fill ~45 ~-61 ~23 ~49 ~-61 ~23 minecraft:air
setblock ~50 ~-61 ~23 minecraft:deepslate_tiles
fill ~51 ~-61 ~23 ~63 ~-61 ~23 minecraft:air
setblock ~64 ~-61 ~23 minecraft:deepslate_tiles
setblock ~4 ~-61 ~24 minecraft:deepslate_tiles
fill ~5 ~-61 ~24 ~17 ~-61 ~24 minecraft:air
setblock ~18 ~-61 ~24 minecraft:deepslate_tiles
fill ~19 ~-61 ~24 ~22 ~-61 ~24 minecraft:air
fill ~23 ~-61 ~24 ~24 ~-61 ~24 minecraft:deepslate_tiles
fill ~25 ~-61 ~24 ~43 ~-61 ~24 minecraft:air
fill ~44 ~-61 ~24 ~45 ~-61 ~24 minecraft:deepslate_tiles
fill ~46 ~-61 ~24 ~49 ~-61 ~24 minecraft:air
setblock ~50 ~-61 ~24 minecraft:deepslate_tiles
fill ~51 ~-61 ~24 ~63 ~-61 ~24 minecraft:air
setblock ~64 ~-61 ~24 minecraft:deepslate_tiles
setblock ~4 ~-61 ~25 minecraft:deepslate_tiles
fill ~5 ~-61 ~25 ~17 ~-61 ~25 minecraft:air
setblock ~18 ~-61 ~25 minecraft:deepslate_tiles
fill ~19 ~-61 ~25 ~21 ~-61 ~25 minecraft:air
fill ~22 ~-61 ~25 ~23 ~-61 ~25 minecraft:deepslate_tiles
fill ~24 ~-61 ~25 ~44 ~-61 ~25 minecraft:air
fill ~45 ~-61 ~25 ~46 ~-61 ~25 minecraft:deepslate_tiles
fill ~47 ~-61 ~25 ~49 ~-61 ~25 minecraft:air
setblock ~50 ~-61 ~25 minecraft:deepslate_tiles
fill ~51 ~-61 ~25 ~63 ~-61 ~25 minecraft:air
setblock ~64 ~-61 ~25 minecraft:deepslate_tiles
setblock ~4 ~-61 ~26 minecraft:deepslate_tiles
setblock ~5 ~-61 ~26 minecraft:waxed_cut_copper
fill ~6 ~-61 ~26 ~16 ~-61 ~26 minecraft:air
setblock ~17 ~-61 ~26 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~26 minecraft:deepslate_tiles
fill ~19 ~-61 ~26 ~21 ~-61 ~26 minecraft:air
setblock ~22 ~-61 ~26 minecraft:deepslate_tiles
fill ~23 ~-61 ~26 ~25 ~-61 ~26 minecraft:air
setblock ~26 ~-61 ~26 minecraft:waxed_cut_copper
fill ~27 ~-61 ~26 ~41 ~-61 ~26 minecraft:air
setblock ~42 ~-61 ~26 minecraft:waxed_cut_copper
fill ~43 ~-61 ~26 ~45 ~-61 ~26 minecraft:air
setblock ~46 ~-61 ~26 minecraft:deepslate_tiles
fill ~47 ~-61 ~26 ~49 ~-61 ~26 minecraft:air
setblock ~50 ~-61 ~26 minecraft:deepslate_tiles
fill ~51 ~-61 ~26 ~63 ~-61 ~26 minecraft:air
setblock ~64 ~-61 ~26 minecraft:deepslate_tiles
setblock ~4 ~-61 ~27 minecraft:deepslate_tiles
fill ~5 ~-61 ~27 ~17 ~-61 ~27 minecraft:air
setblock ~18 ~-61 ~27 minecraft:deepslate_tiles
fill ~19 ~-61 ~27 ~20 ~-61 ~27 minecraft:air
setblock ~21 ~-61 ~27 minecraft:deepslate_tiles
fill ~22 ~-61 ~27 ~46 ~-61 ~27 minecraft:air
setblock ~47 ~-61 ~27 minecraft:deepslate_tiles
fill ~48 ~-61 ~27 ~49 ~-61 ~27 minecraft:air
setblock ~50 ~-61 ~27 minecraft:deepslate_tiles
fill ~51 ~-61 ~27 ~63 ~-61 ~27 minecraft:air
setblock ~64 ~-61 ~27 minecraft:deepslate_tiles
setblock ~4 ~-61 ~28 minecraft:deepslate_tiles
fill ~5 ~-61 ~28 ~17 ~-61 ~28 minecraft:air
setblock ~18 ~-61 ~28 minecraft:deepslate_tiles
fill ~19 ~-61 ~28 ~20 ~-61 ~28 minecraft:air
setblock ~21 ~-61 ~28 minecraft:deepslate_tiles
fill ~22 ~-61 ~28 ~46 ~-61 ~28 minecraft:air
setblock ~47 ~-61 ~28 minecraft:deepslate_tiles
fill ~48 ~-61 ~28 ~49 ~-61 ~28 minecraft:air
setblock ~50 ~-61 ~28 minecraft:deepslate_tiles
fill ~51 ~-61 ~28 ~63 ~-61 ~28 minecraft:air
setblock ~64 ~-61 ~28 minecraft:deepslate_tiles
setblock ~4 ~-61 ~29 minecraft:deepslate_tiles
setblock ~5 ~-61 ~29 minecraft:waxed_cut_copper
fill ~6 ~-61 ~29 ~16 ~-61 ~29 minecraft:air
setblock ~17 ~-61 ~29 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~29 minecraft:deepslate_tiles
setblock ~19 ~-61 ~29 minecraft:air
setblock ~20 ~-61 ~29 minecraft:deepslate_tiles
fill ~21 ~-61 ~29 ~47 ~-61 ~29 minecraft:air
setblock ~48 ~-61 ~29 minecraft:deepslate_tiles
setblock ~49 ~-61 ~29 minecraft:air
setblock ~50 ~-61 ~29 minecraft:deepslate_tiles
fill ~51 ~-61 ~29 ~63 ~-61 ~29 minecraft:air
setblock ~64 ~-61 ~29 minecraft:deepslate_tiles
setblock ~4 ~-61 ~30 minecraft:deepslate_tiles
fill ~5 ~-61 ~30 ~17 ~-61 ~30 minecraft:air
setblock ~18 ~-61 ~30 minecraft:deepslate_tiles
setblock ~19 ~-61 ~30 minecraft:air
setblock ~20 ~-61 ~30 minecraft:deepslate_tiles
fill ~21 ~-61 ~30 ~47 ~-61 ~30 minecraft:air
setblock ~48 ~-61 ~30 minecraft:deepslate_tiles
setblock ~49 ~-61 ~30 minecraft:air
setblock ~50 ~-61 ~30 minecraft:deepslate_tiles
fill ~51 ~-61 ~30 ~63 ~-61 ~30 minecraft:air
setblock ~64 ~-61 ~30 minecraft:deepslate_tiles
setblock ~4 ~-61 ~31 minecraft:deepslate_tiles
setblock ~5 ~-61 ~31 minecraft:air
setblock ~6 ~-61 ~31 minecraft:waxed_cut_copper
fill ~7 ~-61 ~31 ~8 ~-61 ~31 minecraft:air
setblock ~9 ~-61 ~31 minecraft:waxed_cut_copper
fill ~10 ~-61 ~31 ~14 ~-61 ~31 minecraft:air
setblock ~15 ~-61 ~31 minecraft:waxed_cut_copper
fill ~16 ~-61 ~31 ~17 ~-61 ~31 minecraft:air
setblock ~18 ~-61 ~31 minecraft:deepslate_tiles
setblock ~19 ~-61 ~31 minecraft:air
setblock ~20 ~-61 ~31 minecraft:deepslate_tiles
fill ~21 ~-61 ~31 ~47 ~-61 ~31 minecraft:air
setblock ~48 ~-61 ~31 minecraft:deepslate_tiles
setblock ~49 ~-61 ~31 minecraft:air
setblock ~50 ~-61 ~31 minecraft:deepslate_tiles
fill ~51 ~-61 ~31 ~63 ~-61 ~31 minecraft:air
setblock ~64 ~-61 ~31 minecraft:deepslate_tiles
fill ~4 ~-61 ~32 ~20 ~-61 ~32 minecraft:deepslate_tiles
fill ~21 ~-61 ~32 ~32 ~-61 ~32 minecraft:air
fill ~33 ~-61 ~32 ~35 ~-61 ~32 minecraft:glass
fill ~36 ~-61 ~32 ~47 ~-61 ~32 minecraft:air
fill ~48 ~-61 ~32 ~64 ~-61 ~32 minecraft:deepslate_tiles
setblock ~4 ~-61 ~33 minecraft:deepslate_tiles
fill ~5 ~-61 ~33 ~19 ~-61 ~33 minecraft:air
setblock ~20 ~-61 ~33 minecraft:deepslate_tiles
fill ~21 ~-61 ~33 ~31 ~-61 ~33 minecraft:air
setblock ~32 ~-61 ~33 minecraft:glass
fill ~33 ~-61 ~33 ~35 ~-61 ~33 minecraft:sea_lantern
setblock ~36 ~-61 ~33 minecraft:glass
fill ~37 ~-61 ~33 ~47 ~-61 ~33 minecraft:air
setblock ~48 ~-61 ~33 minecraft:deepslate_tiles
fill ~49 ~-61 ~33 ~63 ~-61 ~33 minecraft:air
setblock ~64 ~-61 ~33 minecraft:deepslate_tiles
setblock ~4 ~-61 ~34 minecraft:deepslate_tiles
fill ~5 ~-61 ~34 ~18 ~-61 ~34 minecraft:air
setblock ~19 ~-61 ~34 minecraft:deepslate_tiles
fill ~20 ~-61 ~34 ~31 ~-61 ~34 minecraft:air
setblock ~32 ~-61 ~34 minecraft:glass
fill ~33 ~-61 ~34 ~35 ~-61 ~34 minecraft:sea_lantern
setblock ~36 ~-61 ~34 minecraft:glass
fill ~37 ~-61 ~34 ~48 ~-61 ~34 minecraft:air
setblock ~49 ~-61 ~34 minecraft:deepslate_tiles
fill ~50 ~-61 ~34 ~63 ~-61 ~34 minecraft:air
setblock ~64 ~-61 ~34 minecraft:deepslate_tiles
setblock ~4 ~-61 ~35 minecraft:deepslate_tiles
fill ~5 ~-61 ~35 ~19 ~-61 ~35 minecraft:air
setblock ~20 ~-61 ~35 minecraft:deepslate_tiles
fill ~21 ~-61 ~35 ~31 ~-61 ~35 minecraft:air
setblock ~32 ~-61 ~35 minecraft:glass
fill ~33 ~-61 ~35 ~35 ~-61 ~35 minecraft:sea_lantern
setblock ~36 ~-61 ~35 minecraft:glass
fill ~37 ~-61 ~35 ~47 ~-61 ~35 minecraft:air
setblock ~48 ~-61 ~35 minecraft:deepslate_tiles
fill ~49 ~-61 ~35 ~63 ~-61 ~35 minecraft:air
setblock ~64 ~-61 ~35 minecraft:deepslate_tiles
fill ~4 ~-61 ~36 ~20 ~-61 ~36 minecraft:deepslate_tiles
fill ~21 ~-61 ~36 ~32 ~-61 ~36 minecraft:air
fill ~33 ~-61 ~36 ~35 ~-61 ~36 minecraft:glass
fill ~36 ~-61 ~36 ~47 ~-61 ~36 minecraft:air
fill ~48 ~-61 ~36 ~64 ~-61 ~36 minecraft:deepslate_tiles
setblock ~4 ~-61 ~37 minecraft:deepslate_tiles
setblock ~5 ~-61 ~37 minecraft:air
setblock ~6 ~-61 ~37 minecraft:waxed_cut_copper
fill ~7 ~-61 ~37 ~8 ~-61 ~37 minecraft:air
setblock ~9 ~-61 ~37 minecraft:waxed_cut_copper
fill ~10 ~-61 ~37 ~14 ~-61 ~37 minecraft:air
setblock ~15 ~-61 ~37 minecraft:waxed_cut_copper
fill ~16 ~-61 ~37 ~17 ~-61 ~37 minecraft:air
setblock ~18 ~-61 ~37 minecraft:deepslate_tiles
setblock ~19 ~-61 ~37 minecraft:air
setblock ~20 ~-61 ~37 minecraft:deepslate_tiles
fill ~21 ~-61 ~37 ~47 ~-61 ~37 minecraft:air
setblock ~48 ~-61 ~37 minecraft:deepslate_tiles
setblock ~49 ~-61 ~37 minecraft:air
setblock ~50 ~-61 ~37 minecraft:deepslate_tiles
fill ~51 ~-61 ~37 ~63 ~-61 ~37 minecraft:air
setblock ~64 ~-61 ~37 minecraft:deepslate_tiles
setblock ~4 ~-61 ~38 minecraft:deepslate_tiles
setblock ~5 ~-61 ~38 minecraft:waxed_cut_copper
fill ~6 ~-61 ~38 ~16 ~-61 ~38 minecraft:air
setblock ~17 ~-61 ~38 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~38 minecraft:deepslate_tiles
setblock ~19 ~-61 ~38 minecraft:air
setblock ~20 ~-61 ~38 minecraft:deepslate_tiles
fill ~21 ~-61 ~38 ~47 ~-61 ~38 minecraft:air
setblock ~48 ~-61 ~38 minecraft:deepslate_tiles
setblock ~49 ~-61 ~38 minecraft:air
setblock ~50 ~-61 ~38 minecraft:deepslate_tiles
fill ~51 ~-61 ~38 ~63 ~-61 ~38 minecraft:air
setblock ~64 ~-61 ~38 minecraft:deepslate_tiles
setblock ~4 ~-61 ~39 minecraft:deepslate_tiles
fill ~5 ~-61 ~39 ~17 ~-61 ~39 minecraft:air
setblock ~18 ~-61 ~39 minecraft:deepslate_tiles
setblock ~19 ~-61 ~39 minecraft:air
setblock ~20 ~-61 ~39 minecraft:deepslate_tiles
fill ~21 ~-61 ~39 ~47 ~-61 ~39 minecraft:air
setblock ~48 ~-61 ~39 minecraft:deepslate_tiles
setblock ~49 ~-61 ~39 minecraft:air
setblock ~50 ~-61 ~39 minecraft:deepslate_tiles
fill ~51 ~-61 ~39 ~63 ~-61 ~39 minecraft:air
setblock ~64 ~-61 ~39 minecraft:deepslate_tiles
setblock ~4 ~-61 ~40 minecraft:deepslate_tiles
fill ~5 ~-61 ~40 ~17 ~-61 ~40 minecraft:air
setblock ~18 ~-61 ~40 minecraft:deepslate_tiles
fill ~19 ~-61 ~40 ~20 ~-61 ~40 minecraft:air
setblock ~21 ~-61 ~40 minecraft:deepslate_tiles
fill ~22 ~-61 ~40 ~46 ~-61 ~40 minecraft:air
setblock ~47 ~-61 ~40 minecraft:deepslate_tiles
fill ~48 ~-61 ~40 ~49 ~-61 ~40 minecraft:air
setblock ~50 ~-61 ~40 minecraft:deepslate_tiles
fill ~51 ~-61 ~40 ~63 ~-61 ~40 minecraft:air
setblock ~64 ~-61 ~40 minecraft:deepslate_tiles
setblock ~4 ~-61 ~41 minecraft:deepslate_tiles
setblock ~5 ~-61 ~41 minecraft:waxed_cut_copper
fill ~6 ~-61 ~41 ~16 ~-61 ~41 minecraft:air
setblock ~17 ~-61 ~41 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~41 minecraft:deepslate_tiles
fill ~19 ~-61 ~41 ~20 ~-61 ~41 minecraft:air
setblock ~21 ~-61 ~41 minecraft:deepslate_tiles
fill ~22 ~-61 ~41 ~46 ~-61 ~41 minecraft:air
setblock ~47 ~-61 ~41 minecraft:deepslate_tiles
fill ~48 ~-61 ~41 ~49 ~-61 ~41 minecraft:air
setblock ~50 ~-61 ~41 minecraft:deepslate_tiles
fill ~51 ~-61 ~41 ~63 ~-61 ~41 minecraft:air
setblock ~64 ~-61 ~41 minecraft:deepslate_tiles
setblock ~4 ~-61 ~42 minecraft:deepslate_tiles
fill ~5 ~-61 ~42 ~17 ~-61 ~42 minecraft:air
setblock ~18 ~-61 ~42 minecraft:deepslate_tiles
fill ~19 ~-61 ~42 ~21 ~-61 ~42 minecraft:air
setblock ~22 ~-61 ~42 minecraft:deepslate_tiles
fill ~23 ~-61 ~42 ~25 ~-61 ~42 minecraft:air
setblock ~26 ~-61 ~42 minecraft:waxed_cut_copper
fill ~27 ~-61 ~42 ~41 ~-61 ~42 minecraft:air
setblock ~42 ~-61 ~42 minecraft:waxed_cut_copper
fill ~43 ~-61 ~42 ~45 ~-61 ~42 minecraft:air
setblock ~46 ~-61 ~42 minecraft:deepslate_tiles
fill ~47 ~-61 ~42 ~49 ~-61 ~42 minecraft:air
setblock ~50 ~-61 ~42 minecraft:deepslate_tiles
fill ~51 ~-61 ~42 ~63 ~-61 ~42 minecraft:air
setblock ~64 ~-61 ~42 minecraft:deepslate_tiles
setblock ~4 ~-61 ~43 minecraft:deepslate_tiles
fill ~5 ~-61 ~43 ~17 ~-61 ~43 minecraft:air
setblock ~18 ~-61 ~43 minecraft:deepslate_tiles
fill ~19 ~-61 ~43 ~21 ~-61 ~43 minecraft:air
fill ~22 ~-61 ~43 ~23 ~-61 ~43 minecraft:deepslate_tiles
fill ~24 ~-61 ~43 ~44 ~-61 ~43 minecraft:air
fill ~45 ~-61 ~43 ~46 ~-61 ~43 minecraft:deepslate_tiles
fill ~47 ~-61 ~43 ~49 ~-61 ~43 minecraft:air
setblock ~50 ~-61 ~43 minecraft:deepslate_tiles
fill ~51 ~-61 ~43 ~63 ~-61 ~43 minecraft:air
setblock ~64 ~-61 ~43 minecraft:deepslate_tiles
setblock ~4 ~-61 ~44 minecraft:deepslate_tiles
setblock ~5 ~-61 ~44 minecraft:waxed_cut_copper
fill ~6 ~-61 ~44 ~16 ~-61 ~44 minecraft:air
setblock ~17 ~-61 ~44 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~44 minecraft:deepslate_tiles
fill ~19 ~-61 ~44 ~22 ~-61 ~44 minecraft:air
fill ~23 ~-61 ~44 ~24 ~-61 ~44 minecraft:deepslate_tiles
fill ~25 ~-61 ~44 ~43 ~-61 ~44 minecraft:air
fill ~44 ~-61 ~44 ~45 ~-61 ~44 minecraft:deepslate_tiles
fill ~46 ~-61 ~44 ~49 ~-61 ~44 minecraft:air
setblock ~50 ~-61 ~44 minecraft:deepslate_tiles
fill ~51 ~-61 ~44 ~63 ~-61 ~44 minecraft:air
setblock ~64 ~-61 ~44 minecraft:deepslate_tiles
setblock ~4 ~-61 ~45 minecraft:deepslate_tiles
fill ~5 ~-61 ~45 ~17 ~-61 ~45 minecraft:air
setblock ~18 ~-61 ~45 minecraft:deepslate_tiles
fill ~19 ~-61 ~45 ~23 ~-61 ~45 minecraft:air
fill ~24 ~-61 ~45 ~25 ~-61 ~45 minecraft:deepslate_tiles
fill ~26 ~-61 ~45 ~42 ~-61 ~45 minecraft:air
fill ~43 ~-61 ~45 ~44 ~-61 ~45 minecraft:deepslate_tiles
fill ~45 ~-61 ~45 ~49 ~-61 ~45 minecraft:air
setblock ~50 ~-61 ~45 minecraft:deepslate_tiles
fill ~51 ~-61 ~45 ~63 ~-61 ~45 minecraft:air
setblock ~64 ~-61 ~45 minecraft:deepslate_tiles
setblock ~4 ~-61 ~46 minecraft:deepslate_tiles
fill ~5 ~-61 ~46 ~17 ~-61 ~46 minecraft:air
setblock ~18 ~-61 ~46 minecraft:deepslate_tiles
fill ~19 ~-61 ~46 ~24 ~-61 ~46 minecraft:air
fill ~25 ~-61 ~46 ~26 ~-61 ~46 minecraft:deepslate_tiles
fill ~27 ~-61 ~46 ~41 ~-61 ~46 minecraft:air
fill ~42 ~-61 ~46 ~43 ~-61 ~46 minecraft:deepslate_tiles
fill ~44 ~-61 ~46 ~49 ~-61 ~46 minecraft:air
setblock ~50 ~-61 ~46 minecraft:deepslate_tiles
fill ~51 ~-61 ~46 ~63 ~-61 ~46 minecraft:air
setblock ~64 ~-61 ~46 minecraft:deepslate_tiles
setblock ~4 ~-61 ~47 minecraft:deepslate_tiles
setblock ~5 ~-61 ~47 minecraft:waxed_cut_copper
fill ~6 ~-61 ~47 ~16 ~-61 ~47 minecraft:air
setblock ~17 ~-61 ~47 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~47 minecraft:deepslate_tiles
fill ~19 ~-61 ~47 ~26 ~-61 ~47 minecraft:air
fill ~27 ~-61 ~47 ~28 ~-61 ~47 minecraft:deepslate_tiles
fill ~29 ~-61 ~47 ~39 ~-61 ~47 minecraft:air
fill ~40 ~-61 ~47 ~41 ~-61 ~47 minecraft:deepslate_tiles
fill ~42 ~-61 ~47 ~49 ~-61 ~47 minecraft:air
setblock ~50 ~-61 ~47 minecraft:deepslate_tiles
fill ~51 ~-61 ~47 ~63 ~-61 ~47 minecraft:air
setblock ~64 ~-61 ~47 minecraft:deepslate_tiles
setblock ~4 ~-61 ~48 minecraft:deepslate_tiles
fill ~5 ~-61 ~48 ~17 ~-61 ~48 minecraft:air
setblock ~18 ~-61 ~48 minecraft:deepslate_tiles
fill ~19 ~-61 ~48 ~28 ~-61 ~48 minecraft:air
fill ~29 ~-61 ~48 ~33 ~-61 ~48 minecraft:deepslate_tiles
setblock ~34 ~-61 ~48 minecraft:air
fill ~35 ~-61 ~48 ~39 ~-61 ~48 minecraft:deepslate_tiles
fill ~40 ~-61 ~48 ~49 ~-61 ~48 minecraft:air
setblock ~50 ~-61 ~48 minecraft:deepslate_tiles
fill ~51 ~-61 ~48 ~63 ~-61 ~48 minecraft:air
setblock ~64 ~-61 ~48 minecraft:deepslate_tiles
setblock ~4 ~-61 ~49 minecraft:deepslate_tiles
setblock ~5 ~-61 ~49 minecraft:air
setblock ~6 ~-61 ~49 minecraft:waxed_cut_copper
fill ~7 ~-61 ~49 ~8 ~-61 ~49 minecraft:air
setblock ~9 ~-61 ~49 minecraft:waxed_cut_copper
fill ~10 ~-61 ~49 ~14 ~-61 ~49 minecraft:air
setblock ~15 ~-61 ~49 minecraft:waxed_cut_copper
fill ~16 ~-61 ~49 ~17 ~-61 ~49 minecraft:air
setblock ~18 ~-61 ~49 minecraft:deepslate_tiles
fill ~19 ~-61 ~49 ~31 ~-61 ~49 minecraft:air
setblock ~32 ~-61 ~49 minecraft:deepslate_tiles
setblock ~33 ~-61 ~49 minecraft:air
setblock ~34 ~-61 ~49 minecraft:deepslate_tiles
setblock ~35 ~-61 ~49 minecraft:air
setblock ~36 ~-61 ~49 minecraft:deepslate_tiles
fill ~37 ~-61 ~49 ~49 ~-61 ~49 minecraft:air
setblock ~50 ~-61 ~49 minecraft:deepslate_tiles
fill ~51 ~-61 ~49 ~63 ~-61 ~49 minecraft:air
setblock ~64 ~-61 ~49 minecraft:deepslate_tiles
fill ~4 ~-61 ~50 ~32 ~-61 ~50 minecraft:deepslate_tiles
fill ~33 ~-61 ~50 ~35 ~-61 ~50 minecraft:air
fill ~36 ~-61 ~50 ~64 ~-61 ~50 minecraft:deepslate_tiles
setblock ~4 ~-61 ~51 minecraft:deepslate_tiles
fill ~5 ~-61 ~51 ~9 ~-61 ~51 minecraft:waxed_cut_copper
fill ~10 ~-61 ~51 ~12 ~-61 ~51 minecraft:air
fill ~13 ~-61 ~51 ~17 ~-61 ~51 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~51 minecraft:deepslate_tiles
fill ~19 ~-61 ~51 ~31 ~-61 ~51 minecraft:air
setblock ~32 ~-61 ~51 minecraft:deepslate_tiles
fill ~33 ~-61 ~51 ~35 ~-61 ~51 minecraft:air
setblock ~36 ~-61 ~51 minecraft:deepslate_tiles
fill ~37 ~-61 ~51 ~49 ~-61 ~51 minecraft:air
setblock ~50 ~-61 ~51 minecraft:deepslate_tiles
setblock ~51 ~-61 ~51 minecraft:waxed_cut_copper
fill ~52 ~-61 ~51 ~53 ~-61 ~51 minecraft:air
setblock ~54 ~-61 ~51 minecraft:waxed_cut_copper
fill ~55 ~-61 ~51 ~59 ~-61 ~51 minecraft:air
setblock ~60 ~-61 ~51 minecraft:waxed_cut_copper
fill ~61 ~-61 ~51 ~62 ~-61 ~51 minecraft:air
setblock ~63 ~-61 ~51 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~51 minecraft:deepslate_tiles
setblock ~4 ~-61 ~52 minecraft:deepslate_tiles
setblock ~5 ~-61 ~52 minecraft:waxed_cut_copper
fill ~6 ~-61 ~52 ~16 ~-61 ~52 minecraft:air
setblock ~17 ~-61 ~52 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~52 minecraft:deepslate_tiles
fill ~19 ~-61 ~52 ~31 ~-61 ~52 minecraft:air
setblock ~32 ~-61 ~52 minecraft:deepslate_tiles
fill ~33 ~-61 ~52 ~35 ~-61 ~52 minecraft:air
setblock ~36 ~-61 ~52 minecraft:deepslate_tiles
fill ~37 ~-61 ~52 ~49 ~-61 ~52 minecraft:air
setblock ~50 ~-61 ~52 minecraft:deepslate_tiles
fill ~51 ~-61 ~52 ~63 ~-61 ~52 minecraft:air
setblock ~64 ~-61 ~52 minecraft:deepslate_tiles
setblock ~4 ~-61 ~53 minecraft:deepslate_tiles
setblock ~5 ~-61 ~53 minecraft:waxed_cut_copper
fill ~6 ~-61 ~53 ~16 ~-61 ~53 minecraft:air
setblock ~17 ~-61 ~53 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~53 minecraft:deepslate_tiles
fill ~19 ~-61 ~53 ~31 ~-61 ~53 minecraft:air
setblock ~32 ~-61 ~53 minecraft:deepslate_tiles
fill ~33 ~-61 ~53 ~35 ~-61 ~53 minecraft:air
setblock ~36 ~-61 ~53 minecraft:deepslate_tiles
fill ~37 ~-61 ~53 ~49 ~-61 ~53 minecraft:air
setblock ~50 ~-61 ~53 minecraft:deepslate_tiles
fill ~51 ~-61 ~53 ~63 ~-61 ~53 minecraft:air
setblock ~64 ~-61 ~53 minecraft:deepslate_tiles
setblock ~4 ~-61 ~54 minecraft:deepslate_tiles
setblock ~5 ~-61 ~54 minecraft:waxed_cut_copper
fill ~6 ~-61 ~54 ~16 ~-61 ~54 minecraft:air
setblock ~17 ~-61 ~54 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~54 minecraft:deepslate_tiles
fill ~19 ~-61 ~54 ~31 ~-61 ~54 minecraft:air
setblock ~32 ~-61 ~54 minecraft:deepslate_tiles
fill ~33 ~-61 ~54 ~35 ~-61 ~54 minecraft:air
setblock ~36 ~-61 ~54 minecraft:deepslate_tiles
fill ~37 ~-61 ~54 ~49 ~-61 ~54 minecraft:air
setblock ~50 ~-61 ~54 minecraft:deepslate_tiles
setblock ~51 ~-61 ~54 minecraft:waxed_cut_copper
fill ~52 ~-61 ~54 ~62 ~-61 ~54 minecraft:air
setblock ~63 ~-61 ~54 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~54 minecraft:deepslate_tiles
setblock ~4 ~-61 ~55 minecraft:deepslate_tiles
setblock ~5 ~-61 ~55 minecraft:waxed_cut_copper
fill ~6 ~-61 ~55 ~16 ~-61 ~55 minecraft:air
setblock ~17 ~-61 ~55 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~55 minecraft:deepslate_tiles
fill ~19 ~-61 ~55 ~31 ~-61 ~55 minecraft:air
setblock ~32 ~-61 ~55 minecraft:deepslate_tiles
fill ~33 ~-61 ~55 ~35 ~-61 ~55 minecraft:air
setblock ~36 ~-61 ~55 minecraft:deepslate_tiles
fill ~37 ~-61 ~55 ~49 ~-61 ~55 minecraft:air
setblock ~50 ~-61 ~55 minecraft:deepslate_tiles
fill ~51 ~-61 ~55 ~63 ~-61 ~55 minecraft:air
setblock ~64 ~-61 ~55 minecraft:deepslate_tiles
setblock ~4 ~-61 ~56 minecraft:deepslate_tiles
setblock ~5 ~-61 ~56 minecraft:waxed_cut_copper
fill ~6 ~-61 ~56 ~17 ~-61 ~56 minecraft:air
setblock ~18 ~-61 ~56 minecraft:deepslate_tiles
fill ~19 ~-61 ~56 ~31 ~-61 ~56 minecraft:air
setblock ~32 ~-61 ~56 minecraft:deepslate_tiles
fill ~33 ~-61 ~56 ~35 ~-61 ~56 minecraft:air
setblock ~36 ~-61 ~56 minecraft:deepslate_tiles
fill ~37 ~-61 ~56 ~49 ~-61 ~56 minecraft:air
setblock ~50 ~-61 ~56 minecraft:deepslate_tiles
fill ~51 ~-61 ~56 ~63 ~-61 ~56 minecraft:air
setblock ~64 ~-61 ~56 minecraft:deepslate_tiles
setblock ~4 ~-61 ~57 minecraft:deepslate_tiles
setblock ~5 ~-61 ~57 minecraft:waxed_cut_copper
fill ~6 ~-61 ~57 ~17 ~-61 ~57 minecraft:air
setblock ~18 ~-61 ~57 minecraft:deepslate_tiles
fill ~19 ~-61 ~57 ~31 ~-61 ~57 minecraft:air
setblock ~32 ~-61 ~57 minecraft:deepslate_tiles
fill ~33 ~-61 ~57 ~35 ~-61 ~57 minecraft:air
setblock ~36 ~-61 ~57 minecraft:deepslate_tiles
fill ~37 ~-61 ~57 ~49 ~-61 ~57 minecraft:air
setblock ~50 ~-61 ~57 minecraft:deepslate_tiles
fill ~51 ~-61 ~57 ~62 ~-61 ~57 minecraft:air
setblock ~63 ~-61 ~57 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~57 minecraft:deepslate_tiles
setblock ~4 ~-61 ~58 minecraft:deepslate_tiles
setblock ~5 ~-61 ~58 minecraft:waxed_cut_copper
fill ~6 ~-61 ~58 ~17 ~-61 ~58 minecraft:air
setblock ~18 ~-61 ~58 minecraft:deepslate_tiles
fill ~19 ~-61 ~58 ~31 ~-61 ~58 minecraft:air
setblock ~32 ~-61 ~58 minecraft:deepslate_tiles
fill ~33 ~-61 ~58 ~35 ~-61 ~58 minecraft:air
setblock ~36 ~-61 ~58 minecraft:deepslate_tiles
fill ~37 ~-61 ~58 ~49 ~-61 ~58 minecraft:air
setblock ~50 ~-61 ~58 minecraft:deepslate_tiles
fill ~51 ~-61 ~58 ~63 ~-61 ~58 minecraft:air
setblock ~64 ~-61 ~58 minecraft:deepslate_tiles
setblock ~4 ~-61 ~59 minecraft:deepslate_tiles
setblock ~5 ~-61 ~59 minecraft:waxed_cut_copper
fill ~6 ~-61 ~59 ~16 ~-61 ~59 minecraft:air
setblock ~17 ~-61 ~59 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~59 minecraft:deepslate_tiles
fill ~19 ~-61 ~59 ~31 ~-61 ~59 minecraft:air
setblock ~32 ~-61 ~59 minecraft:deepslate_tiles
fill ~33 ~-61 ~59 ~35 ~-61 ~59 minecraft:air
setblock ~36 ~-61 ~59 minecraft:deepslate_tiles
fill ~37 ~-61 ~59 ~49 ~-61 ~59 minecraft:air
setblock ~50 ~-61 ~59 minecraft:deepslate_tiles
fill ~51 ~-61 ~59 ~63 ~-61 ~59 minecraft:air
setblock ~64 ~-61 ~59 minecraft:deepslate_tiles
setblock ~4 ~-61 ~60 minecraft:deepslate_tiles
setblock ~5 ~-61 ~60 minecraft:waxed_cut_copper
fill ~6 ~-61 ~60 ~16 ~-61 ~60 minecraft:air
setblock ~17 ~-61 ~60 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~60 minecraft:deepslate_tiles
fill ~19 ~-61 ~60 ~31 ~-61 ~60 minecraft:air
setblock ~32 ~-61 ~60 minecraft:deepslate_tiles
fill ~33 ~-61 ~60 ~35 ~-61 ~60 minecraft:air
setblock ~36 ~-61 ~60 minecraft:deepslate_tiles
fill ~37 ~-61 ~60 ~49 ~-61 ~60 minecraft:air
setblock ~50 ~-61 ~60 minecraft:deepslate_tiles
setblock ~51 ~-61 ~60 minecraft:waxed_cut_copper
fill ~52 ~-61 ~60 ~62 ~-61 ~60 minecraft:air
setblock ~63 ~-61 ~60 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~60 minecraft:deepslate_tiles
setblock ~4 ~-61 ~61 minecraft:deepslate_tiles
setblock ~5 ~-61 ~61 minecraft:waxed_cut_copper
fill ~6 ~-61 ~61 ~16 ~-61 ~61 minecraft:air
setblock ~17 ~-61 ~61 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~61 minecraft:deepslate_tiles
fill ~19 ~-61 ~61 ~31 ~-61 ~61 minecraft:air
setblock ~32 ~-61 ~61 minecraft:deepslate_tiles
fill ~33 ~-61 ~61 ~35 ~-61 ~61 minecraft:air
setblock ~36 ~-61 ~61 minecraft:deepslate_tiles
fill ~37 ~-61 ~61 ~49 ~-61 ~61 minecraft:air
setblock ~50 ~-61 ~61 minecraft:deepslate_tiles
fill ~51 ~-61 ~61 ~63 ~-61 ~61 minecraft:air
setblock ~64 ~-61 ~61 minecraft:deepslate_tiles
setblock ~4 ~-61 ~62 minecraft:deepslate_tiles
setblock ~5 ~-61 ~62 minecraft:waxed_cut_copper
fill ~6 ~-61 ~62 ~16 ~-61 ~62 minecraft:air
setblock ~17 ~-61 ~62 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~62 minecraft:deepslate_tiles
fill ~19 ~-61 ~62 ~31 ~-61 ~62 minecraft:air
setblock ~32 ~-61 ~62 minecraft:deepslate_tiles
fill ~33 ~-61 ~62 ~35 ~-61 ~62 minecraft:air
setblock ~36 ~-61 ~62 minecraft:deepslate_tiles
fill ~37 ~-61 ~62 ~49 ~-61 ~62 minecraft:air
setblock ~50 ~-61 ~62 minecraft:deepslate_tiles
fill ~51 ~-61 ~62 ~63 ~-61 ~62 minecraft:air
setblock ~64 ~-61 ~62 minecraft:deepslate_tiles
setblock ~4 ~-61 ~63 minecraft:deepslate_tiles
fill ~5 ~-61 ~63 ~17 ~-61 ~63 minecraft:waxed_cut_copper
setblock ~18 ~-61 ~63 minecraft:deepslate_tiles
fill ~19 ~-61 ~63 ~31 ~-61 ~63 minecraft:air
setblock ~32 ~-61 ~63 minecraft:deepslate_tiles
fill ~33 ~-61 ~63 ~35 ~-61 ~63 minecraft:air
setblock ~36 ~-61 ~63 minecraft:deepslate_tiles
fill ~37 ~-61 ~63 ~49 ~-61 ~63 minecraft:air
setblock ~50 ~-61 ~63 minecraft:deepslate_tiles
setblock ~51 ~-61 ~63 minecraft:waxed_cut_copper
fill ~52 ~-61 ~63 ~53 ~-61 ~63 minecraft:air
setblock ~54 ~-61 ~63 minecraft:waxed_cut_copper
fill ~55 ~-61 ~63 ~56 ~-61 ~63 minecraft:air
setblock ~57 ~-61 ~63 minecraft:waxed_cut_copper
fill ~58 ~-61 ~63 ~59 ~-61 ~63 minecraft:air
setblock ~60 ~-61 ~63 minecraft:waxed_cut_copper
fill ~61 ~-61 ~63 ~62 ~-61 ~63 minecraft:air
setblock ~63 ~-61 ~63 minecraft:waxed_cut_copper
setblock ~64 ~-61 ~63 minecraft:deepslate_tiles
fill ~4 ~-61 ~64 ~64 ~-61 ~64 minecraft:deepslate_tiles
fill ~32 ~-61 ~66 ~36 ~-61 ~66 minecraft:polished_andesite
setblock ~32 ~-61 ~67 minecraft:polished_andesite
setblock ~33 ~-61 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-61 ~67 ~35 ~-61 ~67 minecraft:air
setblock ~36 ~-61 ~67 minecraft:polished_andesite
setblock ~32 ~-61 ~68 minecraft:polished_andesite
setblock ~33 ~-61 ~68 minecraft:air
setblock ~34 ~-61 ~68 minecraft:quartz_pillar
setblock ~35 ~-61 ~68 minecraft:air
setblock ~36 ~-61 ~68 minecraft:polished_andesite
setblock ~32 ~-61 ~69 minecraft:polished_andesite
fill ~33 ~-61 ~69 ~35 ~-61 ~69 minecraft:air
setblock ~36 ~-61 ~69 minecraft:polished_andesite
fill ~32 ~-61 ~70 ~36 ~-61 ~70 minecraft:polished_andesite
fill ~4 ~-60 ~4 ~64 ~-60 ~4 minecraft:deepslate_tiles
setblock ~4 ~-60 ~5 minecraft:deepslate_tiles
fill ~5 ~-60 ~5 ~17 ~-60 ~5 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~5 minecraft:deepslate_tiles
fill ~19 ~-60 ~5 ~31 ~-60 ~5 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~5 minecraft:deepslate_tiles
setblock ~33 ~-60 ~5 minecraft:air
setblock ~34 ~-60 ~5 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~5 minecraft:air
setblock ~36 ~-60 ~5 minecraft:deepslate_tiles
setblock ~37 ~-60 ~5 minecraft:waxed_cut_copper
fill ~38 ~-60 ~5 ~39 ~-60 ~5 minecraft:air
setblock ~40 ~-60 ~5 minecraft:waxed_cut_copper
fill ~41 ~-60 ~5 ~42 ~-60 ~5 minecraft:air
setblock ~43 ~-60 ~5 minecraft:waxed_cut_copper
fill ~44 ~-60 ~5 ~45 ~-60 ~5 minecraft:air
setblock ~46 ~-60 ~5 minecraft:waxed_cut_copper
fill ~47 ~-60 ~5 ~48 ~-60 ~5 minecraft:air
setblock ~49 ~-60 ~5 minecraft:waxed_cut_copper
setblock ~50 ~-60 ~5 minecraft:deepslate_tiles
setblock ~51 ~-60 ~5 minecraft:air
setblock ~52 ~-60 ~5 minecraft:waxed_cut_copper
fill ~53 ~-60 ~5 ~54 ~-60 ~5 minecraft:air
setblock ~55 ~-60 ~5 minecraft:waxed_cut_copper
fill ~56 ~-60 ~5 ~57 ~-60 ~5 minecraft:air
setblock ~58 ~-60 ~5 minecraft:waxed_cut_copper
fill ~59 ~-60 ~5 ~60 ~-60 ~5 minecraft:air
setblock ~61 ~-60 ~5 minecraft:waxed_cut_copper
fill ~62 ~-60 ~5 ~63 ~-60 ~5 minecraft:air
setblock ~64 ~-60 ~5 minecraft:deepslate_tiles
setblock ~4 ~-60 ~6 minecraft:deepslate_tiles
setblock ~5 ~-60 ~6 minecraft:waxed_cut_copper
fill ~6 ~-60 ~6 ~16 ~-60 ~6 minecraft:air
setblock ~17 ~-60 ~6 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~6 minecraft:deepslate_tiles
setblock ~19 ~-60 ~6 minecraft:waxed_cut_copper
fill ~20 ~-60 ~6 ~30 ~-60 ~6 minecraft:air
setblock ~31 ~-60 ~6 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~6 minecraft:deepslate_tiles
setblock ~33 ~-60 ~6 minecraft:air
setblock ~34 ~-60 ~6 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~6 minecraft:air
setblock ~36 ~-60 ~6 minecraft:deepslate_tiles
fill ~37 ~-60 ~6 ~49 ~-60 ~6 minecraft:air
setblock ~50 ~-60 ~6 minecraft:deepslate_tiles
setblock ~51 ~-60 ~6 minecraft:waxed_cut_copper
fill ~52 ~-60 ~6 ~62 ~-60 ~6 minecraft:air
setblock ~63 ~-60 ~6 minecraft:waxed_cut_copper
setblock ~64 ~-60 ~6 minecraft:deepslate_tiles
setblock ~4 ~-60 ~7 minecraft:deepslate_tiles
setblock ~5 ~-60 ~7 minecraft:waxed_cut_copper
fill ~6 ~-60 ~7 ~16 ~-60 ~7 minecraft:air
setblock ~17 ~-60 ~7 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~7 minecraft:deepslate_tiles
setblock ~19 ~-60 ~7 minecraft:waxed_cut_copper
fill ~20 ~-60 ~7 ~30 ~-60 ~7 minecraft:air
setblock ~31 ~-60 ~7 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~7 minecraft:deepslate_tiles
setblock ~33 ~-60 ~7 minecraft:air
setblock ~34 ~-60 ~7 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~7 minecraft:air
setblock ~36 ~-60 ~7 minecraft:deepslate_tiles
fill ~37 ~-60 ~7 ~49 ~-60 ~7 minecraft:air
setblock ~50 ~-60 ~7 minecraft:deepslate_tiles
fill ~51 ~-60 ~7 ~63 ~-60 ~7 minecraft:air
setblock ~64 ~-60 ~7 minecraft:deepslate_tiles
setblock ~4 ~-60 ~8 minecraft:deepslate_tiles
setblock ~5 ~-60 ~8 minecraft:waxed_cut_copper
fill ~6 ~-60 ~8 ~16 ~-60 ~8 minecraft:air
setblock ~17 ~-60 ~8 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~8 minecraft:deepslate_tiles
setblock ~19 ~-60 ~8 minecraft:waxed_cut_copper
fill ~20 ~-60 ~8 ~30 ~-60 ~8 minecraft:air
setblock ~31 ~-60 ~8 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~8 minecraft:deepslate_tiles
setblock ~33 ~-60 ~8 minecraft:air
setblock ~34 ~-60 ~8 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~8 minecraft:air
setblock ~36 ~-60 ~8 minecraft:deepslate_tiles
setblock ~37 ~-60 ~8 minecraft:waxed_cut_copper
fill ~38 ~-60 ~8 ~48 ~-60 ~8 minecraft:air
setblock ~49 ~-60 ~8 minecraft:waxed_cut_copper
setblock ~50 ~-60 ~8 minecraft:deepslate_tiles
fill ~51 ~-60 ~8 ~63 ~-60 ~8 minecraft:air
setblock ~64 ~-60 ~8 minecraft:deepslate_tiles
setblock ~4 ~-60 ~9 minecraft:deepslate_tiles
setblock ~5 ~-60 ~9 minecraft:waxed_cut_copper
fill ~6 ~-60 ~9 ~16 ~-60 ~9 minecraft:air
setblock ~17 ~-60 ~9 minecraft:waxed_cut_copper
setblock ~18 ~-60 ~9 minecraft:deepslate_tiles
setblock ~19 ~-60 ~9 minecraft:waxed_cut_copper
fill ~20 ~-60 ~9 ~30 ~-60 ~9 minecraft:air
setblock ~31 ~-60 ~9 minecraft:waxed_cut_copper
setblock ~32 ~-60 ~9 minecraft:deepslate_tiles
setblock ~33 ~-60 ~9 minecraft:air
setblock ~34 ~-60 ~9 minecraft:waxed_cut_copper
setblock ~35 ~-60 ~9 minecraft:air
setblock ~36 ~-60 ~9 minecraft:deepslate_tiles
fill ~37 ~-60 ~9 ~49 ~-60 ~9 minecraft:air
schedule function hive:weiter/4 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 3 von 18 fertig","color":"gray"}]