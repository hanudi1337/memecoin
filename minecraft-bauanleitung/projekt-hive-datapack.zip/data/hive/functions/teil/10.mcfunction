fill ~20 ~-31 ~19 ~22 ~-31 ~19 minecraft:air
setblock ~23 ~-31 ~19 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-31 ~19 ~26 ~-31 ~19 minecraft:air
setblock ~27 ~-31 ~19 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-31 ~19 ~31 ~-31 ~19 minecraft:air
setblock ~32 ~-31 ~19 minecraft:light_gray_concrete
fill ~33 ~-31 ~19 ~35 ~-31 ~19 minecraft:air
setblock ~36 ~-31 ~19 minecraft:light_gray_concrete
fill ~37 ~-31 ~19 ~49 ~-31 ~19 minecraft:air
setblock ~50 ~-31 ~19 minecraft:light_gray_concrete
fill ~51 ~-31 ~19 ~63 ~-31 ~19 minecraft:air
setblock ~64 ~-31 ~19 minecraft:light_gray_concrete
setblock ~4 ~-31 ~20 minecraft:light_gray_concrete
fill ~5 ~-31 ~20 ~17 ~-31 ~20 minecraft:air
setblock ~18 ~-31 ~20 minecraft:light_gray_concrete
setblock ~19 ~-31 ~20 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-31 ~20 ~22 ~-31 ~20 minecraft:air
setblock ~23 ~-31 ~20 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-31 ~20 ~26 ~-31 ~20 minecraft:air
setblock ~27 ~-31 ~20 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-31 ~20 ~31 ~-31 ~20 minecraft:air
setblock ~32 ~-31 ~20 minecraft:light_gray_concrete
fill ~33 ~-31 ~20 ~35 ~-31 ~20 minecraft:air
setblock ~36 ~-31 ~20 minecraft:light_gray_concrete
fill ~37 ~-31 ~20 ~49 ~-31 ~20 minecraft:air
setblock ~50 ~-31 ~20 minecraft:light_gray_concrete
fill ~51 ~-31 ~20 ~63 ~-31 ~20 minecraft:air
setblock ~64 ~-31 ~20 minecraft:light_gray_concrete
setblock ~4 ~-31 ~21 minecraft:light_gray_concrete
fill ~5 ~-31 ~21 ~17 ~-31 ~21 minecraft:air
setblock ~18 ~-31 ~21 minecraft:light_gray_concrete
setblock ~19 ~-31 ~21 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-31 ~21 ~22 ~-31 ~21 minecraft:air
setblock ~23 ~-31 ~21 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-31 ~21 ~26 ~-31 ~21 minecraft:air
setblock ~27 ~-31 ~21 minecraft:iron_bars[north=true]
fill ~28 ~-31 ~21 ~31 ~-31 ~21 minecraft:air
setblock ~32 ~-31 ~21 minecraft:light_gray_concrete
setblock ~33 ~-31 ~21 minecraft:air
setblock ~34 ~-31 ~21 minecraft:smooth_quartz
setblock ~35 ~-31 ~21 minecraft:air
setblock ~36 ~-31 ~21 minecraft:light_gray_concrete
fill ~37 ~-31 ~21 ~42 ~-31 ~21 minecraft:air
setblock ~43 ~-31 ~21 minecraft:iron_bars[east=true]
setblock ~44 ~-31 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-31 ~21 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~46 ~-31 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~47 ~-31 ~21 minecraft:iron_bars[south=true,west=true]
fill ~48 ~-31 ~21 ~49 ~-31 ~21 minecraft:air
setblock ~50 ~-31 ~21 minecraft:light_gray_concrete
fill ~51 ~-31 ~21 ~63 ~-31 ~21 minecraft:air
setblock ~64 ~-31 ~21 minecraft:light_gray_concrete
setblock ~4 ~-31 ~22 minecraft:light_gray_concrete
fill ~5 ~-31 ~22 ~17 ~-31 ~22 minecraft:air
setblock ~18 ~-31 ~22 minecraft:light_gray_concrete
setblock ~19 ~-31 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~20 ~-31 ~22 ~22 ~-31 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-31 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~24 ~-31 ~22 ~25 ~-31 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~26 ~-31 ~22 minecraft:iron_bars[west=true]
fill ~27 ~-31 ~22 ~28 ~-31 ~22 minecraft:air
setblock ~29 ~-31 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-31 ~22 minecraft:quartz_pillar
setblock ~31 ~-31 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-31 ~22 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~33 ~-31 ~22 minecraft:smooth_quartz
setblock ~34 ~-31 ~22 minecraft:air
setblock ~35 ~-31 ~22 minecraft:smooth_quartz
setblock ~36 ~-31 ~22 minecraft:glass_pane[north=true,east=true,west=true]
fill ~37 ~-31 ~22 ~38 ~-31 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-31 ~22 minecraft:quartz_pillar
fill ~40 ~-31 ~22 ~44 ~-31 ~22 minecraft:air
setblock ~45 ~-31 ~22 minecraft:iron_bars[north=true]
setblock ~46 ~-31 ~22 minecraft:air
setblock ~47 ~-31 ~22 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-31 ~22 ~49 ~-31 ~22 minecraft:air
setblock ~50 ~-31 ~22 minecraft:light_gray_concrete
fill ~51 ~-31 ~22 ~63 ~-31 ~22 minecraft:air
setblock ~64 ~-31 ~22 minecraft:light_gray_concrete
setblock ~4 ~-31 ~23 minecraft:light_gray_concrete
fill ~5 ~-31 ~23 ~17 ~-31 ~23 minecraft:air
setblock ~18 ~-31 ~23 minecraft:light_gray_concrete
fill ~19 ~-31 ~23 ~27 ~-31 ~23 minecraft:air
setblock ~28 ~-31 ~23 minecraft:smooth_quartz
setblock ~29 ~-31 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-31 ~23 ~38 ~-31 ~23 minecraft:air
setblock ~39 ~-31 ~23 minecraft:quartz_pillar
setblock ~40 ~-31 ~23 minecraft:smooth_quartz
fill ~41 ~-31 ~23 ~45 ~-31 ~23 minecraft:air
setblock ~46 ~-31 ~23 minecraft:iron_bars[east=true]
setblock ~47 ~-31 ~23 minecraft:iron_bars[north=true,south=true,west=true]
fill ~48 ~-31 ~23 ~49 ~-31 ~23 minecraft:air
setblock ~50 ~-31 ~23 minecraft:light_gray_concrete
fill ~51 ~-31 ~23 ~63 ~-31 ~23 minecraft:air
setblock ~64 ~-31 ~23 minecraft:light_gray_concrete
setblock ~4 ~-31 ~24 minecraft:light_gray_concrete
fill ~5 ~-31 ~24 ~17 ~-31 ~24 minecraft:air
setblock ~18 ~-31 ~24 minecraft:light_gray_concrete
fill ~19 ~-31 ~24 ~25 ~-31 ~24 minecraft:air
setblock ~26 ~-31 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-31 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-31 ~24 ~29 ~-31 ~24 minecraft:air
setblock ~30 ~-31 ~24 minecraft:quartz_pillar
fill ~31 ~-31 ~24 ~37 ~-31 ~24 minecraft:air
setblock ~38 ~-31 ~24 minecraft:quartz_pillar
fill ~39 ~-31 ~24 ~40 ~-31 ~24 minecraft:air
setblock ~41 ~-31 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-31 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-31 ~24 ~46 ~-31 ~24 minecraft:air
setblock ~47 ~-31 ~24 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-31 ~24 ~49 ~-31 ~24 minecraft:air
setblock ~50 ~-31 ~24 minecraft:light_gray_concrete
fill ~51 ~-31 ~24 ~63 ~-31 ~24 minecraft:air
setblock ~64 ~-31 ~24 minecraft:light_gray_concrete
setblock ~4 ~-31 ~25 minecraft:light_gray_concrete
fill ~5 ~-31 ~25 ~17 ~-31 ~25 minecraft:air
setblock ~18 ~-31 ~25 minecraft:light_gray_concrete
fill ~19 ~-31 ~25 ~24 ~-31 ~25 minecraft:air
fill ~25 ~-31 ~25 ~26 ~-31 ~25 minecraft:quartz_pillar
fill ~27 ~-31 ~25 ~41 ~-31 ~25 minecraft:air
setblock ~42 ~-31 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-31 ~25 minecraft:quartz_pillar
fill ~44 ~-31 ~25 ~46 ~-31 ~25 minecraft:air
setblock ~47 ~-31 ~25 minecraft:iron_bars[north=true]
fill ~48 ~-31 ~25 ~49 ~-31 ~25 minecraft:air
setblock ~50 ~-31 ~25 minecraft:light_gray_concrete
fill ~51 ~-31 ~25 ~63 ~-31 ~25 minecraft:air
setblock ~64 ~-31 ~25 minecraft:light_gray_concrete
setblock ~4 ~-31 ~26 minecraft:light_gray_concrete
fill ~5 ~-31 ~26 ~17 ~-31 ~26 minecraft:air
setblock ~18 ~-31 ~26 minecraft:light_gray_concrete
fill ~19 ~-31 ~26 ~23 ~-31 ~26 minecraft:air
setblock ~24 ~-31 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-31 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-31 ~26 ~42 ~-31 ~26 minecraft:air
setblock ~43 ~-31 ~26 minecraft:quartz_pillar
setblock ~44 ~-31 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-31 ~26 ~49 ~-31 ~26 minecraft:air
setblock ~50 ~-31 ~26 minecraft:light_gray_concrete
fill ~51 ~-31 ~26 ~63 ~-31 ~26 minecraft:air
setblock ~64 ~-31 ~26 minecraft:light_gray_concrete
setblock ~4 ~-31 ~27 minecraft:light_gray_concrete
fill ~5 ~-31 ~27 ~17 ~-31 ~27 minecraft:air
setblock ~18 ~-31 ~27 minecraft:light_gray_concrete
fill ~19 ~-31 ~27 ~23 ~-31 ~27 minecraft:air
setblock ~24 ~-31 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-31 ~27 ~43 ~-31 ~27 minecraft:air
setblock ~44 ~-31 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-31 ~27 ~49 ~-31 ~27 minecraft:air
setblock ~50 ~-31 ~27 minecraft:light_gray_concrete
fill ~51 ~-31 ~27 ~63 ~-31 ~27 minecraft:air
setblock ~64 ~-31 ~27 minecraft:light_gray_concrete
setblock ~4 ~-31 ~28 minecraft:light_gray_concrete
fill ~5 ~-31 ~28 ~17 ~-31 ~28 minecraft:air
setblock ~18 ~-31 ~28 minecraft:light_gray_concrete
fill ~19 ~-31 ~28 ~22 ~-31 ~28 minecraft:air
setblock ~23 ~-31 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-31 ~28 ~44 ~-31 ~28 minecraft:air
setblock ~45 ~-31 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-31 ~28 ~49 ~-31 ~28 minecraft:air
setblock ~50 ~-31 ~28 minecraft:light_gray_concrete
fill ~51 ~-31 ~28 ~63 ~-31 ~28 minecraft:air
setblock ~64 ~-31 ~28 minecraft:light_gray_concrete
setblock ~4 ~-31 ~29 minecraft:light_gray_concrete
fill ~5 ~-31 ~29 ~17 ~-31 ~29 minecraft:air
setblock ~18 ~-31 ~29 minecraft:light_gray_concrete
fill ~19 ~-31 ~29 ~21 ~-31 ~29 minecraft:air
fill ~22 ~-31 ~29 ~23 ~-31 ~29 minecraft:quartz_pillar
fill ~24 ~-31 ~29 ~44 ~-31 ~29 minecraft:air
setblock ~45 ~-31 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-31 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-31 ~29 ~49 ~-31 ~29 minecraft:air
setblock ~50 ~-31 ~29 minecraft:light_gray_concrete
fill ~51 ~-31 ~29 ~63 ~-31 ~29 minecraft:air
setblock ~64 ~-31 ~29 minecraft:light_gray_concrete
setblock ~4 ~-31 ~30 minecraft:light_gray_concrete
fill ~5 ~-31 ~30 ~17 ~-31 ~30 minecraft:air
setblock ~18 ~-31 ~30 minecraft:light_gray_concrete
fill ~19 ~-31 ~30 ~21 ~-31 ~30 minecraft:air
setblock ~22 ~-31 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-31 ~30 minecraft:air
setblock ~24 ~-31 ~30 minecraft:quartz_pillar
fill ~25 ~-31 ~30 ~43 ~-31 ~30 minecraft:air
setblock ~44 ~-31 ~30 minecraft:quartz_pillar
setblock ~45 ~-31 ~30 minecraft:air
setblock ~46 ~-31 ~30 minecraft:quartz_pillar
fill ~47 ~-31 ~30 ~49 ~-31 ~30 minecraft:air
setblock ~50 ~-31 ~30 minecraft:light_gray_concrete
fill ~51 ~-31 ~30 ~63 ~-31 ~30 minecraft:air
setblock ~64 ~-31 ~30 minecraft:light_gray_concrete
setblock ~4 ~-31 ~31 minecraft:light_gray_concrete
fill ~5 ~-31 ~31 ~17 ~-31 ~31 minecraft:air
setblock ~18 ~-31 ~31 minecraft:light_gray_concrete
fill ~19 ~-31 ~31 ~21 ~-31 ~31 minecraft:air
setblock ~22 ~-31 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-31 ~31 ~45 ~-31 ~31 minecraft:air
setblock ~46 ~-31 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-31 ~31 ~49 ~-31 ~31 minecraft:air
setblock ~50 ~-31 ~31 minecraft:light_gray_concrete
fill ~51 ~-31 ~31 ~63 ~-31 ~31 minecraft:air
setblock ~64 ~-31 ~31 minecraft:light_gray_concrete
fill ~4 ~-31 ~32 ~21 ~-31 ~32 minecraft:light_gray_concrete
setblock ~22 ~-31 ~32 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-31 ~32 ~32 ~-31 ~32 minecraft:air
fill ~33 ~-31 ~32 ~35 ~-31 ~32 minecraft:glass
fill ~36 ~-31 ~32 ~45 ~-31 ~32 minecraft:air
setblock ~46 ~-31 ~32 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-31 ~32 ~64 ~-31 ~32 minecraft:light_gray_concrete
setblock ~4 ~-31 ~33 minecraft:light_gray_concrete
fill ~5 ~-31 ~33 ~21 ~-31 ~33 minecraft:air
setblock ~22 ~-31 ~33 minecraft:smooth_quartz
fill ~23 ~-31 ~33 ~32 ~-31 ~33 minecraft:air
setblock ~33 ~-31 ~33 minecraft:glass
setblock ~34 ~-31 ~33 minecraft:air
setblock ~35 ~-31 ~33 minecraft:glass
fill ~36 ~-31 ~33 ~45 ~-31 ~33 minecraft:air
setblock ~46 ~-31 ~33 minecraft:smooth_quartz
fill ~47 ~-31 ~33 ~63 ~-31 ~33 minecraft:air
setblock ~64 ~-31 ~33 minecraft:light_gray_concrete
setblock ~4 ~-31 ~34 minecraft:light_gray_concrete
fill ~5 ~-31 ~34 ~20 ~-31 ~34 minecraft:air
setblock ~21 ~-31 ~34 minecraft:smooth_quartz
fill ~22 ~-31 ~34 ~32 ~-31 ~34 minecraft:air
fill ~33 ~-31 ~34 ~35 ~-31 ~34 minecraft:glass
fill ~36 ~-31 ~34 ~46 ~-31 ~34 minecraft:air
setblock ~47 ~-31 ~34 minecraft:smooth_quartz
fill ~48 ~-31 ~34 ~63 ~-31 ~34 minecraft:air
setblock ~64 ~-31 ~34 minecraft:light_gray_concrete
setblock ~4 ~-31 ~35 minecraft:light_gray_concrete
fill ~5 ~-31 ~35 ~21 ~-31 ~35 minecraft:air
setblock ~22 ~-31 ~35 minecraft:smooth_quartz
fill ~23 ~-31 ~35 ~32 ~-31 ~35 minecraft:air
setblock ~33 ~-31 ~35 minecraft:glass
setblock ~34 ~-31 ~35 minecraft:air
setblock ~35 ~-31 ~35 minecraft:glass
fill ~36 ~-31 ~35 ~45 ~-31 ~35 minecraft:air
setblock ~46 ~-31 ~35 minecraft:smooth_quartz
fill ~47 ~-31 ~35 ~63 ~-31 ~35 minecraft:air
setblock ~64 ~-31 ~35 minecraft:light_gray_concrete
fill ~4 ~-31 ~36 ~21 ~-31 ~36 minecraft:light_gray_concrete
setblock ~22 ~-31 ~36 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-31 ~36 ~32 ~-31 ~36 minecraft:air
fill ~33 ~-31 ~36 ~35 ~-31 ~36 minecraft:glass
fill ~36 ~-31 ~36 ~45 ~-31 ~36 minecraft:air
setblock ~46 ~-31 ~36 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-31 ~36 ~64 ~-31 ~36 minecraft:light_gray_concrete
setblock ~4 ~-31 ~37 minecraft:light_gray_concrete
fill ~5 ~-31 ~37 ~17 ~-31 ~37 minecraft:air
setblock ~18 ~-31 ~37 minecraft:light_gray_concrete
fill ~19 ~-31 ~37 ~21 ~-31 ~37 minecraft:air
setblock ~22 ~-31 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-31 ~37 ~45 ~-31 ~37 minecraft:air
setblock ~46 ~-31 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-31 ~37 ~49 ~-31 ~37 minecraft:air
setblock ~50 ~-31 ~37 minecraft:light_gray_concrete
fill ~51 ~-31 ~37 ~63 ~-31 ~37 minecraft:air
setblock ~64 ~-31 ~37 minecraft:light_gray_concrete
setblock ~4 ~-31 ~38 minecraft:light_gray_concrete
fill ~5 ~-31 ~38 ~17 ~-31 ~38 minecraft:air
setblock ~18 ~-31 ~38 minecraft:light_gray_concrete
fill ~19 ~-31 ~38 ~21 ~-31 ~38 minecraft:air
setblock ~22 ~-31 ~38 minecraft:quartz_pillar
setblock ~23 ~-31 ~38 minecraft:air
setblock ~24 ~-31 ~38 minecraft:quartz_pillar
fill ~25 ~-31 ~38 ~43 ~-31 ~38 minecraft:air
setblock ~44 ~-31 ~38 minecraft:quartz_pillar
setblock ~45 ~-31 ~38 minecraft:air
setblock ~46 ~-31 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-31 ~38 ~49 ~-31 ~38 minecraft:air
setblock ~50 ~-31 ~38 minecraft:light_gray_concrete
fill ~51 ~-31 ~38 ~63 ~-31 ~38 minecraft:air
setblock ~64 ~-31 ~38 minecraft:light_gray_concrete
setblock ~4 ~-31 ~39 minecraft:light_gray_concrete
fill ~5 ~-31 ~39 ~17 ~-31 ~39 minecraft:air
setblock ~18 ~-31 ~39 minecraft:light_gray_concrete
fill ~19 ~-31 ~39 ~21 ~-31 ~39 minecraft:air
setblock ~22 ~-31 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-31 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-31 ~39 ~44 ~-31 ~39 minecraft:air
fill ~45 ~-31 ~39 ~46 ~-31 ~39 minecraft:quartz_pillar
fill ~47 ~-31 ~39 ~49 ~-31 ~39 minecraft:air
setblock ~50 ~-31 ~39 minecraft:light_gray_concrete
fill ~51 ~-31 ~39 ~63 ~-31 ~39 minecraft:air
setblock ~64 ~-31 ~39 minecraft:light_gray_concrete
setblock ~4 ~-31 ~40 minecraft:light_gray_concrete
fill ~5 ~-31 ~40 ~17 ~-31 ~40 minecraft:air
setblock ~18 ~-31 ~40 minecraft:light_gray_concrete
fill ~19 ~-31 ~40 ~22 ~-31 ~40 minecraft:air
setblock ~23 ~-31 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-31 ~40 ~44 ~-31 ~40 minecraft:air
setblock ~45 ~-31 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-31 ~40 ~49 ~-31 ~40 minecraft:air
setblock ~50 ~-31 ~40 minecraft:light_gray_concrete
fill ~51 ~-31 ~40 ~63 ~-31 ~40 minecraft:air
setblock ~64 ~-31 ~40 minecraft:light_gray_concrete
setblock ~4 ~-31 ~41 minecraft:light_gray_concrete
fill ~5 ~-31 ~41 ~17 ~-31 ~41 minecraft:air
setblock ~18 ~-31 ~41 minecraft:light_gray_concrete
fill ~19 ~-31 ~41 ~23 ~-31 ~41 minecraft:air
setblock ~24 ~-31 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-31 ~41 ~43 ~-31 ~41 minecraft:air
setblock ~44 ~-31 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-31 ~41 ~49 ~-31 ~41 minecraft:air
setblock ~50 ~-31 ~41 minecraft:light_gray_concrete
fill ~51 ~-31 ~41 ~63 ~-31 ~41 minecraft:air
setblock ~64 ~-31 ~41 minecraft:light_gray_concrete
setblock ~4 ~-31 ~42 minecraft:light_gray_concrete
fill ~5 ~-31 ~42 ~17 ~-31 ~42 minecraft:air
setblock ~18 ~-31 ~42 minecraft:light_gray_concrete
fill ~19 ~-31 ~42 ~23 ~-31 ~42 minecraft:air
setblock ~24 ~-31 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-31 ~42 minecraft:quartz_pillar
fill ~26 ~-31 ~42 ~42 ~-31 ~42 minecraft:air
setblock ~43 ~-31 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-31 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-31 ~42 ~49 ~-31 ~42 minecraft:air
setblock ~50 ~-31 ~42 minecraft:light_gray_concrete
fill ~51 ~-31 ~42 ~63 ~-31 ~42 minecraft:air
setblock ~64 ~-31 ~42 minecraft:light_gray_concrete
setblock ~4 ~-31 ~43 minecraft:light_gray_concrete
fill ~5 ~-31 ~43 ~17 ~-31 ~43 minecraft:air
setblock ~18 ~-31 ~43 minecraft:light_gray_concrete
fill ~19 ~-31 ~43 ~20 ~-31 ~43 minecraft:air
setblock ~21 ~-31 ~43 minecraft:iron_bars[south=true]
fill ~22 ~-31 ~43 ~24 ~-31 ~43 minecraft:air
setblock ~25 ~-31 ~43 minecraft:quartz_pillar
setblock ~26 ~-31 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-31 ~43 ~41 ~-31 ~43 minecraft:air
fill ~42 ~-31 ~43 ~43 ~-31 ~43 minecraft:quartz_pillar
fill ~44 ~-31 ~43 ~49 ~-31 ~43 minecraft:air
setblock ~50 ~-31 ~43 minecraft:light_gray_concrete
fill ~51 ~-31 ~43 ~63 ~-31 ~43 minecraft:air
setblock ~64 ~-31 ~43 minecraft:light_gray_concrete
setblock ~4 ~-31 ~44 minecraft:light_gray_concrete
fill ~5 ~-31 ~44 ~17 ~-31 ~44 minecraft:air
setblock ~18 ~-31 ~44 minecraft:light_gray_concrete
fill ~19 ~-31 ~44 ~20 ~-31 ~44 minecraft:air
setblock ~21 ~-31 ~44 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-31 ~44 ~25 ~-31 ~44 minecraft:air
setblock ~26 ~-31 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-31 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-31 ~44 ~29 ~-31 ~44 minecraft:air
setblock ~30 ~-31 ~44 minecraft:quartz_pillar
fill ~31 ~-31 ~44 ~37 ~-31 ~44 minecraft:air
setblock ~38 ~-31 ~44 minecraft:quartz_pillar
fill ~39 ~-31 ~44 ~40 ~-31 ~44 minecraft:air
setblock ~41 ~-31 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-31 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-31 ~44 ~49 ~-31 ~44 minecraft:air
setblock ~50 ~-31 ~44 minecraft:light_gray_concrete
fill ~51 ~-31 ~44 ~63 ~-31 ~44 minecraft:air
setblock ~64 ~-31 ~44 minecraft:light_gray_concrete
setblock ~4 ~-31 ~45 minecraft:light_gray_concrete
fill ~5 ~-31 ~45 ~17 ~-31 ~45 minecraft:air
setblock ~18 ~-31 ~45 minecraft:light_gray_concrete
fill ~19 ~-31 ~45 ~20 ~-31 ~45 minecraft:air
setblock ~21 ~-31 ~45 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~22 ~-31 ~45 minecraft:iron_bars[west=true]
fill ~23 ~-31 ~45 ~27 ~-31 ~45 minecraft:air
setblock ~28 ~-31 ~45 minecraft:smooth_quartz
setblock ~29 ~-31 ~45 minecraft:quartz_pillar
fill ~30 ~-31 ~45 ~38 ~-31 ~45 minecraft:air
setblock ~39 ~-31 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-31 ~45 minecraft:smooth_quartz
fill ~41 ~-31 ~45 ~49 ~-31 ~45 minecraft:air
setblock ~50 ~-31 ~45 minecraft:light_gray_concrete
fill ~51 ~-31 ~45 ~63 ~-31 ~45 minecraft:air
setblock ~64 ~-31 ~45 minecraft:light_gray_concrete
setblock ~4 ~-31 ~46 minecraft:light_gray_concrete
fill ~5 ~-31 ~46 ~17 ~-31 ~46 minecraft:air
setblock ~18 ~-31 ~46 minecraft:light_gray_concrete
fill ~19 ~-31 ~46 ~20 ~-31 ~46 minecraft:air
setblock ~21 ~-31 ~46 minecraft:iron_bars[north=true,south=true]
setblock ~22 ~-31 ~46 minecraft:air
setblock ~23 ~-31 ~46 minecraft:iron_bars[south=true]
fill ~24 ~-31 ~46 ~28 ~-31 ~46 minecraft:air
setblock ~29 ~-31 ~46 minecraft:quartz_pillar
fill ~30 ~-31 ~46 ~31 ~-31 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-31 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~33 ~-31 ~46 minecraft:smooth_quartz
setblock ~34 ~-31 ~46 minecraft:air
setblock ~35 ~-31 ~46 minecraft:smooth_quartz
setblock ~36 ~-31 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~37 ~-31 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-31 ~46 minecraft:quartz_pillar
setblock ~39 ~-31 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-31 ~46 ~41 ~-31 ~46 minecraft:air
setblock ~42 ~-31 ~46 minecraft:iron_bars[east=true]
fill ~43 ~-31 ~46 ~44 ~-31 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-31 ~46 minecraft:iron_bars[east=true,south=true,west=true]
fill ~46 ~-31 ~46 ~48 ~-31 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~49 ~-31 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~50 ~-31 ~46 minecraft:light_gray_concrete
fill ~51 ~-31 ~46 ~63 ~-31 ~46 minecraft:air
setblock ~64 ~-31 ~46 minecraft:light_gray_concrete
setblock ~4 ~-31 ~47 minecraft:light_gray_concrete
fill ~5 ~-31 ~47 ~17 ~-31 ~47 minecraft:air
setblock ~18 ~-31 ~47 minecraft:light_gray_concrete
fill ~19 ~-31 ~47 ~20 ~-31 ~47 minecraft:air
setblock ~21 ~-31 ~47 minecraft:iron_bars[north=true,east=true]
setblock ~22 ~-31 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-31 ~47 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-31 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-31 ~47 minecraft:iron_bars[west=true]
fill ~26 ~-31 ~47 ~31 ~-31 ~47 minecraft:air
setblock ~32 ~-31 ~47 minecraft:light_gray_concrete
setblock ~33 ~-31 ~47 minecraft:air
setblock ~34 ~-31 ~47 minecraft:smooth_quartz
setblock ~35 ~-31 ~47 minecraft:air
setblock ~36 ~-31 ~47 minecraft:light_gray_concrete
fill ~37 ~-31 ~47 ~40 ~-31 ~47 minecraft:air
setblock ~41 ~-31 ~47 minecraft:iron_bars[south=true]
fill ~42 ~-31 ~47 ~44 ~-31 ~47 minecraft:air
setblock ~45 ~-31 ~47 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-31 ~47 ~48 ~-31 ~47 minecraft:air
setblock ~49 ~-31 ~47 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-31 ~47 minecraft:light_gray_concrete
fill ~51 ~-31 ~47 ~63 ~-31 ~47 minecraft:air
setblock ~64 ~-31 ~47 minecraft:light_gray_concrete
setblock ~4 ~-31 ~48 minecraft:light_gray_concrete
fill ~5 ~-31 ~48 ~17 ~-31 ~48 minecraft:air
setblock ~18 ~-31 ~48 minecraft:light_gray_concrete
fill ~19 ~-31 ~48 ~31 ~-31 ~48 minecraft:air
setblock ~32 ~-31 ~48 minecraft:light_gray_concrete
fill ~33 ~-31 ~48 ~35 ~-31 ~48 minecraft:air
setblock ~36 ~-31 ~48 minecraft:light_gray_concrete
fill ~37 ~-31 ~48 ~40 ~-31 ~48 minecraft:air
setblock ~41 ~-31 ~48 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-31 ~48 ~44 ~-31 ~48 minecraft:air
setblock ~45 ~-31 ~48 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-31 ~48 ~48 ~-31 ~48 minecraft:air
setblock ~49 ~-31 ~48 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-31 ~48 minecraft:light_gray_concrete
fill ~51 ~-31 ~48 ~63 ~-31 ~48 minecraft:air
setblock ~64 ~-31 ~48 minecraft:light_gray_concrete
setblock ~4 ~-31 ~49 minecraft:light_gray_concrete
fill ~5 ~-31 ~49 ~17 ~-31 ~49 minecraft:air
setblock ~18 ~-31 ~49 minecraft:light_gray_concrete
fill ~19 ~-31 ~49 ~31 ~-31 ~49 minecraft:air
setblock ~32 ~-31 ~49 minecraft:light_gray_concrete
fill ~33 ~-31 ~49 ~35 ~-31 ~49 minecraft:air
setblock ~36 ~-31 ~49 minecraft:light_gray_concrete
fill ~37 ~-31 ~49 ~40 ~-31 ~49 minecraft:air
setblock ~41 ~-31 ~49 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-31 ~49 ~44 ~-31 ~49 minecraft:air
setblock ~45 ~-31 ~49 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-31 ~49 ~48 ~-31 ~49 minecraft:air
setblock ~49 ~-31 ~49 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-31 ~49 minecraft:light_gray_concrete
fill ~51 ~-31 ~49 ~63 ~-31 ~49 minecraft:air
setblock ~64 ~-31 ~49 minecraft:light_gray_concrete
fill ~4 ~-31 ~50 ~32 ~-31 ~50 minecraft:light_gray_concrete
fill ~33 ~-31 ~50 ~35 ~-31 ~50 minecraft:air
fill ~36 ~-31 ~50 ~64 ~-31 ~50 minecraft:light_gray_concrete
setblock ~4 ~-31 ~51 minecraft:light_gray_concrete
fill ~5 ~-31 ~51 ~17 ~-31 ~51 minecraft:air
setblock ~18 ~-31 ~51 minecraft:light_gray_concrete
fill ~19 ~-31 ~51 ~31 ~-31 ~51 minecraft:air
setblock ~32 ~-31 ~51 minecraft:light_gray_concrete
fill ~33 ~-31 ~51 ~35 ~-31 ~51 minecraft:air
setblock ~36 ~-31 ~51 minecraft:light_gray_concrete
fill ~37 ~-31 ~51 ~49 ~-31 ~51 minecraft:air
setblock ~50 ~-31 ~51 minecraft:light_gray_concrete
fill ~51 ~-31 ~51 ~63 ~-31 ~51 minecraft:air
setblock ~64 ~-31 ~51 minecraft:light_gray_concrete
setblock ~4 ~-31 ~52 minecraft:light_gray_concrete
fill ~5 ~-31 ~52 ~17 ~-31 ~52 minecraft:air
setblock ~18 ~-31 ~52 minecraft:light_gray_concrete
fill ~19 ~-31 ~52 ~31 ~-31 ~52 minecraft:air
setblock ~32 ~-31 ~52 minecraft:light_gray_concrete
fill ~33 ~-31 ~52 ~35 ~-31 ~52 minecraft:air
setblock ~36 ~-31 ~52 minecraft:light_gray_concrete
fill ~37 ~-31 ~52 ~49 ~-31 ~52 minecraft:air
setblock ~50 ~-31 ~52 minecraft:light_gray_concrete
fill ~51 ~-31 ~52 ~63 ~-31 ~52 minecraft:air
setblock ~64 ~-31 ~52 minecraft:light_gray_concrete
setblock ~4 ~-31 ~53 minecraft:light_gray_concrete
fill ~5 ~-31 ~53 ~17 ~-31 ~53 minecraft:air
setblock ~18 ~-31 ~53 minecraft:light_gray_concrete
fill ~19 ~-31 ~53 ~31 ~-31 ~53 minecraft:air
setblock ~32 ~-31 ~53 minecraft:light_gray_concrete
fill ~33 ~-31 ~53 ~35 ~-31 ~53 minecraft:air
setblock ~36 ~-31 ~53 minecraft:light_gray_concrete
fill ~37 ~-31 ~53 ~49 ~-31 ~53 minecraft:air
setblock ~50 ~-31 ~53 minecraft:light_gray_concrete
fill ~51 ~-31 ~53 ~63 ~-31 ~53 minecraft:air
setblock ~64 ~-31 ~53 minecraft:light_gray_concrete
setblock ~4 ~-31 ~54 minecraft:light_gray_concrete
fill ~5 ~-31 ~54 ~17 ~-31 ~54 minecraft:air
setblock ~18 ~-31 ~54 minecraft:light_gray_concrete
fill ~19 ~-31 ~54 ~31 ~-31 ~54 minecraft:air
setblock ~32 ~-31 ~54 minecraft:light_gray_concrete
fill ~33 ~-31 ~54 ~35 ~-31 ~54 minecraft:air
setblock ~36 ~-31 ~54 minecraft:light_gray_concrete
fill ~37 ~-31 ~54 ~49 ~-31 ~54 minecraft:air
setblock ~50 ~-31 ~54 minecraft:light_gray_concrete
fill ~51 ~-31 ~54 ~63 ~-31 ~54 minecraft:air
setblock ~64 ~-31 ~54 minecraft:light_gray_concrete
setblock ~4 ~-31 ~55 minecraft:light_gray_concrete
fill ~5 ~-31 ~55 ~17 ~-31 ~55 minecraft:air
setblock ~18 ~-31 ~55 minecraft:light_gray_concrete
fill ~19 ~-31 ~55 ~31 ~-31 ~55 minecraft:air
setblock ~32 ~-31 ~55 minecraft:light_gray_concrete
fill ~33 ~-31 ~55 ~35 ~-31 ~55 minecraft:air
setblock ~36 ~-31 ~55 minecraft:light_gray_concrete
fill ~37 ~-31 ~55 ~49 ~-31 ~55 minecraft:air
setblock ~50 ~-31 ~55 minecraft:light_gray_concrete
fill ~51 ~-31 ~55 ~63 ~-31 ~55 minecraft:air
setblock ~64 ~-31 ~55 minecraft:light_gray_concrete
setblock ~4 ~-31 ~56 minecraft:light_gray_concrete
fill ~5 ~-31 ~56 ~17 ~-31 ~56 minecraft:air
setblock ~18 ~-31 ~56 minecraft:light_gray_concrete
fill ~19 ~-31 ~56 ~31 ~-31 ~56 minecraft:air
setblock ~32 ~-31 ~56 minecraft:light_gray_concrete
fill ~33 ~-31 ~56 ~35 ~-31 ~56 minecraft:air
setblock ~36 ~-31 ~56 minecraft:light_gray_concrete
fill ~37 ~-31 ~56 ~49 ~-31 ~56 minecraft:air
setblock ~50 ~-31 ~56 minecraft:light_gray_concrete
fill ~51 ~-31 ~56 ~63 ~-31 ~56 minecraft:air
setblock ~64 ~-31 ~56 minecraft:light_gray_concrete
setblock ~4 ~-31 ~57 minecraft:light_gray_concrete
fill ~5 ~-31 ~57 ~17 ~-31 ~57 minecraft:air
setblock ~18 ~-31 ~57 minecraft:light_gray_concrete
fill ~19 ~-31 ~57 ~31 ~-31 ~57 minecraft:air
setblock ~32 ~-31 ~57 minecraft:light_gray_concrete
fill ~33 ~-31 ~57 ~35 ~-31 ~57 minecraft:air
setblock ~36 ~-31 ~57 minecraft:light_gray_concrete
fill ~37 ~-31 ~57 ~49 ~-31 ~57 minecraft:air
setblock ~50 ~-31 ~57 minecraft:light_gray_concrete
fill ~51 ~-31 ~57 ~63 ~-31 ~57 minecraft:air
setblock ~64 ~-31 ~57 minecraft:light_gray_concrete
setblock ~4 ~-31 ~58 minecraft:light_gray_concrete
fill ~5 ~-31 ~58 ~17 ~-31 ~58 minecraft:air
setblock ~18 ~-31 ~58 minecraft:light_gray_concrete
fill ~19 ~-31 ~58 ~31 ~-31 ~58 minecraft:air
setblock ~32 ~-31 ~58 minecraft:light_gray_concrete
fill ~33 ~-31 ~58 ~35 ~-31 ~58 minecraft:air
setblock ~36 ~-31 ~58 minecraft:light_gray_concrete
fill ~37 ~-31 ~58 ~49 ~-31 ~58 minecraft:air
setblock ~50 ~-31 ~58 minecraft:light_gray_concrete
fill ~51 ~-31 ~58 ~63 ~-31 ~58 minecraft:air
setblock ~64 ~-31 ~58 minecraft:light_gray_concrete
setblock ~4 ~-31 ~59 minecraft:light_gray_concrete
fill ~5 ~-31 ~59 ~17 ~-31 ~59 minecraft:air
setblock ~18 ~-31 ~59 minecraft:light_gray_concrete
fill ~19 ~-31 ~59 ~31 ~-31 ~59 minecraft:air
setblock ~32 ~-31 ~59 minecraft:light_gray_concrete
fill ~33 ~-31 ~59 ~35 ~-31 ~59 minecraft:air
setblock ~36 ~-31 ~59 minecraft:light_gray_concrete
fill ~37 ~-31 ~59 ~49 ~-31 ~59 minecraft:air
setblock ~50 ~-31 ~59 minecraft:light_gray_concrete
fill ~51 ~-31 ~59 ~63 ~-31 ~59 minecraft:air
setblock ~64 ~-31 ~59 minecraft:light_gray_concrete
setblock ~4 ~-31 ~60 minecraft:light_gray_concrete
fill ~5 ~-31 ~60 ~17 ~-31 ~60 minecraft:air
setblock ~18 ~-31 ~60 minecraft:light_gray_concrete
fill ~19 ~-31 ~60 ~31 ~-31 ~60 minecraft:air
setblock ~32 ~-31 ~60 minecraft:light_gray_concrete
fill ~33 ~-31 ~60 ~35 ~-31 ~60 minecraft:air
setblock ~36 ~-31 ~60 minecraft:light_gray_concrete
fill ~37 ~-31 ~60 ~49 ~-31 ~60 minecraft:air
setblock ~50 ~-31 ~60 minecraft:light_gray_concrete
fill ~51 ~-31 ~60 ~63 ~-31 ~60 minecraft:air
setblock ~64 ~-31 ~60 minecraft:light_gray_concrete
setblock ~4 ~-31 ~61 minecraft:light_gray_concrete
fill ~5 ~-31 ~61 ~17 ~-31 ~61 minecraft:air
setblock ~18 ~-31 ~61 minecraft:light_gray_concrete
fill ~19 ~-31 ~61 ~31 ~-31 ~61 minecraft:air
setblock ~32 ~-31 ~61 minecraft:light_gray_concrete
fill ~33 ~-31 ~61 ~35 ~-31 ~61 minecraft:air
setblock ~36 ~-31 ~61 minecraft:light_gray_concrete
fill ~37 ~-31 ~61 ~49 ~-31 ~61 minecraft:air
setblock ~50 ~-31 ~61 minecraft:light_gray_concrete
fill ~51 ~-31 ~61 ~63 ~-31 ~61 minecraft:air
setblock ~64 ~-31 ~61 minecraft:light_gray_concrete
setblock ~4 ~-31 ~62 minecraft:light_gray_concrete
fill ~5 ~-31 ~62 ~17 ~-31 ~62 minecraft:air
setblock ~18 ~-31 ~62 minecraft:light_gray_concrete
fill ~19 ~-31 ~62 ~31 ~-31 ~62 minecraft:air
setblock ~32 ~-31 ~62 minecraft:light_gray_concrete
fill ~33 ~-31 ~62 ~35 ~-31 ~62 minecraft:air
setblock ~36 ~-31 ~62 minecraft:light_gray_concrete
fill ~37 ~-31 ~62 ~49 ~-31 ~62 minecraft:air
setblock ~50 ~-31 ~62 minecraft:light_gray_concrete
fill ~51 ~-31 ~62 ~63 ~-31 ~62 minecraft:air
setblock ~64 ~-31 ~62 minecraft:light_gray_concrete
setblock ~4 ~-31 ~63 minecraft:light_gray_concrete
fill ~5 ~-31 ~63 ~17 ~-31 ~63 minecraft:air
setblock ~18 ~-31 ~63 minecraft:light_gray_concrete
fill ~19 ~-31 ~63 ~31 ~-31 ~63 minecraft:air
setblock ~32 ~-31 ~63 minecraft:light_gray_concrete
fill ~33 ~-31 ~63 ~35 ~-31 ~63 minecraft:air
setblock ~36 ~-31 ~63 minecraft:light_gray_concrete
fill ~37 ~-31 ~63 ~49 ~-31 ~63 minecraft:air
setblock ~50 ~-31 ~63 minecraft:light_gray_concrete
fill ~51 ~-31 ~63 ~63 ~-31 ~63 minecraft:air
setblock ~64 ~-31 ~63 minecraft:light_gray_concrete
fill ~4 ~-31 ~64 ~64 ~-31 ~64 minecraft:light_gray_concrete
fill ~32 ~-31 ~66 ~36 ~-31 ~66 minecraft:polished_andesite
setblock ~32 ~-31 ~67 minecraft:polished_andesite
fill ~33 ~-31 ~67 ~35 ~-31 ~67 minecraft:air
setblock ~36 ~-31 ~67 minecraft:polished_andesite
setblock ~32 ~-31 ~68 minecraft:polished_andesite
setblock ~33 ~-31 ~68 minecraft:air
setblock ~34 ~-31 ~68 minecraft:quartz_pillar
setblock ~35 ~-31 ~68 minecraft:air
setblock ~36 ~-31 ~68 minecraft:polished_andesite
setblock ~32 ~-31 ~69 minecraft:polished_andesite
setblock ~33 ~-31 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-31 ~69 ~35 ~-31 ~69 minecraft:air
setblock ~36 ~-31 ~69 minecraft:polished_andesite
fill ~32 ~-31 ~70 ~36 ~-31 ~70 minecraft:polished_andesite
fill ~4 ~-30 ~4 ~64 ~-30 ~4 minecraft:light_gray_concrete
setblock ~4 ~-30 ~5 minecraft:light_gray_concrete
fill ~5 ~-30 ~5 ~17 ~-30 ~5 minecraft:air
setblock ~18 ~-30 ~5 minecraft:light_gray_concrete
fill ~19 ~-30 ~5 ~31 ~-30 ~5 minecraft:air
setblock ~32 ~-30 ~5 minecraft:light_gray_concrete
fill ~33 ~-30 ~5 ~35 ~-30 ~5 minecraft:air
setblock ~36 ~-30 ~5 minecraft:light_gray_concrete
fill ~37 ~-30 ~5 ~49 ~-30 ~5 minecraft:air
setblock ~50 ~-30 ~5 minecraft:light_gray_concrete
setblock ~51 ~-30 ~5 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-30 ~5 ~54 ~-30 ~5 minecraft:air
setblock ~55 ~-30 ~5 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-30 ~5 ~58 ~-30 ~5 minecraft:air
setblock ~59 ~-30 ~5 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-30 ~5 ~62 ~-30 ~5 minecraft:air
setblock ~63 ~-30 ~5 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-30 ~5 minecraft:light_gray_concrete
setblock ~4 ~-30 ~6 minecraft:light_gray_concrete
fill ~5 ~-30 ~6 ~17 ~-30 ~6 minecraft:air
setblock ~18 ~-30 ~6 minecraft:light_gray_concrete
fill ~19 ~-30 ~6 ~31 ~-30 ~6 minecraft:air
setblock ~32 ~-30 ~6 minecraft:light_gray_concrete
fill ~33 ~-30 ~6 ~35 ~-30 ~6 minecraft:air
setblock ~36 ~-30 ~6 minecraft:light_gray_concrete
fill ~37 ~-30 ~6 ~49 ~-30 ~6 minecraft:air
setblock ~50 ~-30 ~6 minecraft:light_gray_concrete
setblock ~51 ~-30 ~6 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-30 ~6 ~54 ~-30 ~6 minecraft:air
setblock ~55 ~-30 ~6 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-30 ~6 ~58 ~-30 ~6 minecraft:air
setblock ~59 ~-30 ~6 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-30 ~6 ~62 ~-30 ~6 minecraft:air
setblock ~63 ~-30 ~6 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-30 ~6 minecraft:light_gray_concrete
setblock ~4 ~-30 ~7 minecraft:light_gray_concrete
fill ~5 ~-30 ~7 ~17 ~-30 ~7 minecraft:air
setblock ~18 ~-30 ~7 minecraft:light_gray_concrete
fill ~19 ~-30 ~7 ~31 ~-30 ~7 minecraft:air
setblock ~32 ~-30 ~7 minecraft:light_gray_concrete
fill ~33 ~-30 ~7 ~35 ~-30 ~7 minecraft:air
setblock ~36 ~-30 ~7 minecraft:light_gray_concrete
fill ~37 ~-30 ~7 ~49 ~-30 ~7 minecraft:air
setblock ~50 ~-30 ~7 minecraft:light_gray_concrete
setblock ~51 ~-30 ~7 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-30 ~7 ~54 ~-30 ~7 minecraft:air
setblock ~55 ~-30 ~7 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-30 ~7 ~58 ~-30 ~7 minecraft:air
setblock ~59 ~-30 ~7 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-30 ~7 ~62 ~-30 ~7 minecraft:air
setblock ~63 ~-30 ~7 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-30 ~7 minecraft:light_gray_concrete
setblock ~4 ~-30 ~8 minecraft:light_gray_concrete
fill ~5 ~-30 ~8 ~17 ~-30 ~8 minecraft:air
setblock ~18 ~-30 ~8 minecraft:light_gray_concrete
fill ~19 ~-30 ~8 ~23 ~-30 ~8 minecraft:air
setblock ~24 ~-30 ~8 minecraft:end_rod[facing=down]
fill ~25 ~-30 ~8 ~27 ~-30 ~8 minecraft:air
setblock ~28 ~-30 ~8 minecraft:end_rod[facing=down]
fill ~29 ~-30 ~8 ~31 ~-30 ~8 minecraft:air
setblock ~32 ~-30 ~8 minecraft:light_gray_concrete
fill ~33 ~-30 ~8 ~35 ~-30 ~8 minecraft:air
setblock ~36 ~-30 ~8 minecraft:light_gray_concrete
fill ~37 ~-30 ~8 ~49 ~-30 ~8 minecraft:air
setblock ~50 ~-30 ~8 minecraft:light_gray_concrete
setblock ~51 ~-30 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~52 ~-30 ~8 ~54 ~-30 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~55 ~-30 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~56 ~-30 ~8 ~58 ~-30 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~59 ~-30 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~60 ~-30 ~8 ~62 ~-30 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~63 ~-30 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~64 ~-30 ~8 minecraft:light_gray_concrete
setblock ~4 ~-30 ~9 minecraft:light_gray_concrete
fill ~5 ~-30 ~9 ~17 ~-30 ~9 minecraft:air
setblock ~18 ~-30 ~9 minecraft:light_gray_concrete
fill ~19 ~-30 ~9 ~22 ~-30 ~9 minecraft:air
setblock ~23 ~-30 ~9 minecraft:end_rod[facing=down]
fill ~24 ~-30 ~9 ~26 ~-30 ~9 minecraft:air
setblock ~27 ~-30 ~9 minecraft:end_rod[facing=down]
fill ~28 ~-30 ~9 ~31 ~-30 ~9 minecraft:air
setblock ~32 ~-30 ~9 minecraft:light_gray_concrete
fill ~33 ~-30 ~9 ~35 ~-30 ~9 minecraft:air
setblock ~36 ~-30 ~9 minecraft:light_gray_concrete
fill ~37 ~-30 ~9 ~49 ~-30 ~9 minecraft:air
setblock ~50 ~-30 ~9 minecraft:light_gray_concrete
fill ~51 ~-30 ~9 ~63 ~-30 ~9 minecraft:air
setblock ~64 ~-30 ~9 minecraft:light_gray_concrete
setblock ~4 ~-30 ~10 minecraft:light_gray_concrete
fill ~5 ~-30 ~10 ~17 ~-30 ~10 minecraft:air
setblock ~18 ~-30 ~10 minecraft:light_gray_concrete
fill ~19 ~-30 ~10 ~21 ~-30 ~10 minecraft:air
setblock ~22 ~-30 ~10 minecraft:end_rod[facing=down]
fill ~23 ~-30 ~10 ~25 ~-30 ~10 minecraft:air
setblock ~26 ~-30 ~10 minecraft:end_rod[facing=down]
fill ~27 ~-30 ~10 ~31 ~-30 ~10 minecraft:air
setblock ~32 ~-30 ~10 minecraft:light_gray_concrete
fill ~33 ~-30 ~10 ~35 ~-30 ~10 minecraft:air
setblock ~36 ~-30 ~10 minecraft:light_gray_concrete
fill ~37 ~-30 ~10 ~49 ~-30 ~10 minecraft:air
setblock ~50 ~-30 ~10 minecraft:light_gray_concrete
fill ~51 ~-30 ~10 ~63 ~-30 ~10 minecraft:air
setblock ~64 ~-30 ~10 minecraft:light_gray_concrete
setblock ~4 ~-30 ~11 minecraft:light_gray_concrete
fill ~5 ~-30 ~11 ~10 ~-30 ~11 minecraft:air
setblock ~11 ~-30 ~11 minecraft:end_rod[facing=down]
fill ~12 ~-30 ~11 ~17 ~-30 ~11 minecraft:air
setblock ~18 ~-30 ~11 minecraft:light_gray_concrete
fill ~19 ~-30 ~11 ~24 ~-30 ~11 minecraft:air
setblock ~25 ~-30 ~11 minecraft:end_rod[facing=down]
fill ~26 ~-30 ~11 ~31 ~-30 ~11 minecraft:air
setblock ~32 ~-30 ~11 minecraft:light_gray_concrete
fill ~33 ~-30 ~11 ~35 ~-30 ~11 minecraft:air
setblock ~36 ~-30 ~11 minecraft:light_gray_concrete
fill ~37 ~-30 ~11 ~49 ~-30 ~11 minecraft:air
setblock ~50 ~-30 ~11 minecraft:light_gray_concrete
fill ~51 ~-30 ~11 ~63 ~-30 ~11 minecraft:air
setblock ~64 ~-30 ~11 minecraft:light_gray_concrete
setblock ~4 ~-30 ~12 minecraft:light_gray_concrete
fill ~5 ~-30 ~12 ~10 ~-30 ~12 minecraft:air
setblock ~11 ~-30 ~12 minecraft:end_rod[facing=down]
fill ~12 ~-30 ~12 ~17 ~-30 ~12 minecraft:air
setblock ~18 ~-30 ~12 minecraft:light_gray_concrete
fill ~19 ~-30 ~12 ~23 ~-30 ~12 minecraft:air
setblock ~24 ~-30 ~12 minecraft:end_rod[facing=down]
fill ~25 ~-30 ~12 ~27 ~-30 ~12 minecraft:air
setblock ~28 ~-30 ~12 minecraft:end_rod[facing=down]
fill ~29 ~-30 ~12 ~31 ~-30 ~12 minecraft:air
setblock ~32 ~-30 ~12 minecraft:light_gray_concrete
fill ~33 ~-30 ~12 ~35 ~-30 ~12 minecraft:air
setblock ~36 ~-30 ~12 minecraft:light_gray_concrete
fill ~37 ~-30 ~12 ~49 ~-30 ~12 minecraft:air
setblock ~50 ~-30 ~12 minecraft:light_gray_concrete
fill ~51 ~-30 ~12 ~63 ~-30 ~12 minecraft:air
setblock ~64 ~-30 ~12 minecraft:light_gray_concrete
setblock ~4 ~-30 ~13 minecraft:light_gray_concrete
fill ~5 ~-30 ~13 ~17 ~-30 ~13 minecraft:air
setblock ~18 ~-30 ~13 minecraft:light_gray_concrete
fill ~19 ~-30 ~13 ~22 ~-30 ~13 minecraft:air
setblock ~23 ~-30 ~13 minecraft:end_rod[facing=down]
fill ~24 ~-30 ~13 ~26 ~-30 ~13 minecraft:air
setblock ~27 ~-30 ~13 minecraft:end_rod[facing=down]
fill ~28 ~-30 ~13 ~31 ~-30 ~13 minecraft:air
setblock ~32 ~-30 ~13 minecraft:light_gray_concrete
fill ~33 ~-30 ~13 ~35 ~-30 ~13 minecraft:air
setblock ~36 ~-30 ~13 minecraft:light_gray_concrete
fill ~37 ~-30 ~13 ~49 ~-30 ~13 minecraft:air
setblock ~50 ~-30 ~13 minecraft:light_gray_concrete
fill ~51 ~-30 ~13 ~63 ~-30 ~13 minecraft:air
setblock ~64 ~-30 ~13 minecraft:light_gray_concrete
setblock ~4 ~-30 ~14 minecraft:light_gray_concrete
fill ~5 ~-30 ~14 ~17 ~-30 ~14 minecraft:air
setblock ~18 ~-30 ~14 minecraft:light_gray_concrete
fill ~19 ~-30 ~14 ~21 ~-30 ~14 minecraft:air
setblock ~22 ~-30 ~14 minecraft:end_rod[facing=down]
fill ~23 ~-30 ~14 ~25 ~-30 ~14 minecraft:air
setblock ~26 ~-30 ~14 minecraft:end_rod[facing=down]
fill ~27 ~-30 ~14 ~31 ~-30 ~14 minecraft:air
setblock ~32 ~-30 ~14 minecraft:light_gray_concrete
fill ~33 ~-30 ~14 ~35 ~-30 ~14 minecraft:air
setblock ~36 ~-30 ~14 minecraft:light_gray_concrete
fill ~37 ~-30 ~14 ~49 ~-30 ~14 minecraft:air
setblock ~50 ~-30 ~14 minecraft:light_gray_concrete
fill ~51 ~-30 ~14 ~63 ~-30 ~14 minecraft:air
setblock ~64 ~-30 ~14 minecraft:light_gray_concrete
setblock ~4 ~-30 ~15 minecraft:light_gray_concrete
fill ~5 ~-30 ~15 ~17 ~-30 ~15 minecraft:air
setblock ~18 ~-30 ~15 minecraft:light_gray_concrete
fill ~19 ~-30 ~15 ~31 ~-30 ~15 minecraft:air
setblock ~32 ~-30 ~15 minecraft:light_gray_concrete
fill ~33 ~-30 ~15 ~35 ~-30 ~15 minecraft:air
setblock ~36 ~-30 ~15 minecraft:light_gray_concrete
fill ~37 ~-30 ~15 ~49 ~-30 ~15 minecraft:air
setblock ~50 ~-30 ~15 minecraft:light_gray_concrete
fill ~51 ~-30 ~15 ~63 ~-30 ~15 minecraft:air
setblock ~64 ~-30 ~15 minecraft:light_gray_concrete
setblock ~4 ~-30 ~16 minecraft:light_gray_concrete
fill ~5 ~-30 ~16 ~17 ~-30 ~16 minecraft:air
setblock ~18 ~-30 ~16 minecraft:light_gray_concrete
fill ~19 ~-30 ~16 ~31 ~-30 ~16 minecraft:air
setblock ~32 ~-30 ~16 minecraft:light_gray_concrete
fill ~33 ~-30 ~16 ~35 ~-30 ~16 minecraft:air
setblock ~36 ~-30 ~16 minecraft:light_gray_concrete
fill ~37 ~-30 ~16 ~49 ~-30 ~16 minecraft:air
setblock ~50 ~-30 ~16 minecraft:light_gray_concrete
fill ~51 ~-30 ~16 ~63 ~-30 ~16 minecraft:air
setblock ~64 ~-30 ~16 minecraft:light_gray_concrete
setblock ~4 ~-30 ~17 minecraft:light_gray_concrete
fill ~5 ~-30 ~17 ~17 ~-30 ~17 minecraft:air
setblock ~18 ~-30 ~17 minecraft:light_gray_concrete
fill ~19 ~-30 ~17 ~31 ~-30 ~17 minecraft:air
setblock ~32 ~-30 ~17 minecraft:light_gray_concrete
fill ~33 ~-30 ~17 ~35 ~-30 ~17 minecraft:air
setblock ~36 ~-30 ~17 minecraft:light_gray_concrete
fill ~37 ~-30 ~17 ~49 ~-30 ~17 minecraft:air
setblock ~50 ~-30 ~17 minecraft:light_gray_concrete
fill ~51 ~-30 ~17 ~63 ~-30 ~17 minecraft:air
setblock ~64 ~-30 ~17 minecraft:light_gray_concrete
fill ~4 ~-30 ~18 ~32 ~-30 ~18 minecraft:light_gray_concrete
fill ~33 ~-30 ~18 ~35 ~-30 ~18 minecraft:air
fill ~36 ~-30 ~18 ~64 ~-30 ~18 minecraft:light_gray_concrete
setblock ~4 ~-30 ~19 minecraft:light_gray_concrete
fill ~5 ~-30 ~19 ~17 ~-30 ~19 minecraft:air
setblock ~18 ~-30 ~19 minecraft:light_gray_concrete
setblock ~19 ~-30 ~19 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-30 ~19 ~22 ~-30 ~19 minecraft:air
setblock ~23 ~-30 ~19 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-30 ~19 ~26 ~-30 ~19 minecraft:air
setblock ~27 ~-30 ~19 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-30 ~19 ~31 ~-30 ~19 minecraft:air
setblock ~32 ~-30 ~19 minecraft:light_gray_concrete
fill ~33 ~-30 ~19 ~35 ~-30 ~19 minecraft:air
setblock ~36 ~-30 ~19 minecraft:light_gray_concrete
fill ~37 ~-30 ~19 ~49 ~-30 ~19 minecraft:air
setblock ~50 ~-30 ~19 minecraft:light_gray_concrete
fill ~51 ~-30 ~19 ~63 ~-30 ~19 minecraft:air
setblock ~64 ~-30 ~19 minecraft:light_gray_concrete
setblock ~4 ~-30 ~20 minecraft:light_gray_concrete
fill ~5 ~-30 ~20 ~17 ~-30 ~20 minecraft:air
setblock ~18 ~-30 ~20 minecraft:light_gray_concrete
setblock ~19 ~-30 ~20 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-30 ~20 ~22 ~-30 ~20 minecraft:air
setblock ~23 ~-30 ~20 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-30 ~20 ~26 ~-30 ~20 minecraft:air
setblock ~27 ~-30 ~20 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-30 ~20 ~31 ~-30 ~20 minecraft:air
setblock ~32 ~-30 ~20 minecraft:light_gray_concrete
fill ~33 ~-30 ~20 ~35 ~-30 ~20 minecraft:air
setblock ~36 ~-30 ~20 minecraft:light_gray_concrete
fill ~37 ~-30 ~20 ~49 ~-30 ~20 minecraft:air
setblock ~50 ~-30 ~20 minecraft:light_gray_concrete
fill ~51 ~-30 ~20 ~63 ~-30 ~20 minecraft:air
setblock ~64 ~-30 ~20 minecraft:light_gray_concrete
setblock ~4 ~-30 ~21 minecraft:light_gray_concrete
fill ~5 ~-30 ~21 ~17 ~-30 ~21 minecraft:air
setblock ~18 ~-30 ~21 minecraft:light_gray_concrete
setblock ~19 ~-30 ~21 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-30 ~21 ~22 ~-30 ~21 minecraft:air
setblock ~23 ~-30 ~21 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-30 ~21 ~26 ~-30 ~21 minecraft:air
setblock ~27 ~-30 ~21 minecraft:iron_bars[north=true]
fill ~28 ~-30 ~21 ~31 ~-30 ~21 minecraft:air
setblock ~32 ~-30 ~21 minecraft:light_gray_concrete
setblock ~33 ~-30 ~21 minecraft:air
setblock ~34 ~-30 ~21 minecraft:smooth_quartz
setblock ~35 ~-30 ~21 minecraft:air
setblock ~36 ~-30 ~21 minecraft:light_gray_concrete
fill ~37 ~-30 ~21 ~42 ~-30 ~21 minecraft:air
setblock ~43 ~-30 ~21 minecraft:iron_bars[east=true]
setblock ~44 ~-30 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-30 ~21 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~46 ~-30 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~47 ~-30 ~21 minecraft:iron_bars[south=true,west=true]
fill ~48 ~-30 ~21 ~49 ~-30 ~21 minecraft:air
setblock ~50 ~-30 ~21 minecraft:light_gray_concrete
fill ~51 ~-30 ~21 ~63 ~-30 ~21 minecraft:air
setblock ~64 ~-30 ~21 minecraft:light_gray_concrete
setblock ~4 ~-30 ~22 minecraft:light_gray_concrete
fill ~5 ~-30 ~22 ~17 ~-30 ~22 minecraft:air
setblock ~18 ~-30 ~22 minecraft:light_gray_concrete
setblock ~19 ~-30 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~20 ~-30 ~22 ~22 ~-30 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-30 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~24 ~-30 ~22 ~25 ~-30 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~26 ~-30 ~22 minecraft:iron_bars[west=true]
fill ~27 ~-30 ~22 ~28 ~-30 ~22 minecraft:air
fill ~29 ~-30 ~22 ~33 ~-30 ~22 minecraft:smooth_quartz
setblock ~34 ~-30 ~22 minecraft:air
fill ~35 ~-30 ~22 ~39 ~-30 ~22 minecraft:smooth_quartz
fill ~40 ~-30 ~22 ~44 ~-30 ~22 minecraft:air
setblock ~45 ~-30 ~22 minecraft:iron_bars[north=true]
setblock ~46 ~-30 ~22 minecraft:air
setblock ~47 ~-30 ~22 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-30 ~22 ~49 ~-30 ~22 minecraft:air
setblock ~50 ~-30 ~22 minecraft:light_gray_concrete
fill ~51 ~-30 ~22 ~63 ~-30 ~22 minecraft:air
setblock ~64 ~-30 ~22 minecraft:light_gray_concrete
setblock ~4 ~-30 ~23 minecraft:light_gray_concrete
fill ~5 ~-30 ~23 ~17 ~-30 ~23 minecraft:air
setblock ~18 ~-30 ~23 minecraft:light_gray_concrete
fill ~19 ~-30 ~23 ~27 ~-30 ~23 minecraft:air
fill ~28 ~-30 ~23 ~29 ~-30 ~23 minecraft:smooth_quartz
fill ~30 ~-30 ~23 ~38 ~-30 ~23 minecraft:air
fill ~39 ~-30 ~23 ~40 ~-30 ~23 minecraft:smooth_quartz
fill ~41 ~-30 ~23 ~45 ~-30 ~23 minecraft:air
setblock ~46 ~-30 ~23 minecraft:iron_bars[east=true]
setblock ~47 ~-30 ~23 minecraft:iron_bars[north=true,south=true,west=true]
fill ~48 ~-30 ~23 ~49 ~-30 ~23 minecraft:air
setblock ~50 ~-30 ~23 minecraft:light_gray_concrete
fill ~51 ~-30 ~23 ~63 ~-30 ~23 minecraft:air
setblock ~64 ~-30 ~23 minecraft:light_gray_concrete
setblock ~4 ~-30 ~24 minecraft:light_gray_concrete
fill ~5 ~-30 ~24 ~17 ~-30 ~24 minecraft:air
setblock ~18 ~-30 ~24 minecraft:light_gray_concrete
fill ~19 ~-30 ~24 ~25 ~-30 ~24 minecraft:air
fill ~26 ~-30 ~24 ~27 ~-30 ~24 minecraft:smooth_quartz
fill ~28 ~-30 ~24 ~29 ~-30 ~24 minecraft:air
setblock ~30 ~-30 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-30 ~24 ~37 ~-30 ~24 minecraft:air
setblock ~38 ~-30 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-30 ~24 ~40 ~-30 ~24 minecraft:air
fill ~41 ~-30 ~24 ~42 ~-30 ~24 minecraft:smooth_quartz
fill ~43 ~-30 ~24 ~46 ~-30 ~24 minecraft:air
setblock ~47 ~-30 ~24 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-30 ~24 ~49 ~-30 ~24 minecraft:air
setblock ~50 ~-30 ~24 minecraft:light_gray_concrete
fill ~51 ~-30 ~24 ~63 ~-30 ~24 minecraft:air
setblock ~64 ~-30 ~24 minecraft:light_gray_concrete
setblock ~4 ~-30 ~25 minecraft:light_gray_concrete
fill ~5 ~-30 ~25 ~17 ~-30 ~25 minecraft:air
setblock ~18 ~-30 ~25 minecraft:light_gray_concrete
fill ~19 ~-30 ~25 ~24 ~-30 ~25 minecraft:air
fill ~25 ~-30 ~25 ~26 ~-30 ~25 minecraft:smooth_quartz
fill ~27 ~-30 ~25 ~41 ~-30 ~25 minecraft:air
fill ~42 ~-30 ~25 ~43 ~-30 ~25 minecraft:smooth_quartz
fill ~44 ~-30 ~25 ~46 ~-30 ~25 minecraft:air
setblock ~47 ~-30 ~25 minecraft:iron_bars[north=true]
fill ~48 ~-30 ~25 ~49 ~-30 ~25 minecraft:air
setblock ~50 ~-30 ~25 minecraft:light_gray_concrete
fill ~51 ~-30 ~25 ~55 ~-30 ~25 minecraft:air
fill ~56 ~-30 ~25 ~57 ~-30 ~25 minecraft:end_rod[facing=down]
fill ~58 ~-30 ~25 ~63 ~-30 ~25 minecraft:air
setblock ~64 ~-30 ~25 minecraft:light_gray_concrete
setblock ~4 ~-30 ~26 minecraft:light_gray_concrete
fill ~5 ~-30 ~26 ~17 ~-30 ~26 minecraft:air
setblock ~18 ~-30 ~26 minecraft:light_gray_concrete
fill ~19 ~-30 ~26 ~23 ~-30 ~26 minecraft:air
fill ~24 ~-30 ~26 ~25 ~-30 ~26 minecraft:smooth_quartz
fill ~26 ~-30 ~26 ~42 ~-30 ~26 minecraft:air
fill ~43 ~-30 ~26 ~44 ~-30 ~26 minecraft:smooth_quartz
fill ~45 ~-30 ~26 ~49 ~-30 ~26 minecraft:air
setblock ~50 ~-30 ~26 minecraft:light_gray_concrete
fill ~51 ~-30 ~26 ~63 ~-30 ~26 minecraft:air
setblock ~64 ~-30 ~26 minecraft:light_gray_concrete
setblock ~4 ~-30 ~27 minecraft:light_gray_concrete
fill ~5 ~-30 ~27 ~17 ~-30 ~27 minecraft:air
setblock ~18 ~-30 ~27 minecraft:light_gray_concrete
fill ~19 ~-30 ~27 ~23 ~-30 ~27 minecraft:air
setblock ~24 ~-30 ~27 minecraft:smooth_quartz
fill ~25 ~-30 ~27 ~43 ~-30 ~27 minecraft:air
setblock ~44 ~-30 ~27 minecraft:smooth_quartz
fill ~45 ~-30 ~27 ~49 ~-30 ~27 minecraft:air
setblock ~50 ~-30 ~27 minecraft:light_gray_concrete
fill ~51 ~-30 ~27 ~63 ~-30 ~27 minecraft:air
setblock ~64 ~-30 ~27 minecraft:light_gray_concrete
setblock ~4 ~-30 ~28 minecraft:light_gray_concrete
fill ~5 ~-30 ~28 ~17 ~-30 ~28 minecraft:air
setblock ~18 ~-30 ~28 minecraft:light_gray_concrete
fill ~19 ~-30 ~28 ~22 ~-30 ~28 minecraft:air
setblock ~23 ~-30 ~28 minecraft:smooth_quartz
fill ~24 ~-30 ~28 ~44 ~-30 ~28 minecraft:air
setblock ~45 ~-30 ~28 minecraft:smooth_quartz
fill ~46 ~-30 ~28 ~49 ~-30 ~28 minecraft:air
setblock ~50 ~-30 ~28 minecraft:light_gray_concrete
fill ~51 ~-30 ~28 ~63 ~-30 ~28 minecraft:air
setblock ~64 ~-30 ~28 minecraft:light_gray_concrete
setblock ~4 ~-30 ~29 minecraft:light_gray_concrete
fill ~5 ~-30 ~29 ~17 ~-30 ~29 minecraft:air
setblock ~18 ~-30 ~29 minecraft:light_gray_concrete
fill ~19 ~-30 ~29 ~21 ~-30 ~29 minecraft:air
fill ~22 ~-30 ~29 ~23 ~-30 ~29 minecraft:smooth_quartz
fill ~24 ~-30 ~29 ~44 ~-30 ~29 minecraft:air
fill ~45 ~-30 ~29 ~46 ~-30 ~29 minecraft:smooth_quartz
fill ~47 ~-30 ~29 ~49 ~-30 ~29 minecraft:air
setblock ~50 ~-30 ~29 minecraft:light_gray_concrete
fill ~51 ~-30 ~29 ~63 ~-30 ~29 minecraft:air
setblock ~64 ~-30 ~29 minecraft:light_gray_concrete
setblock ~4 ~-30 ~30 minecraft:light_gray_concrete
fill ~5 ~-30 ~30 ~17 ~-30 ~30 minecraft:air
setblock ~18 ~-30 ~30 minecraft:light_gray_concrete
fill ~19 ~-30 ~30 ~21 ~-30 ~30 minecraft:air
setblock ~22 ~-30 ~30 minecraft:smooth_quartz
setblock ~23 ~-30 ~30 minecraft:air
setblock ~24 ~-30 ~30 minecraft:chiseled_quartz_block
fill ~25 ~-30 ~30 ~43 ~-30 ~30 minecraft:air
setblock ~44 ~-30 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-30 ~30 minecraft:air
setblock ~46 ~-30 ~30 minecraft:smooth_quartz
fill ~47 ~-30 ~30 ~49 ~-30 ~30 minecraft:air
setblock ~50 ~-30 ~30 minecraft:light_gray_concrete
fill ~51 ~-30 ~30 ~63 ~-30 ~30 minecraft:air
setblock ~64 ~-30 ~30 minecraft:light_gray_concrete
setblock ~4 ~-30 ~31 minecraft:light_gray_concrete
fill ~5 ~-30 ~31 ~17 ~-30 ~31 minecraft:air
setblock ~18 ~-30 ~31 minecraft:light_gray_concrete
fill ~19 ~-30 ~31 ~21 ~-30 ~31 minecraft:air
setblock ~22 ~-30 ~31 minecraft:smooth_quartz
fill ~23 ~-30 ~31 ~31 ~-30 ~31 minecraft:air
fill ~32 ~-30 ~31 ~36 ~-30 ~31 minecraft:sea_lantern
fill ~37 ~-30 ~31 ~45 ~-30 ~31 minecraft:air
setblock ~46 ~-30 ~31 minecraft:smooth_quartz
fill ~47 ~-30 ~31 ~49 ~-30 ~31 minecraft:air
setblock ~50 ~-30 ~31 minecraft:light_gray_concrete
fill ~51 ~-30 ~31 ~63 ~-30 ~31 minecraft:air
setblock ~64 ~-30 ~31 minecraft:light_gray_concrete
fill ~4 ~-30 ~32 ~21 ~-30 ~32 minecraft:light_gray_concrete
setblock ~22 ~-30 ~32 minecraft:smooth_quartz
fill ~23 ~-30 ~32 ~31 ~-30 ~32 minecraft:air
setblock ~32 ~-30 ~32 minecraft:sea_lantern
fill ~33 ~-30 ~32 ~35 ~-30 ~32 minecraft:glass
setblock ~36 ~-30 ~32 minecraft:sea_lantern
fill ~37 ~-30 ~32 ~45 ~-30 ~32 minecraft:air
setblock ~46 ~-30 ~32 minecraft:smooth_quartz
fill ~47 ~-30 ~32 ~64 ~-30 ~32 minecraft:light_gray_concrete
setblock ~4 ~-30 ~33 minecraft:light_gray_concrete
fill ~5 ~-30 ~33 ~21 ~-30 ~33 minecraft:air
setblock ~22 ~-30 ~33 minecraft:smooth_quartz
fill ~23 ~-30 ~33 ~31 ~-30 ~33 minecraft:air
setblock ~32 ~-30 ~33 minecraft:sea_lantern
setblock ~33 ~-30 ~33 minecraft:glass
setblock ~34 ~-30 ~33 minecraft:air
setblock ~35 ~-30 ~33 minecraft:glass
setblock ~36 ~-30 ~33 minecraft:sea_lantern
fill ~37 ~-30 ~33 ~45 ~-30 ~33 minecraft:air
setblock ~46 ~-30 ~33 minecraft:smooth_quartz
fill ~47 ~-30 ~33 ~63 ~-30 ~33 minecraft:air
setblock ~64 ~-30 ~33 minecraft:light_gray_concrete
setblock ~4 ~-30 ~34 minecraft:light_gray_concrete
fill ~5 ~-30 ~34 ~20 ~-30 ~34 minecraft:air
setblock ~21 ~-30 ~34 minecraft:smooth_quartz
fill ~22 ~-30 ~34 ~31 ~-30 ~34 minecraft:air
setblock ~32 ~-30 ~34 minecraft:sea_lantern
fill ~33 ~-30 ~34 ~35 ~-30 ~34 minecraft:glass
setblock ~36 ~-30 ~34 minecraft:sea_lantern
fill ~37 ~-30 ~34 ~46 ~-30 ~34 minecraft:air
setblock ~47 ~-30 ~34 minecraft:smooth_quartz
fill ~48 ~-30 ~34 ~63 ~-30 ~34 minecraft:air
setblock ~64 ~-30 ~34 minecraft:light_gray_concrete
setblock ~4 ~-30 ~35 minecraft:light_gray_concrete
fill ~5 ~-30 ~35 ~21 ~-30 ~35 minecraft:air
setblock ~22 ~-30 ~35 minecraft:smooth_quartz
fill ~23 ~-30 ~35 ~31 ~-30 ~35 minecraft:air
setblock ~32 ~-30 ~35 minecraft:sea_lantern
setblock ~33 ~-30 ~35 minecraft:glass
setblock ~34 ~-30 ~35 minecraft:air
setblock ~35 ~-30 ~35 minecraft:glass
setblock ~36 ~-30 ~35 minecraft:sea_lantern
fill ~37 ~-30 ~35 ~45 ~-30 ~35 minecraft:air
setblock ~46 ~-30 ~35 minecraft:smooth_quartz
fill ~47 ~-30 ~35 ~63 ~-30 ~35 minecraft:air
setblock ~64 ~-30 ~35 minecraft:light_gray_concrete
fill ~4 ~-30 ~36 ~21 ~-30 ~36 minecraft:light_gray_concrete
setblock ~22 ~-30 ~36 minecraft:smooth_quartz
fill ~23 ~-30 ~36 ~31 ~-30 ~36 minecraft:air
setblock ~32 ~-30 ~36 minecraft:sea_lantern
fill ~33 ~-30 ~36 ~35 ~-30 ~36 minecraft:glass
setblock ~36 ~-30 ~36 minecraft:sea_lantern
fill ~37 ~-30 ~36 ~45 ~-30 ~36 minecraft:air
setblock ~46 ~-30 ~36 minecraft:smooth_quartz
fill ~47 ~-30 ~36 ~64 ~-30 ~36 minecraft:light_gray_concrete
setblock ~4 ~-30 ~37 minecraft:light_gray_concrete
fill ~5 ~-30 ~37 ~17 ~-30 ~37 minecraft:air
setblock ~18 ~-30 ~37 minecraft:light_gray_concrete
fill ~19 ~-30 ~37 ~21 ~-30 ~37 minecraft:air
setblock ~22 ~-30 ~37 minecraft:smooth_quartz
fill ~23 ~-30 ~37 ~31 ~-30 ~37 minecraft:air
fill ~32 ~-30 ~37 ~36 ~-30 ~37 minecraft:sea_lantern
fill ~37 ~-30 ~37 ~45 ~-30 ~37 minecraft:air
setblock ~46 ~-30 ~37 minecraft:smooth_quartz
fill ~47 ~-30 ~37 ~49 ~-30 ~37 minecraft:air
setblock ~50 ~-30 ~37 minecraft:light_gray_concrete
fill ~51 ~-30 ~37 ~63 ~-30 ~37 minecraft:air
setblock ~64 ~-30 ~37 minecraft:light_gray_concrete
setblock ~4 ~-30 ~38 minecraft:light_gray_concrete
fill ~5 ~-30 ~38 ~17 ~-30 ~38 minecraft:air
setblock ~18 ~-30 ~38 minecraft:light_gray_concrete
fill ~19 ~-30 ~38 ~21 ~-30 ~38 minecraft:air
setblock ~22 ~-30 ~38 minecraft:smooth_quartz
setblock ~23 ~-30 ~38 minecraft:air
setblock ~24 ~-30 ~38 minecraft:chiseled_quartz_block
fill ~25 ~-30 ~38 ~43 ~-30 ~38 minecraft:air
setblock ~44 ~-30 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-30 ~38 minecraft:air
setblock ~46 ~-30 ~38 minecraft:smooth_quartz
fill ~47 ~-30 ~38 ~49 ~-30 ~38 minecraft:air
setblock ~50 ~-30 ~38 minecraft:light_gray_concrete
fill ~51 ~-30 ~38 ~63 ~-30 ~38 minecraft:air
setblock ~64 ~-30 ~38 minecraft:light_gray_concrete
setblock ~4 ~-30 ~39 minecraft:light_gray_concrete
fill ~5 ~-30 ~39 ~17 ~-30 ~39 minecraft:air
setblock ~18 ~-30 ~39 minecraft:light_gray_concrete
fill ~19 ~-30 ~39 ~21 ~-30 ~39 minecraft:air
fill ~22 ~-30 ~39 ~23 ~-30 ~39 minecraft:smooth_quartz
fill ~24 ~-30 ~39 ~44 ~-30 ~39 minecraft:air
fill ~45 ~-30 ~39 ~46 ~-30 ~39 minecraft:smooth_quartz
fill ~47 ~-30 ~39 ~49 ~-30 ~39 minecraft:air
setblock ~50 ~-30 ~39 minecraft:light_gray_concrete
fill ~51 ~-30 ~39 ~63 ~-30 ~39 minecraft:air
setblock ~64 ~-30 ~39 minecraft:light_gray_concrete
setblock ~4 ~-30 ~40 minecraft:light_gray_concrete
fill ~5 ~-30 ~40 ~17 ~-30 ~40 minecraft:air
setblock ~18 ~-30 ~40 minecraft:light_gray_concrete
fill ~19 ~-30 ~40 ~22 ~-30 ~40 minecraft:air
setblock ~23 ~-30 ~40 minecraft:smooth_quartz
fill ~24 ~-30 ~40 ~44 ~-30 ~40 minecraft:air
setblock ~45 ~-30 ~40 minecraft:smooth_quartz
fill ~46 ~-30 ~40 ~49 ~-30 ~40 minecraft:air
setblock ~50 ~-30 ~40 minecraft:light_gray_concrete
fill ~51 ~-30 ~40 ~63 ~-30 ~40 minecraft:air
setblock ~64 ~-30 ~40 minecraft:light_gray_concrete
setblock ~4 ~-30 ~41 minecraft:light_gray_concrete
fill ~5 ~-30 ~41 ~17 ~-30 ~41 minecraft:air
setblock ~18 ~-30 ~41 minecraft:light_gray_concrete
fill ~19 ~-30 ~41 ~23 ~-30 ~41 minecraft:air
setblock ~24 ~-30 ~41 minecraft:smooth_quartz
fill ~25 ~-30 ~41 ~43 ~-30 ~41 minecraft:air
setblock ~44 ~-30 ~41 minecraft:smooth_quartz
fill ~45 ~-30 ~41 ~49 ~-30 ~41 minecraft:air
setblock ~50 ~-30 ~41 minecraft:light_gray_concrete
fill ~51 ~-30 ~41 ~63 ~-30 ~41 minecraft:air
setblock ~64 ~-30 ~41 minecraft:light_gray_concrete
setblock ~4 ~-30 ~42 minecraft:light_gray_concrete
fill ~5 ~-30 ~42 ~17 ~-30 ~42 minecraft:air
setblock ~18 ~-30 ~42 minecraft:light_gray_concrete
fill ~19 ~-30 ~42 ~23 ~-30 ~42 minecraft:air
fill ~24 ~-30 ~42 ~25 ~-30 ~42 minecraft:smooth_quartz
fill ~26 ~-30 ~42 ~42 ~-30 ~42 minecraft:air
fill ~43 ~-30 ~42 ~44 ~-30 ~42 minecraft:smooth_quartz
fill ~45 ~-30 ~42 ~49 ~-30 ~42 minecraft:air
setblock ~50 ~-30 ~42 minecraft:light_gray_concrete
fill ~51 ~-30 ~42 ~63 ~-30 ~42 minecraft:air
setblock ~64 ~-30 ~42 minecraft:light_gray_concrete
setblock ~4 ~-30 ~43 minecraft:light_gray_concrete
fill ~5 ~-30 ~43 ~17 ~-30 ~43 minecraft:air
setblock ~18 ~-30 ~43 minecraft:light_gray_concrete
fill ~19 ~-30 ~43 ~20 ~-30 ~43 minecraft:air
setblock ~21 ~-30 ~43 minecraft:iron_bars[south=true]
fill ~22 ~-30 ~43 ~24 ~-30 ~43 minecraft:air
fill ~25 ~-30 ~43 ~26 ~-30 ~43 minecraft:smooth_quartz
fill ~27 ~-30 ~43 ~41 ~-30 ~43 minecraft:air
fill ~42 ~-30 ~43 ~43 ~-30 ~43 minecraft:smooth_quartz
fill ~44 ~-30 ~43 ~49 ~-30 ~43 minecraft:air
setblock ~50 ~-30 ~43 minecraft:light_gray_concrete
fill ~51 ~-30 ~43 ~63 ~-30 ~43 minecraft:air
setblock ~64 ~-30 ~43 minecraft:light_gray_concrete
setblock ~4 ~-30 ~44 minecraft:light_gray_concrete
fill ~5 ~-30 ~44 ~17 ~-30 ~44 minecraft:air
setblock ~18 ~-30 ~44 minecraft:light_gray_concrete
fill ~19 ~-30 ~44 ~20 ~-30 ~44 minecraft:air
setblock ~21 ~-30 ~44 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-30 ~44 ~25 ~-30 ~44 minecraft:air
fill ~26 ~-30 ~44 ~27 ~-30 ~44 minecraft:smooth_quartz
fill ~28 ~-30 ~44 ~29 ~-30 ~44 minecraft:air
setblock ~30 ~-30 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-30 ~44 ~37 ~-30 ~44 minecraft:air
setblock ~38 ~-30 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-30 ~44 ~40 ~-30 ~44 minecraft:air
fill ~41 ~-30 ~44 ~42 ~-30 ~44 minecraft:smooth_quartz
fill ~43 ~-30 ~44 ~49 ~-30 ~44 minecraft:air
setblock ~50 ~-30 ~44 minecraft:light_gray_concrete
fill ~51 ~-30 ~44 ~63 ~-30 ~44 minecraft:air
setblock ~64 ~-30 ~44 minecraft:light_gray_concrete
setblock ~4 ~-30 ~45 minecraft:light_gray_concrete
fill ~5 ~-30 ~45 ~17 ~-30 ~45 minecraft:air
setblock ~18 ~-30 ~45 minecraft:light_gray_concrete
fill ~19 ~-30 ~45 ~20 ~-30 ~45 minecraft:air
setblock ~21 ~-30 ~45 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~22 ~-30 ~45 minecraft:iron_bars[west=true]
fill ~23 ~-30 ~45 ~27 ~-30 ~45 minecraft:air
fill ~28 ~-30 ~45 ~29 ~-30 ~45 minecraft:smooth_quartz
fill ~30 ~-30 ~45 ~38 ~-30 ~45 minecraft:air
fill ~39 ~-30 ~45 ~40 ~-30 ~45 minecraft:smooth_quartz
fill ~41 ~-30 ~45 ~49 ~-30 ~45 minecraft:air
setblock ~50 ~-30 ~45 minecraft:light_gray_concrete
fill ~51 ~-30 ~45 ~63 ~-30 ~45 minecraft:air
setblock ~64 ~-30 ~45 minecraft:light_gray_concrete
setblock ~4 ~-30 ~46 minecraft:light_gray_concrete
fill ~5 ~-30 ~46 ~17 ~-30 ~46 minecraft:air
setblock ~18 ~-30 ~46 minecraft:light_gray_concrete
fill ~19 ~-30 ~46 ~20 ~-30 ~46 minecraft:air
setblock ~21 ~-30 ~46 minecraft:iron_bars[north=true,south=true]
setblock ~22 ~-30 ~46 minecraft:air
setblock ~23 ~-30 ~46 minecraft:iron_bars[south=true]
fill ~24 ~-30 ~46 ~28 ~-30 ~46 minecraft:air
fill ~29 ~-30 ~46 ~33 ~-30 ~46 minecraft:smooth_quartz
setblock ~34 ~-30 ~46 minecraft:air
fill ~35 ~-30 ~46 ~39 ~-30 ~46 minecraft:smooth_quartz
fill ~40 ~-30 ~46 ~41 ~-30 ~46 minecraft:air
setblock ~42 ~-30 ~46 minecraft:iron_bars[east=true]
fill ~43 ~-30 ~46 ~44 ~-30 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-30 ~46 minecraft:iron_bars[east=true,south=true,west=true]
fill ~46 ~-30 ~46 ~48 ~-30 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~49 ~-30 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~50 ~-30 ~46 minecraft:light_gray_concrete
fill ~51 ~-30 ~46 ~63 ~-30 ~46 minecraft:air
setblock ~64 ~-30 ~46 minecraft:light_gray_concrete
setblock ~4 ~-30 ~47 minecraft:light_gray_concrete
fill ~5 ~-30 ~47 ~17 ~-30 ~47 minecraft:air
setblock ~18 ~-30 ~47 minecraft:light_gray_concrete
fill ~19 ~-30 ~47 ~20 ~-30 ~47 minecraft:air
setblock ~21 ~-30 ~47 minecraft:iron_bars[north=true,east=true]
setblock ~22 ~-30 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-30 ~47 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-30 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-30 ~47 minecraft:iron_bars[west=true]
fill ~26 ~-30 ~47 ~31 ~-30 ~47 minecraft:air
setblock ~32 ~-30 ~47 minecraft:light_gray_concrete
setblock ~33 ~-30 ~47 minecraft:air
setblock ~34 ~-30 ~47 minecraft:smooth_quartz
setblock ~35 ~-30 ~47 minecraft:air
setblock ~36 ~-30 ~47 minecraft:light_gray_concrete
fill ~37 ~-30 ~47 ~40 ~-30 ~47 minecraft:air
setblock ~41 ~-30 ~47 minecraft:iron_bars[south=true]
fill ~42 ~-30 ~47 ~44 ~-30 ~47 minecraft:air
setblock ~45 ~-30 ~47 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-30 ~47 ~48 ~-30 ~47 minecraft:air
setblock ~49 ~-30 ~47 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-30 ~47 minecraft:light_gray_concrete
fill ~51 ~-30 ~47 ~63 ~-30 ~47 minecraft:air
setblock ~64 ~-30 ~47 minecraft:light_gray_concrete
setblock ~4 ~-30 ~48 minecraft:light_gray_concrete
fill ~5 ~-30 ~48 ~17 ~-30 ~48 minecraft:air
setblock ~18 ~-30 ~48 minecraft:light_gray_concrete
fill ~19 ~-30 ~48 ~31 ~-30 ~48 minecraft:air
setblock ~32 ~-30 ~48 minecraft:light_gray_concrete
fill ~33 ~-30 ~48 ~35 ~-30 ~48 minecraft:air
setblock ~36 ~-30 ~48 minecraft:light_gray_concrete
fill ~37 ~-30 ~48 ~40 ~-30 ~48 minecraft:air
setblock ~41 ~-30 ~48 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-30 ~48 ~44 ~-30 ~48 minecraft:air
setblock ~45 ~-30 ~48 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-30 ~48 ~48 ~-30 ~48 minecraft:air
setblock ~49 ~-30 ~48 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-30 ~48 minecraft:light_gray_concrete
fill ~51 ~-30 ~48 ~63 ~-30 ~48 minecraft:air
setblock ~64 ~-30 ~48 minecraft:light_gray_concrete
setblock ~4 ~-30 ~49 minecraft:light_gray_concrete
fill ~5 ~-30 ~49 ~17 ~-30 ~49 minecraft:air
setblock ~18 ~-30 ~49 minecraft:light_gray_concrete
fill ~19 ~-30 ~49 ~31 ~-30 ~49 minecraft:air
setblock ~32 ~-30 ~49 minecraft:light_gray_concrete
fill ~33 ~-30 ~49 ~35 ~-30 ~49 minecraft:air
setblock ~36 ~-30 ~49 minecraft:light_gray_concrete
fill ~37 ~-30 ~49 ~40 ~-30 ~49 minecraft:air
setblock ~41 ~-30 ~49 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-30 ~49 ~44 ~-30 ~49 minecraft:air
setblock ~45 ~-30 ~49 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-30 ~49 ~48 ~-30 ~49 minecraft:air
setblock ~49 ~-30 ~49 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-30 ~49 minecraft:light_gray_concrete
fill ~51 ~-30 ~49 ~63 ~-30 ~49 minecraft:air
setblock ~64 ~-30 ~49 minecraft:light_gray_concrete
fill ~4 ~-30 ~50 ~32 ~-30 ~50 minecraft:light_gray_concrete
fill ~33 ~-30 ~50 ~35 ~-30 ~50 minecraft:air
fill ~36 ~-30 ~50 ~64 ~-30 ~50 minecraft:light_gray_concrete
setblock ~4 ~-30 ~51 minecraft:light_gray_concrete
fill ~5 ~-30 ~51 ~17 ~-30 ~51 minecraft:air
setblock ~18 ~-30 ~51 minecraft:light_gray_concrete
fill ~19 ~-30 ~51 ~31 ~-30 ~51 minecraft:air
setblock ~32 ~-30 ~51 minecraft:light_gray_concrete
fill ~33 ~-30 ~51 ~35 ~-30 ~51 minecraft:air
setblock ~36 ~-30 ~51 minecraft:light_gray_concrete
fill ~37 ~-30 ~51 ~49 ~-30 ~51 minecraft:air
setblock ~50 ~-30 ~51 minecraft:light_gray_concrete
fill ~51 ~-30 ~51 ~63 ~-30 ~51 minecraft:air
setblock ~64 ~-30 ~51 minecraft:light_gray_concrete
setblock ~4 ~-30 ~52 minecraft:light_gray_concrete
fill ~5 ~-30 ~52 ~17 ~-30 ~52 minecraft:air
setblock ~18 ~-30 ~52 minecraft:light_gray_concrete
fill ~19 ~-30 ~52 ~31 ~-30 ~52 minecraft:air
setblock ~32 ~-30 ~52 minecraft:light_gray_concrete
fill ~33 ~-30 ~52 ~35 ~-30 ~52 minecraft:air
setblock ~36 ~-30 ~52 minecraft:light_gray_concrete
fill ~37 ~-30 ~52 ~49 ~-30 ~52 minecraft:air
setblock ~50 ~-30 ~52 minecraft:light_gray_concrete
fill ~51 ~-30 ~52 ~63 ~-30 ~52 minecraft:air
setblock ~64 ~-30 ~52 minecraft:light_gray_concrete
setblock ~4 ~-30 ~53 minecraft:light_gray_concrete
fill ~5 ~-30 ~53 ~17 ~-30 ~53 minecraft:air
setblock ~18 ~-30 ~53 minecraft:light_gray_concrete
fill ~19 ~-30 ~53 ~31 ~-30 ~53 minecraft:air
setblock ~32 ~-30 ~53 minecraft:light_gray_concrete
fill ~33 ~-30 ~53 ~35 ~-30 ~53 minecraft:air
setblock ~36 ~-30 ~53 minecraft:light_gray_concrete
fill ~37 ~-30 ~53 ~49 ~-30 ~53 minecraft:air
setblock ~50 ~-30 ~53 minecraft:light_gray_concrete
fill ~51 ~-30 ~53 ~63 ~-30 ~53 minecraft:air
setblock ~64 ~-30 ~53 minecraft:light_gray_concrete
setblock ~4 ~-30 ~54 minecraft:light_gray_concrete
fill ~5 ~-30 ~54 ~17 ~-30 ~54 minecraft:air
setblock ~18 ~-30 ~54 minecraft:light_gray_concrete
fill ~19 ~-30 ~54 ~31 ~-30 ~54 minecraft:air
setblock ~32 ~-30 ~54 minecraft:light_gray_concrete
fill ~33 ~-30 ~54 ~35 ~-30 ~54 minecraft:air
setblock ~36 ~-30 ~54 minecraft:light_gray_concrete
fill ~37 ~-30 ~54 ~38 ~-30 ~54 minecraft:air
setblock ~39 ~-30 ~54 minecraft:end_rod[facing=down]
fill ~40 ~-30 ~54 ~41 ~-30 ~54 minecraft:air
setblock ~42 ~-30 ~54 minecraft:end_rod[facing=down]
fill ~43 ~-30 ~54 ~44 ~-30 ~54 minecraft:air
setblock ~45 ~-30 ~54 minecraft:end_rod[facing=down]
fill ~46 ~-30 ~54 ~47 ~-30 ~54 minecraft:air
setblock ~48 ~-30 ~54 minecraft:end_rod[facing=down]
setblock ~49 ~-30 ~54 minecraft:air
setblock ~50 ~-30 ~54 minecraft:light_gray_concrete
fill ~51 ~-30 ~54 ~53 ~-30 ~54 minecraft:air
setblock ~54 ~-30 ~54 minecraft:end_rod[facing=down]
fill ~55 ~-30 ~54 ~57 ~-30 ~54 minecraft:air
setblock ~58 ~-30 ~54 minecraft:end_rod[facing=down]
fill ~59 ~-30 ~54 ~63 ~-30 ~54 minecraft:air
setblock ~64 ~-30 ~54 minecraft:light_gray_concrete
setblock ~4 ~-30 ~55 minecraft:light_gray_concrete
fill ~5 ~-30 ~55 ~17 ~-30 ~55 minecraft:air
setblock ~18 ~-30 ~55 minecraft:light_gray_concrete
fill ~19 ~-30 ~55 ~31 ~-30 ~55 minecraft:air
setblock ~32 ~-30 ~55 minecraft:light_gray_concrete
fill ~33 ~-30 ~55 ~35 ~-30 ~55 minecraft:air
setblock ~36 ~-30 ~55 minecraft:light_gray_concrete
fill ~37 ~-30 ~55 ~49 ~-30 ~55 minecraft:air
setblock ~50 ~-30 ~55 minecraft:light_gray_concrete
fill ~51 ~-30 ~55 ~56 ~-30 ~55 minecraft:air
setblock ~57 ~-30 ~55 minecraft:end_rod[facing=down]
fill ~58 ~-30 ~55 ~63 ~-30 ~55 minecraft:air
setblock ~64 ~-30 ~55 minecraft:light_gray_concrete
setblock ~4 ~-30 ~56 minecraft:light_gray_concrete
fill ~5 ~-30 ~56 ~17 ~-30 ~56 minecraft:air
setblock ~18 ~-30 ~56 minecraft:light_gray_concrete
fill ~19 ~-30 ~56 ~31 ~-30 ~56 minecraft:air
setblock ~32 ~-30 ~56 minecraft:light_gray_concrete
fill ~33 ~-30 ~56 ~35 ~-30 ~56 minecraft:air
setblock ~36 ~-30 ~56 minecraft:light_gray_concrete
fill ~37 ~-30 ~56 ~49 ~-30 ~56 minecraft:air
setblock ~50 ~-30 ~56 minecraft:light_gray_concrete
fill ~51 ~-30 ~56 ~55 ~-30 ~56 minecraft:air
setblock ~56 ~-30 ~56 minecraft:end_rod[facing=down]
fill ~57 ~-30 ~56 ~59 ~-30 ~56 minecraft:air
setblock ~60 ~-30 ~56 minecraft:end_rod[facing=down]
fill ~61 ~-30 ~56 ~63 ~-30 ~56 minecraft:air
setblock ~64 ~-30 ~56 minecraft:light_gray_concrete
setblock ~4 ~-30 ~57 minecraft:light_gray_concrete
fill ~5 ~-30 ~57 ~17 ~-30 ~57 minecraft:air
setblock ~18 ~-30 ~57 minecraft:light_gray_concrete
fill ~19 ~-30 ~57 ~31 ~-30 ~57 minecraft:air
setblock ~32 ~-30 ~57 minecraft:light_gray_concrete
fill ~33 ~-30 ~57 ~35 ~-30 ~57 minecraft:air
setblock ~36 ~-30 ~57 minecraft:light_gray_concrete
fill ~37 ~-30 ~57 ~38 ~-30 ~57 minecraft:air
setblock ~39 ~-30 ~57 minecraft:end_rod[facing=down]
fill ~40 ~-30 ~57 ~41 ~-30 ~57 minecraft:air
setblock ~42 ~-30 ~57 minecraft:end_rod[facing=down]
fill ~43 ~-30 ~57 ~44 ~-30 ~57 minecraft:air
setblock ~45 ~-30 ~57 minecraft:end_rod[facing=down]
fill ~46 ~-30 ~57 ~49 ~-30 ~57 minecraft:air
setblock ~50 ~-30 ~57 minecraft:light_gray_concrete
fill ~51 ~-30 ~57 ~54 ~-30 ~57 minecraft:air
setblock ~55 ~-30 ~57 minecraft:end_rod[facing=down]
fill ~56 ~-30 ~57 ~58 ~-30 ~57 minecraft:air
setblock ~59 ~-30 ~57 minecraft:end_rod[facing=down]
fill ~60 ~-30 ~57 ~63 ~-30 ~57 minecraft:air
setblock ~64 ~-30 ~57 minecraft:light_gray_concrete
setblock ~4 ~-30 ~58 minecraft:light_gray_concrete
fill ~5 ~-30 ~58 ~17 ~-30 ~58 minecraft:air
setblock ~18 ~-30 ~58 minecraft:light_gray_concrete
fill ~19 ~-30 ~58 ~31 ~-30 ~58 minecraft:air
setblock ~32 ~-30 ~58 minecraft:light_gray_concrete
fill ~33 ~-30 ~58 ~35 ~-30 ~58 minecraft:air
setblock ~36 ~-30 ~58 minecraft:light_gray_concrete
fill ~37 ~-30 ~58 ~49 ~-30 ~58 minecraft:air
setblock ~50 ~-30 ~58 minecraft:light_gray_concrete
fill ~51 ~-30 ~58 ~53 ~-30 ~58 minecraft:air
setblock ~54 ~-30 ~58 minecraft:end_rod[facing=down]
fill ~55 ~-30 ~58 ~57 ~-30 ~58 minecraft:air
setblock ~58 ~-30 ~58 minecraft:end_rod[facing=down]
fill ~59 ~-30 ~58 ~63 ~-30 ~58 minecraft:air
setblock ~64 ~-30 ~58 minecraft:light_gray_concrete
setblock ~4 ~-30 ~59 minecraft:light_gray_concrete
fill ~5 ~-30 ~59 ~17 ~-30 ~59 minecraft:air
setblock ~18 ~-30 ~59 minecraft:light_gray_concrete
fill ~19 ~-30 ~59 ~31 ~-30 ~59 minecraft:air
setblock ~32 ~-30 ~59 minecraft:light_gray_concrete
fill ~33 ~-30 ~59 ~35 ~-30 ~59 minecraft:air
setblock ~36 ~-30 ~59 minecraft:light_gray_concrete
fill ~37 ~-30 ~59 ~49 ~-30 ~59 minecraft:air
setblock ~50 ~-30 ~59 minecraft:light_gray_concrete
fill ~51 ~-30 ~59 ~56 ~-30 ~59 minecraft:air
setblock ~57 ~-30 ~59 minecraft:end_rod[facing=down]
fill ~58 ~-30 ~59 ~63 ~-30 ~59 minecraft:air
setblock ~64 ~-30 ~59 minecraft:light_gray_concrete
setblock ~4 ~-30 ~60 minecraft:light_gray_concrete
fill ~5 ~-30 ~60 ~17 ~-30 ~60 minecraft:air
setblock ~18 ~-30 ~60 minecraft:light_gray_concrete
fill ~19 ~-30 ~60 ~31 ~-30 ~60 minecraft:air
setblock ~32 ~-30 ~60 minecraft:light_gray_concrete
fill ~33 ~-30 ~60 ~35 ~-30 ~60 minecraft:air
setblock ~36 ~-30 ~60 minecraft:light_gray_concrete
fill ~37 ~-30 ~60 ~38 ~-30 ~60 minecraft:air
setblock ~39 ~-30 ~60 minecraft:end_rod[facing=down]
fill ~40 ~-30 ~60 ~41 ~-30 ~60 minecraft:air
setblock ~42 ~-30 ~60 minecraft:end_rod[facing=down]
fill ~43 ~-30 ~60 ~44 ~-30 ~60 minecraft:air
setblock ~45 ~-30 ~60 minecraft:end_rod[facing=down]
fill ~46 ~-30 ~60 ~47 ~-30 ~60 minecraft:air
setblock ~48 ~-30 ~60 minecraft:end_rod[facing=down]
setblock ~49 ~-30 ~60 minecraft:air
setblock ~50 ~-30 ~60 minecraft:light_gray_concrete
fill ~51 ~-30 ~60 ~55 ~-30 ~60 minecraft:air
setblock ~56 ~-30 ~60 minecraft:end_rod[facing=down]
fill ~57 ~-30 ~60 ~59 ~-30 ~60 minecraft:air
setblock ~60 ~-30 ~60 minecraft:end_rod[facing=down]
fill ~61 ~-30 ~60 ~63 ~-30 ~60 minecraft:air
setblock ~64 ~-30 ~60 minecraft:light_gray_concrete
setblock ~4 ~-30 ~61 minecraft:light_gray_concrete
fill ~5 ~-30 ~61 ~17 ~-30 ~61 minecraft:air
setblock ~18 ~-30 ~61 minecraft:light_gray_concrete
fill ~19 ~-30 ~61 ~31 ~-30 ~61 minecraft:air
setblock ~32 ~-30 ~61 minecraft:light_gray_concrete
fill ~33 ~-30 ~61 ~35 ~-30 ~61 minecraft:air
setblock ~36 ~-30 ~61 minecraft:light_gray_concrete
fill ~37 ~-30 ~61 ~49 ~-30 ~61 minecraft:air
setblock ~50 ~-30 ~61 minecraft:light_gray_concrete
fill ~51 ~-30 ~61 ~63 ~-30 ~61 minecraft:air
setblock ~64 ~-30 ~61 minecraft:light_gray_concrete
setblock ~4 ~-30 ~62 minecraft:light_gray_concrete
fill ~5 ~-30 ~62 ~17 ~-30 ~62 minecraft:air
setblock ~18 ~-30 ~62 minecraft:light_gray_concrete
fill ~19 ~-30 ~62 ~31 ~-30 ~62 minecraft:air
setblock ~32 ~-30 ~62 minecraft:light_gray_concrete
fill ~33 ~-30 ~62 ~35 ~-30 ~62 minecraft:air
setblock ~36 ~-30 ~62 minecraft:light_gray_concrete
fill ~37 ~-30 ~62 ~49 ~-30 ~62 minecraft:air
setblock ~50 ~-30 ~62 minecraft:light_gray_concrete
fill ~51 ~-30 ~62 ~63 ~-30 ~62 minecraft:air
setblock ~64 ~-30 ~62 minecraft:light_gray_concrete
setblock ~4 ~-30 ~63 minecraft:light_gray_concrete
fill ~5 ~-30 ~63 ~17 ~-30 ~63 minecraft:air
setblock ~18 ~-30 ~63 minecraft:light_gray_concrete
fill ~19 ~-30 ~63 ~31 ~-30 ~63 minecraft:air
setblock ~32 ~-30 ~63 minecraft:light_gray_concrete
fill ~33 ~-30 ~63 ~35 ~-30 ~63 minecraft:air
setblock ~36 ~-30 ~63 minecraft:light_gray_concrete
fill ~37 ~-30 ~63 ~49 ~-30 ~63 minecraft:air
setblock ~50 ~-30 ~63 minecraft:light_gray_concrete
fill ~51 ~-30 ~63 ~63 ~-30 ~63 minecraft:air
setblock ~64 ~-30 ~63 minecraft:light_gray_concrete
fill ~4 ~-30 ~64 ~64 ~-30 ~64 minecraft:light_gray_concrete
fill ~32 ~-30 ~66 ~36 ~-30 ~66 minecraft:polished_andesite
setblock ~32 ~-30 ~67 minecraft:polished_andesite
fill ~33 ~-30 ~67 ~35 ~-30 ~67 minecraft:air
setblock ~36 ~-30 ~67 minecraft:polished_andesite
setblock ~32 ~-30 ~68 minecraft:polished_andesite
setblock ~33 ~-30 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-30 ~68 minecraft:quartz_pillar
setblock ~35 ~-30 ~68 minecraft:air
setblock ~36 ~-30 ~68 minecraft:polished_andesite
setblock ~32 ~-30 ~69 minecraft:polished_andesite
fill ~33 ~-30 ~69 ~35 ~-30 ~69 minecraft:air
setblock ~36 ~-30 ~69 minecraft:polished_andesite
fill ~32 ~-30 ~70 ~36 ~-30 ~70 minecraft:polished_andesite
fill ~4 ~-29 ~4 ~64 ~-29 ~4 minecraft:smooth_stone
fill ~4 ~-29 ~5 ~64 ~-29 ~5 minecraft:smooth_stone
fill ~4 ~-29 ~6 ~5 ~-29 ~6 minecraft:smooth_stone
setblock ~6 ~-29 ~6 minecraft:sea_lantern
fill ~7 ~-29 ~6 ~9 ~-29 ~6 minecraft:smooth_stone
setblock ~10 ~-29 ~6 minecraft:sea_lantern
fill ~11 ~-29 ~6 ~13 ~-29 ~6 minecraft:smooth_stone
setblock ~14 ~-29 ~6 minecraft:sea_lantern
fill ~15 ~-29 ~6 ~21 ~-29 ~6 minecraft:smooth_stone
setblock ~22 ~-29 ~6 minecraft:sea_lantern
fill ~23 ~-29 ~6 ~25 ~-29 ~6 minecraft:smooth_stone
setblock ~26 ~-29 ~6 minecraft:sea_lantern
fill ~27 ~-29 ~6 ~29 ~-29 ~6 minecraft:smooth_stone
setblock ~30 ~-29 ~6 minecraft:sea_lantern
fill ~31 ~-29 ~6 ~33 ~-29 ~6 minecraft:smooth_stone
setblock ~34 ~-29 ~6 minecraft:sea_lantern
fill ~35 ~-29 ~6 ~37 ~-29 ~6 minecraft:smooth_stone
setblock ~38 ~-29 ~6 minecraft:sea_lantern
fill ~39 ~-29 ~6 ~41 ~-29 ~6 minecraft:smooth_stone
setblock ~42 ~-29 ~6 minecraft:sea_lantern
fill ~43 ~-29 ~6 ~45 ~-29 ~6 minecraft:smooth_stone
setblock ~46 ~-29 ~6 minecraft:sea_lantern
fill ~47 ~-29 ~6 ~53 ~-29 ~6 minecraft:smooth_stone
setblock ~54 ~-29 ~6 minecraft:sea_lantern
fill ~55 ~-29 ~6 ~57 ~-29 ~6 minecraft:smooth_stone
setblock ~58 ~-29 ~6 minecraft:sea_lantern
fill ~59 ~-29 ~6 ~61 ~-29 ~6 minecraft:smooth_stone
setblock ~62 ~-29 ~6 minecraft:sea_lantern
fill ~63 ~-29 ~6 ~64 ~-29 ~6 minecraft:smooth_stone
fill ~4 ~-29 ~7 ~64 ~-29 ~7 minecraft:smooth_stone
fill ~4 ~-29 ~8 ~64 ~-29 ~8 minecraft:smooth_stone
fill ~4 ~-29 ~9 ~64 ~-29 ~9 minecraft:smooth_stone
fill ~4 ~-29 ~10 ~5 ~-29 ~10 minecraft:smooth_stone
setblock ~6 ~-29 ~10 minecraft:sea_lantern
fill ~7 ~-29 ~10 ~9 ~-29 ~10 minecraft:smooth_stone
setblock ~10 ~-29 ~10 minecraft:sea_lantern
fill ~11 ~-29 ~10 ~13 ~-29 ~10 minecraft:smooth_stone
setblock ~14 ~-29 ~10 minecraft:sea_lantern
fill ~15 ~-29 ~10 ~21 ~-29 ~10 minecraft:smooth_stone
setblock ~22 ~-29 ~10 minecraft:sea_lantern
fill ~23 ~-29 ~10 ~25 ~-29 ~10 minecraft:smooth_stone
setblock ~26 ~-29 ~10 minecraft:sea_lantern
fill ~27 ~-29 ~10 ~29 ~-29 ~10 minecraft:smooth_stone
setblock ~30 ~-29 ~10 minecraft:sea_lantern
fill ~31 ~-29 ~10 ~33 ~-29 ~10 minecraft:smooth_stone
setblock ~34 ~-29 ~10 minecraft:sea_lantern
fill ~35 ~-29 ~10 ~37 ~-29 ~10 minecraft:smooth_stone
setblock ~38 ~-29 ~10 minecraft:sea_lantern
fill ~39 ~-29 ~10 ~41 ~-29 ~10 minecraft:smooth_stone
setblock ~42 ~-29 ~10 minecraft:sea_lantern
fill ~43 ~-29 ~10 ~45 ~-29 ~10 minecraft:smooth_stone
setblock ~46 ~-29 ~10 minecraft:sea_lantern
fill ~47 ~-29 ~10 ~53 ~-29 ~10 minecraft:smooth_stone
setblock ~54 ~-29 ~10 minecraft:sea_lantern
fill ~55 ~-29 ~10 ~57 ~-29 ~10 minecraft:smooth_stone
setblock ~58 ~-29 ~10 minecraft:sea_lantern
fill ~59 ~-29 ~10 ~61 ~-29 ~10 minecraft:smooth_stone
setblock ~62 ~-29 ~10 minecraft:sea_lantern
fill ~63 ~-29 ~10 ~64 ~-29 ~10 minecraft:smooth_stone
fill ~4 ~-29 ~11 ~64 ~-29 ~11 minecraft:smooth_stone
fill ~4 ~-29 ~12 ~64 ~-29 ~12 minecraft:smooth_stone
fill ~4 ~-29 ~13 ~64 ~-29 ~13 minecraft:smooth_stone
fill ~4 ~-29 ~14 ~5 ~-29 ~14 minecraft:smooth_stone
setblock ~6 ~-29 ~14 minecraft:sea_lantern
fill ~7 ~-29 ~14 ~9 ~-29 ~14 minecraft:smooth_stone
setblock ~10 ~-29 ~14 minecraft:sea_lantern
fill ~11 ~-29 ~14 ~13 ~-29 ~14 minecraft:smooth_stone
setblock ~14 ~-29 ~14 minecraft:sea_lantern
fill ~15 ~-29 ~14 ~21 ~-29 ~14 minecraft:smooth_stone
setblock ~22 ~-29 ~14 minecraft:sea_lantern
fill ~23 ~-29 ~14 ~25 ~-29 ~14 minecraft:smooth_stone
setblock ~26 ~-29 ~14 minecraft:sea_lantern
fill ~27 ~-29 ~14 ~29 ~-29 ~14 minecraft:smooth_stone
setblock ~30 ~-29 ~14 minecraft:sea_lantern
fill ~31 ~-29 ~14 ~33 ~-29 ~14 minecraft:smooth_stone
setblock ~34 ~-29 ~14 minecraft:sea_lantern
fill ~35 ~-29 ~14 ~37 ~-29 ~14 minecraft:smooth_stone
setblock ~38 ~-29 ~14 minecraft:sea_lantern
fill ~39 ~-29 ~14 ~41 ~-29 ~14 minecraft:smooth_stone
setblock ~42 ~-29 ~14 minecraft:sea_lantern
fill ~43 ~-29 ~14 ~45 ~-29 ~14 minecraft:smooth_stone
setblock ~46 ~-29 ~14 minecraft:sea_lantern
fill ~47 ~-29 ~14 ~53 ~-29 ~14 minecraft:smooth_stone
setblock ~54 ~-29 ~14 minecraft:sea_lantern
fill ~55 ~-29 ~14 ~57 ~-29 ~14 minecraft:smooth_stone
setblock ~58 ~-29 ~14 minecraft:sea_lantern
fill ~59 ~-29 ~14 ~61 ~-29 ~14 minecraft:smooth_stone
setblock ~62 ~-29 ~14 minecraft:sea_lantern
fill ~63 ~-29 ~14 ~64 ~-29 ~14 minecraft:smooth_stone
fill ~4 ~-29 ~15 ~64 ~-29 ~15 minecraft:smooth_stone
fill ~4 ~-29 ~16 ~64 ~-29 ~16 minecraft:smooth_stone
fill ~4 ~-29 ~17 ~64 ~-29 ~17 minecraft:smooth_stone
fill ~4 ~-29 ~18 ~33 ~-29 ~18 minecraft:smooth_stone
setblock ~34 ~-29 ~18 minecraft:sea_lantern
fill ~35 ~-29 ~18 ~64 ~-29 ~18 minecraft:smooth_stone
fill ~4 ~-29 ~19 ~64 ~-29 ~19 minecraft:smooth_stone
fill ~4 ~-29 ~20 ~64 ~-29 ~20 minecraft:smooth_stone
fill ~4 ~-29 ~21 ~33 ~-29 ~21 minecraft:smooth_stone
setblock ~34 ~-29 ~21 minecraft:smooth_quartz
fill ~35 ~-29 ~21 ~64 ~-29 ~21 minecraft:smooth_stone
fill ~4 ~-29 ~22 ~5 ~-29 ~22 minecraft:smooth_stone
setblock ~6 ~-29 ~22 minecraft:sea_lantern
fill ~7 ~-29 ~22 ~9 ~-29 ~22 minecraft:smooth_stone
setblock ~10 ~-29 ~22 minecraft:sea_lantern
fill ~11 ~-29 ~22 ~13 ~-29 ~22 minecraft:smooth_stone
setblock ~14 ~-29 ~22 minecraft:sea_lantern
fill ~15 ~-29 ~22 ~21 ~-29 ~22 minecraft:smooth_stone
setblock ~22 ~-29 ~22 minecraft:sea_lantern
fill ~23 ~-29 ~22 ~25 ~-29 ~22 minecraft:smooth_stone
setblock ~26 ~-29 ~22 minecraft:sea_lantern
fill ~27 ~-29 ~22 ~28 ~-29 ~22 minecraft:smooth_stone
fill ~29 ~-29 ~22 ~39 ~-29 ~22 minecraft:smooth_quartz
fill ~40 ~-29 ~22 ~41 ~-29 ~22 minecraft:smooth_stone
setblock ~42 ~-29 ~22 minecraft:sea_lantern
fill ~43 ~-29 ~22 ~45 ~-29 ~22 minecraft:smooth_stone
setblock ~46 ~-29 ~22 minecraft:sea_lantern
fill ~47 ~-29 ~22 ~53 ~-29 ~22 minecraft:smooth_stone
setblock ~54 ~-29 ~22 minecraft:sea_lantern
fill ~55 ~-29 ~22 ~57 ~-29 ~22 minecraft:smooth_stone
setblock ~58 ~-29 ~22 minecraft:sea_lantern
fill ~59 ~-29 ~22 ~61 ~-29 ~22 minecraft:smooth_stone
setblock ~62 ~-29 ~22 minecraft:sea_lantern
fill ~63 ~-29 ~22 ~64 ~-29 ~22 minecraft:smooth_stone
fill ~4 ~-29 ~23 ~27 ~-29 ~23 minecraft:smooth_stone
fill ~28 ~-29 ~23 ~40 ~-29 ~23 minecraft:smooth_quartz
fill ~41 ~-29 ~23 ~64 ~-29 ~23 minecraft:smooth_stone
fill ~4 ~-29 ~24 ~25 ~-29 ~24 minecraft:smooth_stone
fill ~26 ~-29 ~24 ~42 ~-29 ~24 minecraft:smooth_quartz
fill ~43 ~-29 ~24 ~64 ~-29 ~24 minecraft:smooth_stone
fill ~4 ~-29 ~25 ~24 ~-29 ~25 minecraft:smooth_stone
fill ~25 ~-29 ~25 ~31 ~-29 ~25 minecraft:smooth_quartz
fill ~32 ~-29 ~25 ~36 ~-29 ~25 minecraft:sea_lantern
fill ~37 ~-29 ~25 ~43 ~-29 ~25 minecraft:smooth_quartz
fill ~44 ~-29 ~25 ~64 ~-29 ~25 minecraft:smooth_stone
fill ~4 ~-29 ~26 ~5 ~-29 ~26 minecraft:smooth_stone
setblock ~6 ~-29 ~26 minecraft:sea_lantern
fill ~7 ~-29 ~26 ~9 ~-29 ~26 minecraft:smooth_stone
setblock ~10 ~-29 ~26 minecraft:sea_lantern
fill ~11 ~-29 ~26 ~13 ~-29 ~26 minecraft:smooth_stone
setblock ~14 ~-29 ~26 minecraft:sea_lantern
fill ~15 ~-29 ~26 ~21 ~-29 ~26 minecraft:smooth_stone
setblock ~22 ~-29 ~26 minecraft:sea_lantern
setblock ~23 ~-29 ~26 minecraft:smooth_stone
fill ~24 ~-29 ~26 ~29 ~-29 ~26 minecraft:smooth_quartz
fill ~30 ~-29 ~26 ~31 ~-29 ~26 minecraft:sea_lantern
fill ~32 ~-29 ~26 ~36 ~-29 ~26 minecraft:air
fill ~37 ~-29 ~26 ~38 ~-29 ~26 minecraft:sea_lantern
fill ~39 ~-29 ~26 ~44 ~-29 ~26 minecraft:smooth_quartz
setblock ~45 ~-29 ~26 minecraft:smooth_stone
setblock ~46 ~-29 ~26 minecraft:sea_lantern
fill ~47 ~-29 ~26 ~53 ~-29 ~26 minecraft:smooth_stone
setblock ~54 ~-29 ~26 minecraft:sea_lantern
fill ~55 ~-29 ~26 ~57 ~-29 ~26 minecraft:smooth_stone
setblock ~58 ~-29 ~26 minecraft:sea_lantern
fill ~59 ~-29 ~26 ~61 ~-29 ~26 minecraft:smooth_stone
setblock ~62 ~-29 ~26 minecraft:sea_lantern
fill ~63 ~-29 ~26 ~64 ~-29 ~26 minecraft:smooth_stone
fill ~4 ~-29 ~27 ~23 ~-29 ~27 minecraft:smooth_stone
fill ~24 ~-29 ~27 ~27 ~-29 ~27 minecraft:smooth_quartz
fill ~28 ~-29 ~27 ~29 ~-29 ~27 minecraft:sea_lantern
fill ~30 ~-29 ~27 ~38 ~-29 ~27 minecraft:air
fill ~39 ~-29 ~27 ~40 ~-29 ~27 minecraft:sea_lantern
fill ~41 ~-29 ~27 ~44 ~-29 ~27 minecraft:smooth_quartz
fill ~45 ~-29 ~27 ~64 ~-29 ~27 minecraft:smooth_stone
fill ~4 ~-29 ~28 ~22 ~-29 ~28 minecraft:smooth_stone
fill ~23 ~-29 ~28 ~26 ~-29 ~28 minecraft:smooth_quartz
setblock ~27 ~-29 ~28 minecraft:sea_lantern
fill ~28 ~-29 ~28 ~40 ~-29 ~28 minecraft:air
setblock ~41 ~-29 ~28 minecraft:sea_lantern
fill ~42 ~-29 ~28 ~45 ~-29 ~28 minecraft:smooth_quartz
fill ~46 ~-29 ~28 ~64 ~-29 ~28 minecraft:smooth_stone
fill ~4 ~-29 ~29 ~21 ~-29 ~29 minecraft:smooth_stone
fill ~22 ~-29 ~29 ~26 ~-29 ~29 minecraft:smooth_quartz
setblock ~27 ~-29 ~29 minecraft:sea_lantern
fill ~28 ~-29 ~29 ~40 ~-29 ~29 minecraft:air
setblock ~41 ~-29 ~29 minecraft:sea_lantern
fill ~42 ~-29 ~29 ~46 ~-29 ~29 minecraft:smooth_quartz
fill ~47 ~-29 ~29 ~64 ~-29 ~29 minecraft:smooth_stone
fill ~4 ~-29 ~30 ~5 ~-29 ~30 minecraft:smooth_stone
setblock ~6 ~-29 ~30 minecraft:sea_lantern
fill ~7 ~-29 ~30 ~9 ~-29 ~30 minecraft:smooth_stone
setblock ~10 ~-29 ~30 minecraft:sea_lantern
fill ~11 ~-29 ~30 ~13 ~-29 ~30 minecraft:smooth_stone
setblock ~14 ~-29 ~30 minecraft:sea_lantern
fill ~15 ~-29 ~30 ~21 ~-29 ~30 minecraft:smooth_stone
fill ~22 ~-29 ~30 ~25 ~-29 ~30 minecraft:smooth_quartz
setblock ~26 ~-29 ~30 minecraft:sea_lantern
fill ~27 ~-29 ~30 ~41 ~-29 ~30 minecraft:air
setblock ~42 ~-29 ~30 minecraft:sea_lantern
fill ~43 ~-29 ~30 ~46 ~-29 ~30 minecraft:smooth_quartz
fill ~47 ~-29 ~30 ~53 ~-29 ~30 minecraft:smooth_stone
setblock ~54 ~-29 ~30 minecraft:sea_lantern
fill ~55 ~-29 ~30 ~57 ~-29 ~30 minecraft:smooth_stone
setblock ~58 ~-29 ~30 minecraft:sea_lantern
fill ~59 ~-29 ~30 ~61 ~-29 ~30 minecraft:smooth_stone
setblock ~62 ~-29 ~30 minecraft:sea_lantern
fill ~63 ~-29 ~30 ~64 ~-29 ~30 minecraft:smooth_stone
fill ~4 ~-29 ~31 ~21 ~-29 ~31 minecraft:smooth_stone
fill ~22 ~-29 ~31 ~25 ~-29 ~31 minecraft:smooth_quartz
setblock ~26 ~-29 ~31 minecraft:sea_lantern
fill ~27 ~-29 ~31 ~41 ~-29 ~31 minecraft:air
setblock ~42 ~-29 ~31 minecraft:sea_lantern
fill ~43 ~-29 ~31 ~46 ~-29 ~31 minecraft:smooth_quartz
fill ~47 ~-29 ~31 ~64 ~-29 ~31 minecraft:smooth_stone
fill ~4 ~-29 ~32 ~21 ~-29 ~32 minecraft:smooth_stone
fill ~22 ~-29 ~32 ~24 ~-29 ~32 minecraft:smooth_quartz
setblock ~25 ~-29 ~32 minecraft:sea_lantern
fill ~26 ~-29 ~32 ~32 ~-29 ~32 minecraft:air
fill ~33 ~-29 ~32 ~35 ~-29 ~32 minecraft:glass
fill ~36 ~-29 ~32 ~42 ~-29 ~32 minecraft:air
setblock ~43 ~-29 ~32 minecraft:sea_lantern
fill ~44 ~-29 ~32 ~46 ~-29 ~32 minecraft:smooth_quartz
fill ~47 ~-29 ~32 ~64 ~-29 ~32 minecraft:smooth_stone
fill ~4 ~-29 ~33 ~21 ~-29 ~33 minecraft:smooth_stone
fill ~22 ~-29 ~33 ~24 ~-29 ~33 minecraft:smooth_quartz
setblock ~25 ~-29 ~33 minecraft:sea_lantern
fill ~26 ~-29 ~33 ~32 ~-29 ~33 minecraft:air
setblock ~33 ~-29 ~33 minecraft:glass
setblock ~34 ~-29 ~33 minecraft:air
setblock ~35 ~-29 ~33 minecraft:glass
fill ~36 ~-29 ~33 ~42 ~-29 ~33 minecraft:air
setblock ~43 ~-29 ~33 minecraft:sea_lantern
fill ~44 ~-29 ~33 ~46 ~-29 ~33 minecraft:smooth_quartz
fill ~47 ~-29 ~33 ~64 ~-29 ~33 minecraft:smooth_stone
fill ~4 ~-29 ~34 ~5 ~-29 ~34 minecraft:smooth_stone
setblock ~6 ~-29 ~34 minecraft:sea_lantern
fill ~7 ~-29 ~34 ~9 ~-29 ~34 minecraft:smooth_stone
setblock ~10 ~-29 ~34 minecraft:sea_lantern
fill ~11 ~-29 ~34 ~13 ~-29 ~34 minecraft:smooth_stone
setblock ~14 ~-29 ~34 minecraft:sea_lantern
fill ~15 ~-29 ~34 ~17 ~-29 ~34 minecraft:smooth_stone
setblock ~18 ~-29 ~34 minecraft:sea_lantern
fill ~19 ~-29 ~34 ~20 ~-29 ~34 minecraft:smooth_stone
fill ~21 ~-29 ~34 ~24 ~-29 ~34 minecraft:smooth_quartz
setblock ~25 ~-29 ~34 minecraft:sea_lantern
fill ~26 ~-29 ~34 ~32 ~-29 ~34 minecraft:air
fill ~33 ~-29 ~34 ~35 ~-29 ~34 minecraft:glass
fill ~36 ~-29 ~34 ~42 ~-29 ~34 minecraft:air
setblock ~43 ~-29 ~34 minecraft:sea_lantern
fill ~44 ~-29 ~34 ~47 ~-29 ~34 minecraft:smooth_quartz
fill ~48 ~-29 ~34 ~49 ~-29 ~34 minecraft:smooth_stone
setblock ~50 ~-29 ~34 minecraft:sea_lantern
fill ~51 ~-29 ~34 ~53 ~-29 ~34 minecraft:smooth_stone
setblock ~54 ~-29 ~34 minecraft:sea_lantern
fill ~55 ~-29 ~34 ~57 ~-29 ~34 minecraft:smooth_stone
setblock ~58 ~-29 ~34 minecraft:sea_lantern
fill ~59 ~-29 ~34 ~61 ~-29 ~34 minecraft:smooth_stone
setblock ~62 ~-29 ~34 minecraft:sea_lantern
fill ~63 ~-29 ~34 ~64 ~-29 ~34 minecraft:smooth_stone
fill ~4 ~-29 ~35 ~21 ~-29 ~35 minecraft:smooth_stone
fill ~22 ~-29 ~35 ~24 ~-29 ~35 minecraft:smooth_quartz
setblock ~25 ~-29 ~35 minecraft:sea_lantern
fill ~26 ~-29 ~35 ~32 ~-29 ~35 minecraft:air
setblock ~33 ~-29 ~35 minecraft:glass
setblock ~34 ~-29 ~35 minecraft:air
setblock ~35 ~-29 ~35 minecraft:glass
fill ~36 ~-29 ~35 ~42 ~-29 ~35 minecraft:air
setblock ~43 ~-29 ~35 minecraft:sea_lantern
fill ~44 ~-29 ~35 ~46 ~-29 ~35 minecraft:smooth_quartz
fill ~47 ~-29 ~35 ~64 ~-29 ~35 minecraft:smooth_stone
fill ~4 ~-29 ~36 ~21 ~-29 ~36 minecraft:smooth_stone
fill ~22 ~-29 ~36 ~24 ~-29 ~36 minecraft:smooth_quartz
setblock ~25 ~-29 ~36 minecraft:sea_lantern
fill ~26 ~-29 ~36 ~32 ~-29 ~36 minecraft:air
fill ~33 ~-29 ~36 ~35 ~-29 ~36 minecraft:glass
fill ~36 ~-29 ~36 ~42 ~-29 ~36 minecraft:air
setblock ~43 ~-29 ~36 minecraft:sea_lantern
fill ~44 ~-29 ~36 ~46 ~-29 ~36 minecraft:smooth_quartz
fill ~47 ~-29 ~36 ~64 ~-29 ~36 minecraft:smooth_stone
fill ~4 ~-29 ~37 ~21 ~-29 ~37 minecraft:smooth_stone
fill ~22 ~-29 ~37 ~25 ~-29 ~37 minecraft:smooth_quartz
setblock ~26 ~-29 ~37 minecraft:sea_lantern
fill ~27 ~-29 ~37 ~41 ~-29 ~37 minecraft:air
setblock ~42 ~-29 ~37 minecraft:sea_lantern
fill ~43 ~-29 ~37 ~46 ~-29 ~37 minecraft:smooth_quartz
fill ~47 ~-29 ~37 ~64 ~-29 ~37 minecraft:smooth_stone
fill ~4 ~-29 ~38 ~5 ~-29 ~38 minecraft:smooth_stone
setblock ~6 ~-29 ~38 minecraft:sea_lantern
fill ~7 ~-29 ~38 ~9 ~-29 ~38 minecraft:smooth_stone
setblock ~10 ~-29 ~38 minecraft:sea_lantern
fill ~11 ~-29 ~38 ~13 ~-29 ~38 minecraft:smooth_stone
setblock ~14 ~-29 ~38 minecraft:sea_lantern
fill ~15 ~-29 ~38 ~21 ~-29 ~38 minecraft:smooth_stone
fill ~22 ~-29 ~38 ~25 ~-29 ~38 minecraft:smooth_quartz
setblock ~26 ~-29 ~38 minecraft:sea_lantern
fill ~27 ~-29 ~38 ~41 ~-29 ~38 minecraft:air
setblock ~42 ~-29 ~38 minecraft:sea_lantern
fill ~43 ~-29 ~38 ~46 ~-29 ~38 minecraft:smooth_quartz
fill ~47 ~-29 ~38 ~53 ~-29 ~38 minecraft:smooth_stone
setblock ~54 ~-29 ~38 minecraft:sea_lantern
fill ~55 ~-29 ~38 ~57 ~-29 ~38 minecraft:smooth_stone
setblock ~58 ~-29 ~38 minecraft:sea_lantern
fill ~59 ~-29 ~38 ~61 ~-29 ~38 minecraft:smooth_stone
setblock ~62 ~-29 ~38 minecraft:sea_lantern
fill ~63 ~-29 ~38 ~64 ~-29 ~38 minecraft:smooth_stone
fill ~4 ~-29 ~39 ~21 ~-29 ~39 minecraft:smooth_stone
fill ~22 ~-29 ~39 ~26 ~-29 ~39 minecraft:smooth_quartz
setblock ~27 ~-29 ~39 minecraft:sea_lantern
fill ~28 ~-29 ~39 ~40 ~-29 ~39 minecraft:air
setblock ~41 ~-29 ~39 minecraft:sea_lantern
fill ~42 ~-29 ~39 ~46 ~-29 ~39 minecraft:smooth_quartz
fill ~47 ~-29 ~39 ~64 ~-29 ~39 minecraft:smooth_stone
fill ~4 ~-29 ~40 ~22 ~-29 ~40 minecraft:smooth_stone
fill ~23 ~-29 ~40 ~26 ~-29 ~40 minecraft:smooth_quartz
setblock ~27 ~-29 ~40 minecraft:sea_lantern
fill ~28 ~-29 ~40 ~40 ~-29 ~40 minecraft:air
setblock ~41 ~-29 ~40 minecraft:sea_lantern
fill ~42 ~-29 ~40 ~45 ~-29 ~40 minecraft:smooth_quartz
fill ~46 ~-29 ~40 ~64 ~-29 ~40 minecraft:smooth_stone
fill ~4 ~-29 ~41 ~23 ~-29 ~41 minecraft:smooth_stone
fill ~24 ~-29 ~41 ~27 ~-29 ~41 minecraft:smooth_quartz
fill ~28 ~-29 ~41 ~29 ~-29 ~41 minecraft:sea_lantern
fill ~30 ~-29 ~41 ~38 ~-29 ~41 minecraft:air
fill ~39 ~-29 ~41 ~40 ~-29 ~41 minecraft:sea_lantern
fill ~41 ~-29 ~41 ~44 ~-29 ~41 minecraft:smooth_quartz
fill ~45 ~-29 ~41 ~64 ~-29 ~41 minecraft:smooth_stone
fill ~4 ~-29 ~42 ~5 ~-29 ~42 minecraft:smooth_stone
setblock ~6 ~-29 ~42 minecraft:sea_lantern
fill ~7 ~-29 ~42 ~9 ~-29 ~42 minecraft:smooth_stone
setblock ~10 ~-29 ~42 minecraft:sea_lantern
fill ~11 ~-29 ~42 ~13 ~-29 ~42 minecraft:smooth_stone
setblock ~14 ~-29 ~42 minecraft:sea_lantern
fill ~15 ~-29 ~42 ~21 ~-29 ~42 minecraft:smooth_stone
setblock ~22 ~-29 ~42 minecraft:sea_lantern
setblock ~23 ~-29 ~42 minecraft:smooth_stone
fill ~24 ~-29 ~42 ~29 ~-29 ~42 minecraft:smooth_quartz
fill ~30 ~-29 ~42 ~31 ~-29 ~42 minecraft:sea_lantern
fill ~32 ~-29 ~42 ~36 ~-29 ~42 minecraft:air
fill ~37 ~-29 ~42 ~38 ~-29 ~42 minecraft:sea_lantern
fill ~39 ~-29 ~42 ~44 ~-29 ~42 minecraft:smooth_quartz
setblock ~45 ~-29 ~42 minecraft:smooth_stone
setblock ~46 ~-29 ~42 minecraft:sea_lantern
fill ~47 ~-29 ~42 ~53 ~-29 ~42 minecraft:smooth_stone
setblock ~54 ~-29 ~42 minecraft:sea_lantern
fill ~55 ~-29 ~42 ~57 ~-29 ~42 minecraft:smooth_stone
setblock ~58 ~-29 ~42 minecraft:sea_lantern
fill ~59 ~-29 ~42 ~61 ~-29 ~42 minecraft:smooth_stone
setblock ~62 ~-29 ~42 minecraft:sea_lantern
fill ~63 ~-29 ~42 ~64 ~-29 ~42 minecraft:smooth_stone
fill ~4 ~-29 ~43 ~24 ~-29 ~43 minecraft:smooth_stone
fill ~25 ~-29 ~43 ~31 ~-29 ~43 minecraft:smooth_quartz
fill ~32 ~-29 ~43 ~36 ~-29 ~43 minecraft:sea_lantern
fill ~37 ~-29 ~43 ~43 ~-29 ~43 minecraft:smooth_quartz
fill ~44 ~-29 ~43 ~64 ~-29 ~43 minecraft:smooth_stone
fill ~4 ~-29 ~44 ~25 ~-29 ~44 minecraft:smooth_stone
fill ~26 ~-29 ~44 ~42 ~-29 ~44 minecraft:smooth_quartz
fill ~43 ~-29 ~44 ~64 ~-29 ~44 minecraft:smooth_stone
fill ~4 ~-29 ~45 ~27 ~-29 ~45 minecraft:smooth_stone
fill ~28 ~-29 ~45 ~40 ~-29 ~45 minecraft:smooth_quartz
fill ~41 ~-29 ~45 ~64 ~-29 ~45 minecraft:smooth_stone
fill ~4 ~-29 ~46 ~5 ~-29 ~46 minecraft:smooth_stone
setblock ~6 ~-29 ~46 minecraft:sea_lantern
fill ~7 ~-29 ~46 ~9 ~-29 ~46 minecraft:smooth_stone
setblock ~10 ~-29 ~46 minecraft:sea_lantern
fill ~11 ~-29 ~46 ~13 ~-29 ~46 minecraft:smooth_stone
setblock ~14 ~-29 ~46 minecraft:sea_lantern
fill ~15 ~-29 ~46 ~21 ~-29 ~46 minecraft:smooth_stone
setblock ~22 ~-29 ~46 minecraft:sea_lantern
fill ~23 ~-29 ~46 ~25 ~-29 ~46 minecraft:smooth_stone
setblock ~26 ~-29 ~46 minecraft:sea_lantern
fill ~27 ~-29 ~46 ~28 ~-29 ~46 minecraft:smooth_stone
fill ~29 ~-29 ~46 ~39 ~-29 ~46 minecraft:smooth_quartz
fill ~40 ~-29 ~46 ~41 ~-29 ~46 minecraft:smooth_stone
setblock ~42 ~-29 ~46 minecraft:sea_lantern
fill ~43 ~-29 ~46 ~45 ~-29 ~46 minecraft:smooth_stone
setblock ~46 ~-29 ~46 minecraft:sea_lantern
fill ~47 ~-29 ~46 ~53 ~-29 ~46 minecraft:smooth_stone
setblock ~54 ~-29 ~46 minecraft:sea_lantern
fill ~55 ~-29 ~46 ~57 ~-29 ~46 minecraft:smooth_stone
setblock ~58 ~-29 ~46 minecraft:sea_lantern
fill ~59 ~-29 ~46 ~61 ~-29 ~46 minecraft:smooth_stone
setblock ~62 ~-29 ~46 minecraft:sea_lantern
fill ~63 ~-29 ~46 ~64 ~-29 ~46 minecraft:smooth_stone
fill ~4 ~-29 ~47 ~33 ~-29 ~47 minecraft:smooth_stone
setblock ~34 ~-29 ~47 minecraft:smooth_quartz
fill ~35 ~-29 ~47 ~64 ~-29 ~47 minecraft:smooth_stone
fill ~4 ~-29 ~48 ~64 ~-29 ~48 minecraft:smooth_stone
fill ~4 ~-29 ~49 ~64 ~-29 ~49 minecraft:smooth_stone
fill ~4 ~-29 ~50 ~33 ~-29 ~50 minecraft:smooth_stone
setblock ~34 ~-29 ~50 minecraft:sea_lantern
fill ~35 ~-29 ~50 ~64 ~-29 ~50 minecraft:smooth_stone
fill ~4 ~-29 ~51 ~64 ~-29 ~51 minecraft:smooth_stone
fill ~4 ~-29 ~52 ~64 ~-29 ~52 minecraft:smooth_stone
fill ~4 ~-29 ~53 ~64 ~-29 ~53 minecraft:smooth_stone
fill ~4 ~-29 ~54 ~5 ~-29 ~54 minecraft:smooth_stone
setblock ~6 ~-29 ~54 minecraft:sea_lantern
fill ~7 ~-29 ~54 ~9 ~-29 ~54 minecraft:smooth_stone
setblock ~10 ~-29 ~54 minecraft:sea_lantern
fill ~11 ~-29 ~54 ~13 ~-29 ~54 minecraft:smooth_stone
setblock ~14 ~-29 ~54 minecraft:sea_lantern
fill ~15 ~-29 ~54 ~21 ~-29 ~54 minecraft:smooth_stone
setblock ~22 ~-29 ~54 minecraft:sea_lantern
fill ~23 ~-29 ~54 ~25 ~-29 ~54 minecraft:smooth_stone
setblock ~26 ~-29 ~54 minecraft:sea_lantern
fill ~27 ~-29 ~54 ~29 ~-29 ~54 minecraft:smooth_stone
setblock ~30 ~-29 ~54 minecraft:sea_lantern
fill ~31 ~-29 ~54 ~33 ~-29 ~54 minecraft:smooth_stone
setblock ~34 ~-29 ~54 minecraft:sea_lantern
fill ~35 ~-29 ~54 ~37 ~-29 ~54 minecraft:smooth_stone
setblock ~38 ~-29 ~54 minecraft:sea_lantern
fill ~39 ~-29 ~54 ~41 ~-29 ~54 minecraft:smooth_stone
setblock ~42 ~-29 ~54 minecraft:sea_lantern
fill ~43 ~-29 ~54 ~45 ~-29 ~54 minecraft:smooth_stone
setblock ~46 ~-29 ~54 minecraft:sea_lantern
fill ~47 ~-29 ~54 ~53 ~-29 ~54 minecraft:smooth_stone
setblock ~54 ~-29 ~54 minecraft:sea_lantern
fill ~55 ~-29 ~54 ~57 ~-29 ~54 minecraft:smooth_stone
setblock ~58 ~-29 ~54 minecraft:sea_lantern
fill ~59 ~-29 ~54 ~61 ~-29 ~54 minecraft:smooth_stone
setblock ~62 ~-29 ~54 minecraft:sea_lantern
fill ~63 ~-29 ~54 ~64 ~-29 ~54 minecraft:smooth_stone
fill ~4 ~-29 ~55 ~64 ~-29 ~55 minecraft:smooth_stone
fill ~4 ~-29 ~56 ~64 ~-29 ~56 minecraft:smooth_stone
fill ~4 ~-29 ~57 ~64 ~-29 ~57 minecraft:smooth_stone
fill ~4 ~-29 ~58 ~5 ~-29 ~58 minecraft:smooth_stone
setblock ~6 ~-29 ~58 minecraft:sea_lantern
fill ~7 ~-29 ~58 ~9 ~-29 ~58 minecraft:smooth_stone
setblock ~10 ~-29 ~58 minecraft:sea_lantern
fill ~11 ~-29 ~58 ~13 ~-29 ~58 minecraft:smooth_stone
setblock ~14 ~-29 ~58 minecraft:sea_lantern
fill ~15 ~-29 ~58 ~21 ~-29 ~58 minecraft:smooth_stone
setblock ~22 ~-29 ~58 minecraft:sea_lantern
fill ~23 ~-29 ~58 ~25 ~-29 ~58 minecraft:smooth_stone
setblock ~26 ~-29 ~58 minecraft:sea_lantern
fill ~27 ~-29 ~58 ~29 ~-29 ~58 minecraft:smooth_stone
setblock ~30 ~-29 ~58 minecraft:sea_lantern
fill ~31 ~-29 ~58 ~33 ~-29 ~58 minecraft:smooth_stone
setblock ~34 ~-29 ~58 minecraft:sea_lantern
fill ~35 ~-29 ~58 ~37 ~-29 ~58 minecraft:smooth_stone
setblock ~38 ~-29 ~58 minecraft:sea_lantern
fill ~39 ~-29 ~58 ~41 ~-29 ~58 minecraft:smooth_stone
setblock ~42 ~-29 ~58 minecraft:sea_lantern
fill ~43 ~-29 ~58 ~45 ~-29 ~58 minecraft:smooth_stone
setblock ~46 ~-29 ~58 minecraft:sea_lantern
fill ~47 ~-29 ~58 ~53 ~-29 ~58 minecraft:smooth_stone
setblock ~54 ~-29 ~58 minecraft:sea_lantern
fill ~55 ~-29 ~58 ~57 ~-29 ~58 minecraft:smooth_stone
setblock ~58 ~-29 ~58 minecraft:sea_lantern
fill ~59 ~-29 ~58 ~61 ~-29 ~58 minecraft:smooth_stone
setblock ~62 ~-29 ~58 minecraft:sea_lantern
fill ~63 ~-29 ~58 ~64 ~-29 ~58 minecraft:smooth_stone
fill ~4 ~-29 ~59 ~64 ~-29 ~59 minecraft:smooth_stone
fill ~4 ~-29 ~60 ~64 ~-29 ~60 minecraft:smooth_stone
fill ~4 ~-29 ~61 ~64 ~-29 ~61 minecraft:smooth_stone
fill ~4 ~-29 ~62 ~5 ~-29 ~62 minecraft:smooth_stone
setblock ~6 ~-29 ~62 minecraft:sea_lantern
fill ~7 ~-29 ~62 ~9 ~-29 ~62 minecraft:smooth_stone
setblock ~10 ~-29 ~62 minecraft:sea_lantern
fill ~11 ~-29 ~62 ~13 ~-29 ~62 minecraft:smooth_stone
setblock ~14 ~-29 ~62 minecraft:sea_lantern
fill ~15 ~-29 ~62 ~21 ~-29 ~62 minecraft:smooth_stone
setblock ~22 ~-29 ~62 minecraft:sea_lantern
fill ~23 ~-29 ~62 ~25 ~-29 ~62 minecraft:smooth_stone
setblock ~26 ~-29 ~62 minecraft:sea_lantern
fill ~27 ~-29 ~62 ~29 ~-29 ~62 minecraft:smooth_stone
setblock ~30 ~-29 ~62 minecraft:sea_lantern
fill ~31 ~-29 ~62 ~33 ~-29 ~62 minecraft:smooth_stone
setblock ~34 ~-29 ~62 minecraft:sea_lantern
fill ~35 ~-29 ~62 ~37 ~-29 ~62 minecraft:smooth_stone
setblock ~38 ~-29 ~62 minecraft:sea_lantern
fill ~39 ~-29 ~62 ~41 ~-29 ~62 minecraft:smooth_stone
setblock ~42 ~-29 ~62 minecraft:sea_lantern
fill ~43 ~-29 ~62 ~45 ~-29 ~62 minecraft:smooth_stone
setblock ~46 ~-29 ~62 minecraft:sea_lantern
fill ~47 ~-29 ~62 ~53 ~-29 ~62 minecraft:smooth_stone
setblock ~54 ~-29 ~62 minecraft:sea_lantern
fill ~55 ~-29 ~62 ~57 ~-29 ~62 minecraft:smooth_stone
setblock ~58 ~-29 ~62 minecraft:sea_lantern
fill ~59 ~-29 ~62 ~61 ~-29 ~62 minecraft:smooth_stone
setblock ~62 ~-29 ~62 minecraft:sea_lantern
fill ~63 ~-29 ~62 ~64 ~-29 ~62 minecraft:smooth_stone
fill ~4 ~-29 ~63 ~64 ~-29 ~63 minecraft:smooth_stone
fill ~4 ~-29 ~64 ~64 ~-29 ~64 minecraft:smooth_stone
fill ~32 ~-29 ~66 ~36 ~-29 ~66 minecraft:polished_andesite
setblock ~32 ~-29 ~67 minecraft:polished_andesite
setblock ~33 ~-29 ~67 minecraft:quartz_stairs[facing=east,half=bottom]
fill ~34 ~-29 ~67 ~35 ~-29 ~67 minecraft:air
setblock ~36 ~-29 ~67 minecraft:polished_andesite
setblock ~32 ~-29 ~68 minecraft:polished_andesite
setblock ~33 ~-29 ~68 minecraft:air
setblock ~34 ~-29 ~68 minecraft:quartz_pillar
setblock ~35 ~-29 ~68 minecraft:air
setblock ~36 ~-29 ~68 minecraft:polished_andesite
setblock ~32 ~-29 ~69 minecraft:polished_andesite
fill ~33 ~-29 ~69 ~35 ~-29 ~69 minecraft:air
setblock ~36 ~-29 ~69 minecraft:polished_andesite
fill ~32 ~-29 ~70 ~36 ~-29 ~70 minecraft:polished_andesite
fill ~4 ~-28 ~4 ~64 ~-28 ~4 minecraft:light_gray_concrete
setblock ~4 ~-28 ~5 minecraft:light_gray_concrete
fill ~5 ~-28 ~5 ~17 ~-28 ~5 minecraft:white_concrete
setblock ~18 ~-28 ~5 minecraft:light_gray_concrete
fill ~19 ~-28 ~5 ~31 ~-28 ~5 minecraft:spruce_planks
setblock ~32 ~-28 ~5 minecraft:light_gray_concrete
setblock ~33 ~-28 ~5 minecraft:white_concrete
setblock ~34 ~-28 ~5 minecraft:red_concrete
setblock ~35 ~-28 ~5 minecraft:white_concrete
setblock ~36 ~-28 ~5 minecraft:light_gray_concrete
fill ~37 ~-28 ~5 ~49 ~-28 ~5 minecraft:white_concrete
setblock ~50 ~-28 ~5 minecraft:light_gray_concrete
fill ~51 ~-28 ~5 ~63 ~-28 ~5 minecraft:white_concrete
setblock ~64 ~-28 ~5 minecraft:light_gray_concrete
setblock ~4 ~-28 ~6 minecraft:light_gray_concrete
fill ~5 ~-28 ~6 ~17 ~-28 ~6 minecraft:white_concrete
setblock ~18 ~-28 ~6 minecraft:light_gray_concrete
fill ~19 ~-28 ~6 ~31 ~-28 ~6 minecraft:spruce_planks
setblock ~32 ~-28 ~6 minecraft:light_gray_concrete
setblock ~33 ~-28 ~6 minecraft:white_concrete
setblock ~34 ~-28 ~6 minecraft:red_concrete
setblock ~35 ~-28 ~6 minecraft:white_concrete
setblock ~36 ~-28 ~6 minecraft:light_gray_concrete
fill ~37 ~-28 ~6 ~49 ~-28 ~6 minecraft:white_concrete
setblock ~50 ~-28 ~6 minecraft:light_gray_concrete
setblock ~51 ~-28 ~6 minecraft:white_concrete
fill ~52 ~-28 ~6 ~62 ~-28 ~6 minecraft:air
setblock ~63 ~-28 ~6 minecraft:white_concrete
setblock ~64 ~-28 ~6 minecraft:light_gray_concrete
setblock ~4 ~-28 ~7 minecraft:light_gray_concrete
fill ~5 ~-28 ~7 ~17 ~-28 ~7 minecraft:white_concrete
setblock ~18 ~-28 ~7 minecraft:light_gray_concrete
fill ~19 ~-28 ~7 ~31 ~-28 ~7 minecraft:spruce_planks
setblock ~32 ~-28 ~7 minecraft:light_gray_concrete
setblock ~33 ~-28 ~7 minecraft:white_concrete
setblock ~34 ~-28 ~7 minecraft:red_concrete
setblock ~35 ~-28 ~7 minecraft:white_concrete
setblock ~36 ~-28 ~7 minecraft:light_gray_concrete
fill ~37 ~-28 ~7 ~49 ~-28 ~7 minecraft:white_concrete
setblock ~50 ~-28 ~7 minecraft:light_gray_concrete
setblock ~51 ~-28 ~7 minecraft:white_concrete
fill ~52 ~-28 ~7 ~62 ~-28 ~7 minecraft:grass_block
setblock ~63 ~-28 ~7 minecraft:white_concrete
setblock ~64 ~-28 ~7 minecraft:light_gray_concrete
setblock ~4 ~-28 ~8 minecraft:light_gray_concrete
fill ~5 ~-28 ~8 ~17 ~-28 ~8 minecraft:white_concrete
setblock ~18 ~-28 ~8 minecraft:light_gray_concrete
fill ~19 ~-28 ~8 ~31 ~-28 ~8 minecraft:spruce_planks
setblock ~32 ~-28 ~8 minecraft:light_gray_concrete
setblock ~33 ~-28 ~8 minecraft:white_concrete
setblock ~34 ~-28 ~8 minecraft:red_concrete
setblock ~35 ~-28 ~8 minecraft:white_concrete
setblock ~36 ~-28 ~8 minecraft:light_gray_concrete
fill ~37 ~-28 ~8 ~49 ~-28 ~8 minecraft:white_concrete
setblock ~50 ~-28 ~8 minecraft:light_gray_concrete
setblock ~51 ~-28 ~8 minecraft:white_concrete
fill ~52 ~-28 ~8 ~62 ~-28 ~8 minecraft:dirt_path
setblock ~63 ~-28 ~8 minecraft:white_concrete
setblock ~64 ~-28 ~8 minecraft:light_gray_concrete
setblock ~4 ~-28 ~9 minecraft:light_gray_concrete
fill ~5 ~-28 ~9 ~17 ~-28 ~9 minecraft:white_concrete
setblock ~18 ~-28 ~9 minecraft:light_gray_concrete
fill ~19 ~-28 ~9 ~31 ~-28 ~9 minecraft:spruce_planks
setblock ~32 ~-28 ~9 minecraft:light_gray_concrete
setblock ~33 ~-28 ~9 minecraft:white_concrete
setblock ~34 ~-28 ~9 minecraft:red_concrete
setblock ~35 ~-28 ~9 minecraft:white_concrete
setblock ~36 ~-28 ~9 minecraft:light_gray_concrete
fill ~37 ~-28 ~9 ~49 ~-28 ~9 minecraft:white_concrete
setblock ~50 ~-28 ~9 minecraft:light_gray_concrete
setblock ~51 ~-28 ~9 minecraft:white_concrete
fill ~52 ~-28 ~9 ~62 ~-28 ~9 minecraft:farmland[moisture=7]
setblock ~63 ~-28 ~9 minecraft:white_concrete
setblock ~64 ~-28 ~9 minecraft:light_gray_concrete
setblock ~4 ~-28 ~10 minecraft:light_gray_concrete
fill ~5 ~-28 ~10 ~17 ~-28 ~10 minecraft:white_concrete
setblock ~18 ~-28 ~10 minecraft:light_gray_concrete
fill ~19 ~-28 ~10 ~31 ~-28 ~10 minecraft:spruce_planks
setblock ~32 ~-28 ~10 minecraft:light_gray_concrete
setblock ~33 ~-28 ~10 minecraft:white_concrete
setblock ~34 ~-28 ~10 minecraft:red_concrete
setblock ~35 ~-28 ~10 minecraft:white_concrete
setblock ~36 ~-28 ~10 minecraft:light_gray_concrete
fill ~37 ~-28 ~10 ~49 ~-28 ~10 minecraft:white_concrete
setblock ~50 ~-28 ~10 minecraft:light_gray_concrete
setblock ~51 ~-28 ~10 minecraft:white_concrete
fill ~52 ~-28 ~10 ~62 ~-28 ~10 minecraft:air
setblock ~63 ~-28 ~10 minecraft:white_concrete
setblock ~64 ~-28 ~10 minecraft:light_gray_concrete
setblock ~4 ~-28 ~11 minecraft:light_gray_concrete
fill ~5 ~-28 ~11 ~17 ~-28 ~11 minecraft:white_concrete
setblock ~18 ~-28 ~11 minecraft:light_gray_concrete
fill ~19 ~-28 ~11 ~31 ~-28 ~11 minecraft:spruce_planks
setblock ~32 ~-28 ~11 minecraft:light_gray_concrete
setblock ~33 ~-28 ~11 minecraft:white_concrete
setblock ~34 ~-28 ~11 minecraft:red_concrete
setblock ~35 ~-28 ~11 minecraft:white_concrete
setblock ~36 ~-28 ~11 minecraft:light_gray_concrete
fill ~37 ~-28 ~11 ~49 ~-28 ~11 minecraft:white_concrete
setblock ~50 ~-28 ~11 minecraft:light_gray_concrete
fill ~51 ~-28 ~11 ~52 ~-28 ~11 minecraft:white_concrete
fill ~53 ~-28 ~11 ~62 ~-28 ~11 minecraft:grass_block
setblock ~63 ~-28 ~11 minecraft:white_concrete
setblock ~64 ~-28 ~11 minecraft:light_gray_concrete
setblock ~4 ~-28 ~12 minecraft:light_gray_concrete
fill ~5 ~-28 ~12 ~17 ~-28 ~12 minecraft:white_concrete
setblock ~18 ~-28 ~12 minecraft:light_gray_concrete
fill ~19 ~-28 ~12 ~31 ~-28 ~12 minecraft:spruce_planks
setblock ~32 ~-28 ~12 minecraft:light_gray_concrete
setblock ~33 ~-28 ~12 minecraft:white_concrete
setblock ~34 ~-28 ~12 minecraft:red_concrete
setblock ~35 ~-28 ~12 minecraft:white_concrete
setblock ~36 ~-28 ~12 minecraft:light_gray_concrete
fill ~37 ~-28 ~12 ~49 ~-28 ~12 minecraft:white_concrete
setblock ~50 ~-28 ~12 minecraft:light_gray_concrete
setblock ~51 ~-28 ~12 minecraft:white_concrete
fill ~52 ~-28 ~12 ~62 ~-28 ~12 minecraft:dirt_path
setblock ~63 ~-28 ~12 minecraft:white_concrete
setblock ~64 ~-28 ~12 minecraft:light_gray_concrete
setblock ~4 ~-28 ~13 minecraft:light_gray_concrete
fill ~5 ~-28 ~13 ~17 ~-28 ~13 minecraft:white_concrete
setblock ~18 ~-28 ~13 minecraft:light_gray_concrete
fill ~19 ~-28 ~13 ~31 ~-28 ~13 minecraft:spruce_planks
setblock ~32 ~-28 ~13 minecraft:light_gray_concrete
setblock ~33 ~-28 ~13 minecraft:white_concrete
setblock ~34 ~-28 ~13 minecraft:red_concrete
setblock ~35 ~-28 ~13 minecraft:white_concrete
setblock ~36 ~-28 ~13 minecraft:light_gray_concrete
fill ~37 ~-28 ~13 ~49 ~-28 ~13 minecraft:white_concrete
setblock ~50 ~-28 ~13 minecraft:light_gray_concrete
setblock ~51 ~-28 ~13 minecraft:white_concrete
fill ~52 ~-28 ~13 ~62 ~-28 ~13 minecraft:farmland[moisture=7]
setblock ~63 ~-28 ~13 minecraft:white_concrete
setblock ~64 ~-28 ~13 minecraft:light_gray_concrete
setblock ~4 ~-28 ~14 minecraft:light_gray_concrete
fill ~5 ~-28 ~14 ~17 ~-28 ~14 minecraft:white_concrete
setblock ~18 ~-28 ~14 minecraft:light_gray_concrete
fill ~19 ~-28 ~14 ~31 ~-28 ~14 minecraft:spruce_planks
setblock ~32 ~-28 ~14 minecraft:light_gray_concrete
setblock ~33 ~-28 ~14 minecraft:white_concrete
setblock ~34 ~-28 ~14 minecraft:red_concrete
setblock ~35 ~-28 ~14 minecraft:white_concrete
setblock ~36 ~-28 ~14 minecraft:light_gray_concrete
fill ~37 ~-28 ~14 ~49 ~-28 ~14 minecraft:white_concrete
setblock ~50 ~-28 ~14 minecraft:light_gray_concrete
setblock ~51 ~-28 ~14 minecraft:white_concrete
fill ~52 ~-28 ~14 ~62 ~-28 ~14 minecraft:air
setblock ~63 ~-28 ~14 minecraft:white_concrete
setblock ~64 ~-28 ~14 minecraft:light_gray_concrete
setblock ~4 ~-28 ~15 minecraft:light_gray_concrete
fill ~5 ~-28 ~15 ~17 ~-28 ~15 minecraft:white_concrete
setblock ~18 ~-28 ~15 minecraft:light_gray_concrete
fill ~19 ~-28 ~15 ~31 ~-28 ~15 minecraft:spruce_planks
setblock ~32 ~-28 ~15 minecraft:light_gray_concrete
setblock ~33 ~-28 ~15 minecraft:white_concrete
setblock ~34 ~-28 ~15 minecraft:red_concrete
setblock ~35 ~-28 ~15 minecraft:white_concrete
setblock ~36 ~-28 ~15 minecraft:light_gray_concrete
fill ~37 ~-28 ~15 ~49 ~-28 ~15 minecraft:white_concrete
setblock ~50 ~-28 ~15 minecraft:light_gray_concrete
setblock ~51 ~-28 ~15 minecraft:white_concrete
fill ~52 ~-28 ~15 ~62 ~-28 ~15 minecraft:grass_block
setblock ~63 ~-28 ~15 minecraft:white_concrete
setblock ~64 ~-28 ~15 minecraft:light_gray_concrete
setblock ~4 ~-28 ~16 minecraft:light_gray_concrete
fill ~5 ~-28 ~16 ~17 ~-28 ~16 minecraft:white_concrete
setblock ~18 ~-28 ~16 minecraft:light_gray_concrete
fill ~19 ~-28 ~16 ~31 ~-28 ~16 minecraft:spruce_planks
setblock ~32 ~-28 ~16 minecraft:light_gray_concrete
setblock ~33 ~-28 ~16 minecraft:white_concrete
setblock ~34 ~-28 ~16 minecraft:red_concrete
setblock ~35 ~-28 ~16 minecraft:white_concrete
setblock ~36 ~-28 ~16 minecraft:light_gray_concrete
fill ~37 ~-28 ~16 ~49 ~-28 ~16 minecraft:white_concrete
setblock ~50 ~-28 ~16 minecraft:light_gray_concrete
setblock ~51 ~-28 ~16 minecraft:white_concrete
fill ~52 ~-28 ~16 ~56 ~-28 ~16 minecraft:dirt_path
setblock ~57 ~-28 ~16 minecraft:white_concrete
fill ~58 ~-28 ~16 ~62 ~-28 ~16 minecraft:dirt_path
setblock ~63 ~-28 ~16 minecraft:white_concrete
setblock ~64 ~-28 ~16 minecraft:light_gray_concrete
setblock ~4 ~-28 ~17 minecraft:light_gray_concrete
fill ~5 ~-28 ~17 ~17 ~-28 ~17 minecraft:white_concrete
setblock ~18 ~-28 ~17 minecraft:light_gray_concrete
fill ~19 ~-28 ~17 ~31 ~-28 ~17 minecraft:spruce_planks
setblock ~32 ~-28 ~17 minecraft:light_gray_concrete
setblock ~33 ~-28 ~17 minecraft:white_concrete
setblock ~34 ~-28 ~17 minecraft:red_concrete
setblock ~35 ~-28 ~17 minecraft:white_concrete
setblock ~36 ~-28 ~17 minecraft:light_gray_concrete
fill ~37 ~-28 ~17 ~49 ~-28 ~17 minecraft:white_concrete
setblock ~50 ~-28 ~17 minecraft:light_gray_concrete
fill ~51 ~-28 ~17 ~63 ~-28 ~17 minecraft:white_concrete
setblock ~64 ~-28 ~17 minecraft:light_gray_concrete
fill ~4 ~-28 ~18 ~32 ~-28 ~18 minecraft:light_gray_concrete
setblock ~33 ~-28 ~18 minecraft:white_concrete
setblock ~34 ~-28 ~18 minecraft:red_concrete
setblock ~35 ~-28 ~18 minecraft:white_concrete
fill ~36 ~-28 ~18 ~64 ~-28 ~18 minecraft:light_gray_concrete
setblock ~4 ~-28 ~19 minecraft:light_gray_concrete
fill ~5 ~-28 ~19 ~17 ~-28 ~19 minecraft:packed_ice
setblock ~18 ~-28 ~19 minecraft:light_gray_concrete
fill ~19 ~-28 ~19 ~31 ~-28 ~19 minecraft:white_concrete
setblock ~32 ~-28 ~19 minecraft:light_gray_concrete
setblock ~33 ~-28 ~19 minecraft:white_concrete
setblock ~34 ~-28 ~19 minecraft:red_concrete
setblock ~35 ~-28 ~19 minecraft:white_concrete
setblock ~36 ~-28 ~19 minecraft:light_gray_concrete
fill ~37 ~-28 ~19 ~49 ~-28 ~19 minecraft:white_concrete
setblock ~50 ~-28 ~19 minecraft:light_gray_concrete
fill ~51 ~-28 ~19 ~63 ~-28 ~19 minecraft:white_concrete
setblock ~64 ~-28 ~19 minecraft:light_gray_concrete
setblock ~4 ~-28 ~20 minecraft:light_gray_concrete
fill ~5 ~-28 ~20 ~17 ~-28 ~20 minecraft:packed_ice
setblock ~18 ~-28 ~20 minecraft:light_gray_concrete
fill ~19 ~-28 ~20 ~31 ~-28 ~20 minecraft:white_concrete
setblock ~32 ~-28 ~20 minecraft:light_gray_concrete
setblock ~33 ~-28 ~20 minecraft:white_concrete
setblock ~34 ~-28 ~20 minecraft:red_concrete
setblock ~35 ~-28 ~20 minecraft:white_concrete
setblock ~36 ~-28 ~20 minecraft:light_gray_concrete
fill ~37 ~-28 ~20 ~38 ~-28 ~20 minecraft:white_concrete
fill ~39 ~-28 ~20 ~48 ~-28 ~20 minecraft:dirt_path
setblock ~49 ~-28 ~20 minecraft:white_concrete
setblock ~50 ~-28 ~20 minecraft:light_gray_concrete
fill ~51 ~-28 ~20 ~63 ~-28 ~20 minecraft:white_concrete
setblock ~64 ~-28 ~20 minecraft:light_gray_concrete
setblock ~4 ~-28 ~21 minecraft:light_gray_concrete
fill ~5 ~-28 ~21 ~17 ~-28 ~21 minecraft:packed_ice
setblock ~18 ~-28 ~21 minecraft:light_gray_concrete
fill ~19 ~-28 ~21 ~31 ~-28 ~21 minecraft:white_concrete
setblock ~32 ~-28 ~21 minecraft:light_gray_concrete
setblock ~33 ~-28 ~21 minecraft:white_concrete
setblock ~34 ~-28 ~21 minecraft:smooth_quartz
setblock ~35 ~-28 ~21 minecraft:white_concrete
setblock ~36 ~-28 ~21 minecraft:light_gray_concrete
fill ~37 ~-28 ~21 ~40 ~-28 ~21 minecraft:white_concrete
fill ~41 ~-28 ~21 ~48 ~-28 ~21 minecraft:farmland[moisture=7]
setblock ~49 ~-28 ~21 minecraft:white_concrete
setblock ~50 ~-28 ~21 minecraft:light_gray_concrete
fill ~51 ~-28 ~21 ~63 ~-28 ~21 minecraft:white_concrete
setblock ~64 ~-28 ~21 minecraft:light_gray_concrete
setblock ~4 ~-28 ~22 minecraft:light_gray_concrete
fill ~5 ~-28 ~22 ~17 ~-28 ~22 minecraft:packed_ice
setblock ~18 ~-28 ~22 minecraft:light_gray_concrete
fill ~19 ~-28 ~22 ~28 ~-28 ~22 minecraft:white_concrete
fill ~29 ~-28 ~22 ~32 ~-28 ~22 minecraft:polished_andesite
fill ~33 ~-28 ~22 ~35 ~-28 ~22 minecraft:smooth_quartz
fill ~36 ~-28 ~22 ~39 ~-28 ~22 minecraft:polished_andesite
fill ~40 ~-28 ~22 ~41 ~-28 ~22 minecraft:white_concrete
fill ~42 ~-28 ~22 ~48 ~-28 ~22 minecraft:air
setblock ~49 ~-28 ~22 minecraft:white_concrete
setblock ~50 ~-28 ~22 minecraft:light_gray_concrete
fill ~51 ~-28 ~22 ~63 ~-28 ~22 minecraft:white_concrete
setblock ~64 ~-28 ~22 minecraft:light_gray_concrete
setblock ~4 ~-28 ~23 minecraft:light_gray_concrete
fill ~5 ~-28 ~23 ~17 ~-28 ~23 minecraft:packed_ice
setblock ~18 ~-28 ~23 minecraft:light_gray_concrete
fill ~19 ~-28 ~23 ~27 ~-28 ~23 minecraft:white_concrete
fill ~28 ~-28 ~23 ~29 ~-28 ~23 minecraft:polished_andesite
fill ~30 ~-28 ~23 ~33 ~-28 ~23 minecraft:smooth_quartz
setblock ~34 ~-28 ~23 minecraft:polished_diorite
fill ~35 ~-28 ~23 ~38 ~-28 ~23 minecraft:smooth_quartz
fill ~39 ~-28 ~23 ~40 ~-28 ~23 minecraft:polished_andesite
fill ~41 ~-28 ~23 ~43 ~-28 ~23 minecraft:white_concrete
fill ~44 ~-28 ~23 ~48 ~-28 ~23 minecraft:grass_block
setblock ~49 ~-28 ~23 minecraft:white_concrete
setblock ~50 ~-28 ~23 minecraft:light_gray_concrete
fill ~51 ~-28 ~23 ~63 ~-28 ~23 minecraft:white_concrete
setblock ~64 ~-28 ~23 minecraft:light_gray_concrete
setblock ~4 ~-28 ~24 minecraft:light_gray_concrete
fill ~5 ~-28 ~24 ~17 ~-28 ~24 minecraft:packed_ice
setblock ~18 ~-28 ~24 minecraft:light_gray_concrete
fill ~19 ~-28 ~24 ~25 ~-28 ~24 minecraft:white_concrete
fill ~26 ~-28 ~24 ~27 ~-28 ~24 minecraft:polished_andesite
fill ~28 ~-28 ~24 ~29 ~-28 ~24 minecraft:smooth_quartz
fill ~30 ~-28 ~24 ~33 ~-28 ~24 minecraft:polished_diorite
setblock ~34 ~-28 ~24 minecraft:smooth_quartz
fill ~35 ~-28 ~24 ~38 ~-28 ~24 minecraft:polished_diorite
fill ~39 ~-28 ~24 ~40 ~-28 ~24 minecraft:smooth_quartz
fill ~41 ~-28 ~24 ~42 ~-28 ~24 minecraft:polished_andesite
fill ~43 ~-28 ~24 ~44 ~-28 ~24 minecraft:white_concrete
fill ~45 ~-28 ~24 ~48 ~-28 ~24 minecraft:dirt_path
setblock ~49 ~-28 ~24 minecraft:white_concrete
setblock ~50 ~-28 ~24 minecraft:light_gray_concrete
fill ~51 ~-28 ~24 ~63 ~-28 ~24 minecraft:white_concrete
setblock ~64 ~-28 ~24 minecraft:light_gray_concrete
setblock ~4 ~-28 ~25 minecraft:light_gray_concrete
fill ~5 ~-28 ~25 ~17 ~-28 ~25 minecraft:packed_ice
setblock ~18 ~-28 ~25 minecraft:light_gray_concrete
fill ~19 ~-28 ~25 ~24 ~-28 ~25 minecraft:white_concrete
fill ~25 ~-28 ~25 ~26 ~-28 ~25 minecraft:polished_andesite
setblock ~27 ~-28 ~25 minecraft:smooth_quartz
fill ~28 ~-28 ~25 ~29 ~-28 ~25 minecraft:polished_diorite
fill ~30 ~-28 ~25 ~31 ~-28 ~25 minecraft:smooth_quartz
fill ~32 ~-28 ~25 ~36 ~-28 ~25 minecraft:red_concrete
fill ~37 ~-28 ~25 ~38 ~-28 ~25 minecraft:smooth_quartz
fill ~39 ~-28 ~25 ~40 ~-28 ~25 minecraft:polished_diorite
setblock ~41 ~-28 ~25 minecraft:smooth_quartz
fill ~42 ~-28 ~25 ~43 ~-28 ~25 minecraft:polished_andesite
fill ~44 ~-28 ~25 ~45 ~-28 ~25 minecraft:white_concrete
fill ~46 ~-28 ~25 ~48 ~-28 ~25 minecraft:farmland[moisture=7]
setblock ~49 ~-28 ~25 minecraft:white_concrete
setblock ~50 ~-28 ~25 minecraft:light_gray_concrete
fill ~51 ~-28 ~25 ~63 ~-28 ~25 minecraft:white_concrete
setblock ~64 ~-28 ~25 minecraft:light_gray_concrete
setblock ~4 ~-28 ~26 minecraft:light_gray_concrete
fill ~5 ~-28 ~26 ~17 ~-28 ~26 minecraft:packed_ice
setblock ~18 ~-28 ~26 minecraft:light_gray_concrete
fill ~19 ~-28 ~26 ~23 ~-28 ~26 minecraft:white_concrete
fill ~24 ~-28 ~26 ~25 ~-28 ~26 minecraft:polished_andesite
setblock ~26 ~-28 ~26 minecraft:smooth_quartz
setblock ~27 ~-28 ~26 minecraft:polished_diorite
fill ~28 ~-28 ~26 ~29 ~-28 ~26 minecraft:smooth_quartz
fill ~30 ~-28 ~26 ~31 ~-28 ~26 minecraft:red_concrete
fill ~32 ~-28 ~26 ~36 ~-28 ~26 minecraft:air
fill ~37 ~-28 ~26 ~38 ~-28 ~26 minecraft:red_concrete
fill ~39 ~-28 ~26 ~40 ~-28 ~26 minecraft:smooth_quartz
setblock ~41 ~-28 ~26 minecraft:polished_diorite
setblock ~42 ~-28 ~26 minecraft:smooth_quartz
fill ~43 ~-28 ~26 ~44 ~-28 ~26 minecraft:polished_andesite
setblock ~45 ~-28 ~26 minecraft:white_concrete
fill ~46 ~-28 ~26 ~48 ~-28 ~26 minecraft:air
setblock ~49 ~-28 ~26 minecraft:white_concrete
setblock ~50 ~-28 ~26 minecraft:light_gray_concrete
fill ~51 ~-28 ~26 ~63 ~-28 ~26 minecraft:white_concrete
setblock ~64 ~-28 ~26 minecraft:light_gray_concrete
setblock ~4 ~-28 ~27 minecraft:light_gray_concrete
fill ~5 ~-28 ~27 ~17 ~-28 ~27 minecraft:packed_ice
setblock ~18 ~-28 ~27 minecraft:light_gray_concrete
fill ~19 ~-28 ~27 ~23 ~-28 ~27 minecraft:white_concrete
setblock ~24 ~-28 ~27 minecraft:polished_andesite
setblock ~25 ~-28 ~27 minecraft:smooth_quartz
setblock ~26 ~-28 ~27 minecraft:polished_diorite
setblock ~27 ~-28 ~27 minecraft:smooth_quartz
fill ~28 ~-28 ~27 ~29 ~-28 ~27 minecraft:red_concrete
fill ~30 ~-28 ~27 ~38 ~-28 ~27 minecraft:air
fill ~39 ~-28 ~27 ~40 ~-28 ~27 minecraft:red_concrete
setblock ~41 ~-28 ~27 minecraft:smooth_quartz
setblock ~42 ~-28 ~27 minecraft:polished_diorite
setblock ~43 ~-28 ~27 minecraft:smooth_quartz
setblock ~44 ~-28 ~27 minecraft:polished_andesite
fill ~45 ~-28 ~27 ~46 ~-28 ~27 minecraft:white_concrete
fill ~47 ~-28 ~27 ~48 ~-28 ~27 minecraft:grass_block
setblock ~49 ~-28 ~27 minecraft:white_concrete
setblock ~50 ~-28 ~27 minecraft:light_gray_concrete
fill ~51 ~-28 ~27 ~63 ~-28 ~27 minecraft:white_concrete
setblock ~64 ~-28 ~27 minecraft:light_gray_concrete
setblock ~4 ~-28 ~28 minecraft:light_gray_concrete
fill ~5 ~-28 ~28 ~17 ~-28 ~28 minecraft:packed_ice
setblock ~18 ~-28 ~28 minecraft:light_gray_concrete
fill ~19 ~-28 ~28 ~22 ~-28 ~28 minecraft:white_concrete
setblock ~23 ~-28 ~28 minecraft:polished_andesite
setblock ~24 ~-28 ~28 minecraft:smooth_quartz
setblock ~25 ~-28 ~28 minecraft:polished_diorite
setblock ~26 ~-28 ~28 minecraft:smooth_quartz
setblock ~27 ~-28 ~28 minecraft:red_concrete
fill ~28 ~-28 ~28 ~40 ~-28 ~28 minecraft:air
setblock ~41 ~-28 ~28 minecraft:red_concrete
setblock ~42 ~-28 ~28 minecraft:smooth_quartz
setblock ~43 ~-28 ~28 minecraft:polished_diorite
setblock ~44 ~-28 ~28 minecraft:smooth_quartz
setblock ~45 ~-28 ~28 minecraft:polished_andesite
fill ~46 ~-28 ~28 ~47 ~-28 ~28 minecraft:white_concrete
setblock ~48 ~-28 ~28 minecraft:dirt_path
setblock ~49 ~-28 ~28 minecraft:white_concrete
setblock ~50 ~-28 ~28 minecraft:light_gray_concrete
fill ~51 ~-28 ~28 ~63 ~-28 ~28 minecraft:white_concrete
setblock ~64 ~-28 ~28 minecraft:light_gray_concrete
setblock ~4 ~-28 ~29 minecraft:light_gray_concrete
fill ~5 ~-28 ~29 ~17 ~-28 ~29 minecraft:packed_ice
setblock ~18 ~-28 ~29 minecraft:light_gray_concrete
fill ~19 ~-28 ~29 ~21 ~-28 ~29 minecraft:white_concrete
fill ~22 ~-28 ~29 ~23 ~-28 ~29 minecraft:polished_andesite
setblock ~24 ~-28 ~29 minecraft:smooth_quartz
setblock ~25 ~-28 ~29 minecraft:polished_diorite
setblock ~26 ~-28 ~29 minecraft:smooth_quartz
setblock ~27 ~-28 ~29 minecraft:red_concrete
fill ~28 ~-28 ~29 ~40 ~-28 ~29 minecraft:air
setblock ~41 ~-28 ~29 minecraft:red_concrete
setblock ~42 ~-28 ~29 minecraft:smooth_quartz
setblock ~43 ~-28 ~29 minecraft:polished_diorite
setblock ~44 ~-28 ~29 minecraft:smooth_quartz
fill ~45 ~-28 ~29 ~46 ~-28 ~29 minecraft:polished_andesite
setblock ~47 ~-28 ~29 minecraft:white_concrete
setblock ~48 ~-28 ~29 minecraft:farmland[moisture=7]
setblock ~49 ~-28 ~29 minecraft:white_concrete
setblock ~50 ~-28 ~29 minecraft:light_gray_concrete
fill ~51 ~-28 ~29 ~63 ~-28 ~29 minecraft:white_concrete
setblock ~64 ~-28 ~29 minecraft:light_gray_concrete
setblock ~4 ~-28 ~30 minecraft:light_gray_concrete
fill ~5 ~-28 ~30 ~17 ~-28 ~30 minecraft:packed_ice
setblock ~18 ~-28 ~30 minecraft:light_gray_concrete
fill ~19 ~-28 ~30 ~21 ~-28 ~30 minecraft:white_concrete
setblock ~22 ~-28 ~30 minecraft:polished_andesite
setblock ~23 ~-28 ~30 minecraft:smooth_quartz
setblock ~24 ~-28 ~30 minecraft:polished_diorite
setblock ~25 ~-28 ~30 minecraft:smooth_quartz
setblock ~26 ~-28 ~30 minecraft:red_concrete
fill ~27 ~-28 ~30 ~41 ~-28 ~30 minecraft:air
setblock ~42 ~-28 ~30 minecraft:red_concrete
setblock ~43 ~-28 ~30 minecraft:smooth_quartz
setblock ~44 ~-28 ~30 minecraft:polished_diorite
setblock ~45 ~-28 ~30 minecraft:smooth_quartz
setblock ~46 ~-28 ~30 minecraft:polished_andesite
fill ~47 ~-28 ~30 ~49 ~-28 ~30 minecraft:white_concrete
setblock ~50 ~-28 ~30 minecraft:light_gray_concrete
fill ~51 ~-28 ~30 ~63 ~-28 ~30 minecraft:white_concrete
setblock ~64 ~-28 ~30 minecraft:light_gray_concrete
setblock ~4 ~-28 ~31 minecraft:light_gray_concrete
fill ~5 ~-28 ~31 ~17 ~-28 ~31 minecraft:packed_ice
setblock ~18 ~-28 ~31 minecraft:light_gray_concrete
fill ~19 ~-28 ~31 ~21 ~-28 ~31 minecraft:white_concrete
setblock ~22 ~-28 ~31 minecraft:polished_andesite
setblock ~23 ~-28 ~31 minecraft:smooth_quartz
setblock ~24 ~-28 ~31 minecraft:polished_diorite
setblock ~25 ~-28 ~31 minecraft:smooth_quartz
setblock ~26 ~-28 ~31 minecraft:red_concrete
fill ~27 ~-28 ~31 ~31 ~-28 ~31 minecraft:air
fill ~32 ~-28 ~31 ~36 ~-28 ~31 minecraft:iron_block
fill ~37 ~-28 ~31 ~41 ~-28 ~31 minecraft:air
setblock ~42 ~-28 ~31 minecraft:red_concrete
setblock ~43 ~-28 ~31 minecraft:smooth_quartz
setblock ~44 ~-28 ~31 minecraft:polished_diorite
setblock ~45 ~-28 ~31 minecraft:smooth_quartz
setblock ~46 ~-28 ~31 minecraft:polished_andesite
fill ~47 ~-28 ~31 ~49 ~-28 ~31 minecraft:white_concrete
setblock ~50 ~-28 ~31 minecraft:light_gray_concrete
fill ~51 ~-28 ~31 ~63 ~-28 ~31 minecraft:white_concrete
setblock ~64 ~-28 ~31 minecraft:light_gray_concrete
fill ~4 ~-28 ~32 ~21 ~-28 ~32 minecraft:light_gray_concrete
setblock ~22 ~-28 ~32 minecraft:polished_andesite
setblock ~23 ~-28 ~32 minecraft:smooth_quartz
setblock ~24 ~-28 ~32 minecraft:polished_diorite
setblock ~25 ~-28 ~32 minecraft:red_concrete
fill ~26 ~-28 ~32 ~32 ~-28 ~32 minecraft:iron_block
fill ~33 ~-28 ~32 ~35 ~-28 ~32 minecraft:glass
setblock ~36 ~-28 ~32 minecraft:iron_block
fill ~37 ~-28 ~32 ~42 ~-28 ~32 minecraft:air
setblock ~43 ~-28 ~32 minecraft:red_concrete
setblock ~44 ~-28 ~32 minecraft:polished_diorite
setblock ~45 ~-28 ~32 minecraft:smooth_quartz
setblock ~46 ~-28 ~32 minecraft:polished_andesite
fill ~47 ~-28 ~32 ~64 ~-28 ~32 minecraft:light_gray_concrete
setblock ~4 ~-28 ~33 minecraft:light_gray_concrete
fill ~5 ~-28 ~33 ~21 ~-28 ~33 minecraft:white_concrete
fill ~22 ~-28 ~33 ~23 ~-28 ~33 minecraft:smooth_quartz
setblock ~24 ~-28 ~33 minecraft:polished_diorite
setblock ~25 ~-28 ~33 minecraft:red_concrete
fill ~26 ~-28 ~33 ~31 ~-28 ~33 minecraft:polished_andesite
setblock ~32 ~-28 ~33 minecraft:iron_block
setblock ~33 ~-28 ~33 minecraft:glass
setblock ~34 ~-28 ~33 minecraft:air
setblock ~35 ~-28 ~33 minecraft:glass
setblock ~36 ~-28 ~33 minecraft:iron_block
fill ~37 ~-28 ~33 ~42 ~-28 ~33 minecraft:air
setblock ~43 ~-28 ~33 minecraft:red_concrete
setblock ~44 ~-28 ~33 minecraft:polished_diorite
fill ~45 ~-28 ~33 ~46 ~-28 ~33 minecraft:smooth_quartz
fill ~47 ~-28 ~33 ~63 ~-28 ~33 minecraft:white_concrete
setblock ~64 ~-28 ~33 minecraft:light_gray_concrete
setblock ~4 ~-28 ~34 minecraft:light_gray_concrete
fill ~5 ~-28 ~34 ~20 ~-28 ~34 minecraft:red_concrete
fill ~21 ~-28 ~34 ~22 ~-28 ~34 minecraft:smooth_quartz
setblock ~23 ~-28 ~34 minecraft:polished_diorite
setblock ~24 ~-28 ~34 minecraft:smooth_quartz
setblock ~25 ~-28 ~34 minecraft:red_concrete
fill ~26 ~-28 ~34 ~31 ~-28 ~34 minecraft:polished_andesite
setblock ~32 ~-28 ~34 minecraft:iron_block
fill ~33 ~-28 ~34 ~35 ~-28 ~34 minecraft:glass
setblock ~36 ~-28 ~34 minecraft:iron_block
fill ~37 ~-28 ~34 ~42 ~-28 ~34 minecraft:air
setblock ~43 ~-28 ~34 minecraft:red_concrete
setblock ~44 ~-28 ~34 minecraft:smooth_quartz
setblock ~45 ~-28 ~34 minecraft:polished_diorite
fill ~46 ~-28 ~34 ~47 ~-28 ~34 minecraft:smooth_quartz
fill ~48 ~-28 ~34 ~63 ~-28 ~34 minecraft:red_concrete
setblock ~64 ~-28 ~34 minecraft:light_gray_concrete
setblock ~4 ~-28 ~35 minecraft:light_gray_concrete
fill ~5 ~-28 ~35 ~21 ~-28 ~35 minecraft:white_concrete
fill ~22 ~-28 ~35 ~23 ~-28 ~35 minecraft:smooth_quartz
setblock ~24 ~-28 ~35 minecraft:polished_diorite
setblock ~25 ~-28 ~35 minecraft:red_concrete
fill ~26 ~-28 ~35 ~31 ~-28 ~35 minecraft:polished_andesite
setblock ~32 ~-28 ~35 minecraft:iron_block
setblock ~33 ~-28 ~35 minecraft:glass
setblock ~34 ~-28 ~35 minecraft:air
setblock ~35 ~-28 ~35 minecraft:glass
setblock ~36 ~-28 ~35 minecraft:iron_block
fill ~37 ~-28 ~35 ~42 ~-28 ~35 minecraft:air
setblock ~43 ~-28 ~35 minecraft:red_concrete
setblock ~44 ~-28 ~35 minecraft:polished_diorite
fill ~45 ~-28 ~35 ~46 ~-28 ~35 minecraft:smooth_quartz
fill ~47 ~-28 ~35 ~63 ~-28 ~35 minecraft:white_concrete
setblock ~64 ~-28 ~35 minecraft:light_gray_concrete
fill ~4 ~-28 ~36 ~21 ~-28 ~36 minecraft:light_gray_concrete
setblock ~22 ~-28 ~36 minecraft:polished_andesite
setblock ~23 ~-28 ~36 minecraft:smooth_quartz
setblock ~24 ~-28 ~36 minecraft:polished_diorite
setblock ~25 ~-28 ~36 minecraft:red_concrete
fill ~26 ~-28 ~36 ~32 ~-28 ~36 minecraft:iron_block
fill ~33 ~-28 ~36 ~35 ~-28 ~36 minecraft:glass
setblock ~36 ~-28 ~36 minecraft:iron_block
fill ~37 ~-28 ~36 ~42 ~-28 ~36 minecraft:air
setblock ~43 ~-28 ~36 minecraft:red_concrete
setblock ~44 ~-28 ~36 minecraft:polished_diorite
setblock ~45 ~-28 ~36 minecraft:smooth_quartz
setblock ~46 ~-28 ~36 minecraft:polished_andesite
fill ~47 ~-28 ~36 ~64 ~-28 ~36 minecraft:light_gray_concrete
setblock ~4 ~-28 ~37 minecraft:light_gray_concrete
fill ~5 ~-28 ~37 ~17 ~-28 ~37 minecraft:dark_oak_planks
setblock ~18 ~-28 ~37 minecraft:light_gray_concrete
fill ~19 ~-28 ~37 ~21 ~-28 ~37 minecraft:white_concrete
setblock ~22 ~-28 ~37 minecraft:polished_andesite
setblock ~23 ~-28 ~37 minecraft:smooth_quartz
setblock ~24 ~-28 ~37 minecraft:polished_diorite
setblock ~25 ~-28 ~37 minecraft:smooth_quartz
setblock ~26 ~-28 ~37 minecraft:red_concrete
fill ~27 ~-28 ~37 ~31 ~-28 ~37 minecraft:air
fill ~32 ~-28 ~37 ~36 ~-28 ~37 minecraft:iron_block
fill ~37 ~-28 ~37 ~41 ~-28 ~37 minecraft:air
setblock ~42 ~-28 ~37 minecraft:red_concrete
setblock ~43 ~-28 ~37 minecraft:smooth_quartz
setblock ~44 ~-28 ~37 minecraft:polished_diorite
setblock ~45 ~-28 ~37 minecraft:smooth_quartz
setblock ~46 ~-28 ~37 minecraft:polished_andesite
fill ~47 ~-28 ~37 ~49 ~-28 ~37 minecraft:white_concrete
setblock ~50 ~-28 ~37 minecraft:light_gray_concrete
fill ~51 ~-28 ~37 ~63 ~-28 ~37 minecraft:packed_ice
setblock ~64 ~-28 ~37 minecraft:light_gray_concrete
setblock ~4 ~-28 ~38 minecraft:light_gray_concrete
fill ~5 ~-28 ~38 ~17 ~-28 ~38 minecraft:dark_oak_planks
setblock ~18 ~-28 ~38 minecraft:light_gray_concrete
fill ~19 ~-28 ~38 ~21 ~-28 ~38 minecraft:white_concrete
setblock ~22 ~-28 ~38 minecraft:polished_andesite
setblock ~23 ~-28 ~38 minecraft:smooth_quartz
setblock ~24 ~-28 ~38 minecraft:polished_diorite
setblock ~25 ~-28 ~38 minecraft:smooth_quartz
setblock ~26 ~-28 ~38 minecraft:red_concrete
fill ~27 ~-28 ~38 ~41 ~-28 ~38 minecraft:air
setblock ~42 ~-28 ~38 minecraft:red_concrete
setblock ~43 ~-28 ~38 minecraft:smooth_quartz
setblock ~44 ~-28 ~38 minecraft:polished_diorite
setblock ~45 ~-28 ~38 minecraft:smooth_quartz
setblock ~46 ~-28 ~38 minecraft:polished_andesite
fill ~47 ~-28 ~38 ~49 ~-28 ~38 minecraft:white_concrete
setblock ~50 ~-28 ~38 minecraft:light_gray_concrete
fill ~51 ~-28 ~38 ~63 ~-28 ~38 minecraft:packed_ice
setblock ~64 ~-28 ~38 minecraft:light_gray_concrete
setblock ~4 ~-28 ~39 minecraft:light_gray_concrete
fill ~5 ~-28 ~39 ~17 ~-28 ~39 minecraft:dark_oak_planks
setblock ~18 ~-28 ~39 minecraft:light_gray_concrete
fill ~19 ~-28 ~39 ~21 ~-28 ~39 minecraft:white_concrete
schedule function hive:weiter/11 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 10 von 18 fertig","color":"gray"}]