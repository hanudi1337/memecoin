setblock ~24 ~-26 ~49 minecraft:brewing_stand
setblock ~27 ~-26 ~49 minecraft:brewing_stand
setblock ~30 ~-26 ~49 minecraft:brewing_stand
setblock ~40 ~-26 ~51 minecraft:lantern[hanging=false]
setblock ~44 ~-26 ~51 minecraft:lantern[hanging=false]
setblock ~48 ~-26 ~51 minecraft:lantern[hanging=false]
setblock ~37 ~-26 ~54 minecraft:lantern[hanging=false]
setblock ~49 ~-26 ~54 minecraft:lantern[hanging=false]
setblock ~41 ~-26 ~55 minecraft:lantern[hanging=false]
setblock ~45 ~-26 ~55 minecraft:lantern[hanging=false]
setblock ~41 ~-26 ~59 minecraft:lantern[hanging=false]
setblock ~45 ~-26 ~59 minecraft:lantern[hanging=false]
setblock ~24 ~-26 ~60 minecraft:lantern[hanging=false]
setblock ~37 ~-26 ~62 minecraft:lantern[hanging=false]
setblock ~49 ~-26 ~62 minecraft:lantern[hanging=false]
setblock ~40 ~-26 ~63 minecraft:lantern[hanging=false]
setblock ~44 ~-26 ~63 minecraft:lantern[hanging=false]
setblock ~48 ~-26 ~63 minecraft:lantern[hanging=false]
setblock ~25 ~-23 ~5 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~33 ~-23 ~5 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~34 ~-23 ~5 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~35 ~-23 ~5 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~31 ~-23 ~23 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~37 ~-23 ~23 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~23 ~-23 ~31 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~45 ~-23 ~31 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~5 ~-23 ~33 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~63 ~-23 ~33 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~5 ~-23 ~34 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~63 ~-23 ~34 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~5 ~-23 ~35 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~63 ~-23 ~35 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~23 ~-23 ~37 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~45 ~-23 ~37 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~31 ~-23 ~45 minecraft:white_wall_banner[facing=north]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~37 ~-23 ~45 minecraft:white_wall_banner[facing=north]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~25 ~-23 ~63 minecraft:white_wall_banner[facing=north]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~34 ~-22 ~17 minecraft:spruce_hanging_sign[rotation=0]{front_text:{messages:['""','"B2"','""','""']},back_text:{messages:['""','"B2"','""','""']}}
setblock ~17 ~-22 ~34 minecraft:spruce_hanging_sign[rotation=4]{front_text:{messages:['""','"B2"','""','""']},back_text:{messages:['""','"B2"','""','""']}}
setblock ~51 ~-22 ~34 minecraft:spruce_hanging_sign[rotation=4]{front_text:{messages:['""','"B2"','""','""']},back_text:{messages:['""','"B2"','""','""']}}
setblock ~34 ~-22 ~51 minecraft:spruce_hanging_sign[rotation=0]{front_text:{messages:['""','"B2"','""','""']},back_text:{messages:['""','"B2"','""','""']}}
setblock ~33 ~-19 ~5 minecraft:potted_azalea_bush
setblock ~35 ~-19 ~5 minecraft:potted_azalea_bush
setblock ~51 ~-19 ~19 minecraft:potted_azalea_bush
setblock ~63 ~-19 ~19 minecraft:potted_azalea_bush
setblock ~49 ~-19 ~20 minecraft:potted_azalea_bush
setblock ~39 ~-19 ~21 minecraft:potted_azalea_bush
setblock ~49 ~-19 ~23 minecraft:potted_azalea_bush
setblock ~44 ~-19 ~25 minecraft:potted_azalea_bush
setblock ~49 ~-19 ~26 minecraft:potted_azalea_bush
setblock ~49 ~-19 ~29 minecraft:potted_azalea_bush
setblock ~51 ~-19 ~31 minecraft:potted_azalea_bush
setblock ~63 ~-19 ~31 minecraft:potted_azalea_bush
setblock ~5 ~-19 ~33 minecraft:potted_azalea_bush
setblock ~63 ~-19 ~33 minecraft:potted_azalea_bush
setblock ~5 ~-19 ~35 minecraft:potted_azalea_bush
setblock ~63 ~-19 ~35 minecraft:potted_azalea_bush
setblock ~46 ~-19 ~40 minecraft:potted_azalea_bush
setblock ~45 ~-19 ~41 minecraft:potted_azalea_bush
setblock ~44 ~-19 ~43 minecraft:potted_azalea_bush
setblock ~43 ~-19 ~44 minecraft:potted_azalea_bush
setblock ~49 ~-19 ~49 minecraft:potted_azalea_bush
setblock ~5 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~8 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~11 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~14 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~17 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~53 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~56 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~59 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~62 ~-18 ~5 minecraft:lantern[hanging=false]
setblock ~5 ~-18 ~8 minecraft:lantern[hanging=false]
setblock ~17 ~-18 ~8 minecraft:lantern[hanging=false]
setblock ~56 ~-18 ~8 minecraft:lantern[hanging=false]
setblock ~60 ~-18 ~8 minecraft:lantern[hanging=false]
setblock ~40 ~-18 ~10 minecraft:lantern[hanging=false]
setblock ~43 ~-18 ~10 minecraft:lantern[hanging=false]
setblock ~46 ~-18 ~10 minecraft:lantern[hanging=false]
setblock ~5 ~-18 ~11 minecraft:lantern[hanging=false]
setblock ~11 ~-18 ~11 minecraft:lantern[hanging=false]
setblock ~40 ~-18 ~11 minecraft:lantern[hanging=false]
setblock ~43 ~-18 ~11 minecraft:lantern[hanging=false]
setblock ~46 ~-18 ~11 minecraft:lantern[hanging=false]
setblock ~56 ~-18 ~12 minecraft:lantern[hanging=false]
setblock ~60 ~-18 ~12 minecraft:lantern[hanging=false]
setblock ~5 ~-18 ~14 minecraft:lantern[hanging=false]
setblock ~17 ~-18 ~14 minecraft:lantern[hanging=false]
setblock ~56 ~-18 ~16 minecraft:lantern[hanging=false]
setblock ~60 ~-18 ~16 minecraft:lantern[hanging=false]
setblock ~5 ~-18 ~17 minecraft:lantern[hanging=false]
setblock ~8 ~-18 ~17 minecraft:lantern[hanging=false]
setblock ~14 ~-18 ~17 minecraft:lantern[hanging=false]
setblock ~17 ~-18 ~17 minecraft:lantern[hanging=false]
setblock ~57 ~-18 ~25 minecraft:lantern[hanging=false]
setblock ~58 ~-18 ~25 minecraft:lantern[hanging=false]
setblock ~57 ~-18 ~41 minecraft:lantern[hanging=false]
setblock ~57 ~-18 ~42 minecraft:brewing_stand
setblock ~25 ~-18 ~43 minecraft:lantern[hanging=false]
setblock ~57 ~-18 ~43 minecraft:lantern[hanging=false]
setblock ~57 ~-18 ~44 minecraft:brewing_stand
setblock ~57 ~-18 ~45 minecraft:lantern[hanging=false]
setblock ~42 ~-18 ~46 minecraft:lantern[hanging=false]
setblock ~52 ~-18 ~51 minecraft:lantern[hanging=false]
setblock ~55 ~-18 ~51 minecraft:lantern[hanging=false]
setblock ~61 ~-18 ~51 minecraft:lantern[hanging=false]
setblock ~11 ~-18 ~55 minecraft:lantern[hanging=false]
setblock ~51 ~-18 ~55 minecraft:lantern[hanging=false]
setblock ~63 ~-18 ~55 minecraft:lantern[hanging=false]
setblock ~57 ~-18 ~57 minecraft:lantern[hanging=false]
setblock ~11 ~-18 ~58 minecraft:lantern[hanging=false]
setblock ~63 ~-18 ~58 minecraft:lantern[hanging=false]
setblock ~51 ~-18 ~61 minecraft:lantern[hanging=false]
setblock ~63 ~-18 ~61 minecraft:lantern[hanging=false]
setblock ~52 ~-18 ~63 minecraft:lantern[hanging=false]
setblock ~55 ~-18 ~63 minecraft:lantern[hanging=false]
setblock ~58 ~-18 ~63 minecraft:lantern[hanging=false]
setblock ~61 ~-18 ~63 minecraft:lantern[hanging=false]
setblock ~33 ~-15 ~5 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~34 ~-15 ~5 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~35 ~-15 ~5 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~31 ~-15 ~23 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~37 ~-15 ~23 minecraft:white_wall_banner[facing=south]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~23 ~-15 ~31 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~45 ~-15 ~31 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~5 ~-15 ~33 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~63 ~-15 ~33 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~5 ~-15 ~34 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~63 ~-15 ~34 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~5 ~-15 ~35 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~63 ~-15 ~35 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~23 ~-15 ~37 minecraft:white_wall_banner[facing=east]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~45 ~-15 ~37 minecraft:white_wall_banner[facing=west]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~31 ~-15 ~45 minecraft:white_wall_banner[facing=north]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~37 ~-15 ~45 minecraft:white_wall_banner[facing=north]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~43 ~-15 ~49 minecraft:white_wall_banner[facing=north]{Patterns:[{Pattern:"cr",Color:14},{Pattern:"sc",Color:14},{Pattern:"mc",Color:0}]}
setblock ~34 ~-14 ~17 minecraft:spruce_hanging_sign[rotation=0]{front_text:{messages:['""','"B1"','""','""']},back_text:{messages:['""','"B1"','""','""']}}
setblock ~17 ~-14 ~34 minecraft:spruce_hanging_sign[rotation=4]{front_text:{messages:['""','"B1"','""','""']},back_text:{messages:['""','"B1"','""','""']}}
setblock ~51 ~-14 ~34 minecraft:spruce_hanging_sign[rotation=4]{front_text:{messages:['""','"B1"','""','""']},back_text:{messages:['""','"B1"','""','""']}}
setblock ~34 ~-14 ~51 minecraft:spruce_hanging_sign[rotation=0]{front_text:{messages:['""','"B1"','""','""']},back_text:{messages:['""','"B1"','""','""']}}
setblock ~29 ~3 ~24 minecraft:decorated_pot
setblock ~38 ~3 ~24 minecraft:decorated_pot
setblock ~32 ~3 ~27 minecraft:decorated_pot
setblock ~35 ~3 ~27 minecraft:decorated_pot
setblock ~32 ~3 ~31 minecraft:decorated_pot
setblock ~36 ~3 ~31 minecraft:decorated_pot
setblock ~32 ~3 ~37 minecraft:decorated_pot
setblock ~36 ~3 ~37 minecraft:decorated_pot
setblock ~29 ~3 ~44 minecraft:decorated_pot
setblock ~38 ~3 ~44 minecraft:decorated_pot
setblock ~31 ~3 ~47 minecraft:decorated_pot
setblock ~36 ~3 ~47 minecraft:decorated_pot
setblock ~33 ~12 ~33 minecraft:lantern[hanging=true]
setblock ~34 ~12 ~39 minecraft:lantern[hanging=true]
setblock ~33 ~12 ~42 minecraft:lantern[hanging=true]
setblock ~39 ~-68 ~7 minecraft:water
setblock ~40 ~-68 ~7 minecraft:water
setblock ~41 ~-68 ~7 minecraft:water
setblock ~42 ~-68 ~7 minecraft:water
setblock ~43 ~-68 ~7 minecraft:water
setblock ~44 ~-68 ~7 minecraft:water
setblock ~45 ~-68 ~7 minecraft:water
setblock ~46 ~-68 ~7 minecraft:water
setblock ~47 ~-68 ~7 minecraft:water
setblock ~53 ~-68 ~7 minecraft:water
setblock ~54 ~-68 ~7 minecraft:water
setblock ~55 ~-68 ~7 minecraft:water
setblock ~56 ~-68 ~7 minecraft:water
setblock ~57 ~-68 ~7 minecraft:water
setblock ~58 ~-68 ~7 minecraft:water
setblock ~59 ~-68 ~7 minecraft:water
setblock ~60 ~-68 ~7 minecraft:water
setblock ~61 ~-68 ~7 minecraft:water
setblock ~39 ~-68 ~8 minecraft:water
setblock ~40 ~-68 ~8 minecraft:water
setblock ~41 ~-68 ~8 minecraft:water
setblock ~42 ~-68 ~8 minecraft:water
setblock ~43 ~-68 ~8 minecraft:water
setblock ~44 ~-68 ~8 minecraft:water
setblock ~45 ~-68 ~8 minecraft:water
setblock ~46 ~-68 ~8 minecraft:water
setblock ~47 ~-68 ~8 minecraft:water
setblock ~53 ~-68 ~8 minecraft:water
setblock ~54 ~-68 ~8 minecraft:water
setblock ~55 ~-68 ~8 minecraft:water
setblock ~56 ~-68 ~8 minecraft:water
setblock ~57 ~-68 ~8 minecraft:water
setblock ~58 ~-68 ~8 minecraft:water
setblock ~59 ~-68 ~8 minecraft:water
setblock ~60 ~-68 ~8 minecraft:water
setblock ~61 ~-68 ~8 minecraft:water
setblock ~39 ~-68 ~9 minecraft:water
setblock ~40 ~-68 ~9 minecraft:water
setblock ~41 ~-68 ~9 minecraft:water
setblock ~42 ~-68 ~9 minecraft:water
setblock ~43 ~-68 ~9 minecraft:water
setblock ~44 ~-68 ~9 minecraft:water
setblock ~45 ~-68 ~9 minecraft:water
setblock ~46 ~-68 ~9 minecraft:water
setblock ~47 ~-68 ~9 minecraft:water
setblock ~53 ~-68 ~9 minecraft:water
setblock ~54 ~-68 ~9 minecraft:water
setblock ~55 ~-68 ~9 minecraft:water
setblock ~56 ~-68 ~9 minecraft:water
setblock ~57 ~-68 ~9 minecraft:water
setblock ~58 ~-68 ~9 minecraft:water
setblock ~59 ~-68 ~9 minecraft:water
setblock ~60 ~-68 ~9 minecraft:water
setblock ~61 ~-68 ~9 minecraft:water
setblock ~39 ~-68 ~10 minecraft:water
setblock ~40 ~-68 ~10 minecraft:water
setblock ~41 ~-68 ~10 minecraft:water
setblock ~42 ~-68 ~10 minecraft:water
setblock ~43 ~-68 ~10 minecraft:water
setblock ~44 ~-68 ~10 minecraft:water
setblock ~45 ~-68 ~10 minecraft:water
setblock ~46 ~-68 ~10 minecraft:water
setblock ~47 ~-68 ~10 minecraft:water
setblock ~53 ~-68 ~10 minecraft:water
setblock ~54 ~-68 ~10 minecraft:water
setblock ~55 ~-68 ~10 minecraft:water
setblock ~56 ~-68 ~10 minecraft:water
setblock ~57 ~-68 ~10 minecraft:water
setblock ~58 ~-68 ~10 minecraft:water
setblock ~59 ~-68 ~10 minecraft:water
setblock ~60 ~-68 ~10 minecraft:water
setblock ~61 ~-68 ~10 minecraft:water
setblock ~39 ~-68 ~11 minecraft:water
setblock ~40 ~-68 ~11 minecraft:water
setblock ~41 ~-68 ~11 minecraft:water
setblock ~42 ~-68 ~11 minecraft:water
setblock ~43 ~-68 ~11 minecraft:water
setblock ~44 ~-68 ~11 minecraft:water
setblock ~45 ~-68 ~11 minecraft:water
setblock ~46 ~-68 ~11 minecraft:water
setblock ~47 ~-68 ~11 minecraft:water
setblock ~53 ~-68 ~11 minecraft:water
setblock ~54 ~-68 ~11 minecraft:water
setblock ~55 ~-68 ~11 minecraft:water
setblock ~56 ~-68 ~11 minecraft:water
setblock ~57 ~-68 ~11 minecraft:water
setblock ~58 ~-68 ~11 minecraft:water
setblock ~59 ~-68 ~11 minecraft:water
setblock ~60 ~-68 ~11 minecraft:water
setblock ~61 ~-68 ~11 minecraft:water
setblock ~39 ~-68 ~12 minecraft:water
setblock ~40 ~-68 ~12 minecraft:water
setblock ~41 ~-68 ~12 minecraft:water
setblock ~42 ~-68 ~12 minecraft:water
setblock ~43 ~-68 ~12 minecraft:water
setblock ~44 ~-68 ~12 minecraft:water
setblock ~45 ~-68 ~12 minecraft:water
setblock ~46 ~-68 ~12 minecraft:water
setblock ~47 ~-68 ~12 minecraft:water
setblock ~53 ~-68 ~12 minecraft:water
setblock ~54 ~-68 ~12 minecraft:water
setblock ~55 ~-68 ~12 minecraft:water
setblock ~56 ~-68 ~12 minecraft:water
setblock ~57 ~-68 ~12 minecraft:water
setblock ~58 ~-68 ~12 minecraft:water
setblock ~59 ~-68 ~12 minecraft:water
setblock ~60 ~-68 ~12 minecraft:water
setblock ~61 ~-68 ~12 minecraft:water
setblock ~39 ~-68 ~13 minecraft:water
setblock ~40 ~-68 ~13 minecraft:water
setblock ~41 ~-68 ~13 minecraft:water
setblock ~42 ~-68 ~13 minecraft:water
setblock ~43 ~-68 ~13 minecraft:water
setblock ~44 ~-68 ~13 minecraft:water
setblock ~45 ~-68 ~13 minecraft:water
setblock ~46 ~-68 ~13 minecraft:water
setblock ~47 ~-68 ~13 minecraft:water
setblock ~53 ~-68 ~13 minecraft:water
setblock ~54 ~-68 ~13 minecraft:water
setblock ~55 ~-68 ~13 minecraft:water
setblock ~56 ~-68 ~13 minecraft:water
setblock ~57 ~-68 ~13 minecraft:water
setblock ~58 ~-68 ~13 minecraft:water
setblock ~59 ~-68 ~13 minecraft:water
setblock ~60 ~-68 ~13 minecraft:water
setblock ~61 ~-68 ~13 minecraft:water
setblock ~39 ~-68 ~14 minecraft:water
setblock ~40 ~-68 ~14 minecraft:water
setblock ~41 ~-68 ~14 minecraft:water
setblock ~42 ~-68 ~14 minecraft:water
setblock ~43 ~-68 ~14 minecraft:water
setblock ~44 ~-68 ~14 minecraft:water
setblock ~45 ~-68 ~14 minecraft:water
setblock ~46 ~-68 ~14 minecraft:water
setblock ~47 ~-68 ~14 minecraft:water
setblock ~53 ~-68 ~14 minecraft:water
setblock ~54 ~-68 ~14 minecraft:water
setblock ~55 ~-68 ~14 minecraft:water
setblock ~56 ~-68 ~14 minecraft:water
setblock ~57 ~-68 ~14 minecraft:water
setblock ~58 ~-68 ~14 minecraft:water
setblock ~59 ~-68 ~14 minecraft:water
setblock ~60 ~-68 ~14 minecraft:water
setblock ~61 ~-68 ~14 minecraft:water
setblock ~39 ~-68 ~15 minecraft:water
setblock ~40 ~-68 ~15 minecraft:water
setblock ~41 ~-68 ~15 minecraft:water
setblock ~42 ~-68 ~15 minecraft:water
setblock ~43 ~-68 ~15 minecraft:water
setblock ~44 ~-68 ~15 minecraft:water
setblock ~45 ~-68 ~15 minecraft:water
setblock ~46 ~-68 ~15 minecraft:water
setblock ~47 ~-68 ~15 minecraft:water
setblock ~53 ~-68 ~15 minecraft:water
setblock ~54 ~-68 ~15 minecraft:water
setblock ~55 ~-68 ~15 minecraft:water
setblock ~56 ~-68 ~15 minecraft:water
setblock ~57 ~-68 ~15 minecraft:water
setblock ~58 ~-68 ~15 minecraft:water
setblock ~59 ~-68 ~15 minecraft:water
setblock ~60 ~-68 ~15 minecraft:water
setblock ~61 ~-68 ~15 minecraft:water
setblock ~53 ~-68 ~53 minecraft:water
setblock ~54 ~-68 ~53 minecraft:water
setblock ~55 ~-68 ~53 minecraft:water
setblock ~56 ~-68 ~53 minecraft:water
setblock ~57 ~-68 ~53 minecraft:water
setblock ~58 ~-68 ~53 minecraft:water
setblock ~59 ~-68 ~53 minecraft:water
setblock ~60 ~-68 ~53 minecraft:water
setblock ~61 ~-68 ~53 minecraft:water
setblock ~53 ~-68 ~54 minecraft:water
setblock ~54 ~-68 ~54 minecraft:water
setblock ~55 ~-68 ~54 minecraft:water
setblock ~56 ~-68 ~54 minecraft:water
setblock ~57 ~-68 ~54 minecraft:water
setblock ~58 ~-68 ~54 minecraft:water
setblock ~59 ~-68 ~54 minecraft:water
setblock ~60 ~-68 ~54 minecraft:water
setblock ~61 ~-68 ~54 minecraft:water
setblock ~53 ~-68 ~55 minecraft:water
setblock ~54 ~-68 ~55 minecraft:water
setblock ~55 ~-68 ~55 minecraft:water
setblock ~56 ~-68 ~55 minecraft:water
setblock ~57 ~-68 ~55 minecraft:water
setblock ~58 ~-68 ~55 minecraft:water
setblock ~59 ~-68 ~55 minecraft:water
setblock ~60 ~-68 ~55 minecraft:water
setblock ~61 ~-68 ~55 minecraft:water
setblock ~53 ~-68 ~56 minecraft:water
setblock ~54 ~-68 ~56 minecraft:water
setblock ~55 ~-68 ~56 minecraft:water
setblock ~56 ~-68 ~56 minecraft:water
setblock ~57 ~-68 ~56 minecraft:water
setblock ~58 ~-68 ~56 minecraft:water
setblock ~59 ~-68 ~56 minecraft:water
setblock ~60 ~-68 ~56 minecraft:water
setblock ~61 ~-68 ~56 minecraft:water
setblock ~53 ~-68 ~57 minecraft:water
setblock ~54 ~-68 ~57 minecraft:water
setblock ~55 ~-68 ~57 minecraft:water
setblock ~56 ~-68 ~57 minecraft:water
setblock ~57 ~-68 ~57 minecraft:water
setblock ~58 ~-68 ~57 minecraft:water
setblock ~59 ~-68 ~57 minecraft:water
setblock ~60 ~-68 ~57 minecraft:water
setblock ~61 ~-68 ~57 minecraft:water
setblock ~53 ~-68 ~58 minecraft:water
setblock ~54 ~-68 ~58 minecraft:water
setblock ~55 ~-68 ~58 minecraft:water
setblock ~56 ~-68 ~58 minecraft:water
setblock ~57 ~-68 ~58 minecraft:water
setblock ~58 ~-68 ~58 minecraft:water
setblock ~59 ~-68 ~58 minecraft:water
setblock ~60 ~-68 ~58 minecraft:water
setblock ~61 ~-68 ~58 minecraft:water
setblock ~53 ~-68 ~59 minecraft:water
setblock ~54 ~-68 ~59 minecraft:water
setblock ~55 ~-68 ~59 minecraft:water
setblock ~56 ~-68 ~59 minecraft:water
setblock ~57 ~-68 ~59 minecraft:water
setblock ~58 ~-68 ~59 minecraft:water
setblock ~59 ~-68 ~59 minecraft:water
setblock ~60 ~-68 ~59 minecraft:water
setblock ~61 ~-68 ~59 minecraft:water
setblock ~53 ~-68 ~60 minecraft:water
setblock ~54 ~-68 ~60 minecraft:water
setblock ~55 ~-68 ~60 minecraft:water
setblock ~56 ~-68 ~60 minecraft:water
setblock ~57 ~-68 ~60 minecraft:water
setblock ~58 ~-68 ~60 minecraft:water
setblock ~59 ~-68 ~60 minecraft:water
setblock ~60 ~-68 ~60 minecraft:water
setblock ~61 ~-68 ~60 minecraft:water
setblock ~53 ~-68 ~61 minecraft:water
setblock ~54 ~-68 ~61 minecraft:water
setblock ~55 ~-68 ~61 minecraft:water
setblock ~56 ~-68 ~61 minecraft:water
setblock ~57 ~-68 ~61 minecraft:water
setblock ~58 ~-68 ~61 minecraft:water
setblock ~59 ~-68 ~61 minecraft:water
setblock ~60 ~-68 ~61 minecraft:water
setblock ~61 ~-68 ~61 minecraft:water
setblock ~34 ~-43 ~33 minecraft:water
setblock ~34 ~-43 ~35 minecraft:water
setblock ~34 ~-42 ~33 minecraft:water
setblock ~34 ~-42 ~35 minecraft:water
setblock ~34 ~-41 ~33 minecraft:water
setblock ~34 ~-41 ~35 minecraft:water
setblock ~34 ~-40 ~33 minecraft:water
setblock ~34 ~-40 ~35 minecraft:water
setblock ~34 ~-39 ~33 minecraft:water
setblock ~34 ~-39 ~35 minecraft:water
setblock ~34 ~-38 ~33 minecraft:water
setblock ~34 ~-38 ~35 minecraft:water
setblock ~34 ~-37 ~33 minecraft:water
setblock ~34 ~-37 ~35 minecraft:water
setblock ~34 ~-36 ~33 minecraft:water
setblock ~34 ~-36 ~35 minecraft:water
setblock ~34 ~-35 ~33 minecraft:water
setblock ~34 ~-35 ~35 minecraft:water
setblock ~34 ~-34 ~33 minecraft:water
setblock ~34 ~-34 ~35 minecraft:water
setblock ~34 ~-33 ~33 minecraft:water
setblock ~34 ~-33 ~35 minecraft:water
setblock ~34 ~-32 ~33 minecraft:water
setblock ~34 ~-32 ~35 minecraft:water
setblock ~34 ~-31 ~33 minecraft:water
setblock ~34 ~-31 ~35 minecraft:water
setblock ~34 ~-30 ~33 minecraft:water
setblock ~34 ~-30 ~35 minecraft:water
setblock ~34 ~-29 ~33 minecraft:water
setblock ~34 ~-29 ~35 minecraft:water
setblock ~52 ~-28 ~6 minecraft:water
setblock ~53 ~-28 ~6 minecraft:water
setblock ~54 ~-28 ~6 minecraft:water
setblock ~55 ~-28 ~6 minecraft:water
setblock ~56 ~-28 ~6 minecraft:water
setblock ~57 ~-28 ~6 minecraft:water
setblock ~58 ~-28 ~6 minecraft:water
setblock ~59 ~-28 ~6 minecraft:water
setblock ~60 ~-28 ~6 minecraft:water
setblock ~61 ~-28 ~6 minecraft:water
setblock ~62 ~-28 ~6 minecraft:water
setblock ~52 ~-28 ~10 minecraft:water
setblock ~53 ~-28 ~10 minecraft:water
setblock ~54 ~-28 ~10 minecraft:water
setblock ~55 ~-28 ~10 minecraft:water
setblock ~56 ~-28 ~10 minecraft:water
setblock ~57 ~-28 ~10 minecraft:water
setblock ~58 ~-28 ~10 minecraft:water
setblock ~59 ~-28 ~10 minecraft:water
setblock ~60 ~-28 ~10 minecraft:water
setblock ~61 ~-28 ~10 minecraft:water
setblock ~62 ~-28 ~10 minecraft:water
setblock ~52 ~-28 ~14 minecraft:water
setblock ~53 ~-28 ~14 minecraft:water
setblock ~54 ~-28 ~14 minecraft:water
setblock ~55 ~-28 ~14 minecraft:water
setblock ~56 ~-28 ~14 minecraft:water
setblock ~57 ~-28 ~14 minecraft:water
setblock ~58 ~-28 ~14 minecraft:water
setblock ~59 ~-28 ~14 minecraft:water
setblock ~60 ~-28 ~14 minecraft:water
setblock ~61 ~-28 ~14 minecraft:water
setblock ~62 ~-28 ~14 minecraft:water
setblock ~42 ~-28 ~22 minecraft:water
setblock ~43 ~-28 ~22 minecraft:water
setblock ~44 ~-28 ~22 minecraft:water
setblock ~45 ~-28 ~22 minecraft:water
setblock ~46 ~-28 ~22 minecraft:water
setblock ~47 ~-28 ~22 minecraft:water
setblock ~48 ~-28 ~22 minecraft:water
setblock ~46 ~-28 ~26 minecraft:water
setblock ~47 ~-28 ~26 minecraft:water
setblock ~48 ~-28 ~26 minecraft:water
setblock ~34 ~-28 ~33 minecraft:water
setblock ~34 ~-28 ~35 minecraft:water
setblock ~34 ~-27 ~33 minecraft:water
setblock ~34 ~-27 ~35 minecraft:water
setblock ~21 ~-26 ~21 minecraft:water
setblock ~25 ~-26 ~21 minecraft:water
setblock ~21 ~-26 ~25 minecraft:water
setblock ~34 ~-26 ~33 minecraft:water
setblock ~34 ~-26 ~35 minecraft:water
setblock ~47 ~-26 ~43 minecraft:water
setblock ~43 ~-26 ~47 minecraft:water
setblock ~47 ~-26 ~47 minecraft:water
setblock ~21 ~-25 ~21 minecraft:water
setblock ~25 ~-25 ~21 minecraft:water
setblock ~21 ~-25 ~25 minecraft:water
setblock ~34 ~-25 ~33 minecraft:water
setblock ~34 ~-25 ~35 minecraft:water
setblock ~47 ~-25 ~43 minecraft:water
setblock ~43 ~-25 ~47 minecraft:water
setblock ~47 ~-25 ~47 minecraft:water
setblock ~21 ~-24 ~21 minecraft:water
setblock ~25 ~-24 ~21 minecraft:water
setblock ~21 ~-24 ~25 minecraft:water
setblock ~34 ~-24 ~33 minecraft:water
setblock ~34 ~-24 ~35 minecraft:water
setblock ~47 ~-24 ~43 minecraft:water
setblock ~43 ~-24 ~47 minecraft:water
setblock ~47 ~-24 ~47 minecraft:water
setblock ~34 ~-23 ~33 minecraft:water
setblock ~34 ~-23 ~35 minecraft:water
setblock ~34 ~-22 ~33 minecraft:water
setblock ~34 ~-22 ~35 minecraft:water
setblock ~34 ~-21 ~33 minecraft:water
setblock ~34 ~-21 ~35 minecraft:water
setblock ~34 ~-20 ~33 minecraft:water
setblock ~34 ~-20 ~35 minecraft:water
setblock ~34 ~-19 ~33 minecraft:water
setblock ~34 ~-19 ~35 minecraft:water
setblock ~34 ~-18 ~33 minecraft:water
setblock ~34 ~-18 ~35 minecraft:water
setblock ~34 ~-17 ~33 minecraft:water
setblock ~34 ~-17 ~35 minecraft:water
setblock ~34 ~-16 ~33 minecraft:water
setblock ~34 ~-16 ~35 minecraft:water
setblock ~34 ~-15 ~33 minecraft:water
setblock ~34 ~-15 ~35 minecraft:water
setblock ~34 ~-14 ~33 minecraft:water
setblock ~34 ~-14 ~35 minecraft:water
setblock ~34 ~-13 ~33 minecraft:water
setblock ~34 ~-13 ~35 minecraft:water
setblock ~34 ~-12 ~33 minecraft:water
setblock ~34 ~-12 ~35 minecraft:water
setblock ~34 ~-11 ~33 minecraft:water
setblock ~34 ~-11 ~35 minecraft:water
setblock ~34 ~-10 ~33 minecraft:water
setblock ~34 ~-10 ~35 minecraft:water
setblock ~34 ~-9 ~33 minecraft:water
setblock ~34 ~-9 ~35 minecraft:water
setblock ~34 ~-8 ~33 minecraft:water
setblock ~34 ~-8 ~35 minecraft:water
setblock ~34 ~-7 ~33 minecraft:water
setblock ~34 ~-7 ~35 minecraft:water
setblock ~34 ~-6 ~33 minecraft:water
setblock ~34 ~-6 ~35 minecraft:water
setblock ~34 ~-5 ~33 minecraft:water
setblock ~34 ~-5 ~35 minecraft:water
setblock ~34 ~-4 ~33 minecraft:water
setblock ~34 ~-4 ~35 minecraft:water
setblock ~34 ~-3 ~33 minecraft:water
setblock ~34 ~-3 ~35 minecraft:water
setblock ~34 ~-2 ~33 minecraft:water
setblock ~34 ~-2 ~35 minecraft:water
setblock ~34 ~-1 ~33 minecraft:water
setblock ~34 ~-1 ~35 minecraft:water
setblock ~34 ~0 ~33 minecraft:water
setblock ~34 ~0 ~35 minecraft:water
setblock ~34 ~1 ~33 minecraft:water
setblock ~34 ~1 ~35 minecraft:water
setblock ~34 ~2 ~33 minecraft:water
setblock ~34 ~2 ~35 minecraft:water
summon minecraft:armor_stand ~19.5 ~-19 ~5.5 {ArmorItems:[{},{},{id:"minecraft:leather_chestplate",Count:1b,tag:{display:{color:16777215}}},{}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~25.5 ~-19 ~24.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~24.5 ~-19 ~25.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~23.5 ~-19 ~27.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~22.5 ~-19 ~28.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-19 ~51.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~7.5 ~-19 ~51.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~9.5 ~-19 ~51.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~13.5 ~-19 ~51.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~15.5 ~-19 ~51.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~17.5 ~-19 ~51.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~5.5 ~-19 ~53.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~17.5 ~-19 ~53.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-19 ~55.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~17.5 ~-19 ~55.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-19 ~57.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~5.5 ~-19 ~59.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~17.5 ~-19 ~59.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-19 ~61.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~17.5 ~-19 ~61.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-19 ~63.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~7.5 ~-19 ~63.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~9.5 ~-19 ~63.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~11.5 ~-19 ~63.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~13.5 ~-19 ~63.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~15.5 ~-19 ~63.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~17.5 ~-19 ~63.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:zombie ~6.5 ~-19 ~39.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[-90f,0f]}
summon minecraft:zombie ~6.5 ~-19 ~43.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[-90f,0f]}
summon minecraft:zombie ~6.5 ~-19 ~47.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[-90f,0f]}
summon minecraft:armor_stand ~19.5 ~-19 ~38.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~21.5 ~-19 ~39.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~19.5 ~-19 ~41.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~19.5 ~-19 ~44.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~19.5 ~-19 ~47.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~20.5 ~-19 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~23.5 ~-19 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~26.5 ~-19 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~29.5 ~-19 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:zombie ~21.5 ~-26 ~21.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~25.5 ~-26 ~21.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~21.5 ~-26 ~25.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~43.5 ~-26 ~47.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~47.5 ~-26 ~47.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~47.5 ~-26 ~43.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~21.5 ~-35 ~20.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~25.5 ~-35 ~20.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~29.5 ~-35 ~20.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~53.5 ~-35 ~6.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~57.5 ~-35 ~6.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~61.5 ~-35 ~6.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~41.5 ~-35 ~25.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~45.5 ~-35 ~24.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[180f,0f]}
summon minecraft:armor_stand ~5.5 ~-35 ~37.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~8.5 ~-35 ~37.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~14.5 ~-35 ~37.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~17.5 ~-35 ~37.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~5.5 ~-35 ~40.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~17.5 ~-35 ~40.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-35 ~43.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~17.5 ~-35 ~43.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-35 ~46.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~17.5 ~-35 ~46.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~5.5 ~-35 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~8.5 ~-35 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~14.5 ~-35 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~17.5 ~-35 ~49.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:zombie ~23.5 ~-35 ~43.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[180f,0f]}
summon minecraft:zombie ~27.5 ~-35 ~44.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[0f,0f]}
summon minecraft:zombie ~39.5 ~-35 ~48.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[180f,0f]}
summon minecraft:zombie ~43.5 ~-35 ~48.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[180f,0f]}
summon minecraft:zombie ~47.5 ~-35 ~48.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,CustomName:'"Testobjekt"',Rotation:[180f,0f]}
summon minecraft:armor_stand ~53.5 ~-43 ~19.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~59.5 ~-43 ~19.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~62.5 ~-43 ~19.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[0f,0f]}
summon minecraft:armor_stand ~51.5 ~-43 ~21.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~63.5 ~-43 ~21.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~51.5 ~-43 ~24.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~63.5 ~-43 ~24.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~51.5 ~-43 ~27.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~63.5 ~-43 ~27.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~51.5 ~-43 ~30.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[-90f,0f]}
summon minecraft:armor_stand ~63.5 ~-43 ~30.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[90f,0f]}
summon minecraft:armor_stand ~53.5 ~-43 ~31.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~59.5 ~-43 ~31.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:armor_stand ~62.5 ~-43 ~31.5 {ArmorItems:[{id:"minecraft:iron_boots",Count:1b},{id:"minecraft:iron_leggings",Count:1b},{id:"minecraft:iron_chestplate",Count:1b},{id:"minecraft:iron_helmet",Count:1b}],Rotation:[180f,0f]}
summon minecraft:minecart ~56.5 ~-68 ~34.5
kill @e[type=minecraft:item,distance=..200]
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Fertig! Willkommen im Hive.","color":"green"}]
kill @e[type=minecraft:marker,tag=hive_origin]