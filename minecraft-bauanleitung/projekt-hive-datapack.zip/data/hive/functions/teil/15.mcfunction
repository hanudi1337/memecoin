setblock ~8 ~-17 ~49 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-17 ~49 ~17 ~-17 ~49 minecraft:air
setblock ~18 ~-17 ~49 minecraft:light_gray_concrete
fill ~19 ~-17 ~49 ~31 ~-17 ~49 minecraft:air
setblock ~32 ~-17 ~49 minecraft:light_gray_concrete
fill ~33 ~-17 ~49 ~35 ~-17 ~49 minecraft:air
setblock ~36 ~-17 ~49 minecraft:light_gray_concrete
setblock ~37 ~-17 ~49 minecraft:air
fill ~38 ~-17 ~49 ~48 ~-17 ~49 minecraft:chiseled_bookshelf[facing=north]
setblock ~49 ~-17 ~49 minecraft:air
setblock ~50 ~-17 ~49 minecraft:light_gray_concrete
fill ~51 ~-17 ~49 ~63 ~-17 ~49 minecraft:air
setblock ~64 ~-17 ~49 minecraft:light_gray_concrete
fill ~4 ~-17 ~50 ~32 ~-17 ~50 minecraft:light_gray_concrete
fill ~33 ~-17 ~50 ~35 ~-17 ~50 minecraft:air
fill ~36 ~-17 ~50 ~64 ~-17 ~50 minecraft:light_gray_concrete
setblock ~4 ~-17 ~51 minecraft:light_gray_concrete
fill ~5 ~-17 ~51 ~17 ~-17 ~51 minecraft:air
setblock ~18 ~-17 ~51 minecraft:light_gray_concrete
fill ~19 ~-17 ~51 ~31 ~-17 ~51 minecraft:air
setblock ~32 ~-17 ~51 minecraft:light_gray_concrete
fill ~33 ~-17 ~51 ~35 ~-17 ~51 minecraft:air
setblock ~36 ~-17 ~51 minecraft:light_gray_concrete
fill ~37 ~-17 ~51 ~49 ~-17 ~51 minecraft:air
setblock ~50 ~-17 ~51 minecraft:light_gray_concrete
fill ~51 ~-17 ~51 ~63 ~-17 ~51 minecraft:air
setblock ~64 ~-17 ~51 minecraft:light_gray_concrete
setblock ~4 ~-17 ~52 minecraft:light_gray_concrete
fill ~5 ~-17 ~52 ~17 ~-17 ~52 minecraft:air
setblock ~18 ~-17 ~52 minecraft:light_gray_concrete
fill ~19 ~-17 ~52 ~31 ~-17 ~52 minecraft:air
setblock ~32 ~-17 ~52 minecraft:light_gray_concrete
fill ~33 ~-17 ~52 ~35 ~-17 ~52 minecraft:air
setblock ~36 ~-17 ~52 minecraft:light_gray_concrete
setblock ~37 ~-17 ~52 minecraft:air
fill ~38 ~-17 ~52 ~41 ~-17 ~52 minecraft:barrel
setblock ~42 ~-17 ~52 minecraft:air
fill ~43 ~-17 ~52 ~46 ~-17 ~52 minecraft:barrel
setblock ~47 ~-17 ~52 minecraft:air
setblock ~48 ~-17 ~52 minecraft:barrel
setblock ~49 ~-17 ~52 minecraft:air
setblock ~50 ~-17 ~52 minecraft:light_gray_concrete
fill ~51 ~-17 ~52 ~63 ~-17 ~52 minecraft:air
setblock ~64 ~-17 ~52 minecraft:light_gray_concrete
setblock ~4 ~-17 ~53 minecraft:light_gray_concrete
fill ~5 ~-17 ~53 ~17 ~-17 ~53 minecraft:air
setblock ~18 ~-17 ~53 minecraft:light_gray_concrete
fill ~19 ~-17 ~53 ~31 ~-17 ~53 minecraft:air
setblock ~32 ~-17 ~53 minecraft:light_gray_concrete
fill ~33 ~-17 ~53 ~35 ~-17 ~53 minecraft:air
setblock ~36 ~-17 ~53 minecraft:light_gray_concrete
fill ~37 ~-17 ~53 ~49 ~-17 ~53 minecraft:air
setblock ~50 ~-17 ~53 minecraft:light_gray_concrete
fill ~51 ~-17 ~53 ~63 ~-17 ~53 minecraft:air
setblock ~64 ~-17 ~53 minecraft:light_gray_concrete
setblock ~4 ~-17 ~54 minecraft:light_gray_concrete
fill ~5 ~-17 ~54 ~17 ~-17 ~54 minecraft:air
setblock ~18 ~-17 ~54 minecraft:light_gray_concrete
fill ~19 ~-17 ~54 ~31 ~-17 ~54 minecraft:air
setblock ~32 ~-17 ~54 minecraft:light_gray_concrete
fill ~33 ~-17 ~54 ~35 ~-17 ~54 minecraft:air
setblock ~36 ~-17 ~54 minecraft:light_gray_concrete
fill ~37 ~-17 ~54 ~49 ~-17 ~54 minecraft:air
setblock ~50 ~-17 ~54 minecraft:light_gray_concrete
fill ~51 ~-17 ~54 ~63 ~-17 ~54 minecraft:air
setblock ~64 ~-17 ~54 minecraft:light_gray_concrete
setblock ~4 ~-17 ~55 minecraft:light_gray_concrete
fill ~5 ~-17 ~55 ~17 ~-17 ~55 minecraft:air
setblock ~18 ~-17 ~55 minecraft:light_gray_concrete
fill ~19 ~-17 ~55 ~31 ~-17 ~55 minecraft:air
setblock ~32 ~-17 ~55 minecraft:light_gray_concrete
fill ~33 ~-17 ~55 ~35 ~-17 ~55 minecraft:air
setblock ~36 ~-17 ~55 minecraft:light_gray_concrete
setblock ~37 ~-17 ~55 minecraft:air
fill ~38 ~-17 ~55 ~41 ~-17 ~55 minecraft:barrel
setblock ~42 ~-17 ~55 minecraft:air
fill ~43 ~-17 ~55 ~46 ~-17 ~55 minecraft:barrel
setblock ~47 ~-17 ~55 minecraft:air
setblock ~48 ~-17 ~55 minecraft:barrel
setblock ~49 ~-17 ~55 minecraft:air
setblock ~50 ~-17 ~55 minecraft:light_gray_concrete
fill ~51 ~-17 ~55 ~63 ~-17 ~55 minecraft:air
setblock ~64 ~-17 ~55 minecraft:light_gray_concrete
setblock ~4 ~-17 ~56 minecraft:light_gray_concrete
fill ~5 ~-17 ~56 ~17 ~-17 ~56 minecraft:air
setblock ~18 ~-17 ~56 minecraft:light_gray_concrete
fill ~19 ~-17 ~56 ~31 ~-17 ~56 minecraft:air
setblock ~32 ~-17 ~56 minecraft:light_gray_concrete
fill ~33 ~-17 ~56 ~35 ~-17 ~56 minecraft:air
setblock ~36 ~-17 ~56 minecraft:light_gray_concrete
fill ~37 ~-17 ~56 ~49 ~-17 ~56 minecraft:air
setblock ~50 ~-17 ~56 minecraft:light_gray_concrete
fill ~51 ~-17 ~56 ~63 ~-17 ~56 minecraft:air
setblock ~64 ~-17 ~56 minecraft:light_gray_concrete
setblock ~4 ~-17 ~57 minecraft:light_gray_concrete
fill ~5 ~-17 ~57 ~17 ~-17 ~57 minecraft:air
setblock ~18 ~-17 ~57 minecraft:light_gray_concrete
fill ~19 ~-17 ~57 ~31 ~-17 ~57 minecraft:air
setblock ~32 ~-17 ~57 minecraft:light_gray_concrete
fill ~33 ~-17 ~57 ~35 ~-17 ~57 minecraft:air
setblock ~36 ~-17 ~57 minecraft:light_gray_concrete
fill ~37 ~-17 ~57 ~49 ~-17 ~57 minecraft:air
setblock ~50 ~-17 ~57 minecraft:light_gray_concrete
fill ~51 ~-17 ~57 ~63 ~-17 ~57 minecraft:air
setblock ~64 ~-17 ~57 minecraft:light_gray_concrete
setblock ~4 ~-17 ~58 minecraft:light_gray_concrete
fill ~5 ~-17 ~58 ~17 ~-17 ~58 minecraft:air
setblock ~18 ~-17 ~58 minecraft:light_gray_concrete
fill ~19 ~-17 ~58 ~20 ~-17 ~58 minecraft:air
setblock ~21 ~-17 ~58 minecraft:iron_bars[south=true]
fill ~22 ~-17 ~58 ~23 ~-17 ~58 minecraft:air
setblock ~24 ~-17 ~58 minecraft:iron_bars[south=true]
fill ~25 ~-17 ~58 ~26 ~-17 ~58 minecraft:air
setblock ~27 ~-17 ~58 minecraft:iron_bars[south=true]
fill ~28 ~-17 ~58 ~29 ~-17 ~58 minecraft:air
setblock ~30 ~-17 ~58 minecraft:iron_bars[south=true]
setblock ~31 ~-17 ~58 minecraft:air
setblock ~32 ~-17 ~58 minecraft:light_gray_concrete
fill ~33 ~-17 ~58 ~35 ~-17 ~58 minecraft:air
setblock ~36 ~-17 ~58 minecraft:light_gray_concrete
setblock ~37 ~-17 ~58 minecraft:air
fill ~38 ~-17 ~58 ~41 ~-17 ~58 minecraft:barrel
setblock ~42 ~-17 ~58 minecraft:air
fill ~43 ~-17 ~58 ~46 ~-17 ~58 minecraft:barrel
setblock ~47 ~-17 ~58 minecraft:air
setblock ~48 ~-17 ~58 minecraft:barrel
setblock ~49 ~-17 ~58 minecraft:air
setblock ~50 ~-17 ~58 minecraft:light_gray_concrete
fill ~51 ~-17 ~58 ~63 ~-17 ~58 minecraft:air
setblock ~64 ~-17 ~58 minecraft:light_gray_concrete
setblock ~4 ~-17 ~59 minecraft:light_gray_concrete
fill ~5 ~-17 ~59 ~17 ~-17 ~59 minecraft:air
setblock ~18 ~-17 ~59 minecraft:light_gray_concrete
fill ~19 ~-17 ~59 ~20 ~-17 ~59 minecraft:air
setblock ~21 ~-17 ~59 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-17 ~59 ~23 ~-17 ~59 minecraft:air
setblock ~24 ~-17 ~59 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-17 ~59 ~26 ~-17 ~59 minecraft:air
setblock ~27 ~-17 ~59 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-17 ~59 ~29 ~-17 ~59 minecraft:air
setblock ~30 ~-17 ~59 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-17 ~59 minecraft:air
setblock ~32 ~-17 ~59 minecraft:light_gray_concrete
fill ~33 ~-17 ~59 ~35 ~-17 ~59 minecraft:air
setblock ~36 ~-17 ~59 minecraft:light_gray_concrete
fill ~37 ~-17 ~59 ~49 ~-17 ~59 minecraft:air
setblock ~50 ~-17 ~59 minecraft:light_gray_concrete
fill ~51 ~-17 ~59 ~63 ~-17 ~59 minecraft:air
setblock ~64 ~-17 ~59 minecraft:light_gray_concrete
setblock ~4 ~-17 ~60 minecraft:light_gray_concrete
fill ~5 ~-17 ~60 ~17 ~-17 ~60 minecraft:air
setblock ~18 ~-17 ~60 minecraft:light_gray_concrete
fill ~19 ~-17 ~60 ~20 ~-17 ~60 minecraft:air
setblock ~21 ~-17 ~60 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-17 ~60 ~23 ~-17 ~60 minecraft:air
setblock ~24 ~-17 ~60 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-17 ~60 ~26 ~-17 ~60 minecraft:air
setblock ~27 ~-17 ~60 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-17 ~60 ~29 ~-17 ~60 minecraft:air
setblock ~30 ~-17 ~60 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-17 ~60 minecraft:air
setblock ~32 ~-17 ~60 minecraft:light_gray_concrete
fill ~33 ~-17 ~60 ~35 ~-17 ~60 minecraft:air
setblock ~36 ~-17 ~60 minecraft:light_gray_concrete
fill ~37 ~-17 ~60 ~49 ~-17 ~60 minecraft:air
setblock ~50 ~-17 ~60 minecraft:light_gray_concrete
fill ~51 ~-17 ~60 ~63 ~-17 ~60 minecraft:air
setblock ~64 ~-17 ~60 minecraft:light_gray_concrete
setblock ~4 ~-17 ~61 minecraft:light_gray_concrete
fill ~5 ~-17 ~61 ~17 ~-17 ~61 minecraft:air
setblock ~18 ~-17 ~61 minecraft:light_gray_concrete
fill ~19 ~-17 ~61 ~20 ~-17 ~61 minecraft:air
setblock ~21 ~-17 ~61 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-17 ~61 ~23 ~-17 ~61 minecraft:air
setblock ~24 ~-17 ~61 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-17 ~61 ~26 ~-17 ~61 minecraft:air
setblock ~27 ~-17 ~61 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-17 ~61 ~29 ~-17 ~61 minecraft:air
setblock ~30 ~-17 ~61 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-17 ~61 minecraft:air
setblock ~32 ~-17 ~61 minecraft:light_gray_concrete
fill ~33 ~-17 ~61 ~35 ~-17 ~61 minecraft:air
setblock ~36 ~-17 ~61 minecraft:light_gray_concrete
setblock ~37 ~-17 ~61 minecraft:air
fill ~38 ~-17 ~61 ~41 ~-17 ~61 minecraft:barrel
setblock ~42 ~-17 ~61 minecraft:air
fill ~43 ~-17 ~61 ~46 ~-17 ~61 minecraft:barrel
setblock ~47 ~-17 ~61 minecraft:air
setblock ~48 ~-17 ~61 minecraft:barrel
setblock ~49 ~-17 ~61 minecraft:air
setblock ~50 ~-17 ~61 minecraft:light_gray_concrete
fill ~51 ~-17 ~61 ~63 ~-17 ~61 minecraft:air
setblock ~64 ~-17 ~61 minecraft:light_gray_concrete
setblock ~4 ~-17 ~62 minecraft:light_gray_concrete
fill ~5 ~-17 ~62 ~17 ~-17 ~62 minecraft:air
setblock ~18 ~-17 ~62 minecraft:light_gray_concrete
fill ~19 ~-17 ~62 ~20 ~-17 ~62 minecraft:air
setblock ~21 ~-17 ~62 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-17 ~62 ~23 ~-17 ~62 minecraft:air
setblock ~24 ~-17 ~62 minecraft:iron_bars[north=true,south=true]
fill ~25 ~-17 ~62 ~26 ~-17 ~62 minecraft:air
setblock ~27 ~-17 ~62 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-17 ~62 ~29 ~-17 ~62 minecraft:air
setblock ~30 ~-17 ~62 minecraft:iron_bars[north=true,south=true]
setblock ~31 ~-17 ~62 minecraft:air
setblock ~32 ~-17 ~62 minecraft:light_gray_concrete
fill ~33 ~-17 ~62 ~35 ~-17 ~62 minecraft:air
setblock ~36 ~-17 ~62 minecraft:light_gray_concrete
fill ~37 ~-17 ~62 ~49 ~-17 ~62 minecraft:air
setblock ~50 ~-17 ~62 minecraft:light_gray_concrete
fill ~51 ~-17 ~62 ~63 ~-17 ~62 minecraft:air
setblock ~64 ~-17 ~62 minecraft:light_gray_concrete
setblock ~4 ~-17 ~63 minecraft:light_gray_concrete
fill ~5 ~-17 ~63 ~17 ~-17 ~63 minecraft:air
setblock ~18 ~-17 ~63 minecraft:light_gray_concrete
fill ~19 ~-17 ~63 ~30 ~-17 ~63 minecraft:hay_block
setblock ~31 ~-17 ~63 minecraft:air
setblock ~32 ~-17 ~63 minecraft:light_gray_concrete
fill ~33 ~-17 ~63 ~35 ~-17 ~63 minecraft:air
setblock ~36 ~-17 ~63 minecraft:light_gray_concrete
fill ~37 ~-17 ~63 ~49 ~-17 ~63 minecraft:air
setblock ~50 ~-17 ~63 minecraft:light_gray_concrete
fill ~51 ~-17 ~63 ~63 ~-17 ~63 minecraft:air
setblock ~64 ~-17 ~63 minecraft:light_gray_concrete
fill ~4 ~-17 ~64 ~64 ~-17 ~64 minecraft:light_gray_concrete
setblock ~34 ~-17 ~65 minecraft:light_gray_concrete
fill ~32 ~-17 ~66 ~36 ~-17 ~66 minecraft:polished_andesite
setblock ~32 ~-17 ~67 minecraft:polished_andesite
fill ~33 ~-17 ~67 ~35 ~-17 ~67 minecraft:air
setblock ~36 ~-17 ~67 minecraft:polished_andesite
setblock ~32 ~-17 ~68 minecraft:polished_andesite
setblock ~33 ~-17 ~68 minecraft:air
setblock ~34 ~-17 ~68 minecraft:quartz_pillar
setblock ~35 ~-17 ~68 minecraft:air
setblock ~36 ~-17 ~68 minecraft:polished_andesite
setblock ~32 ~-17 ~69 minecraft:polished_andesite
fill ~33 ~-17 ~69 ~34 ~-17 ~69 minecraft:air
setblock ~35 ~-17 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-17 ~69 minecraft:polished_andesite
fill ~32 ~-17 ~70 ~36 ~-17 ~70 minecraft:polished_andesite
fill ~4 ~-16 ~4 ~64 ~-16 ~4 minecraft:light_gray_concrete
setblock ~4 ~-16 ~5 minecraft:light_gray_concrete
fill ~5 ~-16 ~5 ~17 ~-16 ~5 minecraft:air
setblock ~18 ~-16 ~5 minecraft:light_gray_concrete
fill ~19 ~-16 ~5 ~31 ~-16 ~5 minecraft:air
setblock ~32 ~-16 ~5 minecraft:light_gray_concrete
fill ~33 ~-16 ~5 ~35 ~-16 ~5 minecraft:air
setblock ~36 ~-16 ~5 minecraft:light_gray_concrete
fill ~37 ~-16 ~5 ~49 ~-16 ~5 minecraft:air
setblock ~50 ~-16 ~5 minecraft:light_gray_concrete
fill ~51 ~-16 ~5 ~63 ~-16 ~5 minecraft:air
setblock ~64 ~-16 ~5 minecraft:light_gray_concrete
setblock ~4 ~-16 ~6 minecraft:light_gray_concrete
fill ~5 ~-16 ~6 ~17 ~-16 ~6 minecraft:air
setblock ~18 ~-16 ~6 minecraft:light_gray_concrete
fill ~19 ~-16 ~6 ~31 ~-16 ~6 minecraft:air
setblock ~32 ~-16 ~6 minecraft:light_gray_concrete
fill ~33 ~-16 ~6 ~35 ~-16 ~6 minecraft:air
setblock ~36 ~-16 ~6 minecraft:light_gray_concrete
fill ~37 ~-16 ~6 ~49 ~-16 ~6 minecraft:air
setblock ~50 ~-16 ~6 minecraft:light_gray_concrete
fill ~51 ~-16 ~6 ~63 ~-16 ~6 minecraft:air
setblock ~64 ~-16 ~6 minecraft:light_gray_concrete
setblock ~4 ~-16 ~7 minecraft:light_gray_concrete
fill ~5 ~-16 ~7 ~17 ~-16 ~7 minecraft:air
setblock ~18 ~-16 ~7 minecraft:light_gray_concrete
fill ~19 ~-16 ~7 ~31 ~-16 ~7 minecraft:air
setblock ~32 ~-16 ~7 minecraft:light_gray_concrete
fill ~33 ~-16 ~7 ~35 ~-16 ~7 minecraft:air
setblock ~36 ~-16 ~7 minecraft:light_gray_concrete
fill ~37 ~-16 ~7 ~49 ~-16 ~7 minecraft:air
setblock ~50 ~-16 ~7 minecraft:light_gray_concrete
fill ~51 ~-16 ~7 ~63 ~-16 ~7 minecraft:air
setblock ~64 ~-16 ~7 minecraft:light_gray_concrete
setblock ~4 ~-16 ~8 minecraft:light_gray_concrete
fill ~5 ~-16 ~8 ~17 ~-16 ~8 minecraft:air
setblock ~18 ~-16 ~8 minecraft:light_gray_concrete
fill ~19 ~-16 ~8 ~31 ~-16 ~8 minecraft:air
setblock ~32 ~-16 ~8 minecraft:light_gray_concrete
fill ~33 ~-16 ~8 ~35 ~-16 ~8 minecraft:air
setblock ~36 ~-16 ~8 minecraft:light_gray_concrete
fill ~37 ~-16 ~8 ~49 ~-16 ~8 minecraft:air
setblock ~50 ~-16 ~8 minecraft:light_gray_concrete
fill ~51 ~-16 ~8 ~63 ~-16 ~8 minecraft:air
setblock ~64 ~-16 ~8 minecraft:light_gray_concrete
setblock ~4 ~-16 ~9 minecraft:light_gray_concrete
fill ~5 ~-16 ~9 ~17 ~-16 ~9 minecraft:air
setblock ~18 ~-16 ~9 minecraft:light_gray_concrete
fill ~19 ~-16 ~9 ~31 ~-16 ~9 minecraft:air
setblock ~32 ~-16 ~9 minecraft:light_gray_concrete
fill ~33 ~-16 ~9 ~35 ~-16 ~9 minecraft:air
setblock ~36 ~-16 ~9 minecraft:light_gray_concrete
fill ~37 ~-16 ~9 ~49 ~-16 ~9 minecraft:air
setblock ~50 ~-16 ~9 minecraft:light_gray_concrete
fill ~51 ~-16 ~9 ~63 ~-16 ~9 minecraft:air
setblock ~64 ~-16 ~9 minecraft:light_gray_concrete
setblock ~4 ~-16 ~10 minecraft:light_gray_concrete
fill ~5 ~-16 ~10 ~17 ~-16 ~10 minecraft:air
setblock ~18 ~-16 ~10 minecraft:light_gray_concrete
fill ~19 ~-16 ~10 ~31 ~-16 ~10 minecraft:air
setblock ~32 ~-16 ~10 minecraft:light_gray_concrete
fill ~33 ~-16 ~10 ~35 ~-16 ~10 minecraft:air
setblock ~36 ~-16 ~10 minecraft:light_gray_concrete
fill ~37 ~-16 ~10 ~49 ~-16 ~10 minecraft:air
setblock ~50 ~-16 ~10 minecraft:light_gray_concrete
fill ~51 ~-16 ~10 ~63 ~-16 ~10 minecraft:air
setblock ~64 ~-16 ~10 minecraft:light_gray_concrete
setblock ~4 ~-16 ~11 minecraft:light_gray_concrete
fill ~5 ~-16 ~11 ~17 ~-16 ~11 minecraft:air
setblock ~18 ~-16 ~11 minecraft:light_gray_concrete
fill ~19 ~-16 ~11 ~31 ~-16 ~11 minecraft:air
setblock ~32 ~-16 ~11 minecraft:light_gray_concrete
fill ~33 ~-16 ~11 ~35 ~-16 ~11 minecraft:air
setblock ~36 ~-16 ~11 minecraft:light_gray_concrete
fill ~37 ~-16 ~11 ~49 ~-16 ~11 minecraft:air
setblock ~50 ~-16 ~11 minecraft:light_gray_concrete
fill ~51 ~-16 ~11 ~63 ~-16 ~11 minecraft:air
setblock ~64 ~-16 ~11 minecraft:light_gray_concrete
setblock ~4 ~-16 ~12 minecraft:light_gray_concrete
fill ~5 ~-16 ~12 ~17 ~-16 ~12 minecraft:air
setblock ~18 ~-16 ~12 minecraft:light_gray_concrete
fill ~19 ~-16 ~12 ~31 ~-16 ~12 minecraft:air
setblock ~32 ~-16 ~12 minecraft:light_gray_concrete
fill ~33 ~-16 ~12 ~35 ~-16 ~12 minecraft:air
setblock ~36 ~-16 ~12 minecraft:light_gray_concrete
fill ~37 ~-16 ~12 ~49 ~-16 ~12 minecraft:air
setblock ~50 ~-16 ~12 minecraft:light_gray_concrete
fill ~51 ~-16 ~12 ~63 ~-16 ~12 minecraft:air
setblock ~64 ~-16 ~12 minecraft:light_gray_concrete
setblock ~4 ~-16 ~13 minecraft:light_gray_concrete
fill ~5 ~-16 ~13 ~17 ~-16 ~13 minecraft:air
setblock ~18 ~-16 ~13 minecraft:light_gray_concrete
fill ~19 ~-16 ~13 ~31 ~-16 ~13 minecraft:air
setblock ~32 ~-16 ~13 minecraft:light_gray_concrete
fill ~33 ~-16 ~13 ~35 ~-16 ~13 minecraft:air
setblock ~36 ~-16 ~13 minecraft:light_gray_concrete
fill ~37 ~-16 ~13 ~49 ~-16 ~13 minecraft:air
setblock ~50 ~-16 ~13 minecraft:light_gray_concrete
fill ~51 ~-16 ~13 ~63 ~-16 ~13 minecraft:air
setblock ~64 ~-16 ~13 minecraft:light_gray_concrete
setblock ~4 ~-16 ~14 minecraft:light_gray_concrete
fill ~5 ~-16 ~14 ~17 ~-16 ~14 minecraft:air
setblock ~18 ~-16 ~14 minecraft:light_gray_concrete
fill ~19 ~-16 ~14 ~31 ~-16 ~14 minecraft:air
setblock ~32 ~-16 ~14 minecraft:light_gray_concrete
fill ~33 ~-16 ~14 ~35 ~-16 ~14 minecraft:air
setblock ~36 ~-16 ~14 minecraft:light_gray_concrete
fill ~37 ~-16 ~14 ~49 ~-16 ~14 minecraft:air
setblock ~50 ~-16 ~14 minecraft:light_gray_concrete
fill ~51 ~-16 ~14 ~63 ~-16 ~14 minecraft:air
setblock ~64 ~-16 ~14 minecraft:light_gray_concrete
setblock ~4 ~-16 ~15 minecraft:light_gray_concrete
fill ~5 ~-16 ~15 ~17 ~-16 ~15 minecraft:air
setblock ~18 ~-16 ~15 minecraft:light_gray_concrete
fill ~19 ~-16 ~15 ~31 ~-16 ~15 minecraft:air
setblock ~32 ~-16 ~15 minecraft:light_gray_concrete
fill ~33 ~-16 ~15 ~35 ~-16 ~15 minecraft:air
setblock ~36 ~-16 ~15 minecraft:light_gray_concrete
fill ~37 ~-16 ~15 ~49 ~-16 ~15 minecraft:air
setblock ~50 ~-16 ~15 minecraft:light_gray_concrete
fill ~51 ~-16 ~15 ~63 ~-16 ~15 minecraft:air
setblock ~64 ~-16 ~15 minecraft:light_gray_concrete
setblock ~4 ~-16 ~16 minecraft:light_gray_concrete
fill ~5 ~-16 ~16 ~17 ~-16 ~16 minecraft:air
setblock ~18 ~-16 ~16 minecraft:light_gray_concrete
fill ~19 ~-16 ~16 ~31 ~-16 ~16 minecraft:air
setblock ~32 ~-16 ~16 minecraft:light_gray_concrete
fill ~33 ~-16 ~16 ~35 ~-16 ~16 minecraft:air
setblock ~36 ~-16 ~16 minecraft:light_gray_concrete
fill ~37 ~-16 ~16 ~49 ~-16 ~16 minecraft:air
setblock ~50 ~-16 ~16 minecraft:light_gray_concrete
fill ~51 ~-16 ~16 ~63 ~-16 ~16 minecraft:air
setblock ~64 ~-16 ~16 minecraft:light_gray_concrete
setblock ~4 ~-16 ~17 minecraft:light_gray_concrete
fill ~5 ~-16 ~17 ~17 ~-16 ~17 minecraft:air
setblock ~18 ~-16 ~17 minecraft:light_gray_concrete
fill ~19 ~-16 ~17 ~31 ~-16 ~17 minecraft:air
setblock ~32 ~-16 ~17 minecraft:light_gray_concrete
fill ~33 ~-16 ~17 ~35 ~-16 ~17 minecraft:air
setblock ~36 ~-16 ~17 minecraft:light_gray_concrete
fill ~37 ~-16 ~17 ~49 ~-16 ~17 minecraft:air
setblock ~50 ~-16 ~17 minecraft:light_gray_concrete
fill ~51 ~-16 ~17 ~63 ~-16 ~17 minecraft:air
setblock ~64 ~-16 ~17 minecraft:light_gray_concrete
fill ~4 ~-16 ~18 ~32 ~-16 ~18 minecraft:light_gray_concrete
fill ~33 ~-16 ~18 ~35 ~-16 ~18 minecraft:air
fill ~36 ~-16 ~18 ~64 ~-16 ~18 minecraft:light_gray_concrete
setblock ~4 ~-16 ~19 minecraft:light_gray_concrete
fill ~5 ~-16 ~19 ~17 ~-16 ~19 minecraft:air
setblock ~18 ~-16 ~19 minecraft:light_gray_concrete
fill ~19 ~-16 ~19 ~30 ~-16 ~19 minecraft:black_concrete
setblock ~31 ~-16 ~19 minecraft:air
setblock ~32 ~-16 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-16 ~19 ~35 ~-16 ~19 minecraft:air
setblock ~36 ~-16 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-16 ~19 ~49 ~-16 ~19 minecraft:air
setblock ~50 ~-16 ~19 minecraft:light_gray_concrete
fill ~51 ~-16 ~19 ~63 ~-16 ~19 minecraft:air
setblock ~64 ~-16 ~19 minecraft:light_gray_concrete
setblock ~4 ~-16 ~20 minecraft:light_gray_concrete
fill ~5 ~-16 ~20 ~17 ~-16 ~20 minecraft:air
setblock ~18 ~-16 ~20 minecraft:light_gray_concrete
fill ~19 ~-16 ~20 ~31 ~-16 ~20 minecraft:air
setblock ~32 ~-16 ~20 minecraft:light_gray_concrete
fill ~33 ~-16 ~20 ~35 ~-16 ~20 minecraft:air
setblock ~36 ~-16 ~20 minecraft:light_gray_concrete
fill ~37 ~-16 ~20 ~49 ~-16 ~20 minecraft:air
setblock ~50 ~-16 ~20 minecraft:light_gray_concrete
fill ~51 ~-16 ~20 ~63 ~-16 ~20 minecraft:air
setblock ~64 ~-16 ~20 minecraft:light_gray_concrete
setblock ~4 ~-16 ~21 minecraft:light_gray_concrete
fill ~5 ~-16 ~21 ~17 ~-16 ~21 minecraft:air
setblock ~18 ~-16 ~21 minecraft:light_gray_concrete
fill ~19 ~-16 ~21 ~31 ~-16 ~21 minecraft:air
setblock ~32 ~-16 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-16 ~21 ~35 ~-16 ~21 minecraft:air
setblock ~36 ~-16 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-16 ~21 ~49 ~-16 ~21 minecraft:air
setblock ~50 ~-16 ~21 minecraft:light_gray_concrete
fill ~51 ~-16 ~21 ~63 ~-16 ~21 minecraft:air
setblock ~64 ~-16 ~21 minecraft:light_gray_concrete
setblock ~4 ~-16 ~22 minecraft:light_gray_concrete
fill ~5 ~-16 ~22 ~17 ~-16 ~22 minecraft:air
setblock ~18 ~-16 ~22 minecraft:light_gray_concrete
fill ~19 ~-16 ~22 ~28 ~-16 ~22 minecraft:air
setblock ~29 ~-16 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-16 ~22 minecraft:quartz_pillar
setblock ~31 ~-16 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-16 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-16 ~22 ~35 ~-16 ~22 minecraft:air
setblock ~36 ~-16 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-16 ~22 ~38 ~-16 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-16 ~22 minecraft:quartz_pillar
fill ~40 ~-16 ~22 ~49 ~-16 ~22 minecraft:air
setblock ~50 ~-16 ~22 minecraft:light_gray_concrete
fill ~51 ~-16 ~22 ~63 ~-16 ~22 minecraft:air
setblock ~64 ~-16 ~22 minecraft:light_gray_concrete
setblock ~4 ~-16 ~23 minecraft:light_gray_concrete
fill ~5 ~-16 ~23 ~17 ~-16 ~23 minecraft:air
setblock ~18 ~-16 ~23 minecraft:light_gray_concrete
fill ~19 ~-16 ~23 ~27 ~-16 ~23 minecraft:air
setblock ~28 ~-16 ~23 minecraft:smooth_quartz
setblock ~29 ~-16 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-16 ~23 ~38 ~-16 ~23 minecraft:air
setblock ~39 ~-16 ~23 minecraft:quartz_pillar
setblock ~40 ~-16 ~23 minecraft:smooth_quartz
fill ~41 ~-16 ~23 ~49 ~-16 ~23 minecraft:air
setblock ~50 ~-16 ~23 minecraft:light_gray_concrete
fill ~51 ~-16 ~23 ~63 ~-16 ~23 minecraft:air
setblock ~64 ~-16 ~23 minecraft:light_gray_concrete
setblock ~4 ~-16 ~24 minecraft:light_gray_concrete
fill ~5 ~-16 ~24 ~17 ~-16 ~24 minecraft:air
setblock ~18 ~-16 ~24 minecraft:light_gray_concrete
fill ~19 ~-16 ~24 ~25 ~-16 ~24 minecraft:air
setblock ~26 ~-16 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-16 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-16 ~24 ~29 ~-16 ~24 minecraft:air
setblock ~30 ~-16 ~24 minecraft:quartz_pillar
fill ~31 ~-16 ~24 ~37 ~-16 ~24 minecraft:air
setblock ~38 ~-16 ~24 minecraft:quartz_pillar
fill ~39 ~-16 ~24 ~40 ~-16 ~24 minecraft:air
setblock ~41 ~-16 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-16 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-16 ~24 ~49 ~-16 ~24 minecraft:air
setblock ~50 ~-16 ~24 minecraft:light_gray_concrete
fill ~51 ~-16 ~24 ~62 ~-16 ~24 minecraft:air
setblock ~63 ~-16 ~24 minecraft:black_concrete
setblock ~64 ~-16 ~24 minecraft:light_gray_concrete
setblock ~4 ~-16 ~25 minecraft:light_gray_concrete
fill ~5 ~-16 ~25 ~17 ~-16 ~25 minecraft:air
setblock ~18 ~-16 ~25 minecraft:light_gray_concrete
fill ~19 ~-16 ~25 ~24 ~-16 ~25 minecraft:air
fill ~25 ~-16 ~25 ~26 ~-16 ~25 minecraft:quartz_pillar
fill ~27 ~-16 ~25 ~41 ~-16 ~25 minecraft:air
setblock ~42 ~-16 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-16 ~25 minecraft:quartz_pillar
fill ~44 ~-16 ~25 ~49 ~-16 ~25 minecraft:air
setblock ~50 ~-16 ~25 minecraft:light_gray_concrete
fill ~51 ~-16 ~25 ~62 ~-16 ~25 minecraft:air
setblock ~63 ~-16 ~25 minecraft:black_concrete
setblock ~64 ~-16 ~25 minecraft:light_gray_concrete
setblock ~4 ~-16 ~26 minecraft:light_gray_concrete
fill ~5 ~-16 ~26 ~17 ~-16 ~26 minecraft:air
setblock ~18 ~-16 ~26 minecraft:light_gray_concrete
fill ~19 ~-16 ~26 ~23 ~-16 ~26 minecraft:air
setblock ~24 ~-16 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-16 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-16 ~26 ~42 ~-16 ~26 minecraft:air
setblock ~43 ~-16 ~26 minecraft:quartz_pillar
setblock ~44 ~-16 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-16 ~26 ~49 ~-16 ~26 minecraft:air
setblock ~50 ~-16 ~26 minecraft:light_gray_concrete
fill ~51 ~-16 ~26 ~62 ~-16 ~26 minecraft:air
setblock ~63 ~-16 ~26 minecraft:black_concrete
setblock ~64 ~-16 ~26 minecraft:light_gray_concrete
setblock ~4 ~-16 ~27 minecraft:light_gray_concrete
fill ~5 ~-16 ~27 ~17 ~-16 ~27 minecraft:air
setblock ~18 ~-16 ~27 minecraft:light_gray_concrete
fill ~19 ~-16 ~27 ~23 ~-16 ~27 minecraft:air
setblock ~24 ~-16 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-16 ~27 ~43 ~-16 ~27 minecraft:air
setblock ~44 ~-16 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-16 ~27 ~49 ~-16 ~27 minecraft:air
setblock ~50 ~-16 ~27 minecraft:light_gray_concrete
fill ~51 ~-16 ~27 ~63 ~-16 ~27 minecraft:air
setblock ~64 ~-16 ~27 minecraft:light_gray_concrete
setblock ~4 ~-16 ~28 minecraft:light_gray_concrete
fill ~5 ~-16 ~28 ~17 ~-16 ~28 minecraft:air
setblock ~18 ~-16 ~28 minecraft:light_gray_concrete
fill ~19 ~-16 ~28 ~22 ~-16 ~28 minecraft:air
setblock ~23 ~-16 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-16 ~28 ~44 ~-16 ~28 minecraft:air
setblock ~45 ~-16 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-16 ~28 ~49 ~-16 ~28 minecraft:air
setblock ~50 ~-16 ~28 minecraft:light_gray_concrete
fill ~51 ~-16 ~28 ~63 ~-16 ~28 minecraft:air
setblock ~64 ~-16 ~28 minecraft:light_gray_concrete
setblock ~4 ~-16 ~29 minecraft:light_gray_concrete
fill ~5 ~-16 ~29 ~17 ~-16 ~29 minecraft:air
setblock ~18 ~-16 ~29 minecraft:light_gray_concrete
fill ~19 ~-16 ~29 ~21 ~-16 ~29 minecraft:air
fill ~22 ~-16 ~29 ~23 ~-16 ~29 minecraft:quartz_pillar
fill ~24 ~-16 ~29 ~44 ~-16 ~29 minecraft:air
setblock ~45 ~-16 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-16 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-16 ~29 ~49 ~-16 ~29 minecraft:air
setblock ~50 ~-16 ~29 minecraft:light_gray_concrete
fill ~51 ~-16 ~29 ~63 ~-16 ~29 minecraft:air
setblock ~64 ~-16 ~29 minecraft:light_gray_concrete
setblock ~4 ~-16 ~30 minecraft:light_gray_concrete
fill ~5 ~-16 ~30 ~17 ~-16 ~30 minecraft:air
setblock ~18 ~-16 ~30 minecraft:light_gray_concrete
fill ~19 ~-16 ~30 ~21 ~-16 ~30 minecraft:air
setblock ~22 ~-16 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-16 ~30 minecraft:air
setblock ~24 ~-16 ~30 minecraft:quartz_pillar
fill ~25 ~-16 ~30 ~43 ~-16 ~30 minecraft:air
setblock ~44 ~-16 ~30 minecraft:quartz_pillar
setblock ~45 ~-16 ~30 minecraft:air
setblock ~46 ~-16 ~30 minecraft:quartz_pillar
fill ~47 ~-16 ~30 ~49 ~-16 ~30 minecraft:air
setblock ~50 ~-16 ~30 minecraft:light_gray_concrete
fill ~51 ~-16 ~30 ~63 ~-16 ~30 minecraft:air
setblock ~64 ~-16 ~30 minecraft:light_gray_concrete
setblock ~4 ~-16 ~31 minecraft:light_gray_concrete
fill ~5 ~-16 ~31 ~17 ~-16 ~31 minecraft:air
setblock ~18 ~-16 ~31 minecraft:light_gray_concrete
fill ~19 ~-16 ~31 ~21 ~-16 ~31 minecraft:air
setblock ~22 ~-16 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-16 ~31 ~45 ~-16 ~31 minecraft:air
setblock ~46 ~-16 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-16 ~31 ~49 ~-16 ~31 minecraft:air
setblock ~50 ~-16 ~31 minecraft:light_gray_concrete
fill ~51 ~-16 ~31 ~63 ~-16 ~31 minecraft:air
setblock ~64 ~-16 ~31 minecraft:light_gray_concrete
setblock ~4 ~-16 ~32 minecraft:light_gray_concrete
setblock ~5 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~6 ~-16 ~32 minecraft:light_gray_concrete
fill ~7 ~-16 ~32 ~9 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
fill ~10 ~-16 ~32 ~11 ~-16 ~32 minecraft:light_gray_concrete
fill ~12 ~-16 ~32 ~13 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~14 ~-16 ~32 minecraft:light_gray_concrete
fill ~15 ~-16 ~32 ~17 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~18 ~-16 ~32 minecraft:light_gray_concrete
setblock ~19 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-16 ~32 minecraft:light_gray_concrete
setblock ~21 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-16 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-16 ~32 ~32 ~-16 ~32 minecraft:air
fill ~33 ~-16 ~32 ~35 ~-16 ~32 minecraft:glass
fill ~36 ~-16 ~32 ~45 ~-16 ~32 minecraft:air
setblock ~46 ~-16 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-16 ~32 minecraft:light_gray_concrete
setblock ~49 ~-16 ~32 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-16 ~32 ~64 ~-16 ~32 minecraft:light_gray_concrete
setblock ~4 ~-16 ~33 minecraft:light_gray_concrete
fill ~5 ~-16 ~33 ~32 ~-16 ~33 minecraft:air
setblock ~33 ~-16 ~33 minecraft:glass
setblock ~34 ~-16 ~33 minecraft:air
setblock ~35 ~-16 ~33 minecraft:glass
fill ~36 ~-16 ~33 ~63 ~-16 ~33 minecraft:air
setblock ~64 ~-16 ~33 minecraft:light_gray_concrete
setblock ~4 ~-16 ~34 minecraft:light_gray_concrete
fill ~5 ~-16 ~34 ~32 ~-16 ~34 minecraft:air
fill ~33 ~-16 ~34 ~35 ~-16 ~34 minecraft:glass
fill ~36 ~-16 ~34 ~63 ~-16 ~34 minecraft:air
setblock ~64 ~-16 ~34 minecraft:light_gray_concrete
setblock ~4 ~-16 ~35 minecraft:light_gray_concrete
fill ~5 ~-16 ~35 ~32 ~-16 ~35 minecraft:air
setblock ~33 ~-16 ~35 minecraft:glass
setblock ~34 ~-16 ~35 minecraft:air
setblock ~35 ~-16 ~35 minecraft:glass
fill ~36 ~-16 ~35 ~63 ~-16 ~35 minecraft:air
setblock ~64 ~-16 ~35 minecraft:light_gray_concrete
setblock ~4 ~-16 ~36 minecraft:light_gray_concrete
setblock ~5 ~-16 ~36 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~6 ~-16 ~36 minecraft:light_gray_concrete
fill ~7 ~-16 ~36 ~8 ~-16 ~36 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~9 ~-16 ~36 minecraft:glass_pane[east=true,west=true]
fill ~10 ~-16 ~36 ~11 ~-16 ~36 minecraft:light_gray_concrete
fill ~12 ~-16 ~36 ~13 ~-16 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~14 ~-16 ~36 minecraft:light_gray_concrete
fill ~15 ~-16 ~36 ~17 ~-16 ~36 minecraft:glass_pane[east=true,west=true]
fill ~18 ~-16 ~36 ~21 ~-16 ~36 minecraft:light_gray_concrete
setblock ~22 ~-16 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-16 ~36 ~32 ~-16 ~36 minecraft:air
fill ~33 ~-16 ~36 ~35 ~-16 ~36 minecraft:glass
fill ~36 ~-16 ~36 ~45 ~-16 ~36 minecraft:air
setblock ~46 ~-16 ~36 minecraft:glass_pane[east=true,south=true]
fill ~47 ~-16 ~36 ~64 ~-16 ~36 minecraft:light_gray_concrete
setblock ~4 ~-16 ~37 minecraft:light_gray_concrete
fill ~5 ~-16 ~37 ~7 ~-16 ~37 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~8 ~-16 ~37 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-16 ~37 ~17 ~-16 ~37 minecraft:air
setblock ~18 ~-16 ~37 minecraft:light_gray_concrete
fill ~19 ~-16 ~37 ~21 ~-16 ~37 minecraft:air
setblock ~22 ~-16 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-16 ~37 ~45 ~-16 ~37 minecraft:air
setblock ~46 ~-16 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-16 ~37 ~49 ~-16 ~37 minecraft:air
setblock ~50 ~-16 ~37 minecraft:light_gray_concrete
fill ~51 ~-16 ~37 ~63 ~-16 ~37 minecraft:air
setblock ~64 ~-16 ~37 minecraft:light_gray_concrete
setblock ~4 ~-16 ~38 minecraft:light_gray_concrete
fill ~5 ~-16 ~38 ~7 ~-16 ~38 minecraft:air
setblock ~8 ~-16 ~38 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~38 ~17 ~-16 ~38 minecraft:air
setblock ~18 ~-16 ~38 minecraft:light_gray_concrete
fill ~19 ~-16 ~38 ~21 ~-16 ~38 minecraft:air
setblock ~22 ~-16 ~38 minecraft:quartz_pillar
setblock ~23 ~-16 ~38 minecraft:air
setblock ~24 ~-16 ~38 minecraft:quartz_pillar
fill ~25 ~-16 ~38 ~43 ~-16 ~38 minecraft:air
setblock ~44 ~-16 ~38 minecraft:quartz_pillar
setblock ~45 ~-16 ~38 minecraft:air
setblock ~46 ~-16 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-16 ~38 ~49 ~-16 ~38 minecraft:air
setblock ~50 ~-16 ~38 minecraft:light_gray_concrete
fill ~51 ~-16 ~38 ~63 ~-16 ~38 minecraft:air
setblock ~64 ~-16 ~38 minecraft:light_gray_concrete
setblock ~4 ~-16 ~39 minecraft:light_gray_concrete
fill ~5 ~-16 ~39 ~7 ~-16 ~39 minecraft:air
setblock ~8 ~-16 ~39 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~39 ~17 ~-16 ~39 minecraft:air
setblock ~18 ~-16 ~39 minecraft:light_gray_concrete
fill ~19 ~-16 ~39 ~21 ~-16 ~39 minecraft:air
setblock ~22 ~-16 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-16 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-16 ~39 ~44 ~-16 ~39 minecraft:air
fill ~45 ~-16 ~39 ~46 ~-16 ~39 minecraft:quartz_pillar
fill ~47 ~-16 ~39 ~49 ~-16 ~39 minecraft:air
setblock ~50 ~-16 ~39 minecraft:light_gray_concrete
fill ~51 ~-16 ~39 ~63 ~-16 ~39 minecraft:air
setblock ~64 ~-16 ~39 minecraft:light_gray_concrete
setblock ~4 ~-16 ~40 minecraft:light_gray_concrete
fill ~5 ~-16 ~40 ~7 ~-16 ~40 minecraft:air
setblock ~8 ~-16 ~40 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~40 ~17 ~-16 ~40 minecraft:air
setblock ~18 ~-16 ~40 minecraft:light_gray_concrete
fill ~19 ~-16 ~40 ~22 ~-16 ~40 minecraft:air
setblock ~23 ~-16 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-16 ~40 ~44 ~-16 ~40 minecraft:air
setblock ~45 ~-16 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-16 ~40 ~49 ~-16 ~40 minecraft:air
setblock ~50 ~-16 ~40 minecraft:light_gray_concrete
fill ~51 ~-16 ~40 ~63 ~-16 ~40 minecraft:air
setblock ~64 ~-16 ~40 minecraft:light_gray_concrete
setblock ~4 ~-16 ~41 minecraft:light_gray_concrete
fill ~5 ~-16 ~41 ~7 ~-16 ~41 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-16 ~41 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-16 ~41 ~17 ~-16 ~41 minecraft:air
setblock ~18 ~-16 ~41 minecraft:light_gray_concrete
fill ~19 ~-16 ~41 ~23 ~-16 ~41 minecraft:air
setblock ~24 ~-16 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-16 ~41 ~43 ~-16 ~41 minecraft:air
setblock ~44 ~-16 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-16 ~41 ~49 ~-16 ~41 minecraft:air
setblock ~50 ~-16 ~41 minecraft:light_gray_concrete
fill ~51 ~-16 ~41 ~63 ~-16 ~41 minecraft:air
setblock ~64 ~-16 ~41 minecraft:light_gray_concrete
setblock ~4 ~-16 ~42 minecraft:light_gray_concrete
fill ~5 ~-16 ~42 ~7 ~-16 ~42 minecraft:air
setblock ~8 ~-16 ~42 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~42 ~17 ~-16 ~42 minecraft:air
setblock ~18 ~-16 ~42 minecraft:light_gray_concrete
fill ~19 ~-16 ~42 ~23 ~-16 ~42 minecraft:air
setblock ~24 ~-16 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-16 ~42 minecraft:quartz_pillar
fill ~26 ~-16 ~42 ~42 ~-16 ~42 minecraft:air
setblock ~43 ~-16 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-16 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-16 ~42 ~49 ~-16 ~42 minecraft:air
setblock ~50 ~-16 ~42 minecraft:light_gray_concrete
fill ~51 ~-16 ~42 ~63 ~-16 ~42 minecraft:air
setblock ~64 ~-16 ~42 minecraft:light_gray_concrete
setblock ~4 ~-16 ~43 minecraft:light_gray_concrete
fill ~5 ~-16 ~43 ~7 ~-16 ~43 minecraft:air
setblock ~8 ~-16 ~43 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~43 ~17 ~-16 ~43 minecraft:air
setblock ~18 ~-16 ~43 minecraft:light_gray_concrete
fill ~19 ~-16 ~43 ~24 ~-16 ~43 minecraft:air
setblock ~25 ~-16 ~43 minecraft:quartz_pillar
setblock ~26 ~-16 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-16 ~43 ~41 ~-16 ~43 minecraft:air
fill ~42 ~-16 ~43 ~43 ~-16 ~43 minecraft:quartz_pillar
fill ~44 ~-16 ~43 ~49 ~-16 ~43 minecraft:air
setblock ~50 ~-16 ~43 minecraft:light_gray_concrete
fill ~51 ~-16 ~43 ~63 ~-16 ~43 minecraft:air
setblock ~64 ~-16 ~43 minecraft:light_gray_concrete
setblock ~4 ~-16 ~44 minecraft:light_gray_concrete
fill ~5 ~-16 ~44 ~7 ~-16 ~44 minecraft:air
setblock ~8 ~-16 ~44 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~44 ~17 ~-16 ~44 minecraft:air
setblock ~18 ~-16 ~44 minecraft:light_gray_concrete
fill ~19 ~-16 ~44 ~25 ~-16 ~44 minecraft:air
setblock ~26 ~-16 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-16 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-16 ~44 ~29 ~-16 ~44 minecraft:air
setblock ~30 ~-16 ~44 minecraft:quartz_pillar
fill ~31 ~-16 ~44 ~37 ~-16 ~44 minecraft:air
setblock ~38 ~-16 ~44 minecraft:quartz_pillar
fill ~39 ~-16 ~44 ~40 ~-16 ~44 minecraft:air
setblock ~41 ~-16 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-16 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-16 ~44 ~49 ~-16 ~44 minecraft:air
setblock ~50 ~-16 ~44 minecraft:light_gray_concrete
fill ~51 ~-16 ~44 ~63 ~-16 ~44 minecraft:air
setblock ~64 ~-16 ~44 minecraft:light_gray_concrete
setblock ~4 ~-16 ~45 minecraft:light_gray_concrete
fill ~5 ~-16 ~45 ~7 ~-16 ~45 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-16 ~45 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-16 ~45 ~17 ~-16 ~45 minecraft:air
setblock ~18 ~-16 ~45 minecraft:light_gray_concrete
fill ~19 ~-16 ~45 ~27 ~-16 ~45 minecraft:air
setblock ~28 ~-16 ~45 minecraft:smooth_quartz
setblock ~29 ~-16 ~45 minecraft:quartz_pillar
fill ~30 ~-16 ~45 ~38 ~-16 ~45 minecraft:air
setblock ~39 ~-16 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-16 ~45 minecraft:smooth_quartz
fill ~41 ~-16 ~45 ~49 ~-16 ~45 minecraft:air
setblock ~50 ~-16 ~45 minecraft:light_gray_concrete
fill ~51 ~-16 ~45 ~63 ~-16 ~45 minecraft:air
setblock ~64 ~-16 ~45 minecraft:light_gray_concrete
setblock ~4 ~-16 ~46 minecraft:light_gray_concrete
fill ~5 ~-16 ~46 ~7 ~-16 ~46 minecraft:air
setblock ~8 ~-16 ~46 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~46 ~17 ~-16 ~46 minecraft:air
setblock ~18 ~-16 ~46 minecraft:light_gray_concrete
fill ~19 ~-16 ~46 ~28 ~-16 ~46 minecraft:air
setblock ~29 ~-16 ~46 minecraft:quartz_pillar
fill ~30 ~-16 ~46 ~31 ~-16 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-16 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-16 ~46 ~35 ~-16 ~46 minecraft:air
setblock ~36 ~-16 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-16 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-16 ~46 minecraft:quartz_pillar
setblock ~39 ~-16 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-16 ~46 ~49 ~-16 ~46 minecraft:air
setblock ~50 ~-16 ~46 minecraft:light_gray_concrete
fill ~51 ~-16 ~46 ~63 ~-16 ~46 minecraft:air
setblock ~64 ~-16 ~46 minecraft:light_gray_concrete
setblock ~4 ~-16 ~47 minecraft:light_gray_concrete
fill ~5 ~-16 ~47 ~7 ~-16 ~47 minecraft:air
setblock ~8 ~-16 ~47 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~47 ~17 ~-16 ~47 minecraft:air
setblock ~18 ~-16 ~47 minecraft:light_gray_concrete
fill ~19 ~-16 ~47 ~31 ~-16 ~47 minecraft:air
setblock ~32 ~-16 ~47 minecraft:light_gray_concrete
fill ~33 ~-16 ~47 ~35 ~-16 ~47 minecraft:air
setblock ~36 ~-16 ~47 minecraft:light_gray_concrete
fill ~37 ~-16 ~47 ~49 ~-16 ~47 minecraft:air
setblock ~50 ~-16 ~47 minecraft:light_gray_concrete
fill ~51 ~-16 ~47 ~63 ~-16 ~47 minecraft:air
setblock ~64 ~-16 ~47 minecraft:light_gray_concrete
setblock ~4 ~-16 ~48 minecraft:light_gray_concrete
fill ~5 ~-16 ~48 ~7 ~-16 ~48 minecraft:air
setblock ~8 ~-16 ~48 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-16 ~48 ~17 ~-16 ~48 minecraft:air
setblock ~18 ~-16 ~48 minecraft:light_gray_concrete
fill ~19 ~-16 ~48 ~31 ~-16 ~48 minecraft:air
setblock ~32 ~-16 ~48 minecraft:light_gray_concrete
fill ~33 ~-16 ~48 ~35 ~-16 ~48 minecraft:air
setblock ~36 ~-16 ~48 minecraft:light_gray_concrete
fill ~37 ~-16 ~48 ~49 ~-16 ~48 minecraft:air
setblock ~50 ~-16 ~48 minecraft:light_gray_concrete
fill ~51 ~-16 ~48 ~63 ~-16 ~48 minecraft:air
setblock ~64 ~-16 ~48 minecraft:light_gray_concrete
setblock ~4 ~-16 ~49 minecraft:light_gray_concrete
fill ~5 ~-16 ~49 ~7 ~-16 ~49 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~8 ~-16 ~49 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-16 ~49 ~17 ~-16 ~49 minecraft:air
setblock ~18 ~-16 ~49 minecraft:light_gray_concrete
fill ~19 ~-16 ~49 ~31 ~-16 ~49 minecraft:air
setblock ~32 ~-16 ~49 minecraft:light_gray_concrete
fill ~33 ~-16 ~49 ~35 ~-16 ~49 minecraft:air
setblock ~36 ~-16 ~49 minecraft:light_gray_concrete
fill ~37 ~-16 ~49 ~49 ~-16 ~49 minecraft:air
setblock ~50 ~-16 ~49 minecraft:light_gray_concrete
fill ~51 ~-16 ~49 ~63 ~-16 ~49 minecraft:air
setblock ~64 ~-16 ~49 minecraft:light_gray_concrete
fill ~4 ~-16 ~50 ~32 ~-16 ~50 minecraft:light_gray_concrete
fill ~33 ~-16 ~50 ~35 ~-16 ~50 minecraft:air
fill ~36 ~-16 ~50 ~64 ~-16 ~50 minecraft:light_gray_concrete
setblock ~4 ~-16 ~51 minecraft:light_gray_concrete
fill ~5 ~-16 ~51 ~17 ~-16 ~51 minecraft:air
setblock ~18 ~-16 ~51 minecraft:light_gray_concrete
fill ~19 ~-16 ~51 ~31 ~-16 ~51 minecraft:air
setblock ~32 ~-16 ~51 minecraft:light_gray_concrete
fill ~33 ~-16 ~51 ~35 ~-16 ~51 minecraft:air
setblock ~36 ~-16 ~51 minecraft:light_gray_concrete
fill ~37 ~-16 ~51 ~49 ~-16 ~51 minecraft:air
setblock ~50 ~-16 ~51 minecraft:light_gray_concrete
fill ~51 ~-16 ~51 ~63 ~-16 ~51 minecraft:air
setblock ~64 ~-16 ~51 minecraft:light_gray_concrete
setblock ~4 ~-16 ~52 minecraft:light_gray_concrete
fill ~5 ~-16 ~52 ~17 ~-16 ~52 minecraft:air
setblock ~18 ~-16 ~52 minecraft:light_gray_concrete
fill ~19 ~-16 ~52 ~31 ~-16 ~52 minecraft:air
setblock ~32 ~-16 ~52 minecraft:light_gray_concrete
fill ~33 ~-16 ~52 ~35 ~-16 ~52 minecraft:air
setblock ~36 ~-16 ~52 minecraft:light_gray_concrete
fill ~37 ~-16 ~52 ~49 ~-16 ~52 minecraft:air
setblock ~50 ~-16 ~52 minecraft:light_gray_concrete
fill ~51 ~-16 ~52 ~63 ~-16 ~52 minecraft:air
setblock ~64 ~-16 ~52 minecraft:light_gray_concrete
setblock ~4 ~-16 ~53 minecraft:light_gray_concrete
fill ~5 ~-16 ~53 ~17 ~-16 ~53 minecraft:air
setblock ~18 ~-16 ~53 minecraft:light_gray_concrete
fill ~19 ~-16 ~53 ~31 ~-16 ~53 minecraft:air
setblock ~32 ~-16 ~53 minecraft:light_gray_concrete
fill ~33 ~-16 ~53 ~35 ~-16 ~53 minecraft:air
setblock ~36 ~-16 ~53 minecraft:light_gray_concrete
fill ~37 ~-16 ~53 ~49 ~-16 ~53 minecraft:air
setblock ~50 ~-16 ~53 minecraft:light_gray_concrete
fill ~51 ~-16 ~53 ~63 ~-16 ~53 minecraft:air
setblock ~64 ~-16 ~53 minecraft:light_gray_concrete
setblock ~4 ~-16 ~54 minecraft:light_gray_concrete
fill ~5 ~-16 ~54 ~17 ~-16 ~54 minecraft:air
setblock ~18 ~-16 ~54 minecraft:light_gray_concrete
fill ~19 ~-16 ~54 ~31 ~-16 ~54 minecraft:air
setblock ~32 ~-16 ~54 minecraft:light_gray_concrete
fill ~33 ~-16 ~54 ~35 ~-16 ~54 minecraft:air
setblock ~36 ~-16 ~54 minecraft:light_gray_concrete
fill ~37 ~-16 ~54 ~49 ~-16 ~54 minecraft:air
setblock ~50 ~-16 ~54 minecraft:light_gray_concrete
fill ~51 ~-16 ~54 ~63 ~-16 ~54 minecraft:air
setblock ~64 ~-16 ~54 minecraft:light_gray_concrete
setblock ~4 ~-16 ~55 minecraft:light_gray_concrete
fill ~5 ~-16 ~55 ~17 ~-16 ~55 minecraft:air
setblock ~18 ~-16 ~55 minecraft:light_gray_concrete
fill ~19 ~-16 ~55 ~31 ~-16 ~55 minecraft:air
setblock ~32 ~-16 ~55 minecraft:light_gray_concrete
fill ~33 ~-16 ~55 ~35 ~-16 ~55 minecraft:air
setblock ~36 ~-16 ~55 minecraft:light_gray_concrete
fill ~37 ~-16 ~55 ~49 ~-16 ~55 minecraft:air
setblock ~50 ~-16 ~55 minecraft:light_gray_concrete
fill ~51 ~-16 ~55 ~63 ~-16 ~55 minecraft:air
setblock ~64 ~-16 ~55 minecraft:light_gray_concrete
setblock ~4 ~-16 ~56 minecraft:light_gray_concrete
fill ~5 ~-16 ~56 ~17 ~-16 ~56 minecraft:air
setblock ~18 ~-16 ~56 minecraft:light_gray_concrete
fill ~19 ~-16 ~56 ~31 ~-16 ~56 minecraft:air
setblock ~32 ~-16 ~56 minecraft:light_gray_concrete
fill ~33 ~-16 ~56 ~35 ~-16 ~56 minecraft:air
setblock ~36 ~-16 ~56 minecraft:light_gray_concrete
fill ~37 ~-16 ~56 ~49 ~-16 ~56 minecraft:air
setblock ~50 ~-16 ~56 minecraft:light_gray_concrete
fill ~51 ~-16 ~56 ~63 ~-16 ~56 minecraft:air
setblock ~64 ~-16 ~56 minecraft:light_gray_concrete
setblock ~4 ~-16 ~57 minecraft:light_gray_concrete
fill ~5 ~-16 ~57 ~17 ~-16 ~57 minecraft:air
setblock ~18 ~-16 ~57 minecraft:light_gray_concrete
fill ~19 ~-16 ~57 ~31 ~-16 ~57 minecraft:air
setblock ~32 ~-16 ~57 minecraft:light_gray_concrete
fill ~33 ~-16 ~57 ~35 ~-16 ~57 minecraft:air
setblock ~36 ~-16 ~57 minecraft:light_gray_concrete
fill ~37 ~-16 ~57 ~49 ~-16 ~57 minecraft:air
setblock ~50 ~-16 ~57 minecraft:light_gray_concrete
fill ~51 ~-16 ~57 ~63 ~-16 ~57 minecraft:air
setblock ~64 ~-16 ~57 minecraft:light_gray_concrete
setblock ~4 ~-16 ~58 minecraft:light_gray_concrete
fill ~5 ~-16 ~58 ~17 ~-16 ~58 minecraft:air
setblock ~18 ~-16 ~58 minecraft:light_gray_concrete
fill ~19 ~-16 ~58 ~31 ~-16 ~58 minecraft:air
setblock ~32 ~-16 ~58 minecraft:light_gray_concrete
fill ~33 ~-16 ~58 ~35 ~-16 ~58 minecraft:air
setblock ~36 ~-16 ~58 minecraft:light_gray_concrete
fill ~37 ~-16 ~58 ~49 ~-16 ~58 minecraft:air
setblock ~50 ~-16 ~58 minecraft:light_gray_concrete
fill ~51 ~-16 ~58 ~63 ~-16 ~58 minecraft:air
setblock ~64 ~-16 ~58 minecraft:light_gray_concrete
setblock ~4 ~-16 ~59 minecraft:light_gray_concrete
fill ~5 ~-16 ~59 ~17 ~-16 ~59 minecraft:air
setblock ~18 ~-16 ~59 minecraft:light_gray_concrete
fill ~19 ~-16 ~59 ~31 ~-16 ~59 minecraft:air
setblock ~32 ~-16 ~59 minecraft:light_gray_concrete
fill ~33 ~-16 ~59 ~35 ~-16 ~59 minecraft:air
setblock ~36 ~-16 ~59 minecraft:light_gray_concrete
fill ~37 ~-16 ~59 ~49 ~-16 ~59 minecraft:air
setblock ~50 ~-16 ~59 minecraft:light_gray_concrete
fill ~51 ~-16 ~59 ~63 ~-16 ~59 minecraft:air
setblock ~64 ~-16 ~59 minecraft:light_gray_concrete
setblock ~4 ~-16 ~60 minecraft:light_gray_concrete
fill ~5 ~-16 ~60 ~17 ~-16 ~60 minecraft:air
setblock ~18 ~-16 ~60 minecraft:light_gray_concrete
fill ~19 ~-16 ~60 ~31 ~-16 ~60 minecraft:air
setblock ~32 ~-16 ~60 minecraft:light_gray_concrete
fill ~33 ~-16 ~60 ~35 ~-16 ~60 minecraft:air
setblock ~36 ~-16 ~60 minecraft:light_gray_concrete
fill ~37 ~-16 ~60 ~49 ~-16 ~60 minecraft:air
setblock ~50 ~-16 ~60 minecraft:light_gray_concrete
fill ~51 ~-16 ~60 ~63 ~-16 ~60 minecraft:air
setblock ~64 ~-16 ~60 minecraft:light_gray_concrete
setblock ~4 ~-16 ~61 minecraft:light_gray_concrete
fill ~5 ~-16 ~61 ~17 ~-16 ~61 minecraft:air
setblock ~18 ~-16 ~61 minecraft:light_gray_concrete
fill ~19 ~-16 ~61 ~31 ~-16 ~61 minecraft:air
setblock ~32 ~-16 ~61 minecraft:light_gray_concrete
fill ~33 ~-16 ~61 ~35 ~-16 ~61 minecraft:air
setblock ~36 ~-16 ~61 minecraft:light_gray_concrete
fill ~37 ~-16 ~61 ~49 ~-16 ~61 minecraft:air
setblock ~50 ~-16 ~61 minecraft:light_gray_concrete
fill ~51 ~-16 ~61 ~63 ~-16 ~61 minecraft:air
setblock ~64 ~-16 ~61 minecraft:light_gray_concrete
setblock ~4 ~-16 ~62 minecraft:light_gray_concrete
fill ~5 ~-16 ~62 ~17 ~-16 ~62 minecraft:air
setblock ~18 ~-16 ~62 minecraft:light_gray_concrete
fill ~19 ~-16 ~62 ~31 ~-16 ~62 minecraft:air
setblock ~32 ~-16 ~62 minecraft:light_gray_concrete
fill ~33 ~-16 ~62 ~35 ~-16 ~62 minecraft:air
setblock ~36 ~-16 ~62 minecraft:light_gray_concrete
fill ~37 ~-16 ~62 ~49 ~-16 ~62 minecraft:air
setblock ~50 ~-16 ~62 minecraft:light_gray_concrete
fill ~51 ~-16 ~62 ~63 ~-16 ~62 minecraft:air
setblock ~64 ~-16 ~62 minecraft:light_gray_concrete
setblock ~4 ~-16 ~63 minecraft:light_gray_concrete
fill ~5 ~-16 ~63 ~17 ~-16 ~63 minecraft:air
setblock ~18 ~-16 ~63 minecraft:light_gray_concrete
fill ~19 ~-16 ~63 ~31 ~-16 ~63 minecraft:air
setblock ~32 ~-16 ~63 minecraft:light_gray_concrete
fill ~33 ~-16 ~63 ~35 ~-16 ~63 minecraft:air
setblock ~36 ~-16 ~63 minecraft:light_gray_concrete
fill ~37 ~-16 ~63 ~49 ~-16 ~63 minecraft:air
setblock ~50 ~-16 ~63 minecraft:light_gray_concrete
fill ~51 ~-16 ~63 ~63 ~-16 ~63 minecraft:air
setblock ~64 ~-16 ~63 minecraft:light_gray_concrete
fill ~4 ~-16 ~64 ~64 ~-16 ~64 minecraft:light_gray_concrete
fill ~32 ~-16 ~66 ~36 ~-16 ~66 minecraft:polished_andesite
setblock ~32 ~-16 ~67 minecraft:polished_andesite
fill ~33 ~-16 ~67 ~35 ~-16 ~67 minecraft:air
setblock ~36 ~-16 ~67 minecraft:polished_andesite
setblock ~32 ~-16 ~68 minecraft:sea_lantern
setblock ~33 ~-16 ~68 minecraft:air
setblock ~34 ~-16 ~68 minecraft:quartz_pillar
setblock ~35 ~-16 ~68 minecraft:air
setblock ~36 ~-16 ~68 minecraft:sea_lantern
setblock ~32 ~-16 ~69 minecraft:polished_andesite
setblock ~33 ~-16 ~69 minecraft:air
setblock ~34 ~-16 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-16 ~69 minecraft:air
setblock ~36 ~-16 ~69 minecraft:polished_andesite
fill ~32 ~-16 ~70 ~36 ~-16 ~70 minecraft:polished_andesite
fill ~4 ~-15 ~4 ~64 ~-15 ~4 minecraft:light_gray_concrete
setblock ~4 ~-15 ~5 minecraft:light_gray_concrete
fill ~5 ~-15 ~5 ~17 ~-15 ~5 minecraft:air
setblock ~18 ~-15 ~5 minecraft:light_gray_concrete
fill ~19 ~-15 ~5 ~31 ~-15 ~5 minecraft:air
setblock ~32 ~-15 ~5 minecraft:light_gray_concrete
fill ~33 ~-15 ~5 ~35 ~-15 ~5 minecraft:air
setblock ~36 ~-15 ~5 minecraft:light_gray_concrete
fill ~37 ~-15 ~5 ~49 ~-15 ~5 minecraft:air
setblock ~50 ~-15 ~5 minecraft:light_gray_concrete
fill ~51 ~-15 ~5 ~63 ~-15 ~5 minecraft:air
setblock ~64 ~-15 ~5 minecraft:light_gray_concrete
setblock ~4 ~-15 ~6 minecraft:light_gray_concrete
fill ~5 ~-15 ~6 ~17 ~-15 ~6 minecraft:air
setblock ~18 ~-15 ~6 minecraft:light_gray_concrete
fill ~19 ~-15 ~6 ~31 ~-15 ~6 minecraft:air
setblock ~32 ~-15 ~6 minecraft:light_gray_concrete
fill ~33 ~-15 ~6 ~35 ~-15 ~6 minecraft:air
setblock ~36 ~-15 ~6 minecraft:light_gray_concrete
fill ~37 ~-15 ~6 ~49 ~-15 ~6 minecraft:air
setblock ~50 ~-15 ~6 minecraft:light_gray_concrete
fill ~51 ~-15 ~6 ~63 ~-15 ~6 minecraft:air
setblock ~64 ~-15 ~6 minecraft:light_gray_concrete
setblock ~4 ~-15 ~7 minecraft:light_gray_concrete
fill ~5 ~-15 ~7 ~17 ~-15 ~7 minecraft:air
setblock ~18 ~-15 ~7 minecraft:light_gray_concrete
fill ~19 ~-15 ~7 ~31 ~-15 ~7 minecraft:air
setblock ~32 ~-15 ~7 minecraft:light_gray_concrete
fill ~33 ~-15 ~7 ~35 ~-15 ~7 minecraft:air
setblock ~36 ~-15 ~7 minecraft:light_gray_concrete
fill ~37 ~-15 ~7 ~49 ~-15 ~7 minecraft:air
setblock ~50 ~-15 ~7 minecraft:light_gray_concrete
fill ~51 ~-15 ~7 ~63 ~-15 ~7 minecraft:air
setblock ~64 ~-15 ~7 minecraft:light_gray_concrete
setblock ~4 ~-15 ~8 minecraft:light_gray_concrete
fill ~5 ~-15 ~8 ~17 ~-15 ~8 minecraft:air
setblock ~18 ~-15 ~8 minecraft:light_gray_concrete
fill ~19 ~-15 ~8 ~31 ~-15 ~8 minecraft:air
setblock ~32 ~-15 ~8 minecraft:light_gray_concrete
fill ~33 ~-15 ~8 ~35 ~-15 ~8 minecraft:air
setblock ~36 ~-15 ~8 minecraft:light_gray_concrete
fill ~37 ~-15 ~8 ~49 ~-15 ~8 minecraft:air
setblock ~50 ~-15 ~8 minecraft:light_gray_concrete
fill ~51 ~-15 ~8 ~63 ~-15 ~8 minecraft:air
setblock ~64 ~-15 ~8 minecraft:light_gray_concrete
setblock ~4 ~-15 ~9 minecraft:light_gray_concrete
fill ~5 ~-15 ~9 ~17 ~-15 ~9 minecraft:air
setblock ~18 ~-15 ~9 minecraft:light_gray_concrete
fill ~19 ~-15 ~9 ~31 ~-15 ~9 minecraft:air
setblock ~32 ~-15 ~9 minecraft:light_gray_concrete
fill ~33 ~-15 ~9 ~35 ~-15 ~9 minecraft:air
setblock ~36 ~-15 ~9 minecraft:light_gray_concrete
fill ~37 ~-15 ~9 ~49 ~-15 ~9 minecraft:air
setblock ~50 ~-15 ~9 minecraft:light_gray_concrete
fill ~51 ~-15 ~9 ~63 ~-15 ~9 minecraft:air
setblock ~64 ~-15 ~9 minecraft:light_gray_concrete
setblock ~4 ~-15 ~10 minecraft:light_gray_concrete
fill ~5 ~-15 ~10 ~17 ~-15 ~10 minecraft:air
setblock ~18 ~-15 ~10 minecraft:light_gray_concrete
fill ~19 ~-15 ~10 ~31 ~-15 ~10 minecraft:air
setblock ~32 ~-15 ~10 minecraft:light_gray_concrete
fill ~33 ~-15 ~10 ~35 ~-15 ~10 minecraft:air
setblock ~36 ~-15 ~10 minecraft:light_gray_concrete
fill ~37 ~-15 ~10 ~49 ~-15 ~10 minecraft:air
setblock ~50 ~-15 ~10 minecraft:light_gray_concrete
fill ~51 ~-15 ~10 ~63 ~-15 ~10 minecraft:air
setblock ~64 ~-15 ~10 minecraft:light_gray_concrete
setblock ~4 ~-15 ~11 minecraft:light_gray_concrete
fill ~5 ~-15 ~11 ~17 ~-15 ~11 minecraft:air
setblock ~18 ~-15 ~11 minecraft:light_gray_concrete
fill ~19 ~-15 ~11 ~31 ~-15 ~11 minecraft:air
setblock ~32 ~-15 ~11 minecraft:light_gray_concrete
fill ~33 ~-15 ~11 ~35 ~-15 ~11 minecraft:air
setblock ~36 ~-15 ~11 minecraft:light_gray_concrete
fill ~37 ~-15 ~11 ~49 ~-15 ~11 minecraft:air
setblock ~50 ~-15 ~11 minecraft:light_gray_concrete
fill ~51 ~-15 ~11 ~63 ~-15 ~11 minecraft:air
setblock ~64 ~-15 ~11 minecraft:light_gray_concrete
setblock ~4 ~-15 ~12 minecraft:light_gray_concrete
fill ~5 ~-15 ~12 ~17 ~-15 ~12 minecraft:air
setblock ~18 ~-15 ~12 minecraft:light_gray_concrete
fill ~19 ~-15 ~12 ~31 ~-15 ~12 minecraft:air
setblock ~32 ~-15 ~12 minecraft:light_gray_concrete
fill ~33 ~-15 ~12 ~35 ~-15 ~12 minecraft:air
setblock ~36 ~-15 ~12 minecraft:light_gray_concrete
fill ~37 ~-15 ~12 ~49 ~-15 ~12 minecraft:air
setblock ~50 ~-15 ~12 minecraft:light_gray_concrete
fill ~51 ~-15 ~12 ~63 ~-15 ~12 minecraft:air
setblock ~64 ~-15 ~12 minecraft:light_gray_concrete
setblock ~4 ~-15 ~13 minecraft:light_gray_concrete
fill ~5 ~-15 ~13 ~17 ~-15 ~13 minecraft:air
setblock ~18 ~-15 ~13 minecraft:light_gray_concrete
fill ~19 ~-15 ~13 ~31 ~-15 ~13 minecraft:air
setblock ~32 ~-15 ~13 minecraft:light_gray_concrete
fill ~33 ~-15 ~13 ~35 ~-15 ~13 minecraft:air
setblock ~36 ~-15 ~13 minecraft:light_gray_concrete
fill ~37 ~-15 ~13 ~49 ~-15 ~13 minecraft:air
setblock ~50 ~-15 ~13 minecraft:light_gray_concrete
fill ~51 ~-15 ~13 ~63 ~-15 ~13 minecraft:air
setblock ~64 ~-15 ~13 minecraft:light_gray_concrete
setblock ~4 ~-15 ~14 minecraft:light_gray_concrete
fill ~5 ~-15 ~14 ~17 ~-15 ~14 minecraft:air
setblock ~18 ~-15 ~14 minecraft:light_gray_concrete
fill ~19 ~-15 ~14 ~31 ~-15 ~14 minecraft:air
setblock ~32 ~-15 ~14 minecraft:light_gray_concrete
fill ~33 ~-15 ~14 ~35 ~-15 ~14 minecraft:air
setblock ~36 ~-15 ~14 minecraft:light_gray_concrete
fill ~37 ~-15 ~14 ~49 ~-15 ~14 minecraft:air
setblock ~50 ~-15 ~14 minecraft:light_gray_concrete
fill ~51 ~-15 ~14 ~63 ~-15 ~14 minecraft:air
setblock ~64 ~-15 ~14 minecraft:light_gray_concrete
setblock ~4 ~-15 ~15 minecraft:light_gray_concrete
fill ~5 ~-15 ~15 ~17 ~-15 ~15 minecraft:air
setblock ~18 ~-15 ~15 minecraft:light_gray_concrete
fill ~19 ~-15 ~15 ~31 ~-15 ~15 minecraft:air
setblock ~32 ~-15 ~15 minecraft:light_gray_concrete
fill ~33 ~-15 ~15 ~35 ~-15 ~15 minecraft:air
setblock ~36 ~-15 ~15 minecraft:light_gray_concrete
fill ~37 ~-15 ~15 ~49 ~-15 ~15 minecraft:air
setblock ~50 ~-15 ~15 minecraft:light_gray_concrete
fill ~51 ~-15 ~15 ~63 ~-15 ~15 minecraft:air
setblock ~64 ~-15 ~15 minecraft:light_gray_concrete
setblock ~4 ~-15 ~16 minecraft:light_gray_concrete
fill ~5 ~-15 ~16 ~17 ~-15 ~16 minecraft:air
setblock ~18 ~-15 ~16 minecraft:light_gray_concrete
fill ~19 ~-15 ~16 ~31 ~-15 ~16 minecraft:air
setblock ~32 ~-15 ~16 minecraft:light_gray_concrete
fill ~33 ~-15 ~16 ~35 ~-15 ~16 minecraft:air
setblock ~36 ~-15 ~16 minecraft:light_gray_concrete
fill ~37 ~-15 ~16 ~49 ~-15 ~16 minecraft:air
setblock ~50 ~-15 ~16 minecraft:light_gray_concrete
fill ~51 ~-15 ~16 ~63 ~-15 ~16 minecraft:air
setblock ~64 ~-15 ~16 minecraft:light_gray_concrete
setblock ~4 ~-15 ~17 minecraft:light_gray_concrete
fill ~5 ~-15 ~17 ~17 ~-15 ~17 minecraft:air
setblock ~18 ~-15 ~17 minecraft:light_gray_concrete
fill ~19 ~-15 ~17 ~31 ~-15 ~17 minecraft:air
setblock ~32 ~-15 ~17 minecraft:light_gray_concrete
fill ~33 ~-15 ~17 ~35 ~-15 ~17 minecraft:air
setblock ~36 ~-15 ~17 minecraft:light_gray_concrete
fill ~37 ~-15 ~17 ~49 ~-15 ~17 minecraft:air
setblock ~50 ~-15 ~17 minecraft:light_gray_concrete
fill ~51 ~-15 ~17 ~63 ~-15 ~17 minecraft:air
setblock ~64 ~-15 ~17 minecraft:light_gray_concrete
fill ~4 ~-15 ~18 ~32 ~-15 ~18 minecraft:light_gray_concrete
fill ~33 ~-15 ~18 ~35 ~-15 ~18 minecraft:air
fill ~36 ~-15 ~18 ~64 ~-15 ~18 minecraft:light_gray_concrete
setblock ~4 ~-15 ~19 minecraft:light_gray_concrete
fill ~5 ~-15 ~19 ~17 ~-15 ~19 minecraft:air
setblock ~18 ~-15 ~19 minecraft:light_gray_concrete
fill ~19 ~-15 ~19 ~30 ~-15 ~19 minecraft:black_concrete
setblock ~31 ~-15 ~19 minecraft:air
setblock ~32 ~-15 ~19 minecraft:light_gray_concrete
fill ~33 ~-15 ~19 ~35 ~-15 ~19 minecraft:air
setblock ~36 ~-15 ~19 minecraft:light_gray_concrete
fill ~37 ~-15 ~19 ~49 ~-15 ~19 minecraft:air
setblock ~50 ~-15 ~19 minecraft:light_gray_concrete
fill ~51 ~-15 ~19 ~63 ~-15 ~19 minecraft:air
setblock ~64 ~-15 ~19 minecraft:light_gray_concrete
setblock ~4 ~-15 ~20 minecraft:light_gray_concrete
fill ~5 ~-15 ~20 ~17 ~-15 ~20 minecraft:air
setblock ~18 ~-15 ~20 minecraft:light_gray_concrete
fill ~19 ~-15 ~20 ~31 ~-15 ~20 minecraft:air
setblock ~32 ~-15 ~20 minecraft:light_gray_concrete
fill ~33 ~-15 ~20 ~35 ~-15 ~20 minecraft:air
setblock ~36 ~-15 ~20 minecraft:light_gray_concrete
fill ~37 ~-15 ~20 ~49 ~-15 ~20 minecraft:air
setblock ~50 ~-15 ~20 minecraft:light_gray_concrete
fill ~51 ~-15 ~20 ~63 ~-15 ~20 minecraft:air
setblock ~64 ~-15 ~20 minecraft:light_gray_concrete
setblock ~4 ~-15 ~21 minecraft:light_gray_concrete
fill ~5 ~-15 ~21 ~17 ~-15 ~21 minecraft:air
setblock ~18 ~-15 ~21 minecraft:light_gray_concrete
fill ~19 ~-15 ~21 ~31 ~-15 ~21 minecraft:air
setblock ~32 ~-15 ~21 minecraft:light_gray_concrete
setblock ~33 ~-15 ~21 minecraft:air
setblock ~34 ~-15 ~21 minecraft:smooth_quartz
setblock ~35 ~-15 ~21 minecraft:air
setblock ~36 ~-15 ~21 minecraft:light_gray_concrete
fill ~37 ~-15 ~21 ~49 ~-15 ~21 minecraft:air
setblock ~50 ~-15 ~21 minecraft:light_gray_concrete
fill ~51 ~-15 ~21 ~63 ~-15 ~21 minecraft:air
setblock ~64 ~-15 ~21 minecraft:light_gray_concrete
setblock ~4 ~-15 ~22 minecraft:light_gray_concrete
fill ~5 ~-15 ~22 ~17 ~-15 ~22 minecraft:air
setblock ~18 ~-15 ~22 minecraft:light_gray_concrete
fill ~19 ~-15 ~22 ~28 ~-15 ~22 minecraft:air
setblock ~29 ~-15 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-15 ~22 minecraft:quartz_pillar
setblock ~31 ~-15 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-15 ~22 minecraft:glass_pane[north=true,east=true,west=true]
setblock ~33 ~-15 ~22 minecraft:smooth_quartz
setblock ~34 ~-15 ~22 minecraft:air
setblock ~35 ~-15 ~22 minecraft:smooth_quartz
setblock ~36 ~-15 ~22 minecraft:glass_pane[north=true,east=true,west=true]
fill ~37 ~-15 ~22 ~38 ~-15 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-15 ~22 minecraft:quartz_pillar
fill ~40 ~-15 ~22 ~49 ~-15 ~22 minecraft:air
setblock ~50 ~-15 ~22 minecraft:light_gray_concrete
fill ~51 ~-15 ~22 ~63 ~-15 ~22 minecraft:air
setblock ~64 ~-15 ~22 minecraft:light_gray_concrete
setblock ~4 ~-15 ~23 minecraft:light_gray_concrete
fill ~5 ~-15 ~23 ~17 ~-15 ~23 minecraft:air
setblock ~18 ~-15 ~23 minecraft:light_gray_concrete
fill ~19 ~-15 ~23 ~27 ~-15 ~23 minecraft:air
setblock ~28 ~-15 ~23 minecraft:smooth_quartz
setblock ~29 ~-15 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-15 ~23 ~38 ~-15 ~23 minecraft:air
setblock ~39 ~-15 ~23 minecraft:quartz_pillar
setblock ~40 ~-15 ~23 minecraft:smooth_quartz
fill ~41 ~-15 ~23 ~49 ~-15 ~23 minecraft:air
setblock ~50 ~-15 ~23 minecraft:light_gray_concrete
fill ~51 ~-15 ~23 ~63 ~-15 ~23 minecraft:air
setblock ~64 ~-15 ~23 minecraft:light_gray_concrete
setblock ~4 ~-15 ~24 minecraft:light_gray_concrete
fill ~5 ~-15 ~24 ~17 ~-15 ~24 minecraft:air
setblock ~18 ~-15 ~24 minecraft:light_gray_concrete
fill ~19 ~-15 ~24 ~25 ~-15 ~24 minecraft:air
setblock ~26 ~-15 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-15 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-15 ~24 ~29 ~-15 ~24 minecraft:air
setblock ~30 ~-15 ~24 minecraft:quartz_pillar
fill ~31 ~-15 ~24 ~37 ~-15 ~24 minecraft:air
setblock ~38 ~-15 ~24 minecraft:quartz_pillar
fill ~39 ~-15 ~24 ~40 ~-15 ~24 minecraft:air
setblock ~41 ~-15 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-15 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-15 ~24 ~49 ~-15 ~24 minecraft:air
setblock ~50 ~-15 ~24 minecraft:light_gray_concrete
fill ~51 ~-15 ~24 ~63 ~-15 ~24 minecraft:air
setblock ~64 ~-15 ~24 minecraft:light_gray_concrete
setblock ~4 ~-15 ~25 minecraft:light_gray_concrete
fill ~5 ~-15 ~25 ~17 ~-15 ~25 minecraft:air
setblock ~18 ~-15 ~25 minecraft:light_gray_concrete
fill ~19 ~-15 ~25 ~24 ~-15 ~25 minecraft:air
fill ~25 ~-15 ~25 ~26 ~-15 ~25 minecraft:quartz_pillar
fill ~27 ~-15 ~25 ~41 ~-15 ~25 minecraft:air
setblock ~42 ~-15 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-15 ~25 minecraft:quartz_pillar
fill ~44 ~-15 ~25 ~49 ~-15 ~25 minecraft:air
setblock ~50 ~-15 ~25 minecraft:light_gray_concrete
fill ~51 ~-15 ~25 ~63 ~-15 ~25 minecraft:air
setblock ~64 ~-15 ~25 minecraft:light_gray_concrete
setblock ~4 ~-15 ~26 minecraft:light_gray_concrete
fill ~5 ~-15 ~26 ~17 ~-15 ~26 minecraft:air
setblock ~18 ~-15 ~26 minecraft:light_gray_concrete
fill ~19 ~-15 ~26 ~23 ~-15 ~26 minecraft:air
setblock ~24 ~-15 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-15 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-15 ~26 ~42 ~-15 ~26 minecraft:air
setblock ~43 ~-15 ~26 minecraft:quartz_pillar
setblock ~44 ~-15 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-15 ~26 ~49 ~-15 ~26 minecraft:air
setblock ~50 ~-15 ~26 minecraft:light_gray_concrete
fill ~51 ~-15 ~26 ~63 ~-15 ~26 minecraft:air
setblock ~64 ~-15 ~26 minecraft:light_gray_concrete
setblock ~4 ~-15 ~27 minecraft:light_gray_concrete
fill ~5 ~-15 ~27 ~17 ~-15 ~27 minecraft:air
setblock ~18 ~-15 ~27 minecraft:light_gray_concrete
fill ~19 ~-15 ~27 ~23 ~-15 ~27 minecraft:air
setblock ~24 ~-15 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-15 ~27 ~43 ~-15 ~27 minecraft:air
setblock ~44 ~-15 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-15 ~27 ~49 ~-15 ~27 minecraft:air
setblock ~50 ~-15 ~27 minecraft:light_gray_concrete
fill ~51 ~-15 ~27 ~63 ~-15 ~27 minecraft:air
setblock ~64 ~-15 ~27 minecraft:light_gray_concrete
setblock ~4 ~-15 ~28 minecraft:light_gray_concrete
fill ~5 ~-15 ~28 ~17 ~-15 ~28 minecraft:air
setblock ~18 ~-15 ~28 minecraft:light_gray_concrete
fill ~19 ~-15 ~28 ~22 ~-15 ~28 minecraft:air
setblock ~23 ~-15 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-15 ~28 ~44 ~-15 ~28 minecraft:air
setblock ~45 ~-15 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-15 ~28 ~49 ~-15 ~28 minecraft:air
setblock ~50 ~-15 ~28 minecraft:light_gray_concrete
fill ~51 ~-15 ~28 ~63 ~-15 ~28 minecraft:air
setblock ~64 ~-15 ~28 minecraft:light_gray_concrete
setblock ~4 ~-15 ~29 minecraft:light_gray_concrete
fill ~5 ~-15 ~29 ~17 ~-15 ~29 minecraft:air
setblock ~18 ~-15 ~29 minecraft:light_gray_concrete
fill ~19 ~-15 ~29 ~21 ~-15 ~29 minecraft:air
fill ~22 ~-15 ~29 ~23 ~-15 ~29 minecraft:quartz_pillar
fill ~24 ~-15 ~29 ~44 ~-15 ~29 minecraft:air
setblock ~45 ~-15 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-15 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-15 ~29 ~49 ~-15 ~29 minecraft:air
setblock ~50 ~-15 ~29 minecraft:light_gray_concrete
fill ~51 ~-15 ~29 ~63 ~-15 ~29 minecraft:air
setblock ~64 ~-15 ~29 minecraft:light_gray_concrete
setblock ~4 ~-15 ~30 minecraft:light_gray_concrete
fill ~5 ~-15 ~30 ~17 ~-15 ~30 minecraft:air
setblock ~18 ~-15 ~30 minecraft:light_gray_concrete
fill ~19 ~-15 ~30 ~21 ~-15 ~30 minecraft:air
setblock ~22 ~-15 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-15 ~30 minecraft:air
setblock ~24 ~-15 ~30 minecraft:quartz_pillar
fill ~25 ~-15 ~30 ~43 ~-15 ~30 minecraft:air
setblock ~44 ~-15 ~30 minecraft:quartz_pillar
setblock ~45 ~-15 ~30 minecraft:air
setblock ~46 ~-15 ~30 minecraft:quartz_pillar
fill ~47 ~-15 ~30 ~49 ~-15 ~30 minecraft:air
setblock ~50 ~-15 ~30 minecraft:light_gray_concrete
fill ~51 ~-15 ~30 ~63 ~-15 ~30 minecraft:air
setblock ~64 ~-15 ~30 minecraft:light_gray_concrete
setblock ~4 ~-15 ~31 minecraft:light_gray_concrete
fill ~5 ~-15 ~31 ~17 ~-15 ~31 minecraft:air
setblock ~18 ~-15 ~31 minecraft:light_gray_concrete
fill ~19 ~-15 ~31 ~21 ~-15 ~31 minecraft:air
setblock ~22 ~-15 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-15 ~31 ~45 ~-15 ~31 minecraft:air
setblock ~46 ~-15 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-15 ~31 ~49 ~-15 ~31 minecraft:air
setblock ~50 ~-15 ~31 minecraft:light_gray_concrete
fill ~51 ~-15 ~31 ~63 ~-15 ~31 minecraft:air
setblock ~64 ~-15 ~31 minecraft:light_gray_concrete
fill ~4 ~-15 ~32 ~21 ~-15 ~32 minecraft:light_gray_concrete
setblock ~22 ~-15 ~32 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-15 ~32 ~32 ~-15 ~32 minecraft:air
fill ~33 ~-15 ~32 ~35 ~-15 ~32 minecraft:glass
fill ~36 ~-15 ~32 ~45 ~-15 ~32 minecraft:air
setblock ~46 ~-15 ~32 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-15 ~32 ~64 ~-15 ~32 minecraft:light_gray_concrete
setblock ~4 ~-15 ~33 minecraft:light_gray_concrete
fill ~5 ~-15 ~33 ~21 ~-15 ~33 minecraft:air
setblock ~22 ~-15 ~33 minecraft:smooth_quartz
fill ~23 ~-15 ~33 ~32 ~-15 ~33 minecraft:air
setblock ~33 ~-15 ~33 minecraft:glass
setblock ~34 ~-15 ~33 minecraft:air
setblock ~35 ~-15 ~33 minecraft:glass
fill ~36 ~-15 ~33 ~45 ~-15 ~33 minecraft:air
setblock ~46 ~-15 ~33 minecraft:smooth_quartz
fill ~47 ~-15 ~33 ~63 ~-15 ~33 minecraft:air
setblock ~64 ~-15 ~33 minecraft:light_gray_concrete
setblock ~4 ~-15 ~34 minecraft:light_gray_concrete
fill ~5 ~-15 ~34 ~20 ~-15 ~34 minecraft:air
setblock ~21 ~-15 ~34 minecraft:smooth_quartz
fill ~22 ~-15 ~34 ~32 ~-15 ~34 minecraft:air
fill ~33 ~-15 ~34 ~35 ~-15 ~34 minecraft:glass
fill ~36 ~-15 ~34 ~46 ~-15 ~34 minecraft:air
setblock ~47 ~-15 ~34 minecraft:smooth_quartz
fill ~48 ~-15 ~34 ~63 ~-15 ~34 minecraft:air
setblock ~64 ~-15 ~34 minecraft:light_gray_concrete
setblock ~4 ~-15 ~35 minecraft:light_gray_concrete
fill ~5 ~-15 ~35 ~21 ~-15 ~35 minecraft:air
setblock ~22 ~-15 ~35 minecraft:smooth_quartz
fill ~23 ~-15 ~35 ~32 ~-15 ~35 minecraft:air
setblock ~33 ~-15 ~35 minecraft:glass
setblock ~34 ~-15 ~35 minecraft:air
setblock ~35 ~-15 ~35 minecraft:glass
fill ~36 ~-15 ~35 ~45 ~-15 ~35 minecraft:air
setblock ~46 ~-15 ~35 minecraft:smooth_quartz
fill ~47 ~-15 ~35 ~63 ~-15 ~35 minecraft:air
setblock ~64 ~-15 ~35 minecraft:light_gray_concrete
fill ~4 ~-15 ~36 ~21 ~-15 ~36 minecraft:light_gray_concrete
setblock ~22 ~-15 ~36 minecraft:glass_pane[north=true,south=true,west=true]
fill ~23 ~-15 ~36 ~32 ~-15 ~36 minecraft:air
fill ~33 ~-15 ~36 ~35 ~-15 ~36 minecraft:glass
fill ~36 ~-15 ~36 ~45 ~-15 ~36 minecraft:air
setblock ~46 ~-15 ~36 minecraft:glass_pane[north=true,east=true,south=true]
fill ~47 ~-15 ~36 ~64 ~-15 ~36 minecraft:light_gray_concrete
setblock ~4 ~-15 ~37 minecraft:light_gray_concrete
fill ~5 ~-15 ~37 ~7 ~-15 ~37 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~8 ~-15 ~37 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-15 ~37 ~17 ~-15 ~37 minecraft:air
setblock ~18 ~-15 ~37 minecraft:light_gray_concrete
fill ~19 ~-15 ~37 ~21 ~-15 ~37 minecraft:air
setblock ~22 ~-15 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-15 ~37 ~45 ~-15 ~37 minecraft:air
setblock ~46 ~-15 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-15 ~37 ~49 ~-15 ~37 minecraft:air
setblock ~50 ~-15 ~37 minecraft:light_gray_concrete
fill ~51 ~-15 ~37 ~63 ~-15 ~37 minecraft:air
setblock ~64 ~-15 ~37 minecraft:light_gray_concrete
setblock ~4 ~-15 ~38 minecraft:light_gray_concrete
fill ~5 ~-15 ~38 ~7 ~-15 ~38 minecraft:air
setblock ~8 ~-15 ~38 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~38 ~17 ~-15 ~38 minecraft:air
setblock ~18 ~-15 ~38 minecraft:light_gray_concrete
fill ~19 ~-15 ~38 ~21 ~-15 ~38 minecraft:air
setblock ~22 ~-15 ~38 minecraft:quartz_pillar
setblock ~23 ~-15 ~38 minecraft:air
setblock ~24 ~-15 ~38 minecraft:quartz_pillar
fill ~25 ~-15 ~38 ~43 ~-15 ~38 minecraft:air
setblock ~44 ~-15 ~38 minecraft:quartz_pillar
setblock ~45 ~-15 ~38 minecraft:air
setblock ~46 ~-15 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-15 ~38 ~49 ~-15 ~38 minecraft:air
setblock ~50 ~-15 ~38 minecraft:light_gray_concrete
fill ~51 ~-15 ~38 ~63 ~-15 ~38 minecraft:air
setblock ~64 ~-15 ~38 minecraft:light_gray_concrete
setblock ~4 ~-15 ~39 minecraft:light_gray_concrete
fill ~5 ~-15 ~39 ~7 ~-15 ~39 minecraft:air
setblock ~8 ~-15 ~39 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~39 ~17 ~-15 ~39 minecraft:air
setblock ~18 ~-15 ~39 minecraft:light_gray_concrete
fill ~19 ~-15 ~39 ~21 ~-15 ~39 minecraft:air
setblock ~22 ~-15 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-15 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-15 ~39 ~44 ~-15 ~39 minecraft:air
fill ~45 ~-15 ~39 ~46 ~-15 ~39 minecraft:quartz_pillar
fill ~47 ~-15 ~39 ~49 ~-15 ~39 minecraft:air
setblock ~50 ~-15 ~39 minecraft:light_gray_concrete
fill ~51 ~-15 ~39 ~63 ~-15 ~39 minecraft:air
setblock ~64 ~-15 ~39 minecraft:light_gray_concrete
setblock ~4 ~-15 ~40 minecraft:light_gray_concrete
fill ~5 ~-15 ~40 ~7 ~-15 ~40 minecraft:air
setblock ~8 ~-15 ~40 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~40 ~17 ~-15 ~40 minecraft:air
setblock ~18 ~-15 ~40 minecraft:light_gray_concrete
fill ~19 ~-15 ~40 ~22 ~-15 ~40 minecraft:air
setblock ~23 ~-15 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-15 ~40 ~44 ~-15 ~40 minecraft:air
setblock ~45 ~-15 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-15 ~40 ~49 ~-15 ~40 minecraft:air
setblock ~50 ~-15 ~40 minecraft:light_gray_concrete
fill ~51 ~-15 ~40 ~63 ~-15 ~40 minecraft:air
setblock ~64 ~-15 ~40 minecraft:light_gray_concrete
setblock ~4 ~-15 ~41 minecraft:light_gray_concrete
fill ~5 ~-15 ~41 ~7 ~-15 ~41 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-15 ~41 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-15 ~41 ~17 ~-15 ~41 minecraft:air
setblock ~18 ~-15 ~41 minecraft:light_gray_concrete
fill ~19 ~-15 ~41 ~23 ~-15 ~41 minecraft:air
setblock ~24 ~-15 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-15 ~41 ~43 ~-15 ~41 minecraft:air
setblock ~44 ~-15 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-15 ~41 ~49 ~-15 ~41 minecraft:air
setblock ~50 ~-15 ~41 minecraft:light_gray_concrete
fill ~51 ~-15 ~41 ~63 ~-15 ~41 minecraft:air
setblock ~64 ~-15 ~41 minecraft:light_gray_concrete
setblock ~4 ~-15 ~42 minecraft:light_gray_concrete
fill ~5 ~-15 ~42 ~7 ~-15 ~42 minecraft:air
setblock ~8 ~-15 ~42 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~42 ~17 ~-15 ~42 minecraft:air
setblock ~18 ~-15 ~42 minecraft:light_gray_concrete
fill ~19 ~-15 ~42 ~23 ~-15 ~42 minecraft:air
setblock ~24 ~-15 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-15 ~42 minecraft:quartz_pillar
fill ~26 ~-15 ~42 ~42 ~-15 ~42 minecraft:air
setblock ~43 ~-15 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-15 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-15 ~42 ~49 ~-15 ~42 minecraft:air
setblock ~50 ~-15 ~42 minecraft:light_gray_concrete
fill ~51 ~-15 ~42 ~63 ~-15 ~42 minecraft:air
setblock ~64 ~-15 ~42 minecraft:light_gray_concrete
setblock ~4 ~-15 ~43 minecraft:light_gray_concrete
fill ~5 ~-15 ~43 ~7 ~-15 ~43 minecraft:air
setblock ~8 ~-15 ~43 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~43 ~17 ~-15 ~43 minecraft:air
setblock ~18 ~-15 ~43 minecraft:light_gray_concrete
fill ~19 ~-15 ~43 ~24 ~-15 ~43 minecraft:air
setblock ~25 ~-15 ~43 minecraft:quartz_pillar
setblock ~26 ~-15 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-15 ~43 ~41 ~-15 ~43 minecraft:air
fill ~42 ~-15 ~43 ~43 ~-15 ~43 minecraft:quartz_pillar
fill ~44 ~-15 ~43 ~49 ~-15 ~43 minecraft:air
setblock ~50 ~-15 ~43 minecraft:light_gray_concrete
fill ~51 ~-15 ~43 ~63 ~-15 ~43 minecraft:air
setblock ~64 ~-15 ~43 minecraft:light_gray_concrete
setblock ~4 ~-15 ~44 minecraft:light_gray_concrete
fill ~5 ~-15 ~44 ~7 ~-15 ~44 minecraft:air
setblock ~8 ~-15 ~44 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~44 ~17 ~-15 ~44 minecraft:air
setblock ~18 ~-15 ~44 minecraft:light_gray_concrete
fill ~19 ~-15 ~44 ~25 ~-15 ~44 minecraft:air
setblock ~26 ~-15 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-15 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-15 ~44 ~29 ~-15 ~44 minecraft:air
setblock ~30 ~-15 ~44 minecraft:quartz_pillar
fill ~31 ~-15 ~44 ~37 ~-15 ~44 minecraft:air
setblock ~38 ~-15 ~44 minecraft:quartz_pillar
fill ~39 ~-15 ~44 ~40 ~-15 ~44 minecraft:air
setblock ~41 ~-15 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-15 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-15 ~44 ~49 ~-15 ~44 minecraft:air
setblock ~50 ~-15 ~44 minecraft:light_gray_concrete
fill ~51 ~-15 ~44 ~63 ~-15 ~44 minecraft:air
setblock ~64 ~-15 ~44 minecraft:light_gray_concrete
setblock ~4 ~-15 ~45 minecraft:light_gray_concrete
fill ~5 ~-15 ~45 ~7 ~-15 ~45 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-15 ~45 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-15 ~45 ~17 ~-15 ~45 minecraft:air
setblock ~18 ~-15 ~45 minecraft:light_gray_concrete
fill ~19 ~-15 ~45 ~27 ~-15 ~45 minecraft:air
setblock ~28 ~-15 ~45 minecraft:smooth_quartz
setblock ~29 ~-15 ~45 minecraft:quartz_pillar
fill ~30 ~-15 ~45 ~38 ~-15 ~45 minecraft:air
setblock ~39 ~-15 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-15 ~45 minecraft:smooth_quartz
fill ~41 ~-15 ~45 ~49 ~-15 ~45 minecraft:air
setblock ~50 ~-15 ~45 minecraft:light_gray_concrete
fill ~51 ~-15 ~45 ~63 ~-15 ~45 minecraft:air
setblock ~64 ~-15 ~45 minecraft:light_gray_concrete
setblock ~4 ~-15 ~46 minecraft:light_gray_concrete
fill ~5 ~-15 ~46 ~7 ~-15 ~46 minecraft:air
setblock ~8 ~-15 ~46 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~46 ~17 ~-15 ~46 minecraft:air
setblock ~18 ~-15 ~46 minecraft:light_gray_concrete
fill ~19 ~-15 ~46 ~28 ~-15 ~46 minecraft:air
setblock ~29 ~-15 ~46 minecraft:quartz_pillar
fill ~30 ~-15 ~46 ~31 ~-15 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-15 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~33 ~-15 ~46 minecraft:smooth_quartz
setblock ~34 ~-15 ~46 minecraft:air
setblock ~35 ~-15 ~46 minecraft:smooth_quartz
setblock ~36 ~-15 ~46 minecraft:glass_pane[east=true,south=true,west=true]
setblock ~37 ~-15 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-15 ~46 minecraft:quartz_pillar
setblock ~39 ~-15 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-15 ~46 ~49 ~-15 ~46 minecraft:air
setblock ~50 ~-15 ~46 minecraft:light_gray_concrete
fill ~51 ~-15 ~46 ~63 ~-15 ~46 minecraft:air
setblock ~64 ~-15 ~46 minecraft:light_gray_concrete
setblock ~4 ~-15 ~47 minecraft:light_gray_concrete
fill ~5 ~-15 ~47 ~7 ~-15 ~47 minecraft:air
setblock ~8 ~-15 ~47 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~47 ~17 ~-15 ~47 minecraft:air
setblock ~18 ~-15 ~47 minecraft:light_gray_concrete
fill ~19 ~-15 ~47 ~31 ~-15 ~47 minecraft:air
setblock ~32 ~-15 ~47 minecraft:light_gray_concrete
setblock ~33 ~-15 ~47 minecraft:air
setblock ~34 ~-15 ~47 minecraft:smooth_quartz
setblock ~35 ~-15 ~47 minecraft:air
setblock ~36 ~-15 ~47 minecraft:light_gray_concrete
fill ~37 ~-15 ~47 ~49 ~-15 ~47 minecraft:air
setblock ~50 ~-15 ~47 minecraft:light_gray_concrete
fill ~51 ~-15 ~47 ~63 ~-15 ~47 minecraft:air
setblock ~64 ~-15 ~47 minecraft:light_gray_concrete
setblock ~4 ~-15 ~48 minecraft:light_gray_concrete
fill ~5 ~-15 ~48 ~7 ~-15 ~48 minecraft:air
setblock ~8 ~-15 ~48 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-15 ~48 ~17 ~-15 ~48 minecraft:air
setblock ~18 ~-15 ~48 minecraft:light_gray_concrete
fill ~19 ~-15 ~48 ~31 ~-15 ~48 minecraft:air
setblock ~32 ~-15 ~48 minecraft:light_gray_concrete
fill ~33 ~-15 ~48 ~35 ~-15 ~48 minecraft:air
setblock ~36 ~-15 ~48 minecraft:light_gray_concrete
fill ~37 ~-15 ~48 ~49 ~-15 ~48 minecraft:air
setblock ~50 ~-15 ~48 minecraft:light_gray_concrete
fill ~51 ~-15 ~48 ~63 ~-15 ~48 minecraft:air
setblock ~64 ~-15 ~48 minecraft:light_gray_concrete
setblock ~4 ~-15 ~49 minecraft:light_gray_concrete
fill ~5 ~-15 ~49 ~7 ~-15 ~49 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~8 ~-15 ~49 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-15 ~49 ~17 ~-15 ~49 minecraft:air
setblock ~18 ~-15 ~49 minecraft:light_gray_concrete
fill ~19 ~-15 ~49 ~31 ~-15 ~49 minecraft:air
setblock ~32 ~-15 ~49 minecraft:light_gray_concrete
fill ~33 ~-15 ~49 ~35 ~-15 ~49 minecraft:air
setblock ~36 ~-15 ~49 minecraft:light_gray_concrete
fill ~37 ~-15 ~49 ~49 ~-15 ~49 minecraft:air
setblock ~50 ~-15 ~49 minecraft:light_gray_concrete
fill ~51 ~-15 ~49 ~63 ~-15 ~49 minecraft:air
setblock ~64 ~-15 ~49 minecraft:light_gray_concrete
fill ~4 ~-15 ~50 ~32 ~-15 ~50 minecraft:light_gray_concrete
fill ~33 ~-15 ~50 ~35 ~-15 ~50 minecraft:air
fill ~36 ~-15 ~50 ~64 ~-15 ~50 minecraft:light_gray_concrete
setblock ~4 ~-15 ~51 minecraft:light_gray_concrete
fill ~5 ~-15 ~51 ~17 ~-15 ~51 minecraft:air
setblock ~18 ~-15 ~51 minecraft:light_gray_concrete
fill ~19 ~-15 ~51 ~31 ~-15 ~51 minecraft:air
setblock ~32 ~-15 ~51 minecraft:light_gray_concrete
fill ~33 ~-15 ~51 ~35 ~-15 ~51 minecraft:air
setblock ~36 ~-15 ~51 minecraft:light_gray_concrete
fill ~37 ~-15 ~51 ~49 ~-15 ~51 minecraft:air
setblock ~50 ~-15 ~51 minecraft:light_gray_concrete
fill ~51 ~-15 ~51 ~63 ~-15 ~51 minecraft:air
setblock ~64 ~-15 ~51 minecraft:light_gray_concrete
setblock ~4 ~-15 ~52 minecraft:light_gray_concrete
fill ~5 ~-15 ~52 ~17 ~-15 ~52 minecraft:air
setblock ~18 ~-15 ~52 minecraft:light_gray_concrete
fill ~19 ~-15 ~52 ~31 ~-15 ~52 minecraft:air
setblock ~32 ~-15 ~52 minecraft:light_gray_concrete
fill ~33 ~-15 ~52 ~35 ~-15 ~52 minecraft:air
setblock ~36 ~-15 ~52 minecraft:light_gray_concrete
fill ~37 ~-15 ~52 ~49 ~-15 ~52 minecraft:air
setblock ~50 ~-15 ~52 minecraft:light_gray_concrete
fill ~51 ~-15 ~52 ~63 ~-15 ~52 minecraft:air
setblock ~64 ~-15 ~52 minecraft:light_gray_concrete
setblock ~4 ~-15 ~53 minecraft:light_gray_concrete
fill ~5 ~-15 ~53 ~17 ~-15 ~53 minecraft:air
setblock ~18 ~-15 ~53 minecraft:light_gray_concrete
fill ~19 ~-15 ~53 ~31 ~-15 ~53 minecraft:air
setblock ~32 ~-15 ~53 minecraft:light_gray_concrete
fill ~33 ~-15 ~53 ~35 ~-15 ~53 minecraft:air
setblock ~36 ~-15 ~53 minecraft:light_gray_concrete
fill ~37 ~-15 ~53 ~49 ~-15 ~53 minecraft:air
setblock ~50 ~-15 ~53 minecraft:light_gray_concrete
fill ~51 ~-15 ~53 ~63 ~-15 ~53 minecraft:air
setblock ~64 ~-15 ~53 minecraft:light_gray_concrete
setblock ~4 ~-15 ~54 minecraft:light_gray_concrete
fill ~5 ~-15 ~54 ~17 ~-15 ~54 minecraft:air
setblock ~18 ~-15 ~54 minecraft:light_gray_concrete
fill ~19 ~-15 ~54 ~31 ~-15 ~54 minecraft:air
setblock ~32 ~-15 ~54 minecraft:light_gray_concrete
fill ~33 ~-15 ~54 ~35 ~-15 ~54 minecraft:air
setblock ~36 ~-15 ~54 minecraft:light_gray_concrete
fill ~37 ~-15 ~54 ~49 ~-15 ~54 minecraft:air
setblock ~50 ~-15 ~54 minecraft:light_gray_concrete
fill ~51 ~-15 ~54 ~63 ~-15 ~54 minecraft:air
setblock ~64 ~-15 ~54 minecraft:light_gray_concrete
setblock ~4 ~-15 ~55 minecraft:light_gray_concrete
fill ~5 ~-15 ~55 ~17 ~-15 ~55 minecraft:air
setblock ~18 ~-15 ~55 minecraft:light_gray_concrete
fill ~19 ~-15 ~55 ~31 ~-15 ~55 minecraft:air
setblock ~32 ~-15 ~55 minecraft:light_gray_concrete
fill ~33 ~-15 ~55 ~35 ~-15 ~55 minecraft:air
setblock ~36 ~-15 ~55 minecraft:light_gray_concrete
fill ~37 ~-15 ~55 ~49 ~-15 ~55 minecraft:air
setblock ~50 ~-15 ~55 minecraft:light_gray_concrete
fill ~51 ~-15 ~55 ~63 ~-15 ~55 minecraft:air
setblock ~64 ~-15 ~55 minecraft:light_gray_concrete
setblock ~4 ~-15 ~56 minecraft:light_gray_concrete
fill ~5 ~-15 ~56 ~17 ~-15 ~56 minecraft:air
setblock ~18 ~-15 ~56 minecraft:light_gray_concrete
fill ~19 ~-15 ~56 ~31 ~-15 ~56 minecraft:air
setblock ~32 ~-15 ~56 minecraft:light_gray_concrete
fill ~33 ~-15 ~56 ~35 ~-15 ~56 minecraft:air
setblock ~36 ~-15 ~56 minecraft:light_gray_concrete
fill ~37 ~-15 ~56 ~49 ~-15 ~56 minecraft:air
setblock ~50 ~-15 ~56 minecraft:light_gray_concrete
fill ~51 ~-15 ~56 ~63 ~-15 ~56 minecraft:air
setblock ~64 ~-15 ~56 minecraft:light_gray_concrete
setblock ~4 ~-15 ~57 minecraft:light_gray_concrete
fill ~5 ~-15 ~57 ~17 ~-15 ~57 minecraft:air
setblock ~18 ~-15 ~57 minecraft:light_gray_concrete
fill ~19 ~-15 ~57 ~31 ~-15 ~57 minecraft:air
setblock ~32 ~-15 ~57 minecraft:light_gray_concrete
fill ~33 ~-15 ~57 ~35 ~-15 ~57 minecraft:air
setblock ~36 ~-15 ~57 minecraft:light_gray_concrete
fill ~37 ~-15 ~57 ~49 ~-15 ~57 minecraft:air
setblock ~50 ~-15 ~57 minecraft:light_gray_concrete
fill ~51 ~-15 ~57 ~63 ~-15 ~57 minecraft:air
setblock ~64 ~-15 ~57 minecraft:light_gray_concrete
setblock ~4 ~-15 ~58 minecraft:light_gray_concrete
fill ~5 ~-15 ~58 ~17 ~-15 ~58 minecraft:air
setblock ~18 ~-15 ~58 minecraft:light_gray_concrete
fill ~19 ~-15 ~58 ~31 ~-15 ~58 minecraft:air
setblock ~32 ~-15 ~58 minecraft:light_gray_concrete
fill ~33 ~-15 ~58 ~35 ~-15 ~58 minecraft:air
setblock ~36 ~-15 ~58 minecraft:light_gray_concrete
fill ~37 ~-15 ~58 ~49 ~-15 ~58 minecraft:air
setblock ~50 ~-15 ~58 minecraft:light_gray_concrete
fill ~51 ~-15 ~58 ~63 ~-15 ~58 minecraft:air
setblock ~64 ~-15 ~58 minecraft:light_gray_concrete
setblock ~4 ~-15 ~59 minecraft:light_gray_concrete
fill ~5 ~-15 ~59 ~17 ~-15 ~59 minecraft:air
setblock ~18 ~-15 ~59 minecraft:light_gray_concrete
fill ~19 ~-15 ~59 ~31 ~-15 ~59 minecraft:air
setblock ~32 ~-15 ~59 minecraft:light_gray_concrete
fill ~33 ~-15 ~59 ~35 ~-15 ~59 minecraft:air
setblock ~36 ~-15 ~59 minecraft:light_gray_concrete
fill ~37 ~-15 ~59 ~49 ~-15 ~59 minecraft:air
setblock ~50 ~-15 ~59 minecraft:light_gray_concrete
fill ~51 ~-15 ~59 ~63 ~-15 ~59 minecraft:air
setblock ~64 ~-15 ~59 minecraft:light_gray_concrete
setblock ~4 ~-15 ~60 minecraft:light_gray_concrete
fill ~5 ~-15 ~60 ~17 ~-15 ~60 minecraft:air
setblock ~18 ~-15 ~60 minecraft:light_gray_concrete
fill ~19 ~-15 ~60 ~31 ~-15 ~60 minecraft:air
setblock ~32 ~-15 ~60 minecraft:light_gray_concrete
fill ~33 ~-15 ~60 ~35 ~-15 ~60 minecraft:air
setblock ~36 ~-15 ~60 minecraft:light_gray_concrete
fill ~37 ~-15 ~60 ~49 ~-15 ~60 minecraft:air
setblock ~50 ~-15 ~60 minecraft:light_gray_concrete
fill ~51 ~-15 ~60 ~63 ~-15 ~60 minecraft:air
setblock ~64 ~-15 ~60 minecraft:light_gray_concrete
setblock ~4 ~-15 ~61 minecraft:light_gray_concrete
fill ~5 ~-15 ~61 ~17 ~-15 ~61 minecraft:air
setblock ~18 ~-15 ~61 minecraft:light_gray_concrete
fill ~19 ~-15 ~61 ~31 ~-15 ~61 minecraft:air
setblock ~32 ~-15 ~61 minecraft:light_gray_concrete
fill ~33 ~-15 ~61 ~35 ~-15 ~61 minecraft:air
setblock ~36 ~-15 ~61 minecraft:light_gray_concrete
fill ~37 ~-15 ~61 ~49 ~-15 ~61 minecraft:air
setblock ~50 ~-15 ~61 minecraft:light_gray_concrete
fill ~51 ~-15 ~61 ~63 ~-15 ~61 minecraft:air
setblock ~64 ~-15 ~61 minecraft:light_gray_concrete
setblock ~4 ~-15 ~62 minecraft:light_gray_concrete
fill ~5 ~-15 ~62 ~17 ~-15 ~62 minecraft:air
setblock ~18 ~-15 ~62 minecraft:light_gray_concrete
fill ~19 ~-15 ~62 ~31 ~-15 ~62 minecraft:air
setblock ~32 ~-15 ~62 minecraft:light_gray_concrete
fill ~33 ~-15 ~62 ~35 ~-15 ~62 minecraft:air
setblock ~36 ~-15 ~62 minecraft:light_gray_concrete
fill ~37 ~-15 ~62 ~49 ~-15 ~62 minecraft:air
setblock ~50 ~-15 ~62 minecraft:light_gray_concrete
fill ~51 ~-15 ~62 ~63 ~-15 ~62 minecraft:air
setblock ~64 ~-15 ~62 minecraft:light_gray_concrete
setblock ~4 ~-15 ~63 minecraft:light_gray_concrete
fill ~5 ~-15 ~63 ~17 ~-15 ~63 minecraft:air
setblock ~18 ~-15 ~63 minecraft:light_gray_concrete
fill ~19 ~-15 ~63 ~31 ~-15 ~63 minecraft:air
setblock ~32 ~-15 ~63 minecraft:light_gray_concrete
fill ~33 ~-15 ~63 ~35 ~-15 ~63 minecraft:air
setblock ~36 ~-15 ~63 minecraft:light_gray_concrete
fill ~37 ~-15 ~63 ~49 ~-15 ~63 minecraft:air
setblock ~50 ~-15 ~63 minecraft:light_gray_concrete
fill ~51 ~-15 ~63 ~63 ~-15 ~63 minecraft:air
setblock ~64 ~-15 ~63 minecraft:light_gray_concrete
fill ~4 ~-15 ~64 ~64 ~-15 ~64 minecraft:light_gray_concrete
fill ~32 ~-15 ~66 ~36 ~-15 ~66 minecraft:polished_andesite
setblock ~32 ~-15 ~67 minecraft:polished_andesite
fill ~33 ~-15 ~67 ~35 ~-15 ~67 minecraft:air
setblock ~36 ~-15 ~67 minecraft:polished_andesite
setblock ~32 ~-15 ~68 minecraft:polished_andesite
setblock ~33 ~-15 ~68 minecraft:air
setblock ~34 ~-15 ~68 minecraft:quartz_pillar
setblock ~35 ~-15 ~68 minecraft:air
setblock ~36 ~-15 ~68 minecraft:polished_andesite
setblock ~32 ~-15 ~69 minecraft:polished_andesite
setblock ~33 ~-15 ~69 minecraft:quartz_stairs[facing=north,half=bottom]
fill ~34 ~-15 ~69 ~35 ~-15 ~69 minecraft:air
setblock ~36 ~-15 ~69 minecraft:polished_andesite
fill ~32 ~-15 ~70 ~36 ~-15 ~70 minecraft:polished_andesite
fill ~4 ~-14 ~4 ~64 ~-14 ~4 minecraft:light_gray_concrete
setblock ~4 ~-14 ~5 minecraft:light_gray_concrete
fill ~5 ~-14 ~5 ~17 ~-14 ~5 minecraft:air
setblock ~18 ~-14 ~5 minecraft:light_gray_concrete
fill ~19 ~-14 ~5 ~31 ~-14 ~5 minecraft:air
setblock ~32 ~-14 ~5 minecraft:light_gray_concrete
fill ~33 ~-14 ~5 ~35 ~-14 ~5 minecraft:air
setblock ~36 ~-14 ~5 minecraft:light_gray_concrete
fill ~37 ~-14 ~5 ~49 ~-14 ~5 minecraft:air
setblock ~50 ~-14 ~5 minecraft:light_gray_concrete
fill ~51 ~-14 ~5 ~63 ~-14 ~5 minecraft:air
setblock ~64 ~-14 ~5 minecraft:light_gray_concrete
setblock ~4 ~-14 ~6 minecraft:light_gray_concrete
fill ~5 ~-14 ~6 ~17 ~-14 ~6 minecraft:air
setblock ~18 ~-14 ~6 minecraft:light_gray_concrete
fill ~19 ~-14 ~6 ~31 ~-14 ~6 minecraft:air
setblock ~32 ~-14 ~6 minecraft:light_gray_concrete
fill ~33 ~-14 ~6 ~35 ~-14 ~6 minecraft:air
setblock ~36 ~-14 ~6 minecraft:light_gray_concrete
fill ~37 ~-14 ~6 ~49 ~-14 ~6 minecraft:air
setblock ~50 ~-14 ~6 minecraft:light_gray_concrete
fill ~51 ~-14 ~6 ~63 ~-14 ~6 minecraft:air
setblock ~64 ~-14 ~6 minecraft:light_gray_concrete
setblock ~4 ~-14 ~7 minecraft:light_gray_concrete
fill ~5 ~-14 ~7 ~17 ~-14 ~7 minecraft:air
setblock ~18 ~-14 ~7 minecraft:light_gray_concrete
fill ~19 ~-14 ~7 ~31 ~-14 ~7 minecraft:air
setblock ~32 ~-14 ~7 minecraft:light_gray_concrete
fill ~33 ~-14 ~7 ~35 ~-14 ~7 minecraft:air
setblock ~36 ~-14 ~7 minecraft:light_gray_concrete
fill ~37 ~-14 ~7 ~49 ~-14 ~7 minecraft:air
setblock ~50 ~-14 ~7 minecraft:light_gray_concrete
fill ~51 ~-14 ~7 ~63 ~-14 ~7 minecraft:air
setblock ~64 ~-14 ~7 minecraft:light_gray_concrete
setblock ~4 ~-14 ~8 minecraft:light_gray_concrete
fill ~5 ~-14 ~8 ~17 ~-14 ~8 minecraft:air
setblock ~18 ~-14 ~8 minecraft:light_gray_concrete
fill ~19 ~-14 ~8 ~31 ~-14 ~8 minecraft:air
setblock ~32 ~-14 ~8 minecraft:light_gray_concrete
fill ~33 ~-14 ~8 ~35 ~-14 ~8 minecraft:air
setblock ~36 ~-14 ~8 minecraft:light_gray_concrete
fill ~37 ~-14 ~8 ~49 ~-14 ~8 minecraft:air
setblock ~50 ~-14 ~8 minecraft:light_gray_concrete
fill ~51 ~-14 ~8 ~63 ~-14 ~8 minecraft:air
setblock ~64 ~-14 ~8 minecraft:light_gray_concrete
setblock ~4 ~-14 ~9 minecraft:light_gray_concrete
fill ~5 ~-14 ~9 ~17 ~-14 ~9 minecraft:air
setblock ~18 ~-14 ~9 minecraft:light_gray_concrete
fill ~19 ~-14 ~9 ~31 ~-14 ~9 minecraft:air
setblock ~32 ~-14 ~9 minecraft:light_gray_concrete
fill ~33 ~-14 ~9 ~35 ~-14 ~9 minecraft:air
setblock ~36 ~-14 ~9 minecraft:light_gray_concrete
fill ~37 ~-14 ~9 ~49 ~-14 ~9 minecraft:air
setblock ~50 ~-14 ~9 minecraft:light_gray_concrete
fill ~51 ~-14 ~9 ~63 ~-14 ~9 minecraft:air
setblock ~64 ~-14 ~9 minecraft:light_gray_concrete
setblock ~4 ~-14 ~10 minecraft:light_gray_concrete
fill ~5 ~-14 ~10 ~17 ~-14 ~10 minecraft:air
setblock ~18 ~-14 ~10 minecraft:light_gray_concrete
fill ~19 ~-14 ~10 ~31 ~-14 ~10 minecraft:air
setblock ~32 ~-14 ~10 minecraft:light_gray_concrete
fill ~33 ~-14 ~10 ~35 ~-14 ~10 minecraft:air
setblock ~36 ~-14 ~10 minecraft:light_gray_concrete
fill ~37 ~-14 ~10 ~49 ~-14 ~10 minecraft:air
setblock ~50 ~-14 ~10 minecraft:light_gray_concrete
fill ~51 ~-14 ~10 ~63 ~-14 ~10 minecraft:air
setblock ~64 ~-14 ~10 minecraft:light_gray_concrete
setblock ~4 ~-14 ~11 minecraft:light_gray_concrete
fill ~5 ~-14 ~11 ~17 ~-14 ~11 minecraft:air
setblock ~18 ~-14 ~11 minecraft:light_gray_concrete
fill ~19 ~-14 ~11 ~31 ~-14 ~11 minecraft:air
setblock ~32 ~-14 ~11 minecraft:light_gray_concrete
fill ~33 ~-14 ~11 ~35 ~-14 ~11 minecraft:air
setblock ~36 ~-14 ~11 minecraft:light_gray_concrete
fill ~37 ~-14 ~11 ~49 ~-14 ~11 minecraft:air
setblock ~50 ~-14 ~11 minecraft:light_gray_concrete
fill ~51 ~-14 ~11 ~63 ~-14 ~11 minecraft:air
setblock ~64 ~-14 ~11 minecraft:light_gray_concrete
setblock ~4 ~-14 ~12 minecraft:light_gray_concrete
fill ~5 ~-14 ~12 ~17 ~-14 ~12 minecraft:air
setblock ~18 ~-14 ~12 minecraft:light_gray_concrete
fill ~19 ~-14 ~12 ~31 ~-14 ~12 minecraft:air
setblock ~32 ~-14 ~12 minecraft:light_gray_concrete
fill ~33 ~-14 ~12 ~35 ~-14 ~12 minecraft:air
setblock ~36 ~-14 ~12 minecraft:light_gray_concrete
fill ~37 ~-14 ~12 ~49 ~-14 ~12 minecraft:air
setblock ~50 ~-14 ~12 minecraft:light_gray_concrete
fill ~51 ~-14 ~12 ~63 ~-14 ~12 minecraft:air
setblock ~64 ~-14 ~12 minecraft:light_gray_concrete
setblock ~4 ~-14 ~13 minecraft:light_gray_concrete
fill ~5 ~-14 ~13 ~17 ~-14 ~13 minecraft:air
setblock ~18 ~-14 ~13 minecraft:light_gray_concrete
fill ~19 ~-14 ~13 ~31 ~-14 ~13 minecraft:air
setblock ~32 ~-14 ~13 minecraft:light_gray_concrete
fill ~33 ~-14 ~13 ~35 ~-14 ~13 minecraft:air
setblock ~36 ~-14 ~13 minecraft:light_gray_concrete
fill ~37 ~-14 ~13 ~49 ~-14 ~13 minecraft:air
setblock ~50 ~-14 ~13 minecraft:light_gray_concrete
fill ~51 ~-14 ~13 ~63 ~-14 ~13 minecraft:air
setblock ~64 ~-14 ~13 minecraft:light_gray_concrete
setblock ~4 ~-14 ~14 minecraft:light_gray_concrete
fill ~5 ~-14 ~14 ~17 ~-14 ~14 minecraft:air
setblock ~18 ~-14 ~14 minecraft:light_gray_concrete
fill ~19 ~-14 ~14 ~31 ~-14 ~14 minecraft:air
setblock ~32 ~-14 ~14 minecraft:light_gray_concrete
fill ~33 ~-14 ~14 ~35 ~-14 ~14 minecraft:air
setblock ~36 ~-14 ~14 minecraft:light_gray_concrete
fill ~37 ~-14 ~14 ~49 ~-14 ~14 minecraft:air
setblock ~50 ~-14 ~14 minecraft:light_gray_concrete
fill ~51 ~-14 ~14 ~63 ~-14 ~14 minecraft:air
setblock ~64 ~-14 ~14 minecraft:light_gray_concrete
setblock ~4 ~-14 ~15 minecraft:light_gray_concrete
fill ~5 ~-14 ~15 ~17 ~-14 ~15 minecraft:air
setblock ~18 ~-14 ~15 minecraft:light_gray_concrete
fill ~19 ~-14 ~15 ~31 ~-14 ~15 minecraft:air
setblock ~32 ~-14 ~15 minecraft:light_gray_concrete
fill ~33 ~-14 ~15 ~35 ~-14 ~15 minecraft:air
setblock ~36 ~-14 ~15 minecraft:light_gray_concrete
fill ~37 ~-14 ~15 ~49 ~-14 ~15 minecraft:air
setblock ~50 ~-14 ~15 minecraft:light_gray_concrete
fill ~51 ~-14 ~15 ~63 ~-14 ~15 minecraft:air
setblock ~64 ~-14 ~15 minecraft:light_gray_concrete
setblock ~4 ~-14 ~16 minecraft:light_gray_concrete
fill ~5 ~-14 ~16 ~17 ~-14 ~16 minecraft:air
setblock ~18 ~-14 ~16 minecraft:light_gray_concrete
fill ~19 ~-14 ~16 ~31 ~-14 ~16 minecraft:air
setblock ~32 ~-14 ~16 minecraft:light_gray_concrete
fill ~33 ~-14 ~16 ~35 ~-14 ~16 minecraft:air
setblock ~36 ~-14 ~16 minecraft:light_gray_concrete
fill ~37 ~-14 ~16 ~49 ~-14 ~16 minecraft:air
setblock ~50 ~-14 ~16 minecraft:light_gray_concrete
fill ~51 ~-14 ~16 ~63 ~-14 ~16 minecraft:air
setblock ~64 ~-14 ~16 minecraft:light_gray_concrete
setblock ~4 ~-14 ~17 minecraft:light_gray_concrete
fill ~5 ~-14 ~17 ~17 ~-14 ~17 minecraft:air
setblock ~18 ~-14 ~17 minecraft:light_gray_concrete
fill ~19 ~-14 ~17 ~31 ~-14 ~17 minecraft:air
setblock ~32 ~-14 ~17 minecraft:light_gray_concrete
fill ~33 ~-14 ~17 ~35 ~-14 ~17 minecraft:air
setblock ~36 ~-14 ~17 minecraft:light_gray_concrete
fill ~37 ~-14 ~17 ~49 ~-14 ~17 minecraft:air
setblock ~50 ~-14 ~17 minecraft:light_gray_concrete
fill ~51 ~-14 ~17 ~63 ~-14 ~17 minecraft:air
setblock ~64 ~-14 ~17 minecraft:light_gray_concrete
fill ~4 ~-14 ~18 ~32 ~-14 ~18 minecraft:light_gray_concrete
fill ~33 ~-14 ~18 ~35 ~-14 ~18 minecraft:air
fill ~36 ~-14 ~18 ~64 ~-14 ~18 minecraft:light_gray_concrete
setblock ~4 ~-14 ~19 minecraft:light_gray_concrete
fill ~5 ~-14 ~19 ~17 ~-14 ~19 minecraft:air
setblock ~18 ~-14 ~19 minecraft:light_gray_concrete
fill ~19 ~-14 ~19 ~31 ~-14 ~19 minecraft:air
setblock ~32 ~-14 ~19 minecraft:light_gray_concrete
fill ~33 ~-14 ~19 ~35 ~-14 ~19 minecraft:air
setblock ~36 ~-14 ~19 minecraft:light_gray_concrete
fill ~37 ~-14 ~19 ~49 ~-14 ~19 minecraft:air
setblock ~50 ~-14 ~19 minecraft:light_gray_concrete
fill ~51 ~-14 ~19 ~63 ~-14 ~19 minecraft:air
setblock ~64 ~-14 ~19 minecraft:light_gray_concrete
setblock ~4 ~-14 ~20 minecraft:light_gray_concrete
fill ~5 ~-14 ~20 ~17 ~-14 ~20 minecraft:air
setblock ~18 ~-14 ~20 minecraft:light_gray_concrete
fill ~19 ~-14 ~20 ~31 ~-14 ~20 minecraft:air
setblock ~32 ~-14 ~20 minecraft:light_gray_concrete
fill ~33 ~-14 ~20 ~35 ~-14 ~20 minecraft:air
setblock ~36 ~-14 ~20 minecraft:light_gray_concrete
fill ~37 ~-14 ~20 ~49 ~-14 ~20 minecraft:air
setblock ~50 ~-14 ~20 minecraft:light_gray_concrete
fill ~51 ~-14 ~20 ~63 ~-14 ~20 minecraft:air
setblock ~64 ~-14 ~20 minecraft:light_gray_concrete
setblock ~4 ~-14 ~21 minecraft:light_gray_concrete
setblock ~5 ~-14 ~21 minecraft:air
setblock ~6 ~-14 ~21 minecraft:end_rod[facing=down]
fill ~7 ~-14 ~21 ~8 ~-14 ~21 minecraft:air
setblock ~9 ~-14 ~21 minecraft:end_rod[facing=down]
fill ~10 ~-14 ~21 ~11 ~-14 ~21 minecraft:air
setblock ~12 ~-14 ~21 minecraft:end_rod[facing=down]
fill ~13 ~-14 ~21 ~14 ~-14 ~21 minecraft:air
setblock ~15 ~-14 ~21 minecraft:end_rod[facing=down]
fill ~16 ~-14 ~21 ~17 ~-14 ~21 minecraft:air
setblock ~18 ~-14 ~21 minecraft:light_gray_concrete
fill ~19 ~-14 ~21 ~31 ~-14 ~21 minecraft:air
setblock ~32 ~-14 ~21 minecraft:light_gray_concrete
setblock ~33 ~-14 ~21 minecraft:air
setblock ~34 ~-14 ~21 minecraft:smooth_quartz
setblock ~35 ~-14 ~21 minecraft:air
setblock ~36 ~-14 ~21 minecraft:light_gray_concrete
fill ~37 ~-14 ~21 ~49 ~-14 ~21 minecraft:air
setblock ~50 ~-14 ~21 minecraft:light_gray_concrete
fill ~51 ~-14 ~21 ~63 ~-14 ~21 minecraft:air
setblock ~64 ~-14 ~21 minecraft:light_gray_concrete
setblock ~4 ~-14 ~22 minecraft:light_gray_concrete
fill ~5 ~-14 ~22 ~17 ~-14 ~22 minecraft:air
setblock ~18 ~-14 ~22 minecraft:light_gray_concrete
fill ~19 ~-14 ~22 ~28 ~-14 ~22 minecraft:air
fill ~29 ~-14 ~22 ~33 ~-14 ~22 minecraft:smooth_quartz
setblock ~34 ~-14 ~22 minecraft:air
fill ~35 ~-14 ~22 ~39 ~-14 ~22 minecraft:smooth_quartz
fill ~40 ~-14 ~22 ~49 ~-14 ~22 minecraft:air
setblock ~50 ~-14 ~22 minecraft:light_gray_concrete
fill ~51 ~-14 ~22 ~63 ~-14 ~22 minecraft:air
setblock ~64 ~-14 ~22 minecraft:light_gray_concrete
setblock ~4 ~-14 ~23 minecraft:light_gray_concrete
fill ~5 ~-14 ~23 ~17 ~-14 ~23 minecraft:air
setblock ~18 ~-14 ~23 minecraft:light_gray_concrete
fill ~19 ~-14 ~23 ~27 ~-14 ~23 minecraft:air
fill ~28 ~-14 ~23 ~29 ~-14 ~23 minecraft:smooth_quartz
fill ~30 ~-14 ~23 ~38 ~-14 ~23 minecraft:air
fill ~39 ~-14 ~23 ~40 ~-14 ~23 minecraft:smooth_quartz
fill ~41 ~-14 ~23 ~49 ~-14 ~23 minecraft:air
setblock ~50 ~-14 ~23 minecraft:light_gray_concrete
fill ~51 ~-14 ~23 ~63 ~-14 ~23 minecraft:air
setblock ~64 ~-14 ~23 minecraft:light_gray_concrete
setblock ~4 ~-14 ~24 minecraft:light_gray_concrete
setblock ~5 ~-14 ~24 minecraft:air
setblock ~6 ~-14 ~24 minecraft:end_rod[facing=down]
fill ~7 ~-14 ~24 ~8 ~-14 ~24 minecraft:air
setblock ~9 ~-14 ~24 minecraft:end_rod[facing=down]
fill ~10 ~-14 ~24 ~11 ~-14 ~24 minecraft:air
setblock ~12 ~-14 ~24 minecraft:end_rod[facing=down]
fill ~13 ~-14 ~24 ~14 ~-14 ~24 minecraft:air
setblock ~15 ~-14 ~24 minecraft:end_rod[facing=down]
fill ~16 ~-14 ~24 ~17 ~-14 ~24 minecraft:air
setblock ~18 ~-14 ~24 minecraft:light_gray_concrete
fill ~19 ~-14 ~24 ~25 ~-14 ~24 minecraft:air
fill ~26 ~-14 ~24 ~27 ~-14 ~24 minecraft:smooth_quartz
fill ~28 ~-14 ~24 ~29 ~-14 ~24 minecraft:air
setblock ~30 ~-14 ~24 minecraft:chiseled_quartz_block
fill ~31 ~-14 ~24 ~37 ~-14 ~24 minecraft:air
setblock ~38 ~-14 ~24 minecraft:chiseled_quartz_block
fill ~39 ~-14 ~24 ~40 ~-14 ~24 minecraft:air
fill ~41 ~-14 ~24 ~42 ~-14 ~24 minecraft:smooth_quartz
fill ~43 ~-14 ~24 ~49 ~-14 ~24 minecraft:air
setblock ~50 ~-14 ~24 minecraft:light_gray_concrete
fill ~51 ~-14 ~24 ~63 ~-14 ~24 minecraft:air
setblock ~64 ~-14 ~24 minecraft:light_gray_concrete
setblock ~4 ~-14 ~25 minecraft:light_gray_concrete
fill ~5 ~-14 ~25 ~17 ~-14 ~25 minecraft:air
setblock ~18 ~-14 ~25 minecraft:light_gray_concrete
fill ~19 ~-14 ~25 ~24 ~-14 ~25 minecraft:air
fill ~25 ~-14 ~25 ~26 ~-14 ~25 minecraft:smooth_quartz
fill ~27 ~-14 ~25 ~41 ~-14 ~25 minecraft:air
fill ~42 ~-14 ~25 ~43 ~-14 ~25 minecraft:smooth_quartz
fill ~44 ~-14 ~25 ~49 ~-14 ~25 minecraft:air
setblock ~50 ~-14 ~25 minecraft:light_gray_concrete
fill ~51 ~-14 ~25 ~63 ~-14 ~25 minecraft:air
setblock ~64 ~-14 ~25 minecraft:light_gray_concrete
setblock ~4 ~-14 ~26 minecraft:light_gray_concrete
fill ~5 ~-14 ~26 ~17 ~-14 ~26 minecraft:air
setblock ~18 ~-14 ~26 minecraft:light_gray_concrete
fill ~19 ~-14 ~26 ~23 ~-14 ~26 minecraft:air
fill ~24 ~-14 ~26 ~25 ~-14 ~26 minecraft:smooth_quartz
fill ~26 ~-14 ~26 ~42 ~-14 ~26 minecraft:air
fill ~43 ~-14 ~26 ~44 ~-14 ~26 minecraft:smooth_quartz
fill ~45 ~-14 ~26 ~49 ~-14 ~26 minecraft:air
setblock ~50 ~-14 ~26 minecraft:light_gray_concrete
fill ~51 ~-14 ~26 ~63 ~-14 ~26 minecraft:air
setblock ~64 ~-14 ~26 minecraft:light_gray_concrete
setblock ~4 ~-14 ~27 minecraft:light_gray_concrete
setblock ~5 ~-14 ~27 minecraft:air
setblock ~6 ~-14 ~27 minecraft:end_rod[facing=down]
fill ~7 ~-14 ~27 ~8 ~-14 ~27 minecraft:air
setblock ~9 ~-14 ~27 minecraft:end_rod[facing=down]
fill ~10 ~-14 ~27 ~11 ~-14 ~27 minecraft:air
setblock ~12 ~-14 ~27 minecraft:end_rod[facing=down]
fill ~13 ~-14 ~27 ~14 ~-14 ~27 minecraft:air
setblock ~15 ~-14 ~27 minecraft:end_rod[facing=down]
fill ~16 ~-14 ~27 ~17 ~-14 ~27 minecraft:air
setblock ~18 ~-14 ~27 minecraft:light_gray_concrete
fill ~19 ~-14 ~27 ~23 ~-14 ~27 minecraft:air
setblock ~24 ~-14 ~27 minecraft:smooth_quartz
fill ~25 ~-14 ~27 ~43 ~-14 ~27 minecraft:air
setblock ~44 ~-14 ~27 minecraft:smooth_quartz
fill ~45 ~-14 ~27 ~49 ~-14 ~27 minecraft:air
setblock ~50 ~-14 ~27 minecraft:light_gray_concrete
fill ~51 ~-14 ~27 ~63 ~-14 ~27 minecraft:air
setblock ~64 ~-14 ~27 minecraft:light_gray_concrete
setblock ~4 ~-14 ~28 minecraft:light_gray_concrete
fill ~5 ~-14 ~28 ~17 ~-14 ~28 minecraft:air
setblock ~18 ~-14 ~28 minecraft:light_gray_concrete
fill ~19 ~-14 ~28 ~22 ~-14 ~28 minecraft:air
setblock ~23 ~-14 ~28 minecraft:smooth_quartz
fill ~24 ~-14 ~28 ~44 ~-14 ~28 minecraft:air
setblock ~45 ~-14 ~28 minecraft:smooth_quartz
fill ~46 ~-14 ~28 ~49 ~-14 ~28 minecraft:air
setblock ~50 ~-14 ~28 minecraft:light_gray_concrete
fill ~51 ~-14 ~28 ~63 ~-14 ~28 minecraft:air
setblock ~64 ~-14 ~28 minecraft:light_gray_concrete
setblock ~4 ~-14 ~29 minecraft:light_gray_concrete
fill ~5 ~-14 ~29 ~17 ~-14 ~29 minecraft:air
setblock ~18 ~-14 ~29 minecraft:light_gray_concrete
fill ~19 ~-14 ~29 ~21 ~-14 ~29 minecraft:air
fill ~22 ~-14 ~29 ~23 ~-14 ~29 minecraft:smooth_quartz
fill ~24 ~-14 ~29 ~44 ~-14 ~29 minecraft:air
fill ~45 ~-14 ~29 ~46 ~-14 ~29 minecraft:smooth_quartz
fill ~47 ~-14 ~29 ~49 ~-14 ~29 minecraft:air
setblock ~50 ~-14 ~29 minecraft:light_gray_concrete
fill ~51 ~-14 ~29 ~63 ~-14 ~29 minecraft:air
setblock ~64 ~-14 ~29 minecraft:light_gray_concrete
setblock ~4 ~-14 ~30 minecraft:light_gray_concrete
setblock ~5 ~-14 ~30 minecraft:air
setblock ~6 ~-14 ~30 minecraft:end_rod[facing=down]
fill ~7 ~-14 ~30 ~8 ~-14 ~30 minecraft:air
setblock ~9 ~-14 ~30 minecraft:end_rod[facing=down]
fill ~10 ~-14 ~30 ~11 ~-14 ~30 minecraft:air
setblock ~12 ~-14 ~30 minecraft:end_rod[facing=down]
fill ~13 ~-14 ~30 ~14 ~-14 ~30 minecraft:air
setblock ~15 ~-14 ~30 minecraft:end_rod[facing=down]
fill ~16 ~-14 ~30 ~17 ~-14 ~30 minecraft:air
setblock ~18 ~-14 ~30 minecraft:light_gray_concrete
fill ~19 ~-14 ~30 ~21 ~-14 ~30 minecraft:air
setblock ~22 ~-14 ~30 minecraft:smooth_quartz
setblock ~23 ~-14 ~30 minecraft:air
setblock ~24 ~-14 ~30 minecraft:chiseled_quartz_block
fill ~25 ~-14 ~30 ~43 ~-14 ~30 minecraft:air
setblock ~44 ~-14 ~30 minecraft:chiseled_quartz_block
setblock ~45 ~-14 ~30 minecraft:air
setblock ~46 ~-14 ~30 minecraft:smooth_quartz
fill ~47 ~-14 ~30 ~49 ~-14 ~30 minecraft:air
setblock ~50 ~-14 ~30 minecraft:light_gray_concrete
fill ~51 ~-14 ~30 ~63 ~-14 ~30 minecraft:air
setblock ~64 ~-14 ~30 minecraft:light_gray_concrete
setblock ~4 ~-14 ~31 minecraft:light_gray_concrete
fill ~5 ~-14 ~31 ~17 ~-14 ~31 minecraft:air
setblock ~18 ~-14 ~31 minecraft:light_gray_concrete
fill ~19 ~-14 ~31 ~21 ~-14 ~31 minecraft:air
setblock ~22 ~-14 ~31 minecraft:smooth_quartz
fill ~23 ~-14 ~31 ~31 ~-14 ~31 minecraft:air
fill ~32 ~-14 ~31 ~36 ~-14 ~31 minecraft:sea_lantern
fill ~37 ~-14 ~31 ~45 ~-14 ~31 minecraft:air
setblock ~46 ~-14 ~31 minecraft:smooth_quartz
fill ~47 ~-14 ~31 ~49 ~-14 ~31 minecraft:air
setblock ~50 ~-14 ~31 minecraft:light_gray_concrete
fill ~51 ~-14 ~31 ~63 ~-14 ~31 minecraft:air
setblock ~64 ~-14 ~31 minecraft:light_gray_concrete
fill ~4 ~-14 ~32 ~21 ~-14 ~32 minecraft:light_gray_concrete
setblock ~22 ~-14 ~32 minecraft:smooth_quartz
fill ~23 ~-14 ~32 ~31 ~-14 ~32 minecraft:air
setblock ~32 ~-14 ~32 minecraft:sea_lantern
fill ~33 ~-14 ~32 ~35 ~-14 ~32 minecraft:glass
setblock ~36 ~-14 ~32 minecraft:sea_lantern
fill ~37 ~-14 ~32 ~45 ~-14 ~32 minecraft:air
setblock ~46 ~-14 ~32 minecraft:smooth_quartz
fill ~47 ~-14 ~32 ~64 ~-14 ~32 minecraft:light_gray_concrete
setblock ~4 ~-14 ~33 minecraft:light_gray_concrete
fill ~5 ~-14 ~33 ~21 ~-14 ~33 minecraft:air
setblock ~22 ~-14 ~33 minecraft:smooth_quartz
fill ~23 ~-14 ~33 ~31 ~-14 ~33 minecraft:air
setblock ~32 ~-14 ~33 minecraft:sea_lantern
setblock ~33 ~-14 ~33 minecraft:glass
setblock ~34 ~-14 ~33 minecraft:air
setblock ~35 ~-14 ~33 minecraft:glass
setblock ~36 ~-14 ~33 minecraft:sea_lantern
fill ~37 ~-14 ~33 ~45 ~-14 ~33 minecraft:air
setblock ~46 ~-14 ~33 minecraft:smooth_quartz
fill ~47 ~-14 ~33 ~63 ~-14 ~33 minecraft:air
setblock ~64 ~-14 ~33 minecraft:light_gray_concrete
setblock ~4 ~-14 ~34 minecraft:light_gray_concrete
fill ~5 ~-14 ~34 ~20 ~-14 ~34 minecraft:air
setblock ~21 ~-14 ~34 minecraft:smooth_quartz
fill ~22 ~-14 ~34 ~31 ~-14 ~34 minecraft:air
setblock ~32 ~-14 ~34 minecraft:sea_lantern
fill ~33 ~-14 ~34 ~35 ~-14 ~34 minecraft:glass
setblock ~36 ~-14 ~34 minecraft:sea_lantern
fill ~37 ~-14 ~34 ~46 ~-14 ~34 minecraft:air
setblock ~47 ~-14 ~34 minecraft:smooth_quartz
fill ~48 ~-14 ~34 ~63 ~-14 ~34 minecraft:air
setblock ~64 ~-14 ~34 minecraft:light_gray_concrete
setblock ~4 ~-14 ~35 minecraft:light_gray_concrete
fill ~5 ~-14 ~35 ~21 ~-14 ~35 minecraft:air
setblock ~22 ~-14 ~35 minecraft:smooth_quartz
fill ~23 ~-14 ~35 ~31 ~-14 ~35 minecraft:air
setblock ~32 ~-14 ~35 minecraft:sea_lantern
setblock ~33 ~-14 ~35 minecraft:glass
setblock ~34 ~-14 ~35 minecraft:air
setblock ~35 ~-14 ~35 minecraft:glass
setblock ~36 ~-14 ~35 minecraft:sea_lantern
fill ~37 ~-14 ~35 ~45 ~-14 ~35 minecraft:air
setblock ~46 ~-14 ~35 minecraft:smooth_quartz
fill ~47 ~-14 ~35 ~63 ~-14 ~35 minecraft:air
setblock ~64 ~-14 ~35 minecraft:light_gray_concrete
fill ~4 ~-14 ~36 ~21 ~-14 ~36 minecraft:light_gray_concrete
setblock ~22 ~-14 ~36 minecraft:smooth_quartz
fill ~23 ~-14 ~36 ~31 ~-14 ~36 minecraft:air
setblock ~32 ~-14 ~36 minecraft:sea_lantern
fill ~33 ~-14 ~36 ~35 ~-14 ~36 minecraft:glass
setblock ~36 ~-14 ~36 minecraft:sea_lantern
fill ~37 ~-14 ~36 ~45 ~-14 ~36 minecraft:air
setblock ~46 ~-14 ~36 minecraft:smooth_quartz
fill ~47 ~-14 ~36 ~64 ~-14 ~36 minecraft:light_gray_concrete
setblock ~4 ~-14 ~37 minecraft:light_gray_concrete
fill ~5 ~-14 ~37 ~7 ~-14 ~37 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~8 ~-14 ~37 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-14 ~37 ~17 ~-14 ~37 minecraft:air
setblock ~18 ~-14 ~37 minecraft:light_gray_concrete
fill ~19 ~-14 ~37 ~21 ~-14 ~37 minecraft:air
setblock ~22 ~-14 ~37 minecraft:smooth_quartz
fill ~23 ~-14 ~37 ~31 ~-14 ~37 minecraft:air
fill ~32 ~-14 ~37 ~36 ~-14 ~37 minecraft:sea_lantern
fill ~37 ~-14 ~37 ~45 ~-14 ~37 minecraft:air
setblock ~46 ~-14 ~37 minecraft:smooth_quartz
fill ~47 ~-14 ~37 ~49 ~-14 ~37 minecraft:air
setblock ~50 ~-14 ~37 minecraft:light_gray_concrete
fill ~51 ~-14 ~37 ~63 ~-14 ~37 minecraft:air
setblock ~64 ~-14 ~37 minecraft:light_gray_concrete
setblock ~4 ~-14 ~38 minecraft:light_gray_concrete
fill ~5 ~-14 ~38 ~7 ~-14 ~38 minecraft:air
setblock ~8 ~-14 ~38 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~38 ~17 ~-14 ~38 minecraft:air
setblock ~18 ~-14 ~38 minecraft:light_gray_concrete
fill ~19 ~-14 ~38 ~21 ~-14 ~38 minecraft:air
setblock ~22 ~-14 ~38 minecraft:smooth_quartz
setblock ~23 ~-14 ~38 minecraft:air
setblock ~24 ~-14 ~38 minecraft:chiseled_quartz_block
fill ~25 ~-14 ~38 ~43 ~-14 ~38 minecraft:air
setblock ~44 ~-14 ~38 minecraft:chiseled_quartz_block
setblock ~45 ~-14 ~38 minecraft:air
setblock ~46 ~-14 ~38 minecraft:smooth_quartz
fill ~47 ~-14 ~38 ~49 ~-14 ~38 minecraft:air
setblock ~50 ~-14 ~38 minecraft:light_gray_concrete
fill ~51 ~-14 ~38 ~63 ~-14 ~38 minecraft:air
setblock ~64 ~-14 ~38 minecraft:light_gray_concrete
setblock ~4 ~-14 ~39 minecraft:light_gray_concrete
fill ~5 ~-14 ~39 ~7 ~-14 ~39 minecraft:air
setblock ~8 ~-14 ~39 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~39 ~17 ~-14 ~39 minecraft:air
setblock ~18 ~-14 ~39 minecraft:light_gray_concrete
fill ~19 ~-14 ~39 ~21 ~-14 ~39 minecraft:air
fill ~22 ~-14 ~39 ~23 ~-14 ~39 minecraft:smooth_quartz
fill ~24 ~-14 ~39 ~44 ~-14 ~39 minecraft:air
fill ~45 ~-14 ~39 ~46 ~-14 ~39 minecraft:smooth_quartz
fill ~47 ~-14 ~39 ~49 ~-14 ~39 minecraft:air
setblock ~50 ~-14 ~39 minecraft:light_gray_concrete
fill ~51 ~-14 ~39 ~63 ~-14 ~39 minecraft:air
setblock ~64 ~-14 ~39 minecraft:light_gray_concrete
setblock ~4 ~-14 ~40 minecraft:light_gray_concrete
fill ~5 ~-14 ~40 ~7 ~-14 ~40 minecraft:air
setblock ~8 ~-14 ~40 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~40 ~17 ~-14 ~40 minecraft:air
setblock ~18 ~-14 ~40 minecraft:light_gray_concrete
fill ~19 ~-14 ~40 ~22 ~-14 ~40 minecraft:air
setblock ~23 ~-14 ~40 minecraft:smooth_quartz
fill ~24 ~-14 ~40 ~44 ~-14 ~40 minecraft:air
setblock ~45 ~-14 ~40 minecraft:smooth_quartz
fill ~46 ~-14 ~40 ~49 ~-14 ~40 minecraft:air
setblock ~50 ~-14 ~40 minecraft:light_gray_concrete
fill ~51 ~-14 ~40 ~55 ~-14 ~40 minecraft:air
setblock ~56 ~-14 ~40 minecraft:end_rod[facing=down]
fill ~57 ~-14 ~40 ~59 ~-14 ~40 minecraft:air
setblock ~60 ~-14 ~40 minecraft:end_rod[facing=down]
fill ~61 ~-14 ~40 ~63 ~-14 ~40 minecraft:air
setblock ~64 ~-14 ~40 minecraft:light_gray_concrete
setblock ~4 ~-14 ~41 minecraft:light_gray_concrete
fill ~5 ~-14 ~41 ~7 ~-14 ~41 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-14 ~41 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-14 ~41 ~17 ~-14 ~41 minecraft:air
setblock ~18 ~-14 ~41 minecraft:light_gray_concrete
fill ~19 ~-14 ~41 ~23 ~-14 ~41 minecraft:air
setblock ~24 ~-14 ~41 minecraft:smooth_quartz
fill ~25 ~-14 ~41 ~43 ~-14 ~41 minecraft:air
setblock ~44 ~-14 ~41 minecraft:smooth_quartz
fill ~45 ~-14 ~41 ~49 ~-14 ~41 minecraft:air
setblock ~50 ~-14 ~41 minecraft:light_gray_concrete
fill ~51 ~-14 ~41 ~54 ~-14 ~41 minecraft:air
setblock ~55 ~-14 ~41 minecraft:end_rod[facing=down]
fill ~56 ~-14 ~41 ~58 ~-14 ~41 minecraft:air
setblock ~59 ~-14 ~41 minecraft:end_rod[facing=down]
fill ~60 ~-14 ~41 ~63 ~-14 ~41 minecraft:air
setblock ~64 ~-14 ~41 minecraft:light_gray_concrete
setblock ~4 ~-14 ~42 minecraft:light_gray_concrete
fill ~5 ~-14 ~42 ~7 ~-14 ~42 minecraft:air
setblock ~8 ~-14 ~42 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~42 ~17 ~-14 ~42 minecraft:air
setblock ~18 ~-14 ~42 minecraft:light_gray_concrete
fill ~19 ~-14 ~42 ~23 ~-14 ~42 minecraft:air
fill ~24 ~-14 ~42 ~25 ~-14 ~42 minecraft:smooth_quartz
fill ~26 ~-14 ~42 ~42 ~-14 ~42 minecraft:air
fill ~43 ~-14 ~42 ~44 ~-14 ~42 minecraft:smooth_quartz
fill ~45 ~-14 ~42 ~49 ~-14 ~42 minecraft:air
setblock ~50 ~-14 ~42 minecraft:light_gray_concrete
fill ~51 ~-14 ~42 ~53 ~-14 ~42 minecraft:air
setblock ~54 ~-14 ~42 minecraft:end_rod[facing=down]
fill ~55 ~-14 ~42 ~57 ~-14 ~42 minecraft:air
setblock ~58 ~-14 ~42 minecraft:end_rod[facing=down]
fill ~59 ~-14 ~42 ~63 ~-14 ~42 minecraft:air
setblock ~64 ~-14 ~42 minecraft:light_gray_concrete
setblock ~4 ~-14 ~43 minecraft:light_gray_concrete
fill ~5 ~-14 ~43 ~7 ~-14 ~43 minecraft:air
setblock ~8 ~-14 ~43 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~43 ~17 ~-14 ~43 minecraft:air
setblock ~18 ~-14 ~43 minecraft:light_gray_concrete
fill ~19 ~-14 ~43 ~24 ~-14 ~43 minecraft:air
fill ~25 ~-14 ~43 ~26 ~-14 ~43 minecraft:smooth_quartz
fill ~27 ~-14 ~43 ~41 ~-14 ~43 minecraft:air
fill ~42 ~-14 ~43 ~43 ~-14 ~43 minecraft:smooth_quartz
fill ~44 ~-14 ~43 ~49 ~-14 ~43 minecraft:air
setblock ~50 ~-14 ~43 minecraft:light_gray_concrete
fill ~51 ~-14 ~43 ~56 ~-14 ~43 minecraft:air
setblock ~57 ~-14 ~43 minecraft:end_rod[facing=down]
fill ~58 ~-14 ~43 ~63 ~-14 ~43 minecraft:air
setblock ~64 ~-14 ~43 minecraft:light_gray_concrete
setblock ~4 ~-14 ~44 minecraft:light_gray_concrete
fill ~5 ~-14 ~44 ~7 ~-14 ~44 minecraft:air
setblock ~8 ~-14 ~44 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~44 ~17 ~-14 ~44 minecraft:air
setblock ~18 ~-14 ~44 minecraft:light_gray_concrete
fill ~19 ~-14 ~44 ~25 ~-14 ~44 minecraft:air
fill ~26 ~-14 ~44 ~27 ~-14 ~44 minecraft:smooth_quartz
fill ~28 ~-14 ~44 ~29 ~-14 ~44 minecraft:air
setblock ~30 ~-14 ~44 minecraft:chiseled_quartz_block
fill ~31 ~-14 ~44 ~37 ~-14 ~44 minecraft:air
setblock ~38 ~-14 ~44 minecraft:chiseled_quartz_block
fill ~39 ~-14 ~44 ~40 ~-14 ~44 minecraft:air
fill ~41 ~-14 ~44 ~42 ~-14 ~44 minecraft:smooth_quartz
fill ~43 ~-14 ~44 ~49 ~-14 ~44 minecraft:air
setblock ~50 ~-14 ~44 minecraft:light_gray_concrete
fill ~51 ~-14 ~44 ~55 ~-14 ~44 minecraft:air
setblock ~56 ~-14 ~44 minecraft:end_rod[facing=down]
fill ~57 ~-14 ~44 ~59 ~-14 ~44 minecraft:air
setblock ~60 ~-14 ~44 minecraft:end_rod[facing=down]
fill ~61 ~-14 ~44 ~63 ~-14 ~44 minecraft:air
setblock ~64 ~-14 ~44 minecraft:light_gray_concrete
setblock ~4 ~-14 ~45 minecraft:light_gray_concrete
fill ~5 ~-14 ~45 ~7 ~-14 ~45 minecraft:iron_bars[east=true,west=true]
setblock ~8 ~-14 ~45 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-14 ~45 ~17 ~-14 ~45 minecraft:air
setblock ~18 ~-14 ~45 minecraft:light_gray_concrete
fill ~19 ~-14 ~45 ~27 ~-14 ~45 minecraft:air
fill ~28 ~-14 ~45 ~29 ~-14 ~45 minecraft:smooth_quartz
fill ~30 ~-14 ~45 ~38 ~-14 ~45 minecraft:air
fill ~39 ~-14 ~45 ~40 ~-14 ~45 minecraft:smooth_quartz
fill ~41 ~-14 ~45 ~49 ~-14 ~45 minecraft:air
setblock ~50 ~-14 ~45 minecraft:light_gray_concrete
fill ~51 ~-14 ~45 ~54 ~-14 ~45 minecraft:air
setblock ~55 ~-14 ~45 minecraft:end_rod[facing=down]
fill ~56 ~-14 ~45 ~58 ~-14 ~45 minecraft:air
setblock ~59 ~-14 ~45 minecraft:end_rod[facing=down]
fill ~60 ~-14 ~45 ~63 ~-14 ~45 minecraft:air
setblock ~64 ~-14 ~45 minecraft:light_gray_concrete
setblock ~4 ~-14 ~46 minecraft:light_gray_concrete
fill ~5 ~-14 ~46 ~7 ~-14 ~46 minecraft:air
setblock ~8 ~-14 ~46 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~46 ~17 ~-14 ~46 minecraft:air
setblock ~18 ~-14 ~46 minecraft:light_gray_concrete
fill ~19 ~-14 ~46 ~28 ~-14 ~46 minecraft:air
fill ~29 ~-14 ~46 ~33 ~-14 ~46 minecraft:smooth_quartz
setblock ~34 ~-14 ~46 minecraft:air
fill ~35 ~-14 ~46 ~39 ~-14 ~46 minecraft:smooth_quartz
fill ~40 ~-14 ~46 ~49 ~-14 ~46 minecraft:air
setblock ~50 ~-14 ~46 minecraft:light_gray_concrete
fill ~51 ~-14 ~46 ~53 ~-14 ~46 minecraft:air
setblock ~54 ~-14 ~46 minecraft:end_rod[facing=down]
fill ~55 ~-14 ~46 ~57 ~-14 ~46 minecraft:air
setblock ~58 ~-14 ~46 minecraft:end_rod[facing=down]
fill ~59 ~-14 ~46 ~63 ~-14 ~46 minecraft:air
setblock ~64 ~-14 ~46 minecraft:light_gray_concrete
setblock ~4 ~-14 ~47 minecraft:light_gray_concrete
fill ~5 ~-14 ~47 ~7 ~-14 ~47 minecraft:air
setblock ~8 ~-14 ~47 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~47 ~17 ~-14 ~47 minecraft:air
setblock ~18 ~-14 ~47 minecraft:light_gray_concrete
fill ~19 ~-14 ~47 ~31 ~-14 ~47 minecraft:air
setblock ~32 ~-14 ~47 minecraft:light_gray_concrete
setblock ~33 ~-14 ~47 minecraft:air
setblock ~34 ~-14 ~47 minecraft:smooth_quartz
setblock ~35 ~-14 ~47 minecraft:air
setblock ~36 ~-14 ~47 minecraft:light_gray_concrete
fill ~37 ~-14 ~47 ~49 ~-14 ~47 minecraft:air
setblock ~50 ~-14 ~47 minecraft:light_gray_concrete
fill ~51 ~-14 ~47 ~63 ~-14 ~47 minecraft:air
setblock ~64 ~-14 ~47 minecraft:light_gray_concrete
setblock ~4 ~-14 ~48 minecraft:light_gray_concrete
fill ~5 ~-14 ~48 ~7 ~-14 ~48 minecraft:air
setblock ~8 ~-14 ~48 minecraft:iron_bars[north=true,south=true]
fill ~9 ~-14 ~48 ~17 ~-14 ~48 minecraft:air
setblock ~18 ~-14 ~48 minecraft:light_gray_concrete
fill ~19 ~-14 ~48 ~31 ~-14 ~48 minecraft:air
setblock ~32 ~-14 ~48 minecraft:light_gray_concrete
fill ~33 ~-14 ~48 ~35 ~-14 ~48 minecraft:air
setblock ~36 ~-14 ~48 minecraft:light_gray_concrete
fill ~37 ~-14 ~48 ~49 ~-14 ~48 minecraft:air
setblock ~50 ~-14 ~48 minecraft:light_gray_concrete
fill ~51 ~-14 ~48 ~63 ~-14 ~48 minecraft:air
setblock ~64 ~-14 ~48 minecraft:light_gray_concrete
setblock ~4 ~-14 ~49 minecraft:light_gray_concrete
fill ~5 ~-14 ~49 ~7 ~-14 ~49 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~8 ~-14 ~49 minecraft:iron_bars[north=true,south=true,west=true]
fill ~9 ~-14 ~49 ~17 ~-14 ~49 minecraft:air
setblock ~18 ~-14 ~49 minecraft:light_gray_concrete
fill ~19 ~-14 ~49 ~31 ~-14 ~49 minecraft:air
setblock ~32 ~-14 ~49 minecraft:light_gray_concrete
fill ~33 ~-14 ~49 ~35 ~-14 ~49 minecraft:air
setblock ~36 ~-14 ~49 minecraft:light_gray_concrete
fill ~37 ~-14 ~49 ~49 ~-14 ~49 minecraft:air
setblock ~50 ~-14 ~49 minecraft:light_gray_concrete
fill ~51 ~-14 ~49 ~63 ~-14 ~49 minecraft:air
setblock ~64 ~-14 ~49 minecraft:light_gray_concrete
fill ~4 ~-14 ~50 ~32 ~-14 ~50 minecraft:light_gray_concrete
fill ~33 ~-14 ~50 ~35 ~-14 ~50 minecraft:air
fill ~36 ~-14 ~50 ~64 ~-14 ~50 minecraft:light_gray_concrete
setblock ~4 ~-14 ~51 minecraft:light_gray_concrete
fill ~5 ~-14 ~51 ~17 ~-14 ~51 minecraft:air
setblock ~18 ~-14 ~51 minecraft:light_gray_concrete
fill ~19 ~-14 ~51 ~31 ~-14 ~51 minecraft:air
setblock ~32 ~-14 ~51 minecraft:light_gray_concrete
fill ~33 ~-14 ~51 ~35 ~-14 ~51 minecraft:air
setblock ~36 ~-14 ~51 minecraft:light_gray_concrete
fill ~37 ~-14 ~51 ~49 ~-14 ~51 minecraft:air
setblock ~50 ~-14 ~51 minecraft:light_gray_concrete
fill ~51 ~-14 ~51 ~63 ~-14 ~51 minecraft:air
setblock ~64 ~-14 ~51 minecraft:light_gray_concrete
setblock ~4 ~-14 ~52 minecraft:light_gray_concrete
fill ~5 ~-14 ~52 ~17 ~-14 ~52 minecraft:air
setblock ~18 ~-14 ~52 minecraft:light_gray_concrete
fill ~19 ~-14 ~52 ~31 ~-14 ~52 minecraft:air
setblock ~32 ~-14 ~52 minecraft:light_gray_concrete
fill ~33 ~-14 ~52 ~35 ~-14 ~52 minecraft:air
setblock ~36 ~-14 ~52 minecraft:light_gray_concrete
fill ~37 ~-14 ~52 ~49 ~-14 ~52 minecraft:air
setblock ~50 ~-14 ~52 minecraft:light_gray_concrete
fill ~51 ~-14 ~52 ~63 ~-14 ~52 minecraft:air
setblock ~64 ~-14 ~52 minecraft:light_gray_concrete
setblock ~4 ~-14 ~53 minecraft:light_gray_concrete
fill ~5 ~-14 ~53 ~17 ~-14 ~53 minecraft:air
setblock ~18 ~-14 ~53 minecraft:light_gray_concrete
fill ~19 ~-14 ~53 ~31 ~-14 ~53 minecraft:air
setblock ~32 ~-14 ~53 minecraft:light_gray_concrete
fill ~33 ~-14 ~53 ~35 ~-14 ~53 minecraft:air
setblock ~36 ~-14 ~53 minecraft:light_gray_concrete
fill ~37 ~-14 ~53 ~49 ~-14 ~53 minecraft:air
setblock ~50 ~-14 ~53 minecraft:light_gray_concrete
fill ~51 ~-14 ~53 ~63 ~-14 ~53 minecraft:air
setblock ~64 ~-14 ~53 minecraft:light_gray_concrete
setblock ~4 ~-14 ~54 minecraft:light_gray_concrete
fill ~5 ~-14 ~54 ~17 ~-14 ~54 minecraft:air
setblock ~18 ~-14 ~54 minecraft:light_gray_concrete
fill ~19 ~-14 ~54 ~31 ~-14 ~54 minecraft:air
setblock ~32 ~-14 ~54 minecraft:light_gray_concrete
fill ~33 ~-14 ~54 ~35 ~-14 ~54 minecraft:air
setblock ~36 ~-14 ~54 minecraft:light_gray_concrete
fill ~37 ~-14 ~54 ~49 ~-14 ~54 minecraft:air
setblock ~50 ~-14 ~54 minecraft:light_gray_concrete
fill ~51 ~-14 ~54 ~63 ~-14 ~54 minecraft:air
setblock ~64 ~-14 ~54 minecraft:light_gray_concrete
setblock ~4 ~-14 ~55 minecraft:light_gray_concrete
fill ~5 ~-14 ~55 ~17 ~-14 ~55 minecraft:air
setblock ~18 ~-14 ~55 minecraft:light_gray_concrete
fill ~19 ~-14 ~55 ~31 ~-14 ~55 minecraft:air
setblock ~32 ~-14 ~55 minecraft:light_gray_concrete
fill ~33 ~-14 ~55 ~35 ~-14 ~55 minecraft:air
setblock ~36 ~-14 ~55 minecraft:light_gray_concrete
fill ~37 ~-14 ~55 ~49 ~-14 ~55 minecraft:air
setblock ~50 ~-14 ~55 minecraft:light_gray_concrete
fill ~51 ~-14 ~55 ~63 ~-14 ~55 minecraft:air
setblock ~64 ~-14 ~55 minecraft:light_gray_concrete
setblock ~4 ~-14 ~56 minecraft:light_gray_concrete
fill ~5 ~-14 ~56 ~17 ~-14 ~56 minecraft:air
setblock ~18 ~-14 ~56 minecraft:light_gray_concrete
fill ~19 ~-14 ~56 ~31 ~-14 ~56 minecraft:air
setblock ~32 ~-14 ~56 minecraft:light_gray_concrete
fill ~33 ~-14 ~56 ~35 ~-14 ~56 minecraft:air
setblock ~36 ~-14 ~56 minecraft:light_gray_concrete
fill ~37 ~-14 ~56 ~49 ~-14 ~56 minecraft:air
setblock ~50 ~-14 ~56 minecraft:light_gray_concrete
fill ~51 ~-14 ~56 ~63 ~-14 ~56 minecraft:air
setblock ~64 ~-14 ~56 minecraft:light_gray_concrete
setblock ~4 ~-14 ~57 minecraft:light_gray_concrete
fill ~5 ~-14 ~57 ~17 ~-14 ~57 minecraft:air
setblock ~18 ~-14 ~57 minecraft:light_gray_concrete
fill ~19 ~-14 ~57 ~31 ~-14 ~57 minecraft:air
setblock ~32 ~-14 ~57 minecraft:light_gray_concrete
fill ~33 ~-14 ~57 ~35 ~-14 ~57 minecraft:air
setblock ~36 ~-14 ~57 minecraft:light_gray_concrete
fill ~37 ~-14 ~57 ~49 ~-14 ~57 minecraft:air
setblock ~50 ~-14 ~57 minecraft:light_gray_concrete
fill ~51 ~-14 ~57 ~63 ~-14 ~57 minecraft:air
setblock ~64 ~-14 ~57 minecraft:light_gray_concrete
setblock ~4 ~-14 ~58 minecraft:light_gray_concrete
fill ~5 ~-14 ~58 ~17 ~-14 ~58 minecraft:air
setblock ~18 ~-14 ~58 minecraft:light_gray_concrete
fill ~19 ~-14 ~58 ~31 ~-14 ~58 minecraft:air
setblock ~32 ~-14 ~58 minecraft:light_gray_concrete
fill ~33 ~-14 ~58 ~35 ~-14 ~58 minecraft:air
setblock ~36 ~-14 ~58 minecraft:light_gray_concrete
fill ~37 ~-14 ~58 ~49 ~-14 ~58 minecraft:air
setblock ~50 ~-14 ~58 minecraft:light_gray_concrete
fill ~51 ~-14 ~58 ~63 ~-14 ~58 minecraft:air
setblock ~64 ~-14 ~58 minecraft:light_gray_concrete
setblock ~4 ~-14 ~59 minecraft:light_gray_concrete
fill ~5 ~-14 ~59 ~17 ~-14 ~59 minecraft:air
setblock ~18 ~-14 ~59 minecraft:light_gray_concrete
fill ~19 ~-14 ~59 ~31 ~-14 ~59 minecraft:air
setblock ~32 ~-14 ~59 minecraft:light_gray_concrete
fill ~33 ~-14 ~59 ~35 ~-14 ~59 minecraft:air
setblock ~36 ~-14 ~59 minecraft:light_gray_concrete
fill ~37 ~-14 ~59 ~49 ~-14 ~59 minecraft:air
setblock ~50 ~-14 ~59 minecraft:light_gray_concrete
fill ~51 ~-14 ~59 ~63 ~-14 ~59 minecraft:air
setblock ~64 ~-14 ~59 minecraft:light_gray_concrete
setblock ~4 ~-14 ~60 minecraft:light_gray_concrete
fill ~5 ~-14 ~60 ~17 ~-14 ~60 minecraft:air
setblock ~18 ~-14 ~60 minecraft:light_gray_concrete
fill ~19 ~-14 ~60 ~31 ~-14 ~60 minecraft:air
setblock ~32 ~-14 ~60 minecraft:light_gray_concrete
fill ~33 ~-14 ~60 ~35 ~-14 ~60 minecraft:air
setblock ~36 ~-14 ~60 minecraft:light_gray_concrete
fill ~37 ~-14 ~60 ~49 ~-14 ~60 minecraft:air
setblock ~50 ~-14 ~60 minecraft:light_gray_concrete
fill ~51 ~-14 ~60 ~63 ~-14 ~60 minecraft:air
setblock ~64 ~-14 ~60 minecraft:light_gray_concrete
setblock ~4 ~-14 ~61 minecraft:light_gray_concrete
fill ~5 ~-14 ~61 ~17 ~-14 ~61 minecraft:air
setblock ~18 ~-14 ~61 minecraft:light_gray_concrete
fill ~19 ~-14 ~61 ~31 ~-14 ~61 minecraft:air
setblock ~32 ~-14 ~61 minecraft:light_gray_concrete
fill ~33 ~-14 ~61 ~35 ~-14 ~61 minecraft:air
setblock ~36 ~-14 ~61 minecraft:light_gray_concrete
fill ~37 ~-14 ~61 ~49 ~-14 ~61 minecraft:air
setblock ~50 ~-14 ~61 minecraft:light_gray_concrete
fill ~51 ~-14 ~61 ~63 ~-14 ~61 minecraft:air
setblock ~64 ~-14 ~61 minecraft:light_gray_concrete
setblock ~4 ~-14 ~62 minecraft:light_gray_concrete
fill ~5 ~-14 ~62 ~17 ~-14 ~62 minecraft:air
setblock ~18 ~-14 ~62 minecraft:light_gray_concrete
fill ~19 ~-14 ~62 ~31 ~-14 ~62 minecraft:air
setblock ~32 ~-14 ~62 minecraft:light_gray_concrete
fill ~33 ~-14 ~62 ~35 ~-14 ~62 minecraft:air
setblock ~36 ~-14 ~62 minecraft:light_gray_concrete
fill ~37 ~-14 ~62 ~49 ~-14 ~62 minecraft:air
setblock ~50 ~-14 ~62 minecraft:light_gray_concrete
fill ~51 ~-14 ~62 ~63 ~-14 ~62 minecraft:air
setblock ~64 ~-14 ~62 minecraft:light_gray_concrete
setblock ~4 ~-14 ~63 minecraft:light_gray_concrete
fill ~5 ~-14 ~63 ~17 ~-14 ~63 minecraft:air
setblock ~18 ~-14 ~63 minecraft:light_gray_concrete
fill ~19 ~-14 ~63 ~31 ~-14 ~63 minecraft:air
setblock ~32 ~-14 ~63 minecraft:light_gray_concrete
fill ~33 ~-14 ~63 ~35 ~-14 ~63 minecraft:air
setblock ~36 ~-14 ~63 minecraft:light_gray_concrete
fill ~37 ~-14 ~63 ~49 ~-14 ~63 minecraft:air
setblock ~50 ~-14 ~63 minecraft:light_gray_concrete
fill ~51 ~-14 ~63 ~63 ~-14 ~63 minecraft:air
setblock ~64 ~-14 ~63 minecraft:light_gray_concrete
fill ~4 ~-14 ~64 ~64 ~-14 ~64 minecraft:light_gray_concrete
fill ~32 ~-14 ~66 ~36 ~-14 ~66 minecraft:polished_andesite
setblock ~32 ~-14 ~67 minecraft:polished_andesite
fill ~33 ~-14 ~67 ~35 ~-14 ~67 minecraft:air
setblock ~36 ~-14 ~67 minecraft:polished_andesite
setblock ~32 ~-14 ~68 minecraft:polished_andesite
setblock ~33 ~-14 ~68 minecraft:quartz_stairs[facing=north,half=bottom]
setblock ~34 ~-14 ~68 minecraft:quartz_pillar
setblock ~35 ~-14 ~68 minecraft:air
setblock ~36 ~-14 ~68 minecraft:polished_andesite
setblock ~32 ~-14 ~69 minecraft:polished_andesite
fill ~33 ~-14 ~69 ~35 ~-14 ~69 minecraft:air
setblock ~36 ~-14 ~69 minecraft:polished_andesite
fill ~32 ~-14 ~70 ~36 ~-14 ~70 minecraft:polished_andesite
fill ~4 ~-13 ~4 ~64 ~-13 ~4 minecraft:smooth_stone
fill ~4 ~-13 ~5 ~64 ~-13 ~5 minecraft:smooth_stone
fill ~4 ~-13 ~6 ~5 ~-13 ~6 minecraft:smooth_stone
setblock ~6 ~-13 ~6 minecraft:sea_lantern
fill ~7 ~-13 ~6 ~9 ~-13 ~6 minecraft:smooth_stone
setblock ~10 ~-13 ~6 minecraft:sea_lantern
fill ~11 ~-13 ~6 ~13 ~-13 ~6 minecraft:smooth_stone
setblock ~14 ~-13 ~6 minecraft:sea_lantern
fill ~15 ~-13 ~6 ~21 ~-13 ~6 minecraft:smooth_stone
setblock ~22 ~-13 ~6 minecraft:sea_lantern
fill ~23 ~-13 ~6 ~25 ~-13 ~6 minecraft:smooth_stone
setblock ~26 ~-13 ~6 minecraft:sea_lantern
fill ~27 ~-13 ~6 ~29 ~-13 ~6 minecraft:smooth_stone
setblock ~30 ~-13 ~6 minecraft:sea_lantern
fill ~31 ~-13 ~6 ~33 ~-13 ~6 minecraft:smooth_stone
setblock ~34 ~-13 ~6 minecraft:sea_lantern
fill ~35 ~-13 ~6 ~37 ~-13 ~6 minecraft:smooth_stone
setblock ~38 ~-13 ~6 minecraft:sea_lantern
fill ~39 ~-13 ~6 ~41 ~-13 ~6 minecraft:smooth_stone
setblock ~42 ~-13 ~6 minecraft:sea_lantern
fill ~43 ~-13 ~6 ~45 ~-13 ~6 minecraft:smooth_stone
setblock ~46 ~-13 ~6 minecraft:sea_lantern
fill ~47 ~-13 ~6 ~53 ~-13 ~6 minecraft:smooth_stone
setblock ~54 ~-13 ~6 minecraft:sea_lantern
fill ~55 ~-13 ~6 ~57 ~-13 ~6 minecraft:smooth_stone
setblock ~58 ~-13 ~6 minecraft:sea_lantern
fill ~59 ~-13 ~6 ~61 ~-13 ~6 minecraft:smooth_stone
setblock ~62 ~-13 ~6 minecraft:sea_lantern
fill ~63 ~-13 ~6 ~64 ~-13 ~6 minecraft:smooth_stone
fill ~4 ~-13 ~7 ~64 ~-13 ~7 minecraft:smooth_stone
fill ~4 ~-13 ~8 ~64 ~-13 ~8 minecraft:smooth_stone
fill ~4 ~-13 ~9 ~64 ~-13 ~9 minecraft:smooth_stone
fill ~4 ~-13 ~10 ~5 ~-13 ~10 minecraft:smooth_stone
setblock ~6 ~-13 ~10 minecraft:sea_lantern
fill ~7 ~-13 ~10 ~9 ~-13 ~10 minecraft:smooth_stone
setblock ~10 ~-13 ~10 minecraft:sea_lantern
fill ~11 ~-13 ~10 ~13 ~-13 ~10 minecraft:smooth_stone
setblock ~14 ~-13 ~10 minecraft:sea_lantern
fill ~15 ~-13 ~10 ~21 ~-13 ~10 minecraft:smooth_stone
setblock ~22 ~-13 ~10 minecraft:sea_lantern
fill ~23 ~-13 ~10 ~25 ~-13 ~10 minecraft:smooth_stone
setblock ~26 ~-13 ~10 minecraft:sea_lantern
fill ~27 ~-13 ~10 ~29 ~-13 ~10 minecraft:smooth_stone
setblock ~30 ~-13 ~10 minecraft:sea_lantern
fill ~31 ~-13 ~10 ~33 ~-13 ~10 minecraft:smooth_stone
setblock ~34 ~-13 ~10 minecraft:sea_lantern
fill ~35 ~-13 ~10 ~37 ~-13 ~10 minecraft:smooth_stone
setblock ~38 ~-13 ~10 minecraft:sea_lantern
fill ~39 ~-13 ~10 ~41 ~-13 ~10 minecraft:smooth_stone
setblock ~42 ~-13 ~10 minecraft:sea_lantern
fill ~43 ~-13 ~10 ~45 ~-13 ~10 minecraft:smooth_stone
setblock ~46 ~-13 ~10 minecraft:sea_lantern
fill ~47 ~-13 ~10 ~53 ~-13 ~10 minecraft:smooth_stone
setblock ~54 ~-13 ~10 minecraft:sea_lantern
fill ~55 ~-13 ~10 ~57 ~-13 ~10 minecraft:smooth_stone
setblock ~58 ~-13 ~10 minecraft:sea_lantern
fill ~59 ~-13 ~10 ~61 ~-13 ~10 minecraft:smooth_stone
setblock ~62 ~-13 ~10 minecraft:sea_lantern
fill ~63 ~-13 ~10 ~64 ~-13 ~10 minecraft:smooth_stone
fill ~4 ~-13 ~11 ~64 ~-13 ~11 minecraft:smooth_stone
fill ~4 ~-13 ~12 ~64 ~-13 ~12 minecraft:smooth_stone
fill ~4 ~-13 ~13 ~64 ~-13 ~13 minecraft:smooth_stone
fill ~4 ~-13 ~14 ~5 ~-13 ~14 minecraft:smooth_stone
setblock ~6 ~-13 ~14 minecraft:sea_lantern
fill ~7 ~-13 ~14 ~9 ~-13 ~14 minecraft:smooth_stone
schedule function hive:weiter/16 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 15 von 18 fertig","color":"gray"}]