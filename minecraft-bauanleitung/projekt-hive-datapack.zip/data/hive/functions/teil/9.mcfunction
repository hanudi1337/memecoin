setblock ~4 ~-34 ~34 minecraft:light_gray_concrete
fill ~5 ~-34 ~34 ~32 ~-34 ~34 minecraft:air
fill ~33 ~-34 ~34 ~35 ~-34 ~34 minecraft:glass
fill ~36 ~-34 ~34 ~63 ~-34 ~34 minecraft:air
setblock ~64 ~-34 ~34 minecraft:light_gray_concrete
setblock ~4 ~-34 ~35 minecraft:light_gray_concrete
fill ~5 ~-34 ~35 ~32 ~-34 ~35 minecraft:air
setblock ~33 ~-34 ~35 minecraft:glass
fill ~34 ~-34 ~35 ~63 ~-34 ~35 minecraft:air
setblock ~64 ~-34 ~35 minecraft:light_gray_concrete
setblock ~4 ~-34 ~36 minecraft:light_gray_concrete
fill ~5 ~-34 ~36 ~10 ~-34 ~36 minecraft:red_concrete
setblock ~11 ~-34 ~36 minecraft:air
fill ~12 ~-34 ~36 ~18 ~-34 ~36 minecraft:red_concrete
setblock ~19 ~-34 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-34 ~36 minecraft:air
setblock ~21 ~-34 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-34 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-34 ~36 ~32 ~-34 ~36 minecraft:air
fill ~33 ~-34 ~36 ~35 ~-34 ~36 minecraft:glass
fill ~36 ~-34 ~36 ~45 ~-34 ~36 minecraft:air
setblock ~46 ~-34 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-34 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-34 ~36 minecraft:air
setblock ~49 ~-34 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-34 ~36 ~56 ~-34 ~36 minecraft:red_concrete
setblock ~57 ~-34 ~36 minecraft:air
fill ~58 ~-34 ~36 ~63 ~-34 ~36 minecraft:red_concrete
setblock ~64 ~-34 ~36 minecraft:light_gray_concrete
setblock ~4 ~-34 ~37 minecraft:light_gray_concrete
fill ~5 ~-34 ~37 ~17 ~-34 ~37 minecraft:air
setblock ~18 ~-34 ~37 minecraft:light_gray_concrete
fill ~19 ~-34 ~37 ~21 ~-34 ~37 minecraft:air
setblock ~22 ~-34 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-34 ~37 ~45 ~-34 ~37 minecraft:air
setblock ~46 ~-34 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-34 ~37 ~49 ~-34 ~37 minecraft:air
setblock ~50 ~-34 ~37 minecraft:light_gray_concrete
fill ~51 ~-34 ~37 ~53 ~-34 ~37 minecraft:packed_ice
setblock ~54 ~-34 ~37 minecraft:air
setblock ~55 ~-34 ~37 minecraft:packed_ice
fill ~56 ~-34 ~37 ~58 ~-34 ~37 minecraft:air
fill ~59 ~-34 ~37 ~61 ~-34 ~37 minecraft:packed_ice
setblock ~62 ~-34 ~37 minecraft:air
setblock ~63 ~-34 ~37 minecraft:packed_ice
setblock ~64 ~-34 ~37 minecraft:light_gray_concrete
setblock ~4 ~-34 ~38 minecraft:light_gray_concrete
fill ~5 ~-34 ~38 ~17 ~-34 ~38 minecraft:air
setblock ~18 ~-34 ~38 minecraft:light_gray_concrete
fill ~19 ~-34 ~38 ~21 ~-34 ~38 minecraft:air
setblock ~22 ~-34 ~38 minecraft:quartz_pillar
setblock ~23 ~-34 ~38 minecraft:air
setblock ~24 ~-34 ~38 minecraft:quartz_pillar
fill ~25 ~-34 ~38 ~43 ~-34 ~38 minecraft:air
setblock ~44 ~-34 ~38 minecraft:quartz_pillar
setblock ~45 ~-34 ~38 minecraft:air
setblock ~46 ~-34 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-34 ~38 ~49 ~-34 ~38 minecraft:air
setblock ~50 ~-34 ~38 minecraft:light_gray_concrete
setblock ~51 ~-34 ~38 minecraft:packed_ice
fill ~52 ~-34 ~38 ~62 ~-34 ~38 minecraft:air
setblock ~63 ~-34 ~38 minecraft:packed_ice
setblock ~64 ~-34 ~38 minecraft:light_gray_concrete
setblock ~4 ~-34 ~39 minecraft:light_gray_concrete
setblock ~5 ~-34 ~39 minecraft:black_concrete
fill ~6 ~-34 ~39 ~17 ~-34 ~39 minecraft:air
setblock ~18 ~-34 ~39 minecraft:light_gray_concrete
fill ~19 ~-34 ~39 ~21 ~-34 ~39 minecraft:air
setblock ~22 ~-34 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-34 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-34 ~39 ~44 ~-34 ~39 minecraft:air
fill ~45 ~-34 ~39 ~46 ~-34 ~39 minecraft:quartz_pillar
fill ~47 ~-34 ~39 ~49 ~-34 ~39 minecraft:air
setblock ~50 ~-34 ~39 minecraft:light_gray_concrete
setblock ~51 ~-34 ~39 minecraft:packed_ice
fill ~52 ~-34 ~39 ~53 ~-34 ~39 minecraft:air
setblock ~54 ~-34 ~39 minecraft:barrel
fill ~55 ~-34 ~39 ~56 ~-34 ~39 minecraft:air
setblock ~57 ~-34 ~39 minecraft:barrel
fill ~58 ~-34 ~39 ~59 ~-34 ~39 minecraft:air
setblock ~60 ~-34 ~39 minecraft:barrel
fill ~61 ~-34 ~39 ~62 ~-34 ~39 minecraft:air
setblock ~63 ~-34 ~39 minecraft:packed_ice
setblock ~64 ~-34 ~39 minecraft:light_gray_concrete
setblock ~4 ~-34 ~40 minecraft:light_gray_concrete
fill ~5 ~-34 ~40 ~17 ~-34 ~40 minecraft:air
setblock ~18 ~-34 ~40 minecraft:light_gray_concrete
fill ~19 ~-34 ~40 ~22 ~-34 ~40 minecraft:air
setblock ~23 ~-34 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-34 ~40 ~44 ~-34 ~40 minecraft:air
setblock ~45 ~-34 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-34 ~40 ~49 ~-34 ~40 minecraft:air
setblock ~50 ~-34 ~40 minecraft:light_gray_concrete
fill ~51 ~-34 ~40 ~53 ~-34 ~40 minecraft:air
setblock ~54 ~-34 ~40 minecraft:barrel
fill ~55 ~-34 ~40 ~56 ~-34 ~40 minecraft:air
setblock ~57 ~-34 ~40 minecraft:barrel
fill ~58 ~-34 ~40 ~59 ~-34 ~40 minecraft:air
setblock ~60 ~-34 ~40 minecraft:barrel
fill ~61 ~-34 ~40 ~63 ~-34 ~40 minecraft:air
setblock ~64 ~-34 ~40 minecraft:light_gray_concrete
setblock ~4 ~-34 ~41 minecraft:light_gray_concrete
fill ~5 ~-34 ~41 ~17 ~-34 ~41 minecraft:air
setblock ~18 ~-34 ~41 minecraft:light_gray_concrete
fill ~19 ~-34 ~41 ~23 ~-34 ~41 minecraft:air
setblock ~24 ~-34 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-34 ~41 ~43 ~-34 ~41 minecraft:air
setblock ~44 ~-34 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-34 ~41 ~49 ~-34 ~41 minecraft:air
setblock ~50 ~-34 ~41 minecraft:light_gray_concrete
setblock ~51 ~-34 ~41 minecraft:packed_ice
fill ~52 ~-34 ~41 ~53 ~-34 ~41 minecraft:air
setblock ~54 ~-34 ~41 minecraft:barrel
fill ~55 ~-34 ~41 ~56 ~-34 ~41 minecraft:air
setblock ~57 ~-34 ~41 minecraft:barrel
fill ~58 ~-34 ~41 ~59 ~-34 ~41 minecraft:air
setblock ~60 ~-34 ~41 minecraft:barrel
fill ~61 ~-34 ~41 ~62 ~-34 ~41 minecraft:air
setblock ~63 ~-34 ~41 minecraft:packed_ice
setblock ~64 ~-34 ~41 minecraft:light_gray_concrete
setblock ~4 ~-34 ~42 minecraft:light_gray_concrete
setblock ~5 ~-34 ~42 minecraft:black_concrete
fill ~6 ~-34 ~42 ~17 ~-34 ~42 minecraft:air
setblock ~18 ~-34 ~42 minecraft:light_gray_concrete
fill ~19 ~-34 ~42 ~23 ~-34 ~42 minecraft:air
setblock ~24 ~-34 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-34 ~42 minecraft:quartz_pillar
fill ~26 ~-34 ~42 ~42 ~-34 ~42 minecraft:air
setblock ~43 ~-34 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-34 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-34 ~42 ~49 ~-34 ~42 minecraft:air
setblock ~50 ~-34 ~42 minecraft:light_gray_concrete
setblock ~51 ~-34 ~42 minecraft:packed_ice
fill ~52 ~-34 ~42 ~53 ~-34 ~42 minecraft:air
setblock ~54 ~-34 ~42 minecraft:barrel
fill ~55 ~-34 ~42 ~56 ~-34 ~42 minecraft:air
setblock ~57 ~-34 ~42 minecraft:barrel
fill ~58 ~-34 ~42 ~59 ~-34 ~42 minecraft:air
setblock ~60 ~-34 ~42 minecraft:barrel
fill ~61 ~-34 ~42 ~62 ~-34 ~42 minecraft:air
setblock ~63 ~-34 ~42 minecraft:packed_ice
setblock ~64 ~-34 ~42 minecraft:light_gray_concrete
setblock ~4 ~-34 ~43 minecraft:light_gray_concrete
fill ~5 ~-34 ~43 ~17 ~-34 ~43 minecraft:air
setblock ~18 ~-34 ~43 minecraft:light_gray_concrete
fill ~19 ~-34 ~43 ~20 ~-34 ~43 minecraft:air
setblock ~21 ~-34 ~43 minecraft:iron_bars[south=true]
fill ~22 ~-34 ~43 ~24 ~-34 ~43 minecraft:air
setblock ~25 ~-34 ~43 minecraft:quartz_pillar
setblock ~26 ~-34 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-34 ~43 ~41 ~-34 ~43 minecraft:air
fill ~42 ~-34 ~43 ~43 ~-34 ~43 minecraft:quartz_pillar
fill ~44 ~-34 ~43 ~49 ~-34 ~43 minecraft:air
setblock ~50 ~-34 ~43 minecraft:light_gray_concrete
setblock ~51 ~-34 ~43 minecraft:packed_ice
fill ~52 ~-34 ~43 ~62 ~-34 ~43 minecraft:air
setblock ~63 ~-34 ~43 minecraft:packed_ice
setblock ~64 ~-34 ~43 minecraft:light_gray_concrete
setblock ~4 ~-34 ~44 minecraft:light_gray_concrete
fill ~5 ~-34 ~44 ~17 ~-34 ~44 minecraft:air
setblock ~18 ~-34 ~44 minecraft:light_gray_concrete
fill ~19 ~-34 ~44 ~20 ~-34 ~44 minecraft:air
setblock ~21 ~-34 ~44 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-34 ~44 ~25 ~-34 ~44 minecraft:air
setblock ~26 ~-34 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-34 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-34 ~44 ~29 ~-34 ~44 minecraft:air
setblock ~30 ~-34 ~44 minecraft:quartz_pillar
fill ~31 ~-34 ~44 ~37 ~-34 ~44 minecraft:air
setblock ~38 ~-34 ~44 minecraft:quartz_pillar
fill ~39 ~-34 ~44 ~40 ~-34 ~44 minecraft:air
setblock ~41 ~-34 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-34 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-34 ~44 ~49 ~-34 ~44 minecraft:air
setblock ~50 ~-34 ~44 minecraft:light_gray_concrete
fill ~51 ~-34 ~44 ~53 ~-34 ~44 minecraft:air
setblock ~54 ~-34 ~44 minecraft:barrel
fill ~55 ~-34 ~44 ~56 ~-34 ~44 minecraft:air
setblock ~57 ~-34 ~44 minecraft:barrel
fill ~58 ~-34 ~44 ~59 ~-34 ~44 minecraft:air
setblock ~60 ~-34 ~44 minecraft:barrel
fill ~61 ~-34 ~44 ~63 ~-34 ~44 minecraft:air
setblock ~64 ~-34 ~44 minecraft:light_gray_concrete
setblock ~4 ~-34 ~45 minecraft:light_gray_concrete
setblock ~5 ~-34 ~45 minecraft:black_concrete
fill ~6 ~-34 ~45 ~17 ~-34 ~45 minecraft:air
setblock ~18 ~-34 ~45 minecraft:light_gray_concrete
fill ~19 ~-34 ~45 ~20 ~-34 ~45 minecraft:air
setblock ~21 ~-34 ~45 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~22 ~-34 ~45 minecraft:iron_bars[west=true]
fill ~23 ~-34 ~45 ~28 ~-34 ~45 minecraft:air
setblock ~29 ~-34 ~45 minecraft:quartz_pillar
fill ~30 ~-34 ~45 ~38 ~-34 ~45 minecraft:air
setblock ~39 ~-34 ~45 minecraft:glass_pane[east=true,south=true]
fill ~40 ~-34 ~45 ~49 ~-34 ~45 minecraft:air
setblock ~50 ~-34 ~45 minecraft:light_gray_concrete
setblock ~51 ~-34 ~45 minecraft:packed_ice
fill ~52 ~-34 ~45 ~53 ~-34 ~45 minecraft:air
setblock ~54 ~-34 ~45 minecraft:barrel
fill ~55 ~-34 ~45 ~56 ~-34 ~45 minecraft:air
setblock ~57 ~-34 ~45 minecraft:barrel
fill ~58 ~-34 ~45 ~59 ~-34 ~45 minecraft:air
setblock ~60 ~-34 ~45 minecraft:barrel
fill ~61 ~-34 ~45 ~62 ~-34 ~45 minecraft:air
setblock ~63 ~-34 ~45 minecraft:packed_ice
setblock ~64 ~-34 ~45 minecraft:light_gray_concrete
setblock ~4 ~-34 ~46 minecraft:light_gray_concrete
fill ~5 ~-34 ~46 ~17 ~-34 ~46 minecraft:air
setblock ~18 ~-34 ~46 minecraft:light_gray_concrete
fill ~19 ~-34 ~46 ~20 ~-34 ~46 minecraft:air
setblock ~21 ~-34 ~46 minecraft:iron_bars[north=true,south=true]
setblock ~22 ~-34 ~46 minecraft:air
setblock ~23 ~-34 ~46 minecraft:iron_bars[south=true]
fill ~24 ~-34 ~46 ~28 ~-34 ~46 minecraft:air
setblock ~29 ~-34 ~46 minecraft:quartz_pillar
fill ~30 ~-34 ~46 ~31 ~-34 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-34 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-34 ~46 ~35 ~-34 ~46 minecraft:air
setblock ~36 ~-34 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-34 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-34 ~46 minecraft:quartz_pillar
setblock ~39 ~-34 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-34 ~46 ~41 ~-34 ~46 minecraft:air
setblock ~42 ~-34 ~46 minecraft:iron_bars[east=true]
setblock ~43 ~-34 ~46 minecraft:air
setblock ~44 ~-34 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-34 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~46 ~-34 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~47 ~-34 ~46 minecraft:air
setblock ~48 ~-34 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~49 ~-34 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~50 ~-34 ~46 minecraft:light_gray_concrete
setblock ~51 ~-34 ~46 minecraft:packed_ice
fill ~52 ~-34 ~46 ~53 ~-34 ~46 minecraft:air
setblock ~54 ~-34 ~46 minecraft:barrel
fill ~55 ~-34 ~46 ~56 ~-34 ~46 minecraft:air
setblock ~57 ~-34 ~46 minecraft:barrel
fill ~58 ~-34 ~46 ~59 ~-34 ~46 minecraft:air
setblock ~60 ~-34 ~46 minecraft:barrel
fill ~61 ~-34 ~46 ~62 ~-34 ~46 minecraft:air
setblock ~63 ~-34 ~46 minecraft:packed_ice
setblock ~64 ~-34 ~46 minecraft:light_gray_concrete
setblock ~4 ~-34 ~47 minecraft:light_gray_concrete
fill ~5 ~-34 ~47 ~17 ~-34 ~47 minecraft:air
setblock ~18 ~-34 ~47 minecraft:light_gray_concrete
fill ~19 ~-34 ~47 ~20 ~-34 ~47 minecraft:air
setblock ~21 ~-34 ~47 minecraft:iron_bars[north=true,east=true]
setblock ~22 ~-34 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-34 ~47 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-34 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-34 ~47 minecraft:iron_bars[west=true]
fill ~26 ~-34 ~47 ~31 ~-34 ~47 minecraft:air
setblock ~32 ~-34 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-34 ~47 ~35 ~-34 ~47 minecraft:air
setblock ~36 ~-34 ~47 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~47 ~40 ~-34 ~47 minecraft:air
setblock ~41 ~-34 ~47 minecraft:iron_bars[south=true]
fill ~42 ~-34 ~47 ~44 ~-34 ~47 minecraft:air
setblock ~45 ~-34 ~47 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-34 ~47 ~48 ~-34 ~47 minecraft:air
setblock ~49 ~-34 ~47 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-34 ~47 minecraft:light_gray_concrete
setblock ~51 ~-34 ~47 minecraft:packed_ice
fill ~52 ~-34 ~47 ~53 ~-34 ~47 minecraft:air
setblock ~54 ~-34 ~47 minecraft:barrel
fill ~55 ~-34 ~47 ~56 ~-34 ~47 minecraft:air
setblock ~57 ~-34 ~47 minecraft:barrel
fill ~58 ~-34 ~47 ~59 ~-34 ~47 minecraft:air
setblock ~60 ~-34 ~47 minecraft:barrel
fill ~61 ~-34 ~47 ~62 ~-34 ~47 minecraft:air
setblock ~63 ~-34 ~47 minecraft:packed_ice
setblock ~64 ~-34 ~47 minecraft:light_gray_concrete
setblock ~4 ~-34 ~48 minecraft:light_gray_concrete
setblock ~5 ~-34 ~48 minecraft:black_concrete
fill ~6 ~-34 ~48 ~17 ~-34 ~48 minecraft:air
setblock ~18 ~-34 ~48 minecraft:light_gray_concrete
fill ~19 ~-34 ~48 ~40 ~-34 ~48 minecraft:air
setblock ~41 ~-34 ~48 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-34 ~48 ~44 ~-34 ~48 minecraft:air
setblock ~45 ~-34 ~48 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-34 ~48 ~48 ~-34 ~48 minecraft:air
setblock ~49 ~-34 ~48 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-34 ~48 minecraft:light_gray_concrete
fill ~51 ~-34 ~48 ~63 ~-34 ~48 minecraft:air
setblock ~64 ~-34 ~48 minecraft:light_gray_concrete
setblock ~4 ~-34 ~49 minecraft:light_gray_concrete
fill ~5 ~-34 ~49 ~17 ~-34 ~49 minecraft:air
setblock ~18 ~-34 ~49 minecraft:light_gray_concrete
fill ~19 ~-34 ~49 ~31 ~-34 ~49 minecraft:air
setblock ~32 ~-34 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-34 ~49 ~35 ~-34 ~49 minecraft:air
setblock ~36 ~-34 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~49 ~40 ~-34 ~49 minecraft:air
setblock ~41 ~-34 ~49 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-34 ~49 ~44 ~-34 ~49 minecraft:air
setblock ~45 ~-34 ~49 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-34 ~49 ~48 ~-34 ~49 minecraft:air
setblock ~49 ~-34 ~49 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-34 ~49 minecraft:light_gray_concrete
fill ~51 ~-34 ~49 ~53 ~-34 ~49 minecraft:packed_ice
setblock ~54 ~-34 ~49 minecraft:air
setblock ~55 ~-34 ~49 minecraft:packed_ice
fill ~56 ~-34 ~49 ~58 ~-34 ~49 minecraft:air
fill ~59 ~-34 ~49 ~61 ~-34 ~49 minecraft:packed_ice
setblock ~62 ~-34 ~49 minecraft:air
setblock ~63 ~-34 ~49 minecraft:packed_ice
setblock ~64 ~-34 ~49 minecraft:light_gray_concrete
fill ~4 ~-34 ~50 ~10 ~-34 ~50 minecraft:light_gray_concrete
setblock ~11 ~-34 ~50 minecraft:air
fill ~12 ~-34 ~50 ~31 ~-34 ~50 minecraft:light_gray_concrete
setblock ~32 ~-34 ~50 minecraft:red_concrete
fill ~33 ~-34 ~50 ~35 ~-34 ~50 minecraft:air
setblock ~36 ~-34 ~50 minecraft:red_concrete
fill ~37 ~-34 ~50 ~56 ~-34 ~50 minecraft:light_gray_concrete
setblock ~57 ~-34 ~50 minecraft:air
fill ~58 ~-34 ~50 ~64 ~-34 ~50 minecraft:light_gray_concrete
setblock ~4 ~-34 ~51 minecraft:light_gray_concrete
fill ~5 ~-34 ~51 ~17 ~-34 ~51 minecraft:air
setblock ~18 ~-34 ~51 minecraft:light_gray_concrete
fill ~19 ~-34 ~51 ~31 ~-34 ~51 minecraft:air
setblock ~32 ~-34 ~51 minecraft:red_concrete
fill ~33 ~-34 ~51 ~35 ~-34 ~51 minecraft:air
setblock ~36 ~-34 ~51 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~51 ~49 ~-34 ~51 minecraft:air
setblock ~50 ~-34 ~51 minecraft:light_gray_concrete
fill ~51 ~-34 ~51 ~63 ~-34 ~51 minecraft:air
setblock ~64 ~-34 ~51 minecraft:light_gray_concrete
setblock ~4 ~-34 ~52 minecraft:light_gray_concrete
setblock ~5 ~-34 ~52 minecraft:iron_block
setblock ~6 ~-34 ~52 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~52 ~15 ~-34 ~52 minecraft:air
setblock ~16 ~-34 ~52 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~52 minecraft:iron_block
setblock ~18 ~-34 ~52 minecraft:light_gray_concrete
setblock ~19 ~-34 ~52 minecraft:air
fill ~20 ~-34 ~52 ~23 ~-34 ~52 minecraft:barrel
setblock ~24 ~-34 ~52 minecraft:air
fill ~25 ~-34 ~52 ~28 ~-34 ~52 minecraft:barrel
setblock ~29 ~-34 ~52 minecraft:air
setblock ~30 ~-34 ~52 minecraft:barrel
setblock ~31 ~-34 ~52 minecraft:air
setblock ~32 ~-34 ~52 minecraft:red_concrete
fill ~33 ~-34 ~52 ~35 ~-34 ~52 minecraft:air
setblock ~36 ~-34 ~52 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~52 ~49 ~-34 ~52 minecraft:air
setblock ~50 ~-34 ~52 minecraft:light_gray_concrete
fill ~51 ~-34 ~52 ~63 ~-34 ~52 minecraft:air
setblock ~64 ~-34 ~52 minecraft:light_gray_concrete
setblock ~4 ~-34 ~53 minecraft:light_gray_concrete
setblock ~5 ~-34 ~53 minecraft:iron_block
setblock ~6 ~-34 ~53 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~53 ~15 ~-34 ~53 minecraft:air
setblock ~16 ~-34 ~53 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~53 minecraft:iron_block
setblock ~18 ~-34 ~53 minecraft:light_gray_concrete
fill ~19 ~-34 ~53 ~31 ~-34 ~53 minecraft:air
setblock ~32 ~-34 ~53 minecraft:red_concrete
fill ~33 ~-34 ~53 ~35 ~-34 ~53 minecraft:air
setblock ~36 ~-34 ~53 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~53 ~49 ~-34 ~53 minecraft:air
setblock ~50 ~-34 ~53 minecraft:light_gray_concrete
fill ~51 ~-34 ~53 ~63 ~-34 ~53 minecraft:air
setblock ~64 ~-34 ~53 minecraft:light_gray_concrete
setblock ~4 ~-34 ~54 minecraft:light_gray_concrete
setblock ~5 ~-34 ~54 minecraft:iron_block
setblock ~6 ~-34 ~54 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~54 ~15 ~-34 ~54 minecraft:air
setblock ~16 ~-34 ~54 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~54 minecraft:iron_block
setblock ~18 ~-34 ~54 minecraft:light_gray_concrete
fill ~19 ~-34 ~54 ~31 ~-34 ~54 minecraft:air
setblock ~32 ~-34 ~54 minecraft:red_concrete
fill ~33 ~-34 ~54 ~35 ~-34 ~54 minecraft:air
setblock ~36 ~-34 ~54 minecraft:red_concrete
fill ~37 ~-34 ~54 ~39 ~-34 ~54 minecraft:air
setblock ~40 ~-34 ~54 minecraft:white_stained_glass_pane
fill ~41 ~-34 ~54 ~42 ~-34 ~54 minecraft:air
setblock ~43 ~-34 ~54 minecraft:white_stained_glass_pane
fill ~44 ~-34 ~54 ~45 ~-34 ~54 minecraft:air
setblock ~46 ~-34 ~54 minecraft:white_stained_glass_pane
fill ~47 ~-34 ~54 ~48 ~-34 ~54 minecraft:air
setblock ~49 ~-34 ~54 minecraft:white_stained_glass_pane[east=true]
setblock ~50 ~-34 ~54 minecraft:light_gray_concrete
fill ~51 ~-34 ~54 ~63 ~-34 ~54 minecraft:air
setblock ~64 ~-34 ~54 minecraft:light_gray_concrete
setblock ~4 ~-34 ~55 minecraft:light_gray_concrete
setblock ~5 ~-34 ~55 minecraft:iron_block
setblock ~6 ~-34 ~55 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~55 ~15 ~-34 ~55 minecraft:air
setblock ~16 ~-34 ~55 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~55 minecraft:iron_block
setblock ~18 ~-34 ~55 minecraft:light_gray_concrete
setblock ~19 ~-34 ~55 minecraft:air
fill ~20 ~-34 ~55 ~23 ~-34 ~55 minecraft:barrel
setblock ~24 ~-34 ~55 minecraft:air
fill ~25 ~-34 ~55 ~28 ~-34 ~55 minecraft:barrel
setblock ~29 ~-34 ~55 minecraft:air
setblock ~30 ~-34 ~55 minecraft:barrel
setblock ~31 ~-34 ~55 minecraft:air
setblock ~32 ~-34 ~55 minecraft:red_concrete
fill ~33 ~-34 ~55 ~35 ~-34 ~55 minecraft:air
setblock ~36 ~-34 ~55 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~55 ~38 ~-34 ~55 minecraft:air
setblock ~39 ~-34 ~55 minecraft:white_stained_glass_pane
fill ~40 ~-34 ~55 ~41 ~-34 ~55 minecraft:air
setblock ~42 ~-34 ~55 minecraft:white_stained_glass_pane
fill ~43 ~-34 ~55 ~44 ~-34 ~55 minecraft:air
setblock ~45 ~-34 ~55 minecraft:white_stained_glass_pane
fill ~46 ~-34 ~55 ~47 ~-34 ~55 minecraft:air
setblock ~48 ~-34 ~55 minecraft:white_stained_glass_pane
setblock ~49 ~-34 ~55 minecraft:air
setblock ~50 ~-34 ~55 minecraft:light_gray_concrete
fill ~51 ~-34 ~55 ~63 ~-34 ~55 minecraft:air
setblock ~64 ~-34 ~55 minecraft:light_gray_concrete
setblock ~4 ~-34 ~56 minecraft:light_gray_concrete
setblock ~5 ~-34 ~56 minecraft:iron_block
setblock ~6 ~-34 ~56 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~56 ~17 ~-34 ~56 minecraft:air
setblock ~18 ~-34 ~56 minecraft:light_gray_concrete
fill ~19 ~-34 ~56 ~31 ~-34 ~56 minecraft:air
setblock ~32 ~-34 ~56 minecraft:red_concrete
fill ~33 ~-34 ~56 ~35 ~-34 ~56 minecraft:air
setblock ~36 ~-34 ~56 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~56 ~49 ~-34 ~56 minecraft:air
setblock ~50 ~-34 ~56 minecraft:light_gray_concrete
fill ~51 ~-34 ~56 ~63 ~-34 ~56 minecraft:air
setblock ~64 ~-34 ~56 minecraft:light_gray_concrete
setblock ~4 ~-34 ~57 minecraft:light_gray_concrete
setblock ~5 ~-34 ~57 minecraft:iron_block
setblock ~6 ~-34 ~57 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~57 ~8 ~-34 ~57 minecraft:air
setblock ~9 ~-34 ~57 minecraft:white_carpet
fill ~10 ~-34 ~57 ~12 ~-34 ~57 minecraft:air
setblock ~13 ~-34 ~57 minecraft:white_carpet
fill ~14 ~-34 ~57 ~39 ~-34 ~57 minecraft:air
setblock ~40 ~-34 ~57 minecraft:white_stained_glass_pane
fill ~41 ~-34 ~57 ~42 ~-34 ~57 minecraft:air
setblock ~43 ~-34 ~57 minecraft:white_stained_glass_pane
fill ~44 ~-34 ~57 ~45 ~-34 ~57 minecraft:air
setblock ~46 ~-34 ~57 minecraft:white_stained_glass_pane
fill ~47 ~-34 ~57 ~63 ~-34 ~57 minecraft:air
setblock ~64 ~-34 ~57 minecraft:light_gray_concrete
setblock ~4 ~-34 ~58 minecraft:light_gray_concrete
setblock ~5 ~-34 ~58 minecraft:iron_block
setblock ~6 ~-34 ~58 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~58 ~17 ~-34 ~58 minecraft:air
setblock ~18 ~-34 ~58 minecraft:light_gray_concrete
setblock ~19 ~-34 ~58 minecraft:air
fill ~20 ~-34 ~58 ~23 ~-34 ~58 minecraft:barrel
setblock ~24 ~-34 ~58 minecraft:air
fill ~25 ~-34 ~58 ~28 ~-34 ~58 minecraft:barrel
setblock ~29 ~-34 ~58 minecraft:air
setblock ~30 ~-34 ~58 minecraft:barrel
setblock ~31 ~-34 ~58 minecraft:air
setblock ~32 ~-34 ~58 minecraft:red_concrete
fill ~33 ~-34 ~58 ~35 ~-34 ~58 minecraft:air
setblock ~36 ~-34 ~58 minecraft:red_concrete
fill ~37 ~-34 ~58 ~38 ~-34 ~58 minecraft:air
setblock ~39 ~-34 ~58 minecraft:white_stained_glass_pane
fill ~40 ~-34 ~58 ~41 ~-34 ~58 minecraft:air
setblock ~42 ~-34 ~58 minecraft:white_stained_glass_pane
fill ~43 ~-34 ~58 ~44 ~-34 ~58 minecraft:air
setblock ~45 ~-34 ~58 minecraft:white_stained_glass_pane
fill ~46 ~-34 ~58 ~49 ~-34 ~58 minecraft:air
setblock ~50 ~-34 ~58 minecraft:light_gray_concrete
fill ~51 ~-34 ~58 ~63 ~-34 ~58 minecraft:air
setblock ~64 ~-34 ~58 minecraft:light_gray_concrete
setblock ~4 ~-34 ~59 minecraft:light_gray_concrete
setblock ~5 ~-34 ~59 minecraft:iron_block
setblock ~6 ~-34 ~59 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~59 ~15 ~-34 ~59 minecraft:air
setblock ~16 ~-34 ~59 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~59 minecraft:iron_block
setblock ~18 ~-34 ~59 minecraft:light_gray_concrete
fill ~19 ~-34 ~59 ~31 ~-34 ~59 minecraft:air
setblock ~32 ~-34 ~59 minecraft:red_concrete
fill ~33 ~-34 ~59 ~35 ~-34 ~59 minecraft:air
setblock ~36 ~-34 ~59 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~59 ~49 ~-34 ~59 minecraft:air
setblock ~50 ~-34 ~59 minecraft:light_gray_concrete
fill ~51 ~-34 ~59 ~63 ~-34 ~59 minecraft:air
setblock ~64 ~-34 ~59 minecraft:light_gray_concrete
setblock ~4 ~-34 ~60 minecraft:light_gray_concrete
setblock ~5 ~-34 ~60 minecraft:iron_block
setblock ~6 ~-34 ~60 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~60 ~15 ~-34 ~60 minecraft:air
setblock ~16 ~-34 ~60 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~60 minecraft:iron_block
setblock ~18 ~-34 ~60 minecraft:light_gray_concrete
fill ~19 ~-34 ~60 ~31 ~-34 ~60 minecraft:air
setblock ~32 ~-34 ~60 minecraft:red_concrete
fill ~33 ~-34 ~60 ~35 ~-34 ~60 minecraft:air
setblock ~36 ~-34 ~60 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~60 ~39 ~-34 ~60 minecraft:air
setblock ~40 ~-34 ~60 minecraft:white_stained_glass_pane
fill ~41 ~-34 ~60 ~42 ~-34 ~60 minecraft:air
setblock ~43 ~-34 ~60 minecraft:white_stained_glass_pane
fill ~44 ~-34 ~60 ~45 ~-34 ~60 minecraft:air
setblock ~46 ~-34 ~60 minecraft:white_stained_glass_pane
fill ~47 ~-34 ~60 ~48 ~-34 ~60 minecraft:air
setblock ~49 ~-34 ~60 minecraft:white_stained_glass_pane[east=true]
setblock ~50 ~-34 ~60 minecraft:light_gray_concrete
fill ~51 ~-34 ~60 ~63 ~-34 ~60 minecraft:air
setblock ~64 ~-34 ~60 minecraft:light_gray_concrete
setblock ~4 ~-34 ~61 minecraft:light_gray_concrete
setblock ~5 ~-34 ~61 minecraft:iron_block
setblock ~6 ~-34 ~61 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~61 ~15 ~-34 ~61 minecraft:air
setblock ~16 ~-34 ~61 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~61 minecraft:iron_block
setblock ~18 ~-34 ~61 minecraft:light_gray_concrete
setblock ~19 ~-34 ~61 minecraft:air
fill ~20 ~-34 ~61 ~23 ~-34 ~61 minecraft:barrel
setblock ~24 ~-34 ~61 minecraft:air
fill ~25 ~-34 ~61 ~28 ~-34 ~61 minecraft:barrel
setblock ~29 ~-34 ~61 minecraft:air
setblock ~30 ~-34 ~61 minecraft:barrel
setblock ~31 ~-34 ~61 minecraft:air
setblock ~32 ~-34 ~61 minecraft:red_concrete
fill ~33 ~-34 ~61 ~35 ~-34 ~61 minecraft:air
setblock ~36 ~-34 ~61 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~61 ~38 ~-34 ~61 minecraft:air
setblock ~39 ~-34 ~61 minecraft:white_stained_glass_pane
fill ~40 ~-34 ~61 ~41 ~-34 ~61 minecraft:air
setblock ~42 ~-34 ~61 minecraft:white_stained_glass_pane
fill ~43 ~-34 ~61 ~44 ~-34 ~61 minecraft:air
setblock ~45 ~-34 ~61 minecraft:white_stained_glass_pane
fill ~46 ~-34 ~61 ~47 ~-34 ~61 minecraft:air
setblock ~48 ~-34 ~61 minecraft:white_stained_glass_pane
setblock ~49 ~-34 ~61 minecraft:air
setblock ~50 ~-34 ~61 minecraft:light_gray_concrete
fill ~51 ~-34 ~61 ~63 ~-34 ~61 minecraft:air
setblock ~64 ~-34 ~61 minecraft:light_gray_concrete
setblock ~4 ~-34 ~62 minecraft:light_gray_concrete
setblock ~5 ~-34 ~62 minecraft:iron_block
setblock ~6 ~-34 ~62 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-34 ~62 ~15 ~-34 ~62 minecraft:iron_trapdoor[open=true,facing=north]
setblock ~16 ~-34 ~62 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~62 minecraft:iron_block
setblock ~18 ~-34 ~62 minecraft:light_gray_concrete
fill ~19 ~-34 ~62 ~31 ~-34 ~62 minecraft:air
setblock ~32 ~-34 ~62 minecraft:red_concrete
fill ~33 ~-34 ~62 ~35 ~-34 ~62 minecraft:air
setblock ~36 ~-34 ~62 minecraft:red_concrete
fill ~37 ~-34 ~62 ~49 ~-34 ~62 minecraft:air
setblock ~50 ~-34 ~62 minecraft:light_gray_concrete
fill ~51 ~-34 ~62 ~63 ~-34 ~62 minecraft:air
setblock ~64 ~-34 ~62 minecraft:light_gray_concrete
setblock ~4 ~-34 ~63 minecraft:light_gray_concrete
fill ~5 ~-34 ~63 ~6 ~-34 ~63 minecraft:air
fill ~7 ~-34 ~63 ~15 ~-34 ~63 minecraft:iron_block
setblock ~16 ~-34 ~63 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-34 ~63 minecraft:iron_block
setblock ~18 ~-34 ~63 minecraft:light_gray_concrete
fill ~19 ~-34 ~63 ~31 ~-34 ~63 minecraft:air
setblock ~32 ~-34 ~63 minecraft:red_concrete
fill ~33 ~-34 ~63 ~35 ~-34 ~63 minecraft:air
setblock ~36 ~-34 ~63 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-34 ~63 ~49 ~-34 ~63 minecraft:air
setblock ~50 ~-34 ~63 minecraft:light_gray_concrete
fill ~51 ~-34 ~63 ~63 ~-34 ~63 minecraft:air
setblock ~64 ~-34 ~63 minecraft:light_gray_concrete
fill ~4 ~-34 ~64 ~33 ~-34 ~64 minecraft:light_gray_concrete
setblock ~34 ~-34 ~64 minecraft:air
fill ~35 ~-34 ~64 ~64 ~-34 ~64 minecraft:light_gray_concrete
setblock ~33 ~-34 ~65 minecraft:light_gray_concrete
setblock ~34 ~-34 ~65 minecraft:air
setblock ~35 ~-34 ~65 minecraft:light_gray_concrete
fill ~32 ~-34 ~66 ~33 ~-34 ~66 minecraft:polished_andesite
setblock ~34 ~-34 ~66 minecraft:air
fill ~35 ~-34 ~66 ~36 ~-34 ~66 minecraft:polished_andesite
setblock ~32 ~-34 ~67 minecraft:polished_andesite
fill ~33 ~-34 ~67 ~35 ~-34 ~67 minecraft:air
setblock ~36 ~-34 ~67 minecraft:polished_andesite
setblock ~32 ~-34 ~68 minecraft:polished_andesite
setblock ~33 ~-34 ~68 minecraft:air
setblock ~34 ~-34 ~68 minecraft:quartz_pillar
setblock ~35 ~-34 ~68 minecraft:quartz_stairs[facing=south,half=bottom]
setblock ~36 ~-34 ~68 minecraft:polished_andesite
setblock ~32 ~-34 ~69 minecraft:polished_andesite
fill ~33 ~-34 ~69 ~35 ~-34 ~69 minecraft:air
setblock ~36 ~-34 ~69 minecraft:polished_andesite
fill ~32 ~-34 ~70 ~36 ~-34 ~70 minecraft:polished_andesite
fill ~4 ~-33 ~4 ~64 ~-33 ~4 minecraft:light_gray_concrete
setblock ~4 ~-33 ~5 minecraft:light_gray_concrete
fill ~5 ~-33 ~5 ~17 ~-33 ~5 minecraft:air
setblock ~18 ~-33 ~5 minecraft:light_gray_concrete
fill ~19 ~-33 ~5 ~31 ~-33 ~5 minecraft:air
setblock ~32 ~-33 ~5 minecraft:light_gray_concrete
fill ~33 ~-33 ~5 ~35 ~-33 ~5 minecraft:air
setblock ~36 ~-33 ~5 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~5 ~49 ~-33 ~5 minecraft:air
setblock ~50 ~-33 ~5 minecraft:light_gray_concrete
setblock ~51 ~-33 ~5 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-33 ~5 ~54 ~-33 ~5 minecraft:air
setblock ~55 ~-33 ~5 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-33 ~5 ~58 ~-33 ~5 minecraft:air
setblock ~59 ~-33 ~5 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-33 ~5 ~62 ~-33 ~5 minecraft:air
setblock ~63 ~-33 ~5 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-33 ~5 minecraft:light_gray_concrete
setblock ~4 ~-33 ~6 minecraft:light_gray_concrete
fill ~5 ~-33 ~6 ~17 ~-33 ~6 minecraft:air
setblock ~18 ~-33 ~6 minecraft:light_gray_concrete
fill ~19 ~-33 ~6 ~31 ~-33 ~6 minecraft:air
setblock ~32 ~-33 ~6 minecraft:light_gray_concrete
fill ~33 ~-33 ~6 ~35 ~-33 ~6 minecraft:air
setblock ~36 ~-33 ~6 minecraft:light_gray_concrete
fill ~37 ~-33 ~6 ~49 ~-33 ~6 minecraft:air
setblock ~50 ~-33 ~6 minecraft:light_gray_concrete
setblock ~51 ~-33 ~6 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-33 ~6 ~54 ~-33 ~6 minecraft:air
setblock ~55 ~-33 ~6 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-33 ~6 ~58 ~-33 ~6 minecraft:air
setblock ~59 ~-33 ~6 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-33 ~6 ~62 ~-33 ~6 minecraft:air
setblock ~63 ~-33 ~6 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-33 ~6 minecraft:light_gray_concrete
setblock ~4 ~-33 ~7 minecraft:light_gray_concrete
fill ~5 ~-33 ~7 ~17 ~-33 ~7 minecraft:air
setblock ~18 ~-33 ~7 minecraft:light_gray_concrete
fill ~19 ~-33 ~7 ~31 ~-33 ~7 minecraft:air
setblock ~32 ~-33 ~7 minecraft:light_gray_concrete
fill ~33 ~-33 ~7 ~35 ~-33 ~7 minecraft:air
setblock ~36 ~-33 ~7 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~7 ~49 ~-33 ~7 minecraft:air
setblock ~50 ~-33 ~7 minecraft:light_gray_concrete
setblock ~51 ~-33 ~7 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-33 ~7 ~54 ~-33 ~7 minecraft:air
setblock ~55 ~-33 ~7 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-33 ~7 ~58 ~-33 ~7 minecraft:air
setblock ~59 ~-33 ~7 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-33 ~7 ~62 ~-33 ~7 minecraft:air
setblock ~63 ~-33 ~7 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-33 ~7 minecraft:light_gray_concrete
setblock ~4 ~-33 ~8 minecraft:light_gray_concrete
fill ~5 ~-33 ~8 ~17 ~-33 ~8 minecraft:air
setblock ~18 ~-33 ~8 minecraft:light_gray_concrete
fill ~19 ~-33 ~8 ~31 ~-33 ~8 minecraft:air
setblock ~32 ~-33 ~8 minecraft:light_gray_concrete
fill ~33 ~-33 ~8 ~35 ~-33 ~8 minecraft:air
setblock ~36 ~-33 ~8 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~8 ~49 ~-33 ~8 minecraft:air
setblock ~50 ~-33 ~8 minecraft:light_gray_concrete
setblock ~51 ~-33 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~52 ~-33 ~8 ~54 ~-33 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~55 ~-33 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~56 ~-33 ~8 ~58 ~-33 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~59 ~-33 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~60 ~-33 ~8 ~62 ~-33 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~63 ~-33 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~64 ~-33 ~8 minecraft:light_gray_concrete
setblock ~4 ~-33 ~9 minecraft:light_gray_concrete
fill ~5 ~-33 ~9 ~17 ~-33 ~9 minecraft:air
setblock ~18 ~-33 ~9 minecraft:light_gray_concrete
fill ~19 ~-33 ~9 ~31 ~-33 ~9 minecraft:air
setblock ~32 ~-33 ~9 minecraft:light_gray_concrete
fill ~33 ~-33 ~9 ~35 ~-33 ~9 minecraft:air
setblock ~36 ~-33 ~9 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~9 ~49 ~-33 ~9 minecraft:air
setblock ~50 ~-33 ~9 minecraft:light_gray_concrete
fill ~51 ~-33 ~9 ~63 ~-33 ~9 minecraft:air
setblock ~64 ~-33 ~9 minecraft:light_gray_concrete
setblock ~4 ~-33 ~10 minecraft:light_gray_concrete
fill ~5 ~-33 ~10 ~17 ~-33 ~10 minecraft:air
setblock ~18 ~-33 ~10 minecraft:light_gray_concrete
fill ~19 ~-33 ~10 ~31 ~-33 ~10 minecraft:air
setblock ~32 ~-33 ~10 minecraft:light_gray_concrete
fill ~33 ~-33 ~10 ~35 ~-33 ~10 minecraft:air
setblock ~36 ~-33 ~10 minecraft:light_gray_concrete
fill ~37 ~-33 ~10 ~49 ~-33 ~10 minecraft:air
setblock ~50 ~-33 ~10 minecraft:light_gray_concrete
fill ~51 ~-33 ~10 ~63 ~-33 ~10 minecraft:air
setblock ~64 ~-33 ~10 minecraft:light_gray_concrete
setblock ~4 ~-33 ~11 minecraft:light_gray_concrete
fill ~5 ~-33 ~11 ~17 ~-33 ~11 minecraft:air
setblock ~18 ~-33 ~11 minecraft:light_gray_concrete
fill ~19 ~-33 ~11 ~31 ~-33 ~11 minecraft:air
setblock ~32 ~-33 ~11 minecraft:light_gray_concrete
fill ~33 ~-33 ~11 ~35 ~-33 ~11 minecraft:air
setblock ~36 ~-33 ~11 minecraft:light_gray_concrete
fill ~37 ~-33 ~11 ~49 ~-33 ~11 minecraft:air
setblock ~50 ~-33 ~11 minecraft:light_gray_concrete
fill ~51 ~-33 ~11 ~63 ~-33 ~11 minecraft:air
setblock ~64 ~-33 ~11 minecraft:light_gray_concrete
setblock ~4 ~-33 ~12 minecraft:light_gray_concrete
fill ~5 ~-33 ~12 ~17 ~-33 ~12 minecraft:air
setblock ~18 ~-33 ~12 minecraft:light_gray_concrete
fill ~19 ~-33 ~12 ~31 ~-33 ~12 minecraft:air
setblock ~32 ~-33 ~12 minecraft:light_gray_concrete
fill ~33 ~-33 ~12 ~35 ~-33 ~12 minecraft:air
setblock ~36 ~-33 ~12 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~12 ~49 ~-33 ~12 minecraft:air
setblock ~50 ~-33 ~12 minecraft:light_gray_concrete
fill ~51 ~-33 ~12 ~63 ~-33 ~12 minecraft:air
setblock ~64 ~-33 ~12 minecraft:light_gray_concrete
setblock ~4 ~-33 ~13 minecraft:light_gray_concrete
fill ~5 ~-33 ~13 ~17 ~-33 ~13 minecraft:air
setblock ~18 ~-33 ~13 minecraft:light_gray_concrete
fill ~19 ~-33 ~13 ~31 ~-33 ~13 minecraft:air
setblock ~32 ~-33 ~13 minecraft:light_gray_concrete
fill ~33 ~-33 ~13 ~35 ~-33 ~13 minecraft:air
setblock ~36 ~-33 ~13 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~13 ~49 ~-33 ~13 minecraft:air
setblock ~50 ~-33 ~13 minecraft:light_gray_concrete
fill ~51 ~-33 ~13 ~63 ~-33 ~13 minecraft:air
setblock ~64 ~-33 ~13 minecraft:light_gray_concrete
setblock ~4 ~-33 ~14 minecraft:light_gray_concrete
fill ~5 ~-33 ~14 ~17 ~-33 ~14 minecraft:air
setblock ~18 ~-33 ~14 minecraft:light_gray_concrete
fill ~19 ~-33 ~14 ~31 ~-33 ~14 minecraft:air
setblock ~32 ~-33 ~14 minecraft:light_gray_concrete
fill ~33 ~-33 ~14 ~35 ~-33 ~14 minecraft:air
setblock ~36 ~-33 ~14 minecraft:light_gray_concrete
fill ~37 ~-33 ~14 ~49 ~-33 ~14 minecraft:air
setblock ~50 ~-33 ~14 minecraft:light_gray_concrete
fill ~51 ~-33 ~14 ~63 ~-33 ~14 minecraft:air
setblock ~64 ~-33 ~14 minecraft:light_gray_concrete
setblock ~4 ~-33 ~15 minecraft:light_gray_concrete
fill ~5 ~-33 ~15 ~17 ~-33 ~15 minecraft:air
setblock ~18 ~-33 ~15 minecraft:light_gray_concrete
fill ~19 ~-33 ~15 ~31 ~-33 ~15 minecraft:air
setblock ~32 ~-33 ~15 minecraft:light_gray_concrete
fill ~33 ~-33 ~15 ~35 ~-33 ~15 minecraft:air
setblock ~36 ~-33 ~15 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~15 ~49 ~-33 ~15 minecraft:air
setblock ~50 ~-33 ~15 minecraft:light_gray_concrete
fill ~51 ~-33 ~15 ~63 ~-33 ~15 minecraft:air
setblock ~64 ~-33 ~15 minecraft:light_gray_concrete
setblock ~4 ~-33 ~16 minecraft:light_gray_concrete
fill ~5 ~-33 ~16 ~17 ~-33 ~16 minecraft:air
setblock ~18 ~-33 ~16 minecraft:light_gray_concrete
fill ~19 ~-33 ~16 ~31 ~-33 ~16 minecraft:air
setblock ~32 ~-33 ~16 minecraft:light_gray_concrete
fill ~33 ~-33 ~16 ~35 ~-33 ~16 minecraft:air
setblock ~36 ~-33 ~16 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~16 ~49 ~-33 ~16 minecraft:air
setblock ~50 ~-33 ~16 minecraft:light_gray_concrete
fill ~51 ~-33 ~16 ~63 ~-33 ~16 minecraft:air
setblock ~64 ~-33 ~16 minecraft:light_gray_concrete
setblock ~4 ~-33 ~17 minecraft:light_gray_concrete
fill ~5 ~-33 ~17 ~17 ~-33 ~17 minecraft:air
setblock ~18 ~-33 ~17 minecraft:light_gray_concrete
fill ~19 ~-33 ~17 ~31 ~-33 ~17 minecraft:air
setblock ~32 ~-33 ~17 minecraft:light_gray_concrete
fill ~33 ~-33 ~17 ~35 ~-33 ~17 minecraft:air
setblock ~36 ~-33 ~17 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~17 ~49 ~-33 ~17 minecraft:air
setblock ~50 ~-33 ~17 minecraft:light_gray_concrete
fill ~51 ~-33 ~17 ~63 ~-33 ~17 minecraft:air
setblock ~64 ~-33 ~17 minecraft:light_gray_concrete
fill ~4 ~-33 ~18 ~32 ~-33 ~18 minecraft:light_gray_concrete
fill ~33 ~-33 ~18 ~35 ~-33 ~18 minecraft:air
fill ~36 ~-33 ~18 ~64 ~-33 ~18 minecraft:light_gray_concrete
setblock ~4 ~-33 ~19 minecraft:light_gray_concrete
fill ~5 ~-33 ~19 ~9 ~-33 ~19 minecraft:iron_block
fill ~10 ~-33 ~19 ~12 ~-33 ~19 minecraft:air
fill ~13 ~-33 ~19 ~17 ~-33 ~19 minecraft:iron_block
setblock ~18 ~-33 ~19 minecraft:light_gray_concrete
setblock ~19 ~-33 ~19 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-33 ~19 ~22 ~-33 ~19 minecraft:air
setblock ~23 ~-33 ~19 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-33 ~19 ~26 ~-33 ~19 minecraft:air
setblock ~27 ~-33 ~19 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-33 ~19 ~31 ~-33 ~19 minecraft:air
setblock ~32 ~-33 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-33 ~19 ~35 ~-33 ~19 minecraft:air
setblock ~36 ~-33 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~19 ~49 ~-33 ~19 minecraft:air
setblock ~50 ~-33 ~19 minecraft:light_gray_concrete
fill ~51 ~-33 ~19 ~63 ~-33 ~19 minecraft:air
setblock ~64 ~-33 ~19 minecraft:light_gray_concrete
setblock ~4 ~-33 ~20 minecraft:light_gray_concrete
fill ~5 ~-33 ~20 ~9 ~-33 ~20 minecraft:iron_trapdoor[open=true,facing=south]
fill ~10 ~-33 ~20 ~12 ~-33 ~20 minecraft:air
fill ~13 ~-33 ~20 ~17 ~-33 ~20 minecraft:iron_trapdoor[open=true,facing=south]
setblock ~18 ~-33 ~20 minecraft:light_gray_concrete
setblock ~19 ~-33 ~20 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-33 ~20 ~22 ~-33 ~20 minecraft:air
setblock ~23 ~-33 ~20 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-33 ~20 ~26 ~-33 ~20 minecraft:air
setblock ~27 ~-33 ~20 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-33 ~20 ~31 ~-33 ~20 minecraft:air
setblock ~32 ~-33 ~20 minecraft:light_gray_concrete
fill ~33 ~-33 ~20 ~35 ~-33 ~20 minecraft:air
setblock ~36 ~-33 ~20 minecraft:light_gray_concrete
fill ~37 ~-33 ~20 ~49 ~-33 ~20 minecraft:air
setblock ~50 ~-33 ~20 minecraft:light_gray_concrete
fill ~51 ~-33 ~20 ~63 ~-33 ~20 minecraft:air
setblock ~64 ~-33 ~20 minecraft:light_gray_concrete
setblock ~4 ~-33 ~21 minecraft:light_gray_concrete
setblock ~5 ~-33 ~21 minecraft:iron_block
setblock ~6 ~-33 ~21 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~21 ~17 ~-33 ~21 minecraft:air
setblock ~18 ~-33 ~21 minecraft:light_gray_concrete
setblock ~19 ~-33 ~21 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-33 ~21 ~22 ~-33 ~21 minecraft:air
setblock ~23 ~-33 ~21 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-33 ~21 ~26 ~-33 ~21 minecraft:air
setblock ~27 ~-33 ~21 minecraft:iron_bars[north=true]
fill ~28 ~-33 ~21 ~31 ~-33 ~21 minecraft:air
setblock ~32 ~-33 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-33 ~21 ~35 ~-33 ~21 minecraft:air
setblock ~36 ~-33 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~21 ~42 ~-33 ~21 minecraft:air
setblock ~43 ~-33 ~21 minecraft:iron_bars[east=true]
setblock ~44 ~-33 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-33 ~21 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~46 ~-33 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~47 ~-33 ~21 minecraft:iron_bars[south=true,west=true]
fill ~48 ~-33 ~21 ~49 ~-33 ~21 minecraft:air
setblock ~50 ~-33 ~21 minecraft:light_gray_concrete
fill ~51 ~-33 ~21 ~63 ~-33 ~21 minecraft:air
setblock ~64 ~-33 ~21 minecraft:light_gray_concrete
setblock ~4 ~-33 ~22 minecraft:light_gray_concrete
setblock ~5 ~-33 ~22 minecraft:iron_block
setblock ~6 ~-33 ~22 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~22 ~17 ~-33 ~22 minecraft:air
setblock ~18 ~-33 ~22 minecraft:light_gray_concrete
setblock ~19 ~-33 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~20 ~-33 ~22 ~22 ~-33 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-33 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~24 ~-33 ~22 ~25 ~-33 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~26 ~-33 ~22 minecraft:iron_bars[west=true]
fill ~27 ~-33 ~22 ~28 ~-33 ~22 minecraft:air
setblock ~29 ~-33 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-33 ~22 minecraft:quartz_pillar
setblock ~31 ~-33 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-33 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-33 ~22 ~35 ~-33 ~22 minecraft:air
setblock ~36 ~-33 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-33 ~22 ~38 ~-33 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-33 ~22 minecraft:quartz_pillar
fill ~40 ~-33 ~22 ~44 ~-33 ~22 minecraft:air
setblock ~45 ~-33 ~22 minecraft:iron_bars[north=true]
setblock ~46 ~-33 ~22 minecraft:air
setblock ~47 ~-33 ~22 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-33 ~22 ~49 ~-33 ~22 minecraft:air
setblock ~50 ~-33 ~22 minecraft:light_gray_concrete
fill ~51 ~-33 ~22 ~63 ~-33 ~22 minecraft:air
setblock ~64 ~-33 ~22 minecraft:light_gray_concrete
setblock ~4 ~-33 ~23 minecraft:light_gray_concrete
setblock ~5 ~-33 ~23 minecraft:iron_block
setblock ~6 ~-33 ~23 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~23 ~17 ~-33 ~23 minecraft:air
setblock ~18 ~-33 ~23 minecraft:light_gray_concrete
fill ~19 ~-33 ~23 ~27 ~-33 ~23 minecraft:air
setblock ~28 ~-33 ~23 minecraft:smooth_quartz
setblock ~29 ~-33 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-33 ~23 ~38 ~-33 ~23 minecraft:air
setblock ~39 ~-33 ~23 minecraft:quartz_pillar
setblock ~40 ~-33 ~23 minecraft:smooth_quartz
fill ~41 ~-33 ~23 ~45 ~-33 ~23 minecraft:air
setblock ~46 ~-33 ~23 minecraft:iron_bars[east=true]
setblock ~47 ~-33 ~23 minecraft:iron_bars[north=true,south=true,west=true]
fill ~48 ~-33 ~23 ~49 ~-33 ~23 minecraft:air
setblock ~50 ~-33 ~23 minecraft:light_gray_concrete
fill ~51 ~-33 ~23 ~63 ~-33 ~23 minecraft:air
setblock ~64 ~-33 ~23 minecraft:light_gray_concrete
setblock ~4 ~-33 ~24 minecraft:light_gray_concrete
setblock ~5 ~-33 ~24 minecraft:iron_block
setblock ~6 ~-33 ~24 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~24 ~17 ~-33 ~24 minecraft:air
setblock ~18 ~-33 ~24 minecraft:light_gray_concrete
fill ~19 ~-33 ~24 ~25 ~-33 ~24 minecraft:air
setblock ~26 ~-33 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-33 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-33 ~24 ~29 ~-33 ~24 minecraft:air
setblock ~30 ~-33 ~24 minecraft:quartz_pillar
fill ~31 ~-33 ~24 ~37 ~-33 ~24 minecraft:air
setblock ~38 ~-33 ~24 minecraft:quartz_pillar
fill ~39 ~-33 ~24 ~40 ~-33 ~24 minecraft:air
setblock ~41 ~-33 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-33 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-33 ~24 ~46 ~-33 ~24 minecraft:air
setblock ~47 ~-33 ~24 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-33 ~24 ~49 ~-33 ~24 minecraft:air
setblock ~50 ~-33 ~24 minecraft:light_gray_concrete
fill ~51 ~-33 ~24 ~63 ~-33 ~24 minecraft:air
setblock ~64 ~-33 ~24 minecraft:light_gray_concrete
setblock ~4 ~-33 ~25 minecraft:light_gray_concrete
setblock ~5 ~-33 ~25 minecraft:iron_block
setblock ~6 ~-33 ~25 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~25 ~17 ~-33 ~25 minecraft:air
setblock ~18 ~-33 ~25 minecraft:light_gray_concrete
fill ~19 ~-33 ~25 ~24 ~-33 ~25 minecraft:air
fill ~25 ~-33 ~25 ~26 ~-33 ~25 minecraft:quartz_pillar
fill ~27 ~-33 ~25 ~41 ~-33 ~25 minecraft:air
setblock ~42 ~-33 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-33 ~25 minecraft:quartz_pillar
fill ~44 ~-33 ~25 ~46 ~-33 ~25 minecraft:air
setblock ~47 ~-33 ~25 minecraft:iron_bars[north=true]
fill ~48 ~-33 ~25 ~49 ~-33 ~25 minecraft:air
setblock ~50 ~-33 ~25 minecraft:light_gray_concrete
fill ~51 ~-33 ~25 ~63 ~-33 ~25 minecraft:air
setblock ~64 ~-33 ~25 minecraft:light_gray_concrete
setblock ~4 ~-33 ~26 minecraft:light_gray_concrete
setblock ~5 ~-33 ~26 minecraft:iron_block
setblock ~6 ~-33 ~26 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~26 ~17 ~-33 ~26 minecraft:air
setblock ~18 ~-33 ~26 minecraft:light_gray_concrete
fill ~19 ~-33 ~26 ~23 ~-33 ~26 minecraft:air
setblock ~24 ~-33 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-33 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-33 ~26 ~42 ~-33 ~26 minecraft:air
setblock ~43 ~-33 ~26 minecraft:quartz_pillar
setblock ~44 ~-33 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-33 ~26 ~49 ~-33 ~26 minecraft:air
setblock ~50 ~-33 ~26 minecraft:light_gray_concrete
fill ~51 ~-33 ~26 ~63 ~-33 ~26 minecraft:air
setblock ~64 ~-33 ~26 minecraft:light_gray_concrete
setblock ~4 ~-33 ~27 minecraft:light_gray_concrete
setblock ~5 ~-33 ~27 minecraft:iron_block
setblock ~6 ~-33 ~27 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~27 ~17 ~-33 ~27 minecraft:air
setblock ~18 ~-33 ~27 minecraft:light_gray_concrete
fill ~19 ~-33 ~27 ~23 ~-33 ~27 minecraft:air
setblock ~24 ~-33 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-33 ~27 ~43 ~-33 ~27 minecraft:air
setblock ~44 ~-33 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-33 ~27 ~49 ~-33 ~27 minecraft:air
setblock ~50 ~-33 ~27 minecraft:light_gray_concrete
fill ~51 ~-33 ~27 ~63 ~-33 ~27 minecraft:air
setblock ~64 ~-33 ~27 minecraft:light_gray_concrete
setblock ~4 ~-33 ~28 minecraft:light_gray_concrete
setblock ~5 ~-33 ~28 minecraft:iron_block
setblock ~6 ~-33 ~28 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~28 ~17 ~-33 ~28 minecraft:air
setblock ~18 ~-33 ~28 minecraft:light_gray_concrete
fill ~19 ~-33 ~28 ~22 ~-33 ~28 minecraft:air
setblock ~23 ~-33 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-33 ~28 ~44 ~-33 ~28 minecraft:air
setblock ~45 ~-33 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-33 ~28 ~49 ~-33 ~28 minecraft:air
setblock ~50 ~-33 ~28 minecraft:light_gray_concrete
fill ~51 ~-33 ~28 ~63 ~-33 ~28 minecraft:air
setblock ~64 ~-33 ~28 minecraft:light_gray_concrete
setblock ~4 ~-33 ~29 minecraft:light_gray_concrete
setblock ~5 ~-33 ~29 minecraft:iron_block
setblock ~6 ~-33 ~29 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~29 ~17 ~-33 ~29 minecraft:air
setblock ~18 ~-33 ~29 minecraft:light_gray_concrete
fill ~19 ~-33 ~29 ~21 ~-33 ~29 minecraft:air
fill ~22 ~-33 ~29 ~23 ~-33 ~29 minecraft:quartz_pillar
fill ~24 ~-33 ~29 ~44 ~-33 ~29 minecraft:air
setblock ~45 ~-33 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-33 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-33 ~29 ~49 ~-33 ~29 minecraft:air
setblock ~50 ~-33 ~29 minecraft:light_gray_concrete
fill ~51 ~-33 ~29 ~63 ~-33 ~29 minecraft:air
setblock ~64 ~-33 ~29 minecraft:light_gray_concrete
setblock ~4 ~-33 ~30 minecraft:light_gray_concrete
setblock ~5 ~-33 ~30 minecraft:iron_block
setblock ~6 ~-33 ~30 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~30 ~9 ~-33 ~30 minecraft:iron_trapdoor[open=true,facing=north]
fill ~10 ~-33 ~30 ~12 ~-33 ~30 minecraft:air
fill ~13 ~-33 ~30 ~16 ~-33 ~30 minecraft:iron_trapdoor[open=true,facing=north]
setblock ~17 ~-33 ~30 minecraft:air
setblock ~18 ~-33 ~30 minecraft:light_gray_concrete
fill ~19 ~-33 ~30 ~21 ~-33 ~30 minecraft:air
setblock ~22 ~-33 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-33 ~30 minecraft:air
setblock ~24 ~-33 ~30 minecraft:quartz_pillar
fill ~25 ~-33 ~30 ~43 ~-33 ~30 minecraft:air
setblock ~44 ~-33 ~30 minecraft:quartz_pillar
setblock ~45 ~-33 ~30 minecraft:air
setblock ~46 ~-33 ~30 minecraft:quartz_pillar
fill ~47 ~-33 ~30 ~49 ~-33 ~30 minecraft:air
setblock ~50 ~-33 ~30 minecraft:light_gray_concrete
fill ~51 ~-33 ~30 ~63 ~-33 ~30 minecraft:air
setblock ~64 ~-33 ~30 minecraft:light_gray_concrete
setblock ~4 ~-33 ~31 minecraft:light_gray_concrete
fill ~5 ~-33 ~31 ~6 ~-33 ~31 minecraft:air
fill ~7 ~-33 ~31 ~9 ~-33 ~31 minecraft:iron_block
fill ~10 ~-33 ~31 ~12 ~-33 ~31 minecraft:air
fill ~13 ~-33 ~31 ~16 ~-33 ~31 minecraft:iron_block
setblock ~17 ~-33 ~31 minecraft:air
setblock ~18 ~-33 ~31 minecraft:light_gray_concrete
fill ~19 ~-33 ~31 ~21 ~-33 ~31 minecraft:air
setblock ~22 ~-33 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-33 ~31 ~45 ~-33 ~31 minecraft:air
setblock ~46 ~-33 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-33 ~31 ~49 ~-33 ~31 minecraft:air
setblock ~50 ~-33 ~31 minecraft:light_gray_concrete
fill ~51 ~-33 ~31 ~63 ~-33 ~31 minecraft:air
setblock ~64 ~-33 ~31 minecraft:light_gray_concrete
fill ~4 ~-33 ~32 ~18 ~-33 ~32 minecraft:light_gray_concrete
setblock ~19 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-33 ~32 minecraft:light_gray_concrete
setblock ~21 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-33 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-33 ~32 ~32 ~-33 ~32 minecraft:air
fill ~33 ~-33 ~32 ~35 ~-33 ~32 minecraft:glass
fill ~36 ~-33 ~32 ~45 ~-33 ~32 minecraft:air
setblock ~46 ~-33 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-33 ~32 minecraft:light_gray_concrete
setblock ~49 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~50 ~-33 ~32 minecraft:light_gray_concrete
fill ~51 ~-33 ~32 ~53 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~54 ~-33 ~32 minecraft:light_gray_concrete
fill ~55 ~-33 ~32 ~56 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
fill ~57 ~-33 ~32 ~58 ~-33 ~32 minecraft:light_gray_concrete
fill ~59 ~-33 ~32 ~61 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~62 ~-33 ~32 minecraft:light_gray_concrete
setblock ~63 ~-33 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~64 ~-33 ~32 minecraft:light_gray_concrete
setblock ~4 ~-33 ~33 minecraft:light_gray_concrete
fill ~5 ~-33 ~33 ~32 ~-33 ~33 minecraft:air
setblock ~33 ~-33 ~33 minecraft:glass
setblock ~34 ~-33 ~33 minecraft:air
setblock ~35 ~-33 ~33 minecraft:glass
fill ~36 ~-33 ~33 ~63 ~-33 ~33 minecraft:air
setblock ~64 ~-33 ~33 minecraft:light_gray_concrete
setblock ~4 ~-33 ~34 minecraft:light_gray_concrete
fill ~5 ~-33 ~34 ~32 ~-33 ~34 minecraft:air
fill ~33 ~-33 ~34 ~35 ~-33 ~34 minecraft:glass
fill ~36 ~-33 ~34 ~63 ~-33 ~34 minecraft:air
setblock ~64 ~-33 ~34 minecraft:light_gray_concrete
setblock ~4 ~-33 ~35 minecraft:light_gray_concrete
fill ~5 ~-33 ~35 ~32 ~-33 ~35 minecraft:air
setblock ~33 ~-33 ~35 minecraft:glass
setblock ~34 ~-33 ~35 minecraft:air
setblock ~35 ~-33 ~35 minecraft:glass
fill ~36 ~-33 ~35 ~63 ~-33 ~35 minecraft:air
setblock ~64 ~-33 ~35 minecraft:light_gray_concrete
fill ~4 ~-33 ~36 ~18 ~-33 ~36 minecraft:light_gray_concrete
setblock ~19 ~-33 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-33 ~36 minecraft:light_gray_concrete
setblock ~21 ~-33 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-33 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-33 ~36 ~32 ~-33 ~36 minecraft:air
fill ~33 ~-33 ~36 ~35 ~-33 ~36 minecraft:glass
fill ~36 ~-33 ~36 ~45 ~-33 ~36 minecraft:air
setblock ~46 ~-33 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-33 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-33 ~36 minecraft:light_gray_concrete
setblock ~49 ~-33 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-33 ~36 ~64 ~-33 ~36 minecraft:light_gray_concrete
setblock ~4 ~-33 ~37 minecraft:light_gray_concrete
fill ~5 ~-33 ~37 ~17 ~-33 ~37 minecraft:air
setblock ~18 ~-33 ~37 minecraft:light_gray_concrete
fill ~19 ~-33 ~37 ~21 ~-33 ~37 minecraft:air
setblock ~22 ~-33 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-33 ~37 ~45 ~-33 ~37 minecraft:air
setblock ~46 ~-33 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-33 ~37 ~49 ~-33 ~37 minecraft:air
setblock ~50 ~-33 ~37 minecraft:light_gray_concrete
fill ~51 ~-33 ~37 ~53 ~-33 ~37 minecraft:packed_ice
setblock ~54 ~-33 ~37 minecraft:air
setblock ~55 ~-33 ~37 minecraft:packed_ice
fill ~56 ~-33 ~37 ~58 ~-33 ~37 minecraft:air
fill ~59 ~-33 ~37 ~61 ~-33 ~37 minecraft:packed_ice
setblock ~62 ~-33 ~37 minecraft:air
setblock ~63 ~-33 ~37 minecraft:packed_ice
setblock ~64 ~-33 ~37 minecraft:light_gray_concrete
setblock ~4 ~-33 ~38 minecraft:light_gray_concrete
fill ~5 ~-33 ~38 ~17 ~-33 ~38 minecraft:air
setblock ~18 ~-33 ~38 minecraft:light_gray_concrete
fill ~19 ~-33 ~38 ~21 ~-33 ~38 minecraft:air
setblock ~22 ~-33 ~38 minecraft:quartz_pillar
setblock ~23 ~-33 ~38 minecraft:air
setblock ~24 ~-33 ~38 minecraft:quartz_pillar
fill ~25 ~-33 ~38 ~43 ~-33 ~38 minecraft:air
setblock ~44 ~-33 ~38 minecraft:quartz_pillar
setblock ~45 ~-33 ~38 minecraft:air
setblock ~46 ~-33 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-33 ~38 ~49 ~-33 ~38 minecraft:air
setblock ~50 ~-33 ~38 minecraft:light_gray_concrete
setblock ~51 ~-33 ~38 minecraft:packed_ice
fill ~52 ~-33 ~38 ~62 ~-33 ~38 minecraft:air
setblock ~63 ~-33 ~38 minecraft:packed_ice
setblock ~64 ~-33 ~38 minecraft:light_gray_concrete
setblock ~4 ~-33 ~39 minecraft:light_gray_concrete
fill ~5 ~-33 ~39 ~17 ~-33 ~39 minecraft:air
setblock ~18 ~-33 ~39 minecraft:light_gray_concrete
fill ~19 ~-33 ~39 ~21 ~-33 ~39 minecraft:air
setblock ~22 ~-33 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-33 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-33 ~39 ~44 ~-33 ~39 minecraft:air
fill ~45 ~-33 ~39 ~46 ~-33 ~39 minecraft:quartz_pillar
fill ~47 ~-33 ~39 ~49 ~-33 ~39 minecraft:air
setblock ~50 ~-33 ~39 minecraft:light_gray_concrete
setblock ~51 ~-33 ~39 minecraft:packed_ice
fill ~52 ~-33 ~39 ~62 ~-33 ~39 minecraft:air
setblock ~63 ~-33 ~39 minecraft:packed_ice
setblock ~64 ~-33 ~39 minecraft:light_gray_concrete
setblock ~4 ~-33 ~40 minecraft:light_gray_concrete
fill ~5 ~-33 ~40 ~17 ~-33 ~40 minecraft:air
setblock ~18 ~-33 ~40 minecraft:light_gray_concrete
fill ~19 ~-33 ~40 ~22 ~-33 ~40 minecraft:air
setblock ~23 ~-33 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-33 ~40 ~44 ~-33 ~40 minecraft:air
setblock ~45 ~-33 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-33 ~40 ~49 ~-33 ~40 minecraft:air
setblock ~50 ~-33 ~40 minecraft:light_gray_concrete
fill ~51 ~-33 ~40 ~63 ~-33 ~40 minecraft:air
setblock ~64 ~-33 ~40 minecraft:light_gray_concrete
setblock ~4 ~-33 ~41 minecraft:light_gray_concrete
fill ~5 ~-33 ~41 ~17 ~-33 ~41 minecraft:air
setblock ~18 ~-33 ~41 minecraft:light_gray_concrete
fill ~19 ~-33 ~41 ~23 ~-33 ~41 minecraft:air
setblock ~24 ~-33 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-33 ~41 ~43 ~-33 ~41 minecraft:air
setblock ~44 ~-33 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-33 ~41 ~49 ~-33 ~41 minecraft:air
setblock ~50 ~-33 ~41 minecraft:light_gray_concrete
setblock ~51 ~-33 ~41 minecraft:packed_ice
fill ~52 ~-33 ~41 ~62 ~-33 ~41 minecraft:air
setblock ~63 ~-33 ~41 minecraft:packed_ice
setblock ~64 ~-33 ~41 minecraft:light_gray_concrete
setblock ~4 ~-33 ~42 minecraft:light_gray_concrete
fill ~5 ~-33 ~42 ~17 ~-33 ~42 minecraft:air
setblock ~18 ~-33 ~42 minecraft:light_gray_concrete
fill ~19 ~-33 ~42 ~23 ~-33 ~42 minecraft:air
setblock ~24 ~-33 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-33 ~42 minecraft:quartz_pillar
fill ~26 ~-33 ~42 ~42 ~-33 ~42 minecraft:air
setblock ~43 ~-33 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-33 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-33 ~42 ~49 ~-33 ~42 minecraft:air
setblock ~50 ~-33 ~42 minecraft:light_gray_concrete
setblock ~51 ~-33 ~42 minecraft:packed_ice
fill ~52 ~-33 ~42 ~62 ~-33 ~42 minecraft:air
setblock ~63 ~-33 ~42 minecraft:packed_ice
setblock ~64 ~-33 ~42 minecraft:light_gray_concrete
setblock ~4 ~-33 ~43 minecraft:light_gray_concrete
fill ~5 ~-33 ~43 ~17 ~-33 ~43 minecraft:air
setblock ~18 ~-33 ~43 minecraft:light_gray_concrete
fill ~19 ~-33 ~43 ~20 ~-33 ~43 minecraft:air
setblock ~21 ~-33 ~43 minecraft:iron_bars[south=true]
fill ~22 ~-33 ~43 ~24 ~-33 ~43 minecraft:air
setblock ~25 ~-33 ~43 minecraft:quartz_pillar
setblock ~26 ~-33 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-33 ~43 ~41 ~-33 ~43 minecraft:air
fill ~42 ~-33 ~43 ~43 ~-33 ~43 minecraft:quartz_pillar
fill ~44 ~-33 ~43 ~49 ~-33 ~43 minecraft:air
setblock ~50 ~-33 ~43 minecraft:light_gray_concrete
setblock ~51 ~-33 ~43 minecraft:packed_ice
fill ~52 ~-33 ~43 ~62 ~-33 ~43 minecraft:air
setblock ~63 ~-33 ~43 minecraft:packed_ice
setblock ~64 ~-33 ~43 minecraft:light_gray_concrete
setblock ~4 ~-33 ~44 minecraft:light_gray_concrete
fill ~5 ~-33 ~44 ~17 ~-33 ~44 minecraft:air
setblock ~18 ~-33 ~44 minecraft:light_gray_concrete
fill ~19 ~-33 ~44 ~20 ~-33 ~44 minecraft:air
setblock ~21 ~-33 ~44 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-33 ~44 ~25 ~-33 ~44 minecraft:air
setblock ~26 ~-33 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-33 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-33 ~44 ~29 ~-33 ~44 minecraft:air
setblock ~30 ~-33 ~44 minecraft:quartz_pillar
fill ~31 ~-33 ~44 ~37 ~-33 ~44 minecraft:air
setblock ~38 ~-33 ~44 minecraft:quartz_pillar
fill ~39 ~-33 ~44 ~40 ~-33 ~44 minecraft:air
setblock ~41 ~-33 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-33 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-33 ~44 ~49 ~-33 ~44 minecraft:air
setblock ~50 ~-33 ~44 minecraft:light_gray_concrete
fill ~51 ~-33 ~44 ~63 ~-33 ~44 minecraft:air
setblock ~64 ~-33 ~44 minecraft:light_gray_concrete
setblock ~4 ~-33 ~45 minecraft:light_gray_concrete
fill ~5 ~-33 ~45 ~17 ~-33 ~45 minecraft:air
setblock ~18 ~-33 ~45 minecraft:light_gray_concrete
fill ~19 ~-33 ~45 ~20 ~-33 ~45 minecraft:air
setblock ~21 ~-33 ~45 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~22 ~-33 ~45 minecraft:iron_bars[west=true]
fill ~23 ~-33 ~45 ~27 ~-33 ~45 minecraft:air
setblock ~28 ~-33 ~45 minecraft:smooth_quartz
setblock ~29 ~-33 ~45 minecraft:quartz_pillar
fill ~30 ~-33 ~45 ~38 ~-33 ~45 minecraft:air
setblock ~39 ~-33 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-33 ~45 minecraft:smooth_quartz
fill ~41 ~-33 ~45 ~49 ~-33 ~45 minecraft:air
setblock ~50 ~-33 ~45 minecraft:light_gray_concrete
setblock ~51 ~-33 ~45 minecraft:packed_ice
fill ~52 ~-33 ~45 ~62 ~-33 ~45 minecraft:air
setblock ~63 ~-33 ~45 minecraft:packed_ice
setblock ~64 ~-33 ~45 minecraft:light_gray_concrete
setblock ~4 ~-33 ~46 minecraft:light_gray_concrete
fill ~5 ~-33 ~46 ~17 ~-33 ~46 minecraft:air
setblock ~18 ~-33 ~46 minecraft:light_gray_concrete
fill ~19 ~-33 ~46 ~20 ~-33 ~46 minecraft:air
setblock ~21 ~-33 ~46 minecraft:iron_bars[north=true,south=true]
setblock ~22 ~-33 ~46 minecraft:air
setblock ~23 ~-33 ~46 minecraft:iron_bars[south=true]
fill ~24 ~-33 ~46 ~28 ~-33 ~46 minecraft:air
setblock ~29 ~-33 ~46 minecraft:quartz_pillar
fill ~30 ~-33 ~46 ~31 ~-33 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-33 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-33 ~46 ~35 ~-33 ~46 minecraft:air
setblock ~36 ~-33 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-33 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-33 ~46 minecraft:quartz_pillar
setblock ~39 ~-33 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-33 ~46 ~41 ~-33 ~46 minecraft:air
setblock ~42 ~-33 ~46 minecraft:iron_bars[east=true]
fill ~43 ~-33 ~46 ~44 ~-33 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-33 ~46 minecraft:iron_bars[east=true,south=true,west=true]
fill ~46 ~-33 ~46 ~48 ~-33 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~49 ~-33 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~50 ~-33 ~46 minecraft:light_gray_concrete
setblock ~51 ~-33 ~46 minecraft:packed_ice
fill ~52 ~-33 ~46 ~62 ~-33 ~46 minecraft:air
setblock ~63 ~-33 ~46 minecraft:packed_ice
setblock ~64 ~-33 ~46 minecraft:light_gray_concrete
setblock ~4 ~-33 ~47 minecraft:light_gray_concrete
fill ~5 ~-33 ~47 ~17 ~-33 ~47 minecraft:air
setblock ~18 ~-33 ~47 minecraft:light_gray_concrete
fill ~19 ~-33 ~47 ~20 ~-33 ~47 minecraft:air
setblock ~21 ~-33 ~47 minecraft:iron_bars[north=true,east=true]
setblock ~22 ~-33 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-33 ~47 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-33 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-33 ~47 minecraft:iron_bars[west=true]
fill ~26 ~-33 ~47 ~31 ~-33 ~47 minecraft:air
setblock ~32 ~-33 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-33 ~47 ~35 ~-33 ~47 minecraft:air
setblock ~36 ~-33 ~47 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~47 ~40 ~-33 ~47 minecraft:air
setblock ~41 ~-33 ~47 minecraft:iron_bars[south=true]
fill ~42 ~-33 ~47 ~44 ~-33 ~47 minecraft:air
setblock ~45 ~-33 ~47 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-33 ~47 ~48 ~-33 ~47 minecraft:air
setblock ~49 ~-33 ~47 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-33 ~47 minecraft:light_gray_concrete
setblock ~51 ~-33 ~47 minecraft:packed_ice
fill ~52 ~-33 ~47 ~62 ~-33 ~47 minecraft:air
setblock ~63 ~-33 ~47 minecraft:packed_ice
setblock ~64 ~-33 ~47 minecraft:light_gray_concrete
setblock ~4 ~-33 ~48 minecraft:light_gray_concrete
fill ~5 ~-33 ~48 ~17 ~-33 ~48 minecraft:air
setblock ~18 ~-33 ~48 minecraft:light_gray_concrete
fill ~19 ~-33 ~48 ~31 ~-33 ~48 minecraft:air
setblock ~32 ~-33 ~48 minecraft:light_gray_concrete
fill ~33 ~-33 ~48 ~35 ~-33 ~48 minecraft:air
setblock ~36 ~-33 ~48 minecraft:light_gray_concrete
fill ~37 ~-33 ~48 ~40 ~-33 ~48 minecraft:air
setblock ~41 ~-33 ~48 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-33 ~48 ~44 ~-33 ~48 minecraft:air
setblock ~45 ~-33 ~48 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-33 ~48 ~48 ~-33 ~48 minecraft:air
setblock ~49 ~-33 ~48 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-33 ~48 minecraft:light_gray_concrete
fill ~51 ~-33 ~48 ~63 ~-33 ~48 minecraft:air
setblock ~64 ~-33 ~48 minecraft:light_gray_concrete
setblock ~4 ~-33 ~49 minecraft:light_gray_concrete
fill ~5 ~-33 ~49 ~17 ~-33 ~49 minecraft:air
setblock ~18 ~-33 ~49 minecraft:light_gray_concrete
fill ~19 ~-33 ~49 ~31 ~-33 ~49 minecraft:air
setblock ~32 ~-33 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-33 ~49 ~35 ~-33 ~49 minecraft:air
setblock ~36 ~-33 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~49 ~40 ~-33 ~49 minecraft:air
setblock ~41 ~-33 ~49 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-33 ~49 ~44 ~-33 ~49 minecraft:air
setblock ~45 ~-33 ~49 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-33 ~49 ~48 ~-33 ~49 minecraft:air
setblock ~49 ~-33 ~49 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-33 ~49 minecraft:light_gray_concrete
fill ~51 ~-33 ~49 ~53 ~-33 ~49 minecraft:packed_ice
setblock ~54 ~-33 ~49 minecraft:air
setblock ~55 ~-33 ~49 minecraft:packed_ice
fill ~56 ~-33 ~49 ~58 ~-33 ~49 minecraft:air
fill ~59 ~-33 ~49 ~61 ~-33 ~49 minecraft:packed_ice
setblock ~62 ~-33 ~49 minecraft:air
setblock ~63 ~-33 ~49 minecraft:packed_ice
setblock ~64 ~-33 ~49 minecraft:light_gray_concrete
fill ~4 ~-33 ~50 ~32 ~-33 ~50 minecraft:light_gray_concrete
fill ~33 ~-33 ~50 ~35 ~-33 ~50 minecraft:air
fill ~36 ~-33 ~50 ~64 ~-33 ~50 minecraft:light_gray_concrete
setblock ~4 ~-33 ~51 minecraft:light_gray_concrete
fill ~5 ~-33 ~51 ~17 ~-33 ~51 minecraft:air
setblock ~18 ~-33 ~51 minecraft:light_gray_concrete
fill ~19 ~-33 ~51 ~31 ~-33 ~51 minecraft:air
setblock ~32 ~-33 ~51 minecraft:light_gray_concrete
fill ~33 ~-33 ~51 ~35 ~-33 ~51 minecraft:air
setblock ~36 ~-33 ~51 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~51 ~49 ~-33 ~51 minecraft:air
setblock ~50 ~-33 ~51 minecraft:light_gray_concrete
fill ~51 ~-33 ~51 ~63 ~-33 ~51 minecraft:air
setblock ~64 ~-33 ~51 minecraft:light_gray_concrete
setblock ~4 ~-33 ~52 minecraft:light_gray_concrete
setblock ~5 ~-33 ~52 minecraft:iron_block
setblock ~6 ~-33 ~52 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~52 ~15 ~-33 ~52 minecraft:air
setblock ~16 ~-33 ~52 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~52 minecraft:iron_block
setblock ~18 ~-33 ~52 minecraft:light_gray_concrete
setblock ~19 ~-33 ~52 minecraft:air
fill ~20 ~-33 ~52 ~23 ~-33 ~52 minecraft:barrel
setblock ~24 ~-33 ~52 minecraft:air
fill ~25 ~-33 ~52 ~28 ~-33 ~52 minecraft:barrel
setblock ~29 ~-33 ~52 minecraft:air
setblock ~30 ~-33 ~52 minecraft:barrel
setblock ~31 ~-33 ~52 minecraft:air
setblock ~32 ~-33 ~52 minecraft:light_gray_concrete
fill ~33 ~-33 ~52 ~35 ~-33 ~52 minecraft:air
setblock ~36 ~-33 ~52 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~52 ~49 ~-33 ~52 minecraft:air
setblock ~50 ~-33 ~52 minecraft:light_gray_concrete
fill ~51 ~-33 ~52 ~63 ~-33 ~52 minecraft:air
setblock ~64 ~-33 ~52 minecraft:light_gray_concrete
setblock ~4 ~-33 ~53 minecraft:light_gray_concrete
setblock ~5 ~-33 ~53 minecraft:iron_block
setblock ~6 ~-33 ~53 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~53 ~15 ~-33 ~53 minecraft:air
setblock ~16 ~-33 ~53 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~53 minecraft:iron_block
setblock ~18 ~-33 ~53 minecraft:light_gray_concrete
fill ~19 ~-33 ~53 ~31 ~-33 ~53 minecraft:air
setblock ~32 ~-33 ~53 minecraft:light_gray_concrete
fill ~33 ~-33 ~53 ~35 ~-33 ~53 minecraft:air
setblock ~36 ~-33 ~53 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~53 ~49 ~-33 ~53 minecraft:air
setblock ~50 ~-33 ~53 minecraft:light_gray_concrete
fill ~51 ~-33 ~53 ~63 ~-33 ~53 minecraft:air
setblock ~64 ~-33 ~53 minecraft:light_gray_concrete
setblock ~4 ~-33 ~54 minecraft:light_gray_concrete
setblock ~5 ~-33 ~54 minecraft:iron_block
setblock ~6 ~-33 ~54 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~54 ~15 ~-33 ~54 minecraft:air
setblock ~16 ~-33 ~54 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~54 minecraft:iron_block
setblock ~18 ~-33 ~54 minecraft:light_gray_concrete
fill ~19 ~-33 ~54 ~31 ~-33 ~54 minecraft:air
setblock ~32 ~-33 ~54 minecraft:light_gray_concrete
fill ~33 ~-33 ~54 ~35 ~-33 ~54 minecraft:air
setblock ~36 ~-33 ~54 minecraft:light_gray_concrete
fill ~37 ~-33 ~54 ~39 ~-33 ~54 minecraft:air
setblock ~40 ~-33 ~54 minecraft:white_stained_glass_pane
fill ~41 ~-33 ~54 ~42 ~-33 ~54 minecraft:air
setblock ~43 ~-33 ~54 minecraft:white_stained_glass_pane
fill ~44 ~-33 ~54 ~45 ~-33 ~54 minecraft:air
setblock ~46 ~-33 ~54 minecraft:white_stained_glass_pane
fill ~47 ~-33 ~54 ~48 ~-33 ~54 minecraft:air
setblock ~49 ~-33 ~54 minecraft:white_stained_glass_pane[east=true]
setblock ~50 ~-33 ~54 minecraft:light_gray_concrete
fill ~51 ~-33 ~54 ~63 ~-33 ~54 minecraft:air
setblock ~64 ~-33 ~54 minecraft:light_gray_concrete
setblock ~4 ~-33 ~55 minecraft:light_gray_concrete
setblock ~5 ~-33 ~55 minecraft:iron_block
setblock ~6 ~-33 ~55 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~55 ~15 ~-33 ~55 minecraft:air
setblock ~16 ~-33 ~55 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~55 minecraft:iron_block
setblock ~18 ~-33 ~55 minecraft:light_gray_concrete
setblock ~19 ~-33 ~55 minecraft:air
fill ~20 ~-33 ~55 ~23 ~-33 ~55 minecraft:barrel
setblock ~24 ~-33 ~55 minecraft:air
fill ~25 ~-33 ~55 ~28 ~-33 ~55 minecraft:barrel
setblock ~29 ~-33 ~55 minecraft:air
setblock ~30 ~-33 ~55 minecraft:barrel
setblock ~31 ~-33 ~55 minecraft:air
setblock ~32 ~-33 ~55 minecraft:light_gray_concrete
fill ~33 ~-33 ~55 ~35 ~-33 ~55 minecraft:air
setblock ~36 ~-33 ~55 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~55 ~38 ~-33 ~55 minecraft:air
setblock ~39 ~-33 ~55 minecraft:white_stained_glass_pane
fill ~40 ~-33 ~55 ~41 ~-33 ~55 minecraft:air
setblock ~42 ~-33 ~55 minecraft:white_stained_glass_pane
fill ~43 ~-33 ~55 ~44 ~-33 ~55 minecraft:air
setblock ~45 ~-33 ~55 minecraft:white_stained_glass_pane
fill ~46 ~-33 ~55 ~47 ~-33 ~55 minecraft:air
setblock ~48 ~-33 ~55 minecraft:white_stained_glass_pane
setblock ~49 ~-33 ~55 minecraft:air
setblock ~50 ~-33 ~55 minecraft:light_gray_concrete
fill ~51 ~-33 ~55 ~63 ~-33 ~55 minecraft:air
setblock ~64 ~-33 ~55 minecraft:light_gray_concrete
setblock ~4 ~-33 ~56 minecraft:light_gray_concrete
setblock ~5 ~-33 ~56 minecraft:iron_block
setblock ~6 ~-33 ~56 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~56 ~17 ~-33 ~56 minecraft:air
setblock ~18 ~-33 ~56 minecraft:light_gray_concrete
fill ~19 ~-33 ~56 ~31 ~-33 ~56 minecraft:air
setblock ~32 ~-33 ~56 minecraft:light_gray_concrete
fill ~33 ~-33 ~56 ~35 ~-33 ~56 minecraft:air
setblock ~36 ~-33 ~56 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~56 ~49 ~-33 ~56 minecraft:air
setblock ~50 ~-33 ~56 minecraft:light_gray_concrete
fill ~51 ~-33 ~56 ~63 ~-33 ~56 minecraft:air
setblock ~64 ~-33 ~56 minecraft:light_gray_concrete
setblock ~4 ~-33 ~57 minecraft:light_gray_concrete
setblock ~5 ~-33 ~57 minecraft:iron_block
setblock ~6 ~-33 ~57 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~57 ~17 ~-33 ~57 minecraft:air
setblock ~18 ~-33 ~57 minecraft:light_gray_concrete
fill ~19 ~-33 ~57 ~31 ~-33 ~57 minecraft:air
setblock ~32 ~-33 ~57 minecraft:light_gray_concrete
fill ~33 ~-33 ~57 ~35 ~-33 ~57 minecraft:air
setblock ~36 ~-33 ~57 minecraft:light_gray_concrete
fill ~37 ~-33 ~57 ~39 ~-33 ~57 minecraft:air
setblock ~40 ~-33 ~57 minecraft:white_stained_glass_pane
fill ~41 ~-33 ~57 ~42 ~-33 ~57 minecraft:air
setblock ~43 ~-33 ~57 minecraft:white_stained_glass_pane
fill ~44 ~-33 ~57 ~45 ~-33 ~57 minecraft:air
setblock ~46 ~-33 ~57 minecraft:white_stained_glass_pane
fill ~47 ~-33 ~57 ~49 ~-33 ~57 minecraft:air
setblock ~50 ~-33 ~57 minecraft:light_gray_concrete
fill ~51 ~-33 ~57 ~63 ~-33 ~57 minecraft:air
setblock ~64 ~-33 ~57 minecraft:light_gray_concrete
setblock ~4 ~-33 ~58 minecraft:light_gray_concrete
setblock ~5 ~-33 ~58 minecraft:iron_block
setblock ~6 ~-33 ~58 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~58 ~17 ~-33 ~58 minecraft:air
setblock ~18 ~-33 ~58 minecraft:light_gray_concrete
setblock ~19 ~-33 ~58 minecraft:air
fill ~20 ~-33 ~58 ~23 ~-33 ~58 minecraft:barrel
setblock ~24 ~-33 ~58 minecraft:air
fill ~25 ~-33 ~58 ~28 ~-33 ~58 minecraft:barrel
setblock ~29 ~-33 ~58 minecraft:air
setblock ~30 ~-33 ~58 minecraft:barrel
setblock ~31 ~-33 ~58 minecraft:air
setblock ~32 ~-33 ~58 minecraft:light_gray_concrete
fill ~33 ~-33 ~58 ~35 ~-33 ~58 minecraft:air
setblock ~36 ~-33 ~58 minecraft:light_gray_concrete
fill ~37 ~-33 ~58 ~38 ~-33 ~58 minecraft:air
setblock ~39 ~-33 ~58 minecraft:white_stained_glass_pane
fill ~40 ~-33 ~58 ~41 ~-33 ~58 minecraft:air
setblock ~42 ~-33 ~58 minecraft:white_stained_glass_pane
fill ~43 ~-33 ~58 ~44 ~-33 ~58 minecraft:air
setblock ~45 ~-33 ~58 minecraft:white_stained_glass_pane
fill ~46 ~-33 ~58 ~49 ~-33 ~58 minecraft:air
setblock ~50 ~-33 ~58 minecraft:light_gray_concrete
fill ~51 ~-33 ~58 ~63 ~-33 ~58 minecraft:air
setblock ~64 ~-33 ~58 minecraft:light_gray_concrete
setblock ~4 ~-33 ~59 minecraft:light_gray_concrete
setblock ~5 ~-33 ~59 minecraft:iron_block
setblock ~6 ~-33 ~59 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~59 ~15 ~-33 ~59 minecraft:air
setblock ~16 ~-33 ~59 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~59 minecraft:iron_block
setblock ~18 ~-33 ~59 minecraft:light_gray_concrete
fill ~19 ~-33 ~59 ~31 ~-33 ~59 minecraft:air
setblock ~32 ~-33 ~59 minecraft:light_gray_concrete
fill ~33 ~-33 ~59 ~35 ~-33 ~59 minecraft:air
setblock ~36 ~-33 ~59 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~59 ~49 ~-33 ~59 minecraft:air
setblock ~50 ~-33 ~59 minecraft:light_gray_concrete
fill ~51 ~-33 ~59 ~63 ~-33 ~59 minecraft:air
setblock ~64 ~-33 ~59 minecraft:light_gray_concrete
setblock ~4 ~-33 ~60 minecraft:light_gray_concrete
setblock ~5 ~-33 ~60 minecraft:iron_block
setblock ~6 ~-33 ~60 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~60 ~15 ~-33 ~60 minecraft:air
setblock ~16 ~-33 ~60 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~60 minecraft:iron_block
setblock ~18 ~-33 ~60 minecraft:light_gray_concrete
fill ~19 ~-33 ~60 ~31 ~-33 ~60 minecraft:air
setblock ~32 ~-33 ~60 minecraft:light_gray_concrete
fill ~33 ~-33 ~60 ~35 ~-33 ~60 minecraft:air
setblock ~36 ~-33 ~60 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~60 ~39 ~-33 ~60 minecraft:air
setblock ~40 ~-33 ~60 minecraft:white_stained_glass_pane
fill ~41 ~-33 ~60 ~42 ~-33 ~60 minecraft:air
setblock ~43 ~-33 ~60 minecraft:white_stained_glass_pane
fill ~44 ~-33 ~60 ~45 ~-33 ~60 minecraft:air
setblock ~46 ~-33 ~60 minecraft:white_stained_glass_pane
fill ~47 ~-33 ~60 ~48 ~-33 ~60 minecraft:air
setblock ~49 ~-33 ~60 minecraft:white_stained_glass_pane[east=true]
setblock ~50 ~-33 ~60 minecraft:light_gray_concrete
fill ~51 ~-33 ~60 ~63 ~-33 ~60 minecraft:air
setblock ~64 ~-33 ~60 minecraft:light_gray_concrete
setblock ~4 ~-33 ~61 minecraft:light_gray_concrete
setblock ~5 ~-33 ~61 minecraft:iron_block
setblock ~6 ~-33 ~61 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~61 ~15 ~-33 ~61 minecraft:air
setblock ~16 ~-33 ~61 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~61 minecraft:iron_block
setblock ~18 ~-33 ~61 minecraft:light_gray_concrete
setblock ~19 ~-33 ~61 minecraft:air
fill ~20 ~-33 ~61 ~23 ~-33 ~61 minecraft:barrel
setblock ~24 ~-33 ~61 minecraft:air
fill ~25 ~-33 ~61 ~28 ~-33 ~61 minecraft:barrel
setblock ~29 ~-33 ~61 minecraft:air
setblock ~30 ~-33 ~61 minecraft:barrel
setblock ~31 ~-33 ~61 minecraft:air
setblock ~32 ~-33 ~61 minecraft:light_gray_concrete
fill ~33 ~-33 ~61 ~35 ~-33 ~61 minecraft:air
setblock ~36 ~-33 ~61 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~61 ~38 ~-33 ~61 minecraft:air
setblock ~39 ~-33 ~61 minecraft:white_stained_glass_pane
fill ~40 ~-33 ~61 ~41 ~-33 ~61 minecraft:air
setblock ~42 ~-33 ~61 minecraft:white_stained_glass_pane
fill ~43 ~-33 ~61 ~44 ~-33 ~61 minecraft:air
setblock ~45 ~-33 ~61 minecraft:white_stained_glass_pane
fill ~46 ~-33 ~61 ~47 ~-33 ~61 minecraft:air
setblock ~48 ~-33 ~61 minecraft:white_stained_glass_pane
setblock ~49 ~-33 ~61 minecraft:air
setblock ~50 ~-33 ~61 minecraft:light_gray_concrete
fill ~51 ~-33 ~61 ~63 ~-33 ~61 minecraft:air
setblock ~64 ~-33 ~61 minecraft:light_gray_concrete
setblock ~4 ~-33 ~62 minecraft:light_gray_concrete
setblock ~5 ~-33 ~62 minecraft:iron_block
setblock ~6 ~-33 ~62 minecraft:iron_trapdoor[open=true,facing=east]
fill ~7 ~-33 ~62 ~15 ~-33 ~62 minecraft:iron_trapdoor[open=true,facing=north]
setblock ~16 ~-33 ~62 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~62 minecraft:iron_block
setblock ~18 ~-33 ~62 minecraft:light_gray_concrete
fill ~19 ~-33 ~62 ~31 ~-33 ~62 minecraft:air
setblock ~32 ~-33 ~62 minecraft:light_gray_concrete
fill ~33 ~-33 ~62 ~35 ~-33 ~62 minecraft:air
setblock ~36 ~-33 ~62 minecraft:light_gray_concrete
fill ~37 ~-33 ~62 ~49 ~-33 ~62 minecraft:air
setblock ~50 ~-33 ~62 minecraft:light_gray_concrete
fill ~51 ~-33 ~62 ~63 ~-33 ~62 minecraft:air
setblock ~64 ~-33 ~62 minecraft:light_gray_concrete
setblock ~4 ~-33 ~63 minecraft:light_gray_concrete
fill ~5 ~-33 ~63 ~6 ~-33 ~63 minecraft:air
fill ~7 ~-33 ~63 ~15 ~-33 ~63 minecraft:iron_block
setblock ~16 ~-33 ~63 minecraft:iron_trapdoor[open=true,facing=west]
setblock ~17 ~-33 ~63 minecraft:iron_block
setblock ~18 ~-33 ~63 minecraft:light_gray_concrete
fill ~19 ~-33 ~63 ~31 ~-33 ~63 minecraft:air
setblock ~32 ~-33 ~63 minecraft:light_gray_concrete
fill ~33 ~-33 ~63 ~35 ~-33 ~63 minecraft:air
setblock ~36 ~-33 ~63 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-33 ~63 ~49 ~-33 ~63 minecraft:air
setblock ~50 ~-33 ~63 minecraft:light_gray_concrete
fill ~51 ~-33 ~63 ~63 ~-33 ~63 minecraft:air
setblock ~64 ~-33 ~63 minecraft:light_gray_concrete
fill ~4 ~-33 ~64 ~64 ~-33 ~64 minecraft:light_gray_concrete
setblock ~34 ~-33 ~65 minecraft:light_gray_concrete
fill ~32 ~-33 ~66 ~36 ~-33 ~66 minecraft:polished_andesite
setblock ~32 ~-33 ~67 minecraft:polished_andesite
fill ~33 ~-33 ~67 ~35 ~-33 ~67 minecraft:air
setblock ~36 ~-33 ~67 minecraft:polished_andesite
setblock ~32 ~-33 ~68 minecraft:polished_andesite
setblock ~33 ~-33 ~68 minecraft:air
setblock ~34 ~-33 ~68 minecraft:quartz_pillar
setblock ~35 ~-33 ~68 minecraft:air
setblock ~36 ~-33 ~68 minecraft:polished_andesite
setblock ~32 ~-33 ~69 minecraft:polished_andesite
fill ~33 ~-33 ~69 ~34 ~-33 ~69 minecraft:air
setblock ~35 ~-33 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~36 ~-33 ~69 minecraft:polished_andesite
fill ~32 ~-33 ~70 ~36 ~-33 ~70 minecraft:polished_andesite
fill ~4 ~-32 ~4 ~64 ~-32 ~4 minecraft:light_gray_concrete
setblock ~4 ~-32 ~5 minecraft:light_gray_concrete
fill ~5 ~-32 ~5 ~17 ~-32 ~5 minecraft:air
setblock ~18 ~-32 ~5 minecraft:light_gray_concrete
fill ~19 ~-32 ~5 ~31 ~-32 ~5 minecraft:air
setblock ~32 ~-32 ~5 minecraft:light_gray_concrete
fill ~33 ~-32 ~5 ~35 ~-32 ~5 minecraft:air
setblock ~36 ~-32 ~5 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~5 ~49 ~-32 ~5 minecraft:air
setblock ~50 ~-32 ~5 minecraft:light_gray_concrete
setblock ~51 ~-32 ~5 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-32 ~5 ~54 ~-32 ~5 minecraft:air
setblock ~55 ~-32 ~5 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-32 ~5 ~58 ~-32 ~5 minecraft:air
setblock ~59 ~-32 ~5 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-32 ~5 ~62 ~-32 ~5 minecraft:air
setblock ~63 ~-32 ~5 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-32 ~5 minecraft:light_gray_concrete
setblock ~4 ~-32 ~6 minecraft:light_gray_concrete
fill ~5 ~-32 ~6 ~17 ~-32 ~6 minecraft:air
setblock ~18 ~-32 ~6 minecraft:light_gray_concrete
fill ~19 ~-32 ~6 ~31 ~-32 ~6 minecraft:air
setblock ~32 ~-32 ~6 minecraft:light_gray_concrete
fill ~33 ~-32 ~6 ~35 ~-32 ~6 minecraft:air
setblock ~36 ~-32 ~6 minecraft:light_gray_concrete
fill ~37 ~-32 ~6 ~49 ~-32 ~6 minecraft:air
setblock ~50 ~-32 ~6 minecraft:light_gray_concrete
setblock ~51 ~-32 ~6 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-32 ~6 ~54 ~-32 ~6 minecraft:air
setblock ~55 ~-32 ~6 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-32 ~6 ~58 ~-32 ~6 minecraft:air
setblock ~59 ~-32 ~6 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-32 ~6 ~62 ~-32 ~6 minecraft:air
setblock ~63 ~-32 ~6 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-32 ~6 minecraft:light_gray_concrete
setblock ~4 ~-32 ~7 minecraft:light_gray_concrete
fill ~5 ~-32 ~7 ~17 ~-32 ~7 minecraft:air
setblock ~18 ~-32 ~7 minecraft:light_gray_concrete
fill ~19 ~-32 ~7 ~31 ~-32 ~7 minecraft:air
setblock ~32 ~-32 ~7 minecraft:light_gray_concrete
fill ~33 ~-32 ~7 ~35 ~-32 ~7 minecraft:air
setblock ~36 ~-32 ~7 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~7 ~49 ~-32 ~7 minecraft:air
setblock ~50 ~-32 ~7 minecraft:light_gray_concrete
setblock ~51 ~-32 ~7 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-32 ~7 ~54 ~-32 ~7 minecraft:air
setblock ~55 ~-32 ~7 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-32 ~7 ~58 ~-32 ~7 minecraft:air
setblock ~59 ~-32 ~7 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-32 ~7 ~62 ~-32 ~7 minecraft:air
setblock ~63 ~-32 ~7 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-32 ~7 minecraft:light_gray_concrete
setblock ~4 ~-32 ~8 minecraft:light_gray_concrete
fill ~5 ~-32 ~8 ~17 ~-32 ~8 minecraft:air
setblock ~18 ~-32 ~8 minecraft:light_gray_concrete
fill ~19 ~-32 ~8 ~31 ~-32 ~8 minecraft:air
setblock ~32 ~-32 ~8 minecraft:light_gray_concrete
fill ~33 ~-32 ~8 ~35 ~-32 ~8 minecraft:air
setblock ~36 ~-32 ~8 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~8 ~49 ~-32 ~8 minecraft:air
setblock ~50 ~-32 ~8 minecraft:light_gray_concrete
setblock ~51 ~-32 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~52 ~-32 ~8 ~54 ~-32 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~55 ~-32 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~56 ~-32 ~8 ~58 ~-32 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~59 ~-32 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~60 ~-32 ~8 ~62 ~-32 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~63 ~-32 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~64 ~-32 ~8 minecraft:light_gray_concrete
setblock ~4 ~-32 ~9 minecraft:light_gray_concrete
fill ~5 ~-32 ~9 ~17 ~-32 ~9 minecraft:air
setblock ~18 ~-32 ~9 minecraft:light_gray_concrete
fill ~19 ~-32 ~9 ~31 ~-32 ~9 minecraft:air
setblock ~32 ~-32 ~9 minecraft:light_gray_concrete
fill ~33 ~-32 ~9 ~35 ~-32 ~9 minecraft:air
setblock ~36 ~-32 ~9 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~9 ~49 ~-32 ~9 minecraft:air
setblock ~50 ~-32 ~9 minecraft:light_gray_concrete
fill ~51 ~-32 ~9 ~63 ~-32 ~9 minecraft:air
setblock ~64 ~-32 ~9 minecraft:light_gray_concrete
setblock ~4 ~-32 ~10 minecraft:light_gray_concrete
fill ~5 ~-32 ~10 ~17 ~-32 ~10 minecraft:air
setblock ~18 ~-32 ~10 minecraft:light_gray_concrete
fill ~19 ~-32 ~10 ~31 ~-32 ~10 minecraft:air
setblock ~32 ~-32 ~10 minecraft:light_gray_concrete
fill ~33 ~-32 ~10 ~35 ~-32 ~10 minecraft:air
setblock ~36 ~-32 ~10 minecraft:light_gray_concrete
fill ~37 ~-32 ~10 ~49 ~-32 ~10 minecraft:air
setblock ~50 ~-32 ~10 minecraft:light_gray_concrete
fill ~51 ~-32 ~10 ~63 ~-32 ~10 minecraft:air
setblock ~64 ~-32 ~10 minecraft:light_gray_concrete
setblock ~4 ~-32 ~11 minecraft:light_gray_concrete
fill ~5 ~-32 ~11 ~17 ~-32 ~11 minecraft:air
setblock ~18 ~-32 ~11 minecraft:light_gray_concrete
fill ~19 ~-32 ~11 ~31 ~-32 ~11 minecraft:air
setblock ~32 ~-32 ~11 minecraft:light_gray_concrete
fill ~33 ~-32 ~11 ~35 ~-32 ~11 minecraft:air
setblock ~36 ~-32 ~11 minecraft:light_gray_concrete
fill ~37 ~-32 ~11 ~49 ~-32 ~11 minecraft:air
setblock ~50 ~-32 ~11 minecraft:light_gray_concrete
fill ~51 ~-32 ~11 ~63 ~-32 ~11 minecraft:air
setblock ~64 ~-32 ~11 minecraft:light_gray_concrete
setblock ~4 ~-32 ~12 minecraft:light_gray_concrete
fill ~5 ~-32 ~12 ~17 ~-32 ~12 minecraft:air
setblock ~18 ~-32 ~12 minecraft:light_gray_concrete
fill ~19 ~-32 ~12 ~31 ~-32 ~12 minecraft:air
setblock ~32 ~-32 ~12 minecraft:light_gray_concrete
fill ~33 ~-32 ~12 ~35 ~-32 ~12 minecraft:air
setblock ~36 ~-32 ~12 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~12 ~49 ~-32 ~12 minecraft:air
setblock ~50 ~-32 ~12 minecraft:light_gray_concrete
fill ~51 ~-32 ~12 ~63 ~-32 ~12 minecraft:air
setblock ~64 ~-32 ~12 minecraft:light_gray_concrete
setblock ~4 ~-32 ~13 minecraft:light_gray_concrete
fill ~5 ~-32 ~13 ~17 ~-32 ~13 minecraft:air
setblock ~18 ~-32 ~13 minecraft:light_gray_concrete
fill ~19 ~-32 ~13 ~31 ~-32 ~13 minecraft:air
setblock ~32 ~-32 ~13 minecraft:light_gray_concrete
fill ~33 ~-32 ~13 ~35 ~-32 ~13 minecraft:air
setblock ~36 ~-32 ~13 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~13 ~49 ~-32 ~13 minecraft:air
setblock ~50 ~-32 ~13 minecraft:light_gray_concrete
fill ~51 ~-32 ~13 ~63 ~-32 ~13 minecraft:air
setblock ~64 ~-32 ~13 minecraft:light_gray_concrete
setblock ~4 ~-32 ~14 minecraft:light_gray_concrete
fill ~5 ~-32 ~14 ~17 ~-32 ~14 minecraft:air
setblock ~18 ~-32 ~14 minecraft:light_gray_concrete
fill ~19 ~-32 ~14 ~31 ~-32 ~14 minecraft:air
setblock ~32 ~-32 ~14 minecraft:light_gray_concrete
fill ~33 ~-32 ~14 ~35 ~-32 ~14 minecraft:air
setblock ~36 ~-32 ~14 minecraft:light_gray_concrete
fill ~37 ~-32 ~14 ~49 ~-32 ~14 minecraft:air
setblock ~50 ~-32 ~14 minecraft:light_gray_concrete
fill ~51 ~-32 ~14 ~63 ~-32 ~14 minecraft:air
setblock ~64 ~-32 ~14 minecraft:light_gray_concrete
setblock ~4 ~-32 ~15 minecraft:light_gray_concrete
fill ~5 ~-32 ~15 ~17 ~-32 ~15 minecraft:air
setblock ~18 ~-32 ~15 minecraft:light_gray_concrete
fill ~19 ~-32 ~15 ~31 ~-32 ~15 minecraft:air
setblock ~32 ~-32 ~15 minecraft:light_gray_concrete
fill ~33 ~-32 ~15 ~35 ~-32 ~15 minecraft:air
setblock ~36 ~-32 ~15 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~15 ~49 ~-32 ~15 minecraft:air
setblock ~50 ~-32 ~15 minecraft:light_gray_concrete
fill ~51 ~-32 ~15 ~63 ~-32 ~15 minecraft:air
setblock ~64 ~-32 ~15 minecraft:light_gray_concrete
setblock ~4 ~-32 ~16 minecraft:light_gray_concrete
fill ~5 ~-32 ~16 ~17 ~-32 ~16 minecraft:air
setblock ~18 ~-32 ~16 minecraft:light_gray_concrete
fill ~19 ~-32 ~16 ~31 ~-32 ~16 minecraft:air
setblock ~32 ~-32 ~16 minecraft:light_gray_concrete
fill ~33 ~-32 ~16 ~35 ~-32 ~16 minecraft:air
setblock ~36 ~-32 ~16 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~16 ~49 ~-32 ~16 minecraft:air
setblock ~50 ~-32 ~16 minecraft:light_gray_concrete
fill ~51 ~-32 ~16 ~63 ~-32 ~16 minecraft:air
setblock ~64 ~-32 ~16 minecraft:light_gray_concrete
setblock ~4 ~-32 ~17 minecraft:light_gray_concrete
fill ~5 ~-32 ~17 ~17 ~-32 ~17 minecraft:air
setblock ~18 ~-32 ~17 minecraft:light_gray_concrete
fill ~19 ~-32 ~17 ~31 ~-32 ~17 minecraft:air
setblock ~32 ~-32 ~17 minecraft:light_gray_concrete
fill ~33 ~-32 ~17 ~35 ~-32 ~17 minecraft:air
setblock ~36 ~-32 ~17 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~17 ~49 ~-32 ~17 minecraft:air
setblock ~50 ~-32 ~17 minecraft:light_gray_concrete
fill ~51 ~-32 ~17 ~63 ~-32 ~17 minecraft:air
setblock ~64 ~-32 ~17 minecraft:light_gray_concrete
fill ~4 ~-32 ~18 ~32 ~-32 ~18 minecraft:light_gray_concrete
fill ~33 ~-32 ~18 ~35 ~-32 ~18 minecraft:air
fill ~36 ~-32 ~18 ~64 ~-32 ~18 minecraft:light_gray_concrete
setblock ~4 ~-32 ~19 minecraft:light_gray_concrete
fill ~5 ~-32 ~19 ~17 ~-32 ~19 minecraft:air
setblock ~18 ~-32 ~19 minecraft:light_gray_concrete
setblock ~19 ~-32 ~19 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-32 ~19 ~22 ~-32 ~19 minecraft:air
setblock ~23 ~-32 ~19 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-32 ~19 ~26 ~-32 ~19 minecraft:air
setblock ~27 ~-32 ~19 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-32 ~19 ~31 ~-32 ~19 minecraft:air
setblock ~32 ~-32 ~19 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-32 ~19 ~35 ~-32 ~19 minecraft:air
setblock ~36 ~-32 ~19 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~19 ~49 ~-32 ~19 minecraft:air
setblock ~50 ~-32 ~19 minecraft:light_gray_concrete
fill ~51 ~-32 ~19 ~63 ~-32 ~19 minecraft:air
setblock ~64 ~-32 ~19 minecraft:light_gray_concrete
setblock ~4 ~-32 ~20 minecraft:light_gray_concrete
fill ~5 ~-32 ~20 ~17 ~-32 ~20 minecraft:air
setblock ~18 ~-32 ~20 minecraft:light_gray_concrete
setblock ~19 ~-32 ~20 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-32 ~20 ~22 ~-32 ~20 minecraft:air
setblock ~23 ~-32 ~20 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-32 ~20 ~26 ~-32 ~20 minecraft:air
setblock ~27 ~-32 ~20 minecraft:iron_bars[north=true,south=true]
fill ~28 ~-32 ~20 ~31 ~-32 ~20 minecraft:air
setblock ~32 ~-32 ~20 minecraft:light_gray_concrete
fill ~33 ~-32 ~20 ~35 ~-32 ~20 minecraft:air
setblock ~36 ~-32 ~20 minecraft:light_gray_concrete
fill ~37 ~-32 ~20 ~49 ~-32 ~20 minecraft:air
setblock ~50 ~-32 ~20 minecraft:light_gray_concrete
fill ~51 ~-32 ~20 ~63 ~-32 ~20 minecraft:air
setblock ~64 ~-32 ~20 minecraft:light_gray_concrete
setblock ~4 ~-32 ~21 minecraft:light_gray_concrete
fill ~5 ~-32 ~21 ~17 ~-32 ~21 minecraft:air
setblock ~18 ~-32 ~21 minecraft:light_gray_concrete
setblock ~19 ~-32 ~21 minecraft:iron_bars[north=true,south=true,west=true]
fill ~20 ~-32 ~21 ~22 ~-32 ~21 minecraft:air
setblock ~23 ~-32 ~21 minecraft:iron_bars[north=true,south=true]
fill ~24 ~-32 ~21 ~26 ~-32 ~21 minecraft:air
setblock ~27 ~-32 ~21 minecraft:iron_bars[north=true]
fill ~28 ~-32 ~21 ~31 ~-32 ~21 minecraft:air
setblock ~32 ~-32 ~21 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-32 ~21 ~35 ~-32 ~21 minecraft:air
setblock ~36 ~-32 ~21 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~21 ~42 ~-32 ~21 minecraft:air
setblock ~43 ~-32 ~21 minecraft:iron_bars[east=true]
setblock ~44 ~-32 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-32 ~21 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~46 ~-32 ~21 minecraft:iron_bars[east=true,west=true]
setblock ~47 ~-32 ~21 minecraft:iron_bars[south=true,west=true]
fill ~48 ~-32 ~21 ~49 ~-32 ~21 minecraft:air
setblock ~50 ~-32 ~21 minecraft:light_gray_concrete
fill ~51 ~-32 ~21 ~63 ~-32 ~21 minecraft:air
setblock ~64 ~-32 ~21 minecraft:light_gray_concrete
setblock ~4 ~-32 ~22 minecraft:light_gray_concrete
fill ~5 ~-32 ~22 ~17 ~-32 ~22 minecraft:air
setblock ~18 ~-32 ~22 minecraft:light_gray_concrete
setblock ~19 ~-32 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~20 ~-32 ~22 ~22 ~-32 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-32 ~22 minecraft:iron_bars[north=true,east=true,west=true]
fill ~24 ~-32 ~22 ~25 ~-32 ~22 minecraft:iron_bars[east=true,west=true]
setblock ~26 ~-32 ~22 minecraft:iron_bars[west=true]
fill ~27 ~-32 ~22 ~28 ~-32 ~22 minecraft:air
setblock ~29 ~-32 ~22 minecraft:glass_pane[east=true,south=true]
setblock ~30 ~-32 ~22 minecraft:quartz_pillar
setblock ~31 ~-32 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-32 ~22 minecraft:glass_pane[north=true,west=true]
fill ~33 ~-32 ~22 ~35 ~-32 ~22 minecraft:air
setblock ~36 ~-32 ~22 minecraft:glass_pane[north=true,east=true]
fill ~37 ~-32 ~22 ~38 ~-32 ~22 minecraft:glass_pane[east=true,west=true]
setblock ~39 ~-32 ~22 minecraft:quartz_pillar
fill ~40 ~-32 ~22 ~44 ~-32 ~22 minecraft:air
setblock ~45 ~-32 ~22 minecraft:iron_bars[north=true]
setblock ~46 ~-32 ~22 minecraft:air
setblock ~47 ~-32 ~22 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-32 ~22 ~49 ~-32 ~22 minecraft:air
setblock ~50 ~-32 ~22 minecraft:light_gray_concrete
fill ~51 ~-32 ~22 ~63 ~-32 ~22 minecraft:air
setblock ~64 ~-32 ~22 minecraft:light_gray_concrete
setblock ~4 ~-32 ~23 minecraft:light_gray_concrete
fill ~5 ~-32 ~23 ~17 ~-32 ~23 minecraft:air
setblock ~18 ~-32 ~23 minecraft:light_gray_concrete
fill ~19 ~-32 ~23 ~27 ~-32 ~23 minecraft:air
setblock ~28 ~-32 ~23 minecraft:smooth_quartz
setblock ~29 ~-32 ~23 minecraft:glass_pane[north=true,west=true]
fill ~30 ~-32 ~23 ~38 ~-32 ~23 minecraft:air
setblock ~39 ~-32 ~23 minecraft:quartz_pillar
setblock ~40 ~-32 ~23 minecraft:smooth_quartz
fill ~41 ~-32 ~23 ~45 ~-32 ~23 minecraft:air
setblock ~46 ~-32 ~23 minecraft:iron_bars[east=true]
setblock ~47 ~-32 ~23 minecraft:iron_bars[north=true,south=true,west=true]
fill ~48 ~-32 ~23 ~49 ~-32 ~23 minecraft:air
setblock ~50 ~-32 ~23 minecraft:light_gray_concrete
fill ~51 ~-32 ~23 ~63 ~-32 ~23 minecraft:air
setblock ~64 ~-32 ~23 minecraft:light_gray_concrete
setblock ~4 ~-32 ~24 minecraft:light_gray_concrete
fill ~5 ~-32 ~24 ~17 ~-32 ~24 minecraft:air
setblock ~18 ~-32 ~24 minecraft:light_gray_concrete
fill ~19 ~-32 ~24 ~25 ~-32 ~24 minecraft:air
setblock ~26 ~-32 ~24 minecraft:glass_pane[east=true,south=true]
setblock ~27 ~-32 ~24 minecraft:glass_pane[west=true]
fill ~28 ~-32 ~24 ~29 ~-32 ~24 minecraft:air
setblock ~30 ~-32 ~24 minecraft:quartz_pillar
fill ~31 ~-32 ~24 ~37 ~-32 ~24 minecraft:air
setblock ~38 ~-32 ~24 minecraft:quartz_pillar
fill ~39 ~-32 ~24 ~40 ~-32 ~24 minecraft:air
setblock ~41 ~-32 ~24 minecraft:glass_pane[east=true]
setblock ~42 ~-32 ~24 minecraft:glass_pane[south=true,west=true]
fill ~43 ~-32 ~24 ~46 ~-32 ~24 minecraft:air
setblock ~47 ~-32 ~24 minecraft:iron_bars[north=true,south=true]
fill ~48 ~-32 ~24 ~49 ~-32 ~24 minecraft:air
setblock ~50 ~-32 ~24 minecraft:light_gray_concrete
fill ~51 ~-32 ~24 ~63 ~-32 ~24 minecraft:air
setblock ~64 ~-32 ~24 minecraft:light_gray_concrete
setblock ~4 ~-32 ~25 minecraft:light_gray_concrete
fill ~5 ~-32 ~25 ~17 ~-32 ~25 minecraft:air
setblock ~18 ~-32 ~25 minecraft:light_gray_concrete
fill ~19 ~-32 ~25 ~24 ~-32 ~25 minecraft:air
fill ~25 ~-32 ~25 ~26 ~-32 ~25 minecraft:quartz_pillar
fill ~27 ~-32 ~25 ~41 ~-32 ~25 minecraft:air
setblock ~42 ~-32 ~25 minecraft:glass_pane[north=true,east=true]
setblock ~43 ~-32 ~25 minecraft:quartz_pillar
fill ~44 ~-32 ~25 ~46 ~-32 ~25 minecraft:air
setblock ~47 ~-32 ~25 minecraft:iron_bars[north=true]
fill ~48 ~-32 ~25 ~49 ~-32 ~25 minecraft:air
setblock ~50 ~-32 ~25 minecraft:light_gray_concrete
fill ~51 ~-32 ~25 ~63 ~-32 ~25 minecraft:air
setblock ~64 ~-32 ~25 minecraft:light_gray_concrete
setblock ~4 ~-32 ~26 minecraft:light_gray_concrete
fill ~5 ~-32 ~26 ~17 ~-32 ~26 minecraft:air
setblock ~18 ~-32 ~26 minecraft:light_gray_concrete
fill ~19 ~-32 ~26 ~23 ~-32 ~26 minecraft:air
setblock ~24 ~-32 ~26 minecraft:glass_pane[east=true,south=true]
setblock ~25 ~-32 ~26 minecraft:glass_pane[north=true,west=true]
fill ~26 ~-32 ~26 ~42 ~-32 ~26 minecraft:air
setblock ~43 ~-32 ~26 minecraft:quartz_pillar
setblock ~44 ~-32 ~26 minecraft:glass_pane[south=true,west=true]
fill ~45 ~-32 ~26 ~49 ~-32 ~26 minecraft:air
setblock ~50 ~-32 ~26 minecraft:light_gray_concrete
fill ~51 ~-32 ~26 ~63 ~-32 ~26 minecraft:air
setblock ~64 ~-32 ~26 minecraft:light_gray_concrete
setblock ~4 ~-32 ~27 minecraft:light_gray_concrete
fill ~5 ~-32 ~27 ~17 ~-32 ~27 minecraft:air
setblock ~18 ~-32 ~27 minecraft:light_gray_concrete
fill ~19 ~-32 ~27 ~23 ~-32 ~27 minecraft:air
setblock ~24 ~-32 ~27 minecraft:glass_pane[north=true]
fill ~25 ~-32 ~27 ~43 ~-32 ~27 minecraft:air
setblock ~44 ~-32 ~27 minecraft:glass_pane[north=true]
fill ~45 ~-32 ~27 ~49 ~-32 ~27 minecraft:air
setblock ~50 ~-32 ~27 minecraft:light_gray_concrete
fill ~51 ~-32 ~27 ~63 ~-32 ~27 minecraft:air
setblock ~64 ~-32 ~27 minecraft:light_gray_concrete
setblock ~4 ~-32 ~28 minecraft:light_gray_concrete
fill ~5 ~-32 ~28 ~17 ~-32 ~28 minecraft:air
setblock ~18 ~-32 ~28 minecraft:light_gray_concrete
fill ~19 ~-32 ~28 ~22 ~-32 ~28 minecraft:air
setblock ~23 ~-32 ~28 minecraft:glass_pane[south=true]
fill ~24 ~-32 ~28 ~44 ~-32 ~28 minecraft:air
setblock ~45 ~-32 ~28 minecraft:glass_pane[south=true]
fill ~46 ~-32 ~28 ~49 ~-32 ~28 minecraft:air
setblock ~50 ~-32 ~28 minecraft:light_gray_concrete
fill ~51 ~-32 ~28 ~63 ~-32 ~28 minecraft:air
setblock ~64 ~-32 ~28 minecraft:light_gray_concrete
setblock ~4 ~-32 ~29 minecraft:light_gray_concrete
fill ~5 ~-32 ~29 ~17 ~-32 ~29 minecraft:air
setblock ~18 ~-32 ~29 minecraft:light_gray_concrete
fill ~19 ~-32 ~29 ~21 ~-32 ~29 minecraft:air
fill ~22 ~-32 ~29 ~23 ~-32 ~29 minecraft:quartz_pillar
fill ~24 ~-32 ~29 ~44 ~-32 ~29 minecraft:air
setblock ~45 ~-32 ~29 minecraft:glass_pane[north=true,east=true]
setblock ~46 ~-32 ~29 minecraft:glass_pane[south=true,west=true]
fill ~47 ~-32 ~29 ~49 ~-32 ~29 minecraft:air
setblock ~50 ~-32 ~29 minecraft:light_gray_concrete
fill ~51 ~-32 ~29 ~63 ~-32 ~29 minecraft:air
setblock ~64 ~-32 ~29 minecraft:light_gray_concrete
setblock ~4 ~-32 ~30 minecraft:light_gray_concrete
fill ~5 ~-32 ~30 ~17 ~-32 ~30 minecraft:air
setblock ~18 ~-32 ~30 minecraft:light_gray_concrete
fill ~19 ~-32 ~30 ~21 ~-32 ~30 minecraft:air
setblock ~22 ~-32 ~30 minecraft:glass_pane[north=true,south=true]
setblock ~23 ~-32 ~30 minecraft:air
setblock ~24 ~-32 ~30 minecraft:quartz_pillar
fill ~25 ~-32 ~30 ~43 ~-32 ~30 minecraft:air
setblock ~44 ~-32 ~30 minecraft:quartz_pillar
setblock ~45 ~-32 ~30 minecraft:air
setblock ~46 ~-32 ~30 minecraft:quartz_pillar
fill ~47 ~-32 ~30 ~49 ~-32 ~30 minecraft:air
setblock ~50 ~-32 ~30 minecraft:light_gray_concrete
fill ~51 ~-32 ~30 ~63 ~-32 ~30 minecraft:air
setblock ~64 ~-32 ~30 minecraft:light_gray_concrete
setblock ~4 ~-32 ~31 minecraft:light_gray_concrete
fill ~5 ~-32 ~31 ~17 ~-32 ~31 minecraft:air
setblock ~18 ~-32 ~31 minecraft:light_gray_concrete
fill ~19 ~-32 ~31 ~21 ~-32 ~31 minecraft:air
setblock ~22 ~-32 ~31 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-32 ~31 ~45 ~-32 ~31 minecraft:air
setblock ~46 ~-32 ~31 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-32 ~31 ~49 ~-32 ~31 minecraft:air
setblock ~50 ~-32 ~31 minecraft:light_gray_concrete
fill ~51 ~-32 ~31 ~63 ~-32 ~31 minecraft:air
setblock ~64 ~-32 ~31 minecraft:light_gray_concrete
fill ~4 ~-32 ~32 ~18 ~-32 ~32 minecraft:light_gray_concrete
setblock ~19 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-32 ~32 minecraft:light_gray_concrete
setblock ~21 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-32 ~32 minecraft:glass_pane[north=true,west=true]
fill ~23 ~-32 ~32 ~32 ~-32 ~32 minecraft:air
fill ~33 ~-32 ~32 ~35 ~-32 ~32 minecraft:glass
fill ~36 ~-32 ~32 ~45 ~-32 ~32 minecraft:air
setblock ~46 ~-32 ~32 minecraft:glass_pane[north=true,east=true]
setblock ~47 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-32 ~32 minecraft:light_gray_concrete
setblock ~49 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~50 ~-32 ~32 minecraft:light_gray_concrete
fill ~51 ~-32 ~32 ~53 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~54 ~-32 ~32 minecraft:light_gray_concrete
fill ~55 ~-32 ~32 ~56 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
fill ~57 ~-32 ~32 ~58 ~-32 ~32 minecraft:light_gray_concrete
fill ~59 ~-32 ~32 ~61 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~62 ~-32 ~32 minecraft:light_gray_concrete
setblock ~63 ~-32 ~32 minecraft:glass_pane[east=true,west=true]
setblock ~64 ~-32 ~32 minecraft:light_gray_concrete
setblock ~4 ~-32 ~33 minecraft:light_gray_concrete
fill ~5 ~-32 ~33 ~32 ~-32 ~33 minecraft:air
setblock ~33 ~-32 ~33 minecraft:glass
setblock ~34 ~-32 ~33 minecraft:air
setblock ~35 ~-32 ~33 minecraft:glass
fill ~36 ~-32 ~33 ~63 ~-32 ~33 minecraft:air
setblock ~64 ~-32 ~33 minecraft:light_gray_concrete
setblock ~4 ~-32 ~34 minecraft:light_gray_concrete
fill ~5 ~-32 ~34 ~32 ~-32 ~34 minecraft:air
fill ~33 ~-32 ~34 ~35 ~-32 ~34 minecraft:glass
fill ~36 ~-32 ~34 ~63 ~-32 ~34 minecraft:air
setblock ~64 ~-32 ~34 minecraft:light_gray_concrete
setblock ~4 ~-32 ~35 minecraft:light_gray_concrete
fill ~5 ~-32 ~35 ~32 ~-32 ~35 minecraft:air
setblock ~33 ~-32 ~35 minecraft:glass
setblock ~34 ~-32 ~35 minecraft:air
setblock ~35 ~-32 ~35 minecraft:glass
fill ~36 ~-32 ~35 ~63 ~-32 ~35 minecraft:air
setblock ~64 ~-32 ~35 minecraft:light_gray_concrete
fill ~4 ~-32 ~36 ~18 ~-32 ~36 minecraft:light_gray_concrete
setblock ~19 ~-32 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~20 ~-32 ~36 minecraft:light_gray_concrete
setblock ~21 ~-32 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~22 ~-32 ~36 minecraft:glass_pane[south=true,west=true]
fill ~23 ~-32 ~36 ~32 ~-32 ~36 minecraft:air
fill ~33 ~-32 ~36 ~35 ~-32 ~36 minecraft:glass
fill ~36 ~-32 ~36 ~45 ~-32 ~36 minecraft:air
setblock ~46 ~-32 ~36 minecraft:glass_pane[east=true,south=true]
setblock ~47 ~-32 ~36 minecraft:glass_pane[east=true,west=true]
setblock ~48 ~-32 ~36 minecraft:light_gray_concrete
setblock ~49 ~-32 ~36 minecraft:glass_pane[east=true,west=true]
fill ~50 ~-32 ~36 ~64 ~-32 ~36 minecraft:light_gray_concrete
setblock ~4 ~-32 ~37 minecraft:light_gray_concrete
fill ~5 ~-32 ~37 ~17 ~-32 ~37 minecraft:air
setblock ~18 ~-32 ~37 minecraft:light_gray_concrete
fill ~19 ~-32 ~37 ~21 ~-32 ~37 minecraft:air
setblock ~22 ~-32 ~37 minecraft:glass_pane[north=true,south=true]
fill ~23 ~-32 ~37 ~45 ~-32 ~37 minecraft:air
setblock ~46 ~-32 ~37 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-32 ~37 ~49 ~-32 ~37 minecraft:air
setblock ~50 ~-32 ~37 minecraft:light_gray_concrete
fill ~51 ~-32 ~37 ~63 ~-32 ~37 minecraft:air
setblock ~64 ~-32 ~37 minecraft:light_gray_concrete
setblock ~4 ~-32 ~38 minecraft:light_gray_concrete
fill ~5 ~-32 ~38 ~17 ~-32 ~38 minecraft:air
setblock ~18 ~-32 ~38 minecraft:light_gray_concrete
fill ~19 ~-32 ~38 ~21 ~-32 ~38 minecraft:air
setblock ~22 ~-32 ~38 minecraft:quartz_pillar
setblock ~23 ~-32 ~38 minecraft:air
setblock ~24 ~-32 ~38 minecraft:quartz_pillar
fill ~25 ~-32 ~38 ~43 ~-32 ~38 minecraft:air
setblock ~44 ~-32 ~38 minecraft:quartz_pillar
setblock ~45 ~-32 ~38 minecraft:air
setblock ~46 ~-32 ~38 minecraft:glass_pane[north=true,south=true]
fill ~47 ~-32 ~38 ~49 ~-32 ~38 minecraft:air
setblock ~50 ~-32 ~38 minecraft:light_gray_concrete
fill ~51 ~-32 ~38 ~63 ~-32 ~38 minecraft:air
setblock ~64 ~-32 ~38 minecraft:light_gray_concrete
setblock ~4 ~-32 ~39 minecraft:light_gray_concrete
fill ~5 ~-32 ~39 ~17 ~-32 ~39 minecraft:air
setblock ~18 ~-32 ~39 minecraft:light_gray_concrete
fill ~19 ~-32 ~39 ~21 ~-32 ~39 minecraft:air
setblock ~22 ~-32 ~39 minecraft:glass_pane[north=true,east=true]
setblock ~23 ~-32 ~39 minecraft:glass_pane[south=true,west=true]
fill ~24 ~-32 ~39 ~44 ~-32 ~39 minecraft:air
fill ~45 ~-32 ~39 ~46 ~-32 ~39 minecraft:quartz_pillar
fill ~47 ~-32 ~39 ~49 ~-32 ~39 minecraft:air
setblock ~50 ~-32 ~39 minecraft:light_gray_concrete
fill ~51 ~-32 ~39 ~63 ~-32 ~39 minecraft:air
setblock ~64 ~-32 ~39 minecraft:light_gray_concrete
setblock ~4 ~-32 ~40 minecraft:light_gray_concrete
fill ~5 ~-32 ~40 ~17 ~-32 ~40 minecraft:air
setblock ~18 ~-32 ~40 minecraft:light_gray_concrete
fill ~19 ~-32 ~40 ~22 ~-32 ~40 minecraft:air
setblock ~23 ~-32 ~40 minecraft:glass_pane[north=true]
fill ~24 ~-32 ~40 ~44 ~-32 ~40 minecraft:air
setblock ~45 ~-32 ~40 minecraft:glass_pane[north=true]
fill ~46 ~-32 ~40 ~49 ~-32 ~40 minecraft:air
setblock ~50 ~-32 ~40 minecraft:light_gray_concrete
fill ~51 ~-32 ~40 ~63 ~-32 ~40 minecraft:air
setblock ~64 ~-32 ~40 minecraft:light_gray_concrete
setblock ~4 ~-32 ~41 minecraft:light_gray_concrete
fill ~5 ~-32 ~41 ~17 ~-32 ~41 minecraft:air
setblock ~18 ~-32 ~41 minecraft:light_gray_concrete
fill ~19 ~-32 ~41 ~23 ~-32 ~41 minecraft:air
setblock ~24 ~-32 ~41 minecraft:glass_pane[south=true]
fill ~25 ~-32 ~41 ~43 ~-32 ~41 minecraft:air
setblock ~44 ~-32 ~41 minecraft:glass_pane[south=true]
fill ~45 ~-32 ~41 ~49 ~-32 ~41 minecraft:air
setblock ~50 ~-32 ~41 minecraft:light_gray_concrete
fill ~51 ~-32 ~41 ~63 ~-32 ~41 minecraft:air
setblock ~64 ~-32 ~41 minecraft:light_gray_concrete
setblock ~4 ~-32 ~42 minecraft:light_gray_concrete
fill ~5 ~-32 ~42 ~17 ~-32 ~42 minecraft:air
setblock ~18 ~-32 ~42 minecraft:light_gray_concrete
fill ~19 ~-32 ~42 ~23 ~-32 ~42 minecraft:air
setblock ~24 ~-32 ~42 minecraft:glass_pane[north=true,east=true]
setblock ~25 ~-32 ~42 minecraft:quartz_pillar
fill ~26 ~-32 ~42 ~42 ~-32 ~42 minecraft:air
setblock ~43 ~-32 ~42 minecraft:glass_pane[east=true,south=true]
setblock ~44 ~-32 ~42 minecraft:glass_pane[north=true,west=true]
fill ~45 ~-32 ~42 ~49 ~-32 ~42 minecraft:air
setblock ~50 ~-32 ~42 minecraft:light_gray_concrete
fill ~51 ~-32 ~42 ~63 ~-32 ~42 minecraft:air
setblock ~64 ~-32 ~42 minecraft:light_gray_concrete
setblock ~4 ~-32 ~43 minecraft:light_gray_concrete
fill ~5 ~-32 ~43 ~17 ~-32 ~43 minecraft:air
setblock ~18 ~-32 ~43 minecraft:light_gray_concrete
fill ~19 ~-32 ~43 ~20 ~-32 ~43 minecraft:air
setblock ~21 ~-32 ~43 minecraft:iron_bars[south=true]
fill ~22 ~-32 ~43 ~24 ~-32 ~43 minecraft:air
setblock ~25 ~-32 ~43 minecraft:quartz_pillar
setblock ~26 ~-32 ~43 minecraft:glass_pane[south=true,west=true]
fill ~27 ~-32 ~43 ~41 ~-32 ~43 minecraft:air
fill ~42 ~-32 ~43 ~43 ~-32 ~43 minecraft:quartz_pillar
fill ~44 ~-32 ~43 ~49 ~-32 ~43 minecraft:air
setblock ~50 ~-32 ~43 minecraft:light_gray_concrete
fill ~51 ~-32 ~43 ~63 ~-32 ~43 minecraft:air
setblock ~64 ~-32 ~43 minecraft:light_gray_concrete
setblock ~4 ~-32 ~44 minecraft:light_gray_concrete
fill ~5 ~-32 ~44 ~17 ~-32 ~44 minecraft:air
setblock ~18 ~-32 ~44 minecraft:light_gray_concrete
fill ~19 ~-32 ~44 ~20 ~-32 ~44 minecraft:air
setblock ~21 ~-32 ~44 minecraft:iron_bars[north=true,south=true]
fill ~22 ~-32 ~44 ~25 ~-32 ~44 minecraft:air
setblock ~26 ~-32 ~44 minecraft:glass_pane[north=true,east=true]
setblock ~27 ~-32 ~44 minecraft:glass_pane[west=true]
fill ~28 ~-32 ~44 ~29 ~-32 ~44 minecraft:air
setblock ~30 ~-32 ~44 minecraft:quartz_pillar
fill ~31 ~-32 ~44 ~37 ~-32 ~44 minecraft:air
setblock ~38 ~-32 ~44 minecraft:quartz_pillar
fill ~39 ~-32 ~44 ~40 ~-32 ~44 minecraft:air
setblock ~41 ~-32 ~44 minecraft:glass_pane[east=true]
setblock ~42 ~-32 ~44 minecraft:glass_pane[north=true,west=true]
fill ~43 ~-32 ~44 ~49 ~-32 ~44 minecraft:air
setblock ~50 ~-32 ~44 minecraft:light_gray_concrete
fill ~51 ~-32 ~44 ~63 ~-32 ~44 minecraft:air
setblock ~64 ~-32 ~44 minecraft:light_gray_concrete
setblock ~4 ~-32 ~45 minecraft:light_gray_concrete
fill ~5 ~-32 ~45 ~17 ~-32 ~45 minecraft:air
setblock ~18 ~-32 ~45 minecraft:light_gray_concrete
fill ~19 ~-32 ~45 ~20 ~-32 ~45 minecraft:air
setblock ~21 ~-32 ~45 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~22 ~-32 ~45 minecraft:iron_bars[west=true]
fill ~23 ~-32 ~45 ~27 ~-32 ~45 minecraft:air
setblock ~28 ~-32 ~45 minecraft:smooth_quartz
setblock ~29 ~-32 ~45 minecraft:quartz_pillar
fill ~30 ~-32 ~45 ~38 ~-32 ~45 minecraft:air
setblock ~39 ~-32 ~45 minecraft:glass_pane[east=true,south=true]
setblock ~40 ~-32 ~45 minecraft:smooth_quartz
fill ~41 ~-32 ~45 ~49 ~-32 ~45 minecraft:air
setblock ~50 ~-32 ~45 minecraft:light_gray_concrete
fill ~51 ~-32 ~45 ~63 ~-32 ~45 minecraft:air
setblock ~64 ~-32 ~45 minecraft:light_gray_concrete
setblock ~4 ~-32 ~46 minecraft:light_gray_concrete
fill ~5 ~-32 ~46 ~17 ~-32 ~46 minecraft:air
setblock ~18 ~-32 ~46 minecraft:light_gray_concrete
fill ~19 ~-32 ~46 ~20 ~-32 ~46 minecraft:air
setblock ~21 ~-32 ~46 minecraft:iron_bars[north=true,south=true]
setblock ~22 ~-32 ~46 minecraft:air
setblock ~23 ~-32 ~46 minecraft:iron_bars[south=true]
fill ~24 ~-32 ~46 ~28 ~-32 ~46 minecraft:air
setblock ~29 ~-32 ~46 minecraft:quartz_pillar
fill ~30 ~-32 ~46 ~31 ~-32 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~32 ~-32 ~46 minecraft:glass_pane[south=true,west=true]
fill ~33 ~-32 ~46 ~35 ~-32 ~46 minecraft:air
setblock ~36 ~-32 ~46 minecraft:glass_pane[east=true,south=true]
setblock ~37 ~-32 ~46 minecraft:glass_pane[east=true,west=true]
setblock ~38 ~-32 ~46 minecraft:quartz_pillar
setblock ~39 ~-32 ~46 minecraft:glass_pane[north=true,west=true]
fill ~40 ~-32 ~46 ~41 ~-32 ~46 minecraft:air
setblock ~42 ~-32 ~46 minecraft:iron_bars[east=true]
fill ~43 ~-32 ~46 ~44 ~-32 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~45 ~-32 ~46 minecraft:iron_bars[east=true,south=true,west=true]
fill ~46 ~-32 ~46 ~48 ~-32 ~46 minecraft:iron_bars[east=true,west=true]
setblock ~49 ~-32 ~46 minecraft:iron_bars[east=true,south=true,west=true]
setblock ~50 ~-32 ~46 minecraft:light_gray_concrete
fill ~51 ~-32 ~46 ~63 ~-32 ~46 minecraft:air
setblock ~64 ~-32 ~46 minecraft:light_gray_concrete
setblock ~4 ~-32 ~47 minecraft:light_gray_concrete
fill ~5 ~-32 ~47 ~17 ~-32 ~47 minecraft:air
setblock ~18 ~-32 ~47 minecraft:light_gray_concrete
fill ~19 ~-32 ~47 ~20 ~-32 ~47 minecraft:air
setblock ~21 ~-32 ~47 minecraft:iron_bars[north=true,east=true]
setblock ~22 ~-32 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~23 ~-32 ~47 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~24 ~-32 ~47 minecraft:iron_bars[east=true,west=true]
setblock ~25 ~-32 ~47 minecraft:iron_bars[west=true]
fill ~26 ~-32 ~47 ~31 ~-32 ~47 minecraft:air
setblock ~32 ~-32 ~47 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-32 ~47 ~35 ~-32 ~47 minecraft:air
setblock ~36 ~-32 ~47 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~47 ~40 ~-32 ~47 minecraft:air
setblock ~41 ~-32 ~47 minecraft:iron_bars[south=true]
fill ~42 ~-32 ~47 ~44 ~-32 ~47 minecraft:air
setblock ~45 ~-32 ~47 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-32 ~47 ~48 ~-32 ~47 minecraft:air
setblock ~49 ~-32 ~47 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-32 ~47 minecraft:light_gray_concrete
fill ~51 ~-32 ~47 ~63 ~-32 ~47 minecraft:air
setblock ~64 ~-32 ~47 minecraft:light_gray_concrete
setblock ~4 ~-32 ~48 minecraft:light_gray_concrete
fill ~5 ~-32 ~48 ~17 ~-32 ~48 minecraft:air
setblock ~18 ~-32 ~48 minecraft:light_gray_concrete
fill ~19 ~-32 ~48 ~31 ~-32 ~48 minecraft:air
setblock ~32 ~-32 ~48 minecraft:light_gray_concrete
fill ~33 ~-32 ~48 ~35 ~-32 ~48 minecraft:air
setblock ~36 ~-32 ~48 minecraft:light_gray_concrete
fill ~37 ~-32 ~48 ~40 ~-32 ~48 minecraft:air
setblock ~41 ~-32 ~48 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-32 ~48 ~44 ~-32 ~48 minecraft:air
setblock ~45 ~-32 ~48 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-32 ~48 ~48 ~-32 ~48 minecraft:air
setblock ~49 ~-32 ~48 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-32 ~48 minecraft:light_gray_concrete
fill ~51 ~-32 ~48 ~63 ~-32 ~48 minecraft:air
setblock ~64 ~-32 ~48 minecraft:light_gray_concrete
setblock ~4 ~-32 ~49 minecraft:light_gray_concrete
fill ~5 ~-32 ~49 ~17 ~-32 ~49 minecraft:air
setblock ~18 ~-32 ~49 minecraft:light_gray_concrete
fill ~19 ~-32 ~49 ~31 ~-32 ~49 minecraft:air
setblock ~32 ~-32 ~49 minecraft:glass_pane[north=true,south=true]
fill ~33 ~-32 ~49 ~35 ~-32 ~49 minecraft:air
setblock ~36 ~-32 ~49 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~49 ~40 ~-32 ~49 minecraft:air
setblock ~41 ~-32 ~49 minecraft:iron_bars[north=true,south=true]
fill ~42 ~-32 ~49 ~44 ~-32 ~49 minecraft:air
setblock ~45 ~-32 ~49 minecraft:iron_bars[north=true,south=true]
fill ~46 ~-32 ~49 ~48 ~-32 ~49 minecraft:air
setblock ~49 ~-32 ~49 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~50 ~-32 ~49 minecraft:light_gray_concrete
fill ~51 ~-32 ~49 ~63 ~-32 ~49 minecraft:air
setblock ~64 ~-32 ~49 minecraft:light_gray_concrete
fill ~4 ~-32 ~50 ~32 ~-32 ~50 minecraft:light_gray_concrete
fill ~33 ~-32 ~50 ~35 ~-32 ~50 minecraft:air
fill ~36 ~-32 ~50 ~64 ~-32 ~50 minecraft:light_gray_concrete
setblock ~4 ~-32 ~51 minecraft:light_gray_concrete
fill ~5 ~-32 ~51 ~17 ~-32 ~51 minecraft:air
setblock ~18 ~-32 ~51 minecraft:light_gray_concrete
fill ~19 ~-32 ~51 ~31 ~-32 ~51 minecraft:air
setblock ~32 ~-32 ~51 minecraft:light_gray_concrete
fill ~33 ~-32 ~51 ~35 ~-32 ~51 minecraft:air
setblock ~36 ~-32 ~51 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~51 ~49 ~-32 ~51 minecraft:air
setblock ~50 ~-32 ~51 minecraft:light_gray_concrete
fill ~51 ~-32 ~51 ~63 ~-32 ~51 minecraft:air
setblock ~64 ~-32 ~51 minecraft:light_gray_concrete
setblock ~4 ~-32 ~52 minecraft:light_gray_concrete
fill ~5 ~-32 ~52 ~17 ~-32 ~52 minecraft:air
setblock ~18 ~-32 ~52 minecraft:light_gray_concrete
fill ~19 ~-32 ~52 ~31 ~-32 ~52 minecraft:air
setblock ~32 ~-32 ~52 minecraft:light_gray_concrete
fill ~33 ~-32 ~52 ~35 ~-32 ~52 minecraft:air
setblock ~36 ~-32 ~52 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~52 ~49 ~-32 ~52 minecraft:air
setblock ~50 ~-32 ~52 minecraft:light_gray_concrete
fill ~51 ~-32 ~52 ~63 ~-32 ~52 minecraft:air
setblock ~64 ~-32 ~52 minecraft:light_gray_concrete
setblock ~4 ~-32 ~53 minecraft:light_gray_concrete
fill ~5 ~-32 ~53 ~17 ~-32 ~53 minecraft:air
setblock ~18 ~-32 ~53 minecraft:light_gray_concrete
fill ~19 ~-32 ~53 ~31 ~-32 ~53 minecraft:air
setblock ~32 ~-32 ~53 minecraft:light_gray_concrete
fill ~33 ~-32 ~53 ~35 ~-32 ~53 minecraft:air
setblock ~36 ~-32 ~53 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~53 ~49 ~-32 ~53 minecraft:air
setblock ~50 ~-32 ~53 minecraft:light_gray_concrete
fill ~51 ~-32 ~53 ~63 ~-32 ~53 minecraft:air
setblock ~64 ~-32 ~53 minecraft:light_gray_concrete
setblock ~4 ~-32 ~54 minecraft:light_gray_concrete
fill ~5 ~-32 ~54 ~17 ~-32 ~54 minecraft:air
setblock ~18 ~-32 ~54 minecraft:light_gray_concrete
fill ~19 ~-32 ~54 ~31 ~-32 ~54 minecraft:air
setblock ~32 ~-32 ~54 minecraft:light_gray_concrete
fill ~33 ~-32 ~54 ~35 ~-32 ~54 minecraft:air
setblock ~36 ~-32 ~54 minecraft:light_gray_concrete
fill ~37 ~-32 ~54 ~49 ~-32 ~54 minecraft:air
setblock ~50 ~-32 ~54 minecraft:light_gray_concrete
fill ~51 ~-32 ~54 ~63 ~-32 ~54 minecraft:air
setblock ~64 ~-32 ~54 minecraft:light_gray_concrete
setblock ~4 ~-32 ~55 minecraft:light_gray_concrete
fill ~5 ~-32 ~55 ~17 ~-32 ~55 minecraft:air
setblock ~18 ~-32 ~55 minecraft:light_gray_concrete
fill ~19 ~-32 ~55 ~31 ~-32 ~55 minecraft:air
setblock ~32 ~-32 ~55 minecraft:light_gray_concrete
fill ~33 ~-32 ~55 ~35 ~-32 ~55 minecraft:air
setblock ~36 ~-32 ~55 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~55 ~49 ~-32 ~55 minecraft:air
setblock ~50 ~-32 ~55 minecraft:light_gray_concrete
fill ~51 ~-32 ~55 ~63 ~-32 ~55 minecraft:air
setblock ~64 ~-32 ~55 minecraft:light_gray_concrete
setblock ~4 ~-32 ~56 minecraft:light_gray_concrete
fill ~5 ~-32 ~56 ~17 ~-32 ~56 minecraft:air
setblock ~18 ~-32 ~56 minecraft:light_gray_concrete
fill ~19 ~-32 ~56 ~31 ~-32 ~56 minecraft:air
setblock ~32 ~-32 ~56 minecraft:light_gray_concrete
fill ~33 ~-32 ~56 ~35 ~-32 ~56 minecraft:air
setblock ~36 ~-32 ~56 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~56 ~49 ~-32 ~56 minecraft:air
setblock ~50 ~-32 ~56 minecraft:light_gray_concrete
fill ~51 ~-32 ~56 ~63 ~-32 ~56 minecraft:air
setblock ~64 ~-32 ~56 minecraft:light_gray_concrete
setblock ~4 ~-32 ~57 minecraft:light_gray_concrete
fill ~5 ~-32 ~57 ~17 ~-32 ~57 minecraft:air
setblock ~18 ~-32 ~57 minecraft:light_gray_concrete
fill ~19 ~-32 ~57 ~31 ~-32 ~57 minecraft:air
setblock ~32 ~-32 ~57 minecraft:light_gray_concrete
fill ~33 ~-32 ~57 ~35 ~-32 ~57 minecraft:air
setblock ~36 ~-32 ~57 minecraft:light_gray_concrete
fill ~37 ~-32 ~57 ~49 ~-32 ~57 minecraft:air
setblock ~50 ~-32 ~57 minecraft:light_gray_concrete
fill ~51 ~-32 ~57 ~63 ~-32 ~57 minecraft:air
setblock ~64 ~-32 ~57 minecraft:light_gray_concrete
setblock ~4 ~-32 ~58 minecraft:light_gray_concrete
fill ~5 ~-32 ~58 ~17 ~-32 ~58 minecraft:air
setblock ~18 ~-32 ~58 minecraft:light_gray_concrete
fill ~19 ~-32 ~58 ~31 ~-32 ~58 minecraft:air
setblock ~32 ~-32 ~58 minecraft:light_gray_concrete
fill ~33 ~-32 ~58 ~35 ~-32 ~58 minecraft:air
setblock ~36 ~-32 ~58 minecraft:light_gray_concrete
fill ~37 ~-32 ~58 ~49 ~-32 ~58 minecraft:air
setblock ~50 ~-32 ~58 minecraft:light_gray_concrete
fill ~51 ~-32 ~58 ~63 ~-32 ~58 minecraft:air
setblock ~64 ~-32 ~58 minecraft:light_gray_concrete
setblock ~4 ~-32 ~59 minecraft:light_gray_concrete
fill ~5 ~-32 ~59 ~17 ~-32 ~59 minecraft:air
setblock ~18 ~-32 ~59 minecraft:light_gray_concrete
fill ~19 ~-32 ~59 ~31 ~-32 ~59 minecraft:air
setblock ~32 ~-32 ~59 minecraft:light_gray_concrete
fill ~33 ~-32 ~59 ~35 ~-32 ~59 minecraft:air
setblock ~36 ~-32 ~59 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~59 ~49 ~-32 ~59 minecraft:air
setblock ~50 ~-32 ~59 minecraft:light_gray_concrete
fill ~51 ~-32 ~59 ~63 ~-32 ~59 minecraft:air
setblock ~64 ~-32 ~59 minecraft:light_gray_concrete
setblock ~4 ~-32 ~60 minecraft:light_gray_concrete
fill ~5 ~-32 ~60 ~17 ~-32 ~60 minecraft:air
setblock ~18 ~-32 ~60 minecraft:light_gray_concrete
fill ~19 ~-32 ~60 ~31 ~-32 ~60 minecraft:air
setblock ~32 ~-32 ~60 minecraft:light_gray_concrete
fill ~33 ~-32 ~60 ~35 ~-32 ~60 minecraft:air
setblock ~36 ~-32 ~60 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~60 ~49 ~-32 ~60 minecraft:air
setblock ~50 ~-32 ~60 minecraft:light_gray_concrete
fill ~51 ~-32 ~60 ~63 ~-32 ~60 minecraft:air
setblock ~64 ~-32 ~60 minecraft:light_gray_concrete
setblock ~4 ~-32 ~61 minecraft:light_gray_concrete
fill ~5 ~-32 ~61 ~17 ~-32 ~61 minecraft:air
setblock ~18 ~-32 ~61 minecraft:light_gray_concrete
fill ~19 ~-32 ~61 ~31 ~-32 ~61 minecraft:air
setblock ~32 ~-32 ~61 minecraft:light_gray_concrete
fill ~33 ~-32 ~61 ~35 ~-32 ~61 minecraft:air
setblock ~36 ~-32 ~61 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~61 ~49 ~-32 ~61 minecraft:air
setblock ~50 ~-32 ~61 minecraft:light_gray_concrete
fill ~51 ~-32 ~61 ~63 ~-32 ~61 minecraft:air
setblock ~64 ~-32 ~61 minecraft:light_gray_concrete
setblock ~4 ~-32 ~62 minecraft:light_gray_concrete
fill ~5 ~-32 ~62 ~17 ~-32 ~62 minecraft:air
setblock ~18 ~-32 ~62 minecraft:light_gray_concrete
fill ~19 ~-32 ~62 ~31 ~-32 ~62 minecraft:air
setblock ~32 ~-32 ~62 minecraft:light_gray_concrete
fill ~33 ~-32 ~62 ~35 ~-32 ~62 minecraft:air
setblock ~36 ~-32 ~62 minecraft:light_gray_concrete
fill ~37 ~-32 ~62 ~49 ~-32 ~62 minecraft:air
setblock ~50 ~-32 ~62 minecraft:light_gray_concrete
fill ~51 ~-32 ~62 ~63 ~-32 ~62 minecraft:air
setblock ~64 ~-32 ~62 minecraft:light_gray_concrete
setblock ~4 ~-32 ~63 minecraft:light_gray_concrete
fill ~5 ~-32 ~63 ~17 ~-32 ~63 minecraft:air
setblock ~18 ~-32 ~63 minecraft:light_gray_concrete
fill ~19 ~-32 ~63 ~31 ~-32 ~63 minecraft:air
setblock ~32 ~-32 ~63 minecraft:light_gray_concrete
fill ~33 ~-32 ~63 ~35 ~-32 ~63 minecraft:air
setblock ~36 ~-32 ~63 minecraft:glass_pane[north=true,south=true]
fill ~37 ~-32 ~63 ~49 ~-32 ~63 minecraft:air
setblock ~50 ~-32 ~63 minecraft:light_gray_concrete
fill ~51 ~-32 ~63 ~63 ~-32 ~63 minecraft:air
setblock ~64 ~-32 ~63 minecraft:light_gray_concrete
fill ~4 ~-32 ~64 ~64 ~-32 ~64 minecraft:light_gray_concrete
fill ~32 ~-32 ~66 ~36 ~-32 ~66 minecraft:polished_andesite
setblock ~32 ~-32 ~67 minecraft:polished_andesite
fill ~33 ~-32 ~67 ~35 ~-32 ~67 minecraft:air
setblock ~36 ~-32 ~67 minecraft:polished_andesite
setblock ~32 ~-32 ~68 minecraft:sea_lantern
setblock ~33 ~-32 ~68 minecraft:air
setblock ~34 ~-32 ~68 minecraft:quartz_pillar
setblock ~35 ~-32 ~68 minecraft:air
setblock ~36 ~-32 ~68 minecraft:sea_lantern
setblock ~32 ~-32 ~69 minecraft:polished_andesite
setblock ~33 ~-32 ~69 minecraft:air
setblock ~34 ~-32 ~69 minecraft:quartz_stairs[facing=west,half=bottom]
setblock ~35 ~-32 ~69 minecraft:air
setblock ~36 ~-32 ~69 minecraft:polished_andesite
fill ~32 ~-32 ~70 ~36 ~-32 ~70 minecraft:polished_andesite
fill ~4 ~-31 ~4 ~64 ~-31 ~4 minecraft:light_gray_concrete
setblock ~4 ~-31 ~5 minecraft:light_gray_concrete
fill ~5 ~-31 ~5 ~17 ~-31 ~5 minecraft:air
setblock ~18 ~-31 ~5 minecraft:light_gray_concrete
fill ~19 ~-31 ~5 ~31 ~-31 ~5 minecraft:air
setblock ~32 ~-31 ~5 minecraft:light_gray_concrete
fill ~33 ~-31 ~5 ~35 ~-31 ~5 minecraft:air
setblock ~36 ~-31 ~5 minecraft:light_gray_concrete
fill ~37 ~-31 ~5 ~49 ~-31 ~5 minecraft:air
setblock ~50 ~-31 ~5 minecraft:light_gray_concrete
setblock ~51 ~-31 ~5 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-31 ~5 ~54 ~-31 ~5 minecraft:air
setblock ~55 ~-31 ~5 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-31 ~5 ~58 ~-31 ~5 minecraft:air
setblock ~59 ~-31 ~5 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-31 ~5 ~62 ~-31 ~5 minecraft:air
setblock ~63 ~-31 ~5 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-31 ~5 minecraft:light_gray_concrete
setblock ~4 ~-31 ~6 minecraft:light_gray_concrete
fill ~5 ~-31 ~6 ~17 ~-31 ~6 minecraft:air
setblock ~18 ~-31 ~6 minecraft:light_gray_concrete
fill ~19 ~-31 ~6 ~31 ~-31 ~6 minecraft:air
setblock ~32 ~-31 ~6 minecraft:light_gray_concrete
fill ~33 ~-31 ~6 ~35 ~-31 ~6 minecraft:air
setblock ~36 ~-31 ~6 minecraft:light_gray_concrete
fill ~37 ~-31 ~6 ~49 ~-31 ~6 minecraft:air
setblock ~50 ~-31 ~6 minecraft:light_gray_concrete
setblock ~51 ~-31 ~6 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-31 ~6 ~54 ~-31 ~6 minecraft:air
setblock ~55 ~-31 ~6 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-31 ~6 ~58 ~-31 ~6 minecraft:air
setblock ~59 ~-31 ~6 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-31 ~6 ~62 ~-31 ~6 minecraft:air
setblock ~63 ~-31 ~6 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-31 ~6 minecraft:light_gray_concrete
setblock ~4 ~-31 ~7 minecraft:light_gray_concrete
fill ~5 ~-31 ~7 ~17 ~-31 ~7 minecraft:air
setblock ~18 ~-31 ~7 minecraft:light_gray_concrete
fill ~19 ~-31 ~7 ~31 ~-31 ~7 minecraft:air
setblock ~32 ~-31 ~7 minecraft:light_gray_concrete
fill ~33 ~-31 ~7 ~35 ~-31 ~7 minecraft:air
setblock ~36 ~-31 ~7 minecraft:light_gray_concrete
fill ~37 ~-31 ~7 ~49 ~-31 ~7 minecraft:air
setblock ~50 ~-31 ~7 minecraft:light_gray_concrete
setblock ~51 ~-31 ~7 minecraft:iron_bars[north=true,south=true,west=true]
fill ~52 ~-31 ~7 ~54 ~-31 ~7 minecraft:air
setblock ~55 ~-31 ~7 minecraft:iron_bars[north=true,south=true]
fill ~56 ~-31 ~7 ~58 ~-31 ~7 minecraft:air
setblock ~59 ~-31 ~7 minecraft:iron_bars[north=true,south=true]
fill ~60 ~-31 ~7 ~62 ~-31 ~7 minecraft:air
setblock ~63 ~-31 ~7 minecraft:iron_bars[north=true,east=true,south=true]
setblock ~64 ~-31 ~7 minecraft:light_gray_concrete
setblock ~4 ~-31 ~8 minecraft:light_gray_concrete
fill ~5 ~-31 ~8 ~17 ~-31 ~8 minecraft:air
setblock ~18 ~-31 ~8 minecraft:light_gray_concrete
fill ~19 ~-31 ~8 ~31 ~-31 ~8 minecraft:air
setblock ~32 ~-31 ~8 minecraft:light_gray_concrete
fill ~33 ~-31 ~8 ~35 ~-31 ~8 minecraft:air
setblock ~36 ~-31 ~8 minecraft:light_gray_concrete
fill ~37 ~-31 ~8 ~49 ~-31 ~8 minecraft:air
setblock ~50 ~-31 ~8 minecraft:light_gray_concrete
setblock ~51 ~-31 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~52 ~-31 ~8 ~54 ~-31 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~55 ~-31 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~56 ~-31 ~8 ~58 ~-31 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~59 ~-31 ~8 minecraft:iron_bars[north=true,east=true,west=true]
fill ~60 ~-31 ~8 ~62 ~-31 ~8 minecraft:iron_bars[east=true,west=true]
setblock ~63 ~-31 ~8 minecraft:iron_bars[north=true,east=true,west=true]
setblock ~64 ~-31 ~8 minecraft:light_gray_concrete
setblock ~4 ~-31 ~9 minecraft:light_gray_concrete
fill ~5 ~-31 ~9 ~17 ~-31 ~9 minecraft:air
setblock ~18 ~-31 ~9 minecraft:light_gray_concrete
fill ~19 ~-31 ~9 ~31 ~-31 ~9 minecraft:air
setblock ~32 ~-31 ~9 minecraft:light_gray_concrete
fill ~33 ~-31 ~9 ~35 ~-31 ~9 minecraft:air
setblock ~36 ~-31 ~9 minecraft:light_gray_concrete
fill ~37 ~-31 ~9 ~49 ~-31 ~9 minecraft:air
setblock ~50 ~-31 ~9 minecraft:light_gray_concrete
fill ~51 ~-31 ~9 ~63 ~-31 ~9 minecraft:air
setblock ~64 ~-31 ~9 minecraft:light_gray_concrete
setblock ~4 ~-31 ~10 minecraft:light_gray_concrete
fill ~5 ~-31 ~10 ~17 ~-31 ~10 minecraft:air
setblock ~18 ~-31 ~10 minecraft:light_gray_concrete
fill ~19 ~-31 ~10 ~31 ~-31 ~10 minecraft:air
setblock ~32 ~-31 ~10 minecraft:light_gray_concrete
fill ~33 ~-31 ~10 ~35 ~-31 ~10 minecraft:air
setblock ~36 ~-31 ~10 minecraft:light_gray_concrete
fill ~37 ~-31 ~10 ~49 ~-31 ~10 minecraft:air
setblock ~50 ~-31 ~10 minecraft:light_gray_concrete
fill ~51 ~-31 ~10 ~63 ~-31 ~10 minecraft:air
setblock ~64 ~-31 ~10 minecraft:light_gray_concrete
setblock ~4 ~-31 ~11 minecraft:light_gray_concrete
fill ~5 ~-31 ~11 ~17 ~-31 ~11 minecraft:air
setblock ~18 ~-31 ~11 minecraft:light_gray_concrete
fill ~19 ~-31 ~11 ~31 ~-31 ~11 minecraft:air
setblock ~32 ~-31 ~11 minecraft:light_gray_concrete
fill ~33 ~-31 ~11 ~35 ~-31 ~11 minecraft:air
setblock ~36 ~-31 ~11 minecraft:light_gray_concrete
fill ~37 ~-31 ~11 ~49 ~-31 ~11 minecraft:air
setblock ~50 ~-31 ~11 minecraft:light_gray_concrete
fill ~51 ~-31 ~11 ~63 ~-31 ~11 minecraft:air
setblock ~64 ~-31 ~11 minecraft:light_gray_concrete
setblock ~4 ~-31 ~12 minecraft:light_gray_concrete
fill ~5 ~-31 ~12 ~17 ~-31 ~12 minecraft:air
setblock ~18 ~-31 ~12 minecraft:light_gray_concrete
fill ~19 ~-31 ~12 ~31 ~-31 ~12 minecraft:air
setblock ~32 ~-31 ~12 minecraft:light_gray_concrete
fill ~33 ~-31 ~12 ~35 ~-31 ~12 minecraft:air
setblock ~36 ~-31 ~12 minecraft:light_gray_concrete
fill ~37 ~-31 ~12 ~49 ~-31 ~12 minecraft:air
setblock ~50 ~-31 ~12 minecraft:light_gray_concrete
fill ~51 ~-31 ~12 ~63 ~-31 ~12 minecraft:air
setblock ~64 ~-31 ~12 minecraft:light_gray_concrete
setblock ~4 ~-31 ~13 minecraft:light_gray_concrete
fill ~5 ~-31 ~13 ~17 ~-31 ~13 minecraft:air
setblock ~18 ~-31 ~13 minecraft:light_gray_concrete
fill ~19 ~-31 ~13 ~31 ~-31 ~13 minecraft:air
setblock ~32 ~-31 ~13 minecraft:light_gray_concrete
fill ~33 ~-31 ~13 ~35 ~-31 ~13 minecraft:air
setblock ~36 ~-31 ~13 minecraft:light_gray_concrete
fill ~37 ~-31 ~13 ~49 ~-31 ~13 minecraft:air
setblock ~50 ~-31 ~13 minecraft:light_gray_concrete
fill ~51 ~-31 ~13 ~63 ~-31 ~13 minecraft:air
setblock ~64 ~-31 ~13 minecraft:light_gray_concrete
setblock ~4 ~-31 ~14 minecraft:light_gray_concrete
fill ~5 ~-31 ~14 ~17 ~-31 ~14 minecraft:air
setblock ~18 ~-31 ~14 minecraft:light_gray_concrete
fill ~19 ~-31 ~14 ~31 ~-31 ~14 minecraft:air
setblock ~32 ~-31 ~14 minecraft:light_gray_concrete
fill ~33 ~-31 ~14 ~35 ~-31 ~14 minecraft:air
setblock ~36 ~-31 ~14 minecraft:light_gray_concrete
fill ~37 ~-31 ~14 ~49 ~-31 ~14 minecraft:air
setblock ~50 ~-31 ~14 minecraft:light_gray_concrete
fill ~51 ~-31 ~14 ~63 ~-31 ~14 minecraft:air
setblock ~64 ~-31 ~14 minecraft:light_gray_concrete
setblock ~4 ~-31 ~15 minecraft:light_gray_concrete
fill ~5 ~-31 ~15 ~17 ~-31 ~15 minecraft:air
setblock ~18 ~-31 ~15 minecraft:light_gray_concrete
fill ~19 ~-31 ~15 ~31 ~-31 ~15 minecraft:air
setblock ~32 ~-31 ~15 minecraft:light_gray_concrete
fill ~33 ~-31 ~15 ~35 ~-31 ~15 minecraft:air
setblock ~36 ~-31 ~15 minecraft:light_gray_concrete
fill ~37 ~-31 ~15 ~49 ~-31 ~15 minecraft:air
setblock ~50 ~-31 ~15 minecraft:light_gray_concrete
fill ~51 ~-31 ~15 ~63 ~-31 ~15 minecraft:air
setblock ~64 ~-31 ~15 minecraft:light_gray_concrete
setblock ~4 ~-31 ~16 minecraft:light_gray_concrete
fill ~5 ~-31 ~16 ~17 ~-31 ~16 minecraft:air
setblock ~18 ~-31 ~16 minecraft:light_gray_concrete
fill ~19 ~-31 ~16 ~31 ~-31 ~16 minecraft:air
setblock ~32 ~-31 ~16 minecraft:light_gray_concrete
fill ~33 ~-31 ~16 ~35 ~-31 ~16 minecraft:air
setblock ~36 ~-31 ~16 minecraft:light_gray_concrete
fill ~37 ~-31 ~16 ~49 ~-31 ~16 minecraft:air
setblock ~50 ~-31 ~16 minecraft:light_gray_concrete
fill ~51 ~-31 ~16 ~63 ~-31 ~16 minecraft:air
setblock ~64 ~-31 ~16 minecraft:light_gray_concrete
setblock ~4 ~-31 ~17 minecraft:light_gray_concrete
fill ~5 ~-31 ~17 ~17 ~-31 ~17 minecraft:air
setblock ~18 ~-31 ~17 minecraft:light_gray_concrete
fill ~19 ~-31 ~17 ~31 ~-31 ~17 minecraft:air
setblock ~32 ~-31 ~17 minecraft:light_gray_concrete
fill ~33 ~-31 ~17 ~35 ~-31 ~17 minecraft:air
setblock ~36 ~-31 ~17 minecraft:light_gray_concrete
fill ~37 ~-31 ~17 ~49 ~-31 ~17 minecraft:air
setblock ~50 ~-31 ~17 minecraft:light_gray_concrete
fill ~51 ~-31 ~17 ~63 ~-31 ~17 minecraft:air
setblock ~64 ~-31 ~17 minecraft:light_gray_concrete
fill ~4 ~-31 ~18 ~32 ~-31 ~18 minecraft:light_gray_concrete
fill ~33 ~-31 ~18 ~35 ~-31 ~18 minecraft:air
fill ~36 ~-31 ~18 ~64 ~-31 ~18 minecraft:light_gray_concrete
setblock ~4 ~-31 ~19 minecraft:light_gray_concrete
fill ~5 ~-31 ~19 ~17 ~-31 ~19 minecraft:air
setblock ~18 ~-31 ~19 minecraft:light_gray_concrete
setblock ~19 ~-31 ~19 minecraft:iron_bars[north=true,south=true,west=true]
schedule function hive:weiter/10 3t
tellraw @a [{"text":"[Hive] ","color":"red"},{"text":"Teil 9 von 18 fertig","color":"gray"}]