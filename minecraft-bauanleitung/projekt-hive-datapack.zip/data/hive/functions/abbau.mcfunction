# Entfernt nichts automatisch – nur ein Hinweis.
tellraw @s {"text":"Zum Rückgängigmachen am besten vorher eine Kopie der Welt machen.","color":"yellow"}